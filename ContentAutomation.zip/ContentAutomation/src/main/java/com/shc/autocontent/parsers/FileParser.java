package com.shc.autocontent.parsers;

import java.util.List;


public interface FileParser<T>{

	public List<T> parseLine(String line);
	public List<T> getCurrentOutput();
	
	
}
