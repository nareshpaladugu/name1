package com.shc.autocontent.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class JodaDateTimeUtility {


	/**
	 * Calculates whether the current date is falling between the startDate and endDate
	 * If startDate is null, then only endDate is evaluated
	 * If endDate is null, then only startDate is evaluated
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static boolean validateDate(String startDate, String endDate){

		//		DateTime end, start;
		DateTimeFormatter fmtOut = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		//		DateTime end = new DateTime(endDate);
		DateTime end = endDate == null ? null : fmtOut.parseDateTime(endDate);
		DateTime start = startDate == null? null : fmtOut.parseDateTime(startDate);

		//System.out.println(" In validate date : End is  "+ end+ "  Start is "+ start);

		if(start != null && end != null)
			return start.isBeforeNow() &&  end.isAfterNow();
		else if (start == null && end != null)
			return end.isAfterNow();
		else if (start != null && end == null)
			return start.isBeforeNow();
		else
			return false;
	}

	/**
	 * Calculates whether the dateToVerify date is falling between the startDate and endDate
	 * If startDate is null, then only endDate is evaluated
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static boolean validateDateBetweenDates(String startDate, String endDate, String dateToVerifyStart, String dateToVerifyEnd){
		DateTime end = new DateTime(convertToJodaFormat(endDate));
		DateTime start = startDate == null? null : new DateTime(convertToJodaFormat(startDate));
		//System.out.println("End is  "+ end+ "  Start is "+ start);

		DateTime dateToVerifyStartDT = new DateTime(convertToJodaFormat(dateToVerifyStart));
		DateTime dateToVerifyEndDT = new DateTime(convertToJodaFormat(dateToVerifyEnd));

		boolean returnVal = false;
		returnVal = (dateToVerifyStartDT.equals(start) || dateToVerifyStartDT.isAfter(start)) && (dateToVerifyStartDT.equals(end) || dateToVerifyStartDT.isBefore(end)); 
		if(returnVal == true)
			return returnVal;

		returnVal = ( dateToVerifyEndDT.isAfter(start)) && (dateToVerifyEndDT.equals(end) || dateToVerifyEndDT.isBefore(end));
		if(returnVal == true)
			return returnVal;

		returnVal = start.isAfter(dateToVerifyStartDT) && start.isBefore(dateToVerifyEndDT);
		return returnVal;


	}

	public static boolean validateDateBetweenDates_(String startDateFromUser, String endDateFromUser, String dateToVerifyStart, String dateToVerifyEnd)
	{
		DateTime endDateUser = new DateTime(convertToJodaFormat(endDateFromUser));
		DateTime startDateUser = new DateTime(convertToJodaFormat(startDateFromUser));

		DateTime dateToVerifyStartDT = new DateTime(convertToJodaFormat(dateToVerifyStart));
		DateTime dateToVerifyEndDT = new DateTime(convertToJodaFormat(dateToVerifyEnd));

		System.out.println("startDateUser  "+ startDateUser+ "  dateToVerifyStartDT "+ dateToVerifyStartDT);
		System.out.println("endDateUser  "+ endDateUser+ "  dateToVerifyEndDT "+ dateToVerifyEndDT);

		boolean result = (startDateUser.isBefore(dateToVerifyStartDT)
				|| startDateUser.isEqual(dateToVerifyStartDT)) && (endDateUser.isAfter(dateToVerifyEndDT)
						||endDateUser.isEqual(dateToVerifyEndDT) ) ;

		System.out.println("Result ............ "+result);

		return result;

	}


	/**
	 * Calculates whether the dateToVerify date is falling between the startDate and endDate
	 * If startDate is null, then only endDate is evaluated
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static boolean validateDateBasedOnEndDate(String expectedEndDate, String dateToVerifyEnd){


		return expectedEndDate.equals(dateToVerifyEnd);

	}

	/**
	 * Returns whether the saleenddate is a future date or not
	 * @param saleEndDate
	 * @return
	 */
	public static boolean isCurrentDateBeforeEndDate(String saleEndDate){

		DateTime jodaSaleEndDate = convertToJodaFormat(saleEndDate);
		return jodaSaleEndDate.isAfterNow();
	}


	/**
	 * Returns any date in joda TZ format as a String object
	 * @param date
	 * @return
	 */
	public static String getJodaTimeFormatString(String date){

		if(date==null) return date;

		DateTimeFormatter fmt, fmtOut = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		DateTime jodaDate = null;
		boolean proceedToNextFormat = false;

		try{
			fmt = DateTimeFormat.forPattern("MMddyyyy");
			jodaDate = fmt.parseDateTime(date);
			jodaDate = jodaDate.plusHours(24).minusSeconds(1);
		}catch(IllegalArgumentException e){
			proceedToNextFormat = true;
		}
		
		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}
		
		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyyMMdd");
				jodaDate = fmt.parseDateTime(date);
				jodaDate = jodaDate.plusHours(24).minusSeconds(1);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
				//jodaDate = jodaDate.plusHours(24).minusSeconds(1);
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.S");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
				jodaDate = fmt.parseDateTime(date);
				proceedToNextFormat = false;
			}catch(IllegalArgumentException e){
				proceedToNextFormat = true;
			}
		}

		if(proceedToNextFormat){
			try{
				fmt = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				jodaDate = fmt.parseDateTime(date);
			}catch(IllegalArgumentException e){
				//e.printStackTrace();
				System.out.println("Date: "+date+" neither in MMddyyyy or yyyy-MM-dd hh:mm:ss format or yyyy-MM-ddThh:mm:ss.SSSZ.  Please check format");
			}
		}




		return fmtOut.print(jodaDate);

	}


	public static DateTime convertToJodaFormat(String date){
		if(date == null)
			return null;
		String jodaDate = getJodaTimeFormatString(date);
		DateTimeFormatter fmtOut = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return fmtOut.parseDateTime(jodaDate);
	}

	public static boolean isFirstDateBeforeSecond(String firstdate, String secondDate ){

		DateTime firstDt = convertToJodaFormat(firstdate);
		DateTime secondDt = convertToJodaFormat(secondDate);

		if(firstDt == null || secondDt == null)
			return false;

		return firstDt.isBefore(secondDt);
	}

	public static String convertUnixTSToTZFormat(Long unixTS){
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));

		return dateFormatGmt.format(new Date(unixTS));
	}

	public static String convertUnixTSToTZFormat(Long unixTS, String timeZone){
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone(timeZone));

		return dateFormatGmt.format(new Date(unixTS));
	}

	
	public static String convertUnixTSToTZ_CSTFormat(Long unixTS, String timeZone){
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone(timeZone));

		return dateFormatGmt.format(new Date(unixTS));
	}
	
	public static boolean isValidDate(String sDate)
	{
		DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		try {
			dtf.parseDateTime(sDate);
		} catch (Exception e) {
			return false;
		}

		return true;

	}

	public static String getTodaysDateTime()
	{
		return DateUtil.getCurrentDateAndTimeInRquiredFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	}

	/**
	 * Method to get random future date
	 * @return
	 */
	public static Date getRandomFutureDate() {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, GenericUtil.getRandomNumberInRange(1,365));
		return c.getTime();
	}
	
	/**
	 * Method to get date for number of days before/after the current date.
	 * @param n will get added/substracted in/from current date. n<0 will give past date, n=0 will give current date & n>0 will give future date 
	 * @param dateFormat required date format
	 * @return
	 */
	public static String getDateFromCurrentDate(int n, String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		cal.add(Calendar.DATE, n);
		return format.format(cal.getTime());
	}
}