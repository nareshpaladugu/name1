package com.shc.autocontent.reports.vo;

import java.util.LinkedHashMap;
import java.util.Map;

public class ExcelResultReportVO {

	public SummaryVO getSummaryVO() {
		return summaryVO;
	}

	public void setSummaryVO(SummaryVO summaryVO) {
		this.summaryVO = summaryVO;
	}

	public Map<String, Map<String, Map<String, String>>> getDetailsResult() {
		return detailsResult;
	}

	public void setDetailsResult(
			Map<String, Map<String, Map<String, String>>> detailsResult) {
		this.detailsResult = detailsResult;
	}

	private SummaryVO summaryVO;
	
	//key- xml name - key - part number  , and value -  map of properties and match/mistmatch details 
	private Map<String,Map<String,Map<String,String>>> detailsResult = new LinkedHashMap<String,Map<String,Map<String,String>>>();
}
