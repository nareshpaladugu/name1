package com.shc.autocontent.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.shc.content.entity.CatentryIds;

public class DBUtil {

	public static int db2QueryHitCounter = 0;
	public static long db2QueryHitTime = 0;


	/**
	 * Returns null if no result found, else the resultset object for further manipulation
	 * @param sQuery
	 * @param resultSetScrollableFlag Set only if ResultSet may have CLOBs in it
	 * @return
	 */
	public static ResultSet executeQueryReturnAll(String sQuery,Boolean... resultSetScrollableFlag){

		db2QueryHitCounter++;
		long start = System.currentTimeMillis();

		Statement stmt ;
		try {
			if(resultSetScrollableFlag.length==0)
				stmt = DBConnecter.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			else
				stmt = DBConnecter.getConnection().createStatement();

			ResultSet rs = stmt.executeQuery(sQuery);

			if(rs.next()){
				if(resultSetScrollableFlag.length==0)
					rs.beforeFirst();

				return rs;
			}
			else{
				stmt.close();
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException("Error in executing sql query "+sQuery+" \n " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
	}

	/**
	 * Returns null if no result found, else the resultset object for further manipulation
	 * @param sQuery
	 * @return ResultSet - result objects
	 */
	public static ResultSet executeQueryReturnSingleResultSet(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();

		try {
			Statement stmt = DBConnecter.getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sQuery);

			if(rs.next()){
				return rs;
			}
			else{
				stmt.close();
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException("Error in executing sql query "+sQuery+" \n " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
	}

	/**
	 * Returns first column's first value or Returns null if no result found
	 * Use for single value return queries
	 * @param sQuery
	 * @return - Returns first column's first value by default
	 */
	public static String executeQuerySingleResult(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		ResultSet rs = executeQueryReturnAll(sQuery);
		String output = null;
		if(rs == null){
			return null;
		}
		try {
			rs.next();
			output = rs.getString(1);
			closeCursor(rs);
			return output;
		} catch (SQLException e) {
			throw new DBException(sQuery+ " :Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}

	}

	/**
	 * Returns null if no result found, else list of strings of first column
	 * @param sQuery
	 * @return
	 */
	public static List<String> executeQuerySingleColMulRow(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		int iIndex = 1;
		ResultSet rs = executeQueryReturnAll(sQuery);
		List<String> lstResults = new ArrayList<String>();
		if(rs == null)
			return null;
		try {
			rs.next();
			lstResults.add(rs.getString(iIndex));
			while(rs.next())
				lstResults.add(rs.getString(iIndex));
			closeCursor(rs);
		} catch (SQLException e) {
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return lstResults;
	}

	/**
	 * Returns null if no result found, else list of strings of first column
	 * @param sQuery
	 * @return
	 */
	public static List<String> executeQueryMultiColumnSingleRow(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		ResultSet rs = executeQueryReturnAll(sQuery);
		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		List<String> lstResults = new ArrayList<String>();
		if(rs == null)
			return null;
		try {
			rs.next();
			for(int i = 1; i<= lstColumns.length; i++){
				lstResults.add(rs.getString(i));
			}
			closeCursor(rs);
		} catch (SQLException e) {
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return lstResults;
	}


	/**
	 * Closes the result set and the corresponding statement
	 * @param rs
	 */
	public static void closeCursor(ResultSet rs){
		try {
			if(rs!=null)
			{
				rs.getStatement().close();
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error in closing resultset.");
		}

	}

	/**
	 * Returns null if no result found, else list of strings of first column
	 * @param sQuery
	 * @return
	 */
	public static Map<String,List<String>> executeQueryMultiRowMultiColumn(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		Map<String,List<String>> resultMap = new LinkedHashMap<String,List<String>>();

		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return resultMap;
		try {

			while(rs.next())
			{
				//for each row new list of column values in sequence
				List<String> singleRowresult = new LinkedList<String>();

				for (int i=2;i<=lstColumns.length;i++) {
					singleRowresult.add(rs.getString(i));
				}

				//key will be always first column value
				resultMap.put(rs.getString(1), singleRowresult);
			}

			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return resultMap;
	}

	/**
	 * Returns null if no result found, else list of strings of first column
	 * @param sQuery
	 * @return
	 */
	public static Map<String,Map<String,String>> executeQueryMultiRowMultiColumnMap(String sQuery,String... column){

		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		Map<String,Map<String,String>> resultMap = new LinkedHashMap<String,Map<String,String>>();

		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		ResultSet rs = executeQueryReturnAll(sQuery,true);
		if(rs == null)
			return resultMap;
		try {

			int colSize=0;

			do
			{
				Map<String,String> singleRowData = new HashMap<String,String>();

				if(lstColumns[0].trim().equals("*"))
				{
					colSize = rs.getMetaData().getColumnCount();
				}
				else
				{
					colSize = lstColumns.length;
				}
				for (int i=1;i<=colSize;i++) {

					singleRowData.put(rs.getMetaData().getColumnName(i), rs.getString(i));
				}

				//key will be always first column value
				if(column.length==0)
					resultMap.put(rs.getString(1), singleRowData);
				else
					resultMap.put(rs.getString(column[0]), singleRowData);
			}	while(rs.next());

			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return resultMap;
	}


	public static List<Map<String,String>> executeQueryMultiRowMultiColumnMapLIST(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		List<Map<String,String>> resultMap = new ArrayList<Map<String,String>>();

		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return resultMap;
		try {

			int colSize=0;

			while(rs.next())
			{
				Map<String,String> singleRowData = new HashMap<String,String>();

				if(lstColumns[0].trim().equals("*"))
				{
					colSize = rs.getMetaData().getColumnCount();
				}
				else
				{
					colSize = lstColumns.length;
				}
				for (int i=1;i<=colSize;i++) {

					singleRowData.put(rs.getMetaData().getColumnName(i), rs.getString(i));
				}

				//key will be always first column value
				resultMap.add(singleRowData);
			}

			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return resultMap;
	}
	public static CatentryIds executeQueryToGetCatentryIds(CatentryIds catentryIds,String sQuery,String site){
		Map<String,String> resultMap = new HashMap<String,String>();
		List<String> catentryIdList = new ArrayList<String>();
		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return catentryIds;
		try {
			while(rs.next())
			{
				resultMap.put(rs.getString(1), rs.getString(2));
				catentryIdList.add(rs.getString(2));
			}
			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		if(site.equalsIgnoreCase("sears")){
			catentryIds.setSearsCatentryIds(resultMap);
			catentryIds.setSearsCatentryIdsList(catentryIdList);
		}
		else if(site.equalsIgnoreCase("kmart")){
			catentryIds.setKmartCatentryIds(resultMap);
			catentryIds.setKmartCatentryIdsList(catentryIdList);
		}
		return catentryIds;
	}
	public static Map<String,String> executeQueryMultiRowMultiColumnSingleMap(String sQuery){
		Map<String,String> resultMap = new HashMap<String,String>();
		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return resultMap;
		try {
			while(rs.next())
			{
				resultMap.put(rs.getString(1), rs.getString(2));
			}
			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		return resultMap;
	}
	
	public static Map<String,List<Map<String, String>>> executeQuery(String sQuery,String... primaryKeyColumn)
	{
		db2QueryHitCounter++;
	
		long start = System.currentTimeMillis();
		
		Map<String,List<Map<String, String>>> resultMap = new HashMap<String, List<Map<String,String>>>();

		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		String sPrimaryKeyColumnValue = null;
		
		
		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return resultMap;
		try {

			int colSize=0;
			
			colSize = lstColumns[0].trim().contains("*")? rs.getMetaData().getColumnCount():  lstColumns.length;
			
			while(rs.next())
			{
				Map<String,String> singleRowData = new HashMap<String,String>();

				for (int i=1;i<=colSize;i++) {

					singleRowData.put(rs.getMetaData().getColumnName(i), rs.getString(i));
				}

				sPrimaryKeyColumnValue  = primaryKeyColumn.length==0? rs.getString(1):	 rs.getString(primaryKeyColumn[0]);
				
				List<Map<String, String>> list = resultMap.get(sPrimaryKeyColumnValue);
				
				list = list ==null? new ArrayList<Map<String, String>>() :list;
				
				list.add(singleRowData);
				
				resultMap.put(sPrimaryKeyColumnValue, list);
			}

			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return resultMap;
	}
	
	public static Map<String,Map<String,Map<String, String>>> executeQueryMultiPrimaryKey(String sQuery,String... primaryKeyColumns)
	{
		db2QueryHitCounter++;
	
		long start = System.currentTimeMillis();
		
		 Map<String,Map<String,Map<String, String>>> resultMap = new HashMap<String, Map<String,Map<String,String>>>();

		String selectQuery = sQuery.split("from")[0];
		String sColumns = selectQuery.split("select")[1];
		String[] lstColumns = sColumns.split(",");

		String sPrimaryKeyColumnValue1 = null;
		String sPrimaryKeyColumnValue2 = null;
		
		ResultSet rs = executeQueryReturnAll(sQuery);
		if(rs == null)
			return resultMap;
		try {

			int colSize=0;
			
			colSize = lstColumns[0].trim().contains("*")? rs.getMetaData().getColumnCount():  lstColumns.length;
			
			while(rs.next())
			{
				Map<String,String> singleRowData = new HashMap<String,String>();

				for (int i=1;i<=colSize;i++) {

					singleRowData.put(rs.getMetaData().getColumnName(i), rs.getString(i));
				}

				sPrimaryKeyColumnValue1  = primaryKeyColumns.length==0? rs.getString(1):	 rs.getString(primaryKeyColumns[0]);
				sPrimaryKeyColumnValue2  = primaryKeyColumns.length==0? rs.getString(2):	 rs.getString(primaryKeyColumns[1]);
				
				Map<String, Map<String, String>> innerMap = resultMap.get(sPrimaryKeyColumnValue1);
				
				if(innerMap==null)
				{
					innerMap = new HashMap<String, Map<String, String>>();
				}
				
				innerMap.put(sPrimaryKeyColumnValue2,singleRowData);
				
				resultMap.put(sPrimaryKeyColumnValue1, innerMap);
			}

			closeCursor(rs);
		} catch (SQLException e) {
			System.out.println(sQuery);
			throw new DBException("Error in reading result " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
		return resultMap;
	}
}
