package com.shc.autocontent.kafkautils;

import java.util.Properties;
import java.util.Random;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

import com.shc.autocontent.LoadProperties;

/**
 * Very basic producer to read messages set as system property and post to the kafka queue
 * @author nvarsh0
 *
 */

public class KafkaProducer {
	
	Producer<String, String> producer ;
	private static String topicName;
	
	/**
	 * Initializes the producer with properties loaded in properties 
	 * Initializes topic to topic specified in properties
	 */
	public KafkaProducer(){
		
		topicName = LoadProperties.KAFKATOPIC;
		
		initProducer(LoadProperties.KAFKABROKER);
		
		
	}
	
	public KafkaProducer(String customTopicName){
		
		topicName = customTopicName;
		
		initProducer(LoadProperties.KAFKABROKER);
		
		
	}
	
	
	/**
	 * Returns the producer for any specific activities required other than publishing messages
	 * @return
	 */
	public Producer<String, String> producer(){
		return producer;
	}
	
	/**
	 * Publish pipe separated messages as one message each to the queue
	 * @param topicName
	 * @param entireMessage
	 */
	public void publishMessages(String topicName, String entireMessage, String separator){
		if(separator == null)
			separator = "\\|";
		
		String[] allMessages = entireMessage.split(separator);
		
		for(String message : allMessages){
			publishMessage(topicName, message.trim());
		}
	}
	
	
	/**
	 * Publish a single message to the topicname specified in properties or
	 * initialized through constructor
	 * @param message
	 */
	public long publishMessage( String message){
		
		return publishMessage(topicName, message);
		
	}
	
	
	/**
	 * Publish a single message to the specified topicName
	 * @param topicName
	 * @param message
	 */
	public long publishMessage(String topicNameToPopulate, String message){
		
		Random rand = new Random();
		int randomKeyData = rand.nextInt(50);
		String key = "Key"+ randomKeyData;
		KeyedMessage<String, String> kafkaData = new KeyedMessage<String, String>(
				topicNameToPopulate, key,
					message.trim());
		long l1 = System.currentTimeMillis();
		producer().send(kafkaData);
		return l1;
	}
	
	public void shutdownProducer(){
		producer().close();
	}
	
	/**
	 * Initializes the producer to post to a broker
	 * @param broker
	 */
	public void initProducer(String broker){
	
		Properties props = new Properties();
		props.put("zk.connect", LoadProperties.ZOOKEEPER);
		props.put("metadata.broker.list", broker);
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		ProducerConfig config = new ProducerConfig(props);
		producer = new Producer<String, String>(config);
	}
}
