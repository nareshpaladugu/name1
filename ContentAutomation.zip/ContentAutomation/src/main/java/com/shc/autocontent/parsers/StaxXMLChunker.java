package com.shc.autocontent.parsers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;

public class StaxXMLChunker implements XMLChunker{
	
	private FileInputStream inputStream;
	private XMLEventReader eventReader;
	private XMLInputFactory xmlFactory;
	private Unmarshaller unmarshaller;
	private String sCutOffNode = null;
	private List<String> lstSkipNodes = null;
	
	public void setCutOffNode(String sCutOffNode){
		this.sCutOffNode = sCutOffNode;
	}
	
	public void setToSkipNodes(List<String> lstToSkipNodes){
		this.lstSkipNodes = lstToSkipNodes;
	}
	
	public StaxXMLChunker(String sFileName){
		xmlFactory = XMLInputFactory.newInstance();
		inputStream = openFileForReading(sFileName);
		try {
			eventReader = xmlFactory.createXMLEventReader(inputStream);
		} catch (XMLStreamException e) {
			e.printStackTrace();
			throw new ParseException("Issue in creating event reader. Please check xml" );
		}
		System.setProperty("org.apache.commons.logging.Log",
                "org.apache.commons.logging.impl.NoOpLog");
		unmarshaller = new Unmarshaller();
        
		
	}

	private static FileInputStream openFileForReading(String sFileName){
		try{
//			File f = new File(sFileName);
			
			return new FileInputStream(new File(sFileName));
		}catch(FileNotFoundException fE){
			throw new ParseException("Failed reading file :"+ sFileName);
		}
	}
	
	/**
	 * Reads a node of type of c
	 */
	public <T> T unmarshalXML(Class<T> c){
		unmarshaller.setClass(c);
		try {
			while(true){
				XMLEvent nextEvent = eventReader.peek();
				//Check for end of document
				if(nextEvent.getEventType() == XMLEvent.END_DOCUMENT || 
						(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equals(sCutOffNode)))
					return null;
				//Check for skip node if any
				this.handleSkipNodes(nextEvent);
				if(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equalsIgnoreCase(c.getSimpleName())){
					//System.out.println("Found node "+ nextEvent.asStartElement().getName());
					return (T)unmarshaller.unmarshal(eventReader);
					
				}else{
					eventReader.nextEvent();
				}
				
			}
		} catch (XMLStreamException e) {
			e.printStackTrace();
			throw new ParseException("Issue in xml streaming - can be due to xml errors", e.getCause());
		} catch (MarshalException e) {
			throw new ParseException("Issue in unmarshalling.  Check node or VO.", e.getCause());
		} catch (ValidationException e) {
			throw new ParseException("Issue in validating xml.  Check node or VO.", e.getCause());
		}
		
		//Ideally this code should not be reached
//		return null;
	}
	
	/**
	 * Reads a node of type of c
	 */
	public <T> T unmarshalXML(Class<T> c, String nodeName){
		unmarshaller.setClass(c);
		try {
			while(true){
				XMLEvent nextEvent = eventReader.peek();
				//Check for end of document
				if(nextEvent.getEventType() == XMLEvent.END_DOCUMENT || 
						(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equals(sCutOffNode)))
					return null;
				//Check for skip node if any
				this.handleSkipNodes(nextEvent);
				if(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equalsIgnoreCase(nodeName)){
					//System.out.println("Found node "+ nextEvent.asStartElement().getName());
					return (T)unmarshaller.unmarshal(eventReader);
					
				}else{
					eventReader.nextEvent();
				}
				
			}
		} catch (XMLStreamException e) {
			e.printStackTrace();
			throw new ParseException("Issue in xml streaming - can be due to xml errors", e.getCause());
		} catch (MarshalException e) {
			throw new ParseException("Issue in unmarshalling.  Check node or VO.", e.getCause());
		} catch (ValidationException e) {
			throw new ParseException("Issue in validating xml.  Check node or VO.", e.getCause());
		}
		
		//Ideally this code should not be reached
//		return null;
	}
	
	private void handleSkipNodes(XMLEvent nextEvent){
		if(lstSkipNodes != null){
			if(nextEvent.isStartElement() && lstSkipNodes.contains(nextEvent.asStartElement().getName().getLocalPart())){
				String sNodeToSkip = nextEvent.asStartElement().getName().getLocalPart();
				System.out.println("Encountered node to skip : "+ sNodeToSkip);
				while(true){
					try {
						XMLEvent nextEventToSkip = eventReader.peek();
						if(nextEventToSkip.getEventType() == XMLEvent.END_DOCUMENT || 
								(nextEventToSkip.isEndElement() && nextEventToSkip.asEndElement().getName().getLocalPart().equals(sNodeToSkip))){
							System.out.println("Encounted end of node to skip : "+ nextEventToSkip);
							return;
						}
						eventReader.next();
					} catch (XMLStreamException e) {
						e.printStackTrace();
						throw new ParseException("Issue in xml streaming - can be due to xml errors", e.getCause());
					} /*catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
					
				}
			}
		}
	}
	
	public String findNodeValue(String node, String value){
		try {
			while(true){
				XMLEvent nextEvent = eventReader.peek();
				//Check for end of document
				if(nextEvent.getEventType() == XMLEvent.END_DOCUMENT || 
						(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equals(sCutOffNode)))
					return null;
				//Check for skip node if any
				this.handleSkipNodes(nextEvent);
				if(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equalsIgnoreCase(node)){
				//	System.out.println("Found node "+ nextEvent.asStartElement().getName());
					return nextEvent.asStartElement().getAttributeByName(new QName(value)).getValue();
//					return (T)unmarshaller.unmarshal(eventReader);
					
				}else{
					eventReader.nextEvent();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<String> findNodeValues(String node){
		List<String> nodes = new ArrayList<String>();
		String content = null;
		try {
			while(true){
				XMLEvent nextEvent = eventReader.peek();
				//Check if nextEvent is null
				if(null == nextEvent)
					break;
				//Check for end of document
				if(nextEvent.getEventType() == XMLEvent.END_DOCUMENT ||
						(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equals(sCutOffNode)))
					//Check for skip node if any
					this.handleSkipNodes(nextEvent);
				if(nextEvent.isStartElement() && nextEvent.asStartElement().getName().getLocalPart().equalsIgnoreCase(node)){
					content = null;
					nextEvent = eventReader.nextEvent();
					nextEvent = eventReader.nextEvent();
					if (nextEvent.isCharacters()) {
						content = nextEvent.toString();
					}
					nodes.add(content);
					eventReader.nextEvent();
				}else{
					eventReader.nextEvent();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return nodes;
	}
	
	/*public void parseXMLUsingCastor(String sFileName) {

		XMLInputFactory factory = XMLInputFactory.newInstance();
		try {
			XMLEventReader eventReader = factory.createXMLEventReader(openFileForReading(sFileName));
			while(eventReader.peek()!= null){
				XMLEvent event = eventReader.nextEvent();
				if(event.getEventType() == XMLEvent.END_DOCUMENT)
					return;
				System.out.println(event);
				if(eventReader.peek().isStartElement() && eventReader.peek().asStartElement().getName().toString().equals("note")){
					System.out.println("am i here");
					Unmarshaller um = new Unmarshaller();
					um.setValidation(false);
					um.setClass(Note.class);
					Note n = (Note)um.unmarshal(eventReader);
					System.out.println(n.getTo());
					System.out.println(n.getBody());
				}
				
				}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void parseXML(String sFileName) {

		XMLInputFactory factory = XMLInputFactory.newInstance();
		try {
			XMLEventReader eventReader = factory.createXMLEventReader(openFileForReading(sFileName));
			if(eventReader.hasNext()){
				XMLEvent e = eventReader.nextEvent();
				if(e.getEventType() == e.START_DOCUMENT){
					System.out.println("Started");
					while(eventReader.hasNext()){
						XMLEvent event = eventReader.nextEvent();
//						Unmarshaller.unmarshal(Note.class, new)
//						Unmarshaller.unmarshal(Note.class, new StAXSource(eventReader)));
						if(event.isStartElement())
							System.out.println("Next: " +event+ " Type: "+ event.getEventType()+" "+ event.asStartElement().getName());
						
					}
				}
			}
		} catch (XMLStreamException e) {
			e.printStackTrace();
			throw new ParseException("Failed to parse xml");
		}
	}

	*/
	
}
