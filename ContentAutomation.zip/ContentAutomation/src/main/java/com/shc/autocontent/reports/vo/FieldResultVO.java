package com.shc.autocontent.reports.vo;

/**
 * Represents single cell value in result
 *
 */
public class FieldResultVO {

	private String fieldName;
	private String expected;
	private String actual;
	private RESULT result;
	private INFOTYPE infoType;
	
	public INFOTYPE getInfoType() {
		return infoType;
	}

	public enum INFOTYPE{
		DATA,
		WARNING,
		FAILED;
	}
	
	public enum RESULT{
		INFO,
		PASSED,
		FAILED;
	}
	
	
	public FieldResultVO(String sFieldName, Object exp, Object act,INFOTYPE infoType){
		this.fieldName = sFieldName;
		this.expected = (exp == null? null :exp.toString());
		this.actual = (act == null? null :act.toString());
		this.result = RESULT.INFO;
		this.infoType=infoType;
	}
	
	public FieldResultVO(String sFieldName, Object exp, Object act, RESULT resultStatus){
		this.fieldName = sFieldName;
		this.expected = (exp == null? null :exp.toString());
		this.actual = (act == null? null :act.toString());
		this.result = resultStatus;
	}
	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
	
	public void setResult(RESULT result) {
		this.result = result;
	}
	
	public RESULT getResult() {
		return result;
	}
	
	public String toString(){
		return (String.format("Field : %s **Result: %s  **Expected: %s **Actual: %s : ",
				this.fieldName, this.result, this.expected, this.actual));
				
	}
}
