package com.shc.autocontent.utils;

import java.lang.reflect.Field;

/**
 * @author ddaphal
 *
 */
public class ReflectionUtils 
{
	/**
	 * This method will return given attribute's value from specified object using reflection
	 * @param object Object from which value needs to extract
	 * @param fieldNames Expected field name 
	 * @return
	 */
	public static Object getFieldFromObject(Object object, String fieldNames) 
	{

		if(object==null)
			return null;
		
		Object output = null;

		try
		{
			String fieldNamesSp []=fieldNames.split(">");

			Field f = object.getClass().getDeclaredField(fieldNamesSp[0]);

			f.setAccessible(true);

			output = f.get(object);
			
			if(output==null)
				return null;
			
			for (int i = 1; i < fieldNamesSp.length; i++) {

				f = output.getClass().getDeclaredField(fieldNamesSp[i]);

				f.setAccessible(true);

				output = f.get(output);
			}

		} catch (NoSuchFieldException e) {
			output = "@no_such_field@";
			//throw e;
		} catch (SecurityException e) {
			e.printStackTrace();
			//throw e;
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			//throw e;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			//throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return output;
	}
	
}
