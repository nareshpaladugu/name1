package com.shc.autocontent.parsers;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * 
 * Contains entire API Response data with _blob, _search, _meta and _ft fields
 * @author nvarsh0
 * @param <T>  - Type of blob object, the class that the blob object needs to be casted to
 */
public class APIResponse<T> {

	private T t;
	private JsonObject searchFields;
	private JsonObject ftFields;
	private JsonObject metaFields;
	public <T> T getT() {
		return  (T)t;
	}
	public void setT(T t) {
		this.t = t;
	}
	public JsonObject getSearchFields() {
		return searchFields;
	}
	public void setSearchFields(JsonObject searchFields) {
		this.searchFields = searchFields;
	}
	public JsonObject getFtFields() {
		return ftFields;
	}
	public void setFtFields(JsonObject ftFields) {
		this.ftFields = ftFields;
	}
	public JsonObject getMetaFields() {
		return metaFields;
	}
	public void setMetaFields(JsonObject metaFields) {
		this.metaFields = metaFields;
	}
	
	public String getMetaFieldValue(String fieldname){
		return this.metaFields.get(fieldname).getAsString();
	}
	
	public String getSearchFieldValue(String fieldname){
		try{
			return this.searchFields.get(fieldname).getAsString();
		}catch(NullPointerException e){
			return null;
		}
	}
	
	public List<String> getSearchFieldList(String fieldname){
		try{
			JsonArray jsonArray = this.searchFields.get(fieldname).getAsJsonArray();
			List<String> list = new ArrayList<String>();
			for (int i=0; i<jsonArray.size(); i++) {
			    list.add(jsonArray.get(i).getAsString());
			}
			return list;
		}catch(NullPointerException e){
			return null;
		}
	}
	
	public String getFtFieldValue(String fieldname){
		try{
			return this.ftFields.get(fieldname).getAsString();
		}catch(NullPointerException e){
			return null;
		}
		
	}
	
}
