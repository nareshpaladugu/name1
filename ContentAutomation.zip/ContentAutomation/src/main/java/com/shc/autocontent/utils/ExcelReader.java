package com.shc.autocontent.utils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.shc.autocontent.LoadProperties;

public class ExcelReader {

	private Sheet sheetToRead;
	Integer currentRow;
	
	public ExcelReader(){
		try {
			Workbook wb = WorkbookFactory.create(new File(LoadProperties.LST_FILES_FOLDER+LoadProperties.LST_FILES));
			sheetToRead = wb.getSheetAt(0);
			
			
		} catch (InvalidFormatException | IOException e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * Reads next row from excel file, converts row to object of class specified.  Returns object
	 * @param classToCastTo - Class whose object needs to be created
	 * @return object of classToCastTo or null
	 */
	public <T> T getNextObject(Class<T> classToCastTo){
		if(currentRow == null)
			currentRow = 1;
		else
			currentRow++;
		
		
		if(currentRow >=  sheetToRead.getPhysicalNumberOfRows())
			return null;
		Row currentRowData = sheetToRead.getRow(currentRow);
		if(currentRowData == null || currentRowData.getCell(0) == null){
			return null;
		}
		
		Field[]  allfields = classToCastTo.getDeclaredFields();
		T t = null;
		try {
			t = classToCastTo.newInstance();
			for(int i=0; i < allfields.length; i++){
					allfields[i].setAccessible(true);
					if(currentRowData.getCell(i).getCellType() == 0)
						allfields[i].set(t, currentRowData.getCell(i).getNumericCellValue());
					if(currentRowData.getCell(i).getCellType() == 1)
						allfields[i].set(t, currentRowData.getCell(i).getStringCellValue());
					if(currentRowData.getCell(i).getCellType() == 2)
						allfields[i].set(t,new BigDecimal(currentRowData.getCell(i).getNumericCellValue()).toPlainString());
			}
		} catch (InstantiationException | IllegalArgumentException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		
		return t;
		
	}
	
	
	
	
}
