package com.shc.autocontent.parsers;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.xpath.CachedXPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class DOMParserImpl {

	private Document doc;
	private DocumentBuilder domBuilder;
	private String sFileName;
	CachedXPathAPI cachedXPathAPI;
	public DOMParserImpl(String sFileName){
			DocumentBuilderFactory domBuilderFac = DocumentBuilderFactory.newInstance();
//			domBuilderFac.setNamespaceAware(true);
			this.sFileName = sFileName;
			try {
				domBuilder= domBuilderFac.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				throw new ParseException("Error building dom builder"+ e.getMessage());
			}
			cachedXPathAPI = new CachedXPathAPI();
	}
	
	/**
	 * 
	 * @param xpathExpression
	 * @return
	 */
	public synchronized NodeList parseAsDOM(String xpathExpression){
		
			XPath xpath = XPathFactory.newInstance().newXPath();
//			long l1 = System.currentTimeMillis();
			try {
				if(doc == null){
					System.out.println("am i parsing");
					doc = domBuilder.parse(sFileName);
				}
				XPathExpression expr = xpath.compile(xpathExpression);
				Object result = expr.evaluate(doc, XPathConstants.NODESET);
		    
			    NodeList nodes = (NodeList) result;
//			    long l2 = System.currentTimeMillis();
//			    System.out.println("Parsing "+ xpathExpression+ " Time "+ (l2-l1));
			    return nodes;
			} catch (XPathExpressionException e) {
				e.printStackTrace();
				throw new ParseException("Error evaluating xpath.  Please check :"+ xpathExpression);
				
			} catch (SAXException e) {
				throw new ParseException("SAX Exception : "+ e.getMessage());
			} catch (IOException e) {
				throw new ParseException("IOException.  Please check path/file "+ sFileName+ "  "+ e.getMessage());
			}
	}
	
	/**
	 * Uses cached copy of dom object to parse
	 * Use this for dom parsing if xml is not going to change
	 * @param xpathExpression
	 * @return
	 */
	public synchronized NodeList parseAsDOMCached(String xpathExpression){
		
			long l1 = System.currentTimeMillis();
			try {
				if(doc == null){
					System.out.println("am i parsing");
					doc = domBuilder.parse(sFileName);
				}
				
				NodeList nodes =cachedXPathAPI.selectNodeList(doc.getDocumentElement(), xpathExpression);
				 long l2 = System.currentTimeMillis();
//				    System.out.println("Parsing "+ xpathExpression+ " Time "+ (l2-l1));
			    return nodes;
			} catch (SAXException e) {
				throw new ParseException("SAX Exception : "+ e.getMessage());
			} catch (IOException e) {
				throw new ParseException("IOException.  Please check path/file "+ sFileName+ "  "+ e.getMessage());
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				throw new ParseException("TransformerException. "+ e.getMessage());
			}
	}
	
	/*@Test
	public void testDOMPTime(){
		this.parseAsDOM("src/main/resources/master-hierarchy.xml");
	}*/
}
