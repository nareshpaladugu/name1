/**
 * 
 */
package com.shc.autocontent.counters;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author djohn0
 *
 */
public class PromoCounters {
	
	public static AtomicInteger offerOnlineCount = new AtomicInteger(0);
	public static AtomicInteger offerOnlinePassCount = new AtomicInteger(0);
	public static AtomicInteger offerOnlineFailCount = new AtomicInteger(0);
	
	public static AtomicInteger offerOfflineCount = new AtomicInteger(0);
	public static AtomicInteger offerOfflinePassCount = new AtomicInteger(0);
	public static AtomicInteger offerOfflineFailCount = new AtomicInteger(0);
	public static AtomicInteger mismatchVariationItemCount = new AtomicInteger(0);
	
	public static AtomicInteger priceAlrtExclItemCount = new AtomicInteger(0);
	
	public static AtomicInteger uvdItemCount = new AtomicInteger(0);
	public static AtomicInteger bundleItemCount = new AtomicInteger(0);
	
	
	public static Map<String, String> uniqueVariationParentCount = new ConcurrentHashMap<>();
	public static Map<String, String> nonVariationFailedItem = new ConcurrentHashMap<>();
	
	public static Map<String, AtomicInteger> hieraritemGroupings = new ConcurrentHashMap<>();
	
	

}
