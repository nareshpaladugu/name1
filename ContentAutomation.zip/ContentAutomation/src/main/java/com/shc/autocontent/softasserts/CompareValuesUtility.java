package com.shc.autocontent.softasserts;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.testng.Assert;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.reports.vo.FieldResultVO;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.reports.vo.FieldResultVO.RESULT;
import com.shc.autocontent.reports.vo.FinalResult;

public class CompareValuesUtility {

	//	private static Map<String, List<FieldResultVO>> idToFieldsMap =new HashMap<String, List<FieldResultVO>>();
	//	public static Map<String, Map<String, List<FieldResultVO>>> allResultsMap = new HashMap<String, Map<String, List<FieldResultVO>>>();
	public static BlockingQueue<Map<String,List<FieldResultVO>>> resultQueue = new LinkedBlockingQueue<Map<String,List<FieldResultVO>>>();

	private static Set<String> infoFieldSet = new HashSet<String>();

	private static Map<String,Integer> headerMap = Collections.synchronizedMap(new LinkedHashMap<String, Integer>());
	private static Map<String,Integer> failedFields = Collections.synchronizedMap(new HashMap<String, Integer>());
	private static FinalResult finalResult= new FinalResult();
	private static ThreadLocal<Integer> fieldFailedResultsCount = new ThreadLocal<Integer>();
	private static ThreadLocal<List<FieldResultVO>> allResults = new ThreadLocal<List<FieldResultVO>>();
	private static boolean isRunAborted = false;
	private static ThreadLocal<Integer> totalFailedResultsCount = new ThreadLocal<Integer>(){
		@Override
		protected Integer initialValue(){
			return 0;
		}
	};
	private static ThreadLocal<Integer> totalResultsCount = new ThreadLocal<Integer>(){
		@Override
		protected Integer initialValue(){
			return 0;
		}
	};
	private static int iFieldColNumber = 2;


	public static final FieldResultVO NEWMULTIVALFIELD = new FieldResultVO("NEWMULTI", null, null, RESULT.PASSED );
	public static final FieldResultVO NEWDATAWITHINDATA = new FieldResultVO("NEWDATA", null, null, RESULT.PASSED );


	/**
	 * Compare only if expected value is not null
	 * @param fieldName
	 * @param toVerify
	 * @param actual
	 * @param subFieldName
	 */
	public static void compareOnlyIfNotNull(String fieldName,Object toVerify, Object actual, String... subFieldName){
		if(toVerify != null){
			compareValues(fieldName, toVerify, actual, subFieldName);
		}
	}

	/**
	 * Compares two values - exact match - handles double, Integer
	 * Builds result map for report generation
	 * @param message
	 * @param exp
	 * @param act
	 * @return
	 */
	public static void compareValues(String message,Object exp, Object act,String... strings )
	{
		try{
			boolean status = false;
			if(exp instanceof Double){

				act = Double.valueOf(act.toString());
				status = exp.equals(act);
			}else if(exp instanceof Integer){
				if(act instanceof Double)
					act = ((Double) act).intValue();
				status = exp.toString().equals(act.toString());
			}
			else{
				status = exp.toString().trim().equals(act.toString().trim());
			}

			if(status){
				addPassedResult(message, exp, act, strings);
			}else{
				addFailedResult(message, exp, act, strings);
			}
		}catch(NullPointerException |NumberFormatException e){
			//System.out.println("NPE in actual.  Reporting failed result for "+ message);
			addFailedResult(message, (exp==null?"null":exp), (act==null?"null":act),strings);
		}

	}

	/**
	 * 
	 * @param fieldName
	 * @param data
	 */
	public static void addFailedDataFieldForReport(String message, String exp){

		buildFieldNames(message,false);
		if(exp==null) exp ="null";

		if (!isInIgnoredFields(message, exp.toString())){
			synchronized (failedFields) {
				Integer count = failedFields.get(message);
				if (count == null) {
					count = 1;
				} else {
					count++;
				}
				failedFields.put(message, count);
			}
			fieldFailedResultsCount.set(fieldFailedResultsCount.get().intValue()+1);
		}

		addDataFieldForReport(message, exp, INFOTYPE.FAILED);
	}
	/**
	 * Method to add some data to the report, which is just for data purpose and not for validation
	 * @param fieldName
	 * @param data
	 */
	public static void addDataFieldForReport(String fieldName, String data,FieldResultVO.INFOTYPE... infotype){

		INFOTYPE infoTypeSelected;

		if(infotype.length==0)
		{
			infoTypeSelected = INFOTYPE.DATA;
		}
		else
		{
			infoTypeSelected = infotype[0];
		}
		synchronized (getInfoFieldSet()) {
			getInfoFieldSet().add(fieldName);
		}
		//			buildFieldNames(fieldName, true);
		addInfo(fieldName, data, infoTypeSelected);

	}

	public static void verifyNullOrEqual(String message,Object exp, Object act,String... toAppend){
		try{
			if(exp == null || exp.toString().trim().equals("")){
				if(!(act == null || act.toString().trim().equals("")))
					throw new AssertionError();
				addPassedResult(message, "null", "null",toAppend);
			}
			else
				compareValues(message, exp, act, toAppend);
		}catch(AssertionError aE){
			addFailedResult(message, exp, act, toAppend);
		}catch(NullPointerException e){
			addFailedResult(message, exp, act, toAppend);
		}
	}
	
	public static void verifyNullOrTrue(String message,Object exp, Object act,String... toAppend){
		try{
			if(exp == null || exp.toString().trim().equals("") || exp.equals(false)){
				if(!(act == null || act.toString().trim().equals("")))
					throw new AssertionError();
				addPassedResult(message, "null", "null",toAppend);
			}
			else
				compareValues(message, exp, act, toAppend);
		}catch(AssertionError aE){
			addFailedResult(message, exp, act, toAppend);
		}catch(NullPointerException e){
			addFailedResult(message, exp, act, toAppend);
		}
	}


	public static void verifyNullOrFalse(String message,Object exp, Object act, String... toAppend){

		if(act == null || act.equals("false")){
			addPassedResult(message, (toAppend.length>0?toAppend[0]+" :":"")+exp, act);
		}
		else
			compareValues(message, exp, act, toAppend);

	}
	public static void verifyNull(String message,Object act,String... toAppend){
		String sToAppendToResult = toAppend.length > 0?toAppend[0]+" :":"";
		try{
			Assert.assertNull(act);
			addPassedResult(message, sToAppendToResult+"null", act);
		}catch(AssertionError e){
			addFailedResult(message, "null", act,sToAppendToResult);
		}
	}
	
	public static void verifyNotNull(String message,Object act,String... toAppend){
		String sToAppendToResult = toAppend.length > 0?toAppend[0]+" :":"";
		try{
			Assert.assertNotNull(act);
			addPassedResult(message, sToAppendToResult+"not null", act);
		}catch(AssertionError e){
			addFailedResult(message, "not null", act,sToAppendToResult);
		}
	}

	public static void verifyRecordNotInserted(){
		//TODO
		//Check if act is null
		//check some mismatch
	}

	/**
	 * Adds field name to header
	 * Adds field comparison result to allResults
	 */
	private static void addPassedResult(String message,Object exp, Object act,String... strings){

		String sToAppendToResult = strings.length > 0 && !strings[0].isEmpty()?strings[0]+" :":"";

		buildFieldNames(message,false);
		if(exp==null) exp ="null";
		if(act==null) act ="null";
		allResults.get().add(new FieldResultVO(message, sToAppendToResult+exp, act, RESULT.PASSED ));
	}

	/**
	 * Info added 
	 * @param message
	 * @param data
	 */
	private static void addInfo(String message,Object data,INFOTYPE infoTypeSelected){

		buildFieldNames(message,true);
		if(data==null) data ="null";
		allResults.get().add(new FieldResultVO(message, data,null, infoTypeSelected ));
	}

	private static void addFailedResult(String message,Object exp, Object act,String... strings){

		String toAppend = strings.length > 0  && !strings[0].isEmpty()?strings[0]+"":"";
		String toAppend1 = strings.length > 0  && !strings[0].isEmpty()?strings[0]+" :":"";

		String finalFieldNameForReport = toAppend.isEmpty()?message:message+"."+toAppend;

		buildFieldNames(message,false);
		if(exp==null) exp ="null";
		if(act==null) act ="null";

		if (!isInIgnoredFields(message, exp.toString(),strings)){
			synchronized (failedFields) {
				Integer count = failedFields.get(finalFieldNameForReport);
				if (count == null) {
					count = 1;
				} else {
					count++;
				}
				failedFields.put(finalFieldNameForReport, count);
			}
			fieldFailedResultsCount.set(fieldFailedResultsCount.get().intValue()+1);
		}

		allResults.get().add(new FieldResultVO(message,toAppend1+ exp, act, RESULT.FAILED ));
	}

	private static boolean isInIgnoredFields(String message, String exp,String... strings){

		String toCheckIngoreCountCase = message+"."+( strings.length > 0  && !strings[0].isEmpty()?strings[0]:"");

		exp = exp.split(":")[0].trim();
		if(LoadProperties.IGNORED_FAILURES.contains(message)
				|| LoadProperties.IGNORED_FAILURES.contains(message+"-"+exp)
				|| LoadProperties.IGNORED_FAILURES.contains(toCheckIngoreCountCase))
			return true;
		else
			return false;
	}

	private static synchronized void buildFieldNames(String message, boolean isInfo){
		if(!headerMap.containsKey(message)){
			if(!headerMap.isEmpty()){
				Object[] allKeys = headerMap.keySet().toArray();
				String lastField = allKeys[headerMap.size()-1].toString();
				if(getInfoFieldSet().contains(lastField))
					headerMap.put(message,iFieldColNumber++);
				else{
					headerMap.put(message, iFieldColNumber + 1);
					iFieldColNumber = iFieldColNumber+2;
				}
			}else{
				headerMap.put(message,iFieldColNumber++);
			}

		}
	}

	/**
	 * 
	 * Add a field to header - specifying the type of field. <br>  
	 * Used to maintain consistency in header order.
	 * @param header - Field name that should appear in the header row
	 * @param isInfo - Set to true if this is an info field, 
	 * false if it is a comparison field with actual and expected values
	 */
	public static void addToHeader(String header, boolean isInfo){
		synchronized (headerMap) {
			infoFieldSet.add(header);
			buildFieldNames(header, isInfo);
		}
	}

	/**
	 * Use to fix the order of fields in a report.
	 * @param headers
	 */
	public static void addToHeaders(String[] headers){
		synchronized (headerMap) {
			for(String h1 : headers){
				if(!headerMap.containsKey(h1)){
					if(headerMap.isEmpty()){
						headerMap.put(h1,iFieldColNumber++);
					}
					else{
						headerMap.put(h1, iFieldColNumber + 1);
						iFieldColNumber = iFieldColNumber+2;
					}

				}
			}

		}
	}

	/**
	 * Returns number of fields failed for current id being tested
	 * @return
	 */
	public static int getFailedResultsSize(){
		try {
			return fieldFailedResultsCount.get().intValue();
		} catch (Exception e) {
			return -1;
		}
	}

	/**
	 * Init method which initializes the result object for each test
	 */
	public static void init(){
		allResults.set(new ArrayList<FieldResultVO>());
		fieldFailedResultsCount.set(0);

	}

	/**
	 * Returns all result for this thread
	 * @return
	 */
	public static List<FieldResultVO> getAllResults(){

		return allResults.get();
	}

	/**
	 * Returns list of fieldNames.  Required for report
	 * @return
	 */
	public static Map<String, Integer> getFieldNames(){
		return headerMap;
	}

	/**
	 * @return the infoFieldSet
	 */
	public static Set<String> getInfoFieldSet() {
		return infoFieldSet;
	}


	public static Set<String> getFailedFieldsSet(){
		return failedFields.keySet();
	}

	/**
	 * Returns list of failedFields
	 * @return
	 */
	public static String getFailedFields(){

		String failedFieldsToReturn="";

		Map<String,Integer> failedFieldsCopy = sortByComparator(failedFields);

		Iterator<Entry<String, Integer>> it = failedFieldsCopy.entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, Integer> pairs = it.next();

			failedFieldsToReturn=failedFieldsToReturn+", "+pairs.getKey()+"["+pairs.getValue()+"]";
		}

		failedFieldsToReturn=failedFieldsToReturn.replaceFirst(",","");

		return failedFieldsToReturn;
	}

	private static Map<String, Integer> sortByComparator(Map<String, Integer> unsortMap) {
		 
		// Convert Map to List
		List<Map.Entry<String, Integer>> list = 
			new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());
 
		// Sort list with comparator, to compare the Map values
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			public int compare(Map.Entry<String, Integer> o1,
                                           Map.Entry<String, Integer> o2) {
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});
 
		// Convert sorted map back to a Map
		Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
		for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext();) {
			Map.Entry<String, Integer> entry = it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}

	public static void teardown(){
		fieldFailedResultsCount.set(0);
		allResults.set(null);
	}

	/**
	 * Gives list of field results for the id
	 * Sets up counts for the summary results
	 * @param sId - id for which result is being setup
	 * @return
	 */
	public static Map<String, List<FieldResultVO>> setupResult(String sId){

		Map<String, List<FieldResultVO>> idToFieldsMap =new HashMap<String, List<FieldResultVO>>();
		//Set id as key and list of all results
		if(!LoadProperties.ONLY_FAILED_RESULTS || getFailedResultsSize()>0){
			/*Object[] allParams = Reporter.getCurrentTestResult().getParameters();
			StringBuffer sKey = new StringBuffer(allParams[0].toString());
			if(allParams.length > 1){
				for(int i =  1; i< allParams.length; i++){
					if(allParams[i] != null)
						sKey.append("-").append(allParams[i].toString());
				}
			}*/
			idToFieldsMap.put(sId, getAllResults());
		}/*else{
			idToFieldsMap.put(sId, getAllResults());
		}*/
		/*if(getFailedResultsSize() > 0){
			totalFailedResultsCount.set(totalFailedResultsCount.get()+ 1);
		}
		totalResultsCount.set(totalResultsCount.get() + 1);*/
		//This data is for summary report
		addToFinalCounts();
		return idToFieldsMap;
	}

	/**
	 * Adds this result to final counts and writes to excel the result of this field
	 * Clears the field map for next result
	 * @param sId - id for which result is being setup or any data that needs to come in first column
	 * @return
	 */
	public static void setupResult(String sId, boolean writeToExcel){
		//Setup the map
		Map<String, List<FieldResultVO>> idToFieldsMap = CompareValuesUtility.setupResult(sId);
		/*----------------------------write only failed result to excel----------------------------*/
		if(idToFieldsMap.size()>0){
			try {
				resultQueue.put(idToFieldsMap);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//			ExcelReportListener.createDetailedReport_updated(CompareValuesUtility.getFieldNames(), idToFieldsMap);
		}
		//			}
		//		else{
		//			
		//		}
		idToFieldsMap=null;
	}

	public static BlockingQueue<Map<String, List<FieldResultVO>>> getResultQueue(){
		return resultQueue;
	}

	/**
	 * 
	 */
	public static void addToFinalCounts(){
		if(getFailedResultsSize() > 0){
			finalResult.addToFailed();
		}
		finalResult.addToTotal();
	}


	/**
	 * Returns total failed count of ids
	 * For single thread executing multiple ids, this would give total number of failures
	 * For single thread executing single id, this would give 1 if there is a failed result
	 * @return
	 */
	public static Integer getTotalFailedResultsCount() {
		return totalFailedResultsCount.get();
	}

	/**
	 * Returns total counts
	 * For single thread executing multiple ids, this would give total number of ids that were compared
	 * For single thread executing single id, this would give 1
	 * @return
	 */

	public static Integer getTotalResultsCount() {
		return totalResultsCount.get();
	}

	public static FinalResult getFinalResult(){
		return finalResult;
	}

	/**
	 * Verifies whether the expObject is available in the list of strings to verify
	 * @param fieldName
	 * @param expObj - Expected string
	 * @param listToVerify
	 */
	public static void verifyItemInList(String fieldName, Object expObj, List<String> listToVerify, String... strings) {
		try{
			Assert.assertTrue(listToVerify.size() > 0);
			Assert.assertTrue(listToVerify.contains(expObj));
			addPassedResult(fieldName, expObj, listToVerify.get(listToVerify.indexOf(expObj)), strings);
		}catch(AssertionError e){
			addFailedResult(fieldName, expObj, listToVerify, strings);
		}

	}

	public static <T> int verifyInListField(String sFieldName,String toSearch, List<T> a, String fieldname,Class<T> cls, Boolean... bIgnoreCase){

		int iPosition = getPositionInList(toSearch, a, fieldname, cls, bIgnoreCase);
		if(iPosition != -1){
			addPassedResult(sFieldName, toSearch,toSearch);
			return iPosition;
		}else{
			addFailedResult(sFieldName, toSearch, "Not found","");
			return -1;
		}
	}
	/*Field f = null;
//		System.out.println("Checking for field : "+ sFieldName+ "   toSearch "+toSearch );

		try {
			f = cls.getDeclaredField(fieldname);
			f.setAccessible(true);
			for(int i = 0; i< a.size(); i++){
				T a1 = a.get(i);

//				System.out.println("Searchig for : "+ toSearch+" Found " +f.get(a1).toString());
				if(f.get(a1).toString().equals(toSearch)){
					addPassedResult(sFieldName, toSearch,f.get(a1));
					return i;
				}
			}
			addFailedResult(sFieldName, toSearch, "Not found");
			return -1;

		} catch (NoSuchFieldException e1) {
			 e1.printStackTrace();
		} catch (SecurityException e1) {
			throw e1;
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return -1;*/

	public static <T> int getPositionInList(String toSearch, List<T> a, String fieldname,Class<T> cls, Boolean... ignoreCase){

		boolean bIgnoreCase = false;
		if(ignoreCase.length > 0)
			bIgnoreCase = ignoreCase[0];
		Field f = null;
		try {
			f = cls.getDeclaredField(fieldname);
			f.setAccessible(true);
			for(int i = 0; i< a.size(); i++){
				T a1 = a.get(i);
				if(!bIgnoreCase && f.get(a1) != null && f.get(a1).toString().equals(toSearch)){
					return i;
				}
				
				if(bIgnoreCase && f.get(a1) != null && f.get(a1).toString().equalsIgnoreCase(toSearch)){
					return i;
				}
			}
			//			addFailedResult(sFieldName, toSearch, "Not found");
			return -1;

		} catch (NoSuchFieldException e1) {
			e1.printStackTrace();
		} catch (SecurityException e1) {
			throw e1;
		} catch (IllegalArgumentException e) {
			throw e;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return -1;
	}

	/**
	 * Utility method to log a failure
	 * @param fieldName - field for which failure is being logged.  This would appear in header of excel report
	 * @param sExpRule - Can be an expected value or a rule
	 * @param sMessage - Can be either found value or any generic text <br> <br>

	 * Usage eg.
	 * <code>
	 * CompareValuesUtility.logFailed("AttrId", attribute_id,"Not found");</code>
	 */
	/*public static void logFailed(String fieldName, Object sExpRule, Object sMessage){
		addFailedResult(fieldName, sExpRule.toString(), sMessage.toString(),"");
	}*/

	public static void logFailed(String fieldName, Object sExpRule, Object sMessage,String... toAppend){

		//String sToAppendToResult = toAppend.length > 0?toAppend[0]+" :":"";

		addFailedResult(fieldName, sExpRule.toString(), sMessage.toString(),toAppend);
	}


	/**
	 * Utility method to log a passed result
	 * @param fieldName - field for which pass is being logged.  This would appear in header of excel report
	 * @param sExpRule - Can be an expected value or a rule
	 * @param sMessage - Can be either found value or any generic text <br> <br>

	 * Usage eg.
	 * <code>
	 * CompareValuesUtility.logPassed("AttrId", attribute_id,"Found");</code>
	 */
	public static void logPassed(String fieldName, Object sExpRule, Object sMessage){
		addPassedResult(fieldName, sExpRule.toString(), sMessage.toString());
	}

	public static void logPassed(String fieldName, Object sExpRule, Object sMessage,String... toAppend){

		//String sToAppendToResult = toAppend.length > 0?toAppend[0]+" :":"";

		addPassedResult(fieldName, sExpRule.toString(), sMessage.toString(),toAppend);
	}



	public static void addNewMultiValuedFields(){
		allResults.get().add(NEWMULTIVALFIELD);
	}

	public static void addNewData(){
		allResults.get().add(NEWDATAWITHINDATA);
	}

	public static void verifyTrue(boolean bResult, String sFieldName, Object sExpRule, Object sMessage){
		if(bResult)
			logPassed(sFieldName, sExpRule, sExpRule);
		else
			logFailed(sFieldName, sExpRule, sMessage);

	}

	/**
	 * Takes and compares Expected and Actual Values along with mandatory and boolean flag
	 * 
	 * @param resultField
	 * @param sExpectedvalue
	 * @param sActaulValue
	 * @param mandatory
	 * @param booleanFlag
	 */
	public static void compareValues(String resultField,Object sExpectedvalue,Object sActaulValue,boolean mandatory, boolean booleanFlag, String... toAppend )
	{
		if(booleanFlag && sExpectedvalue!=null)
		{
			if(sExpectedvalue.equals("1") || sExpectedvalue.equals("YES") || sExpectedvalue.equals("Y"))
			{
				sExpectedvalue ="true";
			}
			else if (sExpectedvalue.equals("0") || sExpectedvalue.equals("NO")|| sExpectedvalue.equals("N"))
			{
				sExpectedvalue ="false";
			}
		}

		if(mandatory)
		{
			CompareValuesUtility.compareValues(resultField, sExpectedvalue, sActaulValue,toAppend);
		}
		else
		{
			if(booleanFlag && (sExpectedvalue ==null || sExpectedvalue.toString().equalsIgnoreCase("false")))
			{
				CompareValuesUtility.verifyNullOrFalse(resultField,sExpectedvalue, sActaulValue, toAppend);
			}
			else
			{
				if(sExpectedvalue==null || sExpectedvalue.toString().trim().isEmpty())
				{
					CompareValuesUtility.verifyNullOrEqual(resultField,sExpectedvalue, sActaulValue, toAppend);
				}
				else
				{
					CompareValuesUtility.compareValues(resultField, sExpectedvalue, sActaulValue, toAppend);
				}
			}
		}

	}

	public static void compareValuesByJsonFetch(FieldVo vo,Object sExpectedvalue,String json,String... toAppend)
	{
		String sActaulValue = JsonStringParser.getJsonValue(json,vo.getFieldPath()); 

		if(toAppend.length==0)
		{
			CompareValuesUtility.compareValues(vo.getResultField(), sExpectedvalue, sActaulValue, vo.isMandatory(), vo.isBooleanFlag());
		}
		else
		{
			CompareValuesUtility.compareValues(toAppend[0], sExpectedvalue, sActaulValue, vo.isMandatory(), vo.isBooleanFlag(),vo.getResultField());
		}
	}


	public static void compareBySplit(String sHeader, String sExp,String sAct,String sDlim)
	{
		String[] sExpArr = sExp.split(sDlim);

		String[] sActArr = sAct.split(sDlim);

		String sSingleExp, sSingleAct;

		for (int i = 0; i < sExpArr.length; i++) {

			sSingleExp = sExpArr[i];  // 2

			sSingleAct = sActArr[i];  // 2.0

			Double dExp=null;
			try {
				dExp = Double.parseDouble(sSingleExp);
			} catch (NumberFormatException e1) {
			}

			Double dAct=null;
			try {
				dAct = Double.parseDouble(sSingleAct);
			} catch (NumberFormatException e) {
			}

			if(dExp==null && dAct ==null )
			{
				CompareValuesUtility.logPassed(sHeader, sExp, sAct);
			}
			else if(! dExp.equals(dAct))
			{
				CompareValuesUtility.logFailed(sHeader, sExp, sAct);
				return;
			}
		}

		CompareValuesUtility.logPassed(sHeader, sExp, sAct);
	}


	public static void compareValuesIgnoreCase(String message,Object exp, Object act,String... strings )
	{
		String sToAppendToResult = strings.length > 0?strings[0]+" :":"";
		try{

			boolean status = exp.toString().trim().equalsIgnoreCase(act.toString().trim());

			if(status){
				addPassedResult(message, sToAppendToResult+exp, act);
			}else{
				addFailedResult(message, exp, act,sToAppendToResult);
			}
		}catch(NullPointerException e){
			addFailedResult(message, (exp==null?"null":exp), (act==null?"null":act),sToAppendToResult);
		}
	}

	public static void compareAsNumbers(String field, String sExp, Object sAct,String... strings )
	{

		Double dExp=null;

		try {
			dExp = Double.parseDouble(sExp);
		} catch (Exception e1) {
			dExp = 0d;
		}

		Double dAct =null;

		try {
			dAct  = Double.parseDouble(sAct.toString());
		} catch (Exception e) {
			dAct = null;
		}

		if(dExp==null && dAct == null)
		{
			CompareValuesUtility.logPassed(field, "null", "null", strings);			
		}
		else if(dExp!=null && dExp.equals(dAct))
		{
			CompareValuesUtility.logPassed(field, sExp==null?dExp:sExp, sAct, strings);			
		}
		else
		{
			Object exp = sExp==null?"null":sExp;
			Object act = sAct==null?"null":sAct;

			CompareValuesUtility.logFailed(field, exp, act, strings);
		}
	}
	
	public static void compareAsNumbers(String field, String sExp, String sAct,String... strings )
	{

		Double dExp=null;

		try {
			dExp = Double.parseDouble(sExp);
		} catch (Exception e1) {
			dExp = null;
		}

		Double dAct =null;

		try {
			dAct  = Double.parseDouble(sAct);
		} catch (Exception e) {
			dAct = null;
		}

		if(dExp==null && dAct == null)
		{
			CompareValuesUtility.logPassed(field, "null", "null", strings);			
		}
		else if(dExp!=null && dExp.equals(dAct))
		{
			CompareValuesUtility.logPassed(field, sExp, sAct, strings);			
		}
		else
		{
			Object exp = sExp==null?"null":sExp;
			Object act = sAct==null?"null":sAct;

			CompareValuesUtility.logFailed(field, exp, act, strings);
		}
	}


	/**
	 * Returns true if run was aborted before execution completed.
	 * 
	 * @return the isRunAborted
	 */
	public static boolean isRunAborted() {
		return isRunAborted;
	}


	/**
	 * Set if failure threshold check needs to be done.  
	 * Based on flag, result email subject would change.
	 * @param isRunAborted the isRunAborted to set
	 */
	public static void setRunAborted(boolean isRunAborted1) {
		isRunAborted = isRunAborted1;
	}

}


