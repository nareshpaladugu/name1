package com.shc.autocontent.gb;

import java.net.UnknownHostException;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.shc.autocontent.LoadProperties;


public class MongoDBClient {

	private static MongoClient mongoGBClient=null;
	private static MongoClient anyClient=null;

	public static void resetmongoGBClient()
	{
		if(mongoGBClient!=null)
		{
			try {
				mongoGBClient.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		mongoGBClient=null;
	}

	public static MongoClient connectToMongoDB(String... dbName) throws Exception
	{
		if(mongoGBClient!=null)
		{
			return mongoGBClient;
		}

		try 
		{
			String dName = "admin";

			if(dbName.length>=1)
			{
				dName=dbName[0];
			}

			System.out.println("DB Name ... "+dName);

			MongoClientURI uri = new MongoClientURI
					("mongodb://"+LoadProperties.gbUser+":"+LoadProperties.gbPassword+"@"+LoadProperties.gbServer+":"+LoadProperties.gbServerPort+"/?authSource="+dName);

			System.out.println("URI ..."+uri.toString());

			mongoGBClient = new MongoClient(uri);

			//MongoDatabase database = mongoClient.getDatabase(dName);

			/*boolean auth = db.authenticate(LoadProperties.gbUser, LoadProperties.gbPassword.toCharArray());

			if(!auth)
			{
				throw new DBException("Authentication to mongo server failed. Server : "+LoadProperties.gbServer
						+" Port : "+ LoadProperties.gbServerPort + " Username: "+ LoadProperties.gbUser);
			}*/

			return mongoGBClient;
		} catch (Exception e) {
			throw new Exception("Mongo client connection failed. Please check settings.");
		}

	}

	/**
	 * Utility method to connect to any mongo db
	 * Throws DBException 
	 * @param server
	 * @param port
	 * @param dbName
	 * @return
	 * @throws UnknownHostException 
	 */
	public static MongoClient connectToMongoDB(String server, Integer port) throws UnknownHostException{

		if(anyClient != null && anyClient.getAddress().getHost().equals(server))
			return anyClient;
		else{
			anyClient = new MongoClient( server , port );
			return anyClient;
		}
	}
}
