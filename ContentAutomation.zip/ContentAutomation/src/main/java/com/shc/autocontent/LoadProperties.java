package com.shc.autocontent;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

public class LoadProperties {
	
	
	public static String rankingMongoServer=System.getProperty("rankingMongoServer","dvmiftrankpoc302p.dev.ch3.s.com");
	public static String rankingMongoServerPort=System.getProperty("rankingMongoServerPort","20000");
	public static String rankingMongoUser=System.getProperty("rankingMongoUser","iftrankuser");
	public static String rankingMongoPassword=System.getProperty("rankingMongoPassword","iftr@nkuser123");
	public static String rankingMongoDatabasename=System.getProperty("rankingMongoDatabasename","ranking");
	public static String rankingMongoCollection=System.getProperty("rankingMongoCollection","bonusdetails-qa");
	public static String rankingBonusService=System.getProperty("rankingBonusService",
			"http://iftrank301p.qa.ch3.s.com:8280/ranking-bonus-service/bonus");
	
	public static String rankingMongoConfig = System.getProperty("rankingMongoConfig","http://iaapp302p.dev.ch3.s.com:8180/acme/config/node");
				/*-------------DB2 Properties---------------*/
	
	public static String db2jdbcClass=getProperty("db2jdbcClass", "com.ibm.db2.jcc.DB2Driver");
	public static String db2user=getProperty("db2user", "wcsadm");
	public static String db2password=getProperty("db2password", "wcs60qa");
	public static String db2databasename=getProperty("db2databasename", "QWCSS42P");
	public static String db2port=getProperty("db2port", "60304");
	public static String db2server=getProperty("db2server", "aixdbq302p.prod.ch3.s.com");
	public static String authDb=getProperty("authDb", "admin");
	
	
	/*-------------SSH Properties---------------*/
	
	public static String SSH_USER=getProperty("sshUserName", "");
	public static String SSH_PWD=getProperty("sshUserPwd", "");
	public static String BATCH_SERVER=getProperty("batchServer", "");
	public static Integer BATCH_PORT=Integer.parseInt(getProperty("batchSrvrPort", "22"));
	
	/*------------------------------------------*/
	
	public static String STORE_ID=getProperty("storeid", "10153");
	public static String SITE_NAME=getProperty("site", "");
	public static String PRICING_GRID_URL=getProperty("pricingGridURL", "");
	
	
				/*-------------REST Properties---------------*/
	public static String GREENVIP=getProperty("greenvip", "greenvip.qa.ch3.s.com:8080");
	public static String OTHERGBBOX=getProperty("otherGbBox","");
	public static String RANKING_SERVICE=getProperty("rankingserv","iftrankvip.dev.ch3.s.com");
	
	public static String EXECUTION_MODE = getProperty("executionMode","");
	public static String RUN_PARAMS = getProperty("runParams","");
	public static Boolean IS_BUCKETBASED_RUN = Boolean.parseBoolean(getProperty("isBucketRun","false"));
	public static Boolean IS_TIMEBASED_RUN = Boolean.parseBoolean(getProperty("isTimeBasedRun","false"));
	public static Boolean IS_LISTBASED_RUN = Boolean.parseBoolean(getProperty("islstBasedRun","false"));
	public static String FROM_TIME = getProperty("fromTimeStamp", "");
	public static String TO_TIME = getProperty("toTimeStamp", "");
	public static String LST_IDS = getProperty("lstIds","");
	public static String LST_FILES = getProperty("lstFiles","");
	public static String LST_FILES_FOLDER = getProperty("fileFolder","");
	public static String LST_CONF_FILE=getProperty("confFile", "");
	public static String OUTPUT_FOLDER = getProperty("outputFolder","");
	public static String collection=getProperty("collection", "test");
	public static String searchKey=getProperty("searchKey", "divitem");
	public static String gbSearchString=getProperty("gbSearchString", "_blob");
	public static Boolean gbSearchPassIfNotPresent = Boolean.parseBoolean(getProperty("gbSearchPassIfNotPresent","false"));
	public static List<String> FIELDSTOFETCH = Arrays.asList(getProperty("fields", "").split(","));
	public static List<String> CRITERIA = Arrays.asList(getProperty("criteria", "").trim().split(","));
	public static String UI_ENV = getProperty("UI_ENV","QA2");
	
	/*************Run configs **********************/
	public static Integer CONSUMER_THREADCOUNT = Integer.parseInt(getProperty("consumerThreads","10"));
	public static Boolean HidePassColumns = Boolean.parseBoolean(getProperty("hidePassColumns","false"));
	public static Boolean retryCallFlag=  Boolean.parseBoolean(getProperty("retryCallFlag", "false"));
	public static Integer FAILURE_THRESHOLD = Integer.parseInt(getProperty("failureThreshold","5000"));
	public static List<String> IGNORED_FAILURES = Arrays.asList(getProperty("ignoredFailures", "").trim().split(","));
	public static String promorelStore=getProperty("promorel.store", "dummy");
	public static String promorelStoreSpecificCompare=getProperty("promorel.store.compare", "false");
	
	
				/*-------------Reporting properties---------------*/
	public static Boolean ONLY_FAILED_RESULTS = Boolean.parseBoolean(getProperty("onlyFailedResults","true"));
	public static boolean EMAIL_FLAG = Boolean.parseBoolean(getProperty("emailflag", "false"));
	public static String EMAIL_RECEPIENTS = getProperty("emailreceipents", "niharika.varshney@searshc.com,dnyaneshwar.daphal@searshc.com");
	public static String EMAIL_RECEPIENTS_CC = getProperty("emailreceipentsCC", "");
	public static float FILE_SIZE = Float.parseFloat(getProperty("fileSize","5"));
	
	public static String GC_PRICE = "10";
	public static String GC_DATE = "9999-12-31 23:59:59";
	public static String STORE_NATIONAL_ID = "0009300,0009305,0009313,7800,7840";
	public static String DIVISION_ID = "003,006,008,009,020,022,026,042,046,057,071,058,034,030,082";
	public static String RIM_STATUS = "X,F";
	public static String Local_Store = "10153,10151";
	public static String LOCGRP_FILES = getProperty("grpFiles","");
	public static String Status = "0,1";
	
	/*************Kafka Setup **********************/
	
	public static String ZOOKEEPER2 = getProperty("zookeeper2", "rtckafka305p.qa.ch3.s.com:2181");
	public static String KAFKATOPIC2 = getProperty("topic2", "");
	public static String KAFKABROKER2 = getProperty("broker2", "");
	
	public static String ZOOKEEPER = getProperty("zookeeper", "rtckafka305p.qa.ch3.s.com:2181");
	public static String KAFKATOPIC = getProperty("topic", "");
	public static String KAFKAREADTIMEOUT = getProperty("readtimeout", "20000");
	public static String KAFKABROKER = getProperty("broker", "");
	public static Boolean ISKAFKARUN = Boolean.parseBoolean(getProperty("isKafkaRun", "false"));
	public static String KAFKAPROMOMETATOPIC = getProperty("promoMetaTopic", "");
	
	public static String KAFKA_MSG_FORMAT = getProperty("msgFormat", "");
	
	public static int TESTDATALIMIT = Integer.parseInt(getProperty("testdatalimit","0"));

	public static Integer CHUNK_SIZE = Integer.parseInt(getProperty("chunkSize","30"));
	public static Boolean FETCH_OFFER_INFO = Boolean.parseBoolean(getProperty("fetchOfferInfo","false"));
	public static Boolean RECONCILE_SERVICE_REFRESH_FLAG = Boolean.parseBoolean(getProperty("reconcileRefreshFlag","false"));
	
	private static Properties prop;

	public static String IA_SERVER = getProperty("iaServer", "iavip.qa.ch3.s.com:80");
	public static String MATCHING_SERVER = getProperty("matchingServer", "iadws302p.dev.ch3.s.com:8180");
	

	public static String gbServer=getProperty("gbserver", "greendb313p.qa.ch3.s.com");
	public static String gbServerPort=getProperty("gbport", "20000");
	public static String gbUser=getProperty("gbuser", "greenread");
	public static String gbPassword=getProperty("gbpassword", "Gr33nR3aD");
	
	/*-------------Buybox Properties---------------*/
	public static String IFTRANKVIP=getProperty("iftrankvip", "http://iftrankvip2.qa.ch3.s.com/ranking-service/v4/rank");
	public static String IASAPI=getProperty("iasApi", "http://ordsvcapp301p.qa.ch3.s.com:8180/itemtntservice/v2/availability");
	public static String PRICEGRIDAPI=getProperty("priceGridApi", "http://prqdvip.qa.ch3.s.com/priceservice/v1/get/price/json");
	public static String SHIPAPI=getProperty("shipApi", "http://ffmapp301p.qa.ch3.s.com:8180/ecomservices/getShippingDetails/json");
	public static String ZIPCODE=getProperty("zipCode", "0");
	public static String USERTYPE=getProperty("userType", "GUEST");
	public static String mysqlurl=getProperty("mysqlUrl","jdbc:mysql://siteadmq.qa.ch3.s.com:3306/siteadm");
	public static String mysqlUser=getProperty("mysqlUser","batchqa");
	public static String mysqlPassword=getProperty("mysqlPassword","sears123");
	public static String groupId="AF=1,AX=9,AL=1,DZ=1,AS=1,AD=1,AO=1,AI=1,AQ=1,AR=0,AM=1,AW=10,AU=5,BA=1,BW=1,BV=1,BR=8,IO=10,BN=1,BG=8,BF=1,BI=1,KH=1,CM=1,CA=0,CV=1,KY=10,CF=1,TD=1,CL=8,CN=6,CX=1,CC=1,CO=9,KM=1,CG=1,CD=1,CK=1,CR=7,EE=1,ET=1,FK=1,FO=1,FJ=1,FI=8,FR=8,GF=1,PF=1,TF=1,GA=1,GM=1,GE=1,HT=10,HM=1,VA=1,HN=7,HK=10,HU=8,IS=1,IN=1,ID=1,IR=1,IQ=1,IE=8,IM=1,LB=1,LS=1,LR=7,LY=7,LI=1,LT=1,LU=8,MO=1,MK=1,MG=7,MW=1,MY=1,MV=1,MS=1,MA=7,MZ=1,MM=1,NA=1,NR=1,NP=1,NL=8,AN=7,NC=8,NZ=5,NI=7,NE=1,PH=1,PN=1,PL=8,PT=8,PR=1,QA=1,RE=1,RO=1,RU=8,RW=1,BL=1,SH=1,KN=10,SK=8,SI=8,SB=1,SO=1,ZA=1,GS=1,ES=8,LK=1,SD=1,SR=10,SJ=1,SZ=1,SE=8,TM=1,TC=1,TV=1,UG=1,UA=1,AE=10,GB=8,US=1,UM=1,UY=1,UZ=1,VU=1,VE=1,AT=8,AZ=1,BS=7,BH=1,BD=1,BB=7,BY=1,BE=8,BZ=7,BJ=1,BM=10,BT=1,BO=1,HR=1,CU=7,CY=1,CZ=8,DK=8,DJ=1,DM=10,DO=7,EC=10,EG=8,SV=7,GQ=1,ER=1,DE=1,GH=1,GI=1,GR=1,GL=1,GD=10,GP=1,GU=7,GT=7,GG=1,GN=1,GW=1,GY=1,IL=1,IT=8,JM=10,JP=9,JE=1,JO=1,KZ=1,KE=1,KI=1,KR=8,KW=1,KG=1,LV=1,ML=1,MT=1,MH=1,MQ=1,MR=1,MU=1,YT=1,MX=7,FM=7,MD=1,MC=7,MN=1,ME=1,NG=1,NU=1,NF=1,MP=1,NO=8,OM=1,PK=1,PW=1,PS=1,PA=7,PG=1,PY=1,PE=1,LC=10,MF=10,PM=1,VC=1,WS=1,SM=1,ST=1,SA=8,SN=1,RS=1,SC=1,SL=1,SG=1,CH=1,SY=1,TW=7,TJ=1,TZ=1,TH=1,TL=1,TG=1,TK=1,TO=1,TT=7,TN=1,TR=1,VN=1,VG=1,VI=7,WF=1,EH=1,YE=1,ZM=1,ZW=1,AG=1";
	
	public static String STOREUNITNUMBER=getProperty("storeUnitNumber", "0");
	public static String STORESITE=getProperty("storeSite", "0");
	public static String LOCALADFLAG=getProperty("localAdFlag", "false");
	public static String PRICEGRIDAPIV2=getProperty("priceGridAPIv2", "http://prqdvip.qa.ch3.s.com:80/priceservice/v2/get/price/json");
	public static String serialAcceesFlag=getProperty("serialAcceesFlag", "true");
	public static String dbBonusPointsFlag=getProperty("dbBonusPointsFlag", "true");
	public static String itemConditionFlag=getProperty("itemConditionFlag", "true");
	public static String BONUSAPI=getProperty("bonusAPI", "http://iftrank301p.qa.ch3.s.com:8280/ranking-bonus-service/bonus/get");
	
	/**------Webdriver properties----**/
	public static Boolean ISLOCALRUN=Boolean.parseBoolean(getProperty("isLocalRun", "true"));
	public static String BROWSER=getProperty("browser", "*firefox");
	public static String DRIVER_HOST=getProperty("driverHost", "localhost");
	public static Integer DRIVER_PORT=Integer.parseInt(getProperty("driverPort", "4444"));
	public static String CHROME_PATH=getProperty("chromeDriverPath", "");
	public static Long EXPLICITWAITTIMEOUT=Long.parseLong(getProperty("explicitWaitTimeOutSec","20"));
	public static String INITURL=getProperty("urlToStart","");
	public static String OUTPUTFOLDER;
	
	
	private static String customMsgForEmail = null;
	public static Boolean splitResult = Boolean.parseBoolean(getProperty("splitResult","false"));
	//public static String searsExcludeStores = "2885,1216,1010,2577,2256,2627,2360,2390,1012,1022,1027,1042,1100,1115,1130,1202,1265,1280,1315,1317,1445,1470,1545,1560,1575,1590,1595,1600,1610,1615,1730,1773,1780,1785,1804,1822,1974,2001,2030,2036,2046,2050,2065,2082,2104,2105,2119,2126,2130,2156,2208,2212,2218,2232,2244,2278,2288,2309,2311,2329,2330,2331,2339,2342,2353,2354,2358,2382,2421,2422,2435,2480,2505,2527,2544,2546,2547,2565,2570,2597,2615,2624,2644,2654,2683,2705,2710,2744,2774,2784,2805,2820,2825,2840,2845,2922,2945,2963,1014,1040,1051,1062,1082,1110,1140,1146,1220,1287,1321,1330,1367,1386,1387,1463,1495,1534,1585,1665,1688,1717,1795,1800,1850,1863,1968,1978,2028,2029,2088,2124,2166,2175,2176,2205,2207,2242,2258,2290,2335,2432,2487,2494,2600,2695,2755,2802,2829,2990,1005,1016,1017,1025,1041,1049,1064,1070,1072,1073,1084,1086,1093,1126,1137,1150,1151,1152,1162,1195,1222,1236,1244,1251,1273,1286,1301,1306,1323,1336,1353,1364,1370,1404,1473,1474,1504,1514,1525,1530,1555,1594,1598,1614,1620,1634,1635,1644,1684,1690,1694,1695,1712,1790,1802,1810,1874,1954,2003,2013,2061,2064,2071,2073,2074,2080,2113,2121,2125,2134,2138,2160,2186,2216,2220,2221,2225,2226,2250,2293,2305,2316,2349,2361,2371,2381,2392,2420,2470,2500,2510,2533,2574,2583,2604,2637,2642,2645,2704,2712,2724,2750,2807,2815,2819,2826,2850,2855,2933,2934,2940,3153,8463,2482,2895";
	//public static String kmartExcludeStores = "9751,7736,9243,4781,7154,3147,9101,4964,9129,3059,3076,3130,3184,3223,3225,3230,3324,3325,3358,3401,3410,3433,3544,3556,3598,3646,3678,3744,3884,3923,4090,4147,4156,4160,4162,4171,4288,4303,4313,4332,4435,4455,4460,4812,4880,7028,7131,7155,7174,7207,7208,7233,7296,7354,7356,7393,7397,7412,7418,7425,7426,7430,7431,7471,7535,7656,7754,9105,9122,9222,9255,9385,9513,9534,9608,9680,9792,3029,3086,3088,3103,3131,3189,3219,3237,3239,3241,3301,3425,3557,3600,3621,3661,3667,3688,3715,3754,3814,3823,3837,3852,3925,3934,3957,4016,4033,4048,4062,4084,4128,4215,4351,4427,4433,4439,4453,4473,4717,4739,4757,4897,4928,4970,7000,7003,7021,7033,7034,7041,7043,7045,7046,7063,7065,7069,7075,7160,7169,7217,7254,7274,7304,7306,7318,7341,7460,7583,7642,7644,7648,7719,9065,9096,9146,9153,9309,9320,9582,9620,9629,9648,9733,9735,3018,3043,3111,3117,3126,3251,3282,3287,3295,3328,3343,3350,3355,3372,3414,3435,3531,3535,3568,3620,3641,3644,3706,3722,3784,3795,3825,3828,3861,3876,3914,3916,3931,3938,3943,3946,3985,3988,3991,3998,4006,4007,4047,4064,4066,4089,4091,4095,4131,4151,4152,4159,4169,4175,4235,4275,4320,4331,4339,4344,4362,4364,4377,4471,4700,4701,4709,4715,4716,4719,4720,4743,4747,4749,4769,4777,4793,4795,4796,4808,4813,4815,4817,4826,4827,4840,4844,4847,4848,4850,4851,4858,4862,4865,4866,4868,4870,4873,4883,4886,4953,4961,4984,4987,7066,7185,7193,7253,7265,7282,7303,7317,7325,7353,7420,7444,7446,7484,7486,7499,7527,7532,7551,7555,7560,7608,7618,7624,7640,7643,7655,7660,7665,7710,7775,7784,7904,9133,9329,9332,9336,9339,9351,9382,9397,9433,9447,9462,9511,9684,9728,3232,3298,3363,3376,3777,3832,3836,3845,3848,3890,3929,3951,3967,3976,3994,4735,4783,4913,7057,7161,7206,7360,7423,7461,7493,7636,7645,9241,9737";
	
	public enum MSGTYPE{
		SUCCESS,
		WARNING,
		ERROR
	}
	
	public static String getCustomMsgForEmail() {
		return customMsgForEmail;
	}

	public static void setCustomMsgForEmail(String msgForEmail) {
		customMsgForEmail = msgForEmail;
	}
	
	public static void setCustomMsgForEmail(String msgForEmail, MSGTYPE typeOfMsg) {
		switch(typeOfMsg){
		case ERROR:{
			customMsgForEmail = "<font face='Calibri' color='red' size='3'>"+msgForEmail+"</font>";
		}
			break;
		case SUCCESS:{
			customMsgForEmail = "<font face='Calibri' color='green' size='3'>"+msgForEmail+"</font>";
		}
			break;
		case WARNING:{
			customMsgForEmail = "<font face='Calibri' color='goldenrod' size='3'>"+msgForEmail+"</font>";
		}
		break;	
		default:{
			customMsgForEmail = msgForEmail;
		}
			break;
		
		}
		
	}

	public static Properties getProp() {
		return prop;
	}

	public static void setProp(Properties prop) {
		LoadProperties.prop = prop;
	}

	public static String getProperty(String key, String defaultValue) {
		// Read properties file.
		if (null == prop) {
			prop = new Properties();

			try {
				prop.load(LoadProperties.class.getClassLoader().getResourceAsStream("env.properties"));
				prop.load(LoadProperties.class.getClassLoader().getResourceAsStream("runnreporting.properties"));
				prop.load(LoadProperties.class.getClassLoader().getResourceAsStream("testspecific.properties"));
				prop.load(LoadProperties.class.getClassLoader().getResourceAsStream("driver.properties"));
				
			} catch (IOException e) {
				e.printStackTrace();
			}

			Enumeration<Object> keys = prop.keys();

			System.out.println("Configured properties:");
			while (keys.hasMoreElements()) {
				String elt = (String) keys.nextElement();
				System.out.println(String.format(
						"\t\tProperty: %s, value: '%s'", elt, prop
						.getProperty(elt)));
			}
			for (Object syskey : prop.keySet()) {
				String value = System.getProperty(syskey.toString());
				if ((value != null) && (!value.equals(""))) {
					prop.setProperty(syskey.toString(), value);
					System.out.println("Overriding "+ syskey+" to  "+value);
				}
			}
		}


		return prop.getProperty(key, defaultValue);
	}

	
	
	
}
