package com.shc.autocontent.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public static String getCurrentDateAndTimeInRquiredFormat(String format)
	{
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	/**
	 * String to Tz format date string
	 * @param exp
	 * @return
	 */
	public static String convertDateToTzFormat(String exp)
	{

		exp = exp.replace(" ", "T");

		exp = exp.substring(0,exp.indexOf("."));

		exp = exp + ".000Z";

		return exp;
	}

}
