package com.shc.autocontent.parsers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;


public class ChunkProducerThread<T> implements Runnable{
	
	private XMLChunker myChunker;
	private BlockingQueue<List<T>> blockingQueue;
	private Class<T> classToTest ;
	private int bucketSize = 10;  //defaults to 10 - can be changed
	public List<T> POISON_PILL ;
	public String nodeName = null;
	
	/**
	 * 
	 * Set the filename to process, the blocking queue to add the list to and the class to cast
	 * the chunk to
	 * @param sFileName  - File name to process
	 * @param queueLstVOs - Queue of list of vos
	 * @param cls - Class to cast to
	 */
	public ChunkProducerThread(String sFileName, BlockingQueue<List<T>> queueLstVOs, Class<T> cls){
		myChunker = new StaxXMLChunker(sFileName);
		this.blockingQueue = queueLstVOs;
		this.classToTest = cls;
		POISON_PILL = new ArrayList<T>();;
		
	}
	
	public ChunkProducerThread(String sFileName, BlockingQueue<List<T>> queueLstVOs, Class<T> cls, String nodeName){
		myChunker = new StaxXMLChunker(sFileName);
		this.blockingQueue = queueLstVOs;
		this.classToTest = cls;
		POISON_PILL = new ArrayList<T>();
		this.nodeName =  nodeName;
		
	}
	
	/**
	 * Use this constructor if a parser has already processed a file and mid way new nodes need to be used
	 * To be used in conjunction with cutoffnode
	 * @param xmlChunker
	 * @param queueLstVOs
	 * @param cls
	 */
	public ChunkProducerThread(XMLChunker xmlParser, BlockingQueue<List<T>> queueLstVOs, Class<T> cls){
		myChunker =  xmlParser;
		this.blockingQueue = queueLstVOs;
		this.classToTest = cls;
		POISON_PILL = new ArrayList<T>();;
		
	}
	
	/**
	 * Set the number of items to be added to one list.
	 * This can be set on the number of threads one plans to have for their tests
	 * @param bucketSize
	 */
	public void setBucketSize(int bucketSize){
		this.bucketSize = bucketSize;
	}
	
	/**
	 * Set the cutoff node.  Optional parameter, in case not the entire xml needs to be read
	 * 
	 * @param bucketSize
	 */
	public void setCutOffNode(String sCutOffNode){
		this.myChunker.setCutOffNode(sCutOffNode);
	}
	
	/**
	 * Retrieve the parser that is parsing the current file
	 * Use in conjunction with cutoff node
	 * @return
	 */
	public XMLChunker getParser(){
		return myChunker;
	}
	/**
	 * Creates list of objects of class<T>, adds to a list of size specified by @field bucketsize
	 * Adds the list to a blockingqueue for someone to process
	 */
	@SuppressWarnings({ "unchecked" })
	public void run() {
		//Read the file and add VOs to the list
		Thread.currentThread().setName("Producer Thread "+ Thread.currentThread().getId());
		List<T> lstObjects = new ArrayList<T>();
		
		int numberOfObjectsToRead = 0;
		
		
		while(true){
			Object readObject;
			if(nodeName != null)
				readObject = myChunker.unmarshalXML(this.classToTest, nodeName);
			else
				readObject = myChunker.unmarshalXML(this.classToTest);
			
			try{
				numberOfObjectsToRead++;
				//if object is null then EOF or no more objects of type 
				//offer to queue whatever is read and get out of producer
				//To add property if specific number of nodes need to be tested
				/*if(numberOfObjectsToRead > 5){
					this.blockingQueue.put(POISON_PILL );
					System.out.println("inserted poison: "+ POISON_PILL);
					break;
				}*/
				if(readObject==null){
					if(lstObjects.size() > 0)
						this.blockingQueue.put(lstObjects);
					
					this.blockingQueue.put(POISON_PILL );
					//System.out.println("Total" + numberOfObjectsToRead);
					return ;
				}
				
				
				//Add to list.  Check if list size is bucketSize and then offer to queue 
				lstObjects.add((T) readObject);
				if(lstObjects.size() == bucketSize){
					//Ok! am taking a chance here with put!
//					this.blockingQueue.put(lstObjects);
					this.blockingQueue.offer(lstObjects,20,TimeUnit.SECONDS);
					lstObjects = new ArrayList<T>();		
				}
			}catch (InterruptedException e) {
					e.printStackTrace();
			}
		}
		
	}
			
}
