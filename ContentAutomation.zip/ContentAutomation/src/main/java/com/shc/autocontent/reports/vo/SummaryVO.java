package com.shc.autocontent.reports.vo;

import java.util.LinkedHashMap;
import java.util.Map;

public class SummaryVO {

	private String jobName;
	private String dateTime;
	private int noOfXmls;
	private int noOfEmptyXmls;
	private int noOfXmlsWithMismatch;
	
	private Map<String,SingleXMLSummaryResultVO> detailMap = new LinkedHashMap<String,SingleXMLSummaryResultVO>();

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public int getNoOfXmls() {
		return noOfXmls;
	}

	public void setNoOfXmls(int noOfXmls) {
		this.noOfXmls = noOfXmls;
	}

	public int getNoOfEmptyXmls() {
		return noOfEmptyXmls;
	}

	public void setNoOfEmptyXmls(int noOfEmptyXmls) {
		this.noOfEmptyXmls = noOfEmptyXmls;
	}

	public int getNoOfXmlsWithMismatch() {
		return noOfXmlsWithMismatch;
	}

	public void setNoOfXmlsWithMismatch(int noOfXmlsWithMismatch) {
		this.noOfXmlsWithMismatch = noOfXmlsWithMismatch;
	}

	public Map<String, SingleXMLSummaryResultVO> getDetailMap() {
		return detailMap;
	}

	public void setDetailMap(Map<String, SingleXMLSummaryResultVO> detailMap) {
		this.detailMap = detailMap;
	}
	
}
