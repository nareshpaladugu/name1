package com.shc.autocontent.reports.vo;

public class FinalResult {

	private int iFailedCount;
	private int iTotalCount;
	
	public int getFailedCount() {
		return iFailedCount;
	}

	public int getTotalCount() {
		return iTotalCount;
	}

	public synchronized void addToFailed(){
		iFailedCount++;
	}
	
	public synchronized void addToTotal(){
		iTotalCount++;
		if(iTotalCount == 10000){
			System.out.println(iTotalCount);
		}
	}
	
	public synchronized void reduceFailed(){
		iFailedCount--;
	}
	
	public synchronized void reduceTotal(){
		iTotalCount--;
	}
}
