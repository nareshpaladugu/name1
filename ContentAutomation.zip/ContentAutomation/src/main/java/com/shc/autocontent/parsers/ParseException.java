package com.shc.autocontent.parsers;

public class ParseException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6229504823639746157L;

	public ParseException(String message){
		super(message);
	}
	
	public ParseException(String message, Throwable cause){
		super(message, cause);
	}
	
}
