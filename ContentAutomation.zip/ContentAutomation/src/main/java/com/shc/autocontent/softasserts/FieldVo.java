package com.shc.autocontent.softasserts;
public class FieldVo implements Cloneable
{

	public FieldVo clone() {
		try {
			return (FieldVo)super.clone();
		}
		catch (CloneNotSupportedException e) {
			// This should never happen
			return null;
		}
	}

	public FieldVo(String resultField, String fieldPath, boolean mandatory,
			boolean booleanFlag) {
		super();
		//System.out.println( resultField +" : "+ fieldPath+" : "+ mandatory+":"+booleanFlag);
		this.resultField = resultField;
		this.fieldPath = fieldPath;
		this.mandatory = mandatory;
		this.booleanFlag = booleanFlag;
	}

	//default mandatory = false
	public FieldVo(String resultField, String fieldPath, 
			boolean booleanFlag) {
		super();
		this.resultField = resultField;
		this.fieldPath = fieldPath;
		this.mandatory = false;
		this.booleanFlag = booleanFlag;
	}


	public String getFieldPath() {
		return fieldPath;
	}
	public void setFieldPath(String fieldPath) {
		this.fieldPath = fieldPath;
	}
	public boolean isMandatory() {
		return mandatory;
	}
	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}
	public boolean isBooleanFlag() {
		return booleanFlag;
	}
	public void setBooleanFlag(boolean booleanFlag) {
		this.booleanFlag = booleanFlag;
	}

	private String resultField;
	public String getResultField() {
		return resultField;
	}
	public void setResultField(String resultField) {
		this.resultField = resultField;
	}

	private String fieldPath;
	private boolean mandatory;
	private boolean booleanFlag;
}