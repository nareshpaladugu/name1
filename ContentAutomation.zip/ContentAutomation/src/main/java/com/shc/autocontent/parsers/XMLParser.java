package com.shc.autocontent.parsers;

import java.io.FileReader;
import java.io.Reader;

import org.exolab.castor.xml.Unmarshaller;

public class XMLParser {

	/**
	 * This method accepts XML file name and returns object of class
	 * @param fileName
	 * @param cls
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T unmarshallXML(String fileName,Class<T> cls) {

		T returnVal=null;
		try {
			Reader reader = new FileReader(fileName);

			returnVal =  (T) Unmarshaller.unmarshal(cls, reader);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return returnVal;
	}
	
	/**
	 * Given a node and an attribute uses the stax parser to return the value of attribute
	 * @param file
	 * @param node
	 * @param attribute
	 * @return
	 */
	public static String findNodeValue(String file,String node, String attribute){
		StaxXMLChunker nodeFinder = new StaxXMLChunker(file);
		return nodeFinder.findNodeValue(node, attribute);
		
	}
	
	
	

}
