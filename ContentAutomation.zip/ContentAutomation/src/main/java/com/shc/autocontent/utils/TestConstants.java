package com.shc.autocontent.utils;

/**
 * @author ddaphal
 *
 */
public class TestConstants 
{

	final public static String EMPTY_STRING = "";
}
