package com.shc.autocontent.db;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.shc.autocontent.LoadProperties;
/**
 * This class should no longer be used
 * @deprecated 
 * Use {@link com.shc.autocontent.db.DBConnector} class with properties set in env.properties file
 */
@Deprecated
public class MySqlConnectionUtil {


	private static Connection connection = null;
	public static int db2QueryHitCounter = 0;
	public static long db2QueryHitTime = 0;

	static{
		String mySqlurl=LoadProperties.mysqlurl;
		String user=LoadProperties.mysqlUser;
		String password=LoadProperties.mysqlPassword;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection("jdbc:mysql://dbincubate.qa.ch3.s.com:3306/e4x", "intqa", "e4x@qa");

		} catch (Exception e) {
			e.printStackTrace();
			throw new DBException("Error in connecting to "+ mySqlurl,e.getCause());
		}
	}

	/**
	 * Returns a singleton connection object to execute queries to wcs db
	 * @return
	 */
	public static Connection getConnection()
	{
			return connection;
	}


	/**
	 * Returns null if no result found, else the resultset object for further manipulation
	 * @param sQuery
	 * @return ResultSet - result objects
	 */
	public static ResultSet executeQueryReturnSingleResultSet(String sQuery){
		db2QueryHitCounter++;
		long start = System.currentTimeMillis();
		
		try {
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sQuery);

			if(rs != null){
				return rs;
			}
			else{
				stmt.close();
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException("Error in executing sql query "+sQuery+" \n " + e.getMessage());
		}
		finally
		{
			db2QueryHitTime+= System.currentTimeMillis()-start;
		}
	}
}
