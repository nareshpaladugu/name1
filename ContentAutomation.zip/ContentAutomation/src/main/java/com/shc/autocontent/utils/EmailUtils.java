package com.shc.autocontent.utils;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.shc.autocontent.LoadProperties;
import com.shc.content.listeners.SendAutoEmail;

public class EmailUtils {


	public static void sendEmail(String customSubject, String customBody, File... file)
	{
		if(!LoadProperties.EMAIL_FLAG)
			return;
		String host = "mailhost.prod.ch3.s.com";
		String from = "content.automation@searshc.com";
		String[] cc = {""};
		try {

			String emailRecipients =  LoadProperties.EMAIL_RECEPIENTS;
			String emailRecipientsCC =  LoadProperties.EMAIL_RECEPIENTS_CC;

			String[] toList = emailRecipients.split(",");

			if(emailRecipientsCC!=null)
			{
				cc = emailRecipientsCC.split(",");
			}

			String sMailBodyTextSummary =  "<font face='Calibri' color='black' size='2'><B>***NOTE: This is an auto generated mail.***" +
					"<br><span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;'>";

			String regards = "<font face='Calibri' color='black' size='2'><B><br><br>Regards, <br>Content Automation<br>";

			SendAutoEmail.sendMailUsingJavaMail(host, from, toList, cc,customSubject , sMailBodyTextSummary+customBody+ regards, file);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void sendEmailWithDetails(String customSubject, String customBody,String time, File file)
	{
		if(!LoadProperties.EMAIL_FLAG)
			return;
		String host = "mailhost.prod.ch3.s.com";
		String from = "content.automation@searshc.com";
		String[] cc = {""};
		try {

			String emailRecipients =  LoadProperties.EMAIL_RECEPIENTS;
			String emailRecipientsCC =  LoadProperties.EMAIL_RECEPIENTS_CC;

			String[] toList = emailRecipients.split(",");

			if(emailRecipientsCC!=null)
			{
				cc = emailRecipientsCC.split(",");
			}

			String sMailBodyTextSummary =  "<font face='Calibri' color='black' size='2'><B>***NOTE: This is an auto generated mail.***" +
					"<br><span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;'>";

			sMailBodyTextSummary += "<br><font face='Calibri' color='black' size='3'> Bucket No(s). : "
			+ LoadProperties.RUN_PARAMS+"<br>GB : "+LoadProperties.GREENVIP
			+ "<br><br> Execution Time(HH:MM:ss) : "+time;
			
			String regards = "<font face='Calibri' color='black' size='2'><B><br><br>Regards, <br>Content Automation<br>";

			SendAutoEmail.sendMailUsingJavaMail(host, from, toList, cc,customSubject , sMailBodyTextSummary+customBody+ regards, file);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public static String prepareCustomTable(Map<String, String> tableData){
		StringBuilder mailBody = new StringBuilder();
		if(tableData.size() == 0){
			mailBody.append("No data found on "+LoadProperties.GREENVIP);
		}else{
			mailBody.append("<font face='Calibri' color='black' size='2'>"+
					"<BR><BR><TABLE><TABLE cellspacing='2' cellpadding='1' border='1' BORDERCOLOR='#4f81bd'  ><col width='160px'><col width='160px'>"+
					"");

			for(String key : tableData.keySet()){
				mailBody.append("<TR><TD>"+key+"</TD><TD>"+tableData.get(key)+"</TD>");
			}
			mailBody.append("</TABLE></TABLE></BR></BR>");
		}
		return mailBody.toString();
	}

	public static String prepareCustomTableUsingList(List<List<String>> tableData)
	{

		StringBuilder mailBody = new StringBuilder();
		if(tableData.size() == 0){
			mailBody.append("No data found on "+LoadProperties.GREENVIP);
		}else{
			mailBody.append("<font face='Calibri' color='black' size='1'>"+
					"<TABLE cellspacing='2' cellpadding='1' border='1' BORDERCOLOR='#4f81bd' ><col width='460px'><col width='160px'>"+
					"");

			List<String> header = tableData.get(0);
			
			mailBody.append("<TR>");
			
			for (String string : header) 
			{
				mailBody.append("<th bgcolor=\"#00FFFF\">"+string+"</TH>");
			}
			 
			mailBody.append("</TR>");
					
			for(int i=1;i<tableData.size();i++)
			{
				List<String> list = tableData.get(i);

				mailBody.append("<TR>");

				for (String string : list) {

					mailBody.append("<TD>"+string+"</TD>");
				}

				mailBody.append("</TR>");
			}

			mailBody.append("</TABLE>");
		}
		return mailBody.toString();
	}

	public static String getDurationString(long seconds) {

		long hours = seconds / 3600;
		long minutes = (seconds % 3600) / 60;
		seconds = seconds % 60;

		return twoDigitString(hours) + ":" + twoDigitString(minutes) + ":" + twoDigitString(seconds);
	}

	public static String twoDigitString(long number) {

		if (number == 0) {
			return "00";
		}

		if (number / 10 == 0) {
			return "0" + number;
		}

		return String.valueOf(number);
	}

}