package com.shc.autocontent.parsers;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileManager;
import com.shc.content.vocabularyfeeds.pojos.HierarchyVO;
import com.shc.content.vocabularyfeeds.pojos.ProductVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;
import com.shc.content.vocabularyfeeds.utils.GBTaggingConstants;
import com.shc.content.vocabularyfeeds.utils.GbTaggingUtils;
import com.shc.content.vocabularyfeeds.utils.HierarchyHelper;

public class VocabularyFeedParser<T> implements Runnable {

	public Model model = null;
	private BlockingQueue<List<T>> blockingQueue;
	public List<T> POISON_PILL = new ArrayList<>();
	public String nodeName = null;

	public VocabularyFeedParser(String fileName, BlockingQueue<List<T>> queueLstVOs) throws Exception {
		File file = new File(fileName);
		if (!file.exists())
			throw new Exception("Input File Not Present At: "+fileName);
		model = FileManager.get().loadModel(fileName);

		this.blockingQueue = queueLstVOs;
		
		// Parse RDF File
		parseRDFFile();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		// Create Objects
		ProductVO productObj = null;
		HierarchyHelper hirearchyHelper = new HierarchyHelper();
		try {
			for(String productId : GBTaggingConstants.PRODUCT_ID_LIST) {
				productObj = GBTaggingConstants.PRODUCT_MAP.get(productId);
				if (productObj != null) {
					List<HierarchyVO> relatedHierarchyList = new ArrayList<>();
					List<HierarchyVO> deletedHierarchyList = new ArrayList<>();
					List<String> relatedVocabularyTermsForProducts = getRelatedVocabularyAssociationsForProduct(productObj.getId());

					// get all hierachy for related associations. This will create our insert displayPath list for
					// product
					if (org.apache.commons.collections.CollectionUtils.isNotEmpty(relatedVocabularyTermsForProducts)) {
						for (String vocabularyTerm : relatedVocabularyTermsForProducts) {
							HierarchyVO relatedHierarchy = hirearchyHelper.createHierarchy(vocabularyTerm, GBTaggingConstants.HIERARCHY_TYPE_INSERT);
							relatedHierarchy.generateSpinIdPaths();
							relatedHierarchy.cascadeDate();
							relatedHierarchy.setDeleteActionHierarchy();
							relatedHierarchyList.add(relatedHierarchy);
						}
					}

					List<String> deletedTermVocabularyTermsForProducts = getDeletedTermVocabularyAssociationsForProduct(productObj.getId());

					// get all hierachy for deletedTerm associations. This will create our delete displayPath list for
					// product
					if (org.apache.commons.collections.CollectionUtils.isNotEmpty(deletedTermVocabularyTermsForProducts)) {
						for (String vocabularyTerm : deletedTermVocabularyTermsForProducts) {
							HierarchyVO deletedHierarchy = hirearchyHelper.createHierarchy(vocabularyTerm, GBTaggingConstants.HIERARCHY_TYPE_DELETE);
							deletedHierarchy.generateSpinIdPaths();
							deletedHierarchy.cascadeDate();
							deletedHierarchy.setDeleteActionHierarchy();
							deletedHierarchyList.add(deletedHierarchy);
						}
					}

					productObj.setRelatedList(relatedHierarchyList);
					//product.setLinkedVocabularyList(linkedHierarchyList);
					productObj.setDeletedList(deletedHierarchyList);

					if (productObj != null) {
						List<T> list = new ArrayList<>();
						list.add((T) productObj);
						this.blockingQueue.put(list);
					}
				}
			}
			this.blockingQueue.put(POISON_PILL);
		} catch (Exception e) {
			System.out.println("Exception while processing product id ::" + productObj.getId()+ e);
		}
	}

	public void parseRDFFile() {
		// Read RDF File
		try {
			Query getProductQuery = QueryFactory.create(GBTaggingConstants.getAllProductIdQuery);
			QueryExecution qexec = QueryExecutionFactory.create(getProductQuery, model);
			try {
				ResultSet results = qexec.execSelect();
				while (results.hasNext()) {
					QuerySolution soln = results.nextSolution();
					Literal productId = soln.getLiteral("id");
					Literal productName = soln.getLiteral("name");
					GBTaggingConstants.PRODUCT_ID_LIST.add(productId.toString());
					addProductToMap(productId, productName);
				}
			} catch (Exception ex) {
				System.out.println("Exception while : " + ex);
			} finally {
				System.out.println("Total Product Size ::" + GBTaggingConstants.PRODUCT_MAP.size());
				qexec.close();
			}

			System.out.println("Started loading vocabulary terms");
			Query getVocabularyTermQuery = QueryFactory.create(GBTaggingConstants.getALLVocabularyTermQuery);
			QueryExecution vocTermQueryExec = QueryExecutionFactory.create(getVocabularyTermQuery, model);
			try {
				ResultSet results = vocTermQueryExec.execSelect();
				while (results.hasNext()) {
					QuerySolution soln = results.nextSolution();
					Literal vocId = soln.getLiteral("id");
					Literal vocName = soln.getLiteral("name");
					Literal displayPath = soln.getLiteral("displayPath");
					Literal parentId = soln.getLiteral("parentId");
					Literal actvDate = soln.getLiteral("activationDate");
					Literal expDate = soln.getLiteral("expirationDate");
					Literal action = soln.getLiteral("action");
					addVocabularyTermToMap(vocId, vocName, displayPath, parentId, actvDate, expDate, action);
				}
				System.out.println("Total vocabulary terms size :" + GBTaggingConstants.VOCTERM_MAP.size());
				System.out.println("Total Product Size ::" + GBTaggingConstants.VOCTERM_MAP.size());
			} catch (Exception ex) {
				System.out.println("error while loading voctags " + ex);
			} finally {
				System.out.println("Total Product Size ::" + GBTaggingConstants.VOCTERM_MAP.size());
				vocTermQueryExec.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	private  void addVocabularyTermToMap(Literal vocId, Literal vocName, Literal displayPath, Literal parentIdField,
			Literal actvDateField, Literal expDateField, Literal actionField) {
		String parentId = null;
		String actvDate = null;
		String expDate = null;
		String action = null;

		if (parentIdField != null) {
			parentId = parentIdField.toString();
		}

		if (actvDateField != null) {
			actvDate = actvDateField.toString();
		}

		if (expDateField != null) {
			expDate = expDateField.toString();
		}

		if (actionField != null) {
			action = actionField.toString();
		}

		VocabularyTermVO vocTerm = GbTaggingUtils.createVocabularyTerm(vocId.toString(), vocName.toString(),displayPath.toString(), parentId, actvDate, expDate, action);
		if (vocTerm != null) {
			GBTaggingConstants.VOCTERM_MAP.put(vocTerm.getId(), vocTerm);
		}
	}

	private  void addProductToMap(Literal productId, Literal productName) {
		ProductVO product = GbTaggingUtils.createProduct(productId.toString(), productName.toString());
		// Product
		// existingProduct=RdfQueryConstants.PRODUCT_MAP.get(Integer.parseInt(productId.toString()));
		if (product != null) {
			GBTaggingConstants.PRODUCT_MAP.put(product.getId(), product);
		}
	}

	public  String getRelatedVocabularyAssociationsForProductQuery(String productId) {
		String relatedVocTags = GBTaggingConstants.getAllRelatedVocabularyTermsForProduct;
		relatedVocTags = relatedVocTags.replace(GBTaggingConstants.productIdPlaceHolder, productId);
		return relatedVocTags;
	}

	public  String getLinkedVocabularyAssociationsForProductQuery(String primaryVocId) {
		String linkedVocTags = GBTaggingConstants.getAllLinkedVocabularyTermsForProduct;
		linkedVocTags = linkedVocTags.replace(GBTaggingConstants.vocabularyIdPlaceHolder, primaryVocId);
		return linkedVocTags;
	}

	public  String getDeletedLinkedVocabularyAssociationsForProductQuery(String primaryVocId) {
		String deletedLinkedVocTags = GBTaggingConstants.getAllDeletedLinkedVocabularyTermsForProduct;
		deletedLinkedVocTags = deletedLinkedVocTags.replace(GBTaggingConstants.vocabularyIdPlaceHolder, primaryVocId);
		return deletedLinkedVocTags;
	}

	public  String getDeletedTermVocabularyAssociationsForProductQuery(String productId) {
		String deletedVocTags = GBTaggingConstants.getAllDeletedVocabularyTermsForProduct;
		deletedVocTags = deletedVocTags.replace(GBTaggingConstants.productIdPlaceHolder, productId);
		return deletedVocTags;
	}

	public  List<String> getRelatedVocabularyAssociationsForProduct(String productId) {
		Query relatedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getRelatedVocabularyAssociationsForProductQuery(productId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(relatedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("vocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public List<String> getLinkedVocabularyAssociationsForProduct(String primaryVocId) {
		Query linkedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getLinkedVocabularyAssociationsForProductQuery(primaryVocId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(linkedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("linkedVocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public List<String> getDeletedLinkedVocabularyAssociationsForProduct(String primaryVocId) {
		Query deletedLinkedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getDeletedLinkedVocabularyAssociationsForProductQuery(primaryVocId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(deletedLinkedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("deletedLinkedVocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public  List<String> getDeletedTermVocabularyAssociationsForProduct(String productId) {
		Query deletedTermVocabularyAssociationsForProductQuery = QueryFactory.create(
				getDeletedTermVocabularyAssociationsForProductQuery(productId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(deletedTermVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("vocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}
}