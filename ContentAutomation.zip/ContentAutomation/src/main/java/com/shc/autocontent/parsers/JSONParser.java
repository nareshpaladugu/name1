package com.shc.autocontent.parsers;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.shc.autocontent.db.CollectionValues;

/**
 * Class offers utility methods to parse JSON string to various outputs
 * @author nvarsh0
 *
 */
public class JSONParser {
	
	public static String toJSON(Object object)
	{
		Gson gson = new Gson();
		return gson.toJson(object);
	}

	/**
	 * This method accepts json string value and returns object of class
	 * @param json
	 * @return
	 * @throws JsonSyntaxException
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static <T> T parseJSON(String json,Class<T> cls) {

		Gson gson = new Gson();
		T returnVal = gson.fromJson(json, cls);
		return returnVal;
	}
	
	/**
	 * Parse a json to integer - use if json is returning a count or number (Use case - number of bucket ids)
	 * @param json
	 * @param sMemberName
	 * @return
	 */
	public static Integer parseJSONToInt(String json, String sMemberName) {

		JsonParser jParser = new JsonParser();
		JsonObject jObj = jParser.parse(json).getAsJsonObject();
		return jObj.get(sMemberName).getAsInt();
	}
	
	/**
	 * Parse a json string to a list of String - use if response is returning a list of string objects 
	 * Use case  - get-ids
	 * @param json
	 * @return
	 */
	public static List<String> parseJSONToArray(String json) {

		
		JsonParser jParser = new JsonParser();
		
		//Adding to handle the malformed json 
		/*JsonReader jReader = new JsonReader(new StringReader(json));
		jReader.setLenient(true);
		JsonArray jObj = jParser.parse(jReader).getAsJsonArray();*/
		
		JsonArray jObj = jParser.parse(json).getAsJsonArray();
		List<String> lstOfValues =  new ArrayList<String>();
		for(JsonElement j : jObj){
			lstOfValues.add(j.getAsString());
		}
		return lstOfValues;
	}
	
	/**
	 * Strips of blob from json response and processes the response
	 * If no value is returned then returns null
	 * @param json - json response to parse
	 * @param c - Collection to which value is mapped
	 * @param cls - Class to cast to
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T parseJSONWithBlob(String json, CollectionValues c,Class<T> cls) {
		//Strip off blob if present
		if(json.contains("_blob")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			return (T) parseJSON(j.get(0).getAsJsonObject().get("_blob").getAsJsonObject().get(c.getTypeOfObject()), cls);
		}else{
			if(json.equals("[]"))
				return null;
			return (T)parseJSON(json, c.getClassType());
		}
	}
	
	/**
	 * Parses multiple json docs and returns a list of objects of type specified by class
	 * @param json - json response
	 * @param c - collection to fetch from
	 * @param cls - If a specific class needs to be cast to
	 * @return
	 */
	public static <T> List<T> parseJSONDocsWithBlob(String json, CollectionValues c,Class<T> cls) {
		//Strip off blob if present
		List<T> lstDocs = new ArrayList<T>();
		if(json.contains("_blob")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			for(int i = 0; i < j.size(); i++){
				lstDocs.add((T) parseJSON(j.get(i).getAsJsonObject().get("_blob").getAsJsonObject().get(c.getTypeOfObject()), cls));
			}
		}else{
			if(json.equals("[]"))
				return null;
		}
		return lstDocs;
	}
	
	/**
	 * Parses multiple json docs and returns a list of objects of type specified by class
	 * Method doesn't remove blob from result
	 * @param json - json response
	 * @param c - collection to fetch from
	 * @param cls - If a specific class needs to be cast to
	 * @return
	 */
	public static <T> List<T> parseJSONDocs(String json,Class<T> cls) {
		//Strip off blob if present
		List<T> lstDocs = new ArrayList<T>();
		if(!json.equals("[]")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			for(int i = 0; i < j.size(); i++){
				lstDocs.add((T) parseJSON(j.get(i).getAsJsonObject(), cls));
			}
		}else{
			if(json.equals("[]"))
				return null;
		}
		return lstDocs;
	}
	
	/**
	 * Parses multiple json docs and returns a list of objects of type specified by class
	 * Method doesn't remove blob from result
	 * @param json - json response
	 * @param c - collection to fetch from
	 * @param cls - If a specific class needs to be cast to
	 * @return
	 */
	public static <T> T parseJSONDoc(String json, Class<T> cls) {
		//Strip off blob if present
		if(!json.equals("[]")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
				return parseJSON(j.get(0).getAsJsonObject(), cls);
		}else{
				return null;
		}
	}
	

	/** Parse a json which doesn't come as a array response
	 * Use with apis which return a count or a list
	 * @param json
	 * @param c
	 * @param cls
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T parseJSONBlobNoArray(String json, CollectionValues c,Class<T> cls) {

		//Strip off blob if present
		if(json.contains("_blob")){
			JsonParser jParser = new JsonParser();
			return (T) parseJSON(jParser.parse(json).getAsJsonObject().get("_blob").getAsJsonObject().get(c.getTypeOfObject()), cls);
		}else{
			return (T)parseJSON(json, c.getClassType());
		}
	}
	
	/**
	 * Parse a jsonelement to a class
	 * @param json
	 * @param cls
	 * @return
	 */
	public static <T> T parseJSON(JsonElement json,Class<T> cls) {
		Gson gson = new Gson();
		T returnVal = gson.fromJson(json, cls);
		
		return returnVal;
	}

	/**
	 * Returns jsonobject for root level nodes eg. _blob, _ft, _search
	 * @param json
	 * @param objectToFetch
	 * @return
	 */
	public static JsonObject parseJSONIndexes(String json, String objectToFetch) {
		
		//Strip off blob if present
		if(json.contains(objectToFetch)){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			return parseJSONSpecificObject(j.get(0), objectToFetch);
//			return  j.get(0).getAsJsonObject().get(objectToFetch).getAsJsonObject();
		}else{
			return null;
		}
	}
	
	/**
	 * Returns jsonobject for root level nodes eg. _blob, _ft, _search
	 * @param json
	 * @param objectToFetch
	 * @return
	 */
	public static JsonObject parseJSONSpecificObject(JsonElement json, String objectToFetch) {
		
		if(json.toString().contains("\""+objectToFetch+"\"")){
			JsonObject j = json.getAsJsonObject();
			return  j.get(objectToFetch).getAsJsonObject();
		}else{
			return null;
		}
	}

	/**
	 * Strips of blob from json response and processes the response for multiple objects
	 * Returns full apiresponse with meta and search fields
	 * If no value is returned then returns null
	 * @param json - json response to parse
	 * @param c - Collection to which value is mapped
	 * @param cls - Class to cast to
	 * @return List<Objects of type T>
	 */
	public static <T> List<APIResponse<T>> parseMultiResponseJSONWithBlob(String json, CollectionValues c,Class<T> cls) {
		///Strip off blob if present
		
		List<APIResponse<T>> lstOutput = new ArrayList<APIResponse<T>>();
		if(json.contains("_blob")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			for(int i=0; i< j.size(); i++){
				APIResponse<T> fullResponse = new APIResponse<T>();
				fullResponse.setFtFields(parseJSONSpecificObject(j.get(i), "_ft"));
				fullResponse.setSearchFields(parseJSONSpecificObject(j.get(i), "_search"));
				fullResponse.setMetaFields(parseJSONSpecificObject(j.get(i), "_meta"));
				fullResponse.setT((T) parseJSON(j.get(i).getAsJsonObject().get("_blob").getAsJsonObject().get(c.getTypeOfObject()), cls));
//				lstOutput.add((T) parseJSON(j.get(i).getAsJsonObject().get("_blob").getAsJsonObject().get(c.getTypeOfObject()), cls));
				lstOutput.add(fullResponse);
			}
			return lstOutput;
		}else{
			if(json.equals("[]"))
				return null;
//			lstOutput.add((T)parseJSON(json, c.getClassType()));
			return lstOutput;
		}
		
		
	}
	public static List<String> parseMultiResponseJSONWithBlobString(String json) {
		
		List<String> lstOutput = new ArrayList<String>();
		if(json.contains("_blob")){
			JsonParser jParser = new JsonParser();
			JsonArray j = jParser.parse(json).getAsJsonArray();
			for(int i=0; i< j.size(); i++){
				lstOutput.add(j.get(i).toString());
			}
			return lstOutput;
		}else{
			if(json.equals("[]"))
				return null;
			return lstOutput;
		}
	}
	
	public static <T> List<T> stringToArray(String s, Class<T[]> clazz) {
		try {
			T[] arr = new Gson().fromJson(s, clazz);
			return Arrays.asList(arr);
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
			return null;
		} 
	}
}
