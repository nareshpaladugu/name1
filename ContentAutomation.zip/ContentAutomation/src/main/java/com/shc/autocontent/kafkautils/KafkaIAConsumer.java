package com.shc.autocontent.kafkautils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;

import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.ConsumerTimeoutException;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

import com.shc.autocontent.ContentLogger;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;

public class KafkaIAConsumer<T> implements Runnable{
	
	private Properties props = new Properties();;
	private String topic;
	private BlockingQueue<List<T>> blockingQueue;
	private Class<T> classToTest ;
	private ConsumerConnector consumerConnector;
	public List<T> POISON_PILL ;
	ContentLogger logger = ContentLogger.getLogger();
	private static final String CONSUMERGROUPNAME = "Auto1";
	
	
	{
		props = new Properties();
		props.put("zookeeper.session.timeout.ms", "4000");
    	props.put("group.id", CONSUMERGROUPNAME);
    	props.put("zookeeper.sync.time.ms", "200");
		props.put("auto.commit.interval.ms", "1000");
		props.put("auto.offset.reset", "smallest");
		props.put("consumer.timeout.ms", LoadProperties.KAFKAREADTIMEOUT);
		
		props.put("zookeeper.connect", LoadProperties.ZOOKEEPER);
		topic = LoadProperties.KAFKATOPIC;
		
		
	}
	
	
	/**
	 * Constructor to be used if message read from Kafka queue needs to be parsed into an object before populating {@code bQueue}
	 * @param classToParseTo  - Class of object that needs to be generated from the message
	 * @param bQueue - Blocking queue in which read and converted objects need to be put
	 */
	 public KafkaIAConsumer(Class<T> classToParseTo, BlockingQueue<List<T>> bQueue){
			
	    	this(CONSUMERGROUPNAME, classToParseTo, bQueue);
	 }
	 
	 /**
		 * Constructor to be used if message read from Kafka queue needs to be parsed into an object before populating {@code bQueue}
		 * @param classToParseTo  - Class of object that needs to be generated from the message
		 * @param bQueue - Blocking queue in which read and converted objects need to be put
		 */
	 public KafkaIAConsumer(String consumerGroup,Class<T> classToParseTo, BlockingQueue<List<T>> bQueue){
		 		props.put("group.id", consumerGroup);
		 		props.put("fetch.message.max.bytes", "15728640");
		    	ConsumerConfig consumerConfig = new ConsumerConfig(props);
		    	consumerConnector = Consumer.createJavaConsumerConnector(consumerConfig);
		    	classToTest = classToParseTo;
		    	blockingQueue = bQueue;
		    	POISON_PILL = new ArrayList<T>();
		 }
	 
	 public KafkaIAConsumer(BlockingQueue<List<T>> bQueue){
			
	    	ConsumerConfig consumerConfig = new ConsumerConfig(props);
	    	consumerConnector = Consumer.createJavaConsumerConnector(consumerConfig);
	    	System.out.println("Connected");
	    	blockingQueue = bQueue;
	    	POISON_PILL = new ArrayList<T>();
	 }
	 
	 public KafkaIAConsumer(String consumerGroup, BlockingQueue<List<T>> bQueue){
	 		props.put("group.id", consumerGroup);
	    	ConsumerConfig consumerConfig = new ConsumerConfig(props);
	    	consumerConnector = Consumer.createJavaConsumerConnector(consumerConfig);
	    	System.out.println("Connected");
	    	blockingQueue = bQueue;
	    	POISON_PILL = new ArrayList<T>();
	 }
	 
	 public void run(){
		 
	    	Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
			topicCountMap.put(topic, new Integer(1));
			System.out.println("Topic is "+topic);
			Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumerConnector.createMessageStreams(topicCountMap);
			List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);
	    	int iMessagesRead =  0;
	    	// consume the messages in the threads
			try{
				for (final KafkaStream<byte[], byte[]> stream : streams) {
					System.out.println("Kafka stream list in open method");
					
					ConsumerIterator<byte[], byte[]> it = stream.iterator();
					
					while (it.hasNext()){
						
						String msg = new String(it.next().message(),"UTF-8");
						iMessagesRead++;
						System.out.println("Message resceived "+ msg);
						if(classToTest != null){
							if(msg.startsWith("[")){
								blockingQueue.put(JSONParser.parseJSONDocs(msg,classToTest));
							}else{
								List<T> toPut = new ArrayList<T>();
								try{
									toPut.add(JSONParser.parseJSON(msg, classToTest));
								}catch(Exception e){
									e.printStackTrace();
									logger.warning("Error on parsing "+ msg);
									//continue reading next message
									continue;
								}
								blockingQueue.put(toPut);
							}
						
						}
						//To put messages as they come instead of parsing and converting to class
						else{
							//TODO :: To see if multiple messages come
							List<T> lstDocs = new ArrayList<T>();
							lstDocs.add((T) msg);
							blockingQueue.put(lstDocs);
						}
						
						if(LoadProperties.TESTDATALIMIT > 0  && iMessagesRead == LoadProperties.TESTDATALIMIT){
							shutdownConsumer();
							break;
						}
						
					}
				}
			}
			catch(ConsumerTimeoutException e){
					shutdownConsumer();
					
			} catch (InterruptedException e) {
					e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			catch (IllegalStateException e) {
				e.printStackTrace();
				shutdownConsumer();
				
			}
			
				System.out.println("Out of here");
				
				
			
	 }
	 
	 private void shutdownConsumer(){
		 consumerConnector.shutdown();
			try {
				blockingQueue.put(POISON_PILL);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	 }
	
}

