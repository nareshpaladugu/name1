package com.shc.autocontent.parsers;

/**
 * Class to create chunks of xml to feed to castor unmarshaller
 * @author nvarsh0
 *
 */
public interface XMLChunker {

	public <T> T unmarshalXML(Class<T> c);
	
	public <T> T unmarshalXML(Class<T> c, String sNodeName);

	public void setCutOffNode(String sCutOffNode);
	
	
}
