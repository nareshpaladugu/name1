package com.shc.autocontent.utils;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.shc.autocontent.LoadProperties;
import com.shc.content.listeners.ExcelReportListener;


public class GenericUtil {

	/*public static String getTime()
	{
		return (new Date().getHours()+":"+new Date().getMinutes()+":"+new Date().getSeconds());
	}*/
	/**
	 * Rounds double value
	 * @param val
	 * @return
	 */
	public static double roundToTwoDigit(double val)
	{
		DecimalFormat format_2Places = new DecimalFormat("0.00");

		return Double.valueOf(format_2Places.format(val));
	}
	/**
	 * Removes SPM from product ID
	 * @param productId
	 * @return
	 */
	public static String removeSPMFromProductId(String productId)
	{
		return productId.replaceFirst("SPM", "");
	}

	/**
	 * Adds SPM prefix to product id
	 * @param productId
	 * @return
	 */
	public static String addSPMPrefixToProductId(String productId)
	{
		return "SPM"+productId;
	}


	/**
	 * Removes specified part of product id
	 * @param productId
	 * @param partToRemove
	 * @return
	 */
	public static String removeProductIdPart(String productId,String partToRemove)
	{
		return productId.replaceAll(partToRemove, "");
	}

	public static boolean isValidPartNumber(String partNumber)
	{
		if(partNumber==null || partNumber.isEmpty()|| partNumber.equals("SPM"))
		{
			return false;
		}
		return true;
	}


	public static boolean isExcluded(String attr)
	{
		if(attr == null || attr.equalsIgnoreCase("false"))
		{
			return false;
		}
		else if(attr.equalsIgnoreCase("true"))
		{
			return true;
		}

		return false;
	}

	/**
	 * generates html mail body content when no data found for selected filter
	 * @return
	 */
	public static String getActualBodyTextForNoData()
	{

		String table_criteria = prepareCriteriaTable();

		String sMailBodyTextSummary =  "<font face='Calibri' color='black' size='2'>" +
				"<B>***NOTE: This is an auto generated mail.***<br><br>" +
				"<span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;' color='red'>"
				+(LoadProperties.getCustomMsgForEmail() == null?"No data found for selected filters.":LoadProperties.getCustomMsgForEmail())+"<br>"

				+"<span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;'>" 
				+table_criteria+
				"</font>";;

				return sMailBodyTextSummary + "</font><font face='Calibri' color='black' size='2'><B></br></br>Regards, <br><br>Content Automation<br>";
	}

	/**
	 * Generates html mail body content for pass/fail case
	 * @param passcount
	 * @param failcount
	 * @return
	 */
	public static String getActualBodyText(int passcount,int failcount,String failedFields, String timeinMin,String dateAndTime)
	{
		/*	String lstFiles = "";
		String sWCSDB = "", sPricingGrid = "", sSite = "";*/

		/*if(!LoadProperties.SITE_NAME.isEmpty()){
			sSite = "<br>Site : "+LoadProperties.SITE_NAME +"</br>";
		}

		if(LoadProperties.LST_FILES != "")
			lstFiles = "List of files tested : "+LoadProperties.LST_FILES_FOLDER+LoadProperties.LST_FILES;
		if(LoadProperties.IS_LISTBASED_RUN)
			lstFiles = "List :"+ LoadProperties.RUN_PARAMS;
		if(LoadProperties.IS_BUCKETBASED_RUN)
			lstFiles = "Bucket No(s). : "+ LoadProperties.RUN_PARAMS;
		String sGreenvip = "GBDetail : "+LoadProperties.GREENVIP;
		if(!LoadProperties.db2databasename.isEmpty())
			sWCSDB = "<br>WCS DB : "+LoadProperties.db2databasename +"</br>";

		if(!LoadProperties.PRICING_GRID_URL.isEmpty()){
			sPricingGrid = "<br>Pricing Grid : "+LoadProperties.PRICING_GRID_URL +"</br>";
		}*/




		String table_criteria = prepareCriteriaTable();


		String sMailBodyTextSummary =  "<font face='Calibri' color='black' size='2'><B>***NOTE: This is an auto generated mail.***<br>" +
				(LoadProperties.getCustomMsgForEmail()==null?"":(LoadProperties.getCustomMsgForEmail()+"<br>"))+
				"<span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;'>" 
				+table_criteria+
				"</font>";

		sMailBodyTextSummary +=
				"<H3> Result : <H3>"+"<font face='Calibri' color='black' size='3'>"+
						"<TABLE>" +
						"	<TR align='center'>" +
						"		<TD rowspan='2'>" +
						"			<TABLE cellspacing='2' cellpadding='1' border='1' BORDERCOLOR='#4f81bd' align='left' ><col width='160px'><col width='160px'>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='green' size='2'><B>Total PASSED Tests</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='green' size='2'><B>"	+ passcount+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>Total FAILED Tests</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>"+ failcount+ "</DIV>" +
						"			</TR>"+ 
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>Failed Fields</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ failedFields+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>IgnoredFailures</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ LoadProperties.IGNORED_FAILURES+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>Execution time(hh:mm:ss)</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ timeinMin+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>Date-Time of report creation</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"+ dateAndTime+ "</DIV>" +
						"			</TR>";

		//Add Build console log
		if(System.getProperty("BUILD_USER") != null)
			sMailBodyTextSummary =sMailBodyTextSummary + getTestResultRow("Triggerred by", System.getProperty("BUILD_USER"));
		
		if(System.getenv("BUILD_URL") != null)
			sMailBodyTextSummary =sMailBodyTextSummary + getTestResultRow("Console Log", "<a href="+System.getenv("BUILD_URL")+"/console>Log link</a>");
		
		
		if(ExcelReportListener.getTotalFileCount()>1)
		{
			sMailBodyTextSummary =sMailBodyTextSummary+"			<TR>" +
					"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>No. of result files</DIV>" +
					"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"+ ExcelReportListener.getTotalFileCount()+
					" <a href="+System.getenv("BUILD_URL")+">See all reports</a>"+"</DIV>" +
					"			</TR>";
		}


		sMailBodyTextSummary =sMailBodyTextSummary+"			</TABLE>" +
				"		</TD></TR></TABLE></BR>" ;


		/*

						"			</TABLE>" +
						"		</TD></TR></TABLE></BR>" ;
		 */


		return sMailBodyTextSummary + "<br>Please refer attached file containing test execution report.<br><font face='Calibri' color='black' size='2'><B></br>Regards, <br>Content Automation<br>";
	}
	
	private static String getTestResultRow(String leftString, String valueString){
		return "			<TR>" +
				"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"+leftString+"</DIV>" +
				"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"+ valueString+"</DIV>" +
				"			</TR>";
	}

	private static String prepareCriteriaTable(){

		List<List<String>> tableData = new ArrayList<List<String>>();
		List<String> header = new ArrayList<String>();
		header.add("Criteria/input field");
		header.add("Value specified");
		tableData.add(header);

		List<String> row = new ArrayList<String>();


		if(!LoadProperties.EXECUTION_MODE.isEmpty())
		{
			row = new ArrayList<String>();
			row.add("Execution Mode");
			row.add(LoadProperties.EXECUTION_MODE);
			tableData.add(row);
		}

		if(!LoadProperties.RUN_PARAMS.isEmpty())
		{
			row = new ArrayList<String>();
			row.add("Run Parameters");
			row.add(LoadProperties.RUN_PARAMS);
			tableData.add(row);
		}

		if(!LoadProperties.SITE_NAME.isEmpty())
		{
			row = new ArrayList<String>();
			row.add("Site ");
			row.add(LoadProperties.SITE_NAME);
			tableData.add(row);
		}

		if(!LoadProperties.LST_FILES.isEmpty()){
			row = new ArrayList<String>();
			row.add("List of files tested");
			row.add(LoadProperties.LST_FILES_FOLDER+LoadProperties.LST_FILES);
			tableData.add(row);
		}

		if(!LoadProperties.GREENVIP.isEmpty()){
			row = new ArrayList<String>();
			row.add("GreenBox");
			row.add(LoadProperties.GREENVIP);
			tableData.add(row);
		}

		if(!LoadProperties.OTHERGBBOX.isEmpty()){
			row = new ArrayList<String>();
			row.add("Other GB Details");
			row.add(LoadProperties.OTHERGBBOX);
			tableData.add(row);
		}


		if(!LoadProperties.db2databasename.isEmpty()){
			row = new ArrayList<String>();
			row.add("WCS DB");
			row.add(LoadProperties.db2databasename);
			tableData.add(row);
		}

		if(!LoadProperties.PRICING_GRID_URL.isEmpty())
		{
			row = new ArrayList<String>();
			row.add("Pricing Grid");
			row.add(LoadProperties.PRICING_GRID_URL);
			tableData.add(row);
		}

		if(!LoadProperties.FROM_TIME.isEmpty()){
			row = new ArrayList<String>();
			row.add("From Time Stamp ");
			row.add(LoadProperties.FROM_TIME);
			tableData.add(row);
		}

		if(!LoadProperties.TO_TIME.isEmpty()){
			row = new ArrayList<String>();
			row.add("To Time Stamp ");
			row.add(LoadProperties.TO_TIME);
			tableData.add(row);
		}

		if(!LoadProperties.KAFKATOPIC.isEmpty()){
			row = new ArrayList<String>();
			row.add("Kafka Topic ");
			row.add(LoadProperties.KAFKATOPIC);
			tableData.add(row);
		}

		if(!LoadProperties.IA_SERVER.isEmpty()){
			row = new ArrayList<String>();
			row.add("IA Server");
			row.add(LoadProperties.IA_SERVER);
			tableData.add(row);
		}

		if(!LoadProperties.MATCHING_SERVER.isEmpty()){
			row = new ArrayList<String>();
			row.add("Matching Server");
			row.add(LoadProperties.MATCHING_SERVER);
			tableData.add(row);
		}

		row = new ArrayList<String>();
		row.add("Test Data Limit");
		row.add(LoadProperties.TESTDATALIMIT+"");
		tableData.add(row);

		String table_criteria = "<H3> Input Data/Criteria : <H3>"+EmailUtils.prepareCustomTableUsingList(tableData);
		return table_criteria;
	}


	public static String getActualBodyText_OLD_AS_IT_IS(int passcount,int failcount,String failedFields, String timeinMin,String dateAndTime)
	{
		String lstFiles = "";
		String sWCSDB = "", sPricingGrid = "", sSite = "";

		if(!LoadProperties.SITE_NAME.isEmpty()){
			sSite = "<br>Site : "+LoadProperties.SITE_NAME +"</br>";
		}

		if(LoadProperties.LST_FILES != "")
			lstFiles = "List of files tested : "+LoadProperties.LST_FILES_FOLDER+LoadProperties.LST_FILES;
		if(LoadProperties.IS_LISTBASED_RUN)
			lstFiles = "List :"+ LoadProperties.RUN_PARAMS;
		if(LoadProperties.IS_BUCKETBASED_RUN)
			lstFiles = "Bucket No(s). : "+ LoadProperties.RUN_PARAMS;
		String sGreenvip = "GBDetail : "+LoadProperties.GREENVIP;
		if(!LoadProperties.db2databasename.isEmpty())
			sWCSDB = "<br>WCS DB : "+LoadProperties.db2databasename +"</br>";

		if(!LoadProperties.PRICING_GRID_URL.isEmpty()){
			sPricingGrid = "<br>Pricing Grid : "+LoadProperties.PRICING_GRID_URL +"</br>";
		}
		String sMailBodyTextSummary =  "<font face='Calibri' color='black' size='2'><B>***NOTE: This is an auto generated mail.***<br><span style='font-family:Calibri, Arial; font-size:1em; font-weight:bold;'>" 
				+sSite+"<br>"+lstFiles+"</br><br>"+sGreenvip+"</br>"+sPricingGrid+sWCSDB+
				"</font>";



		sMailBodyTextSummary +=
				"<font face='Calibri' color='black' size='3'>"+
						"<BR><BR><TABLE>" +
						"	<TR align='center'>" +
						"		<TD rowspan='2'>" +
						"			<TABLE cellspacing='2' cellpadding='1' border='1' BORDERCOLOR='#4f81bd' align='left' ><col width='160px'><col width='160px'>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='green' size='2'><B>Total PASSED Tests</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='green' size='2'><B>"	+ passcount+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>Total FAILED Tests</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>"+ failcount+ "</DIV>" +
						"			</TR>"+ 
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>Failed Fields</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ failedFields+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='red' size='2'><B>IgnoredFailures</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ LoadProperties.IGNORED_FAILURES+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>Execution time(hh:mm:ss)</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"	+ timeinMin+ "</DIV>" +
						"			</TR>" +
						"			<TR>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>Date-Time of report creation</DIV>" +
						"				<TD><DIV style='text-align:left'><font face='Calibri' color='black' size='2'><B>"+ dateAndTime+ "</DIV>" +
						"			</TR>"+ 


						"			</TABLE>" +
						"		</TD></TR></TABLE></BR>" ;



		return sMailBodyTextSummary + "<br>Please refer attached file containing test execution report.<br><font face='Calibri' color='black' size='2'><B></br>Regards, <br>Content Automation<br>";
	}

	/**
	 * Returns file size in MB
	 * @param fileName
	 * @return
	 */
	public static long getFileSizeInMb(String fileName)
	{
		try {
			return (new File(fileName).length()/(1024*1024));
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * Returns file size in MB
	 * @param fileName
	 * @return
	 */
	public static long getFileSizeInMb(File file)
	{
		try {
			return (file.length()/(1024*1024));
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * Get intvalue for long and double values
	 * @param d
	 * @return
	 */
	public static Integer convertToIntFromDouble(Object d){
		if(d == null)
			return null;
		else{
			if(d instanceof Long )
				return ((Long)d).intValue();
			else if(d instanceof Double)
				return ((Double)d).intValue();
			else 
				return null;
		}
	}

	/**
	 * Converts any object to string value
	 * @param d
	 * @return
	 */
	public static String convertToString(Object d){
		if(d == null)
			return null;
		else{
			if(d instanceof Long )
				return String.valueOf(((Long)d).intValue());
			else if(d instanceof Double)
				return String.valueOf(((Double)d).intValue());
			else 
				return d.toString();
		}
	}
	
	/**
	 * Method to get random number within specified range
	 * @param min - lower limit of range
	 * @param max - upper limit of range
	 * @return
	 */
	public static int getRandomNumberInRange(Integer min, Integer max) {
		Random random = new Random();
		return random.nextInt((max - min) + 1) + min;
	}
}
