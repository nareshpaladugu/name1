package com.shc.autocontent.parsers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.JsonElement;
import com.shc.content.listeners.SuiteListener;

public class JsonStringParser {

	public static long HIERARCHY_COUNT = 1000;
	public static String REGEX_ARRAY_START = "[";
	public static String REGEX_ARRAY_END = "]";
	public static String REGEX_OBJECT_START = "{";
	public static String REGEX_OBJECT_END = "}";
	public static String REGEX_DELIMITER = "|";
	public static String REGEX_JSON_WRAPPER = "\"";


	private static boolean contains(String hierarchy) {
		return hierarchy == null ? false : hierarchy.contains(REGEX_ARRAY_START) || hierarchy.contains(REGEX_OBJECT_START);
	}


	/**
	 * This method cleans the json value
	 * 
	 * @param value
	 * @return
	 */
	public static String clean(String value,Boolean... booleans) {


		//TODO - need to check backword compatibility for clean method,
		//for now returning same value
		/*if(true)
			return value==null?"":value;*/

		boolean trimFlag = true;

		if(booleans.length!=0)
		{
			trimFlag = booleans[0];
		}
		if (value != null) {

			if (value.startsWith(REGEX_JSON_WRAPPER)) {
				value = value.substring(value.indexOf(REGEX_JSON_WRAPPER) + 1);
				if (value.endsWith(REGEX_JSON_WRAPPER)) {
					if(trimFlag)
						value = value.substring(0, value.lastIndexOf(REGEX_JSON_WRAPPER)).trim();
					else
						value = value.substring(0, value.lastIndexOf(REGEX_JSON_WRAPPER));

				}
			}

			//Changes made to handle " in JSON
			/*if (value.contains("\"")) {
				if(trimFlag)
					value = value.replace("\\\"", "\"").trim();
				else
					value = value.replace("\\\"", "\"");
			}*/

			value = value.replaceAll("\\},\\{", "},\n{");

			return value;
		}
		else

		{
			return "";
		}
	}


	public static String getArrayHierarchy(String hierarchy) {
		return hierarchy == null ? null : hierarchy.substring(hierarchy.indexOf(REGEX_ARRAY_START) + 1, hierarchy.lastIndexOf(REGEX_ARRAY_END));
	}

	public static String getObjectHierarchy(String hierarchy) {
		return hierarchy == null ? null : hierarchy.substring(hierarchy.indexOf(REGEX_OBJECT_START) + 1, hierarchy.lastIndexOf(REGEX_OBJECT_END));
	}


	public static String getJsonKey(String hierarchy) {
		String key = null;
		if (hierarchy != null) {
			key = "";
			for (int i = 0; i < hierarchy.length(); i++) {
				if (hierarchy.charAt(i) == REGEX_ARRAY_START.charAt(0) || hierarchy.charAt(i) == REGEX_OBJECT_START.charAt(0)) {
					break;
				} else {
					key = key.concat(hierarchy.substring(i, i + 1));
				}
			}
		}
		return key;
	}

	private static boolean isArray(String hierarchy) {
		return hierarchy == null ? false : hierarchy.trim().startsWith(REGEX_ARRAY_START);
	}

	private static  boolean isObject(String hierarchy) {
		return hierarchy == null ? false : hierarchy.trim().startsWith(REGEX_OBJECT_START);
	}

	public static String clean(String actaulValueGb)
	{
		if(actaulValueGb!=null && actaulValueGb.startsWith("\"") && actaulValueGb.endsWith("\""))
			actaulValueGb = actaulValueGb.substring(1, actaulValueGb.length()-1);

		return actaulValueGb;

	}


	public static String getJsonValueNew(String sResponse, String pattern,Boolean... clean)
	{
		String[] splittedPattern = pattern.split("\\.");

		List<String> responces = new ArrayList<String>();

		List<String> tempResponces = new ArrayList<String>();

		responces.add(sResponse);

		int index = -1;

		for (String sCurrentJsonTag : splittedPattern) {

			tempResponces = new ArrayList<String>();

			for (String sCurrentJsonResponse : responces) {

				if(isJsonArray(sCurrentJsonResponse))
				{
					List<String> resps = Json.getStringArrayList(sCurrentJsonResponse);

					if(index==-1)
					{
						for (String string2 : resps) {
							JsonElement jsonEle = Json.getJsonElement(string2).getAsJsonObject().get(sCurrentJsonTag);
							tempResponces.add(jsonEle == null?"null":jsonEle.toString());

//							tempResponces.add(Json.getJsonElement(string2).getAsJsonObject().get(sCurrentJsonTag).toString());
						}
					}
					else
					{
						tempResponces.add(Json.getJsonElement(resps.get(index)).getAsJsonObject().get(sCurrentJsonTag).toString());
						index =  -1;
					}
				}
				else if(isJsonObject(sCurrentJsonResponse))
				{
					if(sCurrentJsonTag.contains("["))
					{
						index = Integer.parseInt(sCurrentJsonTag.substring(sCurrentJsonTag.indexOf("[")+1,sCurrentJsonTag.indexOf("]")));

						//						System.out.println(index);

						sCurrentJsonTag = sCurrentJsonTag.substring(0,sCurrentJsonTag.indexOf("["));

					}
					else
					{
						index = -1;
					}
					JsonElement jsonEle = Json.getJsonElement(sCurrentJsonResponse).getAsJsonObject().get(sCurrentJsonTag);
					tempResponces.add(jsonEle == null?"null":jsonEle.toString());
				}
			}

			responces.clear();
			responces.addAll(tempResponces);
		}

		String output=null;

		for (String string : responces) {

			if(output==null)
			{
				output=string;
			}
			else
			{
				output=output+";"+string;
			}
		}

		if(clean.length>=1)
			return clean(output);
		else
			return output;
	}

	public static boolean isJsonArray(String response)
	{
		return Json.getJsonElement(response).isJsonArray();
	}

	public static boolean isJsonObject(String response)
	{
		return Json.getJsonElement(response).isJsonObject();
	}

	public static boolean isJsonPrimitive(String response)
	{
		return Json.getJsonElement(response).isJsonPrimitive();
	}

	public static String getJsonValue(String response, String pattern,String sDelim ,Boolean... booleans )
	{
		String value = getJsonValue(response,pattern,booleans);

		if(value==null)
		{
			return null;
		}

		else return value.replaceAll("@D@", sDelim);
	}


	public static String getJsonValue(String response, String pattern,Boolean... booleans )
	{

		long start = System.currentTimeMillis();


		String actuKey = null;

		List<String> values = new LinkedList<String>();

		List<String> elementMap = new LinkedList<String>();

		List<String> elementMapTemp = new LinkedList<String>();

		/* ============ Initial response ==========*/

		elementMap.add(response);

		boolean loop = true;

		int limit = 0;

		try 
		{
			while (loop) 
			{
				++limit;

				if (isArray(pattern)) 
				{
					/* ==================  Handle array part ================== */
					pattern = getArrayHierarchy(pattern);

					elementMapTemp = new LinkedList<String>();

					for (Iterator<String> iterator = elementMap.iterator(); iterator.hasNext();)
					{
						String string = (String) iterator.next();

						List<String> array = Json.getStringArrayList(string);

						for (Iterator<String> it = array.iterator(); it.hasNext();) 
						{

							String jsonResp = it.next();
							elementMapTemp.add(jsonResp);

						}
					}

					elementMap.clear();
					elementMap.addAll(elementMapTemp);

				} else if (isObject(pattern)) 
				{
					pattern = getObjectHierarchy(pattern);


					elementMapTemp = new LinkedList<String>();

					for (Iterator<String> iterator = elementMap.iterator(); iterator.hasNext();)
					{
						String string = (String) iterator.next();

						try {
							elementMapTemp.add(Json.getJsonObject(string).toString());
						} catch (Exception e) {

							List<String> array = Json.getStringArrayList(string);
							for (Iterator<String> iterator2 = array.iterator(); iterator2
									.hasNext();) {
								String string2 = iterator2.next();
								elementMapTemp.add(string2);
							}
							//System.out.println("Exception : Actually got array and expecting object : "+e.getMessage());
						}
					}

					elementMap.clear();
					elementMap.addAll(elementMapTemp);


				} else 
				{
					String key = null;


					loop = contains(pattern);
					if (loop) {

						actuKey = key = getJsonKey(pattern);

						if(key.contains("."))
						{
							handleDot(key, elementMap, elementMapTemp, values,1);
						}
						else
						{
							elementMapTemp =  new LinkedList<String>();

							for (Iterator<String> iterator = elementMap.iterator(); iterator.hasNext();) {
								String string = (String) iterator.next();

								try {
									elementMapTemp.add(Json.get(string, actuKey));
								} catch (Exception e) {

									//System.out.println("Exception plz see "+e.getMessage());
								}
							}

							elementMap.clear();
							elementMap.addAll(elementMapTemp);

						}
						pattern = pattern.replaceFirst(key, "");

					} else 
					{
						if(pattern.contains("."))
						{
							handleDot(pattern, elementMap, elementMapTemp, values,0);
						}
						else
						{
							for (Iterator<String> iterator = elementMap.iterator(); iterator.hasNext();) {
								String string = (String) iterator.next();
								try {
									values.add(clean(Json.get(string, pattern),booleans));
								} catch (Exception e) {
									//System.out.println("Exception : Need to handle this."+e.getMessage());
								}
							}
						}
					}
				}
				if (limit == HIERARCHY_COUNT) {
					loop = false;
				}
			}

		} catch (Exception e) {
			throw e;
		}

		int ii = 0;
		StringBuffer buffer = new StringBuffer();
		for (Iterator<String> iterator = values.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();

			if(ii==0)
			{
				buffer = buffer.append(string);
				ii++;
			}
			else
			{
				buffer = buffer.append("@D@").append(string);
			}
		}
		if(ii==0)
		{
			return null;
		}

		SuiteListener.jsonTimer+=System.currentTimeMillis() - start;
		return buffer.toString();
	}



	/**
	 * This method handles array part with index e.g. field.ALL or field.2
	 * @param pattern
	 * @param elementMap
	 * @param elementMapTemp
	 * @param values
	 * @param keyFlag
	 */
	public static void handleDot(String pattern,List<String> elementMap ,List<String> elementMapTemp,List<String> values,int keyFlag,Boolean... booleans)
	{

		String actuKey = null;

		String indx ="";

		/* ==============  This is array ============== */

		actuKey=pattern.split("\\.")[0];
		indx=pattern.split("\\.")[1];

		elementMapTemp = new LinkedList<String>();

		for (Iterator<String> iterator = elementMap.iterator(); iterator.hasNext();)
		{
			String string = (String) iterator.next();
			if(actuKey==null)
			{
				continue;
			}
			List<String> array = Json.getStringArrayList(Json.get(string, actuKey));

			if(indx.equals("ALL"))
			{
				for (Iterator<String> it = array.iterator(); it.hasNext();) 
				{

					String jsonResp = it.next();

					if(keyFlag==1)
					{
						elementMapTemp.add(jsonResp);
					}
					else
					{
						values.add(clean(jsonResp,booleans));
					}
				}
			}
			else
			{
				if(keyFlag==1)
				{
					try {
						elementMapTemp.add(array.get(Integer.parseInt(indx)));
					} catch (Exception e) {
						//System.out.println("Exception302 : Please also check this "+e.getMessage());
					}
				}
				else
				{
					try {
						values.add(clean(array.get(Integer.parseInt(indx)),booleans));
					} catch (Exception e) {
						System.out.println("Exception502 : Please also check this "+e.getMessage());
					}
				}
			}
		}

		elementMap.clear();
		elementMap.addAll(elementMapTemp);

	}
}
