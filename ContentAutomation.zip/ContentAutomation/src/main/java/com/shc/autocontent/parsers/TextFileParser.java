package com.shc.autocontent.parsers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

/**
 * 
 * @author Niharika Varshney
 * File Parser to read normal files.
 * Reads each line in the file. 
 * Parses based on logic specified by {@link com.shc.autocontent.parsers.FileParser FileParser} implementation
 * If no implementing class is passed, returns line as is.
 * @param <T>
 */
public class TextFileParser<T> implements Runnable {

	
	private BlockingQueue<List<T>> blockingQueue;
	private BlockingQueue<String> blockingQueueSingleString;
	public List<T> POISON_PILL ;
	public String POISON_PILL_STRING ;
	private FileParser<T> fParser;
	private String fileName;
	
	public TextFileParser(String sFileName, BlockingQueue<List<T>> queueLstVOs, FileParser<T> parseLogic) {
	
		this.fileName = sFileName;
		this.blockingQueue = queueLstVOs;
		POISON_PILL = new ArrayList<T>();;
		this.fParser = parseLogic;
		
	}
	
	public TextFileParser(String sFileName, BlockingQueue<String> queueLstVOs) {
		
		this.fileName = sFileName;
		this.blockingQueueSingleString = queueLstVOs;
		POISON_PILL_STRING = new String("Poison Pill");
		
	}
	
	public void readFileBufferedReader(FileParser<T> customParser) throws IOException {
		FileReader file = new FileReader(fileName);
		BufferedReader br = new BufferedReader(file);
		String scannedLine;
		try {
			while (!((scannedLine = br.readLine()) ==null)) {
	
				// process each line in some way
				List<T> lstOutputToSend;
				lstOutputToSend = customParser.parseLine(scannedLine);
				if (lstOutputToSend != null) {
						this.blockingQueue.put(lstOutputToSend);
				} 
			}

		
			if(customParser.getCurrentOutput().size() > 0){
					this.blockingQueue.put(fParser.getCurrentOutput());
			}
			this.blockingQueue.put(POISON_PILL);
			System.out.println("Putting poison pill");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		br.close();
	}
	
	/**
	 * Read each line of file and put in blocking queue
	 * @throws IOException
	 */
	public void readFileBufferedReader() throws IOException {
		FileReader file = new FileReader(fileName);
		BufferedReader br = new BufferedReader(file);
		String scan;
		try {
			while (!((scan = br.readLine()) ==null)) {
	
				//No parsing involved, read and put
					this.blockingQueueSingleString.put(scan);
			}

		
			this.blockingQueueSingleString.put(POISON_PILL_STRING);
			System.out.println("Putting poison pill");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		br.close();
	}

	@Override
	public void run() {
		try {
			//If custom parser is provided, use the parser, else read and put in String queue
			if(fParser != null)
				this.readFileBufferedReader(fParser);
			else
				this.readFileBufferedReader();
		} catch (IOException e) {
			e.printStackTrace();
			try {
				if(fParser == null)
					this.blockingQueueSingleString.put(POISON_PILL_STRING);
				else
					this.blockingQueue.put(POISON_PILL);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}

}
