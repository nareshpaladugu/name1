package com.shc.autocontent.db;

public class CollectionValues {

	private final String sTypeOfObject;
	private final String sCollection;
	private final Class classType;

	public CollectionValues(String sCollection, String sType, Class classType) {
		this.sTypeOfObject = sType;
		this.sCollection = sCollection;
		this.classType=classType;
	}

	public String getTypeOfObject() {
		return sTypeOfObject;
	}

	public String getCollection() {
		return sCollection;
	}
	
	public Class getClassType() {
		return classType;
	}
}
