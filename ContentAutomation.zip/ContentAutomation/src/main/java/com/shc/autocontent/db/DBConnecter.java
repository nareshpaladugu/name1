package com.shc.autocontent.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.shc.autocontent.LoadProperties;
/**
 * 
 * Class to connect to MySql or WCSDB
 * 
 * @author Niharika Varshney
 * 
 * 
 */
public class DBConnecter {

	private static Connection connection = null;
	
	private final static String MYSQL = "mysql";
	
	static{
		String dbType ="";
		if(LoadProperties.db2jdbcClass.contains(MYSQL))
			dbType = MYSQL;

		String db2url="jdbc:"+dbType+"://"+LoadProperties.db2server+":"+LoadProperties.db2port+"/"+LoadProperties.db2databasename;
		try {
			Class.forName(LoadProperties.db2jdbcClass);
			connection = DriverManager.getConnection(db2url, LoadProperties.db2user, LoadProperties.db2password);

		} catch (Exception e) {
			e.printStackTrace();
			throw new DBException("Error in connecting to "+ db2url,e.getCause());
		}
	}

	/**
	 * Returns a singleton connection object to execute queries to wcs db
	 * @return
	 */
	public static Connection getConnection()
	{
			return connection;
	}
	
	
	
	



	public static void disconnect() {
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println("Error closing connection");
			e.printStackTrace();
		}
	}
	
	
	

}