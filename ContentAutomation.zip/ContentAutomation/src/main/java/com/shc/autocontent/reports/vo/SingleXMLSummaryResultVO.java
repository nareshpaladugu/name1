package com.shc.autocontent.reports.vo;

public class SingleXMLSummaryResultVO {

	//Xml Name	Total Item Count	Item with mismatch	Status
	private String xmlName;
	private int itemCount;
	public String getXmlName() {
		return xmlName;
	}
	public void setXmlName(String xmlName) {
		this.xmlName = xmlName;
	}
	public int getItemCount() {
		return itemCount;
	}
	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}
	public int getItemWithMismatch() {
		return itemWithMismatch;
	}
	public void setItemWithMismatch(int itemWithMismatch) {
		this.itemWithMismatch = itemWithMismatch;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	private int itemWithMismatch;
	private String Status;
	
}
