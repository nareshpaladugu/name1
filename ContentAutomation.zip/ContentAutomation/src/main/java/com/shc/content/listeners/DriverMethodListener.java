package com.shc.content.listeners;

import java.io.File;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestResult;

import com.shc.autocontent.LoadProperties;
import com.shc.content.webdriver.DriverInitializer;
import com.shc.content.webdriver.GridLauncher;
import com.shc.content.webdriver.assertions.DriverLogger;

/**
 * 
 * Listener to start grid if it is local run
 * @author Niharika Varshney
 *
 */
public class DriverMethodListener implements  IInvokedMethodListener, ISuiteListener {

	/**
	 * Instantiate the driver class
	 */
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		
		if(!(DriverInitializer.getThreadLocalWebDriver().get() == null))
			return;

		
		
		if(!LoadProperties.INITURL.isEmpty()){
			DriverInitializer.driver().get(LoadProperties.INITURL);
			DriverInitializer.driver().manage().window().maximize();
		}
	}
	
	
	/**
	 * Cleanup the driver instance and log messages
	 */
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		
		if(!method.isTestMethod())
			return;
		
		if(!testResult.isSuccess()){
			DriverLogger logger = new DriverLogger();
			logger.logFailed(ExceptionUtils.getRootCauseMessage(testResult.getThrowable()));
		}
		DriverInitializer.driver().quit();
		DriverInitializer.disconnect();
		
		
		
	}

	@Override
	public void onStart(ISuite suite) {
		if(LoadProperties.ISLOCALRUN)
			GridLauncher.setupLocalGrid();
		File file = new File(suite.getOutputDirectory());
		LoadProperties.OUTPUTFOLDER = file.getParent();
		
	}

	@Override
	public void onFinish(ISuite suite) {

		if(LoadProperties.ISLOCALRUN)
			GridLauncher.shutdownGrid();
		
	}

	
	
}
