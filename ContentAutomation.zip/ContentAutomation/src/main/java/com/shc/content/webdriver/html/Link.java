package com.shc.content.webdriver.html;

public class Link extends AbstractBaseElement{

	public Link(String locator, String elementName) {
		super(locator, elementName);
	}
	

}
