package com.shc.content.entity;

public class AttrKey {
	
	private String itemClassId;
	private Long attrId;
	private Long attrValueId;
	
	
	
	public AttrKey(String itemClassId, Long attrId, Long attrValueId) {
		super();
		this.itemClassId = itemClassId;
		this.attrId = attrId;
		this.attrValueId = attrValueId;
	}
	
	public AttrKey() {
		super();
	}

	public String getItemClassId() {
		return itemClassId;
	}
	public void setItemClassId(String itemClassId) {
		this.itemClassId = itemClassId;
	}
	public Long getAttrId() {
		return attrId;
	}
	public void setAttrId(Long attrId) {
		this.attrId = attrId;
	}
	public Long getAttrValueId() {
		return attrValueId;
	}
	public void setAttrValueId(Long attrValueId) {
		this.attrValueId = attrValueId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((attrId == null) ? 0 : attrId.hashCode());
		result = prime * result + ((attrValueId == null) ? 0 : attrValueId.hashCode());
		result = prime * result + ((itemClassId == null) ? 0 : itemClassId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AttrKey other = (AttrKey) obj;
		if (attrId == null) {
			if (other.attrId != null)
				return false;
		} else if (!attrId.equals(other.attrId))
			return false;
		if (attrValueId == null) {
			if (other.attrValueId != null)
				return false;
		} else if (!attrValueId.equals(other.attrValueId))
			return false;
		if (itemClassId == null) {
			if (other.itemClassId != null)
				return false;
		} else if (!itemClassId.equals(other.itemClassId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AttrKey [itemClassId=" + itemClassId + ", attrId=" + attrId + ", attrValueId=" + attrValueId + "]";
	}
	
	

}
