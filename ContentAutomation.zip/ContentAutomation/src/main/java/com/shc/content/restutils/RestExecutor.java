package com.shc.content.restutils;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;

import com.shc.autocontent.ContentLogger;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;

/**
 * Utility class to wrap all APIs exposed by GB
 * @author nvarsh0
 *
 */
public class RestExecutor {

	public static int TotalAPIHitCounter = 0;
	public static long TotalAPIResponseTime = 0;
	static ContentLogger logger = ContentLogger.getLogger();
	private static RestClient getRestClient(){

		return PipelinedRestClientImpl.INSTANCE;
		//		return RestClientImpl.INSTANCE;
	}


	private static RestClient getNonPipelinedRestClient(){
		return RestClientImpl.INSTANCE;
	}
	/**
	 * Executed a get request against the URI
	 * @param uri
	 * @return
	 */
	public static String getJSonResponse(URI uri){
		logger.fine("Executing "+ uri);
		return getRestClient().getResponse(uri);
	}

	/**
	 * Executed a get request against the URI
	 * @param uri
	 * @return
	 */
	public static String getJSonResponse(String url){
		TotalAPIHitCounter++;
		logger.info("Executing "+ url);
		long start = System.currentTimeMillis();
		try {
			return getRestClient().getResponse(new URI(url));
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return null;
		}finally{
			TotalAPIResponseTime+= System.currentTimeMillis()-start;
		}
	}

	
	public static String postForXmlResponse(String url, String body){
		try {
			return getRestClient().postResponseXml(new URI(url), body);
		} catch (URISyntaxException e) {
			return "";
		}
	}
	
	/**
	 * Executed a post request against the URI
	 * @param uri
	 * @return
	 */
	public static String postForJSonResponse(String url, String body){
		try {
			return getRestClient().postResponse(new URI(url), body);
		} catch (URISyntaxException e) {
			return "";
		}
	}
	
	/**
	 * Executed a post request against the URI
	 * @param uri
	 * @return
	 */
	public static String postForJSonResponse(URI uri, String body){
		logger.fine("Executing "+ uri);
		return getRestClient().postResponse(uri, body);
	}

	public static String getJSonResponseById(CollectionValues c,String sId){
		URI u = RestAPIs.getByIdURI(c, sId);
		logger.fine(u.toString());
		return getJSonResponse(u);
	}

	public static String getJSonResponseById(String c,String sId){
		URI u = RestAPIs.getByIdURI(c, sId);
		logger.fine(u.toString());
		return getJSonResponse(u);
	}

	/**
	 * Executes a rest call and returns json response as string
	 * @param uri
	 * @return
	 *//*
	public static String getJSonResponse(URI uri){
		String singleJSonObject = null;
		BufferedReader r = new BufferedReader(new InputStreamReader(get(uri)));
		try{
			singleJSonObject = r.readLine();
//			System.out.println(singleJSonObject);
		}catch(IOException e){
			throw new RestExecutionException("Error on reading response", e.getCause());
		}
		return singleJSonObject;
	}*/

	/**
	 * Executes a rest call against a uri and returns object of type t
	 * @param uri
	 * @param t
	 * @return
	 */
	public static <T> T getResponseAsObject(URI uri, Class<T> t){
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseJSON(jsonAsString, t);

	}

	/**
	 * Executes a rest call against a uri and returns an object of corresponding collection
	 * Use for calls against collections
	 * @param uri
	 * @param c
	 * @return
	 */
	public static <T> T getResponseAsObject(URI uri, CollectionValues c, Class<T> t){
		String jsonAsString = getJSonResponse(uri);
		//System.out.println("Output "+ jsonAsString);
		return JSONParser.parseJSONWithBlob(jsonAsString, c,t);

	}
	
	public static <T> T getResponseAsObject(String json, CollectionValues c, Class<T> t){
		//String jsonAsString = getJSonResponse(uri);
		//System.out.println("Output "+ jsonAsString);
		return JSONParser.parseJSONWithBlob(json, c,t);

	}

	/**
	 * Returns the entire response as {@link APIResponse} object, which contains the entire data for response
	 * @param uri
	 * @param c
	 * @param t
	 * @return
	 */
	public static <T> APIResponse<T> getEntireResponseAsObject(URI uri, CollectionValues c, Class<T> t){

		String jsonAsString = getJSonResponse(uri);
		APIResponse<T> fullResponse = new APIResponse<T>();
		fullResponse.setT((T) JSONParser.parseJSONWithBlob(jsonAsString, c,t));
		fullResponse.setFtFields(JSONParser.parseJSONIndexes(jsonAsString, "_ft"));
		fullResponse.setSearchFields(JSONParser.parseJSONIndexes(jsonAsString, "_search"));
		fullResponse.setMetaFields(JSONParser.parseJSONIndexes(jsonAsString, "_meta"));
		return fullResponse;
	}

	/**
	 * Returns entire api response as {@link APIResponse} object 
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings(value = { "unchecked" })
	public static <T> APIResponse<T> getAllDataById(CollectionValues c, String sId){

		URI u = RestAPIs.getByIdURI(c, sId);
		logger.fine(u.toString());
		return (APIResponse<T>)getEntireResponseAsObject(u, c,c.getClassType());
	}


	/**
	 * Returns number of bucket ids for a collection
	 * @param c - Collection for which bucket ids are being fetched
	 * @return
	 */
	public static int getBucketIdsForCollection(CollectionValues c){
		String singleJSonObject = getJSonResponse(RestAPIs.getBucketsURI(c));

		return JSONParser.parseJSONToInt(singleJSonObject,"0");
	}

	/**
	 * Fetches all ids using getIDs api from collection c for a bucket ID
	 * @param c
	 * @param iBucketId
	 * @return
	 */
	public static List<String> getIdsForBucket(CollectionValues c, int iBucketId){

		String singleJSonObject = getJSonResponse(RestAPIs.getIDsURI(c, iBucketId));
		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	public static List<String> getIdsForBucket(String otherGb, CollectionValues c, int iBucketId){

		String singleJSonObject = getJSonResponse(RestAPIs.getIDsURI(otherGb,c, iBucketId));
		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	/**
	 * Fetches all ids using getFilter api from collection c for a bucket ID
	 * @param c
	 * @param iBucketId
	 * @param sKey - filter key
	 * @param sValue - filter value
	 * @return
	 */
	public static List<String> getFilteredIds(CollectionValues c, int iBucketId,String sKey, String sValue){

		String singleJSonObject = getJSonResponse(RestAPIs.getFilterIdsURI(c, iBucketId, sKey, sValue));
		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	public static List<String> getFilteredIds(String otherGb,CollectionValues c, int iBucketId,String sKey, String sValue){

		String singleJSonObject = getJSonResponse(RestAPIs.getFilterIdsURI(otherGb,c, iBucketId, sKey, sValue));
		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	/**
	 * Fetches all ids using get by alt key
	 * @param c
	 * @param iBucketId
	 * @return
	 */
	public static List<String> getIdsByAltKey(CollectionValues c, String sKey, String sValue){

		String singleJSonObject = getJSonResponse(RestAPIs.getByAltKey(c, sKey, sValue));

		return JSONParser.parseJSONToArray(singleJSonObject);
	}
	
	/**
	 * Fetches all ids using multiple get by alt keys
	 * @param c
	 * @param queryParams - get by alt keys & values
	 * @return
	 */
	public static List<String> getIdsByAltKey(CollectionValues c, HashMap<String, String> queryParams){

		String singleJSonObject = getJSonResponse(RestAPIs.getByAltKey(c, queryParams));

		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	public static List<String> getIdsByAltKey(CollectionValues c, String otherEndString){

		String singleJSonObject = getJSonResponse(RestAPIs.getByAltKey(c, otherEndString));

		try {
			return JSONParser.parseJSONToArray(singleJSonObject);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception ......................"+singleJSonObject);
			return null;
		}
	}	

	/**
	 * Fetches all ids using get by alt key
	 * @param c
	 * @param iBucketId
	 * @return
	 */
	public static List<String> getIdsByAltKey(URI uri){

		String singleJSonObject = getJSonResponse(uri);

		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	/**
	 * Fetches all ids using getIDs api from collection c for a bucket ID
	 * @param c
	 * @param iBucketId
	 * @return
	 */
	public static List<String> getIdsForBucketTimeStamp(CollectionValues c, int iBucketId){

		URI uri = RestAPIs.getIDsWithinTimeStamp(c, iBucketId, LoadProperties.FROM_TIME, LoadProperties.TO_TIME);
		validateTime(LoadProperties.FROM_TIME);

		String singleJSonObject = getJSonResponse(uri);
		return JSONParser.parseJSONToArray(singleJSonObject);
	}

	private static void validateTime(String sTime){
		//TODO : Add check
	}

	/**
	 * Generic method to get data by id from any collection
	 * @param c
	 * @param sId
	 * @return Type of object mapped to a collectionvalue see {@link CollectionValues}}
	 */
	public static <T> T getDataById(CollectionValues c, String sId, Class<T> t){

		URI u = RestAPIs.getByIdURI(c, sId);
		logger.fine(u.toString());
		return (T) getResponseAsObject(u, c,t);
	}

	/**
	 * Makes the api call for specified id and Returns just the class data for collection
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getDataById(CollectionValues c, String sId){

		//TotalAPIHitCounter++;
		URI u = RestAPIs.getByIdURI(c, sId);
		logger.fine(u.toString());


		return (T) getResponseAsObject(u, c,c.getClassType());
	}

	@SuppressWarnings("unchecked")
	public static <T> T getDataById(String json, CollectionValues c){

		//TotalAPIHitCounter++;
		//URI u = RestAPIs.getByIdURI(c, sId);
		//logger.fine(u.toString());


		return (T) getResponseAsObject(json, c,c.getClassType());
	}
	
	/**
	 * Makes the api call for specified id and Returns just the class data for collection
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getDataById(URI u,CollectionValues c){

		//TotalAPIHitCounter++;
		logger.fine(u.toString());
		return (T) getResponseAsObject(u, c,c.getClassType());
	}

	/**
	 * Makes the api call for specified id and Returns just the class data for collection
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> getDataById(CollectionValues c, List<String> lstIds){

		URI uri = RestAPIs.getByIdURI(c, lstIds);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseJSONDocsWithBlob(jsonAsString, c, c.getClassType());
		//		return (T) getResponseAsObject(u, c,c.getClassType());
	}

	public static <T> List<T> getDataById(String customGB, CollectionValues c, List<String> lstIds){

		URI uri = RestAPIs.getByIdURI(customGB,c, lstIds);
		//System.out.println("URI ..... : "+uri.toString());
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseJSONDocsWithBlob(jsonAsString, c, c.getClassType());
		//		return (T) getResponseAsObject(u, c,c.getClassType());
	}

	/**
	 * Makes the api call for list of ids together, parses responses to class object.
	 * This method does not remove the blob part and gives entire response converted to Schema classes
	 * Returned objects would have _blob, _search, _meta and _ft objects as well.
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> getDataByIdFullSchema(CollectionValues c, List<String> lstIds){

		URI uri = RestAPIs.getByIdURI(c, lstIds);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		List<T> response = JSONParser.parseJSONDocs(jsonAsString, c.getClassType());
		return response;
		//		return (T) getResponseAsObject(u, c,c.getClassType());
	}




	/**
	 * Makes the api call for list of ids together, parses responses to class object.
	 * This method does not remove the blob part and gives entire response converted to Schema classes
	 * Returned objects would have _blob, _search, _meta and _ft objects as well.
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getDataByIdFullSchema(CollectionValues c, String id){

		URI uri = RestAPIs.getByIdURI(c, id);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return (T)JSONParser.parseJSONDoc(jsonAsString, c.getClassType());
	}




	/**
	 * Takes a list of ids, makes a api call and returns all responses as a list.
	 * Returns null if no data found
	 * @param collection - collection to hit against
	 * @param lstIds - lst of ids to fetch data for
	 * @return - List of entire api responses including blob, meta, search and index data
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<APIResponse<T>>  getAllDataById(

			CollectionValues collection, List<String> lstIds) {
		//TotalAPIHitCounter++;
		URI uri = RestAPIs.getByIdURI(collection, lstIds);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseMultiResponseJSONWithBlob(jsonAsString, collection,collection.getClassType());

	}

	public static String  getAllDataByIdSingleString(
			CollectionValues collection, List<String> lstIds) {
		URI uri = RestAPIs.getByIdURI(collection, lstIds);
		logger.fine(uri.toString());
		return getJSonResponse(uri);

	}

	/**
	 * Takes a list of ids, hits GB GET API and returns as list of strings
	 * @param collection - Collection to hit
	 * @param lstIds - List of ids to get data for
	 * @return
	 */
	public static List<String>  getAllDataByIdString(
			CollectionValues collection, List<String> lstIds) {
		URI uri = RestAPIs.getByIdURI(collection, lstIds);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseMultiResponseJSONWithBlobString(jsonAsString);
	}

	/**
	 * Takes a list of ids, hits GB GET API and returns as list of strings
	 * @param collection - Collection to hit
	 * @param lstIds - List of ids to get data for
	 * @return
	 */
	public static List<String>  getAllDataByIdString(URI uri) {
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JSONParser.parseMultiResponseJSONWithBlobString(jsonAsString);
	}


	/**
	 * Forms a uri, hits GB with api and returns xpath generated single value
	 * @param collection
	 * @param id
	 * @param xPath
	 * @return
	 */
	public static String getSpecificValueFromJson(CollectionValues collection, String id, String xPath){
		URI uri = RestAPIs.getByIdURI(collection, id);
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JsonStringParser.getJsonValue(jsonAsString,xPath);
	}

	/**
	 * Hits api uri and returns xpath generated single value
	 * @param uri
	 * @param xPath
	 * @return
	 */
	public static String getSpecificValueFromJson(URI uri, String xPath){
		logger.fine(uri.toString());
		String jsonAsString = getJSonResponse(uri);
		return JsonStringParser.getJsonValue(jsonAsString,xPath);
	}

	/**
	 * Makes the api call for specified id and Returns just the class data for collection
	 * @param c
	 * @param sId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> getDataByListOfIds(URI u,CollectionValues c){

		//TotalAPIHitCounter++;
		logger.fine(u.toString());
		String jsonAsString = getJSonResponse(u);
		return JSONParser.parseJSONDocsWithBlob(jsonAsString, c, c.getClassType());
	}

	public static String putRequest(String uriToConvert, String postParams){
		URI uri;
		try {
			uri = new URI(uriToConvert);
			return getNonPipelinedRestClient().putResponse(uri, postParams);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Please check uri");
		}
		return null;

	}

	public static String deleteRequest(String uriToConvert, String deleteParams){
		URI uri;
		try {
			uri = new URI(uriToConvert+"/"+deleteParams);
			return getNonPipelinedRestClient().deleteResponse(uri, deleteParams);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Please check uri");
		}
		return null;

	}

}
