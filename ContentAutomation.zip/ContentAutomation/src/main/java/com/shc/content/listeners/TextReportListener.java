package com.shc.content.listeners;

import java.io.IOException;

import org.testng.ISuite;
import org.testng.ISuiteListener;

public class TextReportListener implements ISuiteListener{

	@Override
	public void onStart(ISuite suite) {
		System.out.println("TextReport Listener" + suite.getAllMethods().get(0).getMethodName());
		try {
//			if(suite.getAllInvokedMethods().size() > 0 )
				SimpleReporter.initFile(suite.getAllMethods().get(0).getMethodName(),".csv");
//			else
//				SimpleReporter.initFile(suite.getName(),".csv");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void onFinish(ISuite suite) {
		SimpleReporter.markEnd();
		
	}


}
