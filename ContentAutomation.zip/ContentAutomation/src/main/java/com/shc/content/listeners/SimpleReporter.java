package com.shc.content.listeners;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.counters.PromoCounters;
import com.shc.autocontent.utils.EmailUtils;

/**
 * This reporter writes any kind of data to a text file
 * @author nvarsh0
 *
 */
public class SimpleReporter implements Runnable {

	public static BlockingQueue<List<String>> resultsQueue = new LinkedBlockingQueue<List<String>>();
	static BufferedWriter writer;
	private static boolean allTestsRan = false;
	private static File file; 
	private static long l1 ;
	private static Thread t;
	private static String fileName;
	private static AtomicInteger passedCount = new AtomicInteger(0);
	private static AtomicInteger failedCount = new AtomicInteger(0);
	private static boolean isDataResult = false;
	
	
	/**
	 * Creates a file and creates a writer for it
	 * @param filename
	 * @param ext
	 * @throws IOException
	 */
	public static void initFile(String filename, String ext) throws IOException{
		fileName = filename;
		file = new File(filename+ext);
		try {
			if(file.exists())
				file = new File(filename+"_"+new Date().getTime()+ext);

			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		FileWriter fwriter = new FileWriter(file.getAbsoluteFile());
		writer = new BufferedWriter(fwriter);
		

		t = new Thread(new SimpleReporter());
		t.start();
		l1 = System.currentTimeMillis();
	}
	
	public static void logPassed(List<String> passedResult){
		
		try {
			if(!LoadProperties.ONLY_FAILED_RESULTS)
				SimpleReporter.resultsQueue.put(passedResult);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		passedCount.incrementAndGet();
		
	}
	
	public static void logFailed(List<String> failedResult){
		
		try {
				SimpleReporter.resultsQueue.put(failedResult);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		failedCount.incrementAndGet();
		
	}
	
	/**
	 * Keeps polling the resultsQueue for any results and writes to file <br>
	 * If no result is returned for 10 seconds and allTests have run then exits
	 */
	public void run(){
		List<String>  currentResult = null;
		while(true){
			try{
				currentResult = resultsQueue.poll(10, TimeUnit.SECONDS);
			}catch(Exception e){
				e.printStackTrace();
			}
			if (currentResult == null && allTestsRan)
				break;
			else{
				if(currentResult != null)
					writeResult(currentResult);
			}
			
		}
		shutdown();
	}

	private void writeResult(List<String> currentResult) {
		try {
			for(String result : currentResult){
				
					writer.write(result+",");
				
			}
			writer.write("\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Shuts down writer and sends email
	 */
	public static void shutdown(){
		try {
			writer.flush();
			writer.close();
			Map<String, String> mp = new LinkedHashMap<String, String>();
			SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d, ''yy 'at' HH:mm z");
			
			mp.put("Collection ", LoadProperties.collection);
			mp.put("GB ", LoadProperties.GREENVIP);
			if(!LoadProperties.OTHERGBBOX.equals(""))
				mp.put("GB 2 :", LoadProperties.OTHERGBBOX);
			mp.put("Data :", LoadProperties.RUN_PARAMS);
			
			mp.put("Online Item Count", String.valueOf(PromoCounters.offerOnlineCount.get()));
			mp.put("Online Item Pass Count", String.valueOf(PromoCounters.offerOnlinePassCount.get()));
			mp.put("Online Item Fail Count", String.valueOf(PromoCounters.offerOnlineFailCount.get()));
			mp.put("Offline Item Count", String.valueOf(PromoCounters.offerOfflineCount.get()));
			mp.put("Offline Item Failed Count", String.valueOf(PromoCounters.offerOfflineFailCount.get()));
			mp.put("Offline Item Pass Count", String.valueOf(PromoCounters.offerOfflinePassCount.get()));
			mp.put("MisMatch VariationItem Count", String.valueOf(PromoCounters.mismatchVariationItemCount.get()));
			mp.put("Mismatch Variation Unique Parent Count", String.valueOf(PromoCounters.uniqueVariationParentCount.size()));
			mp.put("UVD Count", String.valueOf(PromoCounters.uvdItemCount.get()));
			mp.put("Bundle Count", String.valueOf(PromoCounters.bundleItemCount.get()));
			StringBuilder msg = new StringBuilder();
			for(String key : PromoCounters.hieraritemGroupings.keySet()){
				msg.append(key).append(":: ").append(PromoCounters.hieraritemGroupings.get(key)).append(", ");
			}
			mp.put("Hierarchy Count", msg.toString());
			
			
			if(LoadProperties.FIELDSTOFETCH.size() > 0 && !LoadProperties.FIELDSTOFETCH.get(0).isEmpty())
				mp.put("Fields", LoadProperties.FIELDSTOFETCH.toString());
			
			if(LoadProperties.CRITERIA.size() > 0 && !LoadProperties.CRITERIA.get(0).isEmpty())
				mp.put("Criteria", LoadProperties.CRITERIA.toString());
			
			if(LoadProperties.IGNORED_FAILURES.size()>0 && !LoadProperties.IGNORED_FAILURES.get(0).isEmpty())
				mp.put("Ignored :", LoadProperties.IGNORED_FAILURES.toString());
			
			String sftc  = System.getProperty("fieldsToConsider", "");
			
			if(sftc!=null && !sftc.trim().isEmpty())
				mp.put("Fields Considered :", sftc);
			
			
			mp.put("Time Taken ", ReportUtils.getDurationString(Integer.parseInt(Long.toString((System.currentTimeMillis()-l1)/1000))));
			mp.put("Report Created on", sdf.format(new Date()));
			
			//If it's just a data related email - then do not add failed passed count
			if(!isDataResult){
			//Subtracting one since header is also in result queue, hence ignoring it
				mp.put("Failed ", String.valueOf(failedCount.get()));
				if(passedCount.get() > 0)
					mp.put("Passed ", String.valueOf(passedCount.get()));
				
			}
			mp.put("Total ", String.valueOf(failedCount.get()+ passedCount.get()));
			
			if(failedCount.get() > 0 || (!LoadProperties.ONLY_FAILED_RESULTS && passedCount.get() >0 ) || isDataResult)
				EmailUtils.sendEmail("Automation results - "+fileName, EmailUtils.prepareCustomTable(mp), file);
			else
				EmailUtils.sendEmail("Automation results - "+fileName, EmailUtils.prepareCustomTable(mp));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void markDataResults(){
		isDataResult = true;
	}

	/**
	 * Marks that all tests have run.  <br>
	 * Used in conjuction with resultsqueue poll in order to avoid exiting the reporter thread prematurely.
	 */
	public static void markEnd() {
		allTestsRan = true;
		try {
			t.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
}
