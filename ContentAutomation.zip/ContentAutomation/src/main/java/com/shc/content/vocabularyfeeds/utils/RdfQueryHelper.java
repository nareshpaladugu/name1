package com.shc.content.vocabularyfeeds.utils;

import com.shc.content.vocabularyfeeds.pojos.ProductVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.InitializingBean;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileManager;

public class RdfQueryHelper implements InitializingBean {

	public Model model = null;
	GbTaggingUtils gbTaggingUtils = new GbTaggingUtils();
	
	public void loadProductMap() throws Exception {
		try {
			Model model = FileManager.get().loadModel("vocabulary.xml");

			Query getProductQuery = QueryFactory.create(GBTaggingConstants.getAllProductIdQuery);
			QueryExecution qexec = QueryExecutionFactory.create(getProductQuery, model);
			try {
				ResultSet results = qexec.execSelect();
				while (results.hasNext()) {
					QuerySolution soln = results.nextSolution();
					Literal productId = soln.getLiteral("id");
					Literal productName = soln.getLiteral("name");
					GBTaggingConstants.PRODUCT_ID_LIST.add(productId.toString());
					addProductToMap(productId, productName);
				}
			} catch (Exception ex) {
			} finally {
				qexec.close();

			}

			Query getVocabularyTermQuery = QueryFactory.create(GBTaggingConstants.getALLVocabularyTermQuery);
			QueryExecution vocTermQueryExec = QueryExecutionFactory.create(getVocabularyTermQuery, model);
			try {
				ResultSet results = vocTermQueryExec.execSelect();
				while (results.hasNext()) {
					QuerySolution soln = results.nextSolution();
					Literal vocId = soln.getLiteral("id");
					Literal vocName = soln.getLiteral("name");
					Literal displayPath = soln.getLiteral("displayPath");
					Literal parentId = soln.getLiteral("parentId");
					Literal actvDate = soln.getLiteral("activationDate");
					Literal expDate = soln.getLiteral("expirationDate");
					Literal action = soln.getLiteral("action");
					addVocabularyTermToMap(vocId, vocName, displayPath, parentId, actvDate, expDate, action);
				}
			} catch (Exception ex) {
			} finally {
				vocTermQueryExec.close();
			}
		} catch (Throwable t) {
		}
	}

	private void addVocabularyTermToMap(Literal vocId, Literal vocName, Literal displayPath, Literal parentIdField,
			Literal actvDateField, Literal expDateField, Literal actionField) {
		String parentId = null;
		String actvDate = null;
		String expDate = null;
		String action = null;

		if (parentIdField != null) {
			parentId = parentIdField.toString();
		}

		if (actvDateField != null) {
			actvDate = actvDateField.toString();
		}

		if (expDateField != null) {
			expDate = expDateField.toString();
		}

		if (actionField != null) {
			action = actionField.toString();
		}

		VocabularyTermVO vocTerm = gbTaggingUtils.createVocabularyTerm(vocId.toString(), vocName.toString(),
				displayPath.toString(), parentId, actvDate, expDate, action);
		if (vocTerm != null) {
			GBTaggingConstants.VOCTERM_MAP.put(vocTerm.getId(), vocTerm);
		}
	}

	private void addProductToMap(Literal productId, Literal productName) {
		ProductVO product = gbTaggingUtils.createProduct(productId.toString(), productName.toString());
		// Product
		// existingProduct=RdfQueryConstants.PRODUCT_MAP.get(Integer.parseInt(productId.toString()));
		if (product != null) {
			GBTaggingConstants.PRODUCT_MAP.put(product.getId(), product);
		}
	}

	public String getRelatedVocabularyAssociationsForProductQuery(String productId) {
		String relatedVocTags = GBTaggingConstants.getAllRelatedVocabularyTermsForProduct;
		relatedVocTags = relatedVocTags.replace(GBTaggingConstants.productIdPlaceHolder, productId);
		return relatedVocTags;

	}

	public String getLinkedVocabularyAssociationsForProductQuery(String primaryVocId) {
		String linkedVocTags = GBTaggingConstants.getAllLinkedVocabularyTermsForProduct;
		linkedVocTags = linkedVocTags.replace(GBTaggingConstants.vocabularyIdPlaceHolder, primaryVocId);
		return linkedVocTags;

	}

	public String getDeletedLinkedVocabularyAssociationsForProductQuery(String primaryVocId) {
		String deletedLinkedVocTags = GBTaggingConstants.getAllDeletedLinkedVocabularyTermsForProduct;
		deletedLinkedVocTags = deletedLinkedVocTags.replace(GBTaggingConstants.vocabularyIdPlaceHolder, primaryVocId);
		return deletedLinkedVocTags;

	}

	public String getDeletedTermVocabularyAssociationsForProductQuery(String productId) {
		String deletedVocTags = GBTaggingConstants.getAllDeletedVocabularyTermsForProduct;
		deletedVocTags = deletedVocTags.replace(GBTaggingConstants.productIdPlaceHolder, productId);
		return deletedVocTags;

	}

	public List<String> getRelatedVocabularyAssociationsForProduct(String productId) {
		Query relatedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getRelatedVocabularyAssociationsForProductQuery(productId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(relatedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("vocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public List<String> getLinkedVocabularyAssociationsForProduct(String primaryVocId) {
		Query linkedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getLinkedVocabularyAssociationsForProductQuery(primaryVocId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(linkedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("linkedVocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public List<String> getDeletedLinkedVocabularyAssociationsForProduct(String primaryVocId) {
		Query deletedLinkedVocabularyAssociationsForProductQuery = QueryFactory.create(
				getDeletedLinkedVocabularyAssociationsForProductQuery(primaryVocId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(deletedLinkedVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("deletedLinkedVocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	public List<String> getDeletedTermVocabularyAssociationsForProduct(String productId) {
		Query deletedTermVocabularyAssociationsForProductQuery = QueryFactory.create(
				getDeletedTermVocabularyAssociationsForProductQuery(productId));
		QueryExecution vocTermQueryExec = QueryExecutionFactory.create(deletedTermVocabularyAssociationsForProductQuery,
				model);

		List<String> vocIds = new ArrayList<>();
		try {
			ResultSet results = vocTermQueryExec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				Literal vocId = soln.getLiteral("vocId");
				vocIds.add(vocId.toString());
			}
		} catch (Exception ex) {
		}
		return vocIds;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub

	}
}