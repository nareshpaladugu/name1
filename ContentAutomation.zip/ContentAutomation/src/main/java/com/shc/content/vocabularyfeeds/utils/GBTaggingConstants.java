package com.shc.content.vocabularyfeeds.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.shc.content.vocabularyfeeds.pojos.ProductVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;

public class GBTaggingConstants {

		public static AtomicInteger productReadCount = new AtomicInteger(0);
		public static ConcurrentMap<String, ProductVO> PRODUCT_MAP = new ConcurrentHashMap<String, ProductVO>();
		public static ConcurrentMap<String, VocabularyTermVO> VOCTERM_MAP = new ConcurrentHashMap<String, VocabularyTermVO>();
		
		public static List<String> PRODUCT_ID_LIST=new ArrayList<>();
		
		public static String productIdPlaceHolder="PRODUCT_ID";
		public static String vocabularyIdPlaceHolder="VOCABULARY_ID";
		
		public static String RELATE_TYPE="relate";
		public static String LINKED_TYPE="linked";
		public static String ACTION_TYPE_DELETE="DELETE";
		
		public static String HIERARCHY_TYPE_INSERT="INSERT";
		public static String HIERARCHY_TYPE_DELETE="DELETE";
		
		public static final String GB_TAGGING_JOB = "gb-Tagging";
		public static final String ISO_8601_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
		
		public static String DEFAULT_STARTDATE ="01/01/1900";
		public static String DEFAULT_ENDATE = "12/31/9999";
		
		public static final String ENDTIME = " 23:59:59";
		public static final String STARTTIME = " 00:00:00";
		
		public static final String YYYY_MM_DD_HH_MM_SS_DATE = "yyyy-MM-dd HH:mm:ss";
		public static final String MM_DD_YYYY_HH_MM_SS_DATE = "MM/dd/yyyy HH:mm:ss";
		
		public static final ThreadLocal<SimpleDateFormat> DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE = new ThreadLocal<SimpleDateFormat>() {
			@Override
			protected SimpleDateFormat initialValue() {
				return new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS_DATE);
			}
		};
		
		public static final ThreadLocal<SimpleDateFormat> DATE_FORMAT_MM_DD_YYYY_HH_MM_SS_DATE = new ThreadLocal<SimpleDateFormat>() {
			@Override
			protected SimpleDateFormat initialValue() {
				return new SimpleDateFormat(MM_DD_YYYY_HH_MM_SS_DATE);
			}
		};

		
		public static String getAllProductIdQuery = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?name ?id "+
			      "WHERE { "+
				  "?class rdf:type <spin:owlClass#product> ."+
			      "?class spin:id ?id ."+
				  "?class spin:name ?name ."+
			      "} ORDER BY ASC(?id)";
		
		
		public static String getALLVocabularyTermQuery = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?id ?name ?displayPath ?activationDate ?expirationDate ?action ?parentId "+
			      "WHERE { "+
				  "?class rdf:type <spin:owlClass#vocabulary_term> ."+
			      "?class spin:id ?id ."+
				  "?class spin:name ?name ."+
				  "?class spin:displayPath ?displayPath ."+
				  "OPTIONAL { ?class spin:activationDate ?activationDate . }" +
				  "OPTIONAL { ?class spin:expirationDate ?expirationDate . }" +
				  "OPTIONAL { ?class spin:action ?action . }" +
				  "OPTIONAL { "+
				  	"?class spin:hasParent ?parentVocTag . "+
				  	"?parentVocTag spin:id ?parentId ." +
				  "}"+
			      "} ORDER BY ASC(?id)";
		
/*		public static String getAllRelatedVocabularyTermsForProduct = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?vocId  ?action " +
			      " WHERE { "+
				  "?product spin:id \"PRODUCT_ID\"  ."+
			      "?assoc spin:associatedTerm ?product . "+
				  "?vocTerm spin:related ?assoc . "+
				  "optional { ?vocTerm spin:action ?action . }"+
				  "?vocTerm spin:id ?vocId ."+
			      "} ORDER BY ASC(?vocId)";
*/		
		
		public static String getAllRelatedVocabularyTermsForProduct = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?vocId  ?action " +
			      " WHERE { "+
			      "?product rdf:type <spin:owlClass#product> ."+
				  "?product spin:id \"PRODUCT_ID\"  ."+
			      "?assoc spin:associatedTerm ?product . "+
				  "?vocTerm spin:related ?assoc . "+
				  "optional { ?vocTerm spin:action ?action . }"+
				  "?vocTerm spin:id ?vocId ."+
			      "} ORDER BY ASC(?vocId)";

		
		public static String getAllLinkedVocabularyTermsForProduct = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?linkedVocId  " +
			      " WHERE { "+
				  "?linkedVoc rdf:type <spin:owlClass#vocabulary_term> ."+
			      "?linkedVoc spin:related ?assoc ."+
				  "?assoc spin:associatedTerm ?primaryVoc ."+
				  "?primaryVoc rdf:type <spin:owlClass#vocabulary_term> ."+
				  "?primaryVoc spin:id \"VOCABULARY_ID\" ." +
				  "?linkedVoc spin:id ?linkedVocId ."+
			      "} ORDER BY ASC(?linkedVocId)";
		
		public static String getAllDeletedVocabularyTermsForProduct = 
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
			      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
				  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
			      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
				  "SELECT distinct ?vocId  " +
			      " WHERE { "+
				  "?product spin:id \"PRODUCT_ID\"  ."+
			      "?assoc spin:associatedTerm ?product . "+
				  "?vocTerm spin:deletedTerm ?assoc ."+
				  "?vocTerm spin:id ?vocId ."+
			      "} ORDER BY ASC(?vocId)";
		
		public static String getAllDeletedLinkedVocabularyTermsForProduct =
				  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
					      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
						  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
					      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
						  "SELECT distinct ?deletedLinkedVocId  " +
					      " WHERE { "+
						  "?linkedVoc rdf:type <spin:owlClass#vocabulary_term> ."+
					      "?linkedVoc spin:deletedTerm ?assoc . "+
						  "?assoc spin:associatedTerm ?primaryVoc ."+
						  "?primaryVoc rdf:type <spin:owlClass#vocabulary_term> ."+
						  "?primaryVoc spin:id \"VOCABULARY_ID\" ." +
						  "?linkedVoc spin:id ?deletedLinkedVocId ."+
					      "} ORDER BY ASC(?deletedLinkedVocId)";
		
	}
	
/*	public  AtomicInteger productReadCount = new AtomicInteger(0);
	public  ConcurrentMap<String, ProductVO> PRODUCT_MAP = new ConcurrentHashMap<String, ProductVO>();
	public  ConcurrentMap<String, VocabularyTermVO> VOCTERM_MAP = new ConcurrentHashMap<String, VocabularyTermVO>();
	
	public  List<String> PRODUCT_ID_LIST=new ArrayList<>();
	
	public  String productIdPlaceHolder="PRODUCT_ID";
	public  String vocabularyIdPlaceHolder="VOCABULARY_ID";
	
	public  String RELATE_TYPE="relate";
	public  String LINKED_TYPE="linked";
	public  String ACTION_TYPE_DELETE="DELETE";
	
	public  String HIERARCHY_TYPE_INSERT="INSERT";
	public  String HIERARCHY_TYPE_DELETE="DELETE";
	
	public  final String GB_TAGGING_JOB = "gb-Tagging";
	public  final String ISO_8601_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	public  String DEFAULT_STARTDATE ="1900-01-01";
	public  String DEFAULT_ENDATE = "9999-12-31";
	
	public  final String ENDTIME = " 23:59:59";
	public  final String STARTTIME = " 00:00:00";
	
	public  final String YYYY_MM_DD_HH_MM_SS_DATE = "yyyy-MM-dd HH:mm:ss";

	public  final ThreadLocal<SimpleDateFormat> DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS_DATE);
		}
	};
	
	
	public  String getAllProductIdQuery = 
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
		      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
			  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
		      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
			  "SELECT distinct ?name ?id "+
		      "WHERE { "+
			  "?class rdf:type <spin:owlClass#product> ."+
		      "?class spin:id ?id ."+
			  "?class spin:name ?name ."+
		      "} ORDER BY ASC(?id)";
	
	
	public  String getALLVocabularyTermQuery = 
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
		      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
			  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
		      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
			  "SELECT distinct ?id ?name ?displayPath ?activationDate ?expirationDate ?action ?parentId "+
		      "WHERE { "+
			  "?class rdf:type <spin:owlClass#vocabulary_term> ."+
		      "?class spin:id ?id ."+
			  "?class spin:name ?name ."+
			  "?class spin:displayPath ?displayPath ."+
			  "OPTIONAL { ?class spin:activationDate ?activationDate . }" +
			  "OPTIONAL { ?class spin:expirationDate ?expirationDate . }" +
			  "OPTIONAL { ?class spin:action ?action . }" +
			  "OPTIONAL { "+
			  	"?class spin:hasParent ?parentVocTag . "+
			  	"?parentVocTag spin:id ?parentId ." +
			  "}"+
		      "} ORDER BY ASC(?id)";
	
	public  String getAllRelatedVocabularyTermsForProduct = 
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
		      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
			  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
		      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
			  "SELECT distinct ?vocId  ?action " +
		      " WHERE { "+
			  "?product spin:id \"PRODUCT_ID\"  ."+
		      "?assoc spin:associatedTerm ?product . "+
			  "?vocTerm spin:related ?assoc . "+
			  "optional { ?vocTerm spin:action ?action . }"+
			  "?vocTerm spin:id ?vocId ."+
		      "} ORDER BY ASC(?vocId)";
	
	
	public  String getAllLinkedVocabularyTermsForProduct = 
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
		      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
			  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
		      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
			  "SELECT distinct ?linkedVocId  " +
		      " WHERE { "+
			  "?linkedVoc rdf:type <spin:owlClass#vocabulary_term> ."+
		      "?linkedVoc spin:related ?assoc ."+
			  "?assoc spin:associatedTerm ?primaryVoc ."+
			  "?primaryVoc rdf:type <spin:owlClass#vocabulary_term> ."+
			  "?primaryVoc spin:id \"VOCABULARY_ID\" ." +
			  "?linkedVoc spin:id ?linkedVocId ."+
		      "} ORDER BY ASC(?linkedVocId)";
	
	public String getAllDeletedVocabularyTermsForProduct = 
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
		      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
			  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
		      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
			  "SELECT distinct ?vocId  " +
		      " WHERE { "+
			  "?product spin:id \"PRODUCT_ID\"  ."+
		      "?assoc spin:associatedTerm ?product . "+
			  "?vocTerm spin:deletedTerm ?assoc ."+
			  "?vocTerm spin:id ?vocId ."+
		      "} ORDER BY ASC(?vocId)";
	
	public String getAllDeletedLinkedVocabularyTermsForProduct =
			  "PREFIX spin:      <http://spin.sears.com:8080/spin-batch-webapp/d/api/vocabulary/v1/core#>"+
				      "PREFIX rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> "+
					  "PREFIX owl:    <http://www.w3.org/2002/07/owl#> "+
				      "PREFIX rdfs:    <http://www.w3.org/1999/02/22-rdfs-syntax-ns#>"+
					  "SELECT distinct ?deletedLinkedVocId  " +
				      " WHERE { "+
					  "?linkedVoc rdf:type <spin:owlClass#vocabulary_term> ."+
				      "?linkedVoc spin:deletedTerm ?assoc . "+
					  "?assoc spin:associatedTerm ?primaryVoc ."+
					  "?primaryVoc rdf:type <spin:owlClass#vocabulary_term> ."+
					  "?primaryVoc spin:id \"VOCABULARY_ID\" ." +
					  "?linkedVoc spin:id ?deletedLinkedVocId ."+
				      "} ORDER BY ASC(?deletedLinkedVocId)";
	*/
