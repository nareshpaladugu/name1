package com.shc.content.restutils;

import java.net.URI;

/**
 * Pipelined rest client for faster GETS
 * @author nvarsh0
 *
 */
public enum PipelinedRestClientImpl implements RestClient {

	INSTANCE;
	
	private WebserviceUtil  httpClient;
	
	private PipelinedRestClientImpl()  {
			httpClient = new WebserviceUtil();
			httpClient.initialize();
	}
	
	public String getResponse(URI uri) {
		return httpClient.processGet(uri);
	}
	
	public String postResponse(URI uri, String body) {
		return httpClient.processPost(uri,body);
	}

	public String postResponseXml(URI uri, String body) {
		return httpClient.processPostXml(uri,body);
	}
	@Override
	public String putResponse(URI uri, String postParams) {
		// TODO Auto-generated method stub
		System.out.println("Not implemented yet");
		return null;
	}

	@Override
	public String deleteResponse(URI uri, String param) {
		// TODO Auto-generated method stub
		return null;
	}

}
