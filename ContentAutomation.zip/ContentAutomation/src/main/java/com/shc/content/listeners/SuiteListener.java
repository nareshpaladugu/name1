package com.shc.content.listeners;

import java.io.File;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.Reporter;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;

/**
 * Initializes all properties, starts the reporting thread
 * Sets suite completion to true in aftersuite, to indicate to the reporting thread to end
 * @author nvarsh0
 *
 */
public class SuiteListener implements ISuiteListener{

	Long start, stop;
	public static long jsonTimer =0;
	public static boolean isSuiteCompleted = false;

	public void onStart(ISuite suite) {

		start = System.currentTimeMillis();
		File file = new File(suite.getOutputDirectory());
		ExcelReportListener.openResultFileForWriting(file.getParent());
		LoadProperties.OUTPUTFOLDER = file.getParent();

	}

	public void onFinish(ISuite suite) {
		stop = System.currentTimeMillis();
		System.out.println("Total time taken in secs:"+(stop - start)/1000);
		System.out.println("Total time taken in mins:"+(stop - start)/60000);
		suite.setAttribute("TotalTimeSecs", (stop - start)/1000);
		suite.setAttribute("TotalTimeMins", new Double((stop - start)/60000));

		System.out.println("Total DB2 Hits ..."+DBUtil.db2QueryHitCounter);

		System.out.println("Total DB2 Hit Time(in sec) ..."+(DBUtil.db2QueryHitTime/1000));

		System.out.println("JsonStringParser Timer(in ms).............. "+(jsonTimer));

		System.out.println("Size of result queue "+ CompareValuesUtility.getResultQueue().size());

		try {
			System.out.println("Total API Hits ..."+RestExecutor.TotalAPIHitCounter);
			System.out.println("Average API Response Time(in millis) ..."
			+(RestExecutor.TotalAPIResponseTime/RestExecutor.TotalAPIHitCounter));
		} catch (Exception e) {
			//"Ignore exception for these lines..."...
		}

		isSuiteCompleted = true;
	}

	

}
