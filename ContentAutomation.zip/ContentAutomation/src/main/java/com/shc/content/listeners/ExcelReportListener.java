package com.shc.content.listeners;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

import com.shc.autocontent.ContentLogger;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.reports.vo.FieldResultVO;
import com.shc.autocontent.reports.vo.FieldResultVO.RESULT;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.utils.DateUtil;
import com.shc.autocontent.utils.GenericUtil;

/**
 * Excel report generator - works as a thread, reading data from CompareValuesUtility queue to 
 * generate reports parallely.
 * @author nvarsh0
 *
 */
public class ExcelReportListener implements IReporter,Runnable 
{
	private static Styles stylesPassWB;
	private static Styles stylesFailWB;

	private static String sFileName  = "ContentAuto_Result_";

	private static int rowCounterPass = 2;
	private static int rowCounterFail = 2;

	ContentLogger logger = ContentLogger.getLogger();
	public static HSSFWorkbook resultWorkBookPass;
	public static HSSFWorkbook resultWorkBookFail;

	int passedCount = 0;
	int failedCount = 0;
	int totalCount = 0;

	int itimeOfExecutionInSeconds;
	String dateAndTimeOfReportCreation="";
	String sTestName;
	private Set<String> finalListOfHeaders = new HashSet<String>();
	static Thread reportingThread;

	private static int totalResultFileCount = 0;

	private static String outputDirForReports;


	private static String getFileName(int type)
	{
		if(type==1)
			return outputDirForReports + File.separator +"PASSED_"+sFileName+DateUtil.getCurrentDateAndTimeInRquiredFormat("ddMMM_hhmmss")+".xls";
		else if(type==0)
			return outputDirForReports + File.separator +"FAILED_"+sFileName+DateUtil.getCurrentDateAndTimeInRquiredFormat("ddMMM_hhmmss")+".xls";
		else
			return outputDirForReports + File.separator + sFileName+DateUtil.getCurrentDateAndTimeInRquiredFormat("ddMMM_hhmmss")+".xls";
	}

	public static void openResultFileForWriting(String outputDir)
	{
		outputDirForReports = outputDir ;
		reportingThread = new Thread(new ExcelReportListener());
		reportingThread.start();
	}

	static int ct=0;

	private String createPassedExcel()
	{
		if(rowCounterPass==2)
		{
			// Nothing is there in PASSED result ....
			return null;
		}
		String reportFileName;

		if(LoadProperties.splitResult)
			reportFileName =  getFileName(1);
		else
			reportFileName =  getFileName(-1);

		createExcel(reportFileName,resultWorkBookPass);

		return reportFileName;
	}

	private String createFailedExcel()
	{
		if(!LoadProperties.splitResult)
		{
			// Failed file not needed in case of !splittResult
			return null;
		}

		if(rowCounterFail==2)
		{
			// Nothing is there in FAILED result ....
			return null;
		}

		String reportFileName =  getFileName(0);

		createExcel(reportFileName,resultWorkBookFail);

		return reportFileName;
	}

	public void run(){

		if(resultWorkBookPass==null)
		{
			resultWorkBookPass = new HSSFWorkbook();
			stylesPassWB = new Styles(resultWorkBookPass);
		}

		if(resultWorkBookFail==null)
		{
			resultWorkBookFail = new HSSFWorkbook();
			stylesFailWB =  new Styles(resultWorkBookFail);
		}

		logger.info("Report thread started");

		BlockingQueue<Map<String,List<FieldResultVO>>> resultsToWrite = CompareValuesUtility.getResultQueue();

		//exit sleeping if we get a result to write or the suite completes
		while ( resultsToWrite.size() < 1  && SuiteListener.isSuiteCompleted == false ){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}

		logger.info("Out of sleep for writing");

		while(true)
		{
			Map<String, List<FieldResultVO>> mp;

			try
			{
				mp = resultsToWrite.poll(10, TimeUnit.SECONDS);

				if(mp == null && SuiteListener.isSuiteCompleted == true  && resultsToWrite.size() < 5){
					logger.info("Breaking the thread.  Suitecompleted "+ SuiteListener.isSuiteCompleted +
							" MP : "+ mp+ "  ResultsWrite size "+ resultsToWrite.size());
					break;
				}

				if(mp != null)
				{
					createDetailedReport_updated(CompareValuesUtility.getFieldNames(), mp);

					ct++;

					long length = 0; 

					if(ct%300==0)
					{
						logger.info("[PASS]Result File Size in Bytes : "+length +" : "+new Date());
						length = resultWorkBookPass.getBytes().length;
					}

					if((length > LoadProperties.FILE_SIZE * 1024 *1024 ) || rowCounterPass>55500 )
					{
						createPassedExcel();

						resultWorkBookPass = new HSSFWorkbook();

						stylesPassWB =  new Styles(resultWorkBookPass);

						rowCounterPass = 2;
					}

					if(LoadProperties.splitResult)
					{
						/*------------  need to check for fail file sub part if splittResult----------- */
						if(ct%300==0)
						{
							logger.info("[FAIL]Result File Size in Bytes : "+length +" : "+new Date());
							length = resultWorkBookFail.getBytes().length;
						}

						if((length > LoadProperties.FILE_SIZE * 1024 *1024 ) || rowCounterFail>55500 ) 
						{
							createFailedExcel();

							resultWorkBookFail = new HSSFWorkbook();

							stylesFailWB =  new Styles(resultWorkBookFail);

							rowCounterFail = 2;
						}
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
				System.out.println(" Caught let's go ahead"+e.getMessage());
			}
		}
	}

	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites,
			String outputDirectory) {

		try {
			long l1 = System.currentTimeMillis();
			logger.info("Waiting for report thread to end..");
			reportingThread.join();
			logger.info("Report thread ended"+(System.currentTimeMillis() -  l1));
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}


		sTestName = xmlSuites.get(0).getTests().get(0).getName();
		if(sTestName.equals("Automation Test Results")){

			if(suites.size() > 0 && suites.get(0).getAllMethods().size() > 0){
				if(suites.get(0).getAllMethods().get(0).getGroups().length ==0)
					sTestName = suites.get(0).getAllMethods().get(0).getMethodName();
				else
					sTestName = suites.get(0).getAllMethods().get(0).getGroups()[0];
			}
		}
		if(sTestName.equals("Default test"))
			sTestName = "";

		/* ---------------- Add summary sheet to both filed ---------------*/

		//Styles.reinit(resultWorkBookPass);
		this.createSummaryReport(suites,resultWorkBookPass,stylesPassWB);

		String fileForEmail=null;

		if(LoadProperties.splitResult)
		{
			this.createSummaryReport(suites,resultWorkBookFail,stylesFailWB);
			fileForEmail = createFailedExcel();
		}

		String passedFile = createPassedExcel();

		/**
		 * Not sure why the headers get incorrectly written - unable to reproduce
		 * Till the time fix is identified, adding below as a fail-safe repetition
		 */
		try {
			Sheet resultSheet = resultWorkBookPass.getSheet("Results");
			//Styles.reinit(resultWorkBookPass);

			if(resultSheet!=null)
			{
				finalListOfHeaders = CompareValuesUtility.getFieldNames().keySet();
				setupHeader(resultSheet,CompareValuesUtility.getFieldNames(),stylesPassWB);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			Sheet resultSheet = resultWorkBookFail.getSheet("Results");
			//Styles.reinit(resultWorkBookFail);

			if(resultSheet!=null)
			{
				finalListOfHeaders = CompareValuesUtility.getFieldNames().keySet();
				setupHeader(resultSheet,CompareValuesUtility.getFieldNames(),stylesFailWB);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/*--------------- which file needs to be send with result email ----------*/
		if(rowCounterFail>2)
			sendAutoEmail(fileForEmail);
		else
			sendAutoEmail(passedFile);

	}

	public void createExcel(String reportFileName,HSSFWorkbook resultWorkBook)
	{
		// Render the report
		totalResultFileCount = getTotalFileCount() + 1;

		File outputDir =  new File(outputDirForReports);
		if(!outputDir.exists()){
			logger.info("Creating directory " + outputDirForReports);
			System.out.println("Result : " +outputDir.mkdir());
		}

		FileOutputStream fOut;
		try {

			fOut = new FileOutputStream(new File(reportFileName));

			resultWorkBook.write(fOut);
			fOut.flush();
			fOut.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Excel File Created @ " + reportFileName);
	}


	public void sendAutoEmail(String reportFileName)
	{
		String host = "mailhost.prod.ch3.s.com";
		String from = "content.automation@searshc.com";
		String[] cc = {""};
		try {

			Boolean bEmailFlag =  LoadProperties.EMAIL_FLAG;

			if(bEmailFlag)
			{
				logger.info("Sending email..");
				String emailRecipients =  LoadProperties.EMAIL_RECEPIENTS;
				String emailRecipientsCC =  LoadProperties.EMAIL_RECEPIENTS_CC;

				logger.info("bEmailFlag.............. "+bEmailFlag);
				logger.info("emailRecipients.............. "+emailRecipients);
				logger.info("emailRecipientsCC.............. "+emailRecipientsCC);

				String[] toList = emailRecipients.split(",");

				if(emailRecipientsCC!=null)
				{
					cc = emailRecipientsCC.split(",");
				}

				if(passedCount+failedCount==0)
				{
					File[] fs = null;
					SendAutoEmail.sendMailUsingJavaMail(host, from, toList, cc, "Test results "+ sTestName,
							GenericUtil.getActualBodyTextForNoData(),
							fs);
				}
				else
				{
					File[] fs;
					
					if(reportFileName==null||reportFileName.isEmpty())
					{
						fs=null;
					}
					else
					{
						fs = new File[1];
						fs[0]=new File(reportFileName);
					}

					SendAutoEmail.sendMailUsingJavaMail(host, from, toList, cc, "Test results "+ sTestName +
							(CompareValuesUtility.isRunAborted() ?" - Run Aborted. Failure threshold : "
									+LoadProperties.FAILURE_THRESHOLD+ " exceeded.":""),
									GenericUtil.getActualBodyText(passedCount,failedCount,CompareValuesUtility.getFailedFields().toString(),
											ReportUtils.getDurationString(itimeOfExecutionInSeconds),dateAndTimeOfReportCreation),
											fs);
				}
			}else{
				logger.info("Email flag set to false.  Skipping email send.");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.severe("Not able to send auto email, "+e.getMessage());
		}
	}


	public void createSummaryReport(List<ISuite> suites,HSSFWorkbook resultWorkBook,Styles styles)
	{
		if(resultWorkBook==null)
		{
			resultWorkBook = new HSSFWorkbook();
			styles=new Styles(resultWorkBook);
		}

		Sheet  summarySheet = resultWorkBook.createSheet("Summary");

		String timeOfExecutionInSeconds="";

		totalCount = CompareValuesUtility.getFinalResult().getTotalCount();
		failedCount = CompareValuesUtility.getFinalResult().getFailedCount();
		passedCount = totalCount - failedCount;

		for(ISuite suite : suites){
			timeOfExecutionInSeconds+=suite.getAttribute("TotalTimeSecs").toString();
		}

		try {
			itimeOfExecutionInSeconds = Integer.parseInt(timeOfExecutionInSeconds);
		} catch (NumberFormatException e) {
			itimeOfExecutionInSeconds=0;
		}

		createRow(summarySheet,2, "Passed Count", String.valueOf(passedCount),styles);
		createRow(summarySheet,3, "Failed Count", String.valueOf(failedCount),styles);
		createRow(summarySheet,4, "Total Count", String.valueOf(totalCount),styles);
		createRow(summarySheet,5, "Execution Time", ReportUtils.getDurationString(itimeOfExecutionInSeconds),styles);
		createRow(summarySheet,6, "Failed fields", CompareValuesUtility.getFailedFields().toString(),styles);
		createRow(summarySheet,7, "Ignored failures", LoadProperties.IGNORED_FAILURES.toString(),styles);
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d, ''yy 'at' HH:mm z");
		dateAndTimeOfReportCreation =  sdf.format(new Date());
		createRow(summarySheet,8, "Report Created on ",dateAndTimeOfReportCreation,styles);				

	}

	public void createRow(Sheet s, int row, String sTitle, String count,Styles styles){
		s.createRow(row).createCell(1).setCellValue(sTitle);
		s.getRow(row).createCell(2).setCellValue(count);
		s.getRow(row).getCell(1).setCellStyle(styles.headerStyle);
		s.autoSizeColumn(1);
	}

	synchronized public  Sheet getResultSheet(boolean status)
	{

		Sheet  resultSheet = null;

		/*--------------use pass file to write failed ones if !splittResult ----------*/

		if(!LoadProperties.splitResult  || status)
		{
			resultSheet = resultWorkBookPass.getSheet("Results");

			if (resultSheet == null) 
			{
				resultSheet = resultWorkBookPass.createSheet("Results");
				logger.info("[PASS]Creating Results : "+resultSheet.getSheetName());
			}

			//Styles.reinit(resultWorkBookPass);
		}
		else
		{
			resultSheet = resultWorkBookFail.getSheet("Results");

			if (resultSheet == null) 
			{
				resultSheet = resultWorkBookFail.createSheet("Results");
				logger.info("[FAIL]Creating Results : "+resultSheet.getSheetName());
			}

			//Styles.reinit(resultWorkBookFail);
		}

		return resultSheet;
	}

	private boolean getResultStatus(	List<FieldResultVO> allResults)
	{
		for (FieldResultVO singleFieldResult : allResults) {

			if(singleFieldResult.getResult() == FieldResultVO.RESULT.FAILED || singleFieldResult.getInfoType() == FieldResultVO.INFOTYPE.FAILED)
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * Core method to write to report - result for one id or one testdata.
	 * 
	 * @param sHeaders  - List of current headers, this may or may not be complete at all times.
	 * @param mp - map of id to it's FieldResults
	 */
	public  void createDetailedReport_updated(Map<String,Integer> sHeaders,Map<String,List<FieldResultVO>> mp){

		//Setup header

		Styles styles;
		Cell dataCell;
		Row dataRow;
		List<FieldResultVO> allResults;

		Sheet  resultSheet;

		for (String sId : mp.keySet()) 
		{
			allResults = mp.get(sId);

			boolean rowStatus = getResultStatus(allResults);

			int rowCounter;

			if(LoadProperties.splitResult)
			{
				if(rowStatus)
				{
					rowCounter = rowCounterPass;
					styles=stylesPassWB;
				}
				else
				{
					rowCounter = rowCounterFail;
					styles=stylesFailWB;
				}
			}
			else
			{
				//use pass file count in case !splittResult
				rowCounter = rowCounterPass;
				styles=stylesPassWB;
			}

			resultSheet = getResultSheet(rowStatus);

			finalListOfHeaders = sHeaders.keySet();
			synchronized (resultSheet) {
				setupHeader(resultSheet, sHeaders,styles);
			}


			int colCount = 0;
			int iInitRow = rowCounter;  //Row of initial entry
			int iLastRow = rowCounter;// Counter to track what is the lastest row updated
			RESULT finalRowResult = RESULT.PASSED;



			dataRow = resultSheet.createRow(rowCounter++);
			dataCell = dataRow.createCell(colCount++);
			dataCell.setCellValue(sId);


			int iLastCol = 0;
			//				for (FieldResultVO f : allResults) {
			for(int i = 0; i < allResults.size(); i++){
				FieldResultVO singleFieldResult = allResults.get(i);
				if(singleFieldResult.equals(CompareValuesUtility.NEWMULTIVALFIELD)){
					//Only do rowcounter change if previous field was not newmultivaluedfield
					if(!allResults.get(i-1).equals(CompareValuesUtility.NEWMULTIVALFIELD)){
						rowCounter = iInitRow + 1;
						dataRow = resultSheet.getRow(iInitRow);
						continue;
					}
					continue;
				}

				if(singleFieldResult.equals(CompareValuesUtility.NEWDATAWITHINDATA)){
					if(iLastRow > rowCounter)
						rowCounter = iLastRow;
					iInitRow = iLastRow ;
					//	rowCounter = iInitRow + 1;
					dataRow = resultSheet.createRow(rowCounter++);
					continue;
				}


				//Get column number of field name - * 2 for act and exp columns and + 1 for id column at start
				int iCol = sHeaders.get(singleFieldResult.getFieldName());// * 2 + 1;


				//If current column is greater than the last column filled then data is for same row
				//and the column should not have any value, then create new cell
				//else move to next row or create if it doesn't exist
				/*if moving ahead and icol is null then create column
					else moving back and icol is not null then create new row
					if moving back and icol is empty then create column*/

				if ( (iCol>iLastCol && dataRow.getCell(iCol) == null ) || 
						(iCol<iLastCol && dataRow.getCell(iCol) == null && resultSheet.getRow(iInitRow).getCell(iCol) == null)){
					dataCell = dataRow.createCell(iCol++);
					iLastCol = iCol;
				}
				else {
					//TODO :: To revisit the logic
					//Last row signifies the last rowCounter value.
					//If last row is less then current rowCounter, then this row has not been created 
					if(iLastRow < rowCounter+1){
						dataRow = resultSheet.createRow(rowCounter++);
						iLastRow = rowCounter;
					}else
						dataRow = resultSheet.getRow(rowCounter++);

					//Make lastcol now based on new column
					iLastCol = iCol;
					dataCell = dataRow.createCell(iCol++);

				}
				dataCell.setCellValue(singleFieldResult.getExpected());

				//if(!(singleFieldResult.getResult() == FieldResultVO.RESULT.INFO))
				//{
				//Only if it is a non-info field - look for result for formatting cells

				//Failed result - Set to red first two columns for id and result and then the actual exp and actual cells
				if (singleFieldResult.getResult() == FieldResultVO.RESULT.FAILED || singleFieldResult.getInfoType() == FieldResultVO.INFOTYPE.FAILED) {
					try {
						if(!finalRowResult.equals(RESULT.FAILED)){
							finalRowResult = RESULT.FAILED;
							Cell idCell = resultSheet.getRow(iInitRow).getCell(0);
							idCell.setCellStyle(styles.failStyle);
							Cell resultCell = resultSheet.getRow(iInitRow).createCell(1);
							resultCell.setCellValue("Failed");
							resultCell.setCellStyle(styles.failStyle);
						}
						//							Cell a = dataCell.getRow().getCell(0);

					} catch (Exception e) {
					}
					dataCell.setCellStyle(styles.failStyle);
				}

				if(!(singleFieldResult.getResult() == FieldResultVO.RESULT.INFO))
				{
					/*-----------------Add actual value not non INFO fields ------------*/
					dataCell = dataRow.createCell(iCol++);
					if (singleFieldResult.getResult() == FieldResultVO.RESULT.FAILED)
						dataCell.setCellStyle(styles.failStyle);
					dataCell.setCellValue(singleFieldResult.getActual());
				}
				else
				{
					iLastCol--;

					if(singleFieldResult.getInfoType() == FieldResultVO.INFOTYPE.FAILED)
					{
						dataCell.setCellStyle(styles.failStyle);
					}
				}
				/*}else{
					//Reducing iLastCol since while earlier it was assumed that there will be two columns for each
					//field - do not want to change existing logic - hence adding this else for info fields
					iLastCol--;

					if(singleFieldResult.getInfoType() == FieldResultVO.INFOTYPE.FAILED)
					{
						dataCell.setCellStyle(styles.failStyle);
					}
				}*/
			}

			//If finalRowResult has not been changed by any failed result, then result is updated as passed in the second column
			if(finalRowResult.equals(RESULT.PASSED)){
				Cell resultCell = resultSheet.getRow(iInitRow).createCell(1);
				resultCell.setCellValue("Passed");
			}

			//After all fields are done, the rowCounter should move to the greatest row updated
			if(iLastRow > rowCounter)
				rowCounter = iLastRow;

			if(LoadProperties.splitResult)
			{
				if(rowStatus)
				{
					rowCounterPass = rowCounter;
				}
				else
				{
					rowCounterFail = rowCounter ;
				}
			}
			else
			{
				rowCounterPass = rowCounter;
			}
		}
	}

	/**
	 * Sets up headers (field names) and subheader(actual exp column) based on fieldnames in result vos.
	 * @param resultSheet
	 * @param sHeaders
	 */
	private static void setupHeader(Sheet resultSheet, Map<String,Integer> sHeaders,Styles styles
			){
		Row headerRow = resultSheet.createRow(0);
		Row subHeaderRow = resultSheet.createRow(1);
		int i = 0, jSubHeaderColCount =2;
		Set<String> infoFieldList = CompareValuesUtility.getInfoFieldSet();

		//Set Header cells - first with Id and second with result
		Cell cell = headerRow.createCell(i++);
		cell.setCellStyle(styles.headerStyle);
		cell.setCellValue("Id");

		cell = headerRow.createCell(i++);
		cell.setCellStyle(styles.headerStyle);
		cell.setCellValue("Result");

		int iLastColNum = 0;
		for(String sHeader: sHeaders.keySet()){
			Cell cell1 = headerRow.createCell(i++);
			cell1.setCellValue(sHeader);
			cell1.setCellStyle(styles.headerStyle);

			if(!infoFieldList.contains(sHeader)){
				Cell cell2 = headerRow.createCell(i++);
				cell2.setCellStyle(styles.headerStyle);
				resultSheet.addMergedRegion(new CellRangeAddress(0,0, i-2, i-1));
			}
			cell1 = subHeaderRow.createCell(jSubHeaderColCount++);
			cell1.setCellStyle(styles.subHeaderStyle);
			//TODO : To clear this hardcoding up
			cell1.setCellValue("Data");
			if(!infoFieldList.contains(sHeader)){
				cell1.setCellValue("Exp");
				Cell cell2 = subHeaderRow.createCell(jSubHeaderColCount++);
				cell2.setCellStyle(styles.subHeaderStyle);
				cell2.setCellValue("Actual");
			}
			iLastColNum = sHeaders.get(sHeader);
		}

	}



	/**
	 * @return the totalFile count
	 */
	public static int getTotalFileCount() {
		return totalResultFileCount;
	}
}