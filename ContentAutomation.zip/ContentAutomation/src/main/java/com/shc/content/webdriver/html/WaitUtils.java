package com.shc.content.webdriver.html;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shc.autocontent.LoadProperties;
import com.shc.content.webdriver.DriverInitializer;
import com.shc.content.webdriver.assertions.DriverLogger;
/**
 * Utility for explicit waits.
 * @author Niharika Varshney
 *
 */
public class WaitUtils {
	final static long timeoutSec = LoadProperties.EXPLICITWAITTIMEOUT;
	private static DriverLogger logger = new DriverLogger();
	
	/**
	 * Waits until element is visible
	 * @param locator - locator
	 * @param elementName - Name of element for logging purpose
	 */
	public static void waitUntilElementIsVisible(String locator, String... elementName) {
		By by = ElementHelper.figureOutBy(locator);
		waitUntilElementIsVisible(by, elementName);
    }


	
	/**
	 * Waits until the {@code condition} evaluates to true.  Throws timeout exception otherwise.
	 * Waits for {@link LoadProperties.EXPLICITWAITTIMEOUT}
	 * 
	 * @param condition
	 * @param locatorName
	 */
	public static void waitUntil(ExpectedCondition<?> condition, String... locatorName) {
		try{
	        new WebDriverWait(DriverInitializer.driver(), timeoutSec).until(condition);
		}catch(TimeoutException e){
			if(locatorName.length > 0)
				logger.logFailed("Timed out waiting for "+ locatorName[0]);
			throw e;
		}
	 }


	/**
	 * Checks that an element is present on the DOM of a page and visible.<br> 
	 * Visibility means that the element is not only displayed but also has a 
	 * height and width that is greater than 0
	 * @param byType
	 * @param elementName
	 */
	public static void waitUntilElementIsVisible(By byType, String... elementName) {
		 ExpectedCondition<WebElement> condition = ExpectedConditions.visibilityOfElementLocated(byType);
	        waitUntil(condition, elementName);
	}
	
	/**
	 * Checks that an element is present on the DOM of a page and visible.<br> 
	 * Visibility means that the element is not only displayed but also has a 
	 * height and width that is greater than 0
	 * @param AbstractBaseElement
	 */
	public static void waitUntilElementIsVisible(AbstractBaseElement element) {
			waitUntilElementIsVisible(element.getByType(), element.getControlName());
			
    }
	
	/**
	 * Waits till  an element is either invisible or not present on the DOM.
	 * @param byType
	 * @param elementName
	 */
	public static void waitUntilElementIsInVisible(By byType, String elementName) {
		 ExpectedCondition<Boolean> condition = ExpectedConditions.invisibilityOfElementLocated(byType);
	        waitUntil(condition,elementName);
	}
	
	/**
	 * Waits till  an element is either invisible or not present on the DOM.
	 * @param element
	 */
	public static void waitUntilElementIsInVisible(AbstractBaseElement element) {
		 ExpectedCondition<Boolean> condition = ExpectedConditions.invisibilityOfElementLocated(element.getByType());
	        waitUntil(condition, element.getControlName());
	}
	
	/**
	 * Waits till an element is visible and enabled such that you can click it.
	 * @param element
	 */
	public static void waitUntilElementIsClickable(AbstractBaseElement element) {
		 ExpectedCondition<WebElement> condition = ExpectedConditions.elementToBeClickable(element.getByType());
	        waitUntil(condition, element.getControlName());
	}
	
	public static void waitBySleep() {
		 
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Method to wait till element contains specified text
	 * @param element
	 * @param textToCheck
	 */
	public static void waitUntilElementContainsText(AbstractBaseElement element, String textToCheck) {
		ExpectedCondition<Boolean> condition = ExpectedConditions.textToBePresentInElementLocated(element.getByType(), textToCheck);
		waitUntil(condition, element.getControlName());
	}
}