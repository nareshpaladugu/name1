package com.shc.content.webdriver;

import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.shc.autocontent.LoadProperties;


public class DriverInitializer {

	private static ThreadLocal<RemoteWebDriver> threadLocalWebDriver = new ThreadLocal<RemoteWebDriver>();

	private DriverInitializer() {
	}

	public static ThreadLocal<RemoteWebDriver> getThreadLocalWebDriver() {
		return threadLocalWebDriver;
	}

	/**
	 * Returns the threadlocal driver instance for current run
	 * @return
	 */
	public static RemoteWebDriver driver() {

		createSession();

		RemoteWebDriver rwd = threadLocalWebDriver.get();
		if (rwd == null) {
			throw new IllegalStateException("Driver not initialized.");
		}
		return rwd;
	}

	private static void createSession() {

		if(threadLocalWebDriver.get() != null)
			return;
		
		URL hubURL = DriverHelper.getURL();
		RemoteWebDriver driver = createInstance( hubURL);
		DriverInitializer.getThreadLocalWebDriver().set(driver);
	}

	private static RemoteWebDriver createInstance( URL url){
		RemoteWebDriver driver = null;
		Browser browserToExecuteOn = Browser.getBrowser(LoadProperties.BROWSER);
		DesiredCapabilities capability = DriverHelper.getCapabilities(browserToExecuteOn);
		driver = new RemoteWebDriver(url, capability);
		return driver;

	}

	public static void disconnect(){
		DriverInitializer.getThreadLocalWebDriver().set(null);
	}

}
