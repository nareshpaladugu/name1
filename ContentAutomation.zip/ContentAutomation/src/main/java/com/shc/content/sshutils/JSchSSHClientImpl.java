package com.shc.content.sshutils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;
import com.shc.autocontent.LoadProperties;

public class JSchSSHClientImpl implements SSHClient{

	protected String sshUserName, sshUserPwd;
    protected String hostName;
    protected int timeOut;
    protected int port;
    private Session session;
    private ChannelExec execChannel = null;
	
	 JSchSSHClientImpl() {
	        sshUserName = LoadProperties.SSH_USER;
	        sshUserPwd = LoadProperties.SSH_PWD;
	        hostName = LoadProperties.BATCH_SERVER;
	        port = LoadProperties.BATCH_PORT;
	    }
	 
	 private JSch getClient() {
	    	
	        JSch jsch = new JSch();
	        return jsch;
	   }
	 
	 private Session getSession() throws JSchException {
		 try {
				if (this.session == null || ! session.isConnected()) {
					JSch jsch;
					jsch = this.getClient();
					session =	jsch.getSession(this.sshUserName, this.hostName ,this.port);
					session.setConfig("StrictHostKeyChecking", "no");
					session.setUserInfo(new SSHUser());
					session.setPassword(LoadProperties.SSH_PWD);
					session.connect();
					session.setTimeout(this.timeOut);
				}
				return session;
			} catch (JSchException e) {
				Logger.getLogger("sdf").severe("Passwordless setup not done or could not connect "+ e.getMessage());
				throw e;
			}

	 } 
	 
	 
	 /**
	  * Pass any command to execute on a shell
	  * @param sCommand
	  */
	@Override
	public List<String> executeCommand(String sCommand) {
		 ByteArrayOutputStream err = new ByteArrayOutputStream();
	     
	     List<String> output = new ArrayList<String>();
		try{
			session = getSession();
			execChannel= (ChannelExec)session.openChannel("exec");
			
			execChannel.setCommand(sCommand);
			execChannel.setErrStream(err);
			InputStream in=execChannel.getInputStream();
			execChannel.connect();
			try(BufferedReader inReader =  new BufferedReader(new InputStreamReader(in))){
		        StringBuilder builder = new StringBuilder();
	
		        int data = 0;
		        	
		        while(data !=-1){
	
		        	data = inReader.read();
		        	if((char)data == '\n'){
		        		output.add(builder.toString());
		        		builder = new StringBuilder();
		        	}
		        	else
		        		builder.append((char)data);
		        }
		        return output;
			} catch (IOException e) {
				e.printStackTrace();
				throw new SSHExecutionException("Error reading output from console."+ sCommand );
			}
		
		} catch (JSchException e) {
			e.printStackTrace();
			throw new SSHExecutionException("Could not establish connection with "+hostName+" for user "+ sshUserName );
		} catch (IOException e) {
			e.printStackTrace();
			throw new SSHExecutionException("SSH execution failed on "+hostName+" for user "+ sshUserName );
		}
	}
	
	public void disconnect(){
		if (execChannel != null) {
			execChannel.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
	}

	/**
     * This object is internally used by JSch and is required by it.
     *
     */
    static class SSHUser implements UserInfo {

        public String getPassphrase() {
            return null;
        }

        public String getPassword() {
            return null;
        }

        public boolean promptPassphrase(String arg0) {
            return false;
        }

        public boolean promptPassword(String arg0) {
            return false;
        }

        public boolean promptYesNo(String arg0) {
            return false;
        }

        public void showMessage(String arg0) {

        }

    }

	public void finalize(){
		System.out.println("In finalize");
		this.disconnect();
	}

	
}
