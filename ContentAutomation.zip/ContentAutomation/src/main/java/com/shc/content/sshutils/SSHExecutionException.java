package com.shc.content.sshutils;

public class SSHExecutionException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7274941976907961651L;

	public SSHExecutionException(String message){
		super(message);
	}
	
	public SSHExecutionException(String message, Throwable cause){
		super(message, cause);
	}
}
