package com.shc.content.restutils;

import java.net.URI;
import java.nio.charset.Charset;

import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.handler.codec.http.DefaultHttpRequest;
import org.jboss.netty.handler.codec.http.HttpHeaders;
import org.jboss.netty.handler.codec.http.HttpMethod;
import org.jboss.netty.handler.codec.http.HttpRequest;
import org.jboss.netty.handler.codec.http.HttpVersion;

import com.biasedbit.http.client.CannotExecuteRequestException;
import com.biasedbit.http.client.DefaultHttpClientFactory;
import com.biasedbit.http.client.HttpClient;
import com.biasedbit.http.client.connection.PipeliningConnectionFactory;
import com.biasedbit.http.client.future.RequestFuture;
import com.biasedbit.http.client.processor.BodyAsStringProcessor;
import com.shc.autocontent.ContentLogger;
import com.shc.autocontent.LoadProperties;


public class WebserviceUtil {

	private static final ContentLogger log = ContentLogger.getLogger();

	private HttpClient httpclient = null;

	private static final boolean GB_ENABLE_HTTP_PIPELINING = true;
	//	private static final boolean GB_GATHER_HTTP_CLIENTS_STATS = new Boolean (PropertiesReader.getProperty("gather.http.client.stats")).booleanValue();
	private static final int GB_MAX_CONNECTIONS_PER_HOST = 128;
	private static final int GB_REQ_TIMEOUT_IN_MILLIS = 45000;
	private static final int GB_REQ_IN_PIPE = 30;
	private static final int GB_MAX_REQ_IN_QUEUE = Short.MAX_VALUE;
	private static final int GB_MAX_EVENT_PROCESSING_THREADS = 64;
	private static final int GB_MAX_IO_WORKER_THREADS = 128;
	private static final boolean GB_USE_NIO = true;
	//public static final int  GB_PORT = Integer.parseInt(PropertiesReader.getProperty("port"));;
	//public static final String GB_HOST_ROUTE_URL = PropertiesReader.getProperty("host.route.url");

	private static final boolean GB_GATHER_HTTP_CLIENTS_STATS = false;


	public WebserviceUtil()  {
	}

	public void initialize() {
		DefaultHttpClientFactory factory = new DefaultHttpClientFactory();
		factory.setMaxConnectionsPerHost(GB_MAX_CONNECTIONS_PER_HOST);
		factory.setRequestInactivityTimeout(GB_REQ_TIMEOUT_IN_MILLIS);
		factory.setUseNio(GB_USE_NIO);
		factory.setMaxHelperThreads(GB_MAX_EVENT_PROCESSING_THREADS);
		factory.setGatherStats(GB_GATHER_HTTP_CLIENTS_STATS);
		factory.setMaxIoWorkerThreads(GB_MAX_IO_WORKER_THREADS);
		factory.setMaxQueuedRequests(GB_MAX_REQ_IN_QUEUE);
		if (GB_ENABLE_HTTP_PIPELINING) {
			PipeliningConnectionFactory pf = new PipeliningConnectionFactory();
			pf.setMaxRequestsInPipeline(GB_REQ_IN_PIPE);
			pf.setAllowNonIdempotentPipelining(true);
			factory.setConnectionFactory(pf);
		}
		httpclient = factory.createClient();
		httpclient.init();
		System.out.println(httpclient.isInitialized());
		/*if(GB_GATHER_HTTP_CLIENTS_STATS){
			callStats(GB_CALL_STATS_DELAY_TIME);
		}*/
	}
	
	/**
	 * Create a GET request with json as contenttype and accepttype.  Make a call to the given uri.
	 * 
	 * @param uri
	 * @return response of the call as String.  If timeout error is received, returns TIMEOUT ERROR
	 */
	public String processGet(URI uri) {
		String returnJson = "";
		try {
			final HttpRequest request = new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.GET, uri.toString());
			HttpHeaders.setHeader(request, HttpHeaders.Names.CONTENT_TYPE, "application/json");
			HttpHeaders.setHeader(request, HttpHeaders.Names.ACCEPT, "application/json");

			HttpHeaders.addHeader(request,"AuthId", "ovg5Zf4ee0K418JfpQcBBg==");
			HttpHeaders.setHost(request, uri.getHost());    
			HttpHeaders.setKeepAlive(request, true);
			
			//old line
			//HttpHeaders.setHost(request, uri.getHost()+(uri.getPort()==-1?null:":"+uri.getPort()));
			
			return processRequestWithRetryCheck(uri, request);
			
		} catch (CannotExecuteRequestException e) {
			log.severe("Connection refused");
			log.severe(e.getMessage());
		} catch (Throwable t) {
			log.severe("Error in connection for : "+uri);
			log.severe("Error sending the message :::"+t.getMessage());

		}
		return returnJson;
	}

	/**
	 * Hits the request(GET/POST).  If retry flag has been set and error occurs, hits the request once again
	 * @param uri - URI to hit
	 * @param request - Request params and body
	 * @return response of request
	 */
	private String processRequestWithRetryCheck(URI uri,HttpRequest request){
		
		RequestFuture<String> future = procressRequest(uri, request);
		String returnJson = null;
		if(!future.hasSuccessfulResponse() && LoadProperties.retryCallFlag)
		{
			System.out.println("Retrying request ... "+uri.toString());
			future =  procressRequest(uri, request);
		}
		
		if (future.hasSuccessfulResponse()) {
			returnJson = future.getProcessedResult();
			//System.out.println("return ::" + returnJson);
			if(uri.getHost().equals("contentapi.prod.global.s.com")){
				System.out.println("Header(Server): "+future.getResponse().getHeaders("Server"));
			}
		} else{

				returnJson = future.getProcessedResult();
				if(returnJson.contains("TIME OUT ERROR"))
					returnJson = "TIME OUT ERROR";
		}
		return returnJson;
		
	}
	
	/**
	 * Hits one request.  Logs error if failed.
	 * @param uri - URI to hit
	 * @param request - Request params and body
	 * @return Future object which contains result.
	 */
	private RequestFuture<String> procressRequest(URI uri,HttpRequest request)
	{
		final RequestFuture<String> future = httpclient.execute(uri.getHost(), (uri.getPort() == -1?80:uri.getPort()), request, new BodyAsStringProcessor());
		future.awaitUninterruptibly();
		if (!future.hasSuccessfulResponse()) {
								
			log.severe("Error Message        ::" + future.getCause());
			log.severe("RequestFuture Object ::" + future);
			log.severe("Request Object       ::" + request);
		}

		return future;
	}

	public void afterPropertiesSet() throws Exception {
		initialize();

	}

	public void destroy() throws Exception {
		try{
			if(httpclient != null){
				httpclient.terminate();
			}
		}catch(Throwable t){
			log.severe("Error terminating HttpClient Object");
		}
	}

	public String processPost(URI uri, String body) {
		String returnJson = "";
		try {
			final HttpRequest postRequest = new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST, uri.toString());

			HttpHeaders.setHeader(postRequest, HttpHeaders.Names.CONTENT_TYPE, "application/json");
			HttpHeaders.setHost(postRequest, uri.getHost()+(uri.getPort()==-1?null:":"+uri.getPort()));
			HttpHeaders.setKeepAlive(postRequest, true);
			postRequest.setHeader(HttpHeaders.Names.CONTENT_LENGTH, body.length());

			postRequest.setContent(ChannelBuffers.copiedBuffer(body, Charset.defaultCharset()));
			
			return processRequestWithRetryCheck(uri, postRequest);
			
		} catch (CannotExecuteRequestException e) {
			log.severe("Connection refused");
			log.severe(e.getMessage());
		} catch (Throwable t) {
			log.severe("Error in connection for : "+uri);
			log.severe("Error sending the message :::"+t.getMessage());

		}
		return returnJson;
	}


	public String processPostXml(URI uri, String body) {
		
		String returnJson = "";
		try {
			final HttpRequest postRequest = new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST, uri.toString());

			HttpHeaders.setHeader(postRequest, HttpHeaders.Names.CONTENT_TYPE, "application/xml");
			HttpHeaders.setHost(postRequest, uri.getHost()+(uri.getPort()==-1?null:":"+uri.getPort()));
			HttpHeaders.setKeepAlive(postRequest, true);
			postRequest.setHeader(HttpHeaders.Names.CONTENT_LENGTH, body.length());

			postRequest.setContent(ChannelBuffers.copiedBuffer(body, Charset.defaultCharset()));
			
			return processRequestWithRetryCheck(uri, postRequest);
			
		} catch (CannotExecuteRequestException e) {
			log.severe("Connection refused");
			log.severe(e.getMessage());
		} catch (Throwable t) {
			log.severe("Error in connection for : "+uri);
			log.severe("Error sending the message :::"+t.getMessage());

		}
		return returnJson;
	}




}
