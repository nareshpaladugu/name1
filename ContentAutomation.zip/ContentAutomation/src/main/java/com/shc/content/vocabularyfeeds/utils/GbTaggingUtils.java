package com.shc.content.vocabularyfeeds.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.shc.content.vocabularyfeeds.pojos.ProductVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;

public class GbTaggingUtils {

	public static ProductVO createProduct(String productId, String productName) {
		ProductVO product = new ProductVO();
		product.setId(productId);
		product.setName(productName);
		return product;
	}

	public static VocabularyTermVO createVocabularyTerm(String vocId,
			String vocName, String displayPath, String parentId,
			String actvDate, String expDate, String action) {

		VocabularyTermVO vocTerm = new VocabularyTermVO();
		vocTerm.setId(vocId);
		vocTerm.setName(vocName);
		vocTerm.setParentId(parentId);
		vocTerm.setDisplayPath(displayPath);
		vocTerm.setActivationDate(actvDate);
		vocTerm.setExpiryDate(expDate);
		vocTerm.setAction(action);
		return vocTerm;

	}

	/**
	 * @author dsebast
	 * @param str	
	 * @return str
	 * @throws Exception 
	 */
	public String getcurrentTime(String formatter) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(formatter);
		Date date = new Date();
		String currentdate;
		try {
			currentdate = dateFormat.format(date);
		} catch (Exception e) {
			System.out.println("Error while parsing to date object...."+ e);
			throw new Exception("Error while parsing to date object..........." , e);
		}
		return currentdate;
	}

	public static String getDateAsPerISOFormat(Date inputDate) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(GBTaggingConstants.ISO_8601_DATE_FORMAT);
		String inputDateInIsoFormat;
		try {
			inputDateInIsoFormat = dateFormat.format(inputDate);
		} catch (Exception e) {
			System.out.println("Error while parsing to date object...."+ e);
			throw new Exception("Error while parsing to date object..........." + e);
		}
		return inputDateInIsoFormat;
	}

}
