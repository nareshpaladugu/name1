package com.shc.content.listeners;

import static com.shc.content.listeners.ListenerConstants.ID_FAILED_COUNT;
import static com.shc.content.listeners.ListenerConstants.ID_TOTAL_COUNT;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;
import org.testng.internal.TestResult;

import com.shc.autocontent.softasserts.CompareValuesUtility;

/**
 * 
 * @author Niharika Varshney
 *
 */
public class MethodListeners implements IInvokedMethodListener {

	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		CompareValuesUtility.init();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		if(CompareValuesUtility.getTotalFailedResultsCount() > 0){
			testResult.setStatus(TestResult.FAILURE);
			testResult.setThrowable(new Throwable(CompareValuesUtility.getFailedResultsSize()+ " Ids failed"));
		}
		testResult.setAttribute(ID_FAILED_COUNT, CompareValuesUtility.getTotalFailedResultsCount());
		testResult.setAttribute(ID_TOTAL_COUNT, CompareValuesUtility.getTotalResultsCount());

		CompareValuesUtility.teardown();
	}
}
