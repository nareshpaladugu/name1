package com.shc.content.listeners;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;

public class Styles
{
	Font failFont, headerFont;
	CellStyle failStyle;
	CellStyle headerStyle;
	CellStyle  subHeaderStyle;

	public Styles( HSSFWorkbook resultWorkBook)
	{
		failFont = resultWorkBook.createFont();
		failFont.setBoldweight(Font.BOLDWEIGHT_BOLD);

		failFont.setColor(Font.COLOR_RED);
		failStyle = resultWorkBook.createCellStyle();
		failStyle.setFont(failFont);
		failStyle.setDataFormat((short)1);

		headerStyle = resultWorkBook.createCellStyle();
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerFont = resultWorkBook.createFont();
		headerFont.setFontHeightInPoints((short) 10);
		headerFont.setFontName(HSSFFont.FONT_ARIAL);
		headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		headerStyle.setFillForegroundColor(HSSFColor.AQUA.index);
		headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		headerStyle.setFont(headerFont);
		headerStyle.setBorderTop(XSSFCellStyle.BORDER_THICK);
		headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);

		subHeaderStyle = resultWorkBook.createCellStyle();
		subHeaderStyle.cloneStyleFrom(headerStyle);
		subHeaderStyle.setFillForegroundColor(HSSFColor.WHITE.index);
		subHeaderStyle.setBorderTop(XSSFCellStyle.BORDER_NONE);
	}
}