package com.shc.content.vocabularyfeeds.pojos;


public class VocabularyAssociationVO {

	public ProductVO productAssociatedTerm;
	public VocabularyTermVO vocTermAssociatedTerm;
	
	public ProductVO getProductAssociatedTerm() {
		return productAssociatedTerm;
	}
	public void setProductAssociatedTerm(ProductVO productAssociatedTerm) {
		this.productAssociatedTerm = productAssociatedTerm;
	}
	public VocabularyTermVO getVocTermAssociatedTerm() {
		return vocTermAssociatedTerm;
	}
	public void setVocTermAssociatedTerm(VocabularyTermVO vocTermAssociatedTerm) {
		this.vocTermAssociatedTerm = vocTermAssociatedTerm;
	}
}