package com.shc.content.webdriver.html;

public class Button extends AbstractBaseElement{

	public Button(String locator, String elementName) {
		super(locator, elementName);
	}
	

}
