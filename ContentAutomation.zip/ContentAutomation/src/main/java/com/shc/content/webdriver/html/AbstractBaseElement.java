package com.shc.content.webdriver.html;

import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shc.autocontent.LoadProperties;
import com.shc.content.webdriver.DriverInitializer;
import com.shc.content.webdriver.assertions.DriverLogger;
/**
 * Base Element class.  All html elements extend this class
 * @author Niharika Varshney
 *
 */
public  class AbstractBaseElement {
	private String locator;
	private String controlName;
	private By byType;
	private DriverLogger logger;
	private static RandomElement pageLoadingImage = null;
			
	public String getControlName() {
		return controlName;
	}

	public void setControlName(String controlName) {
		this.controlName = controlName;
	}

	public By getByType() {
		return byType;
	}

	public String getLocator() {
		return locator;
	}



	AbstractBaseElement(String locator, String elementName){
		System.out.println(elementName);
		this.locator = locator;
		this.controlName = elementName;
		this.byType = ElementHelper.figureOutBy(this.locator);
		logger = new DriverLogger();
	}



	/**
	 * Finds an element based on it's locator
	 * @return RemoteWebElement matching the locator
	 */
	public RemoteWebElement findElement() {
		RemoteWebElement foundElement = null;
		try{
			foundElement = (RemoteWebElement)DriverInitializer.driver().findElement(getByType());
		}catch(NoSuchElementException e){
			//        	 logger.logFailed("Element not found "+ this.controlName);
			throw e;
		}

		return foundElement;
	}

	/**
	 * 
	 * @return list of webelements matching locator
	 */
	public List<WebElement> findElements() {
		List<WebElement> foundElements = null;
		try {
			foundElements = DriverInitializer.driver().findElements(getByType());
		} catch (NoSuchElementException e){
			logger.logFailed("Element not found "+ this.controlName);
			throw e;
		}

		return foundElements;
	}


	/**
	 * Checks if element is present on page.  Does not check visibility, selectability.
	 * 
	 * @return True if element is present, false otherwise.
	 */
	public boolean isElementPresent() {
		boolean returnValue = false;
		try {
			if (findElement() != null) {
				returnValue = true;
			}
		} catch (NoSuchElementException e) {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * Checks visibility of element
	 * @return true if element is visible, false otherwise
	 */
	public boolean isVisible(){
		try{
			if(findElement().isDisplayed() == true)
				return true;
			else
				return false;
		}catch(NoSuchElementException e){
			return false;
		}
	}

	/**
	 * Is the element currently enabled or not? This will generally return true for everything but disabled input elements.
	 * @return true if element is enabled, false otherwise
	 */
	public boolean isEnabled(){
		return findElement().isEnabled();
	}


	/**
	 * Finds element on the page and gets the visible (i.e. not hidden by CSS) innerText of this element, 
	 * including sub-elements, without any leading or trailing whitespace.
	 * 
	 * @return The innerText of this element.
	 */
	public String getText() {
		return findElement().getText();
	}

	/**
	 * Finds element on the page and gets the value of a the given attribute of the element. 
	 * Will return the current value, even if this has been modified after the page has been loaded. 
	 * <br>Returns null if attribute is not found
	 * 
	 * @return The innerText of this element.
	 */
	public String getAttribute(String attributeName) {
		try{
			try{
				return findElement().getAttribute(attributeName);
			}	 catch(StaleElementReferenceException e){
				findElement().click();
			}	 
		}catch(Exception e){
			logger.logFailed("Unable to find attribute of "+ this.controlName + " Exception : "+ExceptionUtils.getMessage(e));
			throw e;
		}
		return null;
	}



	/**
	 * Clicks the element
	 */

	public void click() {
		try{
			try{
				// Wait if loading image is displayed
				pageLoadingImage = (pageLoadingImage != null ? pageLoadingImage : new RandomElement("id=j_idt70_modal", "Page Loading Image"));
				WaitUtils.waitUntilElementIsInVisible(pageLoadingImage);
				findElement().click();
			}catch(StaleElementReferenceException e){
				findElement().click();
			}
		}catch(WebDriverException e){
			try{
				Actions actions = new Actions(DriverInitializer.driver());
				actions.moveToElement(findElement()).click().perform();
			}catch(WebDriverException e1){
				logger.logFailed("Unable to click on "+ this.controlName);
				throw e1;
			}
		}
	}

	/**
	 * Clicks the element and waits for the specified object
	 * @param expectedData - Can be <br>
	 * 1. String - locator <br>
	 * 2. AbstractBaseElement <br>
	 * 3. ExpectedConditions 
	 */
	public void click(Object expectedData){
		this.click();
		if (expectedData instanceof ExpectedCondition<?>) {
			WaitUtils.waitUntil(ExpectedCondition.class.cast(expectedData));
		}
		if (expectedData instanceof AbstractBaseElement) {
			AbstractBaseElement a = (AbstractBaseElement) expectedData;
			WaitUtils.waitUntilElementIsVisible(a.getByType(), a.getControlName());
		}
		if (expectedData instanceof String) {
			WaitUtils.waitUntilElementIsVisible((String)expectedData);
		}
	}        


	/**
	 * A point, containing the location of the top left-hand corner of the element
	 * @param expectedData
	 */
	public Point getLocation(){
		return findElement().getLocation();

	} 


	/**
	 * Formats the locator.  Replaces the {0} string with the {@code toReplace} value 
	 * @param toReplace
	 * @return 
	 */
	public AbstractBaseElement formatOption(String toReplace){
		AbstractBaseElement formattedElement = null;
		try {
			formattedElement = this.getClass().getConstructor(String.class, String.class).
					newInstance(MessageFormat.format(this.locator.replaceAll("'", "''"), toReplace), this.controlName+" "+ toReplace);
		} catch (IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return formattedElement;
	}
}
