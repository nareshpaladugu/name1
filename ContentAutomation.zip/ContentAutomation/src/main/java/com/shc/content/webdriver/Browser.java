package com.shc.content.webdriver;
public enum Browser {
    FIREFOX("*firefox"),
    INTERNET_EXPLORER("*iexplore"),
    HTMLUNIT("*htmlunit"),
    CHROME("*chrome"),
    PHANTOMJS("*phantomjs");

    private String browser;

    private Browser(String browser) {
        this.browser = browser;
    }

    /**
     * Returns the browser as a string
     * 
     */
    public String getBrowser() {
        return this.browser;
    }

   
    /**
     * @param browser - Browser string from properties file
     * @return - {@link Browser} enum that represents a browser.
     */
    public static Browser getBrowser(String browser) {
        for (Browser currentBrowser : Browser.values()) {
            if (currentBrowser.getBrowser().equalsIgnoreCase(browser)) {
                return currentBrowser;
            }
        }
        // No corresponding browser was found. Throwing an exception
        StringBuilder errorMsg = new StringBuilder();
        errorMsg.append("Browser name \'").append(browser).append("\' not supported.\n");
        

        IllegalArgumentException e = new IllegalArgumentException(errorMsg.toString());
        throw e;
    }
}
    