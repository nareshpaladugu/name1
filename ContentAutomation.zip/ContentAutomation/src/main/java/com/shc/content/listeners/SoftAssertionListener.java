package com.shc.content.listeners;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.assertions.SoftAsserts;

public class SoftAssertionListener implements IInvokedMethodListener{

	
	@Override
	public void beforeInvocation(IInvokedMethod arg0, ITestResult testResult) {
	
		SoftAsserts testAssertions= new SoftAsserts(arg0.getTestMethod().getMethodName());
		testResult.setAttribute(Asserts.RESULT, testAssertions);
		testResult.setAttribute(Asserts.LOGGER, new DriverLogger());
	}
	
	@Override
	public void afterInvocation(IInvokedMethod arg0, ITestResult testResult) {
		
		SoftAsserts testAssertions = (SoftAsserts) testResult.getAttribute(Asserts.RESULT);
		testAssertions.assertAll();
		
		
	}


}
