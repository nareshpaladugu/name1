package com.shc.content.vocabularyfeeds.pojos;

import java.util.Date;

import com.fasterxml.jackson.databind.util.ISO8601DateFormat;

public class VocabularyTermVO {

	public String parentId;
	public String displayPath;
	public String name;
	public String id;
	public String activationDate;
	public String expiryDate;
	public String action;
	
	public boolean isoDateSet=false;
	// spinIdPath will be derived while creating the hierarchy(Doubly linked list).
	
	public String spinIdPath;

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getDisplayPath() {
		return displayPath;
	}

	public void setDisplayPath(String displayPath) {
		this.displayPath = displayPath;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
	public String getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSpinIdPath() {
		return spinIdPath;
	}

	public void setSpinIdPath(String spinIdPath) {
		this.spinIdPath = spinIdPath;
	}

	public Boolean hasParent() {
		return parentId != null;
	}

	public boolean isActivationDateIsoFormat() {
		try {
			ISO8601DateFormat df = new ISO8601DateFormat();
			Date date = df.parse(activationDate);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
	
	public boolean isExpiryDateIsoFormat() {
		try {
			ISO8601DateFormat df = new ISO8601DateFormat();
			Date date = df.parse(expiryDate);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public void setIsoDateSet(boolean isoDateSet) {
		this.isoDateSet = isoDateSet;
	}

	
	
	

	
}
