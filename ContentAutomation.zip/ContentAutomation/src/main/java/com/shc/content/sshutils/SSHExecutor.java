package com.shc.content.sshutils;

import java.util.List;

/**
 * Class to execute commands on batchserver
 * @author Niharika Varshney
 *
 */
public class SSHExecutor {
	
	private SSHClient sshClient;

	private SSHClient getSSHClientImpl(){
		if(sshClient == null)
			sshClient = new JSchSSHClientImpl();
		return sshClient;
	}
	
	/**
	 * Use this to initialize connection and execute command.<br>
	 * This method doesn't disconnect by default and the same channel can be used to execute multiple commands.
	 * Make sure to call disconnect 
	 * @param sCommand
	 * @return 
	 */
	public List<String> executeCommand(String sCommand) {
		return getSSHClientImpl().executeCommand(sCommand);
	}
	
	/**
	 * Initializes connection, executes single command and disconnects the session.
	 * @param sCommand
	 */
	public void executeSingleCommand(String sCommand) {
		getSSHClientImpl().executeCommand(sCommand);
		disconnect();
	}
	
	/**
	 * Disconnects the session and the execution channel
	 */
	public void disconnect(){
		getSSHClientImpl().disconnect();
	}
	
	
	
	
	
}
