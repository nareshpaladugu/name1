package com.shc.content.webdriver.html;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table extends AbstractBaseElement {

	public Table(String locator, String elementName) {
		super(locator, elementName);
	}

	public ArrayList<ArrayList<String>> getTable() {

		List<WebElement> tr_table = this.findElements();

		ArrayList<ArrayList<String>> table = new ArrayList<ArrayList<String>>();

		int row_num, col_num;

		row_num = 1;

		for (WebElement trElement : tr_table) {

			ArrayList<String> tableRows = new ArrayList<String>();

			List<WebElement> td_table = trElement.findElements(By.xpath("td"));

			col_num = 1;

			for (WebElement tdElement : td_table) {

				col_num++;

				tableRows.add(tdElement.getText());

			}

			table.add(tableRows);

			row_num++;
		}

		return table;
	}
	
	
	//store web element
	public ArrayList<ArrayList<WebElement>> getTableElements() {

		List<WebElement> tr_table = this.findElements();

		ArrayList<ArrayList<WebElement>> table = new ArrayList<ArrayList<WebElement>>();

		int row_num, col_num;

		row_num = 1;

		for (WebElement trElement : tr_table) {

			ArrayList<WebElement> tableRows = new ArrayList<WebElement>();

			List<WebElement> td_table = trElement.findElements(By.xpath("td"));

			col_num = 1;

			for (WebElement tdElement : td_table) {

				col_num++;

				tableRows.add(tdElement);

			}

			table.add(tableRows);
			
			row_num++;
		}

		return table;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String getCellValue(ArrayList<ArrayList<String>> table, int rowNum,
			int colNum) {

		return table.get(rowNum).get(colNum);
	}

}
