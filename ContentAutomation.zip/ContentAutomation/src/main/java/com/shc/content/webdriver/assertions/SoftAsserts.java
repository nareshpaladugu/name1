package com.shc.content.webdriver.assertions;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;
import org.testng.collections.Maps;

public class SoftAsserts extends Assertion{

	String testName;
	private Map<AssertionError, IAssert<?>> m_errors = Maps.newHashMap();
	private Map<AssertionError, String> mScreenshots = Maps.newHashMap();
	ScreenshotCapturer ssCapture = new ScreenshotCapturer();
	DriverLogger logger ;



	public SoftAsserts(String testName) {
		super();
		this.testName = testName;
		logger = new DriverLogger(testName);
	}

	@Override
	public void executeAssert(IAssert<?> a) {
		try {
			a.doAssert();
			logger.logPassed(a.getMessage());
		} catch(AssertionError ex) {
			String ssFileName = this.generateFileName();
			String fullyQualifiedPathOfScreenshot = ssCapture.saveScreenshot(ssFileName);
			mScreenshots.put(ex,fullyQualifiedPathOfScreenshot);	
			logger.logFailed(ExceptionUtils.getRootCauseMessage(ex));
			m_errors.put(ex, a);
		}
	}

	String generateFileName() {
		return this.testName+ "_"+System.currentTimeMillis();

	}


	/**
	 * Asserts all captured failures to set final result of testcase
	 */
	public void assertAll() {
		if(m_errors.isEmpty())
			return;
		StringBuilder sb =  new StringBuilder("The following asserts failed:\n");
		int assertionCount = 0;
		AssertionError singleAssertionError;
		for (Map.Entry<AssertionError, IAssert<?>> ae : m_errors.entrySet()) {
			singleAssertionError = ae.getKey();
			sb.append("\t")  .append(assertionCount += 1) .append(". ")
			.append(ExceptionUtils.getRootCauseMessage(singleAssertionError))
			.append("\n");

			if (Reporter.getCurrentTestResult() != null) {
				sb.append(StringUtils.substringBetween(ExceptionUtils.getStackTrace(singleAssertionError), "\n",
						"\tat sun.reflect").replace("\t", "\t\t"));
			}
			else {
				sb.append(StringUtils.substringAfter(ExceptionUtils.getStackTrace(singleAssertionError),"\n").replace("\t", "\t\t"));
			}



		}
		sb.append("\t]");

		if (Reporter.getCurrentTestResult() != null) {
			AssertionError custom = new AssertionError(sb.toString());
			custom.setStackTrace(new StackTraceElement[]{new StackTraceElement("SoftAsserts", "AssertAll", "All", 1)});
			Reporter.getCurrentTestResult().setThrowable(custom);
			Reporter.getCurrentTestResult().setStatus(ITestResult.FAILURE);
			Reporter.log("<br><b>Summary</b><br>");
			Reporter.log(sb.toString());
		} else {
			throw new AssertionError(sb.toString());
		}

	}


}
