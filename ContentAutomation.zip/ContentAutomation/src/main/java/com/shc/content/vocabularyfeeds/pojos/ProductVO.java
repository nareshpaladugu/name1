package com.shc.content.vocabularyfeeds.pojos;

import java.util.ArrayList;
import java.util.List;

public class ProductVO {

	public String name;
	public String id;
	public List<HierarchyVO> relatedList = new ArrayList<>();
	public List<HierarchyVO> deletedList = new ArrayList<>();
	public List<HierarchyVO> linkedVocabularyList = new ArrayList<>();
	public List<HierarchyVO> deletedLinkedVocabularyList = new ArrayList<>();
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<HierarchyVO> getRelatedList() {
		return relatedList;
	}

	public void setRelatedList(List<HierarchyVO> relatedList) {
		this.relatedList = relatedList;
	}

	public List<HierarchyVO> getDeletedList() {
		return deletedList;
	}

	public void setDeletedList(List<HierarchyVO> deletedList) {
		this.deletedList = deletedList;
	}

//	public Set<VocTags> getInsertVocTagList() {
//		return insertVocTagList;
//	}
//
//	public void setInsertVocTagList(Set<VocTags> insertVocTagList) {
//		this.insertVocTagList = insertVocTagList;
//	}
//
//	public Set<VocTags> getDeleteVocTagList() {
//		return deleteVocTagList;
//	}
//
//	public void setDeleteVocTagList(Set<VocTags> deleteVocTagList) {
//		this.deleteVocTagList = deleteVocTagList;
//	}

	public List<HierarchyVO> getLinkedVocabularyList() {
		return linkedVocabularyList;
	}

	public void setLinkedVocabularyList(List<HierarchyVO> linkedVocabularyList) {
		this.linkedVocabularyList = linkedVocabularyList;
	}

	public List<HierarchyVO> getDeletedLinkedVocabularyList() {
		return deletedLinkedVocabularyList;
	}

	public void setDeletedLinkedVocabularyList(List<HierarchyVO> deletedLinkedVocabularyList) {
		this.deletedLinkedVocabularyList = deletedLinkedVocabularyList;
	}

	
}
