package com.shc.content.webdriver.html;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;



public class SelectList extends AbstractBaseElement{

	public SelectList(String locator, String elementName) {
		super(locator, elementName);
	}
	
	/**
	 * Returns the Select element
	 * @return
	 */
	public Select getSelectBox(){
		return new Select((WebElement)findElement());
	}
	/**
	 * Selects by value from a selectbox
	 * @return
	 */
	public void selectByValue(String value){
		
		getSelectBox().selectByValue(value);
	}
	
	
	public void multiSelectByValue(String[] values){
		
		for(String value : values)
			getSelectBox().selectByValue(value);
	}
	/**
	 * Selects by index from a selectbox
	 */
	public void selectByIndex(int value){
		getSelectBox().selectByIndex(value);
	}
	
	/**
	 * Selects multiple value by indices
	 * @param values - array of indices to select
	 */
	public void multiSelectByIndex(int[] values){
		
		for(int value : values)
			getSelectBox().selectByIndex(value);
	}
	
	/**
	 * Selects by visible text from a selectbox
	 */
	public void selectByText(String value){
		getSelectBox().selectByVisibleText(value);
	}
	
	/**
	 * Selects multiple value by visible text
	 * @param values - array of texts to select
	 */
	public void multiSelectByText(String[] values){
		
		for(String value : values)
			getSelectBox().selectByVisibleText(value);
	}
	
	
	/**
	 * Deselects all options
	 */
	public void deselectAll(){
		getSelectBox().deselectAll();
	}
	
	/**
	 * Returns a list of webelements which are selected
	 * @return - List of elements selected
	 */
	public List<WebElement> getSelectedOptions(){
		return getSelectBox().getAllSelectedOptions();
	}
	
}
