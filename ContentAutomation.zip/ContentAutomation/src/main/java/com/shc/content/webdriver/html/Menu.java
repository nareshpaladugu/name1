package com.shc.content.webdriver.html;

public class Menu extends AbstractBaseElement{

	public Menu(String locator, String elementName) {
		super(locator, elementName);
	}
	

}
