package com.shc.content.restutils;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.message.BasicNameValuePair;

import com.shc.autocontent.ContentLogger;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;


public class RestAPIs {

	private static final String GET_BUCKETS = "gbox/gb/s/data/get-buckets/";
	private static final String GET_BY_KEY = "gbox/gb/s/data/get/";
	private static final String RANKING_SERVICE = "ranking-service/v2/group";
	private static final String GET_IDS = "gbox/gb/s/data/get-ids/";
	private static final String GETBY_ALT_KEY = "gbox/gb/s/data/get-by-alt-key/";
	private static final String FILTER_IDS = "gbox/gb/s/data/filter-ids/";
	private static final String PROTOCOL = "http://";
	private static final String BASE_URI = PROTOCOL+LoadProperties.GREENVIP+"/";
	private static String ACME_BASE_URI = "http://"+LoadProperties.IA_SERVER;
	private static ContentLogger logger = ContentLogger.getLogger();
	
	public static URI getAcmeURI(CollectionValues c, String id ){
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(ACME_BASE_URI);
			uri = u.setPath("/acme/"+c.getCollection()+"/"+id).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for acme service. Please check details", e.getCause());
		} 
		System.out.println(uri);
		return uri;
		
	}
	
	public static URI getAltAcmeURI(CollectionValues c, String key, String value ){
		NameValuePair nvp = new BasicNameValuePair(key, value);
		List<NameValuePair> keyValues = new ArrayList<>();
		keyValues.add(nvp);
		return getAcmeParametrizedURL(c, keyValues);
		
	}
	
	public static URI getAcmeMultiDocFetchURI(CollectionValues c, String pageSize, String pageNum ){
		NameValuePair pageSizeKey = new BasicNameValuePair("page-size", pageSize);
		NameValuePair pageNumKey = new BasicNameValuePair("page", pageNum);
		List<NameValuePair> keyValues = new ArrayList<>();
		keyValues.add(pageSizeKey);
		keyValues.add(pageNumKey);
		
		return getAcmeParametrizedURL(c, keyValues);
		
		
	}
	
	
	
	public static URI getAcmeParametrizedURL(CollectionValues c, List<NameValuePair> keyValues ){
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(ACME_BASE_URI);
			uri = u.setPath("/acme/"+c.getCollection()).setParameters(keyValues).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for acme service. Please check details", e.getCause());
		} 
		System.out.println(uri);
		return uri;
		
	}
	
	public static URI getBucketsURI(CollectionValues c){
		
		StringBuffer bucketsURI = new StringBuffer(BASE_URI);
		URI uri = null;
		try {
			uri = new URI(bucketsURI.append(GET_BUCKETS).append(c.getCollection()).toString());
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed. Please check details", e.getCause());
		}
		logger.fine(uri.toString());
		return uri;
	}
	
		
	/**
	 * Returns URI for getting ids for specified bucket from collection
	 * @param c
	 * @param sBucketID
	 * @return
	 */
	public static URI getIDsURI(CollectionValues c, int sBucketID){
		
		StringBuffer idsURI = new StringBuffer(BASE_URI);
		URI uri = null;
		try {
			uri = new URI(idsURI.append(GET_IDS).append(c.getCollection()).append("/").append(sBucketID).toString());
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed. Please check details", e.getCause());
		}
//		System.out.println(uri.toString());
		return uri;
	}
	
	/**
	 * Returns get by key uri for a given collection and and id
	 * @param Collection
	 * @return
	 */
	public static URI getIDsURI(String custombaseURI,CollectionValues c, int iBucketId){
		URI uri = null;
		try {
			StringBuffer u = new StringBuffer(PROTOCOL+custombaseURI+"/");
			uri = new URI(u.append(GET_IDS).append(c.getCollection()).append("/").append(iBucketId).toString());
			System.out.println(uri);
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for getById uri. Please check details", e.getCause());
		} 
		return uri;
	}
	
	
	/**
	 * Returns URI for getting ids within requested timestamps
	 * @param c - Collection to query on
	 * @param sBucketID - Bucket id 
	 * @param sFrom - From timestamp - current format 2013-11-09 T 11:20 UTC
	 * @param sTo - optional - To timestamp
	 * @return URI
	 */
	public static URI getIDsWithinTimeStamp(CollectionValues c, int sBucketID,String sFrom, String... sTo){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			u.setPath("/"+GET_IDS+c.getCollection()+"/"+sBucketID).setParameter("from", sFrom);
			if(sTo.length > 0)
				u.setParameter("to", sTo[0]);
			uri = u.build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns ranking service uri for groupid
	 * @param sGroupId
	 * @return
	 */
	public static URI getRankingServiceURI(String sGroupId){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(PROTOCOL+LoadProperties.RANKING_SERVICE);
			uri = u.setPath("/"+RANKING_SERVICE).setParameter("groupId", sGroupId).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for ranking service. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns get by key uri for a given collection and and id
	 * @param Collection
	 * @return
	 */
	public static URI getByIdURI(CollectionValues c,String sID){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GET_BY_KEY+c.getCollection()+"/"+sID).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for ranking service. Please check details", e.getCause());
		} 
		return uri;
	
	}
	
	/**
	 * Creates the fitment status uri
	 * @param Collection
	 * @return
	 */
	public static URI formFitmentURI(){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder("http://fitmentvip.prod.ch4.s.com:80/");
			uri = u.setPath("/fit/v1/fitment/status").build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for fitment service. Please check details", e.getCause());
		} 
		return uri;
	
	}
	
	/**
	 * Constructs a URI object from string </br>
	 * Returns null if issue with parsing.
	 * @param uriString
	 * @return
	 */
	public static URI buildURI(String uriString){
		
		URI u;
		try {
			u = new URI(uriString);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return u;
	}
	
	/**
	 * Returns get by key uri for a given collection and and id
	 * @param Collection
	 * @return
	 */
	public static URI getByIdURI(String custombaseURI,CollectionValues c,String sID){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(PROTOCOL+custombaseURI+"/");
			uri = u.setPath("/"+GET_BY_KEY+c.getCollection()+"/"+sID).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for getById uri. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns ranking service uri for groupid
	 * @param sGroupId
	 * @return
	 */
	public static URI getByIdURI(CollectionValues c,Long lID){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GET_BY_KEY+c.getCollection()+"/"+lID).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for ranking service. Please check details", e.getCause());
		} 
		return uri;
	}
	
	public static URI getByIdURI(String c,String lID){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GET_BY_KEY+c+"/"+lID).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for ranking service. Please check details", e.getCause());
		} 
		return uri;
	}

	/**
	 * Returns uri for multiple ids
	 * @param collection
	 * @param lstIds
	 * @return
	 */
	public static URI getByIdURI(String customBaseURI, CollectionValues collection,
			List<String> lstIds) {
		String multiIdList ="" ;
		URI uri = null;
		for(String sID : lstIds)
			multiIdList += ("/"+ sID);
		try {
			if(!customBaseURI.startsWith("http"))
				customBaseURI="http://"+customBaseURI;
			URIBuilder u = new URIBuilder(customBaseURI+"/");
			uri = u.setPath("/"+GET_BY_KEY+collection.getCollection()+multiIdList).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for multiple ids uri. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns uri for multiple ids
	 * @param collection
	 * @param lstIds
	 * @return
	 */
	public static URI getByIdURI(CollectionValues collection,
			List<String> lstIds) {
		
		return getByIdURI(BASE_URI, collection, lstIds);
		/*String multiIdList ="" ;
		URI uri = null;
		for(String sID : lstIds)
			multiIdList += ("/"+ sID);
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GET_BY_KEY+collection.getCollection()+multiIdList).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for multiple ids uri. Please check details", e.getCause());
		} 
		return uri;*/
	}
	
	/**
	 * Returns URI for get By Alt key api
	 * @param key - the alt key
	 * @param value - value of the alt key
	 * @return 
	 */
	public static URI getByAltKey(CollectionValues c,String key, String value){
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GETBY_ALT_KEY+c.getCollection()).setParameter(key,value).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for alt key. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns URI for multiple get by alt keys
	 * @param c - Collection
	 * @param queryParams - get by alt key & values
	 * @return
	 */
	public static URI getByAltKey(CollectionValues c, HashMap<String, String> queryParams){
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			for (String key : queryParams.keySet()) {
				u.setPath("/"+GETBY_ALT_KEY+c.getCollection()).setParameter(key,queryParams.get(key));
			}
			uri = u.build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for alt key. Please check details", e.getCause());
		} 
		return uri;
	}

	/**
	 * Returns get by key uri for a given collection and and id
	 * @param Collection
	 * @return
	 */
	public static URI getByAltKey(String custombaseURI,CollectionValues c,String key, String value){
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(PROTOCOL+custombaseURI+"/");
			uri = u.setPath("/"+GETBY_ALT_KEY+c.getCollection()).setParameter(key,value).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for getById uri. Please check details", e.getCause());
		} 
		return uri;
	}
	
	/**
	 * Returns URI for get By Alt key api
	 * @param key - the alt key
	 * @param value - value of the alt key
	 * @return 
	 */
	public static URI getByAltKey(CollectionValues c,String otherEndString){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+GETBY_ALT_KEY+c.getCollection()).setCustomQuery(otherEndString).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed for alt key. Please check details", e.getCause());
		} 
		return uri;
	}
	
	
	/**
	 * Returns URI for filtering ids for specified bucket from collection based on filter criteria
	 * @param c  - Collection to apply filter on
	 * @param sBucketID - Bucket to test
	 * @param key - filter key
	 * @param value - filter value
	 * @return
	 */
	public static URI getFilterIdsURI(CollectionValues c, int sBucketID,String key, String value){
		
		URI uri = null;
		try {
			URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+FILTER_IDS+c.getCollection()+"/"+sBucketID).setParameter(key,value).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed. Please check details", e.getCause());
		}
		return uri;
	}
	
	public static URI getFilterIdsURI(String customGb, CollectionValues c, int sBucketID,String key, String value){
		
		URI uri = null;
		try {
			
			URIBuilder u = new URIBuilder(PROTOCOL+customGb+"/");
			
			//URIBuilder u = new URIBuilder(BASE_URI);
			uri = u.setPath("/"+FILTER_IDS+c.getCollection()+"/"+sBucketID).setParameter(key,value).build();
		} catch (URISyntaxException e) {
			throw new RestExecutionException("Rest URI creation failed. Please check details", e.getCause());
		}
		System.out.println(uri.toString());
		return uri;
	}
	
}
