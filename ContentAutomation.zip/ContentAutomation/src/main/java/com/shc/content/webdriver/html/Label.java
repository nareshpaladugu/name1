package com.shc.content.webdriver.html;

import org.openqa.selenium.support.ui.ExpectedConditions;

public class Label extends AbstractBaseElement{

	public Label(String locator, String elementName) {
		super(locator, elementName);
	}

	/**
	 * Return true if text is equal to the text in label
	 * @param textToCheck
	 * @return
	 */
	public boolean isTextPresent(String textToCheck){
		if(this.getText().trim().equals(textToCheck))
			return true;
		return false;
	}

	/**
	 * Return true if label contains the text
	 * @param textToCheck
	 * @return
	 */
	public boolean containsText(String textToCheck){
		try {
			WaitUtils.waitUntilElementContainsText(this, textToCheck);
			if(this.getText().trim().contains(textToCheck))
				return true;
		} catch (Exception e) {}
		return false;
	}
}