package com.shc.content.webdriver.html;

import org.openqa.selenium.remote.RemoteWebElement;

public class TextField extends AbstractBaseElement{

	public TextField(String locator, String elementName) {
		super(locator, elementName);
	}
	
	/**
	 * Use this method to simulate typing into an element, which may set its value.
	 * @param textToType
	 */
	public void sendKeys(String textToType){
		RemoteWebElement textBox = findElement();
		textBox.clear();
		findElement().sendKeys(textToType);
		
	}
	
	public void appendText(String textToAppend){
		findElement().sendKeys(textToAppend);
	}
	
	/**
	 * Clear the value of the textfield
	 */
	public void clear(){
		findElement().clear();
	}
	
	/**
	 * Gets the text in the input field else gets its value
	 * @return Text in the input box
	 */
	public String getText() {
        String text = findElement().getText();
        if (text.isEmpty()) {
            text = getAttribute("value");
        }
        return text;
    }
	
}
