package com.shc.content.vocabularyfeeds.pojos;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.shc.content.vocabularyfeeds.utils.GBTaggingConstants;
import com.shc.content.vocabularyfeeds.utils.GbTaggingUtils;


public class HierarchyVO {
	public NodeVO leaf;
	public NodeVO root;
	public String hierarchyType;
	public boolean isDeleteActionHierarchy;

	public NodeVO getRoot() {
		return root;
	}

	public void setRoot(NodeVO root) {
		this.root = root;
	}

	public String getHierarchyType() {
		return hierarchyType;
	}

	public void setHierarchyType(String hierarchyType) {
		this.hierarchyType = hierarchyType;
	}

	public boolean isDeleteActionHierarchy() {
		return isDeleteActionHierarchy;
	}

	public void setDeleteActionHierarchy(boolean isDeleteActionHierarchy) {
		this.isDeleteActionHierarchy = isDeleteActionHierarchy;
	}

	public void addNode(VocabularyTermVO vocabularyTerm) {
		NodeVO node = new NodeVO(vocabularyTerm);
		if (leaf == null) {
			leaf = node;
			root = node;
		} else {
			root.parentNode = node;
			node.childNode = root;
			node.parentNode = null;
			root = node;
		}
	}
	
	public void generateSpinIdPaths() {
		NodeVO current = root;
		StringBuilder spinIdPathBuilder = new StringBuilder();
		boolean isFirst = true;
		
		//
		while(current != null) {
			if (isFirst) {
				spinIdPathBuilder.append(current.vocabularyTerm.getId());
				current.vocabularyTerm.setSpinIdPath(spinIdPathBuilder.toString());
				isFirst = false;
			} else {
				spinIdPathBuilder.append("|").append(current.vocabularyTerm.getId());
				current.vocabularyTerm.setSpinIdPath(spinIdPathBuilder.toString());
			}
			current = current.childNode;
		}
	}

/*	public void cascadeDate() throws Exception {
		NodeVO current = root;
		String activationDate = null;
		String expiryDate = null;

		// Set default Activation and Expiry date if not present for any vocTerm
		if (root != null) {
			if (StringUtils.isEmpty(root.vocabularyTerm.getActivationDate())) {
				activationDate = GBTaggingConstants.DEFAULT_STARTDATE;
			}
			if (StringUtils.isEmpty(root.vocabularyTerm.getExpiryDate())) {
				expiryDate = GBTaggingConstants.DEFAULT_ENDATE;
			}
		}

		while (current != null) {
			try {
				if (StringUtils.isNotEmpty(current.vocabularyTerm.getActivationDate())) {
					activationDate = current.vocabularyTerm.getActivationDate();
				} else {
					current.vocabularyTerm.setActivationDate(activationDate);
				}

				if (StringUtils.isNotEmpty(current.vocabularyTerm.getExpiryDate())) {
					expiryDate = current.vocabularyTerm.getExpiryDate();
				} else {
					current.vocabularyTerm.setExpiryDate(expiryDate);
				}
				if (!current.vocabularyTerm.isActivationDateIsoFormat()) {
					Date nodeActivationDate = GBTaggingConstants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE.get().parse(
							current.vocabularyTerm.getActivationDate() + GBTaggingConstants.STARTTIME);
					try {
						current.vocabularyTerm.setActivationDate(GbTaggingUtils.getDateAsPerISOFormat(nodeActivationDate));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				if (!current.vocabularyTerm.isExpiryDateIsoFormat()) {
					Date nodeExpiryDate = GBTaggingConstants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE.get().parse(
							current.vocabularyTerm.getExpiryDate() + GBTaggingConstants.ENDTIME);
					try {
						current.vocabularyTerm.setExpiryDate(GbTaggingUtils.getDateAsPerISOFormat(nodeExpiryDate));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			//	current = current.childNode;
			} catch (Exception e) {
				System.out.println("Exception while parsing the date for product id :: "+current.vocabularyTerm.getId());
			}
			current = current.childNode;
		}
	}
*/	
	
	public void cascadeDate() {
		NodeVO current = root;
		String activationDate = null;
		String expiryDate = null;

		// Set default Activation and Expiry date if not present for any vocTerm
		if (root != null) {
			if (StringUtils.isEmpty(root.vocabularyTerm.getActivationDate())) {
				activationDate = GBTaggingConstants.DEFAULT_STARTDATE;
			}
			if (StringUtils.isEmpty(root.vocabularyTerm.getExpiryDate())) {
				expiryDate = GBTaggingConstants.DEFAULT_ENDATE;
			}
		}

		while (current != null) {
			try {
				if (StringUtils.isNotEmpty(current.vocabularyTerm.getActivationDate())) {
					activationDate = current.vocabularyTerm.getActivationDate();
				} else {
					current.vocabularyTerm.setActivationDate(activationDate);
				}

				if (StringUtils.isNotEmpty(current.vocabularyTerm.getExpiryDate())) {
					expiryDate = current.vocabularyTerm.getExpiryDate();
				} else {
					current.vocabularyTerm.setExpiryDate(expiryDate);
				}
				if (!current.vocabularyTerm.isActivationDateIsoFormat()) {
					Date nodeActivationDate = GBTaggingConstants.DATE_FORMAT_MM_DD_YYYY_HH_MM_SS_DATE.get().parse(
							current.vocabularyTerm.getActivationDate() + GBTaggingConstants.STARTTIME);
					current.vocabularyTerm.setActivationDate(GbTaggingUtils.getDateAsPerISOFormat(nodeActivationDate));
				}
				
				if (!current.vocabularyTerm.isExpiryDateIsoFormat()) {
					Date nodeExpiryDate = GBTaggingConstants.DATE_FORMAT_MM_DD_YYYY_HH_MM_SS_DATE.get().parse(
							current.vocabularyTerm.getExpiryDate() + GBTaggingConstants.ENDTIME);
					current.vocabularyTerm.setExpiryDate(GbTaggingUtils.getDateAsPerISOFormat(nodeExpiryDate));
				}
			//	current = current.childNode;
			} catch (Exception e) {
				System.out.println("Exception while parsing the date for product id :: "+current.vocabularyTerm.getId());
			}
			current = current.childNode;
		}
	}

	public void setDeleteActionHierarchy() {
		NodeVO current = root;
		while (current != null) {
			VocabularyTermVO vocabularyTermVO = current.vocabularyTerm;
			if (StringUtils.isNotEmpty(vocabularyTermVO.getAction()) && GBTaggingConstants.ACTION_TYPE_DELETE.equals(vocabularyTermVO.getAction())) {
				isDeleteActionHierarchy = true;
				break;
			} 
			current = current.childNode;
		} 
	}
	
	public String display() {
		StringBuilder str = new StringBuilder();
		NodeVO current = leaf;
		boolean arrow = true;
		do {
			if (arrow) {
				str.append("|" + current.vocabularyTerm.id + "|");
			} else {
				str.append("-->" + "|" + current.vocabularyTerm.id + "|");
			}
			arrow = false;
			current = current.parentNode;
		} while (current != null);
		return str.toString();
	}

	public String displayWithDisplayPath() {
		StringBuilder str = new StringBuilder();
		NodeVO current = leaf;
		boolean arrow = true;
		do {
			if (arrow) {
				str.append("'" + current.vocabularyTerm.getDisplayPath() + "'");
			} else {
				str.append("-->" + "'" + current.vocabularyTerm.getDisplayPath() + "'");
			}
			arrow = false;
			current = current.parentNode;

		} while (current != null);
		return str.toString();
	}

	public String displaySpinIdPath() {
		StringBuilder str = new StringBuilder();
		NodeVO current = leaf;
		boolean arrow = true;
		do {
			if (arrow) {
				str.append(current.vocabularyTerm.getSpinIdPath());
			} else {
				str.append("-->" + current.vocabularyTerm.getSpinIdPath());
			}
			arrow = false;
			current = current.parentNode;
		} while (current != null);
		return str.toString();
	}

	public String displayWithDate() {
		StringBuilder str = new StringBuilder();
		NodeVO current = leaf;
		boolean arrow = true;
		do {
			if (arrow) {
				str.append(current.vocabularyTerm.id + "["
						+ current.vocabularyTerm.getActivationDate() + " , "
						+ current.vocabularyTerm.getExpiryDate() + "]");
			} else {
				str.append("-->" + current.vocabularyTerm.id + "["
						+ current.vocabularyTerm.getActivationDate() + " , "
						+ current.vocabularyTerm.getExpiryDate() + "]");
			}
			arrow = false;
			current = current.parentNode;

		} while (current != null);
		return str.toString();
	}

	public NodeVO getLeafNode() {
		return leaf;
	}
	
	public void printBackward() {
		NodeVO current = leaf;
		boolean arrow = true;
		while (current.parentNode != null) {
			current = current.parentNode;
		}
		do {
			System.out.print((arrow) ? "|" + current.vocabularyTerm + "|" : "-->" + "|"
					+ current.vocabularyTerm + "|");
			arrow = false;
			current = current.childNode;
		} while (current.childNode != null);
		System.out.print("-->" + "|" + current.vocabularyTerm + "|");
	}
}