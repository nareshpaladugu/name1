package com.shc.content.webdriver;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.shc.autocontent.LoadProperties;

public class DriverHelper {

	static DesiredCapabilities getCapabilities(Browser browser){
		DesiredCapabilities capability;
		switch (browser) {
		case FIREFOX:
			capability = DesiredCapabilities.firefox();
			break;
		case CHROME:{
			capability = DesiredCapabilities.chrome();
			System.setProperty("webdriver.chrome.driver", LoadProperties.CHROME_PATH);
			break;
		}
		case INTERNET_EXPLORER:
			capability = DesiredCapabilities.internetExplorer();
		default:
			capability = DesiredCapabilities.chrome();	
		}
		System.out.println("Browser selected is "+ browser);
		return capability;

	}
	
	static  URL getURL(){
		
		String host = LoadProperties.DRIVER_HOST;
		int port = LoadProperties.DRIVER_PORT;
		if (LoadProperties.ISLOCALRUN) {
			host = "localhost";

		}
		URL url = null;

		try {
			url = new URL("http://"+host+":"+port+"/wd/hub");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return url;
	}

}
