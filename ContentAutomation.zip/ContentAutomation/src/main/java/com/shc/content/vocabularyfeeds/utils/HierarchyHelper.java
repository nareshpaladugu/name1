package com.shc.content.vocabularyfeeds.utils;

import org.apache.commons.lang.StringUtils;
import com.shc.content.vocabularyfeeds.pojos.HierarchyVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;


public class HierarchyHelper {

	public HierarchyVO createHierarchy(String vocId, String hierarchyType) {
		HierarchyVO hierarchy = new HierarchyVO();
		hierarchy.hierarchyType = hierarchyType;
		try {
			addNodeToHierarchy(hierarchy, vocId);
		} catch (Exception ex) {
			System.out.println("Exception while creating hierarchy ::" + vocId+ex );
		}
		return hierarchy;
	}

	private void addNodeToHierarchy(HierarchyVO hierarchy, String vocId) {
		VocabularyTermVO vocabularyTermVO = GBTaggingConstants.VOCTERM_MAP.get(vocId);
		if (vocabularyTermVO != null && !StringUtils.equals(vocabularyTermVO.getId(),"10")) {
			hierarchy.addNode(vocabularyTermVO);
			if (vocabularyTermVO.hasParent()) {
				String parentId = vocabularyTermVO.getParentId();
				addNodeToHierarchy(hierarchy, parentId);
			}
		}
	}
}