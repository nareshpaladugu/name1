package com.shc.content.webdriver.html;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ByIdOrName;
import org.openqa.selenium.support.ui.ExpectedCondition;

public class ElementHelper {

	static By figureOutBy(String locator) {
		
        String locatorType = locator.split("=")[0].trim();
        String locatorToReturn = locator.contains("=")?locator.split("=")[1].trim(): locator;
        By identifiedBy;
        switch (locatorType) {
        case "id":
            identifiedBy = By.id(locatorToReturn);
            break;
        case "name":
            identifiedBy = By.name(locatorToReturn);
            break;
        case "link":
            identifiedBy = By.linkText(locatorToReturn);
            break;
        case "xpath":
            identifiedBy = By.xpath(locatorToReturn);
            break;
        case "css":
            identifiedBy = By.cssSelector(locatorToReturn);
            break;
        case "class":
            identifiedBy = By.className(locatorToReturn);
            break;
        default:
            if (locator.startsWith("/") || locator.startsWith("./")) {
                identifiedBy = By.xpath(locator);
                break;
            }
            identifiedBy = new ByIdOrName(locator);
        }
        return identifiedBy;
		
	}
	
	static void commonWaitLogic(Object expectedData){
		 if (expectedData instanceof ExpectedCondition<?>) {
			 WaitUtils.waitUntil(ExpectedCondition.class.cast(expectedData));
		 }
		 if (expectedData instanceof AbstractBaseElement) {
			 AbstractBaseElement a = (AbstractBaseElement) expectedData;
			 WaitUtils.waitUntilElementIsVisible(a.getByType());
		 }
		 if (expectedData instanceof String) {
			 WaitUtils.waitUntilElementIsVisible((String)expectedData);
		 }
	}
}
