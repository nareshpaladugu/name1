package com.shc.content.webdriver.assertions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.shc.autocontent.LoadProperties;
import com.shc.content.webdriver.DriverInitializer;

public class ScreenshotCapturer {

	private final String outputFolder;
	
	

    public ScreenshotCapturer(String testNGOutputFolder) {
        this.outputFolder = testNGOutputFolder;
        
    }
    
    public ScreenshotCapturer() {
        this.outputFolder = LoadProperties.OUTPUTFOLDER;
        File screenshotsDir = new File(outputFolder, "screenshots");
        if(!screenshotsDir.exists())
        	screenshotsDir.mkdir();
    }
    
	private String getScreenshotAbsolutePath(String name) {
        String screenshotPath = "screenshots" + File.separator + name + ".png";
        String screenshotAbsolutePath = outputFolder +File.separator+ screenshotPath;
        return screenshotAbsolutePath;
    }
	
    public String saveScreenshot(String filename) {
        String screenshotAbsolutePath = getScreenshotAbsolutePath(filename);
        try (OutputStream out = new FileOutputStream(screenshotAbsolutePath)) {
            out.write(takeScreenshot(DriverInitializer.driver()));
        } catch (IOException e) {
        	e.printStackTrace();
        }
        String screenshotUrl = "screenshots/" + filename + ".png";
        return screenshotUrl;

    }
    
    static byte[] takeScreenshot(WebDriver driver) {
        try {
            byte[] decodeBuffer = null;

            if (driver instanceof TakesScreenshot) {
                TakesScreenshot screenshot = ((TakesScreenshot) driver);
                String ss = screenshot.getScreenshotAs(OutputType.BASE64);
                decodeBuffer = Base64.decodeBase64(ss.getBytes());
            }
            return decodeBuffer;
        } catch (Exception exception) {
            return null;
        }
    }
}
