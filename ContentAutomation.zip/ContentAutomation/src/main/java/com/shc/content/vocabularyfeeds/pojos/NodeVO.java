package com.shc.content.vocabularyfeeds.pojos;

public class NodeVO {
	
	public VocabularyTermVO vocabularyTerm;
	public NodeVO parentNode;
	public NodeVO childNode;

	public NodeVO(VocabularyTermVO vocabularyTerm) {
		this.vocabularyTerm = vocabularyTerm;
		this.parentNode = null;
		this.childNode = null;
	}
	
	public VocabularyTermVO getVocabularyTerm() {
		return vocabularyTerm;
	}

	public void setVocabularyTerm(VocabularyTermVO vocabularyTerm) {
		this.vocabularyTerm = vocabularyTerm;
	}

	public NodeVO getParentNode() {
		return parentNode;
	}

	public void setParentNode(NodeVO parentNode) {
		this.parentNode = parentNode;
	}

	public NodeVO getChildNode() {
		return childNode;
	}

	public void setChildNode(NodeVO childNode) {
		this.childNode = childNode;
	}
}