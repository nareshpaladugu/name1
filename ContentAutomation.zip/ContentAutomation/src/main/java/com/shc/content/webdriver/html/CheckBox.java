package com.shc.content.webdriver.html;



public class CheckBox extends AbstractBaseElement{

	public CheckBox(String locator, String elementName) {
		super(locator, elementName);
	}
	
	/**
	 * Returns whether the checkbox is selected or not
	 * @return
	 */
	public boolean isChecked(){
		return findElement().isSelected();
	}
	
	/**
	 * Checks the checkbox if not already checked
	 */
	public void check(){
		if(!this.isChecked())
			this.click();
	}
	
	/**
	 * Checks the checkbox and waits for the expecteddata to be true
	 * 
	 * @param expectedData - Can be <br>
	 * 1. String - locator <br>
	 * 2. AbstractBaseElement <br>
	 * 3. ExpectedConditions 
	 */
	public void checkAndWait(Object expectedData){
		if(!this.isChecked())
			this.click(expectedData);
	}
	
	/**
	 * Unchecks the checkbox if it is checked
	 */
	public void uncheck(){
		if(this.isChecked())
			this.click();
		
	}
	
	/**
	 * Unchecks the checkbox and waits for the expecteddata to be true
	 * 
	 * @param expectedData - Can be <br>
	 * 1. String - locator <br>
	 * 2. AbstractBaseElement <br>
	 * 3. ExpectedConditions 
	 */
	public void uncheckAndWait(Object expectedData){
		if(this.isChecked())
			this.click(expectedData);
	}

}
