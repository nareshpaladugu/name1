package com.shc.content.webdriver.assertions;

import org.testng.Reporter;


public class DriverLogger {

	ScreenshotCapturer ssCapture = new ScreenshotCapturer();
	String testName;
	
	/**
	 * Use this if you want the screenshots to be saved with particular title
	 * @param testName
	 */
	public DriverLogger(String testName) {
		
		super();
		this.testName = testName;
	}
	
	/**
	 * Default constructor - would save all screenshots with default_ appended with timestamps
	 */
	public DriverLogger() {
		
		super();
		this.testName = "Default";
	}

	/**
	 * Based on type of status, generates html formatted message for reporter
	 * @param typeOfMessage - 0 for passed, -1 for failure and 1 for normal logged input
	 * @param message - message to be formatted
	 * @return- HTML formatted message
	 */
	private String getMessageString(int typeOfMessage, String message){
		switch(typeOfMessage){
		case 0 :
			return "<br><font color=green><b>PASSED: </b>"+message + "</font>";
		case -1:
			return "<br><font color=red><b>FAILED: </b>"+message + "</font>";
		default :
			return "<br>"+message;
		}
	}
	
	private String takeScreenshotAndGenerateMsg(){
		String fileLocation = ssCapture.saveScreenshot(this.generateFileName());
		return (" <a href="+ fileLocation + " target=\"_blank\">Screenshot</a> </br> ");
	}
	

	private String generateFileName() {
		return this.testName+ "_"+System.currentTimeMillis();

	}

	
	/**
	 * Log passed messages in reporter output
	 * @param message
	 */

	public void logPassed(String message){
		Reporter.log(getMessageString(0, message),true);
	}
	
	
	
	
	
	public void logPassed(String message, boolean bScreenshot){
		if(bScreenshot){
			Reporter.log(getMessageString(0, message)+ takeScreenshotAndGenerateMsg());
		}
		else
			this.logPassed(message);
	}
	
	
	
	

	public void log(String message, boolean screenshot){
		if(screenshot){
			Reporter.log(getMessageString(1, message)+ takeScreenshotAndGenerateMsg());
		}else
			Reporter.log(getMessageString(1, message),true);
	}

	public void logFailed(String rootCauseMessage) {
		
			Reporter.log(getMessageString(-1, rootCauseMessage)+ takeScreenshotAndGenerateMsg());
	}
	
	
}
