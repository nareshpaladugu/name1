package com.shc.content.webdriver.html;

public class DialogBox extends AbstractBaseElement{

	public DialogBox(String locator, String elementName) {
		super(locator, elementName);
	}
	

}
