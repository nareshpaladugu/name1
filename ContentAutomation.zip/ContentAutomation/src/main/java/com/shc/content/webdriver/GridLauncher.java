package com.shc.content.webdriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.grid.common.GridRole;
import org.openqa.grid.common.RegistrationRequest;
import org.openqa.grid.internal.utils.GridHubConfiguration;
import org.openqa.grid.internal.utils.SelfRegisteringRemote;
import org.openqa.grid.web.Hub;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shc.autocontent.LoadProperties;

public class GridLauncher {
	
	private static Hub contentHub;
	private static SelfRegisteringRemote node;
	
	
	public static void setupLocalGrid(){
		try{
			spawnLocalHub();
		}
		catch(Exception e){
			return;
		}
		launchNode();
	}
	
	private static void spawnLocalHub() throws Exception{
		
		GridHubConfiguration hubConfig = new GridHubConfiguration();
		hubConfig.setHost("localhost");
		hubConfig.setPort(4444);
		contentHub = new Hub(hubConfig);
		try {
			contentHub.start();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		
	}

	private static void launchNode(){
		
		Browser browserToExecuteOn = Browser.getBrowser(LoadProperties.BROWSER);
		DesiredCapabilities capability = DriverHelper.getCapabilities(browserToExecuteOn);
		capability.setCapability("maxInstances", 4);
		RegistrationRequest nodeRegRequest = new RegistrationRequest();
		
		nodeRegRequest.setRole(GridRole.NODE);
		try {
			nodeRegRequest.setConfiguration(fetchNodeConfiguration(5555));
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		nodeRegRequest.addDesiredCapability(capability);
		System.out.println(nodeRegRequest.toJSON());
		
		node = new SelfRegisteringRemote(nodeRegRequest);
        
		try {
			node.startRemoteServer();
			node.startRegistrationProcess();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private  static Map<String, Object> fetchNodeConfiguration(int portToRun)
			throws MalformedURLException {
		Map<String, Object> nodeConfiguration = new HashMap<String, Object>();
		nodeConfiguration.put(RegistrationRequest.AUTO_REGISTER, true);
		nodeConfiguration.put(RegistrationRequest.HUB_HOST, "localhost");
		nodeConfiguration.put(RegistrationRequest.HUB_PORT, LoadProperties.DRIVER_PORT);
		nodeConfiguration.put(RegistrationRequest.PORT, portToRun);
		URL remoteURL = new URL("http://localhost:" + portToRun);
		nodeConfiguration.put(RegistrationRequest.PROXY_CLASS,
				"org.openqa.grid.selenium.proxy.DefaultRemoteProxy");
		nodeConfiguration.put(RegistrationRequest.CLEAN_UP_CYCLE, 2000);
		nodeConfiguration.put(RegistrationRequest.REMOTE_HOST, remoteURL);
		
		return nodeConfiguration;
	}
	
	public static void shutdownGrid(){
		node.stopRemoteServer();
		try {
			contentHub.stop();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
