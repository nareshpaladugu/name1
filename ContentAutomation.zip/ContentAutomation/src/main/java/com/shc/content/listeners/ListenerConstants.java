package com.shc.content.listeners;

public class ListenerConstants {

	public static final String ID_FAILED_COUNT = "FailedCount";
	public static final String ID_TOTAL_COUNT = "TotalCount";
//	public static final String ID_FAILED_COUNT = "FailedCount";
}
