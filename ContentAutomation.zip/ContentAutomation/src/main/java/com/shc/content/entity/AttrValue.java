package com.shc.content.entity;

public class AttrValue {
	
	private String displaylabel;
	private String attrSeqence;
	private String stringValue;
	private String seqence;
	
	
	public AttrValue() {
		super();
	}
	
	public AttrValue(String displaylabel, String attrSeqence, String stringValue, String seqence) {
		super();
		this.displaylabel = displaylabel;
		this.attrSeqence = attrSeqence;
		this.stringValue = stringValue;
		this.seqence = seqence;
	}
	public String getDisplaylabel() {
		return displaylabel;
	}
	public void setDisplaylabel(String displaylabel) {
		this.displaylabel = displaylabel;
	}
	public String getAttrSeqence() {
		return attrSeqence;
	}
	public void setAttrSeqence(String attrSeqence) {
		this.attrSeqence = attrSeqence;
	}
	public String getStringValue() {
		return stringValue;
	}
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}
	public String getSeqence() {
		return seqence;
	}
	public void setSeqence(String seqence) {
		this.seqence = seqence;
	}

	@Override
	public String toString() {
		return "AttrValue [displaylabel=" + displaylabel + ", attrSeqence=" + attrSeqence + ", stringValue=" + stringValue + ", seqence=" + seqence + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((attrSeqence == null) ? 0 : attrSeqence.hashCode());
		result = prime * result + ((displaylabel == null) ? 0 : displaylabel.hashCode());
		result = prime * result + ((seqence == null) ? 0 : seqence.hashCode());
		result = prime * result + ((stringValue == null) ? 0 : stringValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AttrValue other = (AttrValue) obj;
		if (attrSeqence == null) {
			if (other.attrSeqence != null)
				return false;
		} else if (!attrSeqence.equals(other.attrSeqence))
			return false;
		if (displaylabel == null) {
			if (other.displaylabel != null)
				return false;
		} else if (!displaylabel.equals(other.displaylabel))
			return false;
		if (seqence == null) {
			if (other.seqence != null)
				return false;
		} else if (!seqence.equals(other.seqence))
			return false;
		if (stringValue == null) {
			if (other.stringValue != null)
				return false;
		} else if (!stringValue.equals(other.stringValue))
			return false;
		return true;
	}
	
	
	
	
}
