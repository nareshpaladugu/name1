package com.shc.content.webdriver.html;

/**
 * Element class which represents any random element on UI 
 * @author vshar10
 */
public class RandomElement extends AbstractBaseElement{

	public RandomElement(String locator, String elementName) {
		super(locator, elementName);
	}
}