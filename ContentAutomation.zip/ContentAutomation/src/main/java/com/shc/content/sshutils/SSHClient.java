package com.shc.content.sshutils;

import java.util.List;

public interface SSHClient {

	public List<String> executeCommand(String sCommand);
	public void disconnect();
}
