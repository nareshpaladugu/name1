package com.shc.content.webdriver.html;

import com.shc.content.webdriver.DriverInitializer;

public  class BasePage {

	String pageName;
	
	protected BasePage(String pageName){
		this.pageName = pageName;
	}
	
	public String getTitle(){
	        return DriverInitializer.driver().getTitle();
	}
}
