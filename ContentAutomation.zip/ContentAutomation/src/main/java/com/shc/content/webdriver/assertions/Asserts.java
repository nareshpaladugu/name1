package com.shc.content.webdriver.assertions;

import org.testng.Assert;
import org.testng.Reporter;

public class Asserts {

	public static final String RESULT = "Result";
	public static final String LOGGER = "Logger";
	
	private static SoftAsserts getSoftAsserts(){
		return (SoftAsserts) Reporter.getCurrentTestResult().getAttribute(RESULT);
	}
	
	private static DriverLogger logger(){
		return (DriverLogger) Reporter.getCurrentTestResult().getAttribute(LOGGER);
	}
	
	
	public static void verifyTrue(Boolean bVerify, String message){
		getSoftAsserts().assertTrue(bVerify, message);
	}
	
	public static void verifyFalse(Boolean bVerify, String message){
		getSoftAsserts().assertFalse(bVerify, message);
	}
	
	public static void verifyEquals(Object expected, Object actual,String msg){
		getSoftAsserts().assertEquals(actual, expected, msg);
	}
	
	public static void verifyNotEquals(Object expected, Object actual,String msg){
		getSoftAsserts().assertNotEquals(actual, expected, msg);
	}
	
	public static void verifyNull(Object actualObj, String message){
		getSoftAsserts().assertNull(actualObj, message);
	}
	
	public static void verifyNotNull(Object actualObj, String message){
		getSoftAsserts().assertNotNull(actualObj, message);
	}
	
	public static void assertTrue(Boolean bAssert, String message){
		try{
			Assert.assertTrue(bAssert, message);
		}catch(AssertionError e){
			logger().logFailed(message);
			throw e;
		}
		logger().logPassed(message);
		
	}
}
