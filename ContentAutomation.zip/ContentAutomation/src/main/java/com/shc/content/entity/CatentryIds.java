/**
 * 
 */
package com.shc.content.entity;

import java.util.List;
import java.util.Map;

/**
 * @author gvegesn
 *
 */
public class CatentryIds {
	
	private Map<String, String> kmartCatentryIds;
	private Map<String, String> searsCatentryIds;
	private List<String> kmartCatentryIdsList;
	private List<String> searsCatentryIdsList;
	private Map<String, String> kmartCheckFlagsFromAttribs1;
	private Map<String, String> searsCheckFlagsFromAttribs1;
	private Map<String, String> kmartCheckFlagsFromAttribs2;
	private Map<String, String> searsCheckFlagsFromAttribs2;
	
	public CatentryIds(){
		super();
	}
	public CatentryIds(Map<String, String> kmartCatentryIds,Map<String, String> searsCatentryIds,List<String> kmartCatentryIdsList,List<String> searsCatentryIdsList,Map<String, String> kmartCheckFlagsFromAttribs1,Map<String, String> searsCheckFlagsFromAttribs1,Map<String, String> kmartCheckFlagsFromAttribs2,Map<String, String> searsCheckFlagsFromAttribs2) {
		super();
		this.kmartCatentryIds = kmartCatentryIds;
		this.searsCatentryIds = searsCatentryIds;
		this.kmartCatentryIdsList = kmartCatentryIdsList;
		this.searsCatentryIdsList = searsCatentryIdsList;
		this.kmartCheckFlagsFromAttribs1 = kmartCheckFlagsFromAttribs1;
		this.searsCheckFlagsFromAttribs1 = searsCheckFlagsFromAttribs1;
		this.kmartCheckFlagsFromAttribs2 = kmartCheckFlagsFromAttribs2;
		this.searsCheckFlagsFromAttribs2 = searsCheckFlagsFromAttribs2;
	}
	public Map<String, String> getKmartCatentryIds() {
		return kmartCatentryIds;
	}
	public void setKmartCatentryIds(Map<String, String> kmartCatentryIds) {
		this.kmartCatentryIds = kmartCatentryIds;
	}
	public Map<String, String> getSearsCatentryIds() {
		return searsCatentryIds;
	}
	public void setSearsCatentryIds(Map<String, String> searsCatentryIds) {
		this.searsCatentryIds = searsCatentryIds;
	}
	public List<String> getKmartCatentryIdsList() {
		return kmartCatentryIdsList;
	}
	public void setKmartCatentryIdsList(List<String> kmartCatentryIdsList) {
		this.kmartCatentryIdsList = kmartCatentryIdsList;
	}
	public List<String> getSearsCatentryIdsList() {
		return searsCatentryIdsList;
	}
	public void setSearsCatentryIdsList(List<String> searsCatentryIdsList) {
		this.searsCatentryIdsList = searsCatentryIdsList;
	}
	public Map<String, String> getKmartCheckFlagsFromAttribs1() {
		return kmartCheckFlagsFromAttribs1;
	}
	public void setKmartCheckFlagsFromAttribs1(
			Map<String, String> kmartCheckFlagsFromAttribs1) {
		this.kmartCheckFlagsFromAttribs1 = kmartCheckFlagsFromAttribs1;
	}
	public Map<String, String> getSearsCheckFlagsFromAttribs1() {
		return searsCheckFlagsFromAttribs1;
	}
	public void setSearsCheckFlagsFromAttribs1(
			Map<String, String> searsCheckFlagsFromAttribs1) {
		this.searsCheckFlagsFromAttribs1 = searsCheckFlagsFromAttribs1;
	}
	public Map<String, String> getKmartCheckFlagsFromAttribs2() {
		return kmartCheckFlagsFromAttribs2;
	}
	public void setKmartCheckFlagsFromAttribs2(
			Map<String, String> kmartCheckFlagsFromAttribs2) {
		this.kmartCheckFlagsFromAttribs2 = kmartCheckFlagsFromAttribs2;
	}
	public Map<String, String> getSearsCheckFlagsFromAttribs2() {
		return searsCheckFlagsFromAttribs2;
	}
	public void setSearsCheckFlagsFromAttribs2(
			Map<String, String> searsCheckFlagsFromAttribs2) {
		this.searsCheckFlagsFromAttribs2 = searsCheckFlagsFromAttribs2;
	}
	
}
