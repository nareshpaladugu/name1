package com.shi.content.promos.phase2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.generated.vos.content.Hierarchy_;
import com.generated.vos.offer.Offer;
import com.generated.vos.promo.PromoDetails;
import com.generated.vos.promo.Promorel;
import com.generated.vos.promos.Attr;
import com.generated.vos.promos.Hierarchy;
import com.generated.vos.promos.Item;
import com.generated.vos.promos.Promo;
import com.generated.vos.promos.Source;
import com.generated.vos.promos.SpecificHierarchy;
import com.generated.vos.promos.Target;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 * Actual promorel collection validation logic
 */
public class PromoRelLogic implements Runnable {

	List<String> chunked;

	/**
	 * @param chunked
	 */
	public PromoRelLogic(List<String> chunked) {

		this.chunked = chunked;
	}


	@Override
	public void run() {

		/* ----------------------- Hit PromoRel chunk wise------------------------- */

		List<APIResponse<Promorel>> lstOffersFromPromoRel = RestExecutor.getAllDataById(CollectionValuesVal.PROMO_REL, chunked);

		List<APIResponse<Offer>> lstOffers = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, chunked);

		Map<String, Offer> offersMap = new HashMap<String, Offer>();

		if(lstOffers!=null && !lstOffers.isEmpty())
		{
			for (APIResponse<Offer> offerRes : lstOffers) {

				Offer offer = offerRes.getT();

				offersMap.put(offer.getId(),offer);
			}
		}


		for (APIResponse<Promorel> apiResponse : lstOffersFromPromoRel)
		{

			CompareValuesUtility.init();

			Promorel promorel = (Promorel)apiResponse.getT();

			System.out.println("Testing promorel : "+promorel.getPno());

			/* ----------------------- Hit offer ------------------------- */

			Offer offer = offersMap.get(promorel.getPno());

			/* ----------------------- Check if offer is null/blank ------------------------- */
			if(offer==null)
			{
				CompareValuesUtility.logFailed("Offer", promorel.getPno(), "Offer not found is GB");
			}
			else
			{
				validatePromos(PromoPhase2Helper.getPromosFromPromoRel(promorel),offer);
			}

			CompareValuesUtility.setupResult(promorel.getPno()+"", true);
		}

	}

	public void validatePromos(Map<String, List<PromoDetails>>  map,Offer offer)
	{

		List<String> promoIds = new ArrayList<String>();

		Iterator<Entry<String, List<PromoDetails>>> iterator = map.entrySet().iterator();

		/* ----------------------- Extract all associated promo ids ------------------------- */

		while (iterator.hasNext()) {
			Entry<String, List<PromoDetails>> mapEntry =  iterator.next();

			for (PromoDetails promoDetails : mapEntry.getValue()) 
			{
				promoIds.add(promoDetails.getPromoId());
			}
		}

		/* ----------------------- hit Promo collection in one go ------------------------- */

		PromoPhase2Helper.hitPromos(promoIds);

		iterator = map.entrySet().iterator();

		/* --------------- Validate promo association based on inclusions and exclusions logic ---------- */

		while (iterator.hasNext())
		{
			Entry<String, List<PromoDetails>> mapEntry =  iterator.next();

			String storeName  = mapEntry.getKey();

			//System.out.println("Store Name : "+storeName +" No. of promos : "+ mapEntry.getValue().size());

			for (PromoDetails promoDetails : mapEntry.getValue()) 
			{

				String promoId = promoDetails.getPromoId();

				System.out.println("\tpromoId .. "+promoId);


				/* ----------------------- Get Promo ------------------------- */

				Promo promo = PromoPhase2Helper.getPromo(promoId);

				if(promo==null)
				{
					CompareValuesUtility.logFailed("Promo", promoId,"Not Found in GB");
				}
				else
				{

					CompareValuesUtility.logPassed("Promo", promoId,promoId);
					
					CompareValuesUtility.logPassed("Store", storeName,storeName);
					
					/* ----------------------- First apply exclusion logic ------------------------- */

					ReturnVal retValExcl = validateExclusions(promo,storeName,offer);
					
					boolean bExclusionResult =  retValExcl.isStatus();

					//System.out.println("bExclusionResult : "+bExclusionResult);

					if(bExclusionResult)
					{
						/* ----------------------- ERROR : this item need to be excluded ------------------------- */
						// FAIL CASE - Exclusion
						System.out.println("ERROR : this item need to be excluded ");

						CompareValuesUtility.logFailed("Exclusion", "This item need to be excluded", retValExcl.getDescription());
					}
					else
					{
						ReturnVal retVal =  validateInclusions(promo,storeName,offer);

						boolean bInclusionResult = retVal.isStatus();
								
						//System.out.println("bInclusionResult : "+bInclusionResult);

						if(bInclusionResult)
						{
							//PASS case - Inclusion
							CompareValuesUtility.logPassed("Inclusions", "True", "This item is included");
						}
						else
						{
							/* ----------------------- ERROR : this item should NOT be included ------------------------- */
							// FAIL CASE - Inclusion
							System.out.println("ERROR : this item should NOT be included");
							CompareValuesUtility.logFailed("Inclusions", "This item should NOT be included", retVal.getDescription());
						}
					}
				}
			}
		}
	}

	/**
	 * Process exclusions logic
	 * @param promo
	 * @param storeName
	 * @return
	 */
	public ReturnVal validateExclusions(Promo promo,String storeName,Offer offer)
	{
		List<Source> sources = promo.getEligCriterias().get(0).getSources();

		for (Source source : sources) 
		{
			ReturnVal returnVal = validateItem(source.getExclusions().getItems().get(0), false,storeName,offer);

			boolean bSourceValidationResult = returnVal.isStatus();

			/*---------------  Return once true --------------- */
			if(bSourceValidationResult)
				return new ReturnVal(true);
				//return true;

		}

		if(promo.getEligCriterias().get(0).getTargets()!=null)
		{
			Target target = promo.getEligCriterias().get(0).getTargets().get(0);

			return validateItem(target.getExclusions().getItems().get(0), false,storeName,offer);

		}
		else
		{
			return new ReturnVal(false);
			//This item should not be excluded
			//return false;
		}
	}


	/**
	 * Process inclusions logic
	 * @param promo
	 * @param storeName
	 * @return
	 */
	public ReturnVal validateInclusions(Promo promo,String storeName,Offer offer)
	{
		List<Source> sources = promo.getEligCriterias().get(0).getSources();

		for (Source source : sources) 
		{
			ReturnVal returnVal = validateItem(source.getInclusions().getItems().get(0), false,storeName,offer);

			boolean bSourceValidationResult = returnVal.isStatus();

			/*---------------  Return once true --------------- */
			if(bSourceValidationResult)
				return new ReturnVal(true);
			//return true;
		}

		if(promo.getEligCriterias().get(0).getTargets()!=null)
		{
			Target target = promo.getEligCriterias().get(0).getTargets().get(0);

			return  validateItem(target.getInclusions().getItems().get(0), false,storeName,offer);

		}
		else
		{
			return new ReturnVal(false);
			//return false;
		}

	}


	/**
	 * validates attributes, part number and hierarchies
	 * @param item
	 * @param flagInclusions  Inclusions=true, Exclusions=false
	 * @return
	 */
	public ReturnVal validateItem(Item item,boolean flagInclusions,String storeName,Offer offer)
	{
		List<Attr> listOfAttributes = item.getAttrs();

		List<String> partNumbersList = item.getPartnumbers();

		List<Hierarchy> hierarchies = item.getHierarchies();

		String catalog  = item.getCatalog();

		// We don't know attr validation result here, so marking as null
		Boolean attrValidationResult = null;

		/* ------------  validate attributes -----------------*/

		if(listOfAttributes!=null && !listOfAttributes.isEmpty())
		{
			ReturnVal retVal = validateAttributes(listOfAttributes, flagInclusions,offer);

			attrValidationResult = retVal.isStatus();

			if(flagInclusions && !attrValidationResult)
			{
				/* Here we are checking inclusions and we got false for attribute validation, 
				hence no more validation needed, return false from here itself */

				return new ReturnVal("Inclusion - Attribute validation failed", false);
				//return false;
			}

			if(!flagInclusions && attrValidationResult)
			{
				/* Here we are checking excluions and we got true for attribute validation, 
				hence no more validation needed, return TRUE from here itself */

				return new ReturnVal(true);
				//return true;
			}

		}

		if(partNumbersList!=null && !partNumbersList.isEmpty())
		{
			//if category and items are present – only items will be considered for the rule evaluation and ignore the category

			/* ------------  validate part numbers -----------------*/

			boolean partNumberValidationResult = containsOfferInPartNumberList(partNumbersList,offer);

			//check is we have attr validation result, if yes consider it for final result
			if(attrValidationResult==null)
			{
				String desc= partNumberValidationResult?"Partnumber validation failed":"";
				
				return new ReturnVal(desc,partNumberValidationResult);
				//return partNumberValidationResult;
			}
			else
			{
				if(flagInclusions)
					return new ReturnVal(attrValidationResult && partNumberValidationResult);
				//return attrValidationResult && partNumberValidationResult;
				else
					return new ReturnVal( attrValidationResult || partNumberValidationResult);
				//return attrValidationResult || partNumberValidationResult;
			}
		}
		else
		{
			/* ------------  validate hierarchies -----------------*/

			boolean hierarchyValidationResult = validateHierarchy(hierarchies,storeName, catalog,offer);

			//check is we have attr validation result, if yes consider it for final result
			if(attrValidationResult==null)
			{
				String desc= hierarchyValidationResult?"Hierarchy validation failed":"";
				
				return new ReturnVal(desc,hierarchyValidationResult);
				//return hierarchyValidationResult;
			}
			else
			{
				if(flagInclusions)
					return new ReturnVal(attrValidationResult  && hierarchyValidationResult);
				//return attrValidationResult  && hierarchyValidationResult;
				else
					return new ReturnVal( attrValidationResult  || hierarchyValidationResult);
				//return attrValidationResult  || hierarchyValidationResult;
			}
		}
	}


	/**
	 * Return cid to name map
	 * @param ids
	 * @return
	 */
	public  static Map<String,String> getStoreHierarchyCidPath(List<String> ids)
	{
		Map<String,String> idsMap =new HashMap<String, String>();

		List<String> hierarchy = RestExecutor.getAllDataByIdString(CollectionValuesVal.STORE_HIERARCHY, ids);


		if(hierarchy!=null && !hierarchy.isEmpty())
		{
			for (String string : hierarchy) {

				String cid = JsonStringParser.getJsonValue(string, "{_blob{hierarchy{path{cidPath}}}}");

				String imaid =  JsonStringParser.getJsonValue(string, "{_blob{hierarchy{imaId}}}");

				idsMap.put(cid,imaid); 
			}

		}
		else
		{
			System.out.println("No store hierarchy present *** ");
		}
		return idsMap;
	}

	/**
	 * Validate store and web hierarchy
	 * @param hierarchies
	 * @param store
	 * @param catalog
	 * @return
	 */
	public boolean validateHierarchy(List<Hierarchy> hierarchies,String store,String catalog,Offer offer)
	{
		String id,name;

		if(catalog.equalsIgnoreCase("store"))
		{
			/*  ------------  get store hierarchy from offer ------------ */ 

			List<com.generated.vos.offer.Hierarchy> listOfStoreHierarchy = offer.getTaxonomy().getStore().getHierarchy();

			List<String> ids = new ArrayList<String>();

			for (com.generated.vos.offer.Hierarchy hierarchy : listOfStoreHierarchy) {

				//System.out.println("[Store hierarchy]id : "+hierarchy.getId() +" name :"+hierarchy.getName());

				ids.add(hierarchy.getId());
			}

			/*  ------------ hit store hierarchy and get cid path to name map ------------ */ 

			Map<String,String> idsMap = getStoreHierarchyCidPath(ids);

			/*  ------------ iterate hierarchies from current promo ------------ */ 

			for (Hierarchy singlehierarchy : hierarchies) {

				List<SpecificHierarchy> hierarchy = singlehierarchy.getSpecificHierarchy();

				for (SpecificHierarchy specificHierarchy : hierarchy) {

					id = specificHierarchy.getId();
					name = specificHierarchy.getName();

					if(idsMap.containsKey(id))
					{
						if(idsMap.get(id).equals(name))
						{
							//both cid path and name are matching - got required hierarchy
							//System.out.println("both cid path and name are matching - got required hierarchy [STORE]");
							return true;
						}
					}

				}
			}

		}
		else if(catalog.equalsIgnoreCase("web"))
		{

			if(offer.getTaxonomy().getWeb()==null)
			{
				System.out.println("Web hierarhcy is not PRESENT *** ");
				return false;
			}
			else
			{
				List<com.generated.vos.content.SpecificHierarchy> offerHierachies = getOfferWebTaxonomy(offer, store);

				if(offerHierachies==null)
				{
					System.out.println("No web hierarchy is present for store "+store +" offer id  : "+offer.getId());
					return false;
				}
				else
				{
					for (Hierarchy singlehierarchy : hierarchies) {

						List<SpecificHierarchy> hierarchy = singlehierarchy.getSpecificHierarchy();

						for (SpecificHierarchy specificHierarchy : hierarchy) {

							id = specificHierarchy.getId();
							name = specificHierarchy.getName();

							for (com.generated.vos.content.SpecificHierarchy specificHierarchyOffer : offerHierachies) {

								if(specificHierarchyOffer.getId().equals(id) &&
										specificHierarchyOffer.getName().equals(name))
								{
									//both id and name are matching - got required hierarchy

									//System.out.println("both id and name are matching - got required hierarchy [WEB]");

									return true;
								}

							}
						}
					}
				}
			}
		}
		else
		{
			System.out.println("[ERROR] Unhandled  catalog : "+catalog);
		}

		return false;
	}

	public static List<com.generated.vos.content.SpecificHierarchy> getOfferWebTaxonomy(Offer offer, String store)
	{

		List<com.generated.vos.content.SpecificHierarchy> spHierarchies = new ArrayList<com.generated.vos.content.SpecificHierarchy>();

		List<Hierarchy_> hierarchies = null ;

		try {
			switch(store.toUpperCase())
			{
			case "SEARS":
				hierarchies = offer.getTaxonomy().getWeb().getSites().getSears().getHierarchies();
				break;
			case "KMART":
				hierarchies =  offer.getTaxonomy().getWeb().getSites().getKmart().getHierarchies();
				break;
			case "MYGOFER":case "MYGOFER3":
				hierarchies =  offer.getTaxonomy().getWeb().getSites().getMygofer().getHierarchies();
				break;
			case "PUERTORICO":
				hierarchies =  offer.getTaxonomy().getWeb().getSites().getPuertorico().getHierarchies();
				break;
			case "KENMORE":
				hierarchies =  offer.getTaxonomy().getWeb().getSites().getKenmore().getHierarchies();
				break;
			case "CRAFTSMAN":
				hierarchies =  offer.getTaxonomy().getWeb().getSites().getCraftsman().getHierarchies();
				break;
			}
		} catch (Exception e) {

			System.out.println("Web hierarchy not found for store :"+store +"  and for offer "+offer.getId());
		}

		if(hierarchies!=null)
		{
			for (Hierarchy_ hierarchy_ : hierarchies) {

				spHierarchies.addAll(hierarchy_.getSpecificHierarchy());
			}
		}

		return spHierarchies;
	}
	/**
	 * Validates part number 
	 * @param partNumbers
	 * @return
	 */
	public boolean containsOfferInPartNumberList(List<String> partNumbers,Offer offer)
	{
		/* ------------This method gets called only if partNumbers list if not empty ----------- */

		String partNumber = offer.getId();

		if(partNumbers.contains(partNumber))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	class ReturnVal
	{
		private String description;
		private boolean status;
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public boolean isStatus() {
			return status;
		}
		public void setStatus(boolean status) {
			this.status = status;
		}
		public ReturnVal(String description, boolean status) {
			super();
			this.description = description;
			this.status = status;
		}

		public ReturnVal( boolean status) {
			super();
			this.description = "";
			this.status = status;
		}

	}

	/**
	 * Validates attributes
	 * @param listOfAttributes
	 * @param flagInclusions  Inclusions=true, Exclusions=false
	 * @return
	 */
	public ReturnVal validateAttributes(List<Attr> listOfAttributes,boolean flagInclusions,Offer offer)
	{
		Gson gson=new Gson();

		String offerResponse = gson.toJson(offer);

		Boolean finalResult = null;

		String actualAttributeValue=null;
		String attributeName = null;
		String expectedAttributeValue = null;
		String condition = null;

		for (Attr attr : listOfAttributes)
		{

			boolean singleAttrMatchResult = true;

			attributeName = attr.getName();
			expectedAttributeValue = attr.getValue();
			condition = attr.getOperator();

			String offerAttrPath = PromoRelTestPhase2.FieldsMap.get(attributeName);

			if(offerAttrPath==null)
			{
				System.out.println("[TODO]#### Attr not found field map : "+attributeName);
			}
			else
			{
				actualAttributeValue = JsonStringParser.getJsonValue(offerResponse,offerAttrPath);
			}

			//System.out.println("expectedAttributeValue : "+expectedAttributeValue +  " And  actualAttributeValue : "+ actualAttributeValue);

			if(condition.equals("==")||condition.equals("="))
			{
				if(!expectedAttributeValue.equals(actualAttributeValue))
				{
					singleAttrMatchResult = false;
				}
			}
			else
			{
				Double d1 = Double.parseDouble(expectedAttributeValue);

				Double d2 = Double.parseDouble(actualAttributeValue);

				switch(condition)
				{
				case ">":

					if(!(d2>d1))
					{
						singleAttrMatchResult = false;
					}
					break;
				case ">=":
					if(!(d2>=d1))
					{
						singleAttrMatchResult = false;
					}
					break;
				case "<":
					if(!(d2<d1))
					{
						singleAttrMatchResult = false;
					}
					break;
				case "<=":
					if(!(d2<=d1))
					{
						singleAttrMatchResult = false;
					}
					break;
				}

			}

			if(flagInclusions)
			{
				/* --------- Inclusions : ANDing attribute validation result ----------*/

				finalResult = finalResult==null?singleAttrMatchResult:finalResult && singleAttrMatchResult;

				if(!finalResult)
				{
					/* ------------ Return if any of attribute value MISMATCHES for inclusions -----------*/
					return new ReturnVal("Attr MISMATCHED, Exp - "+attributeName+":"+expectedAttributeValue
							+" Act - "+attributeName+":"+actualAttributeValue, false);
					//return false;
				}
			}
			else
			{
				/* --------- Exclusions : ORing attribute validation result ----------*/

				finalResult = finalResult==null?singleAttrMatchResult:finalResult || singleAttrMatchResult;

				if(finalResult)
				{
					/* ------------ Return if any of attribute value [MATCHES] for exclusions -----------*/

					/*return new ReturnVal("Attr MATCHED, Exp - "+attributeName+":"+expectedAttributeValue
							+" Act - "+attributeName+":"+actualAttributeValue, true);*/
					return new ReturnVal( true);
					//	return true;
				}
			}
		}

		finalResult = finalResult==null?false:finalResult;

		return new ReturnVal("", finalResult);

		//	return finalResult;
	}
}
