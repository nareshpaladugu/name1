package com.shi.content.international;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.generated.vos.contentbco.Bundle;
import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.offer.IntlCountryGrp;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;


public class InternationalVerifications implements Runnable {


	private String offerToTest;
	private String errResp;

	//List<BndlGrp> bundleGroups = new ArrayList<BndlGrp>();
	
	public InternationalVerifications(String offerId)
	{
		this.offerToTest=offerId;
	}
	
	public void run() {
		
		if(offerToTest!=null) {
			
			APIResponse<Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offerToTest);

			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Skipped", offerToTest, " Offer not found");
					CompareValuesUtility.setupResult(offerToTest, true);
					return;
				}
				
				Offer gbOffer = (Offer)allResponse.getT();
				if(gbOffer == null){
					CompareValuesUtility.logFailed("Skipped", offerToTest, " Item Not found");
					CompareValuesUtility.setupResult(offerToTest, true);
					return;
				}
				else if(gbOffer.getOperational()!=null && gbOffer.getOperational().getSites()!=null && gbOffer.getOperational().getSites().getSears()!=null && gbOffer.getOperational().getSites().getSears().getIsDispElig()!=null){
					if(!gbOffer.getOperational().getSites().getSears().getIsDispElig()){
						CompareValuesUtility.logPassed("Skipped", "isDispELig:true", " isDispELig:false");
						CompareValuesUtility.setupResult(offerToTest, true);
						return;
					}
				}
				else if(gbOffer.getOperational()==null || gbOffer.getOperational().getSites()==null || gbOffer.getOperational().getSites().getSears()==null || gbOffer.getOperational().getSites().getSears().getIsDispElig()==null){
					CompareValuesUtility.logPassed("Skipped", "isDispELig:true", " isDispELig node not present");
					CompareValuesUtility.setupResult(offerToTest, true);
					return;
				}
				//System.out.println("Testing bundle id " + sBundleIdToTest);
				
				if(!LoadProperties.SITE_NAME.equals("Both") && !LoadProperties.SITE_NAME.equals(gbOffer.getFfm().getSoldBy())) {
					System.out.println("Ignoring "+gbOffer.getFfm().getSoldBy()+" item "+offerToTest);
					return;
				}
				

				verifyOffer(gbOffer, offerToTest);
					
				//CompareValuesUtility.setupResult(offerToTest, true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ offerToTest);
				System.out.println(this.errResp);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	}

	private void verifyOffer(Offer gbOffer, String sOfferId) {
		boolean intlFlag=true;
		boolean channelFlag=true;
		boolean hazmatFlag=true;
		boolean isSimiEligFlag=true;
		boolean isMailableFlag=true;
		boolean intlCntryGrpExistsFlag=false;
		String international_shipping="null";
		String intlCntryGrpString="null";
		String mailable="null";
		String hazmat="null";
		String channel="null";
		String isSimi="null";
		if(gbOffer.getShipping()!=null){
			if(gbOffer.getShipping().getIntlCountryGrps()!=null && gbOffer.getShipping().getIntlCountryGrps().isEmpty()==false){
				intlCntryGrpExistsFlag=true;
			}
		}
		if(intlCntryGrpExistsFlag)
		{
			intlCntryGrpString="";
			for(IntlCountryGrp intlCntryGrps:gbOffer.getShipping().getIntlCountryGrps())
			{
				intlCntryGrpString=intlCntryGrpString+" ["+intlCntryGrps.getName()+"]";
			}
		}
		if(gbOffer.getLegal().getHazmat()!=null && gbOffer.getLegal()!=null){
			hazmat=gbOffer.getLegal().getHazmat().toString();
		}
		if(gbOffer.getShipping().getIsMailable()!=null && gbOffer.getShipping()!=null){
			mailable=gbOffer.getShipping().getIsMailable().toString();
		}
		if(gbOffer.getFfm().getChannel() !=null && gbOffer.getFfm()!=null){
			channel=gbOffer.getFfm().getChannel().toString();
		}
		if(gbOffer.getShipping().getIsSimiElig()!=null && gbOffer.getShipping()!=null){
			isSimi=gbOffer.getShipping().getIsSimiElig().toString();
		}
		String Id ="";
		if(gbOffer.getTaxonomy()!=null && gbOffer.getTaxonomy().getWeb()!=null && gbOffer.getTaxonomy().getWeb().getSites()!=null){
		if(gbOffer.getTaxonomy().getWeb().getSites()
				.getSears()!=null){
			if(gbOffer.getTaxonomy().getWeb().getSites()
				.getSears().getHierarchies()!=null && !gbOffer.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().isEmpty()){
					if(gbOffer.getTaxonomy().getWeb().getSites()
							.getSears().getHierarchies().get(0)
							.getSpecificHierarchy().size()>2 && gbOffer.getTaxonomy().getWeb().getSites()
							.getSears().getHierarchies().get(0)!=null && !gbOffer.getTaxonomy().getWeb().getSites()
									.getSears().getHierarchies().isEmpty()){
								if(gbOffer.getTaxonomy().getWeb().getSites()
									.getSears().getHierarchies().get(0)
									.getSpecificHierarchy().get(
																	((gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().size())-1)
																).getSpinId().toString()!=null){
								Id = gbOffer.getTaxonomy().getWeb().getSites()
									.getSears().getHierarchies().get(0)
									.getSpecificHierarchy().get(
											((gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().size())-1)
																).getSpinId().toString();
								}
				
			}else{
				if(gbOffer.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)!=null && !gbOffer.getTaxonomy().getWeb().getSites()
								.getSears().getHierarchies().isEmpty() && gbOffer.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getSpinId().toString()!=null){
				Id = gbOffer.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getSpinId().toString();	
			}else{
				intlFlag=false;
			}
			}
		}else{
			intlFlag=false;
		}
		}
		}
		APIResponse<Hierarchy> allResponse =null;
		if(Id!=""){
		allResponse = RestExecutor.getAllDataById(CollectionValuesVal.WEB_HIERARCHY, Id);
		}
		Hierarchy gbHierarchy =null;
		if(allResponse!=null){
		gbHierarchy = allResponse.getT();
		}
		System.out.println("Offer ID" +offerToTest );
		if(gbHierarchy!=null &&gbHierarchy.getAttrs()!=null && gbHierarchy.getAttrs().getTags()!=null && !gbHierarchy.getAttrs().getTags().isEmpty())
		{
			international_shipping="";
			for (int i=0;i<gbHierarchy.getAttrs().getTags().size();i++){
				international_shipping=international_shipping+" "+gbHierarchy.getAttrs().getTags().get(i).getName();
				if (gbHierarchy.getAttrs().getTags().get(i).getName().contains("International_Shipping")){
					intlFlag=true;
				}else{
					intlFlag=false;
				}
			}
		}else{
			intlFlag=false;	
		}
			if(gbOffer.getFfm()!=null && gbOffer.getFfm().getChannel()!=null && (gbOffer.getFfm().getChannel().equalsIgnoreCase("TW") ||gbOffer.getFfm().getChannel().equalsIgnoreCase("VD"))){
				channelFlag=true;
			}else{
				channelFlag=false;
			}
			String brandName = gbOffer.getBrandName();
	//		ResultSet resultSet_Brand = MySqlConnectionUtil.executeQueryReturnSingleResultSet("SELECT EXCLUDECNTRYGRP FROM `brandexclusion` WHERE `BRANDDISPLAYNAME`=" + brandName);
	//		List<String> excludedCountryGrpIds=convertToList(resultSet_Brand);
	//		for(String excludedCountryGrp: excludedCountryGrpIds){
	//			if(gbOffer.getShipping().getIntlCountryGrps().contains(excludedCountryGrp)){
	//				CompareValuesUtility.logFailed("Id", offerToTest, "Country group id: "+excludedCountryGrp+" not excluded");
	//				CompareValuesUtility.setupResult(offerToTest, true);
	//				break;
	//			}
	//			else{
	//				continue;
	//			}
	//		}
			if(gbOffer.getShipping().getIsSimiElig()==null || gbOffer.getShipping().getIsSimiElig()==false || gbOffer.getShipping()==null){
				isSimiEligFlag=true;
			}
			else{
				isSimiEligFlag=false;
			}
			if(gbOffer.getShipping().getIsMailable()==false || gbOffer.getShipping().getIsMailable()==null){
				isMailableFlag=false;
			}else{
				isMailableFlag=true;
			}
			if(gbOffer.getLegal().getHazmat()==null || gbOffer.getLegal().getHazmat()==false){
				hazmatFlag=true;
			}
			else
			{
				hazmatFlag=false;
			}
			if(hazmatFlag==false && intlCntryGrpExistsFlag==true){
				CompareValuesUtility.logFailed("Hazmat rule", "not satisfied",hazmat);
			}else{
				CompareValuesUtility.logPassed("Hazmat rule", "satisfied",hazmat);
			}
			
			if(channelFlag==false && intlCntryGrpExistsFlag==true){
				CompareValuesUtility.logFailed("Channel rule","not satisfied",channel);
			}else{
				CompareValuesUtility.logPassed("Channel rule","satisfied",channel);
			}
			
			if(isSimiEligFlag==false && intlCntryGrpExistsFlag==true){
				CompareValuesUtility.logFailed("Simi rule", "not satisfied",isSimi);
			}else{
				CompareValuesUtility.logPassed("Simi rule", "satisfied",isSimi);
			}
			
			if(isMailableFlag==false && intlCntryGrpExistsFlag==true){
				CompareValuesUtility.logFailed("mailable rule", "not satisfied",mailable);
			}else{
				CompareValuesUtility.logPassed("mailable rule", "satisfied",mailable);
			}
			
			if(intlFlag==false && intlCntryGrpExistsFlag==true){
				CompareValuesUtility.logFailed("webhierarchy rule", "not satisfied",international_shipping);
			}else{
				CompareValuesUtility.logPassed("webhierarchy rule", "satisfied",international_shipping);
			}
			
			if((hazmatFlag==true && isSimiEligFlag==true && channelFlag==true && isMailableFlag==true && intlFlag==true) && intlCntryGrpExistsFlag){
					CompareValuesUtility.logPassed("intlCountryGrp", "expected",intlCntryGrpString);
			}
			else if((hazmatFlag==false || isSimiEligFlag==false || channelFlag==false || isMailableFlag==false ||intlFlag==false) && (!intlCntryGrpExistsFlag)){
				 	CompareValuesUtility.logPassed("intlCountryGrp", "Not expected",intlCntryGrpString);		 	
			}
			else{
				CompareValuesUtility.logFailed("intlCountryGrp", "expected",intlCntryGrpString);
			}
			if(intlCntryGrpExistsFlag){
				if(gbOffer.getTaxonomy()!=null && gbOffer.getTaxonomy().getWeb()!=null && gbOffer.getTaxonomy().getWeb().getSites()!=null && gbOffer.getTaxonomy().getWeb().getSites().getSears()!=null 
						&& gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies()!=null 
						&& gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0)!=null && !gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().isEmpty()){
					if(brandName=="Craftsman" && 
							gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().contains("Lawn & Garden") 
							&& gbOffer.getShipping().getIntlCountryGrps().contains("AUS/NZ")){
						CompareValuesUtility.logFailed("Craftsman Lawn & Garden Rule","Country group AUS/NZ not expected", intlCntryGrpString);
					}else{
						if(gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0).getName()!=null && gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0)!=null){
							CompareValuesUtility.logPassed("Craftsman Rule", "For Lawn & Garden Craftsman only",gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0).getName());
						}else{
							CompareValuesUtility.logPassed("CraftsMan Rule","For craftsman hierarchy only",gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0));
						}	
					}
					
					if(	gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().contains("Tools") 
							&& gbOffer.getShipping().getIntlCountryGrps().contains("Tools")){
						CompareValuesUtility.logFailed("Tools Rule", "Tools country group not expected",intlCntryGrpString);
					}else{
						if(gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0).getName()!=null && gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0)!=null){
							CompareValuesUtility.logPassed("Tools Rule", "For tools hierarchy only",gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0).getName());
						}else{
							CompareValuesUtility.logPassed("Tools Rule","For tools hierarchy only",gbOffer.getTaxonomy().getWeb().getSites().getSears().getHierarchies().get(0).getSpecificHierarchy().get(0));
						}
					}
				}
		
			}
			CompareValuesUtility.setupResult(offerToTest, true);

			
			
	}

	public List<String> convertToList(ResultSet rs){
	
		List<String> excludedCountryGrpIds=new ArrayList<String>();
		try {
			while(rs.next()){
				excludedCountryGrpIds.add(rs.getString("EXCLUDECNTRYGRP"));
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return excludedCountryGrpIds;
		
	}


}
