package com.shi.content.wcsmigration.commons;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.generated.vos.hierarchy.Path;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.utils.GenericUtil;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.wcsmigration.commons.vos.HierarchyPathVo;

/**
 * @author ddaphal
 *
 */
public class WcsMigrationCommon 
{

	private String hierarchySeparator = "/";
	
	public void processMasterHierarchy(List<com.generated.vos.content.Hierarchy> list ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();
		List<String> lstCids  = new LinkedList<String>();

		String id=null, name=null,cid=null;

		for (com.generated.vos.content.Hierarchy hierarchy : list) {

			if(id==null)
				id= GenericUtil.convertToString(hierarchy.getSpinId()); //replaced getId
			else
				id = id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

			if(name==null)
				name=hierarchy.getName();
			else
				name = name+this.hierarchySeparator+hierarchy.getName();

			if(cid==null)
				cid=GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ======  For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	public void compareMasterhierarchyGB(long l, List<com.generated.vos.content.Hierarchy> list)
	{

		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath =GreenBoxCache.getPathForItemClass(l+"");

		if(masterHierarchyPath == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "No hierarchy exists");
			return;
		}

		if(list == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master", hierarchyMap);

		compareValues("Master", masterHierarchyPath.getIdPath(),hierarchyMap.get("no-site-required-for-master").getLstIds().get(0),"IDPath");
		compareValues("Master", masterHierarchyPath.getDisplayPath(),hierarchyMap.get("no-site-required-for-master").getDisplayPaths().get(0),"DisplayPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void setGBHierarchySeparator()
	{
		this.hierarchySeparator = "|";
	}

}
