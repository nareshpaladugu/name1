package com.shi.content.wcstogb.giftRegi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.db.DBUtil;

public class RegistryCollectionTest 
{
	@Test(groups="GiftRegistry-registryCollection")
	public void registryCollectionTest()
	{
		List<String> allGiftRegIdsList = null;

		String sOrgQuery = "  select "+ 
				"  reg.GIFTREGISTRY_ID as GRGFTREG_GIFTREGISTRY_ID,  "+ 
				"  reg.EVENTTYPE_ID as GRGFTREG_EVENTTYPE_ID,  "+ 
				"  reg.GUESTACCESSOPTION as GRGFTREG_GUESTACCESSOPTION,  "+ 
				"  reg.PREEVENTADDRESS_ID as GRGFTREG_PREEVENTADDRESS_ID,  "+ 
				"  reg.POSTEVENTADDRESS_ID as GRGFTREG_POSTEVENTADDRESS_ID,  "+ 
				"  reg.STATUS as GRGFTREG_STATUS,  "+ 
				"  reg.ACCEPTGIFTCARD as GRGFTREG_ACCEPTGIFTCARD,  "+ 
				"  reg.STOREID as GRGFTREG_STOREID,  "+ 
				"  reg.OPTFOREMAIL as GRGFTREG_OPTFOREMAIL,  "+ 
				"  reg.REGTYPE as GRGFTREG_REGTYPE,  "+ 
				"  reg.FIELD1 as GRGFTREG_FIELD1,  "+ 
				"  reg.FIELD2 as GRGFTREG_FIELD2,  "+ 
				"  reg.OPTCOUNTER as GRGFTREG_OPTCOUNTER,  "+ 
				"  reg.CREATEDTIME as GRGFTREG_CREATEDTIME,  "+ 
				"  reg.LASTUPDATE as GRGFTREG_LASTUPDATE,  "+ 
				"  reg.EVENTDATE as GRGFTREG_EVENTDATE,  "+ 
				"  reg.LOCATION as GRGFTREG_LOCATION,  "+ 
				"  reg.EXTERNALID as GRGFTREG_EXTERNALID,  "+ 
				"  reg.DESCRIPTION as GRGFTREG_DESCRIPTION,  "+ 
				"  reg.MESSAGEFORGUEST as GRGFTREG_MESSAGEFORGUEST,  "+ 
				"  reg.NAME as GRGFTREG_NAME,  "+ 
				"  reg.GUESTACCESSKEY as GRGFTREG_GUESTACCESSKEY,  "+ 
				"  reg.REGACCESSKEY as GRGFTREG_REGACCESSKEY,  "+ 
				"  reg.FIELD3 as GRGFTREG_FIELD3,  "+ 
				"  reg.FIELD4 as GRGFTREG_FIELD4,  "+ 
				"  reg.FIELD5 as GRGFTREG_FIELD5,  "+ 
				"  xreg.XGRGFTREG_ID as XGRGFTREG_XGRGFTREG_ID,  "+ 
				"  xreg.GIVETOGETHERFLG as XGRGFTREG_GIVETOGETHERFLG,  "+ 
				"  xreg.NOOFGUESTS as XGRGFTREG_NOOFGUESTS,  "+ 
				"  xreg.SYWRID as XGRGFTREG_SYWRID,  "+ 
				"  xreg.THANKUMGRFLG as XGRGFTREG_THANKUMGRFLG,  "+ 
				"  xreg.EMAILOPTIONS as XGRGFTREG_EMAILOPTIONS,  "+ 
				"  xreg.EVENTBASEDDATE as XGRGFTREG_EVENTBASEDDATE,  "+ 
				"  xreg.ANTICIPATEDDOB as XGRGFTREG_ANTICIPATEDDOB,  "+ 
				"  xreg.NOOFCHILDEXPECTED as XGRGFTREG_NOOFCHILDEXPECTED,  "+ 
				"  xreg.GENDER as XGRGFTREG_GENDER,  "+ 
				"  xreg.CELEBRANTAGE as XGRGFTREG_CELEBRANTAGE,  "+ 
				"  xreg.CELEBRANTNAME as XGRGFTREG_CELEBRANTNAME,  "+ 
				"  xreg.GRPHOTOIMAGEURL as XGRGFTREG_GRPHOTOIMAGEURL,  "+ 
				"  xreg.GRFONTCOLOR as XGRGFTREG_GRFONTCOLOR,  "+ 
				"  xreg.GRBORDER as XGRGFTREG_GRBORDER,  "+ 
				"  xreg.TOPVIEWEDCOUNT as XGRGFTREG_TOPVIEWEDCOUNT,  "+ 
				"  xreg.CHKLISTADDALLENABLE as XGRGFTREG_CHKLISTADDALLENABLE,  "+ 
				"  xreg.REGISTRYTYPENAME as XGRGFTREG_REGISTRYTYPENAME,  "+ 
				"  xreg.APOSHIPPINGELIGIBLE as XGRGFTREG_APOSHIPPINGELIGIBLE,  "+ 
				"  xreg.ADDSHOWERDATE as XGRGFTREG_ADDSHOWERDATE,  "+ 
				"  xreg.GRCATALOGID as XGRGFTREG_GRCATALOGID "+ 
				"  from GRGFTREG reg LEFT OUTER JOIN  XGRGFTREG xreg   "+ 
				"  on reg.GIFTREGISTRY_ID =  xreg.XGRGFTREG_ID "+ 
				"  HARDCODED_IDS " +
				"  PHOLDER  " +
				" with ur";

		//String sQuery;

		if(CommonGiftReg.database==null)
		{
			LoadProperties.setCustomMsgForEmail("Check MongoDb Connection",MSGTYPE.ERROR);
			return;
		}

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("LIST"))
		{
			allGiftRegIdsList = Arrays.asList(LoadProperties.RUN_PARAMS.split(","));

			sOrgQuery = sOrgQuery.replaceFirst("PHOLDER", " ");

			sOrgQuery = sOrgQuery.replaceFirst("HARDCODED_IDS",
					" where reg.GIFTREGISTRY_ID in ("+RegistryCollectionCache.getListToString(allGiftRegIdsList) +")");
		}
		else
		{
			sOrgQuery = sOrgQuery.replaceFirst("HARDCODED_IDS"," ");

			if(LoadProperties.TESTDATALIMIT!=-1)
				sOrgQuery = sOrgQuery.replaceFirst("PHOLDER", " fetch first "+LoadProperties.TESTDATALIMIT+" rows only ");
			else
				sOrgQuery = sOrgQuery.replaceFirst("PHOLDER", " ");
		}


		ResultSet resultSet = DBUtil.executeQueryReturnAll(sOrgQuery);

		List<Map<String,String>> mapList = new ArrayList<Map<String,String>>();

		ArrayList<String> ids = new ArrayList<String>();
		try {
			while(resultSet.next())
			{
				Map<String,String> GRGFTREG_XGRGFTREG_map = CommonGiftReg.getMap(resultSet);

				mapList.add(GRGFTREG_XGRGFTREG_map);

				ids.add(resultSet.getString("GRGFTREG_GIFTREGISTRY_ID"));
				
				if(mapList.size()%50000==0)
				{
					System.out.println(" ................  Pushing to pool ................ ");
					RegistryCollectionCache.init(ids);
					System.out.println(" ................  INIT DONE ................ ");
					//Execute
					for (Map<String, String> map : mapList) 
					{
						pool.execute(new RegistryCollectionVerification(
								map.get("GRGFTREG_GIFTREGISTRY_ID"),map));
					}
					
					mapList = new ArrayList<Map<String,String>>();
					ids = new ArrayList<String>();
				}
				
			}
			
			if(!mapList.isEmpty())
			{
				System.out.println(" ................ Last Pushing to pool ................ ");
				
				RegistryCollectionCache.init(ids);
				
				//Execute
				for (Map<String, String> map : mapList) {
					
					pool.execute(new RegistryCollectionVerification(
							map.get("GRGFTREG_GIFTREGISTRY_ID"),map));
				}
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally
		{
			DBUtil.closeCursor(resultSet);
		}

		/*System.out.println("Test Data Size ..... "+allGiftRegIdsList.size());

		List<List<String>> allPartitions = com.google.common.collect.Lists.partition(allGiftRegIdsList,1000);

		String strList = null;

		for (List<String> list : allPartitions) 
		{
			strList= RegistryCollectionCache.getListToString(list);

			Map<String,Map<String,String>> GRGFTREG = RegistryCollectionCache.getGRGFTREG(strList);

			RegistryCollectionCache.init(strList);

			Iterator<Map.Entry<String,Map<String,String>>> entries = GRGFTREG.entrySet().iterator();

			while (entries.hasNext()) 
			{
				Entry<String,Map<String,String>> singleEntry = entries.next();
				pool.execute(new RegistryCollectionVerification(singleEntry.getKey(),singleEntry.getValue()));
			}
		}*/

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

	}

	@BeforeSuite(groups="GiftRegistry-registryCollection")
	public void startUp()
	{
		CommonGiftReg.initMaps();
		CommonGiftReg.getGiftRegMongoDB();
	}
}