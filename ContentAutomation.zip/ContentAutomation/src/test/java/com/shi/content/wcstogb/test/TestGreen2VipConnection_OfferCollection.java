package com.shi.content.wcstogb.test;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.shc.autocontent.gb.MongoDBClient;

public class TestGreen2VipConnection_OfferCollection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// TODO Auto-generated method stub

			MongoClient mongoc = MongoDBClient.connectToMongoDB();

			DB db = mongoc.getDB("offer");

			DBCollection dbCollection = db.getCollection("offer");

			System.out.println(dbCollection.findOne());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
