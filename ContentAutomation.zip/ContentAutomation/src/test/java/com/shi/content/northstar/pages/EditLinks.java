package com.shi.content.northstar.pages;

import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Menu;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.WaitUtils;

public class EditLinks extends BasePage{

	Link linkDepartmentView = new Link("//a[contains(text(),'Unit Attributes and Department View')]","Department View");
	Link linkUnitRegularHoursView = new Link("//a[contains(text(),'Unit Regular Hours View')]","Unit Regular Hours View");
	Link linkUnitHolidayHoursView = new Link("//a[contains(text(),'Holiday Hours View')]","Holiday Hours View");
	
	Table tblView = new Table("//div[@class='ui-accordion-content ui-helper-reset ui-widget-content ui-helper-hidden'][@aria-hidden='false']", "Department View");
	
	DriverLogger logger = new DriverLogger();
	
	public EditLinks() {
		super("Link Panel_Editable View");
	}

	public void goToDepartmentsView(){
	
		logger.log("Go to Departments view ", false);
		
		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkDepartmentView);
			linkDepartmentView.click();
		}
		
		WaitUtils.waitUntilElementIsVisible(linkDepartmentView);
		linkDepartmentView.click();

	}

	public Link getDepartmentsView() {
		return linkDepartmentView;
	}
	
	public void goToUnitRegHoursView(){
		
		logger.log("Go to Regular Hours view ", false);
		
		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkUnitRegularHoursView);
			linkUnitRegularHoursView.click();
		}
		
		WaitUtils.waitUntilElementIsVisible(linkUnitRegularHoursView);
		linkUnitRegularHoursView.click();
	
	}

	public Link getUnitRegHoursView() {
		return linkUnitRegularHoursView;
	}


	public void goToHolidayHoursView(){
		
		logger.log("Go to Holiday Hours view ", false);
		
		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkUnitHolidayHoursView);
			linkUnitRegularHoursView.click();
		}
		
		WaitUtils.waitUntilElementIsVisible(linkUnitHolidayHoursView);
		linkUnitHolidayHoursView.click();
	
	}

	public Link getHolidayHoursView() {
		return linkUnitHolidayHoursView;
	}
}
