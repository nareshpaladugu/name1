package com.shi.content.ranking.vos;

public class WareHouseLocation {
	private Sopt sopt;

	public Sopt getSopt() {
		return sopt;
	}

	public void setSopt(Sopt sopt) {
		this.sopt = sopt;
	}

}
