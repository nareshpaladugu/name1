package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.uvd.AutomotiveProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.UVD_ContentVerifications;

public class UVD_ContentLoadTest {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="UVDContentLoadTest")
	public void testUvdLoad7_30(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);

		System.out.println("Testing sFileName "+ sFileName);
		String vendorId = sFileName.split("\\.")[0].split("-")[3];

		BlockingQueue<List<AutomotiveProductOffer>> productOfferQueue = new LinkedBlockingQueue<List<AutomotiveProductOffer>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<AutomotiveProductOffer> prodThread = new ChunkProducerThread<AutomotiveProductOffer>(sFileName, productOfferQueue, AutomotiveProductOffer.class,"automotive-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<AutomotiveProductOffer> nodeToTest = productOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new UVD_ContentVerifications(nodeToTest.get(0), vendorId));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public 	static List<String> errorPartNumbers = new ArrayList<String>();
	
	@BeforeClass(groups="UVDContentLoadTest")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			errorPartNumbers = ErrorPartReader.getUVDErrorPartsFromLogFile(errorlogFile);
		}

	}
}
