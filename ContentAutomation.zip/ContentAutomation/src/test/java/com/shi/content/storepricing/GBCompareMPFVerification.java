package com.shi.content.storepricing;

import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;

public class GBCompareMPFVerification implements Runnable {
	
		static Map<String, Boolean> storeIds = Collections.synchronizedMap(new HashMap<String, Boolean>());
		String finalId=null;
		ShcPricing storePricingGB;
		List<String> singlePricingBlob;
		
		public GBCompareMPFVerification(List<String> pricingDataForProduct){
			this.singlePricingBlob = pricingDataForProduct;
		}
		


		public void run() {
			System.out.println("Thread:" + Thread.currentThread().getId() + " "
					+ singlePricingBlob);
	        CompareValuesUtility.init();
			// Fill code here
	     
	        String[] singlePriceData = singlePricingBlob.get(0).split("\\|");
	        String mainId = singlePriceData[0] + singlePriceData[2];
	        boolean present=false;
			
			for (String s : singlePricingBlob) {
				System.out.println("the string retrived is= " + s);
				String[] afterSplit = s.split("\\|");

				String storeId=afterSplit[0];
				String productId=afterSplit[2];
				String priceType=afterSplit[3];
				String startDate=afterSplit[4].substring(0, 10);
				String startTime=afterSplit[4].substring(11,19);
				String startDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit[4]);
		 		String endDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit[5]);
				String endDate=afterSplit[5];
				String price=afterSplit[6];
				
				if (compareDates(startDate, endDate) == true) // first check if  the dates are valid
				{
					if (!validateStore(storeId)) // //check if store exists in store collection
						return; 
					else {
						 if (productId.substring(8, 11).equals("000")) {
						       ///After store is checked creating id
								String id = storeId + "-"+ productId.substring(0, 8);
								
								
									URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, id);
									storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
									finalId=id;
									if (storePricingGB==null)
									{
										CompareValuesUtility.logFailed("Comments",finalId,"No result found in gb");
										present=true;
										break;   
									 }else{
										 Double pPrice=Double.parseDouble(price);
										 if(priceType.equalsIgnoreCase("r")){
										 if(storePricingGB.getP()!=null&&storePricingGB.getP().getR()!=null){
											 for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {	 
												 if (startDate.equals(storePricingGB.getP().getR().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getR().get(k).getSt().toString().substring(11,19))){
										 CompareValuesUtility.logPassed("Id", id, id);
										 CompareValuesUtility.compareValues("Price Type", "R", "R");
										 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getR().get(k).getIp().toString());
										 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getR().get(k).getSt().toString());
										 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getR().get(k).getEt().toString());
										 present=true;	
										 break;
												 }
											 }
										 }else{
											 CompareValuesUtility.logFailed("Comments",finalId,"No R price found in gb"); 
											 present=true;
										 }
										 }
										 if(priceType.equalsIgnoreCase("p")){
									 if(storePricingGB.getP()!=null&&storePricingGB.getP().getS()!=null){
										 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {	 
											 if (startDate.equals(storePricingGB.getP().getS().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getS().get(k).getSt().toString().substring(11,19))){
									 CompareValuesUtility.logPassed("Id", id, id);
									 CompareValuesUtility.compareValues("Price Type", "P", "P");
									 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getS().get(k).getIp().toString());
									 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getS().get(k).getSt().toString());
									 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getS().get(k).getEt().toString());
									 present=true;	
									 break;
											 }
										 }
									 }else{
										 CompareValuesUtility.logFailed("Comments",finalId,"No P price found in gb"); 
										 present=true;
									 }
										 }
										 if(priceType.equalsIgnoreCase("x")){
									 if(storePricingGB.getP()!=null&&storePricingGB.getP().getX()!=null){
										 for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {	 
											 if (startDate.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(11,19))){
									 CompareValuesUtility.logPassed("Id", id, id);
									 CompareValuesUtility.compareValues("Price Type", "X", "X");
									 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getX().get(k).getIp().toString());
									 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getX().get(k).getSt().toString());
									 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getX().get(k).getEt().toString());
									 present=true;	
									 break;
											 }
										 }
									 }else{
										 CompareValuesUtility.logFailed("Comments",finalId,"No X price found in gb"); 
										 present=true;
									 }
										 }
											 if(storePricingGB.getMpf().getMp()!=null){
											 CompareValuesUtility.compareValues("MPFValue", "true",storePricingGB.getMpf().getMp().toString());
											 }
											 if(storePricingGB.getMpf().getSt()!=null){
												CompareValuesUtility.compareValues("StartDate", "",storePricingGB.getMpf().getSt().toString());
											 }
											 if(storePricingGB.getMpf().getEt()!=null){
												CompareValuesUtility.compareValues("EndDate", "",storePricingGB.getMpf().getEt().toString());	
											 }
									 }													
							      }
									
						
						
						 
					//Start of sku code
					else {
					       ///After store is checked creating id
							String id = storeId + "-"+ productId;
							
							
								storePricingGB = RestExecutor.getDataById(CollectionValuesVal.STOREPRICING, id);
								finalId=id;
								if (storePricingGB==null)
								{
									CompareValuesUtility.logFailed("Id",finalId,"No result found in gb");
								present=true; 
								break;  
								 }else{
									 Double pPrice=Double.parseDouble(price);
									 if(priceType.equalsIgnoreCase("r")){
									 if(storePricingGB.getP()!=null&&storePricingGB.getP().getR()!=null){
										 for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {	 
											 if (startDate.equals(storePricingGB.getP().getR().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getR().get(k).getSt().toString().substring(11,19))){
									 CompareValuesUtility.logPassed("Id", id, id);
									 CompareValuesUtility.compareValues("Price Type", "R", "R");
									 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getR().get(k).getIp().toString());
									 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getR().get(k).getSt().toString());
									 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getR().get(k).getEt().toString());
									 present=true;	
									 break;
											 }
										 }
									 }else{
										 CompareValuesUtility.logFailed("Comments",finalId,"No R price found in gb"); 
										 present=true;
									 }
									 }
									 if(priceType.equalsIgnoreCase("p")){
								 if(storePricingGB.getP()!=null&&storePricingGB.getP().getS()!=null){
									 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {	 
										 if (startDate.equals(storePricingGB.getP().getS().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getS().get(k).getSt().toString().substring(11,19))){
								 CompareValuesUtility.logPassed("Id", id, id);
								 CompareValuesUtility.compareValues("Price Type", "P", "P");
								 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getS().get(k).getIp().toString());
								 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getS().get(k).getSt().toString());
								 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getS().get(k).getEt().toString());
								 present=true;	
								 break;
										 }
									 }
								 }else{
									 CompareValuesUtility.logFailed("Comments",finalId,"No P price found in gb"); 
									 present=true;
								 }
									 }
									 if(priceType.equalsIgnoreCase("x")){
								 if(storePricingGB.getP()!=null&&storePricingGB.getP().getX()!=null){
									 for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {	 
										 if (startDate.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(0,10))&& startTime.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(11,19))){
								 CompareValuesUtility.logPassed("Id", id, id);
								 CompareValuesUtility.compareValues("Price Type", "X", "X");
								 CompareValuesUtility.compareValues("Price", pPrice,storePricingGB.getP().getX().get(k).getIp().toString());
								 CompareValuesUtility.compareValues("StartDate", startDate1,storePricingGB.getP().getX().get(k).getSt().toString());
								 CompareValuesUtility.compareValues("EndDate", endDate1,storePricingGB.getP().getX().get(k).getEt().toString());
								 present=true;	
								 break;
										 }
									 }
								 }else{
									 CompareValuesUtility.logFailed("Comments",finalId,"No X price found in gb"); 
									 present=true;
								 }
									 }
									 if(storePricingGB.getMpf()!=null){
										 CompareValuesUtility.compareValues("MPFValue", "true",storePricingGB.getMpf().getMp().toString());
										 CompareValuesUtility.compareValues("StartDate", "",storePricingGB.getMpf().getSt().toString());
										 CompareValuesUtility.compareValues("EndDate", "",storePricingGB.getMpf().getEt().toString());	 
									 }
								 													
						      
								
					
					} // /end of else for sku level clearance price
					}
					}// /end of else for checking values in store_pricing
				} else
					continue;
				
			} // end of for for each string
			if(present){
			CompareValuesUtility.setupResult(mainId, true);
			CompareValuesUtility.teardown();
			}
		}


		public boolean compareDates(String a, String b) { // method to check if date
															// is valid or not
			Date d = new Date();
			SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date c1 = sf.parse(sf.format(d)); // /to get current date

				Date a1 = sf.parse(a);
				Date b1 = sf.parse(b);

				if (b1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
																	// dates in the
																	// input file
				{
					return true;
				} else {
					return false;
				}
			} catch (ParseException pr) {
				pr.printStackTrace();
				return false;
			}
		}

		/**
		 * validates if store exists in store collection and adds the store to map
		 * if exists with value as true
		 * 
		 * @param stor
		 * @return
		 */
		public boolean validateStore(String stor) {
			if (storeIds.containsKey(stor)) {
				boolean storeStatus = storeIds.get(stor);
				return storeStatus;
			} else {

				String com = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, stor);
				if (com != "[]" || com != null) {
					storeIds.put(stor, true);
					return true;
				} else {
					storeIds.put(stor, false);
					return false;
				}
			}

		}
		
		
		class PriceDetailVO{
			String type, price, startDate, endDate;
			public PriceDetailVO(String type, String startDate, String endDate, String price) {
				
				this.type = type;
				this.price = price;
				this.startDate = startDate;
				this.endDate = endDate;
				
			}
		}

			
		
		
	}


