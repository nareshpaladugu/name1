package com.shi.content.wcsmigration.tests;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.uvd.AutomotiveProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.verifications.UVD_ImaPidVerifications;

public class UVD_ImaPidTests {
	
	private static Set<String> ProccessedImaPids = new HashSet<String>();

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="UVDImaPidTest")
	public void uvdImaPidTest(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);

		System.out.println("Testing sFileName "+ sFileName);
		//String vendorId = sFileName.split("\\.")[0].split("-")[3];

		BlockingQueue<List<AutomotiveProductOffer>> imaPidQueue = new LinkedBlockingQueue<List<AutomotiveProductOffer>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<AutomotiveProductOffer> prodThread = new ChunkProducerThread<AutomotiveProductOffer>(sFileName, imaPidQueue, AutomotiveProductOffer.class,"automotive-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<AutomotiveProductOffer> nodeToTest = imaPidQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					if(!ProccessedImaPids.contains(nodeToTest.get(0).getImaClassControlPid())){
						pool.execute(new UVD_ImaPidVerifications(
								nodeToTest.get(0).getImaClassControlPid(), 
								nodeToTest.get(0).getProductOfferings().getProductOffer(0),
								nodeToTest.get(0).getProductContent()));
						ProccessedImaPids.add(nodeToTest.get(0).getImaClassControlPid());
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
