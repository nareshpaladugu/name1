package com.shi.content.ranking.threepointfive;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

/**
 * @author ddaphal
 *
 */
public class RankingPromoRelVerificationTest {

	public static Long CURRENT_TIME;

	@Test(description="Tests to read from sywoffers-ift queue and validate IFT Mongo", groups="RankingPromoRelVerificationTest")
	public void mprtContOffrTests() throws Exception {


		BlockingQueue<List<com.generated.vos.proto.itemPromo.PromoRelList>> mpContOffrDocs = 
				new LinkedBlockingQueue<List<com.generated.vos.proto.itemPromo.PromoRelList>>();

		KafkaIAConsumer<com.generated.vos.proto.itemPromo.PromoRelList> prodThread =
				new KafkaIAConsumer<com.generated.vos.proto.itemPromo.PromoRelList>
		("RankingPromoRelVerificationTestQA", com.generated.vos.proto.itemPromo.PromoRelList.class, mpContOffrDocs);		
		Thread t = new Thread(prodThread);
		t.start();

		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<com.generated.vos.proto.itemPromo.PromoRelList> nodeToTest;

				nodeToTest = mpContOffrDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					pool.execute(new RankingPromoRelVerification(nodeToTest.get(0)));

				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}

	@BeforeTest(description="Daily routine before Test", groups="RankingPromoRelVerificationTest")
	public void loadData()
	{
		CURRENT_TIME  = System.currentTimeMillis();
	}
}
