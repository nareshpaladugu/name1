package com.shi.content.acme.ingest;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.CommonItemFieldsGroup;
import com.generated.vos.catdelta.Cpc;
import com.generated.vos.catdelta.Delete;
import com.generated.vos.catdelta.Fbm;
import com.generated.vos.catdelta.ItemDelete;
import com.generated.vos.catdelta.Shipping;
import com.generated.vos.catdelta.SpecificFbmsFieldsGroup;
import com.generated.vos.catdelta.Upsert;
import com.generated.vos.catdelta.VariantAttribute;
import com.generated.vos.catdelta.VariantItem;
import com.generated.vos.catdelta.Variation;
import com.generated.vos.catdelta.VariationDelete;
import com.generated.vos.catdelta.VariationGroupDelete;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.acme.ItemAuthorityTestCommon;

public class AcmeMPIngestVerifications implements Runnable {

	String programType;
	CommonFbmsFieldsGroup commonFields;
	CommonItemFieldsGroup commonItems;
	SpecificFbmsFieldsGroup specificFields;
	Cpc cpcNode;
	String confScore;
	String spinId,ssin, uid;
	Variation variation;
	private boolean bSingleProductOffer = true;
	String sellerId;
	String partNumberToTest;
	String dartPartNumber=null;
	private static final String FBM = "FBM";
	private static final String FBS = "FBS";
	private static final String DSS = "DSS";
	private static final String CPC = "CPC";
	Shipping shipping;
	Delete deleteNode;

	private String SSIN_XML =null;
	private String GUID_XML =null;

	private boolean deleteItemCheck;

	public AcmeMPIngestVerifications(Delete deleteNode, String sellerId){

		this.deleteNode=deleteNode;
		this.deleteItemCheck=true;
	}
	public AcmeMPIngestVerifications(Upsert upsertNode, String sellerId){

		this.deleteItemCheck = false;
		this.sellerId = sellerId;
		if(upsertNode.getUpsertTypeChoice().getFbm()!= null){
			programType = FBM;
			fetchData(upsertNode.getUpsertTypeChoice().getFbm());

		}else if(upsertNode.getUpsertTypeChoice().getFbs()!= null){
			programType = FBS;
			dartPartNumber = upsertNode.getUpsertTypeChoice().getFbs().getDartPartNumber();
			fetchData(convertToFBM(upsertNode.getUpsertTypeChoice().getFbs()));


		}else if(upsertNode.getUpsertTypeChoice().getDss() != null){
			programType = DSS;
			fetchData(convertToFBM(upsertNode.getUpsertTypeChoice().getDss()));

		}else if(upsertNode.getUpsertTypeChoice().getCpc()!= null){
			programType = CPC;
			cpcNode = upsertNode.getUpsertTypeChoice().getCpc();
			commonItems = cpcNode.getCommonItemFieldsGroup();
			if(cpcNode.getConfidenceScore()!= null)
				confScore = cpcNode.getConfidenceScore().toPlainString();
			spinId = cpcNode.getItemId()+"";
			ssin = cpcNode.getSsin();
			uid = cpcNode.getGuid();

			GUID_XML = cpcNode.getGuid();
			SSIN_XML = cpcNode.getSsin();
			partNumberToTest = cpcNode.getItemId()+"";

		}
		else if(upsertNode.getUpsertTypeChoice().getVariation() != null){

			variation = upsertNode.getUpsertTypeChoice().getVariation();
			programType = variation.getProgramType().name();
			commonFields = convertToCommon(variation.getCommonFbmsFieldsGroupVariation());
			if(variation.getConfidenceScore()!= null)
				confScore = variation.getConfidenceScore().toPlainString();
			bSingleProductOffer  = false;
			spinId = upsertNode.getUpsertTypeChoice().getVariation().getVariationGroupId();
		}

	}

	public static <T> Fbm convertToFBM(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		Fbm fbm=new Fbm();
		try {
			BeanUtils.copyProperties(fbm, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fbm;
	}

	public static <T> CommonFbmsFieldsGroup convertToCommon(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		CommonFbmsFieldsGroup commonsIncommons=new CommonFbmsFieldsGroup();
		try {
			BeanUtils.copyProperties(commonsIncommons, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsIncommons;
	}

	public static <T> SpecificFbmsFieldsGroup convertToSpecificFields(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		SpecificFbmsFieldsGroup commonsInSpecificFields=new SpecificFbmsFieldsGroup();
		try {
			BeanUtils.copyProperties(commonsInSpecificFields, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsInSpecificFields;
	}


	public void fetchData(Fbm fbmItem){
		commonFields = fbmItem.getCommonFbmsFieldsGroup();
		specificFields=fbmItem.getSpecificFbmsFieldsGroup();
		if(fbmItem.getConfidenceScore()!=null)
			confScore=fbmItem.getConfidenceScore().toPlainString();
		spinId = fbmItem.getItemId()+"";
		ssin = fbmItem.getSsin();
		uid = fbmItem.getGuid();
		GUID_XML = fbmItem.getGuid();
		SSIN_XML = fbmItem.getSsin();
		partNumberToTest=fbmItem.getItemId()+"";
	}

	private String sSourceJson;
	private AcmeSourceById iaSource;
	/**
	 * @param partNumberToTest
	 * @return
	 */
	public boolean  getIaSource(String partNumberToTest)
	{
		String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+partNumberToTest;
		System.out.println(sURL);
		URI uri=null;
		try {
			uri = new URI(sURL);
		} catch (URISyntaxException e) {

			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
			CompareValuesUtility.setupResult(partNumberToTest, true);
			return false;
		}

		this.sSourceJson = RestExecutor.getJSonResponse(uri);

		if(!sSourceJson.contains("item")){
			iaSource=null;
			/*CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
			CompareValuesUtility.setupResult(partNumberToTest, true);*/
			return false;
		}

		iaSource = JSONParser.parseJSON(this.sSourceJson, AcmeSourceById.class);

		/*if(iaSource == null){
			CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
			CompareValuesUtility.setupResult(partNumberToTest, true);
			return false;
		}*/

		return true;
	}

	private void verifySingleItemDelete(ItemDelete deleteItem)
	{
		if(deleteItem!=null)
		{
			CompareValuesUtility.init();

			String itemId = deleteItem.getItemId()+"";

			getIaSource(itemId);

			if(iaSource == null){
				CompareValuesUtility.logPassed("Id", itemId, " Not found");
			}else{

				/*ECOM-357862 –MP Ingester: Default status to DELETED for <delete> 
			    items where is no <item-status> in the feed as <item-status> is optional*/
				String sExpStatus;

				if(deleteItem.getItemStatusDetails()==null || deleteItem.getItemStatusDetails().getItemStatus()==null )
				{
					sExpStatus ="DELETED";
				}
				else
				{
					sExpStatus = deleteItem.getItemStatusDetails().getItemStatus().name();
				}

				//here sExpStatus = deleteItem.getItemStatusDetails().getItemStatus()
				compareDeleteStatus(sExpStatus, iaSource, deleteItem.getItemStatusDetails().getInactiveReason());

				/*ItemAuthorityTestCommon.compareTwoLists(deleteItem.getItemStatusDetails()==null?null:deleteItem.getItemStatusDetails().getInactiveReason(), 
						iaSource.getItem().getAttributes().getInactiveReason(), "Inactive Reason");*/

			}

			CompareValuesUtility.setupResult(itemId, true);
		}
	}

	VariantItem variantItem;

	public void run() 
	{
		if(deleteItemCheck)
		{
			//=============================== ItemDelete =============================

			ItemDelete deleteItem = deleteNode.getItemDelete();
			if(deleteItem!=null)
			{
				verifySingleItemDelete(deleteItem);
			}
			//============================= VariationDelet e=========================

			VariationDelete variationDelete = deleteNode.getVariationDelete();

			if(variationDelete!=null)
			{
				ItemDelete[] deleteItems = variationDelete.getItemDelete();

				for (ItemDelete itemDelete : deleteItems) {

					verifySingleItemDelete(itemDelete);
				}
			}

			//============================= VariationGroupDelete ===========================

			VariationGroupDelete variationGroupDelete = deleteNode.getVariationGroupDelete();

			if(variationGroupDelete!=null)
			{
				CompareValuesUtility.init();

				String variationGroupId = variationGroupDelete.getSellpoUniqueGroupId().toString();

				getIaSource(variationGroupId);

				if(iaSource == null){
					CompareValuesUtility.logPassed("Id", variationGroupId, " Not found");
				}else{

					String sExpStatus;

					if( variationGroupDelete.getItemStatusDetails()==null || variationGroupDelete.getItemStatusDetails().getItemStatus()==null )
					{
						sExpStatus ="DELETED";
					}
					else
					{
						sExpStatus =  variationGroupDelete.getItemStatusDetails().getItemStatus().name();
					}

					compareDeleteStatus(sExpStatus, iaSource, variationGroupDelete.getItemStatusDetails().getInactiveReason());

					/*ItemAuthorityTestCommon.compareTwoLists(variationGroupDelete.getItemStatusDetails()==null?null:variationGroupDelete.getItemStatusDetails().getInactiveReason(), 
							iaSource.getItem().getAttributes().getInactiveReason(), "Inactive Reason");*/

				}

				CompareValuesUtility.setupResult(variationGroupId, true);
			}
		}
		else
		{
			if(bSingleProductOffer)
			{
				/*if(!partNumberToTest.equals("8354825702"))
				{
					return;
				}*/

				System.out.println(" ........  [NV] partNumberToTest... "+partNumberToTest);
				callVerifications(partNumberToTest,"NV","");
			}
			else
			{
				/*if(true)
				return;*/
				/*--------------------- [P] -------------------*/
				partNumberToTest = variation.getSellpoUniqueGroupId().toString();
				System.out.println(" ........  [P] partNumberToTest... "+partNumberToTest);
				specificFields = convertToSpecificFields(variation.getVariantItems().getVariantItem(0).getSpecificFbmsFieldsGroupVariation());
				callVerifications(partNumberToTest,"P",variation.getSellpoUniqueGroupId().toString());

				/*-------------------------- variant items loop [V]-------------------*/

				for(VariantItem varItem : variation.getVariantItems().getVariantItem())
				{
					SSIN_XML = varItem.getSsin();
					GUID_XML = varItem.getGuid();

					spinId=varItem.getItemId()+"";

					this.variantItem = varItem;
					partNumberToTest = varItem.getItemId()+"";
					dartPartNumber = varItem.getDartPartNumber();
					System.out.println(" ........  [V] partNumberToTest... "+partNumberToTest);
					specificFields = convertToSpecificFields(varItem.getSpecificFbmsFieldsGroupVariation());
					callVerifications(partNumberToTest,"V",variation.getSellpoUniqueGroupId().toString());
				}
			}
		}

	}

	/*private void verifyAutoFitment(Attribute[] prodAttributes,IaSourceById iaSource,String modelNumber)
	{
		SHCContentCommons commonUtils = new SHCContentCommons("","sears");

		boolean isBrandCodeFound=false;

		String sBrandCodeId =null ;

		if(prodAttributes!=null)
		{
			for (Attribute pa : prodAttributes) {
				if(pa.getItemAttributeGroup().getAttributeId().toString().equals("873910"))
				{
					sBrandCodeId = pa.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree();
					isBrandCodeFound=true;
					break;
				}
			}

			boolean checkForNull = true;
			for (Attribute pa : prodAttributes) 
			{
				if(pa.getItemAttributeGroup().getAttributeId().toString().equals("1035210"))
				{
					if(pa.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId().toString().equals("2509310"))
					{
						if(isBrandCodeFound)
						{
							boolean isFit = commonUtils.fitmentValidation(sBrandCodeId, modelNumber);

							checkForNull = false;
							CompareValuesUtility.compareValues("autoFitment", isFit, iaSource.getItem().getAttributes().getAutoFitment());
						}
					}
				}
			}

			if(checkForNull)
			{
				CompareValuesUtility.verifyNull("autoFitment", iaSource.getItem().getAttributes().getAutoFitment());
			}
		}
	}*/

	/**
	 * Compares delete status with expected from isSource item
	 * @param sExpStatus
	 * @param iaSource
	 * @param strings 
	 */
	private void compareDeleteStatus(String sExpStatus, AcmeSourceById iaSource, String[] reasonList)
	{
		sExpStatus = sExpStatus==null?"DELETED":sExpStatus;

		String sActStatus;

		if(iaSource.getItem()==null||iaSource.getItem().getStatus()==null)
		{
			sActStatus = "null";
		}
		else
		{
			sActStatus = iaSource.getItem().getStatus();
		}

		CompareValuesUtility.compareValues("Status", sExpStatus ,  sActStatus);
		CompareValuesUtility.compareValues("Attr.Status", sExpStatus ,  iaSource.getItem().getAttributes().getStatus().getStatus());
		
		List<String> actReasonLst = iaSource.getItem().getAttributes().getStatus().getStatusReason();

		if(reasonList.length != 0){
						
			for(String reason : reasonList){
				CompareValuesUtility.verifyItemInList("StatusReason", reason, actReasonLst);
			}
		}else{
			CompareValuesUtility.verifyNull("StatusReason", actReasonLst.isEmpty()?null:actReasonLst);
		}
	}

	private void callVerifications( String partNumberToTest,String classifier,String parentId) {

		try{
			CompareValuesUtility.init();

			getIaSource(partNumberToTest);

			if(iaSource == null){
				CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
				CompareValuesUtility.logFailed("vendorId", sellerId , " Not found");
				CompareValuesUtility.setupResult(partNumberToTest, true);
				return;
			}else{

				if(commonFields!=null)
					commonItems = commonFields.getCommonItemFieldsGroup();

				compareValues("Id", partNumberToTest, iaSource.getItem().getId());
				compareValues("vendorId", sellerId , iaSource.getItem().getVendorId());
				
				if(AcmeMPIngestTest.bVerifyNotNullSsinGuid){
					CompareValuesUtility.verifyNotNull("ssin", iaSource.getItem().getSsin());
					CompareValuesUtility.verifyNotNull("guid", iaSource.getItem().getGuid());
				}

				/*if(AcmeMPIngestTest.bValidatedOnlySSINnGUID)
				{
					//new ItemAuthorityTestCommon().validateSSINnGUID(iaSource,SSIN_XML,GUID_XML,classifier);
					System.out.println("ok");
				}
				else
				{*/

					String sActualTitle = JsonStringParser.getJsonValue(this.sSourceJson,"{item{attributes{title}}}");

					compareValues("title",TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(OfferCommons.replaceNewline(commonItems.getTitle())), 
							sActualTitle);

					String sExpectedShortDesc = commonItems.getShortDesc()==null?null:
						TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(OfferCommons.replaceNewline(commonItems.getShortDesc()));

					String sActualShortDesc = JsonStringParser.getJsonValue(this.sSourceJson,"{item{attributes{shortDesc}}}");

					verifyNullOrEqual("shortDesc", sExpectedShortDesc, sActualShortDesc);

					String sActualLongDesc = JsonStringParser.getJsonValue(this.sSourceJson,"{item{attributes{longDesc}}}");

					if(commonFields!=null)
					{
						verifyNullOrEqual("longDesc",commonFields.getLongDesc()==null?null:
							TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(OfferCommons.replaceNewline(commonFields.getLongDesc())),
							sActualLongDesc);

						verifyNullOrEqual("brandId",commonFields.getBrand()==null?null:commonFields.getBrand().getId(),	iaSource.getItem().getAttributes().getBrandId());
						verifyNullOrEqual("brandName", commonFields.getBrand()==null?null:TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(commonFields.getBrand().getName()), iaSource.getItem().getAttributes().getBrandName());
						//BrandImage brandImage = iaSource.getItem().getAttributes().getBrandImage();

						//verifyNullOrEqual("brandImage", commonFields.getBrand()==null?null:IngestCommons.convertImageUrl(commonFields.getBrand().getLogoImageUrl()), brandImage==null?null:brandImage.getUrl());
						verifyNullOrEqual("modelNumber", commonFields.getModelNumber(), iaSource.getItem().getAttributes().getModelNumber());
						//verifyNullOrEqual("manufacturerName", commonFields.getManufacturerName() , iaSource.getItem().getAttributes().getManufacturerName());

					}


					verifyNullOrEqual("classifier",classifier, iaSource.getItem().getAttributes().getClassifier());
					verifyNullOrEqual("Status", "ACTIVE", iaSource.getItem().getStatus());
					verifyNullOrEqual("feedSource", "sellerPortal", iaSource.getItem().getAttributes().getFeedSource());
					compareValues("itemClassId", commonItems.getItemClassId() , iaSource.getItem().getItemClassId());
					compareValues("attrItemClassId", commonItems.getItemClassId() , iaSource.getItem().getAttributes().getItemClassId());
					verifyNullOrEqual("programType", programType, iaSource.getItem().getAttributes().getProgramType());
					//compareValues("spinId", spinId, iaSource.getItem().getAttributes().getSpinId());

					if(classifier.equalsIgnoreCase("V"))
					{
						Map<String, List<com.shi.content.acme.VarAttr>> actaulMapVarAttr = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(sSourceJson, "{item{attributes{varAttr}}}"));

						VariantAttribute[] variantAttributes =    variantItem.getVariantAttributes().getVariantAttribute();

						Map<String, List<com.shi.content.acme.VarAttr>> expectedMapVarAttr = ItemAuthorityTestCommon.getVarAttrMapXml(variantAttributes);

						new ItemAuthorityTestCommon().compareAttributesMaps(expectedMapVarAttr, actaulMapVarAttr,true,"varAttr",true);

						verifyNullOrEqual("pid", parentId , iaSource.getItem().getAttributes().getPid());
					}
					else
					{
						if(commonFields!=null && commonFields.getAttributes()!=null)
						{
							Attribute[] prodAttributes = commonFields.getAttributes().getAttribute();

							for (Attribute pa : prodAttributes) {

								if(pa.getItemAttributeGroup().getAttributeId().toString().equals("28101") ||
										pa.getItemAttributeGroup().getAttributeId().toString().equals("11720") ||
										pa.getItemAttributeGroup().getAttributeId().toString().equals("242"))
								{
									/*verifyNullOrEqual("brandCodeId",pa.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree(),
											iaSource.getItem().getAttributes().getBrandCodeId());*/
									
									String pkgQty = pa.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree();
									verifyNullOrEqual("packageQuantity", pkgQty ,iaSource.getItem().getAttributes().getPackageQuantity());

									break;
								}
							}

							//verifyAutoFitment(prodAttributes, iaSource,commonFields.getModelNumber());

							Map<String, List<com.shi.content.acme.VarAttr>> xmlAttributeMap = ItemAuthorityTestCommon.getattributesMapXml(commonFields.getAttributes());

							Map<String, List<com.shi.content.acme.VarAttr>> jsonAttributeMal = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(sSourceJson, "{item{attributes{attributes}}}"));

							new ItemAuthorityTestCommon().compareAttributesMaps(xmlAttributeMap, jsonAttributeMal,true,"attributes",true);
						}

					}

					SHCContentCommons commonUtils = new SHCContentCommons();

					//String xmlEnrichment = commonItems.getEnrichmentInfo()==null?"SP":commonItems.getEnrichmentInfo().getEnrichmentProvider().value();
					//String sSourceEnrichmentExp = commonUtils.getEnrichmentProvider(xmlEnrichment, false);
					//compareValues("enrichmentProvider", sSourceEnrichmentExp, iaSource.getItem().getAttributes().getEnrichmentProvider());

					/*if(commonFields!=null)
						verifyTaxonomy(commonFields.getCommonItemFieldsGroup().getSite(), iaSource.getItem().getAttributes().getSites());
					
					if(classifier.equalsIgnoreCase("P"))
					{
						VariantItem firstChild = variation.getVariantItems().getVariantItem()[0];
						verifyPrimaryImage( firstChild.getSpecificFbmsFieldsGroupVariation().getImageUrl(), iaSource.getItem().getAttributes().getPrimaryImage());
					}
					else
					{
						if(programType.equalsIgnoreCase("CPC"))
							verifyPrimaryImage( cpcNode.getImageUrl(), iaSource.getItem().getAttributes().getPrimaryImage());
						else
							verifyPrimaryImage( specificFields==null?null:specificFields.getImageUrl(), iaSource.getItem().getAttributes().getPrimaryImage());
					}

					if(commonFields!=null)
						verifyFeatureImage(commonFields.getFeatureImageUrls(), iaSource.getItem().getAttributes().getFeatureImages());

					CompareValuesUtility.verifyNullOrFalse("isMature", commonItems.isMatureContent() , iaSource.getItem().getAttributes().getIsMature());
					*/
					if(programType.equalsIgnoreCase("CPC"))
						verifyNullOrEqual("upcCode", classifier=="P"?null:cpcNode.getUpc(), iaSource.getItem().getAttributes().getUpcCode());
					else
						verifyNullOrEqual("upcCode", classifier=="P"?null:specificFields.getUpc(), iaSource.getItem().getAttributes().getUpcCode());

					/*newly added*/
					verifyNullOrEqual("attributes.Status", "ACTIVE", iaSource.getItem().getAttributes().getStatus().getStatus());
					CompareValuesUtility.verifyNull("StatusReason", iaSource.getItem().getAttributes().getStatus().getStatusReason().isEmpty()?null:iaSource.getItem().getAttributes().getStatus().getStatusReason());
					verifyNullOrEqual("varGrpId", classifier=="P"?variation.getVariationGroupId():null, iaSource.getItem().getAttributes().getVarGroupId());
					verifyNullOrEqual("dartPartnumber", (programType=="FBS"?(classifier=="P"?null:dartPartNumber):null), iaSource.getItem().getAttributes().getDartPartNumber());
					//verifyNullOrEqual("inactiveReason", "[]",iaSource.getItem().getAttributes().getInactiveReason());

					/*if(commonFields!=null)
						verifyProdAssets(commonFields.getCommonItemFieldsGroup().getProductAssets(), iaSource.getItem().getAttributes().getProductAssets());
					*/
					
					String calcSsin = calculateSsin(programType, classifier, iaSource.getItem().getId());
					verifyNullOrEqual("calcSsin", calcSsin, iaSource.getItem().getCalcSsin());
				//}
			}

			CompareValuesUtility.setupResult(partNumberToTest, true);
		}catch(Throwable e){
			System.out.println("Check this id :"+ partNumberToTest);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}
	
	private String calculateSsin(String pgrmType, String classifier, String id) {
		String calcSsin = null;
		if(classifier.equals("NV") || classifier.equals("V")){
			switch(pgrmType){
			case "FBM":
			case "DSS":
				calcSsin = "SPM" + id;
				break;
			case "FBS":
				calcSsin = dartPartNumber;
				break;
			case "CPC":
				calcSsin = "SPA" + sellerId + "S" + id;
				break;
			default:
				System.out.println("Invalid programType: " + pgrmType);
			}
		}else{
			calcSsin = TestUtils.generateVariationId(sellerId, spinId, pgrmType);
		}
		return calcSsin.replaceAll(" ", "");
	}

	/*private String convertUnicodeNine(String s) {
		if (s == null)
			return null;
		String space = " ";
		char x = space.charAt(0);
		StringBuffer out = new StringBuffer();
		for (int i = 0; i < s.length(); i++){
		    char c = s.charAt(i);   
		    if (("\\u" + Integer.toHexString(c | 0x10000).substring(1)).equals("\\u0009")){
      	    	out.append("");
		    	System.out.println("replaced \\u0009");
		    }else
			{
				out.append(c);
			}
		}
		return out.toString().replaceAll("\\n", " ").replaceAll("</b><", "</b> <");
	}*/
	/*private void verifyProdAssets(com.generated.vos.catdelta.ProductAssets productAssets, List<ProductAsset> iaSrcPrdAssets) {
		if(productAssets!=null) {
			for each asset in xml
			for(com.generated.vos.catdelta.ProductAsset xmlPrdAsset : productAssets.getProductAsset()) {
				if(!(iaSrcPrdAssets.size()==0)) {
					Boolean assetFoundInIA=false;
					for each asset in IA source
					for(ProductAsset iaSrcPrdAsset : iaSrcPrdAssets) {
						if(xmlPrdAsset.getType().name().equals(iaSrcPrdAsset.getType()) && IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()).equals(iaSrcPrdAsset.getUrl())) {
							compareValues("ProductAsset", xmlPrdAsset.getType().name(), iaSrcPrdAsset.getType(), "Type");
							compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), iaSrcPrdAsset.getUrl(), "Url");
							verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), iaSrcPrdAsset.getName(), "Name");
							verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), iaSrcPrdAsset.getHeight(), "Height");
							verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), iaSrcPrdAsset.getWidth(), "Width");
							//verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank(), iaSrcPrdAsset.getRank(), "Rank");
							assetFoundInIA=true;
							break;
						}
					}
					if(!assetFoundInIA) {
						compareValues("ProductAsset", xmlPrdAsset.getType().name(), null, "Type");
						compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), null, "Url");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), null, "Name");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), null, "Height");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), null, "Width");
						//verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank(), null, "Rank");
					}
				}else{
					compareValues("ProductAsset", xmlPrdAsset.getType().name(), null, "Type");
					compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), null, "Url");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), null, "Name");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), null, "Height");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), null, "Width");
					//verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank(), null, "Rank");
				}
			}
		}else{
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Type");
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Url");
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Name");
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Height");
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Width");
			verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Rank");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	private void verifyFeatureImage(FeatureImageUrls[] featureImageUrls, List<FeatureImage> iaSrcFeatImgs) {
		if(featureImageUrls!=null) {
			for each feat img in xml
			for(FeatureImageUrls xmlFeatImg : featureImageUrls) {

				Image[] fImages = xmlFeatImg.getImage();
				for (Image image : fImages) {

					if(!(iaSrcFeatImgs.size()==0)) {
						Boolean featImgFoundInIA=false;
						for each feat img in IA source
						for(FeatureImage iaSrcFeatImg : iaSrcFeatImgs) {
							if(IngestCommons.convertImageUrl(image.getUrl()).equals(iaSrcFeatImg.getUrl())) {
								compareValues("FeatureImg", IngestCommons.convertImageUrl(image.getUrl()), iaSrcFeatImg.getUrl(), "Url");
								verifyNullOrEqual("FeatureImg",image.getHeight(), iaSrcFeatImg.getHeight(), "Height");
								verifyNullOrEqual("FeatureImg", image.getWidth(), iaSrcFeatImg.getWidth(), "Width");
								//verifyNullOrEqual("FeatureImg", image.get , iaSrcFeatImg.getName(), "Name");
								//verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank(), iaSrcFeatImg.getRank(), "Rank");
								featImgFoundInIA=true;
								break;
							}
						}if(!featImgFoundInIA) {
							compareValues("FeatureImg", IngestCommons.convertImageUrl(image.getUrl()), null, "Url");
							verifyNullOrEqual("FeatureImg", image.getHeight(), null, "Height");
							verifyNullOrEqual("FeatureImg", image.getWidth(), null, "Width");
							//verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getName(), null, "Name");
							//verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank(), null, "Rank");
						}
					}else{
						compareValues("FeatureImg", IngestCommons.convertImageUrl(image.getUrl()), null, "Url");
						verifyNullOrEqual("FeatureImg",image.getHeight(), null, "Height");
						verifyNullOrEqual("FeatureImg", image.getWidth(), null, "Width");
						//verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getName(), null, "Name");
						//verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank(), null, "Rank");
					}
				}
			}
		}else{
			verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Url");
			verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Height");
			verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Width");
			verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Name");
			verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Rank");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	private void verifyPrimaryImage(ImageUrl imageUrl,
			List<com.generated.vos.iasourcebyid.PrimaryImage> iaSrcPriImg) {

		if(imageUrl!=null) 
		{
			verifyNullOrEqual("PrimaryImg", IngestCommons.convertImageUrl(imageUrl.getUrl()), (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getUrl())), "Url");
			verifyNullOrEqual("PrimaryImg", imageUrl.getHeight(), (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getHeight())), "Height");
			verifyNullOrEqual("PrimaryImg", imageUrl.getWidth(), (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getWidth())), "Width");
			//	verifyNullOrEqual("PrimaryImg", imageUrl, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getName(), "Name");
		}else{
			verifyNullOrEqual("PrimaryImg", null, (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getUrl())), "Url");
			verifyNullOrEqual("PrimaryImg", null, (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getHeight())), "Height");
			verifyNullOrEqual("PrimaryImg", null, (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getWidth())), "Width");
			verifyNullOrEqual("PrimaryImg", null, (iaSrcPriImg.size()==0?null:(iaSrcPriImg==null?null:iaSrcPriImg.get(0).getName())), "Name");
		}
	}


	private void verifyTaxonomy(com.generated.vos.catdelta.Site[] sites, List<com.generated.vos.iasourcebyid.Site> iaSrcSites) {
		if(sites!=null) {

			CompareValuesUtility.addNewMultiValuedFields();	
			for each site in xml
			for(com.generated.vos.catdelta.Site xmlSite : sites) {
				if(!(iaSrcSites.size()==0)) {
					Boolean siteFoundInIA=false;
					for each site in IA source
					for(com.generated.vos.iasourcebyid.Site iaSrcSite : iaSrcSites) {
						if(xmlSite.getId().toString().equals(iaSrcSite.getId())) {
							compareValues("Sites", xmlSite.getId().toString(), iaSrcSite.getId(), "SiteId");
							for each hierarchy id under xml site
							for(com.generated.vos.catdelta.Hierarchy xmlHier : xmlSite.getTaxonomy().getHierarchy()) {
								if(!(iaSrcSite.getTaxonomy().getHierarchy().size()==0)) {
									Boolean hierFoundInIA=false;
									for each hierarchy id under IA source site
									for(com.generated.vos.iasourcebyid.Hierarchy iaSrcHier : iaSrcSite.getTaxonomy().getHierarchy()) {
										if(xmlHier.getId().toString().equals(iaSrcHier.getId())) {
											compareValues("Sites", xmlHier.getId(), iaSrcHier.getId(), "HierarchyId");
											//compareValues("Sites", xmlHier.getPrimary(), iaSrcSite.getId(), "Primary");
											hierFoundInIA=true;
											break;
										}
									}
									if(!hierFoundInIA) {
										compareValues("Sites", xmlHier.getId(), null, "HierarchyId");
									}
								}else{
									compareValues("Sites", xmlHier.getId(), null, "HierarchyId");
								}
							}
							siteFoundInIA=true;
							break;
						}
					}if(!siteFoundInIA) {
						compareValues("Sites", xmlSite.getId().toString(), null, "SiteId");
					}
				}else{
					compareValues("Sites", xmlSite.getId().toString(), null, "SiteId");
				}
			}
		}else{
			verifyNullOrEqual("Sites", null, iaSrcSites.size()==0?null:"Sites found in IA", "SiteId");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}*/

}
