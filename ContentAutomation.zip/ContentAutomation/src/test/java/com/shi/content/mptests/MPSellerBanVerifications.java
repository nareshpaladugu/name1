package com.shi.content.mptests;

import java.util.List;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class MPSellerBanVerifications implements Runnable {

	int bucketCounter;
	String seller_id;
	
	public MPSellerBanVerifications(int bucket,String seller_id)
	{
		this.seller_id=seller_id;
		this.bucketCounter=bucket;
	}
	
	public void run()
	{

		try {
			//System.out.println("bucket number ...................."+bucketCounter);
			List<String> lstIdsInBucket = RestExecutor
					.getFilteredIds(CollectionValuesVal.OFFER,
							bucketCounter, "sellerId", seller_id);
			
			//System.out.println("lstIdsInBucket....."+lstIdsInBucket);
			for (String id : lstIdsInBucket) {
				checkSingleItem(id);
			}
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	private void checkSingleItem(String id) {
		CompareValuesUtility.init();

		Offer offerDoc = RestExecutor
				.getDataById(CollectionValuesVal.OFFER, id);
		if (offerDoc == null) {
			CompareValuesUtility.logPassed("ItemId", id, "Offer NOT found");
		} else {
			CompareValuesUtility.logFailed("ItemId", id, "Offer found");
		}

		CompareValuesUtility.setupResult(id, true);
	}

}
