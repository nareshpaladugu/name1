package com.shi.content.realtime.mp;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;

import com.generated.vos.catdelta.ClickCaptureUrl;
import com.generated.vos.catdelta.CommissionRate;
import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.CommonItemFieldsGroup;
import com.generated.vos.catdelta.Cpc;
import com.generated.vos.catdelta.Fbm;
import com.generated.vos.catdelta.FeatureImageUrls;
import com.generated.vos.catdelta.Hierarchy;
import com.generated.vos.catdelta.ProductAsset;
import com.generated.vos.catdelta.Shipping;
import com.generated.vos.catdelta.SpecificFbmsFieldsGroup;
import com.generated.vos.catdelta.VariantAttribute;
import com.generated.vos.catdelta.VariantItem;
import com.generated.vos.catdelta.Variation;
import com.generated.vos.catdelta.types.AttributeTypeType;
import com.generated.vos.catdelta.types.TypeType;
import com.generated.vos.proto.catalog.Catalog;
import com.generated.vos.proto.catalog.Header;
import com.generated.vos.proto.catalog.Item;
import com.generated.vos.proto.catalogcommons.Asset;
import com.generated.vos.proto.catalogcommons.AssetType;
import com.generated.vos.proto.catalogcommons.Attribute;
import com.generated.vos.proto.catalogcommons.AttributeType;
import com.generated.vos.proto.catalogcommons.Image;
import com.generated.vos.proto.catalogcommons.ProgramType;
import com.generated.vos.proto.content.Brand;
import com.generated.vos.proto.content.CommRate;
import com.generated.vos.proto.content.CommissionRates;
import com.generated.vos.proto.content.Content;
import com.generated.vos.proto.content.EnrichmentInfo;
import com.generated.vos.proto.content.EnrichmentProvider;
import com.generated.vos.proto.content.Site;
import com.generated.vos.proto.content.Taxonomy;
import com.generated.vos.proto.offer.ChokingHazards;
import com.generated.vos.proto.offer.ClickCaptureUrls;
import com.generated.vos.proto.offer.ConditionType;
import com.generated.vos.proto.offer.Dimensions;
import com.generated.vos.proto.offer.Flags;
import com.generated.vos.proto.offer.GeoLimiters;
import com.generated.vos.proto.offer.ItemCondition;
import com.generated.vos.proto.offer.Offer;
import com.generated.vos.proto.offer.USDotShipType;
import com.shc.autocontent.kafkautils.KafkaProducer;
import com.shc.autocontent.parsers.JSONParser;
import com.shi.content.Variations.SHCContentCommons;

public class MPRealtimeContOfferGenPost implements Runnable{

	SHCContentCommons commonUtils = new SHCContentCommons("","sears");
	List<Fbm> wNodeList;
	List<Cpc> wNodeListCpc;
	List<Variation> wNodeListVar;
	String sFileName;
	boolean isCpc = false;
	String sSellerId=null;
	String sVariationGroupId=null;
	String sVariationPgrmType=null;
	KafkaProducer kProd;
	String pgrmType;
	boolean isVariation = false;

	CommonFbmsFieldsGroup commonFields;
	SpecificFbmsFieldsGroup specificFields;
	
	Catalog mpContOffrDoc = new Catalog();
	Header header = new Header();
	List<Item> itemList = new ArrayList<Item>();

	public MPRealtimeContOfferGenPost(
			KafkaProducer kProd,
			List<Fbm> wNodeList, 
			String pgrmType,
			String sSeller){
		this.wNodeList = wNodeList;
		this.pgrmType = pgrmType;
		this.kProd = kProd;
		this.sSellerId=sSeller;
	}

	public MPRealtimeContOfferGenPost(
			KafkaProducer kProd,
			List<Cpc> wNodeListCpc, 
			boolean cpc, 
			String sSeller){
		isCpc = true;
		this.wNodeListCpc = wNodeListCpc;
		this.sSellerId=sSeller;
		this.kProd = kProd;
		this.pgrmType = "CPC";
	}

	public MPRealtimeContOfferGenPost(
			KafkaProducer kProd,
			List<Variation> wNodeListVar, 
			String pgrmType, 
			String sSeller,
			boolean variation) {
		this.kProd = kProd;
		this.pgrmType = pgrmType;
		this.sSellerId = sSeller;
		this.wNodeListVar = wNodeListVar;
		this.isVariation = true;
	}

	public void run() 
	{	
		header.setVer("v1");
		header.setMsgDtm(System.currentTimeMillis());
		header.setMsgId("1");
		mpContOffrDoc.setHeader(header);		
		
		if(isCpc){
			cpcGeneration();
		}
		else if(isVariation){
			varGrpGeneration();
		}
		else{
			for(Fbm fbmItem : wNodeList) {
				Item item = new Item();
				Content content = new Content();
				List<Offer> offerList = new ArrayList<Offer>();
				Offer offer = new Offer();
				
				try{
					/*Content fields*/
					content.setContentId(fbmItem.getItemId());
					content = setCommonItemFields(content, fbmItem.getCommonFbmsFieldsGroup().getCommonItemFieldsGroup());
					content = setCommonFbmsFields(content, fbmItem.getCommonFbmsFieldsGroup());
					content.setOwnerId(Integer.parseInt(sSellerId));
					content.setPgmType(getPgrmType(pgrmType));
					
					//image-url at content level
					/*Image primeImg = new Image();
					primeImg.setUrl(fbmItem.getSpecificFbmsFieldsGroup().getImageUrl().getUrl());
					if(fbmItem.getSpecificFbmsFieldsGroup().getImageUrl().getHeight()!=null)
						primeImg.setHeight(fbmItem.getSpecificFbmsFieldsGroup().getImageUrl().getHeight().intValue());
					if(fbmItem.getSpecificFbmsFieldsGroup().getImageUrl().getWidth()!=null)
						primeImg.setWidth(fbmItem.getSpecificFbmsFieldsGroup().getImageUrl().getWidth().intValue());
					content.setPrimeImg(primeImg);*/
					
					/*Offer fields*/
					offer = setOfferIds(offer, 
							fbmItem.getItemId(),
							fbmItem.getItemId(), 
							fbmItem.getUid(), 
							fbmItem.getSsin(), 
							fbmItem.getGuid(), 
							fbmItem.getDartPartNumber());
					
					offer.setItemClassId(fbmItem.getCommonFbmsFieldsGroup().getCommonItemFieldsGroup().getItemClassId());
					offer = setDimensions(offer, fbmItem.getCommonFbmsFieldsGroup().getShipping());
					
					offer = setOfferCommonItemFields(offer, fbmItem.getCommonFbmsFieldsGroup().getCommonItemFieldsGroup());
					offer = setOfferCommonFbmsFields(offer, fbmItem.getCommonFbmsFieldsGroup());
					offer = setSpecFbmsFields(offer, fbmItem.getSpecificFbmsFieldsGroup());
					
					//confidence-score
					if(fbmItem.getConfidenceScore()!=null)
						offer.setConfScore(fbmItem.getConfidenceScore().doubleValue());
					
					item.setContent(content);
					offerList.add(offer);
					item.setOfferList(offerList);	

				}catch(Throwable e){
					e.printStackTrace();
				}
				itemList.add(item);
			}	
		}
		mpContOffrDoc.setItemList(itemList);
		
		String msg = JSONParser.toJSON(mpContOffrDoc);
		System.out.println("---------------Message formed-------------");
		System.out.println(msg);
		kProd.publishMessage(msg);
	}
	
	private Offer setDimensions(Offer offer, Shipping shipping) {
		//shipping
		Dimensions itemDimensions = new Dimensions();
		itemDimensions.setLen(shipping.getLength().doubleValue());
		itemDimensions.setWid(shipping.getWidth().doubleValue());
		itemDimensions.setWt(shipping.getWeight().doubleValue());
		itemDimensions.setHt(shipping.getHeight().doubleValue());

		if(shipping.getRestrictions()!=null){
			GeoLimiters geoLimits = new GeoLimiters();
			geoLimits.setStates(shipping.getRestrictions());
			offer.setGeoLimits(geoLimits);
		}
		offer.setItemDimensions(itemDimensions);
		return offer;
	}

	private Offer setOfferIds(Offer offer, Long itemId, Long contentId, 
			String uid, String ssin, String guid, String dartPartNumber) {
		
		offer.setItemId(itemId);
		offer.setContentId(contentId);
		
		if(uid!=null)
			offer.setUid(uid);
		
		if(ssin!=null)
			offer.setSsin(ssin);
		
		if(guid!=null)
			offer.setGuid(guid);
		
		offer.setSellerId(Integer.parseInt(sSellerId));
		offer.setPrgm(getPgrmType(pgrmType));
		
		if(dartPartNumber!=null)
			offer.setDartPartNbr(dartPartNumber);
		
		return offer;
	}

	private Offer setOfferCommonFbmsFields(Offer offer, CommonFbmsFieldsGroup cffg) {
		//flags
		Flags flags = new Flags();
		ChokingHazards chokingHazards = new ChokingHazards();
		chokingHazards.setBalloons(cffg.getFlags().getChokingHazards().getBalloons());
		chokingHazards.setContainsMarble(cffg.getFlags().getChokingHazards().getContainsMarble());
		chokingHazards.setContainsSmallBall(cffg.getFlags().getChokingHazards().getContainsSmallBall());
		chokingHazards.setSmallBall(cffg.getFlags().getChokingHazards().getSmallBall());
		chokingHazards.setSmallParts(cffg.getFlags().getChokingHazards().getSmallParts());
		chokingHazards.setOther(cffg.getFlags().getChokingHazards().getOther());
		flags.setChokingHazards(chokingHazards);
		flags.setCaliforniaEmissions(cffg.getFlags().getCaliforniaEmissions());
		flags.setGiftMessageElg(cffg.getFlags().getGiftMessageEligible());
		flags.setGoodHouseKeepingApprd(cffg.getFlags().getGoodHouseKeepingApproved());
		flags.setHazardousMaterial(cffg.getFlags().getHazardousMaterial());
		flags.setNowarning(cffg.getFlags().getNoWarning());
		flags.setSafetyWarningOther(cffg.getFlags().getSafetyWarningOther());
		flags.setWebExclusive(cffg.getFlags().getWebExclusive());
		offer.setFlags(flags);
		
		//model-number
		offer.setModelNbr(cffg.getModelNumber());
		
		//syw-redemption-eligible
		if(cffg.getSywRedemptionEligible()!=null)
			offer.setSywRedElig(cffg.getSywRedemptionEligible());
		
		return offer;
	}

	private void varGrpGeneration() {
		
		for(Variation varGrp : wNodeListVar){
			Item item = new Item();
			Content content = new Content();
			List<Offer> offerList = new ArrayList<Offer>();
			
			content.setContentId(varGrp.getSellpoUniqueGroupId());
			content.setUniqueGroupId(varGrp.getSellpoUniqueGroupId().toString());
			content.setExternalGroupId(varGrp.getVariationGroupId());
			content = setCommonItemFields(content, varGrp.getCommonFbmsFieldsGroupVariation().getCommonItemFieldsGroup());
			content = setCommonFbmsFields(content, convToCommonFbms(varGrp.getCommonFbmsFieldsGroupVariation()));
			content.setOwnerId(Integer.parseInt(sSellerId));
			content.setPgmType(getPgrmType(pgrmType));
			
			//Boolean contentImgSet = false;
			
			for(VariantItem varItem : varGrp.getVariantItems().getVariantItem()){
				Offer offer = new Offer();
				
				offer = setOfferIds(offer, 
						varItem.getItemId(),
						varGrp.getSellpoUniqueGroupId(),
						varItem.getUid(), 
						varItem.getSsin(), 
						varItem.getGuid(), 
						varItem.getDartPartNumber());
				
				offer.setInternalGrpId(varGrp.getSellpoUniqueGroupId().toString());
				offer.setExternalGrpId(varGrp.getVariationGroupId());
				offer.setItemClassId(varGrp.getCommonFbmsFieldsGroupVariation().getCommonItemFieldsGroup().getItemClassId());
				offer = setDimensions(offer, varItem.getSpecificFbmsFieldsGroupVariation().getShipping());

				offer = setOfferCommonItemFields(offer, varGrp.getCommonFbmsFieldsGroupVariation().getCommonItemFieldsGroup());
				offer = setOfferCommonFbmsFields(offer, convToCommonFbms(varGrp.getCommonFbmsFieldsGroupVariation()));
				offer = setSpecFbmsFields(offer, convToSpecificFbms(varItem.getSpecificFbmsFieldsGroupVariation()));
				
				//image-url at content level
				/*if(!contentImgSet){
					Image primeImg = new Image();
					primeImg.setUrl(varItem.getSpecificFbmsFieldsGroupVariation().getImageUrl().getUrl());
					if(varItem.getSpecificFbmsFieldsGroupVariation().getImageUrl().getHeight()!=null)
						primeImg.setHeight(varItem.getSpecificFbmsFieldsGroupVariation().getImageUrl().getHeight().intValue());
					if(varItem.getSpecificFbmsFieldsGroupVariation().getImageUrl().getWidth()!=null)
						primeImg.setWidth(varItem.getSpecificFbmsFieldsGroupVariation().getImageUrl().getWidth().intValue());
					content.setPrimeImg(primeImg);
					contentImgSet = true;
				}*/
				
				//swatch-image-url
				if(varItem.getSwatchImageUrl()!=null){
					Image swatchImg = new Image();
					swatchImg.setUrl(varItem.getSwatchImageUrl().getUrl());
					if(varItem.getSwatchImageUrl().getHeight()!=null)
						swatchImg.setHeight(varItem.getSwatchImageUrl().getHeight().intValue());
					if(varItem.getSwatchImageUrl().getWidth()!=null)
						swatchImg.setWidth(varItem.getSwatchImageUrl().getWidth().intValue());
					offer.setSwatchImg(swatchImg);
				}
				
				//variant-attribute
				List<Attribute> skuAttrLst = new ArrayList<Attribute>();
				
				for(VariantAttribute varAttr : varItem.getVariantAttributes().getVariantAttribute()){
					Attribute skuAttr = new Attribute();
					skuAttr.setId(varAttr.getItemAttributeGroup().getAttributeId());
					skuAttr.setAttrType(getAttrType(varAttr.getAttributeType()));
					if(varAttr.getItemAttributeGroup().getTrademarkText()!=null)
						skuAttr.setTrademarkTxt(varAttr.getItemAttributeGroup().getTrademarkText());
					if(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()!=null)
						skuAttr.setValueId(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId());
					if(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree()!=null)
						skuAttr.setValueFree(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree());
					if(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag()!=null)
						skuAttr.setValueFlag(varAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag());
					skuAttrLst.add(skuAttr);
				}
				offer.setSkuAttributesList(skuAttrLst);
				
				//confidence-score
				if(varGrp.getConfidenceScore()!=null)
					offer.setConfScore(varGrp.getConfidenceScore().doubleValue());
				
				offerList.add(offer);
			}
			item.setContent(content);
			item.setOfferList(offerList);
		
			itemList.add(item);
		}
	}

	private AttributeType getAttrType(AttributeTypeType attrType) {
		switch(attrType.toString()){
		case "SWATCH":
			return AttributeType.SWATCH;
		case "DROPDOWN":
			return AttributeType.DROPDOWN;
		case "COMBOBOX":
			return AttributeType.COMBOBOX;
		default:
			return null;
		}
	}

	private ProgramType getPgrmType(String pgrmType) {
		switch(pgrmType){
		case "FBM":
			return ProgramType.FBM;
		case "FBS":
			return ProgramType.FBS;
		case "DSS":
			return ProgramType.DSS;
		case "CPC":
			return ProgramType.CPC;
		default:
			return null;
		}
	}

	private Offer setSpecFbmsFields(Offer offer, SpecificFbmsFieldsGroup sffg) {

		//seller-product-id
		offer.setSellerPrdId(sffg.getSellerProductId());
		
		//handling-fee
		if(sffg.getHandlingFee()!=null)
			offer.setHandlingFee(sffg.getHandlingFee().doubleValue());
		
		//upc
		if(sffg.getUpc()!=null)
			offer.setUpc(sffg.getUpc());
		
		//sales-tax-code
		if(sffg.getSaleTaxCode()!=null)
			offer.setSaleTaxCd(sffg.getSaleTaxCode());
		
		//image-url
		Image prdImg = new Image();
		prdImg.setUrl(sffg.getImageUrl().getUrl());
		if(sffg.getImageUrl().getHeight()!=null)
			prdImg.setHeight(sffg.getImageUrl().getHeight().intValue());
		if(sffg.getImageUrl().getWidth()!=null)
			prdImg.setWidth(sffg.getImageUrl().getWidth().intValue());
		offer.setPrdImg(prdImg);
		
		//us-dot-ship-type
		if(sffg.getUsDotShipType()!=null){
			
			switch(sffg.getUsDotShipType().toString()){
				case "N":
					offer.setUsDotShipTyp(USDotShipType.N);
					break;
				case "S":
					offer.setUsDotShipTyp(USDotShipType.S);
					break;
			}
		}
		
		//ship-to-store-elig
		if(sffg.getShipToStoreEligibility()!=null)
			offer.setStsElig(sffg.getShipToStoreEligibility());
		
		//country-of-origin
		if(sffg.getCountryOfOrigin()!=null)
			offer.setCoo(sffg.getCountryOfOrigin());
		
		//item-condition
		if(sffg.getItemCondition()!=null){
			ItemCondition itemCondition = new ItemCondition();
			
			itemCondition.setTyp(getConditionType(sffg.getItemCondition().getCondition()));
			
			if(sffg.getItemCondition().getConditionSpecificImageUrl()!=null){
				Image img = new Image();
				img.setUrl(sffg.getItemCondition().getConditionSpecificImageUrl().getUrl());
				if(sffg.getItemCondition().getConditionSpecificImageUrl().getHeight()!=null)
					img.setHeight(sffg.getItemCondition().getConditionSpecificImageUrl().getHeight().intValue());
				if(sffg.getItemCondition().getConditionSpecificImageUrl().getWidth()!=null)
					img.setWidth(sffg.getItemCondition().getConditionSpecificImageUrl().getWidth().intValue());
				itemCondition.setImg(img);
			}
			
			if(sffg.getItemCondition().getConditionComments()!=null)
				itemCondition.setCmnt(sffg.getItemCondition().getConditionComments());
			
			offer.setItemCondition(itemCondition);
		}
		
		return offer;
	}

	private ConditionType getConditionType(com.generated.vos.catdelta.types.ConditionType condition) {
		switch(condition.toString()){
		case "New":
			return ConditionType.NEW;
		case "Refurbished":
			return ConditionType.REFURBISHED;
		case "Used-General":
			return ConditionType.USED_GENERAL;
		case "Used-Like New":
			return ConditionType.USED_LIKE_NEW;
		case "Used-Very Good":
			return ConditionType.USED_VERY_GOOD;
		case "Used-Good":
			return ConditionType.USED_GOOD;
		case "Used-Acceptable":
			return ConditionType.USED_ACCEPTABLE;
		case "Used-Poor":
			return ConditionType.USED_POOR;
		default:
			return null;
		}
	}

	private Content setCommonFbmsFields(Content content, CommonFbmsFieldsGroup cffg) {
		
		//long-desc
		if(cffg.getLongDesc()!=null)
			content.setFeatDesc(cffg.getLongDesc());
		//model-number
		content.setModelNbr(cffg.getModelNumber());
		//manufacturer-name
		if(cffg.getManufacturerName()!=null)
			content.setMfgName(cffg.getManufacturerName());
		//brand
		if(cffg.getBrand()!=null){
			Brand brand = new Brand();
			brand.setName(cffg.getBrand().getName());
			if(cffg.getBrand().getId()!=null)
				brand.setId(cffg.getBrand().getId().toString());
			if(cffg.getBrand().getLogoImageUrl()!=null){
				Image image = new Image();
				image.setUrl(cffg.getBrand().getLogoImageUrl());
				brand.setBrandImg(image);
			}
			content.setBrand(brand);
		}
		
		//commission-rates
		if(cffg.getCommissionRates()!=null){
			CommissionRates commRates = new CommissionRates();
			
			if(cffg.getCommissionRates().getDefaultCommissionRate()!=null)
				commRates.setDefRate(cffg.getCommissionRates().getDefaultCommissionRate().doubleValue());
			
			List<CommRate> commRateLst = new ArrayList<CommRate>();
			for(CommissionRate commSite : cffg.getCommissionRates().getCommissionRate()){
				CommRate commRate = new CommRate();
				commRate.setSiteId(commSite.getSiteId().intValue());
				commRate.setRateVal(commSite.getContent());
				commRateLst.add(commRate);
			}
			commRates.setCommRateList(commRateLst);
			content.setCommRates(commRates);
		}
		
		//attributes
		if(cffg.getAttributes()!=null){
			List<Attribute> prdAttrLst = new ArrayList<Attribute>();
			for(com.generated.vos.catdelta.Attribute xmlAttr : cffg.getAttributes().getAttribute()){
				Attribute prdAttr = new Attribute();
				prdAttr.setId(xmlAttr.getItemAttributeGroup().getAttributeId());
				if(xmlAttr.getItemAttributeGroup().getTrademarkText()!=null)
					prdAttr.setTrademarkTxt(xmlAttr.getItemAttributeGroup().getTrademarkText());
				if(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()!=null)
					prdAttr.setValueId(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId());
				if(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree()!=null)
					prdAttr.setValueFree(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree());
				if(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag()!=null)
					prdAttr.setValueFlag(xmlAttr.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag());
				prdAttrLst.add(prdAttr);
			}
			content.setPrdAttrList(prdAttrLst);
		}
		
		//feature-images
		if(cffg.getFeatureImageUrls()!=null){
			List<Image> ftrImgLst = new ArrayList<Image>();
			for(FeatureImageUrls xmlFeat : cffg.getFeatureImageUrls()){
				for(com.generated.vos.catdelta.Image ft : xmlFeat.getImage()){
					Image ftrImg = new Image();
					ftrImg.setUrl(ft.getUrl());
					if(ft.getHeight()!=null)
						ftrImg.setHeight(ft.getHeight().intValue());
					if(ft.getWidth()!=null)
						ftrImg.setWidth(ft.getWidth().intValue());
					ftrImgLst.add(ftrImg);
				}
			}
			content.setFtrImgList(ftrImgLst);
		}
		
		return content;
	}

	private Content setCommonItemFields(Content content, CommonItemFieldsGroup cifg) {
		
		content.setTitle(cifg.getTitle()); //title
		content.setMktgDesc(cifg.getShortDesc()); //short-desc
		content.setItemClassId(cifg.getItemClassId()); //item-class-id
		
		/*site*/
		List<Site> siteList = new ArrayList<Site>();
		for(com.generated.vos.catdelta.Site xmlSite : cifg.getSite()){
			Site site = new Site();
			site.setId(xmlSite.getId().toString());
			Taxonomy taxo = new Taxonomy();
			List<com.generated.vos.proto.content.Hierarchy> hierList = new ArrayList<com.generated.vos.proto.content.Hierarchy>();
			for(Hierarchy xSiteTaxo : xmlSite.getTaxonomy().getHierarchy()){
				com.generated.vos.proto.content.Hierarchy hier = new com.generated.vos.proto.content.Hierarchy();
				hier.setId(xSiteTaxo.getId().toString());
				hier.setPrimary(xSiteTaxo.getPrimary());
				hierList.add(hier);
			}
			taxo.setHierList(hierList);
			site.setTaxo(taxo);
			siteList.add(site);
		}
		content.setSiteList(siteList);
		
		content.setMatureCont(cifg.getMatureContent()); //mature-content
		
		/*enrichment-info*/
		if(cifg.getEnrichmentInfo()!=null){
			EnrichmentInfo enrichInfo = new EnrichmentInfo();
			EnrichmentProvider enrichProvdr = EnrichmentProvider.CNET;
			enrichInfo.setEnrichProvdr(enrichProvdr);
			enrichInfo.setProviderItemId(cifg.getEnrichmentInfo().getProviderItemId());
			content.setEnrichInfo(enrichInfo);
		}
		
		/*product-assets*/
		if(cifg.getProductAssets()!=null){
			List<Asset> assetLst = new ArrayList<Asset>();
			for(ProductAsset prdAsst : cifg.getProductAssets().getProductAsset()){
				Asset asset = new Asset();
				asset.setUrl(prdAsst.getUrl());
				asset.setType(getAssetType(prdAsst.getType()));
				if(prdAsst.getName()!=null)
					asset.setName(prdAsst.getName());
				if(prdAsst.getWidth()!=null)
					asset.setWidth(prdAsst.getWidth().intValue());
				if(prdAsst.getHeight()!=null)
					asset.setHeight(prdAsst.getHeight().intValue());
				
				assetLst.add(asset);
			}
			content.setAssetList(assetLst);
		}
		
		return content;		
	}

	private void cpcGeneration()
	{

		Item item = new Item();
		Content content = new Content();
		List<Offer> offerList = new ArrayList<Offer>();
		Offer offer = new Offer();
		
		for(Cpc cpc : wNodeListCpc){
		
			
			content.setContentId(cpc.getItemId());
			
			content = setCommonItemFields(content, cpc.getCommonItemFieldsGroup());
					
			content.setPgmType(com.generated.vos.proto.catalogcommons.ProgramType.CPC);
			content.setOwnerId(Integer.parseInt(sSellerId));
			//content.setStatus(Status.ACTIVE);
			
			if(cpc.getModelNumber()!=null){
				content.setModelNbr(cpc.getModelNumber());
				offer.setModelNbr(cpc.getModelNumber());
			}
			
			if(cpc.getBrand()!=null){
				Brand brand = new Brand();
				brand.setName(cpc.getBrand().getName());
				if(cpc.getBrand().getId()!=null)
					brand.setId(cpc.getBrand().getId().toString());
				if(cpc.getBrand().getLogoImageUrl()!=null){
					Image image = new Image();
					image.setUrl(cpc.getBrand().getLogoImageUrl());
					brand.setBrandImg(image);
				}
				content.setBrand(brand);
			}
			
			offer = setOfferIds(offer, 
					cpc.getItemId(),
					cpc.getItemId(),
					cpc.getUid(), 
					cpc.getSsin(), 
					cpc.getGuid(), 
					null);
			
			offer.setItemClassId(cpc.getCommonItemFieldsGroup().getItemClassId());
			
			offer = setOfferCommonItemFields(offer, cpc.getCommonItemFieldsGroup());
			
			if(cpc.getUpc()!=null)
				offer.setUpc(cpc.getUpc());
			
			if(cpc.getAggregatorProductId()!=null)
				offer.setAggPdtId(cpc.getAggregatorProductId());
			
			if(cpc.getImportance()!=null)
				offer.setImp(cpc.getImportance().doubleValue());
						
			if(cpc.getConfidenceScore()!=null)
				offer.setConfScore(cpc.getConfidenceScore().doubleValue());
			
			if(cpc.getItemUrl()!=null)
				offer.setItemUrl(cpc.getItemUrl());
			
			if(cpc.getImageUrl()!=null){
				Image prdImg = new Image();
				//Image primeImg = new Image();
				prdImg.setUrl(cpc.getImageUrl().getUrl());
				//primeImg.setUrl(cpc.getImageUrl().getUrl());
				if(cpc.getImageUrl().getWidth()!=null){
					prdImg.setWidth(cpc.getImageUrl().getWidth().intValue());
					//primeImg.setWidth(cpc.getImageUrl().getWidth().intValue());
				}
				if(cpc.getImageUrl().getHeight()!=null){
					prdImg.setHeight(cpc.getImageUrl().getHeight().intValue());
					//primeImg.setHeight(cpc.getImageUrl().getHeight().intValue());
				}
				offer.setPrdImg(prdImg);
				//content.setPrimeImg(primeImg);
			}
			
			List<ClickCaptureUrls> ccUrlList = new ArrayList<ClickCaptureUrls>();
			for(ClickCaptureUrl xmlClickUrl : cpc.getClickCaptureUrls().getClickCaptureUrl()){
				ClickCaptureUrls ccUrl = new ClickCaptureUrls();
				ccUrl.setSiteId(xmlClickUrl.getSiteId().intValue());
				ccUrl.setUrl(xmlClickUrl.getContent());
				ccUrlList.add(ccUrl);
			}
			offer.setClickCaptureUrlsList(ccUrlList);
			
			//offer.setStatus(Status.ACTIVE);
			
			item.setContent(content);
			offerList.add(offer);
			item.setOfferList(offerList);
		}
		
		itemList.add(item);

	}

	private Offer setOfferCommonItemFields(Offer offer, CommonItemFieldsGroup cffg) {
				
		//seller-item-class
		if(cffg.getSellerItemClass()!=null)
			offer.setSellerItemClass(cffg.getSellerItemClass().intValue());
		
		//seller-categories
		if(cffg.getSellerCategories()!=null)
			offer.setSellerCtgry(cffg.getSellerCategories());
		
		return offer;
	}

	private AssetType getAssetType(TypeType type) {
		switch(type.toString()){
		case "ENERGY_GUIDE":
			return AssetType.ENERGY_GUIDE;
		case "MISCELLANEOUS":
			return AssetType.MISCELLANEOUS;
		case "PRODUCT_WARRANTY":
			return AssetType.PRODUCT_WARRANTY;
		case "SPANISH_WARRANTY":
			return AssetType.SPANISH_WARRANTY;
		case "ENGLISH_OWNER_MANUAL":
			return AssetType.ENGLISH_OWNER_MANUAL;
		case "SPANISH_OWNER_MANUAL":
			return AssetType.SPANISH_OWNER_MANUAL;
		default:
			return null;
		}
	}
	
	public static <T> CommonFbmsFieldsGroup convToCommonFbms(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		CommonFbmsFieldsGroup comnFbmsFldGrp = new CommonFbmsFieldsGroup();
		try {
				BeanUtils.copyProperties(comnFbmsFldGrp , nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return comnFbmsFldGrp ;
	}
	
	public static <T> SpecificFbmsFieldsGroup convToSpecificFbms(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		SpecificFbmsFieldsGroup specFbmsFldGrp = new SpecificFbmsFieldsGroup();
		try {
				BeanUtils.copyProperties(specFbmsFldGrp, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return specFbmsFldGrp;
	}
}
