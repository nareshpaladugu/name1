package com.shi.content.acme.ingest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.EmailUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.OfferCommons;

/**
 * @author mbashee
 *
 */
public class ForceMatchDataMockupTest 
{

	private static int totalProductstoUpdate;
	private static String field = System.getProperty("fieldToAdd","");
	private static String type = System.getProperty("fieldType","STRING");
	private static String value = System.getProperty("fieldValue","");
	private static long startTime;
	private static long stopTime;
	
	@Test(groups="ForceMatchDataMockupTest")
	public void forceMatchDataMockup()
	{
		try
		{
			
			startTime = System.currentTimeMillis();
			
			Boolean backfillSsinGuid = Boolean.valueOf(System.getProperty("backfillSsinGuid","true"));
			Boolean refreshFeatures = Boolean.valueOf(System.getProperty("refreshFeatures","true"));
			Boolean refreshReconciled = Boolean.valueOf(System.getProperty("refreshReconciled","true"));
			
			String ssins = System.getProperty("ssins","");
			
			String[] ssinLst = ssins.split(",");
			Set<String> guids = new HashSet<String>();
			
			for(String ssin : ssinLst){
				
				List<String> offers = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin", ssin);
				System.out.println("SSIN=" + ssin + " : OfferList=" + offers);
				
				for(String offer : offers){
					APIResponse<Offer> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offer);
					Offer gbOffer = (Offer) allResponse.getT();
					
					String vendorId = null;
					String feedSource = null;
					String programType = null;
					String storeHierId = null;
					if(allResponse.getFtFieldValue("pgrmType").equals("Sears")){
						feedSource = "spin";
						programType = "SEARS";
						vendorId = "sears";
						storeHierId = gbOffer.getTaxonomy().getStore().getHierarchy().get(gbOffer.getTaxonomy().getStore().getHierarchy().size()-1).getId();
					}
					else if(allResponse.getFtFieldValue("pgrmType").equals("FBM") ||
							allResponse.getFtFieldValue("pgrmType").equals("FBS") ||
							allResponse.getFtFieldValue("pgrmType").equals("DSS") ||
							allResponse.getFtFieldValue("pgrmType").equals("CPC")){
						vendorId = String.valueOf(gbOffer.getMarketplace().getSeller().getId().intValue());
						feedSource = "sellerPortal";
						programType = gbOffer.getClassifications().getIsMpPgmType();
					}else{
						System.out.println("Skipping invalid SSIN: " + ssin);
						break;
					}
					
					String title = TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(gbOffer.getName());
					String shortDesc = TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(OfferCommons.escapeNewline(gbOffer.getDesc()));
					String uid = gbOffer.getIdentity().getUid();
					String upcCode = gbOffer.getAltIds().getUpc();
					String modelNumber = gbOffer.getModelNo();
					String brandName = gbOffer.getBrandName();
					String classifier = gbOffer.getClassifications().getOfferType().toString();
					String id = gbOffer.getAltIds().getSpinId();
					Integer itemClassId = gbOffer.getTaxonomy().getMaster().getHierarchy().get(gbOffer.getTaxonomy().getMaster().getHierarchy().size()-1).getSpinId().intValue();
				
					String sourceJson = null;
					sourceJson = "[{\"id\": \""+id+"\","
							+ "\"vendorId\": \""+vendorId+"\","
							+ "\"guid\": \""+uid+"\","
							+ "\"ssin\": \""+ssin+"\","
							+ "\"itemClassId\": \""+itemClassId+"\","
							+ "\"attributes\": {\"itemClassId\": \""+itemClassId+"\","
							+ "\"status\": {\"status\": \"ACTIVE\"},"
							+ "\"feedSource\": \""+feedSource+"\","
							+ "\"shortDesc\": \""+shortDesc+"\","
							+ "\"title\": \""+title+"\","
							+ "\"classifier\": \""+classifier+"\","
							+ "\"programType\": \""+programType+"\",";
					
					if(programType.equals("SEARS")){
						sourceJson = sourceJson + "\"partNumber\":{\"searsPartNumber\": \""+gbOffer.getId()+"\"},";
						sourceJson = sourceJson + "\"storeHierId\": \""+storeHierId+"\",";
					}
					else if(gbOffer.getClassifications().getIsMpPgmType().equals("FBS")){
						sourceJson = sourceJson + "\"dartPartNumber\": \""+offer+"\",";
					}
					if(upcCode!=null){
						sourceJson = sourceJson + "\"upcCode\": \""+upcCode+"\",";
					}
					if(brandName!=null){
						sourceJson = sourceJson + "\"brandName\": \""+brandName+"\",";
					}
					if(modelNumber!=null){
						sourceJson = sourceJson + "\"modelNumber\": \""+modelNumber+"\"},";
					}
					
					if(backfillSsinGuid){
						sourceJson = sourceJson + "\"guid\": \""+uid+"\",";
						sourceJson = sourceJson + "\"ssin\": \""+ssin+"\",";
					}
					
					sourceJson = sourceJson + "\"status\": \"ACTIVE\"}]";
					
					System.out.println("Putting JSON in source: " + sourceJson);
					String sourceUrl ="http://"+LoadProperties.IA_SERVER+"/acme/source/";
					String srcResp = RestExecutor.putRequest(sourceUrl, sourceJson);
					System.out.println(srcResp);
					
					if(refreshFeatures){
						System.out.println("Refreshing features: " + id);
						String featureUrl = "http://"+LoadProperties.IA_SERVER+"/acme/features/" + id + "?refresh=true";
						String featResp = RestExecutor.getJSonResponse(featureUrl);
						System.out.println(featResp);
					}
					
					/*System.out.println("Refreshing features with hints: " + id);
					String hintsUrl = "http://"+LoadProperties.IA_SERVER+"/acme/features/hints/" + id + "?refresh=true";
					String hintsResp = RestExecutor.getJSonResponse(hintsUrl);
					System.out.println(hintsResp);*/
					
					guids.add(uid);
				}
			}
			
			if(refreshReconciled){
				
				for(String guid : guids) {
					System.out.println("Refreshing reconciled: " + guid);
					String reconciledUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled/" + guid + "?refresh=true";
					String reconResp = RestExecutor.getJSonResponse(reconciledUrl);
					System.out.println(reconResp);
				}
			}
			
			stopTime = (System.currentTimeMillis());
			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	@AfterClass(groups="GBCountUtility")
	public void result()
	{

		String sCustomBody="<br><font face='Calibri' color='black' size='2'> "
				+"<br>GB : "+LoadProperties.gbServer
				+"<br>Collection : "+LoadProperties.collection
				+"<br>Field : "+field
				+"<br>Type : "+type
				+"<br>Value : "+value
				+"<br>Total Products Updated : "+totalProductstoUpdate
				+"<br>Total Execution Time : "+EmailUtils.getDurationString((stopTime-startTime)/1000)
				+ "<font face='Calibri' color='red' size='2'>" 
				+"<br><br><font face='Calibri' color='black' size='2'>";

		//EmailUtils.sendEmail("GB Update Test ", sCustomeBody, null);

	}
}
