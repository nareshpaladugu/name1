package com.shi.content.storeLocalAd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.localadpage.Element;
import com.generated.vos.localadpage.Localadpage;
import com.generated.vos.localadpage.Product;
import com.generated.vos.offer.Offer;
import com.generated.xmls.storelocalad.Article;
import com.generated.xmls.storelocalad.Coord;
import com.generated.xmls.storelocalad.Media;
import com.generated.xmls.storelocalad.Page;
import com.generated.xmls.storelocalad.Property;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class LocalAdPageVerification implements Runnable {

	
	private List<Media> lstXmlMedia;
	
	Localadpage localadpage;
	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(LocalAdPageVerification.class.getName());
	public static Map<String, com.generated.xmls.storelocalad.Element> elementsmap = new HashMap<String, com.generated.xmls.storelocalad.Element>();
	public LocalAdPageVerification(List<Media> xmlMedia){
		lstXmlMedia = xmlMedia;
	}
	
	@Override
	public void run() {
		
		//For each attribute assigned to this thread, do validations
		for(Media media : lstXmlMedia){
			try{
				CompareValuesUtility.init();
				System.out.println("Testing mediaType: " + media.getMedia_type());
				
				List<Page> pageList = Arrays.asList(media.getSection(0).getPage());
				List<com.generated.xmls.storelocalad.Element> elementList = Arrays.asList(media.getElement_list().getElement());
				for(com.generated.xmls.storelocalad.Element ele : elementList){
					elementsmap.put(ele.getId(), ele);
				}
				for(Page page : pageList ){
					String pageId = page.getId();
					
					
					System.out.println("Testing pageId: " + pageId);
					localadpage=RestExecutor.getDataById(CollectionValuesVal.LOCALADPAGE, pageId);	
					
					if(localadpage == null){
						CompareValuesUtility.logFailed("Id", pageId, "Not found");
						continue; //Setup the result for this id
					}else{
						String dudeHostUrl = "http://env37.ca.s.com/s/i/la/image/";
						
						CompareValuesUtility.compareValues("Id", pageId, localadpage.getId());
						CompareValuesUtility.compareValues("ImageId", page.getAsset(0).getUrl(), localadpage.getImageId());
						CompareValuesUtility.compareValues("ImageUrl", page.getAsset(0).getUrl()==null?null:dudeHostUrl +page.getAsset(0).getUrl().replaceAll(".jpg",""), localadpage.getImageUrl()==null?null:localadpage.getImageUrl());
						
						for(Coord coord : Arrays.asList(page.getCoord())){
							com.generated.xmls.storelocalad.Element elem = elementsmap.get(coord.getElement_id());
							for(Article article : elem.getArticle()){
								String productId =null;
								String div =null;
								for(Property props: article.getProperty()){
								if(props.getName().equalsIgnoreCase("Product Id"))
									productId =props.getValue();
								}
								List<String> partList = null;
								String s = "divitem";
								String ksn = "ksn";
								String errorLog="";
								if(productId!=null){
									if(media.getMedia_type().equalsIgnoreCase("sears")){
										errorLog = productId;
										partList=RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,s, productId);
									}else if(media.getMedia_type().equalsIgnoreCase("kmart")){
										errorLog=productId;
										partList=RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,ksn, productId);
									}
									
								}
								if(partList!=null && !(partList.isEmpty())){
									List<String> processedParentIds = new ArrayList<String>();
									for(String partNum: partList){
										String parentId ="";
										Offer offer = RestExecutor.getDataById(CollectionValuesVal.OFFER, partNum);
									    if(offer!=null){
											parentId = offer.getIdentity().getParentId();
											String pgrmType = RestExecutor.getSpecificValueFromJson(CollectionValuesVal.OFFER, partNum, "[{_blob{offer{ffm{soldBy}}}}]");
											if(!pgrmType.equalsIgnoreCase(media.getMedia_type())){
												continue;
											}
											
											if(processedParentIds.contains(parentId)){
												continue;
											}
											
											boolean cFound = false;
											for(Element gbElement : localadpage.getElements()){
												if(coord.getPoints().equalsIgnoreCase(gbElement.getCoords())) // Why to check
												{
													CompareValuesUtility.compareValues("Coords", coord.getPoints(), gbElement.getCoords());

													boolean pFound =false;
													for(Product prodId: gbElement.getProducts()){													
														if(parentId.equalsIgnoreCase(prodId.getProductId())){
															CompareValuesUtility.compareValues("ProductID", parentId, prodId.getProductId());
															pFound = true;
															break;
														}
													}
													if(!pFound){
														CompareValuesUtility.logFailed("ProductID", parentId, "ProductId not loaded in GB");	
														break;
													}
													cFound = true;
													break;
												}
											}
											if(!cFound){
												CompareValuesUtility.logFailed("Coords", coord.getPoints(), "Coords not loaded in GB");
												break;
											}
											processedParentIds.add(parentId);
									    }	
									}
										
								}else{
									log.info(errorLog+ "Ksn/Divitem doesnt have any partnumber in offer collection. mediaType=" + media.getMedia_type() + " div=" + div + " productId=" + productId);	
								}
							}					
						}
					}
				}
				CompareValuesUtility.setupResult(media.getImport_name(), true);
			}catch(Throwable e){
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	}


}