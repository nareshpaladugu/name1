package com.shi.content.seotest;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;

/**
 * @author ddaphal
 * Created : 13 March 2015
 */
public class SeoTest {

	@Test(dataProvider="sourceIdProvider",groups="SeoTest")

	public void seoTest(Set<String> contentIds) 
	{
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		for (String sContentIdSingle : contentIds) 
		{
			if(sContentIdSingle!=null && !sContentIdSingle.isEmpty() )
			{
				pool.execute(new SeoTestVerification(sContentIdSingle.trim()));
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}

	@DataProvider(name="sourceIdProvider", parallel=true)
	public Object[][] sourceIdProvider()
	{
		Set<String> contentIds = new java.util.HashSet<String>();

		String sContentsIds = LoadProperties.RUN_PARAMS;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("fileMode"))
		{

			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");

			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty() )
					{
						contentIds.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}
		else
		{
			contentIds.addAll(Arrays.asList(sContentsIds.split(",")));
		}
		
		return new Object[][] { { contentIds} };
	}
}
