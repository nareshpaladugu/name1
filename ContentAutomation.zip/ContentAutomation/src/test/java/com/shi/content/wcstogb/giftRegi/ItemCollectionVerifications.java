package com.shi.content.wcstogb.giftRegi;

import java.util.List;
import java.util.Map;

import com.generated.vos.gr.item.ItemCollection;
import com.generated.vos.gr.item.ItemDetail;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;

public class ItemCollectionVerifications implements Runnable
{
	private String giftregistry_id;
	List<Map<String,String>> listOfMaps;

	public ItemCollectionVerifications(String giftregistry_id,List<Map<String,String>> mapForSingleGiftRegId)
	{
		this.giftregistry_id=giftregistry_id.trim();
		this.listOfMaps=mapForSingleGiftRegId;
	}

	public void run() 
	{
		if(giftregistry_id==null || giftregistry_id.isEmpty())
		{
			return;
		}

		//System.out.println("Testing registryItemCollection id : "+giftregistry_id);

		CompareValuesUtility.init();

		BasicDBObject criteria = new BasicDBObject();
		criteria.put("_id", giftregistry_id);

		DBCollection dbCollection =  CommonGiftReg.getDBCollection("registryItemCollection"); 
		CommonGiftReg commonGiftReg = new CommonGiftReg();
		DBObject singleDocumentRegistryItemColl = dbCollection.findOne(criteria);

		if(singleDocumentRegistryItemColl == null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("registryItemCollection", "Not Found");
		}
		else
		{

			if(TestUtils.isEmptyJsonResponse(singleDocumentRegistryItemColl.toString()))
			{
				CompareValuesUtility.addFailedDataFieldForReport("registryItemCollection", "Not Found");
			}
			else
			{

				String tempField = null;

				String GIFTITEM_ID=null;
				//System.out.println(singleDocumentRegistryItemColl.toString());

				ItemCollection itemCollection = CommonGiftReg.getCollectionObject(singleDocumentRegistryItemColl.toString(),ItemCollection.class);

				CompareValuesUtility.compareValues("_id", giftregistry_id,itemCollection.getId()); 

				CompareValuesUtility.compareValues("giftregistry_id", giftregistry_id,itemCollection.getGiftRegistryId()); 

				List<ItemDetail> itemDeatilsList = 	itemCollection.getItemDetails();

				String tmp = null;
				try 
				{
					boolean found = false;
					if(listOfMaps!=null &&!listOfMaps.isEmpty())
					{
						for (Map<String, String> rs : listOfMaps) 
						{
							GIFTITEM_ID = rs.get("GRGFTITM_GIFTITEM_ID");

							found = false;

							for (ItemDetail itemDetail : itemDeatilsList) 
							{

								if(GIFTITEM_ID.equals(itemDetail.getGiftItemId()))
								{

									//createTimeStamp  = ((LinkedTreeMap<String, String>) itemDetail.getCreateTimeStamp()).get("$date");
									//lastUpdatedTimeStamp = ((LinkedTreeMap<String, String>) itemDetail.getLastUpdatedTimeStamp()).get("$date");

									CompareValuesUtility.compareValues("giftItemId", GIFTITEM_ID,itemDetail.getGiftItemId());
									CompareValuesUtility.compareValues("partNumber", rs.get("GRGFTITM_PARTNUMBER"),itemDetail.getPartNumber());
									CompareValuesUtility.verifyNullOrEqual("quantityRequested",  rs.get("GRGFTITM_QUANTITYREQUESTED"),itemDetail.getQuantityRequested());
									CompareValuesUtility.verifyNullOrEqual("quantityBought",  rs.get("GRGFTITM_QUANTITYBOUGHT"),itemDetail.getQuantityBought());
									//CompareValuesUtility.verifyNullOrEqual("createTimeStamp",  rs.get("CREATETIME"),createTimeStamp);
									//CompareValuesUtility.verifyNullOrEqual("lastUpdatedTimeStamp",  rs.get("LASTUPDATE"),lastUpdatedTimeStamp);
									CompareValuesUtility.verifyNullOrEqual("location",  rs.get("GRGFTITM_LOCATION"),itemDetail.getLocation());
									
									tmp = CommonGiftReg.removeSpecialChar( rs.get("GRGFTITM_FIELD3"));
									
									CompareValuesUtility.verifyNullOrEqual("categoryName", tmp ,itemDetail.getCategoryName());
									CompareValuesUtility.verifyNullOrEqual("itemName",  tmp ,itemDetail.getName());
									try {
										commonGiftReg.compareAsNumbers("upc",   rs.get("GRGFTITM_FIELD4")==null||rs.get("GRGFTITM_FIELD4").equals("0")?null
												:rs.get("GRGFTITM_FIELD4").replaceAll("\\W", "").replaceAll("[a-zA-Z]", ""),
												itemDetail.getUpc()==null?null:itemDetail.getUpc().longValue());
									} catch (Exception e) {
										CompareValuesUtility.verifyNull("upc",  
												itemDetail.getUpc()==null?null:itemDetail.getUpc().longValue());
									}
									try {
										commonGiftReg.compareAsNumbers("ksn",   rs.get("GRGFTITM_FIELD5")==null||rs.get("GRGFTITM_FIELD5").equals("0")
												?null:rs.get("GRGFTITM_FIELD5").replaceAll("\\W", "").replaceAll("[a-zA-Z]", ""),
														itemDetail.getKsn()==null?null:itemDetail.getKsn().longValue());
									} catch (Exception e) {
										CompareValuesUtility.verifyNull("ksn",  
												itemDetail.getKsn()==null?null:itemDetail.getKsn().longValue());
									}

									tempField = rs.get("XGRGFTITM_FIELD3");

									if(tempField==null || tempField.isEmpty() || tempField.equals("0"))
									{
										tempField="false";
									}

									if(tempField.equals("1"))
									{
										tempField ="true";
									}

									CompareValuesUtility.verifyNullOrEqual("DeleteStatus", 
											tempField, itemDetail.getDeleteStatus());


									CompareValuesUtility.verifyNullOrEqual("InstoreOnlyNotes",  
											rs.get("XGRGFTITM_INSTOREONLYNOTES"),itemDetail.getInstoreOnlyNotes());

									tempField = rs.get("XGRGFTITM_INSTOREONLYITMFLAG") ;
									if(tempField!=null && tempField.equalsIgnoreCase("Y"))
									{
										tempField="true";
									}
									else
									{
										tempField="false";
									}

									CompareValuesUtility.verifyNullOrEqual("InstoreOnlyItmFlag",  
											tempField ,itemDetail.getInstoreOnlyItmFlag());

									found = true;
									break;
								}
							}
							if(!found)
							{
								CompareValuesUtility.addFailedDataFieldForReport("itemDetails", "Not Found -"+GIFTITEM_ID);
							}
						}
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				finally
				{
					ItemCollectionCache.clearMaps(giftregistry_id);
					ItemCollectionTest.ctr++;
					if(ItemCollectionTest.ctr%10000==0)
					{
						System.out.println("DONE....................."+ItemCollectionTest.ctr);
					}
				}
			}
		}
		CompareValuesUtility.setupResult(giftregistry_id,true);
	}
}
