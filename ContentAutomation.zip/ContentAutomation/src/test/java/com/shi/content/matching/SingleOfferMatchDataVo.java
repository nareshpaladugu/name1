package com.shi.content.matching;

import java.util.ArrayList;
import java.util.List;

import com.generated.vos.offer.Attr;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.Val;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.testcommons.TestUtils;

public class SingleOfferMatchDataVo {

	private String contentId;
	
	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public void setMisClass(Boolean misClass) {
		this.misClass = misClass;
	}

	private Double contentScore;
	
	public Double getContentScore() {
		return contentScore;
	}

	public void setContentScore(Double contentScore) {
		this.contentScore = contentScore;
	}

	private String misClassStr;
	
	public String getMisClassStr() {
		return misClassStr;
	}

	public void setMisClassStr(String misClassStr) {
		this.misClassStr = misClassStr;
	}

	private Boolean misClass;
	
	public boolean getMisClass() {
		misClass=misClass==null?false:misClass;
		return misClass;
	}

	public void setMisClass(boolean misClass) {
		this.misClass = misClass;
	}

	@Override
	public String toString() {
		return "SingleOfferMatchDataVo [spinId=" + spinId + ", upc=" + upc
				+ ", uid=" + uid + ", ssin=" + ssin + ", offerid=" + offerid
				+ ", brandName=" + brandName + ", parentId=" + parentId
				+ ", modelNumber=" + modelNumber + ", programType="
				+ programType + "]";
	}

	private String brandCodeId;
	public String getBrandCodeId() {
		brandCodeId=brandCodeId==null?"":brandCodeId;
		return brandCodeId;
	}

	public void setBrandCodeId(String brandCodeId) {
		this.brandCodeId = brandCodeId;
	}

	public String getVarAttrs() {
		varAttrs=varAttrs==null||varAttrs.equals("null")?"":varAttrs;
		return varAttrs.toLowerCase();
	}

	public void setVarAttrs(String varAttrs) {
		this.varAttrs = varAttrs;
	}

	private String varAttrs;

	public String getAcmeSourceStatus() {
		return acmeSourceStatus;
	}

	public void setAcmeSourceStatus(String acmeSourceStatus) {
		this.acmeSourceStatus = acmeSourceStatus;
	}

	private String acmeSourceStatus;

	private String sourceDbId;

	public String getSourceDbId() {
		return sourceDbId;
	}


	public void setSourceDbId(String sourceDbId) {
		this.sourceDbId = sourceDbId;
	}

	private  com.generated.vos.content.Sites webSitesHie;

	public  com.generated.vos.content.Sites getWebSitesHie() {
		return webSitesHie;
	}


	public void setWebSitesHie( com.generated.vos.content.Sites webSitesHie) {
		this.webSitesHie = webSitesHie;
	}

	public boolean isSiteOnlySpecificOffer;

	public boolean isSiteOnlySpecificOffer() {
		return isSiteOnlySpecificOffer;
	}


	public void setSiteOnlySpecificOffer(boolean isSiteOnlySpecificOffer) {
		this.isSiteOnlySpecificOffer = isSiteOnlySpecificOffer;
	}

	private String spinId;

	public String getSpinId() {
		return spinId;
	}


	public void setSpinId(String spinId) {
		this.spinId = spinId;
	}

	private String webHierarchy;

	public String getWebHierarchy() {
		return webHierarchy;
	}


	public void setWebHierarchy(String webHierarchy) {
		this.webHierarchy = webHierarchy;
	}

	private String missingOfferReason;

	public String getMissingOfferReason() {
		missingOfferReason=missingOfferReason==null?"":missingOfferReason;
		return missingOfferReason;
	}


	public void setMissingOfferReason(String missingOfferReason) {
		this.missingOfferReason = missingOfferReason;
	}

	private boolean isValidDefAttr;

	public boolean isValidDefAttr() {
		return isValidDefAttr;
	}


	public void setValidDefAttr(boolean isInValidDefAttr) {
		this.isValidDefAttr = isInValidDefAttr;
	}

	private boolean excludedAtParentLevel;
	public boolean isExcludedAtParentLevel() {
		return excludedAtParentLevel;
	}


	public void setExcludedAtParentLevel(boolean excludedAtParentLevel) {
		this.excludedAtParentLevel = excludedAtParentLevel;
	}

	private int offerNumberInSubGroup;

	public int getOfferNumberInSubGroup() {
		return offerNumberInSubGroup;
	}


	public void setOfferNumberInSubGroup(int offerNumberInSubGroup) {
		this.offerNumberInSubGroup = offerNumberInSubGroup;
	}

	private boolean isSingleItemGroupNeeded;
	public boolean isSingleItemGroupNeeded() {
		return isSingleItemGroupNeeded;
	}


	public void setSingleItemGroupNeeded(boolean isSingleItemGroupNeeded) {
		this.isSingleItemGroupNeeded = isSingleItemGroupNeeded;
	}


	public String getSingleItemGroupReason() {
		return singleItemGroupReason;
	}


	public void setSingleItemGroupReason(String singleItemGroupReason) {
		this.singleItemGroupReason = singleItemGroupReason;
	}

	private String singleItemGroupReason;

	private String upc;
	public String getUpc() {
		upc=upc==null?"":upc;
		return upc;
	}


	public void setUpc(String upc) {
		this.upc = upc;
	}

	public List<DefiningAttr> getDefiningAttrs() {
		if(definingAttrs==null)
			definingAttrs=new ArrayList<DefiningAttr>();

		for (DefiningAttr attr : definingAttrs) {

			Attr attrs = attr.getAttr();

			attrs.setId("");
			attrs.setSeq(-1d);

			Val val = attr.getVal();

			if(val==null)
			{
				//System.out.println("Defining attribute val not found ... offer : "+offerid);
				val=new Val();
			}

			val.setId("");
			val.setSeq(-1d);
		}
		return definingAttrs;
	}

	List<DefiningAttr> definingAttrs;

	String definingAttrsStr;

	public String getDefiningAttrsStr()
	{
		if(definingAttrs!=null && !definingAttrs.isEmpty())
		{
			Gson g = new Gson();
			definingAttrsStr = g.toJson(definingAttrs);
		}
		definingAttrsStr=definingAttrsStr==null?"":definingAttrsStr;
		return definingAttrsStr;
	}


	public void setStrDefiningAttributes(String strDefiningAttributes) {

		this.definingAttrsStr=strDefiningAttributes;

		if(strDefiningAttributes!=null && !strDefiningAttributes.equals("null") && !strDefiningAttributes.isEmpty())
		{
			definingAttrs = JSONParser.stringToArray(strDefiningAttributes, DefiningAttr[].class);
		}
	}


	public void setDefiningAttributes(List<DefiningAttr> definingAttrss) {
		if(definingAttrss!=null&& !definingAttrss.isEmpty())
		{
			definingAttrs = definingAttrss;
		}
	}

	public void setDefiningAttrs(List<DefiningAttr> definingAttrs) {
		this.definingAttrs = definingAttrs;
	}


	public void setDefiningAttrsStr(String definingAttrsStr) {
		this.definingAttrsStr = definingAttrsStr;
	}

	private 	String packageQty;
	private 	String uid;
	private 	String ssin;
	private 	String offerid;
	private 	String brandName;
	private 	String parentId;
	public String getParentId() {
		if(parentId==null)
		{
			System.out.println("parentId not known for source.. "+sourceDbId);
			parentId="";
		}
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getSsin() {
		ssin=ssin==null?"":ssin;
		ssin=ssin.trim();
		return ssin;
	}
	public void setSsin(String ssin) {
		this.ssin = ssin;
	}
	public String getOfferid() {
		if(offerid==null)
		{
			offerid="";
		}
		return offerid;
	}
	public void setOfferid(String offerid) {
		this.offerid = offerid;
	}


	public String getModelNumber() {

		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	private String modelNumber;

	public String getBrandName() {

		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDivLine() {

		return divLine;
	}
	public void setDivLine(String divLine) {
		this.divLine = divLine;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public Boolean getIsUvd() {

		if(isUvd==null)
			isUvd=false;
		return isUvd;
	}
	public void setIsUvd(Boolean isUvd) {
		this.isUvd = isUvd;
	}
	public String getMasterVerticalId() {
		MasterVerticalId=MasterVerticalId==null?"":MasterVerticalId;

		if(!MasterVerticalId.isEmpty())
		{
			MasterVerticalId = String.valueOf(Double.valueOf(MasterVerticalId).intValue());
		}
		return MasterVerticalId;
	}
	public void setMasterVerticalId(String masterVerticalId) {
		if(masterVerticalId!=null && masterVerticalId.contains("["))
		{
			try {
				masterVerticalId = TestUtils.cleanListValue(masterVerticalId).split(",")[0];
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		MasterVerticalId = masterVerticalId;
	}

	private 	String divLine;
	private 	String offerType;
	Boolean isUvd;
	public String getPackageQty() {
		packageQty=packageQty==null||packageQty.equals("null")?"":packageQty;
		return packageQty;
	}
	public void setPackageQty(String packageQty) {
		this.packageQty = packageQty;
	}
	private 	String MasterVerticalId;

	private 	String programType;
	public String getProgramType() {
		programType=programType==null?"":programType;
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}

}
