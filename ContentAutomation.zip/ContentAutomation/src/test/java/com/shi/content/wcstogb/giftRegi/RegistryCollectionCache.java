package com.shi.content.wcstogb.giftRegi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shc.autocontent.db.DBUtil;

public class RegistryCollectionCache 
{

	public static Map<String, Map<String, String>> mapXGRGFTREG = new HashMap<String, Map<String,String>>();

	public static Map<String, Map<String, String>> mapGRADDR = new HashMap<String, Map<String,String>>();
	
	public static Map<String,List<Map<String, String>>> mapGRANNHIST = new HashMap<String, List<Map<String,String>>>();
	
	public static Map<String,List<Map<String, String>>> mapGRRGSTRNT = new HashMap<String, List<Map<String,String>>>();
	
	public static Map<String,List<Map<String, String>>> mapGREMLLIST = new HashMap<String, List<Map<String,String>>>();
	
	public static Map<String,List<Map<String, String>>> mapGRADDR2 = new HashMap<String, List<Map<String,String>>>();
	
	public static Map<String,List<Map<String, String>>> mapXGRATTRVAL = new HashMap<String, List<Map<String,String>>>();
	
	
	public static void clearMap(String id)
	{
		mapGRADDR.remove(id);
		mapGRADDR2.remove(id);
		mapGRANNHIST.remove(id);
		mapGREMLLIST.remove(id);
		mapGRRGSTRNT.remove(id);
		mapXGRATTRVAL.remove(id);
		mapXGRGFTREG.remove(id);
	}
	/**
	 * Table : GRGFTREG
	 * 
	 * @param list
	 * @return
	 */
	public static Map<String,Map<String,String>> getGRGFTREG(String strList)
	{
		return DBUtil.executeQueryMultiRowMultiColumnMap
				("select * from GRGFTREG where GIFTREGISTRY_ID in ("+strList+") with ur","GIFTREGISTRY_ID");
	}
	
	public static void init(List<String> strLists)
	{
		String strList = getListToString(strLists);
		
		initXGRGFTREG(strList);

		initGRANNHIST(strList);

		initGRRGSTRNT(strList);
		
		initGREMLLIST(strList);
		
		initGRADDR2(strList);
		
		initXGRATTRVAL(strList);
	}
	public static void init(String strList)
	{
		initXGRGFTREG(strList);

		initGRANNHIST(strList);

		initGRRGSTRNT(strList);
		
		initGREMLLIST(strList);
		
		initGRADDR2(strList);
		
		initXGRATTRVAL(strList);
	}
			
	
	public static void initXGRGFTREG(String strList)
	{
		mapXGRGFTREG.putAll(DBUtil.executeQueryMultiRowMultiColumnMap
				("select * from XGRGFTREG where xgrgftreg_id in ("+strList+") with ur","XGRGFTREG_ID"));
	}

	public static void initGRADDR(String strList)
	{
		mapGRADDR.putAll(DBUtil.executeQueryMultiRowMultiColumnMap
				("select * from GRADDR g,GRRGSTRNT gt where g.address_id = gt.address_id  and  giftregistry_id in("+strList+") with ur","giftregistry_id"));
	}

	public static void initGRANNHIST(String strList)
	{
		String sQuery = " select * from GRANNHIST where GIFTREGISTRY_ID in ("+strList+") order by field1 with ur";
		
		mapGRANNHIST.putAll(DBUtil.executeQuery(sQuery ,"GIFTREGISTRY_ID"));
		
	}
	
	public static void initGRRGSTRNT(String strList)
	{
		String sQuery  = "select * from GRRGSTRNT where ADDRESS_ID in (select PREEVENTADDRESS_ID from GRGFTREG where GIFTREGISTRY_ID in("+strList+")) with ur";
	
		mapGRRGSTRNT.putAll(DBUtil.executeQuery(sQuery,"GIFTREGISTRY_ID"));
		
	}
	
	public static void initGREMLLIST(String strList)
	{

		/*String sQuery ="select * from GREMLLIST where annhistory_id in "+
				" (select annhistory_id from GRANNHIST where giftregistry_id in("+strList+")) with ur";*/
		
		String sQuery ="select * from GREMLLIST a,GRANNHIST b where a.annhistory_id  = b.annhistory_id and b.giftregistry_id in("+strList+") with ur";
		
		mapGREMLLIST.putAll(DBUtil.executeQuery(sQuery,"GIFTREGISTRY_ID"));
		
	}
	
	public static void initGRADDR2(String strList)
	{

		/*String sQuery =" select * from GRADDR where address_id in (select preeventaddress_id from GRGFTREG" +
					"  where giftregistry_id in ("+strList+")) with ur";*/
		
		String sQuery = " select * from GRADDR a,GRGFTREG b where a.address_id = b.preeventaddress_id and b.giftregistry_id in ("+strList+") with ur";
		
		mapGRADDR2.putAll(DBUtil.executeQuery(sQuery,"GIFTREGISTRY_ID"));
		
	}
	
	public static void initXGRATTRVAL(String strList)
	{

		String sQuery ="select * from XGRATTRVAL where GIFTREGISTRY_ID in ("+strList+") with ur";
		
		mapXGRATTRVAL.putAll(DBUtil.executeQuery(sQuery,"GIFTREGISTRY_ID"));
		
	}
	
	
	public static String getListToString(List<String> sp)
	{
		String giftregistry_ids = null;

		for (String string : sp) 
		{
			if(string!=null && !string.isEmpty())
			{
				if(giftregistry_ids==null)
					giftregistry_ids="'"+string+"'";
				else
					giftregistry_ids=giftregistry_ids+",'"+string+"'";
			}
		}

		return giftregistry_ids;
	}
}
