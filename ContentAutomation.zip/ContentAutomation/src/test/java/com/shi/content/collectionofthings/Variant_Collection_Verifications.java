package com.shi.content.collectionofthings;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.generated.vos.content.Content;
import com.generated.vos.content.Desc;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Operational;
import com.generated.vos.contentbco.PrimAttr;
import com.generated.vos.contentbco.PrimAttr_;
import com.generated.vos.contentbco.Product;
import com.generated.vos.contentbco.Sites____;
import com.generated.vos.contentbco.Sites_____;
import com.generated.vos.contentbco.Val;
import com.generated.vos.hierarchy.Attrs;
import com.generated.xmls.collections.Attribute;
import com.generated.xmls.collections.Attributes;
import com.generated.xmls.collections.Bundle;
import com.generated.xmls.collections.Collection;
import com.generated.xmls.collections.CuratedContent;
import com.generated.xmls.collections.Group;
import com.generated.xmls.collections.Hierarchy;
import com.generated.xmls.collections.ItemPartNumber;
import com.generated.xmls.collections.VariantCollection;
import com.generated.xmls.collections.VariantCollectionAttributeTypeChoiceItem;
import com.generated.xmls.collections.VariantCollectionElementsGroup;
import com.generated.xmls.collections.VariantCollectionTypeChoice;
import com.generated.xmls.collections.VariantCollectionTypeChoiceItem;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.wcsmigration.verifications.SHCCollectionBundleCommons;

public class Variant_Collection_Verifications implements Runnable {
	
	Collection collection;
	Bundle bundle;
	Boolean isBundle = false;
	Boolean isCrossFormatted = false;
	String itemClassId;
	Attrs masterHierarchyAttributes;
	String sSiteToTest;
	SHCCollectionBundleCommons commonUtils;
	String spinId;
	String catentrySubType;
	List<String> errorPartNumbers;
	private VariantCollection variantCollection;
	private String varBndlId;

	public Variant_Collection_Verifications(
			VariantCollection variantCollection,
			SHCCollectionBundleCommons commonUtils, 
			String siteToTest,
			List<String> errorPartNumbers) {
		this.variantCollection = variantCollection;
		this.itemClassId = variantCollection.getVariantCollectionElementsGroup().getMasterHierarchyId().toString();
		this.commonUtils = commonUtils;
		this.sSiteToTest = siteToTest;
		this.errorPartNumbers = errorPartNumbers;
	}

	@Override
	public void run() {
		try{
		CompareValuesUtility.init();
		
		String id = null;
		com.generated.xmls.collections.VariantCollectionElementsGroup commElementsGrp = null;
		String soldBy = null;
		
		Boolean pNotFound = false;
		if(sSiteToTest.equals("sears")){
			/*Check if variant-collection has Kmart site*/
			Boolean parentSiteFound = false;
			for(com.generated.xmls.collections.Site site : variantCollection.getVariantCollectionElementsGroup().getSite()){
				long lSiteId = site.getId();
				if(lSiteId==1 && variantCollection.getVariantCollectionKmartPartNumber()==null){
					isCrossFormatted = true;
				}
				if(lSiteId==2 && variantCollection.getVariantCollectionSearsPartNumber()!=null){
					parentSiteFound = true;
				}
			}
			/*Check if is-primary groups have sears or kmart partnumber*/
			/*for(com.generated.xmls.collections.VariantCollectionTypeChoiceItem varColGrp : variantCollection.getVariantCollectionTypeChoice().getVariantCollectionTypeChoiceItem()){
				for(com.generated.xmls.collections.Group group : varColGrp.getVariantCollectionGroups().getGroup()){
					if(group.getIsPrimary()!=null && group.getIsPrimary()){					
						for(ItemPartNumber item : group.getItemPartNumber()){
							if(item.getItemSearsPartNumber()==null){
								System.out.println("Non-"+sSiteToTest+" variant-collection: "+variantCollection.getVariantCollectionSearsPartNumber()+"B");
								pNotFound = true;
								return;
							}
							if(item.getItemKmartPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}else{
						for(ItemPartNumber item : group.getItemPartNumber()){
							if(item.getItemKmartPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}
				}
			}*/
			/*Check if parent Site exists in feed*/
			if(!parentSiteFound){
				System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " variant-collection: "+variantCollection.getVariantCollectionSearsPartNumber()+"B");
				return;
			}
			if(!pNotFound){
				id = variantCollection.getVariantCollectionSearsPartNumber()+"B";
				soldBy = "Sears";
			}
		}else{
			/*Check if variant-collection has Sears site*/
			Boolean parentSiteFound = false;
			for(com.generated.xmls.collections.Site site : variantCollection.getVariantCollectionElementsGroup().getSite()){
				long lSiteId = site.getId();
				if(lSiteId==2 && variantCollection.getVariantCollectionSearsPartNumber()==null){
					isCrossFormatted = true;
				}
				if(lSiteId==1 && variantCollection.getVariantCollectionKmartPartNumber()!=null){
					parentSiteFound = true;
				}
			}
			/*Check if first required group has sears or kmart partnumber*/
			/*for(com.generated.xmls.collections.VariantCollectionTypeChoiceItem varColGrp : variantCollection.getVariantCollectionTypeChoice().getVariantCollectionTypeChoiceItem()){
				for(com.generated.xmls.collections.Group group : varColGrp.getVariantCollectionGroups().getGroup()){
					if(group.getIsPrimary()!=null && group.getIsPrimary()){					
						for(ItemPartNumber item : group.getItemPartNumber()){
							if(item.getItemKmartPartNumber()==null){
								System.out.println("Non-"+sSiteToTest+" variant-collection: "+variantCollection.getVariantCollectionKmartPartNumber()+"B");
								pNotFound = true;
								return;
							}
							if(item.getItemSearsPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}else{
						for(ItemPartNumber item : group.getItemPartNumber()){
							if(item.getItemSearsPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}
				}
			}*/
			/*Check if parent Site exists in feed*/
			if(!parentSiteFound){
				System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " variant-collection: "+variantCollection.getVariantCollectionKmartPartNumber()+"B");
				return;
			}
			if(!pNotFound){
				id = variantCollection.getVariantCollectionKmartPartNumber()+"B";
				soldBy = "Kmart";
			}
		}
		
		commElementsGrp = variantCollection.getVariantCollectionElementsGroup();
		spinId = variantCollection.getSpinVariantCollectionId();

		this.varBndlId = id;
		System.out.println("Testing id: " + id);
		
		if(errorPartNumbers.contains(id)){
			System.out.println("Item not found in GB; found in error file: " + id);
			CompareValuesUtility.logPassed("Id", id, "Error Item, Not found in GB");
			CompareValuesUtility.setupResult(id, true);
			return;
		}

		APIResponse<com.generated.vos.contentbco.Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENTBCO,id);
		com.generated.vos.contentbco.Bundle gbVarBundle = (com.generated.vos.contentbco.Bundle)allResponse.getT();
		
		if(gbVarBundle==null){
			if(errorPartNumbers.contains(id)){
				System.out.println("Item not found in GB; found in error file: " + id);
				CompareValuesUtility.logPassed("Id", id, "Error Item, Not found in GB");
			}else{
				CompareValuesUtility.logFailed("Id", id, "Not Found in GB");
			}
		}
		else{
			try{
				verifyCommonElements(commElementsGrp, gbVarBundle, id, soldBy);
				verifyFtSearch(allResponse, soldBy);
				verifyVariantColl(variantCollection.getAttributes(), variantCollection.getVariantCollectionTypeChoice(), gbVarBundle);
				
			}catch (Exception e){
				System.out.println(e.getMessage() + " Exception : " + id);
			}	
		}
		
		CompareValuesUtility.setupResult(id, true);
		
		}catch (Exception e){
			System.out.println(e.getMessage() + " Exception for spinId: " + variantCollection.getSpinVariantCollectionId().toString());
		}	
	}

	private void verifyVariantColl(Attributes attributes, 
			VariantCollectionTypeChoice varCollType, 
			com.generated.vos.contentbco.Bundle gbVarBundle) {
		
		/*variantColls logic*/
		List<com.generated.xmls.collections.Group> primAttrGrps = new ArrayList<com.generated.xmls.collections.Group>();
		List<com.generated.xmls.collections.Group> nonPrimAttrGrps = new ArrayList<com.generated.xmls.collections.Group>();
		List<com.generated.xmls.collections.Group> dfltGrps = new ArrayList<com.generated.xmls.collections.Group>();
		
		for(VariantCollectionTypeChoiceItem varCollItem : varCollType.getVariantCollectionTypeChoiceItem()){
			for(Group group : varCollItem.getVariantCollectionGroups().getGroup()){
				if(group.isIsPrimary()!=null && group.isIsPrimary()	&& group.getCuratedLabel()!=null){
					primAttrGrps.add(group);
				}else if(group.getAttributes()!=null && group.getAttributes().getAttributeCount() > 0 && group.getCuratedLabel()!=null){
					nonPrimAttrGrps.add(group);
				}else if(group.getCuratedLabel()!=null){
					dfltGrps.add(group);
				}
			}
		}
		
		Map<String, String> attrValRankMap = new HashMap<String, String>();
		List<VariantColl> variantColls = new ArrayList<VariantColl>();
		
		/*Loop through primary attribute group list and create variantColl object for each unique primary attribute value and added to a list*/
		for(Group primAttrGrp : primAttrGrps){
			VariantColl variantColl = new VariantColl();
			List<Group> groupLst = new ArrayList<Group>();
			for(Attribute attr : primAttrGrp.getAttributes().getAttribute()){
				String attrId = attr.getAttributeId().toString();
				List<String> attrList = new ArrayList<String>();
				attrList.add(attrId);
				Map<String, String> attributeData = GreenBoxCache.getAttributeData(attrList);
				variantColl.setPrimAttrName(attributeData.get(attrId));
				for(VariantCollectionAttributeTypeChoiceItem attrVal : attr.getVariantCollectionAttributeTypeChoice().getVariantCollectionAttributeTypeChoiceItem()){
					String primAttrVal = "";
					if(attrVal.getAttributeValueId()!=null){
						String attrValId = attrVal.getAttributeValueId().toString();
						List<String> attrValList = new ArrayList<String>();
						attrValList.add(attrValId);
						Map<String, String> attrValueData = GreenBoxCache.getAttributeValData(attrValList);
						primAttrVal = attrValueData.get(attrValId);
					}else if(attrVal.getAttributeValueFree()!=null){
						primAttrVal = attrVal.getAttributeValueFree();
					}else if(attrVal.getAttributeValueFlag()!=null){
						primAttrVal = attrVal.getAttributeValueFlag().toString();
					}
					//TODO trademark-text logic
					
					variantColl.setPrimAttrVal(primAttrVal);
					
					//storing primary attribute rank for each attribute value
					attrValRankMap.put(primAttrVal, primAttrGrp.getRank().toString());
					
					break;
				}
				break;
			}
			groupLst.add(primAttrGrp);
			variantColl.setGroups(groupLst);
			variantColls.add(variantColl);
		}
		
		/*Loop through non-primary attribute group list and add each group to the matching variantColl*/
		for(Group nonPrimAttrGrp : nonPrimAttrGrps){
			for(Attribute attr : nonPrimAttrGrp.getAttributes().getAttribute()){
				String attrId = attr.getAttributeId().toString();
				List<String> attrList = new ArrayList<String>();
				attrList.add(attrId);
				Map<String, String> attributeData = GreenBoxCache.getAttributeData(attrList);
				String primAttrName = attributeData.get(attrId);
				for(VariantCollectionAttributeTypeChoiceItem attrVal : attr.getVariantCollectionAttributeTypeChoice().getVariantCollectionAttributeTypeChoiceItem()){
					String primAttrVal = "";
					if(attrVal.getAttributeValueId()!=null){
						String attrValId = attrVal.getAttributeValueId().toString();
						List<String> attrValList = new ArrayList<String>();
						attrValList.add(attrValId);
						Map<String, String> attrValueData = GreenBoxCache.getAttributeValData(attrValList);
						primAttrVal = attrValueData.get(attrValId);
					}else if(attrVal.getAttributeValueFree()!=null){
						primAttrVal = attrVal.getAttributeValueFree();
					}else if(attrVal.getAttributeValueFlag()!=null){
						primAttrVal = attrVal.getAttributeValueFlag().toString();
					}
					
					for(VariantColl variantColl : variantColls){
						if(primAttrName.equals(variantColl.getPrimAttrName()) &&
								primAttrVal.equals(variantColl.getPrimAttrVal())){
							List<Group> grpLst = variantColl.getGroups();
							grpLst.add(nonPrimAttrGrp);
							variantColl.setGroups(grpLst);
						}
					}
				}
			}
		}
		
		/*Loop through default group list and add each group to every variantColl*/
		for(Group dfltGrp : dfltGrps){
			for(VariantColl variantColl : variantColls){
				List<Group> grpLst = variantColl.getGroups();
				grpLst.add(dfltGrp);
				variantColl.setGroups(grpLst);
			}
		}
		
		/**Test code**/
		/*
		System.out.println("------------");
		for(VariantColl variantColl : variantColls){
			System.out.println("primAttrName: " + variantColl.getPrimAttrName());
			System.out.println("primAttrVal: " + variantColl.getPrimAttrVal());
			for(Group grp : variantColl.getGroups()){
				System.out.println("Grp Name: " + grp.getName());
			}
			System.out.println("------------");
		}
		*/
		/**ends**/
		/*variantColls logic ends*/
		
		verifyVariantCollAttrs(attributes, attrValRankMap, gbVarBundle);
		CompareValuesUtility.addNewMultiValuedFields();
		
		verifyVariantCollList(variantColls, gbVarBundle.getVariantColls(), gbVarBundle.getSites(), gbVarBundle.getOperational());
		CompareValuesUtility.addNewMultiValuedFields();
		
	}

	private void verifyVariantCollAttrs(Attributes attributes, 
			Map<String, String> attrValRankMap, 
			com.generated.vos.contentbco.Bundle gbVarBundle) {

		List<PrimAttr> gbPrimAttrs = gbVarBundle.getVariantCollAttrs()==null?null:gbVarBundle.getVariantCollAttrs().getPrimAttrs();

		for(Attribute attr : attributes.getAttribute()){
			Boolean aFound = false;
			if(attr.getIsPrimary()!=null && attr.getIsPrimary()){
				String attrId = attr.getAttributeId().toString();
				List<String> attrList = new ArrayList<String>();
				attrList.add(attrId);
				Map<String, String> attributeData = GreenBoxCache.getAttributeData(attrList);
				for(PrimAttr gbPrimAttr : gbPrimAttrs){
					if(attributeData.get(attrId).equals(gbPrimAttr.getName())){
						aFound = true;
						CompareValuesUtility.logPassed("primAttrName", gbPrimAttr.getName(), gbPrimAttr.getName());
						CompareValuesUtility.verifyNullOrEqual("primAttrRank", attr.getRank(), gbPrimAttr.getRank()==null?null:gbPrimAttr.getRank().intValue());
						CompareValuesUtility.addNewMultiValuedFields();
						
						for(VariantCollectionAttributeTypeChoiceItem val : attr.getVariantCollectionAttributeTypeChoice().getVariantCollectionAttributeTypeChoiceItem()){
							Boolean vFound = false;
							if(val.getAttributeValueId()!=null){
								String attrValId = val.getAttributeValueId().toString();
								List<String> attrValList = new ArrayList<String>();
								attrValList.add(attrValId);
								Map<String, String> attrValueData = GreenBoxCache.getAttributeValData(attrValList);
								for(Val gbVal : gbPrimAttr.getVals()){
									if(attrValueData.get(attrValId).equals(gbVal.getVal())){
										vFound = true;
										CompareValuesUtility.logPassed("primAttrsVal", gbVal.getVal(), gbVal.getVal());										
										CompareValuesUtility.verifyNullOrEqual("primAttrsValRank", attrValRankMap.get(gbVal.getVal()), gbVal.getRank()==null?null:gbVal.getRank().intValue());										
										CompareValuesUtility.addNewMultiValuedFields();
										break; //break when attrvalue found
									}
								}
								if(!vFound){
									CompareValuesUtility.logFailed("primAttrsVal", attrValueData.get(attrValId), "Not found in GB");
								}
							}
							//TODO value-free, value-flag to be added
						}
						break; //break when attribute found
					}
				}
				if(!aFound){
					CompareValuesUtility.logFailed("primAttrName", attributeData.get(attrId), "Not found in GB");
				}
			}
		}		
	}

	private void verifyVariantCollList(
			List<VariantColl> variantColls, 	
			List<com.generated.vos.contentbco.VariantColl> gbVariantColls, 
			List<String> sites, 
			com.generated.vos.contentbco.Operational gbVarBndlOper) {
		
		Boolean isDispEligSrVb = false;
		Boolean isDispEligKmVb = false;
		Boolean isDispEligMgVb = false;
		Boolean isDispEligPrVb = false;
		
		for(VariantColl varColl : variantColls){
			Boolean vFound = false;
			for(com.generated.vos.contentbco.VariantColl gbVarColl : gbVariantColls){
				for(PrimAttr_ gbPrAttr : gbVarColl.getPrimAttrs()){
					if(varColl.getPrimAttrName().equals(gbPrAttr.getName()) && varColl.getPrimAttrVal().equals(gbPrAttr.getVal())){
						vFound = true;
						
						CompareValuesUtility.logPassed("varCollsPrimAttrName", varColl.getPrimAttrName(), gbPrAttr.getName());
						CompareValuesUtility.logPassed("varCollsPrimAttrVal", varColl.getPrimAttrVal(), gbPrAttr.getVal());
						CompareValuesUtility.addNewMultiValuedFields();
						
						for(Group xmlGrp : varColl.getGroups()){
							Boolean gFound = false;
							for(com.generated.vos.contentbco.Group gbGrp : gbVarColl.getGroups()){
								if(xmlGrp.getId().toString().equals(gbGrp.getGrpId()) && xmlGrp.getName().equals(gbGrp.getName())){
									gFound = true;
									Boolean isPrimary = xmlGrp.getIsPrimary()==null?false:xmlGrp.getIsPrimary();
									
									CompareValuesUtility.logPassed("varCollsGrpName", xmlGrp.getName(), gbGrp.getName());
									CompareValuesUtility.logPassed("varCollsGrpId", xmlGrp.getId().toString(), gbGrp.getGrpId());
									CompareValuesUtility.verifyNullOrEqual("varCollsGrpIsPrimry", isPrimary?true:null, gbGrp.getIsPrimary());
									CompareValuesUtility.verifyNullOrEqual("varCollsGrpRank", xmlGrp.getRank().toString(), gbGrp.getRank());
									CompareValuesUtility.verifyNullOrEqual("varCollsGrpDispLbl", xmlGrp.getCuratedLabel(), gbGrp.getDispLabel());
									CompareValuesUtility.verifyNullOrEqual("varCollsGrpIsDflt", xmlGrp.getAttributes()==null?true:null, gbGrp.getIsDfltGrp());
									CompareValuesUtility.addNewMultiValuedFields();
									
									for(ItemPartNumber xmlItem : xmlGrp.getItemPartNumber()){

										String id;
										if(sSiteToTest.equals("sears")){
											id = xmlItem.getItemSearsPartNumber()+"P";
										}else{
											id = xmlItem.getItemKmartPartNumber()+"P";
										}
										
										if(id.equals("nullP")){
											System.out.println("item-"+sSiteToTest+"-part-number is null: " + xmlItem.getSpinUniqueId());
											continue;
										}
										
										com.generated.vos.content.Content gbContent = RestExecutor.getDataById(CollectionValuesVal.CONTENT,id);
										
										if(gbContent==null){
											System.out.println("Product not present in GB content: " + id);
											continue;
										}
										
										if(gbContent.getIdentity()==null || gbContent.getIdentity().getSsin()==null){
											System.out.println("Product SSIN null in GB content: " + id);
											continue;
										}
										
										if(gbContent.getOperational().getIsMarkForDelete()!=null && gbContent.getOperational().getIsMarkForDelete()){
											System.out.println("Product MFD=true in GB content: " + id);
											continue;
										}
										
										//TODO
										//Logic to skip group/logical bundle based on product validation
											
										Boolean pFound = false;
										for(Product gbGrpPrd : gbGrp.getProducts()){
											if(id.equals(gbGrpPrd.getId())){
												pFound = true;
												verifyProduct(id, xmlItem, gbContent, gbGrpPrd, sites, isPrimary, varColl, xmlGrp);
												CompareValuesUtility.addNewMultiValuedFields();
												CompareValuesUtility.addNewData();
												break; //when product found
											}
										}
										if(!pFound){
											CompareValuesUtility.compareValues("prdId", id, " Product not found under variantColl group: " + xmlGrp.getName());
										}
										//CompareValuesUtility.addNewMultiValuedFields();
									}
									break; //when group found
								}
							}
							if(!gFound){
								CompareValuesUtility.logFailed("varCollsGrpName", xmlGrp.getName(), "Not found in GB");
								CompareValuesUtility.logFailed("varCollsGrpId", xmlGrp.getId().toString(), "Not found in GB");
								
							}
							
							//CompareValuesUtility.addNewMultiValuedFields();
						}
						CompareValuesUtility.addNewMultiValuedFields();
						
						/*Validate logical bundle level operational & set root level operational based on logical bundle isDispElig*/
						if(sites.contains("sears")){
							CompareValuesUtility.verifyNullOrEqual("varCollsOperDispElig", varColl.getIsDispEligSr(), gbVarColl.getOperational().getSites().getSears().getIsDispElig(), "Sears");
							if(varColl.getIsDispEligSr())
								isDispEligSrVb = varColl.getIsDispEligSr();
						}
						if(sites.contains("kmart")){
							CompareValuesUtility.verifyNullOrEqual("varCollsOperDispElig", varColl.getIsDispEligKm(), gbVarColl.getOperational().getSites().getKmart().getIsDispElig(), "Kmart");
							if(varColl.getIsDispEligKm())
								isDispEligKmVb = varColl.getIsDispEligKm();
						}
						if(sites.contains("mygofer")){
							CompareValuesUtility.verifyNullOrEqual("varCollsOperDispElig", varColl.getIsDispEligMg(), gbVarColl.getOperational().getSites().getMygofer().getIsDispElig(), "Mygofer");
							if(varColl.getIsDispEligMg())
								isDispEligMgVb = varColl.getIsDispEligMg();
						}
						if(sites.contains("puertorico")){
							CompareValuesUtility.verifyNullOrEqual("varCollsOperDispElig", varColl.getIsDispEligPr(), gbVarColl.getOperational().getSites().getPuertorico().getIsDispElig(), "Pr");
							if(varColl.getIsDispEligPr())
								isDispEligPrVb = varColl.getIsDispEligPr();
						}
						CompareValuesUtility.addNewMultiValuedFields();
						
						/*Validate logical bundle operational*/
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsDeliveryElig(), gbVarColl.getFfm().getIsDeliveryElig(), "IsDeliveryElig");
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsShipElig(), gbVarColl.getFfm().getIsShipElig(), "IsShipElig");
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsSpuElig(), gbVarColl.getFfm().getIsSpuElig(), "IsSpuElig");
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsPickupOnly(), gbVarColl.getFfm().getIsPickupOnly(), "IsPickupOly");
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsSResElig(), gbVarColl.getFfm().getIsSResElig(), "IsSResElig");
						CompareValuesUtility.verifyNullOrEqual("varCollsFfm", varColl.getIsSTSElig(), gbVarColl.getFfm().getIsSTSElig(), "IsSTSElig");
						CompareValuesUtility.addNewMultiValuedFields();
						
						break; //when variantColl found
					}
				}
			}
			if(!vFound){
				CompareValuesUtility.logFailed("varCollsPrimAttrName", varColl.getPrimAttrName(), "Not found in GB");
				CompareValuesUtility.logFailed("varCollsPrimAttrVal", varColl.getPrimAttrVal(), "Not found in GB");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}
		
		/*Validate variant bundle root level operational*/
		if(sites.contains("sears")){
			CompareValuesUtility.verifyNullOrEqual("varBndlOperDispElig", isDispEligSrVb, gbVarBndlOper.getSites().getSears().getIsDispElig(), "Sears");	
		}
		if(sites.contains("kmart")){
			CompareValuesUtility.verifyNullOrEqual("varBndlOperDispElig", isDispEligKmVb, gbVarBndlOper.getSites().getKmart().getIsDispElig(), "Kmart");
		}
		if(sites.contains("mygofer")){
			CompareValuesUtility.verifyNullOrEqual("varBndlOperDispElig", isDispEligMgVb, gbVarBndlOper.getSites().getMygofer().getIsDispElig(), "Mygofer");
		}
		if(sites.contains("puertorico")){
			CompareValuesUtility.verifyNullOrEqual("varBndlOperDispElig", isDispEligPrVb, gbVarBndlOper.getSites().getPuertorico().getIsDispElig(), "Pr");
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
	}

	private void verifyProduct(
			String id, 
			ItemPartNumber item, 
			Content gbContent, 
			Product gbBundleProduct, 
			List<String> sites,
			Boolean isPrimary,
			VariantColl varColl, 
			Group xmlGrp) {
		
		CompareValuesUtility.compareValues("prdId", id, gbBundleProduct.getId());
		CompareValuesUtility.compareValues("prdRank", item.getRank().intValue(), gbBundleProduct.getRank());
		CompareValuesUtility.verifyNullOrEqual("prdQty", item.getQuantity()==null?"1":item.getQuantity().intValue(), gbBundleProduct.getQuantity());
		CompareValuesUtility.compareValues("prdName", gbContent.getName(), gbBundleProduct.getName());
		CompareValuesUtility.verifyNullOrEqual("prdBrand", gbContent.getBrand()==null?null:gbContent.getBrand().getName(), gbBundleProduct.getBrand());
		CompareValuesUtility.verifyNullOrEqual("prdModelNo", gbContent.getMfr()==null?null:gbContent.getMfr().getModelNo(), gbBundleProduct.getModelNo());
		
		CompareValuesUtility.compareValues("prdSsin", gbContent.getIdentity().getSsin(), gbBundleProduct.getSsin());
		CompareValuesUtility.compareValues("prdCatSubTyp", gbContent.getClassifications().getCatentrySubType(), gbBundleProduct.getCatentrySubType());
		CompareValuesUtility.verifyNullOrEqual("prdDispLbl", item.getDisplayLabel(), gbBundleProduct.getDispLabel());
		
		if(item.getDisplayLabel()==null && xmlGrp.getCuratedLabel().equals("Pillow")){
			System.out.println("Pillow item missing display-label. group-id=" 
								+ xmlGrp.getId().toString() 
								+ " spin-variant-collection-id=" 
								+ spinId
								+ " variant-collection-sears-part-number=" 
								+ this.varBndlId.substring(0, this.varBndlId.length()-1));
		}
		
		String offerId = id.substring(0, id.length()-1);
		com.generated.vos.offer.Offer gbOffer = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerId);
		
		Boolean prdDispElig = false;
		
		if(gbOffer!=null){
			CompareValuesUtility.compareValues("prdOffrId", offerId, gbBundleProduct.getOfferId());
			
			Boolean ofrDelvElig = gbOffer.getFfm().getIsDeliveryElig()==null?false:gbOffer.getFfm().getIsDeliveryElig();
			Boolean ofrShipElig = gbOffer.getFfm().getIsShipElig()==null?false:gbOffer.getFfm().getIsShipElig();
			Boolean ofrSpuElig = gbOffer.getFfm().getIsSpuElig()==null?false:gbOffer.getFfm().getIsSpuElig();
			Boolean ofrPckupOly = (gbOffer.getFfm().getChannel().equals("SPU") && !ofrDelvElig && !ofrShipElig)?true:false;
			Boolean ofrSTSElig = gbOffer.getFfm().getIsSTSElig()==null?false:gbOffer.getFfm().getIsSTSElig();
			Boolean ofrSResElig = gbOffer.getFfm().getIsSResElig()==null?false:gbOffer.getFfm().getIsSResElig();

			CompareValuesUtility.compareValues("prdFfmDelvElig", ofrDelvElig, gbBundleProduct.getFfm().getIsDeliveryElig());
			CompareValuesUtility.compareValues("prdFfmShipElig", ofrShipElig, gbBundleProduct.getFfm().getIsShipElig());
			CompareValuesUtility.compareValues("prdFfmSpuElig", ofrSpuElig, gbBundleProduct.getFfm().getIsSpuElig());
			CompareValuesUtility.compareValues("prdFfmPickupOly", ofrPckupOly, gbBundleProduct.getFfm().getIsPickupOnly());
			CompareValuesUtility.compareValues("prdfmStsElig", ofrSTSElig, gbBundleProduct.getFfm().getIsSTSElig());
			CompareValuesUtility.compareValues("prdFfmSresElig", ofrSResElig, gbBundleProduct.getFfm().getIsSResElig());
			CompareValuesUtility.compareValues("prdFfmSoldBy", gbOffer.getFfm().getSoldBy()==null?null:gbOffer.getFfm().getSoldBy().toLowerCase(), gbBundleProduct.getFfm().getSoldBy());
			
			if(isPrimary){
				varColl.setIsDeliveryElig(ofrDelvElig);
				varColl.setIsShipElig(ofrShipElig);
				varColl.setIsSpuElig(ofrSpuElig);
				varColl.setIsPickupOnly(ofrPckupOly);
				varColl.setIsSTSElig(ofrSTSElig);
				varColl.setIsSResElig(ofrSResElig);
			}
			
			Sites_____ gbBndlPrdOper = gbBundleProduct.getOperational()==null?null:(gbBundleProduct.getOperational().getSites()==null?null:gbBundleProduct.getOperational().getSites());
			
			if(gbBndlPrdOper!=null){
				if(sites.contains("sears")){
					Boolean isDispElig = evaluateDispElig(gbContent.getOperational(), gbOffer.getOperational(), this.sSiteToTest);
					CompareValuesUtility.verifyNullOrEqual("prdSrDispElig", isDispElig, gbBndlPrdOper.getSears()==null?null:gbBndlPrdOper.getSears().getIsDispElig());
					if(isPrimary){
						varColl.setIsDispEligSr(isDispElig);
					}
					prdDispElig = isDispElig;
				}else{
					CompareValuesUtility.verifyNull("prdSrDispElig", gbBndlPrdOper.getSears());
				}
				if(sites.contains("kmart")){
					Boolean isDispElig = evaluateDispElig(gbContent.getOperational(), gbOffer.getOperational(), this.sSiteToTest);
					CompareValuesUtility.verifyNullOrEqual("prdKmDispElig", isDispElig, gbBndlPrdOper.getKmart()==null?null:gbBndlPrdOper.getKmart().getIsDispElig());
					if(isPrimary){
						varColl.setIsDispEligKm(isDispElig);
					}
					prdDispElig = isDispElig;
				}else{
					CompareValuesUtility.verifyNull("prdKmDispElig", gbBndlPrdOper.getKmart());
				}
				if(sites.contains("mygofer")){
					Boolean isDispElig = evaluateDispElig(gbContent.getOperational(), gbOffer.getOperational(), "mygofer");
					CompareValuesUtility.verifyNullOrEqual("prdMgDispElig", isDispElig, gbBndlPrdOper.getMygofer()==null?null:gbBndlPrdOper.getMygofer().getIsDispElig());
					if(isPrimary){
						varColl.setIsDispEligMg(isDispElig);
					}
				}else{
					CompareValuesUtility.verifyNull("prdMgDispElig", gbBndlPrdOper.getMygofer());
				}
				if(sites.contains("puertorico")){
					Boolean isDispElig = evaluateDispElig(gbContent.getOperational(), gbOffer.getOperational(), "puertorico");
					CompareValuesUtility.verifyNullOrEqual("prdPrDispElig", isDispElig, gbBndlPrdOper.getPuertorico()==null?null:gbBndlPrdOper.getPuertorico().getIsDispElig());
					if(isPrimary){
						varColl.setIsDispEligPr(isDispElig);
					}
				}else{
					CompareValuesUtility.verifyNull("prdPrDispElig", gbBndlPrdOper.getPuertorico());
				}
			}else{
				CompareValuesUtility.logFailed("prdOper", "Null in GB", "operational");
			}
		}
		
		List<com.generated.vos.content.Desc> desc = gbContent.getDesc();
		int i = getPositionInList("S", desc, "type", Desc.class);
		
		CompareValuesUtility.compareValues("prdDescTyp", "S", gbBundleProduct.getDesc().getType());
		CompareValuesUtility.compareValues("prdDescVal", desc.get(i).getVal()==null?null:desc.get(i).getVal(), gbBundleProduct.getDesc()==null?null:gbBundleProduct.getDesc().getVal()==null?null:gbBundleProduct.getDesc().getVal());
		
		List<Img_> imgs = gbContent.getAssets().getImgs();
		int j = getPositionInList("P", imgs, "type", Img_.class);
				
		if(j!=-1){
			CompareValuesUtility.compareValues("prdImgTyp", "P", gbBundleProduct.getImgs().getType());
			CompareValuesUtility.compareValues("prdImgSrc", imgs.get(j).getVals().get(0).getSrc(), gbBundleProduct.getImgs().getVals().get(0).getSrc());
			CompareValuesUtility.verifyNullOrEqual("prdImgHeight", imgs.get(j).getVals().get(0).getHeight(), gbBundleProduct.getImgs().getVals().get(0).getHeight());
			CompareValuesUtility.verifyNullOrEqual("prdImgWidth", imgs.get(j).getVals().get(0).getWidth(), gbBundleProduct.getImgs().getVals().get(0).getWidth());
			CompareValuesUtility.verifyNullOrEqual("prdImgTitle", imgs.get(j).getVals().get(0).getTitle(), gbBundleProduct.getImgs().getVals().get(0).getTitle());
		}
		
		if(isPrimary && prdDispElig){
			com.generated.vos.prodrel.Prodrel gbProdrel = RestExecutor.getDataById(CollectionValuesVal.PRODREL, id);
			if(gbProdrel==null){
				CompareValuesUtility.logFailed("ProdrelId", id, "Not Found");
			}else{
				CompareValuesUtility.logPassed("ProdrelId", id, gbProdrel.getId());
				CompareValuesUtility.verifyNullOrEqual("ProdrelType", "P2VB", gbProdrel.getRelType());
				CompareValuesUtility.verifyNullOrEqual("ProdrelSoldBy", gbOffer.getFfm().getSoldBy()==null?null:gbOffer.getFfm().getSoldBy().toLowerCase(), gbProdrel.getSoldBy());
				CompareValuesUtility.verifyNullOrEqual("ProdrelCollId", this.varBndlId, gbProdrel.getVarColl().getCollId());
				CompareValuesUtility.verifyNullOrEqual("ProdrelAttrName", varColl.getPrimAttrName(), gbProdrel.getVarColl().getPrimAttrs().get(0).getName());
				CompareValuesUtility.verifyNullOrEqual("ProdrelAttrVal", varColl.getPrimAttrVal(), gbProdrel.getVarColl().getPrimAttrs().get(0).getVal());
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	private Boolean evaluateDispElig(Operational contOper,
			com.generated.vos.offer.Operational offrOper, 
			String site) {

		switch(site){
		case "sears":
			try{
				if(contOper.getSites().getSears().getIsDispElig()){
					if(offrOper.getSites().getSears().getIsDispElig())
						return true;
					else
						return false;
				}else
					return false;
			}catch(Exception e){
				return false;
			}
		case "kmart":
			try{
				if(contOper.getSites().getKmart().getIsDispElig()){
					if(offrOper.getSites().getKmart().getIsDispElig())
						return true;
					else
						return false;
				}else
					return false;
			}catch(Exception e){
				return false;
			}
		case "mygofer":
			try{
				if(contOper.getSites().getMygofer().getIsDispElig()){
					if(offrOper.getSites().getMygofer().getIsDispElig())
						return true;
					else
						return false;
				}else
					return false;
			}catch(Exception e){
				return false;
			}
		case "puertorico":
			try{
				if(contOper.getSites().getPuertorico().getIsDispElig()){
					if(offrOper.getSites().getPuertorico().getIsDispElig())
						return true;
					else
						return false;
				}else
					return false;
			}catch(Exception e){
				return false;
			}
		default:
			return false;
		}
	}

	private void verifyFtSearch(APIResponse<com.generated.vos.contentbco.Bundle> allResponse, String soldBy) {
		CompareValuesUtility.compareValues("_ft", catentrySubType, allResponse.getFtFieldValue("catentrySubType"), "catentrySubType");
		CompareValuesUtility.compareValues("_ft", soldBy, allResponse.getFtFieldValue("pgrmType"), "pgrmType");
		CompareValuesUtility.addNewMultiValuedFields();
		CompareValuesUtility.compareValues("_search.spinId", spinId, allResponse.getSearchFieldValue("spinId"));
		
	}

	private void verifyCommonElements(
			VariantCollectionElementsGroup commElementsGrp,
			com.generated.vos.contentbco.Bundle gbBundleContent, 
			String id, 
			String soldBy) {
		
		CompareValuesUtility.compareValues("Id", id, gbBundleContent.getId());
		CompareValuesUtility.compareValues("Name", TestUtils.plainEncodeHTML(OfferCommons.escapeNewline(commElementsGrp.getName())), gbBundleContent.getName());
		
		catentrySubType = "C";
		catentrySubType = "VB";
		
		CompareValuesUtility.compareValues("Classifications", "C", gbBundleContent.getClassifications().getCatentryType(), "catentryType");
		CompareValuesUtility.compareValues("Classifications", catentrySubType, gbBundleContent.getClassifications().getCatentrySubType(), "catentrySubType");
		CompareValuesUtility.compareValues("Classifications", "S", gbBundleContent.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
		CompareValuesUtility.compareValues("Classifications", "false", gbBundleContent.getClassifications().getIsMarketplace(), "isMarketplace");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.compareValues("AltIds", spinId, gbBundleContent.getAltIds().getSpinId(), "spinId");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("isMarkForDelete", null, gbBundleContent.getOperational()==null?null:gbBundleContent.getOperational().getIsMarkForDelete());

		/***Validate sites***/
		commonUtils.verifySites(commElementsGrp, gbBundleContent.getSites(), isCrossFormatted);

		/***Taxonomy***/
		verifyTaxonomy(commElementsGrp.getSite(), gbBundleContent);
		
		/***curatedContents***/
		if(commElementsGrp.getCuratedContents() != null){
			CompareValuesUtility.addNewMultiValuedFields();
			verifyCuratedContents(commElementsGrp.getCuratedContents().getCuratedGroup(), gbBundleContent.getCuratedContents());
		}
	}
	
	public void verifyCuratedContents(com.generated.xmls.collections.CuratedGroup[] curatedGroups, com.generated.vos.contentbco.CuratedContents curatedContents) {

		if(curatedContents==null || curatedContents.getCuratedGrp()==null){
			CompareValuesUtility.logFailed("curatedContents", "Found in XML", "Not found in GB");
			return;
		}
		else{
			List<com.generated.vos.contentbco.CuratedGrp> gbCuratedGrps = curatedContents.getCuratedGrp(); // curatedContents.get(0).getCuratedGrp();

			for (com.generated.xmls.collections.CuratedGroup xmlCurGroup : curatedGroups) {
				int i = CompareValuesUtility.getPositionInList(String.valueOf((Long.valueOf(xmlCurGroup.getRank()).doubleValue())), gbCuratedGrps, "rank", com.generated.vos.contentbco.CuratedGrp.class);
				if (i != -1) {
					compareValues("CurGrpType", xmlCurGroup.getCuratedType(), gbCuratedGrps.get(i).getType());
					compareValues("CurGrpRank", xmlCurGroup.getRank(), GenericUtil.convertToString(gbCuratedGrps.get(i).getRank()));
					verifyNullOrEqual("CurGrpName", xmlCurGroup.getCuratedGroupName(), gbCuratedGrps.get(i).getName());
					verifyNullOrEqual("CurGrpLabel", xmlCurGroup.getCuratedLabel(), gbCuratedGrps.get(i).getDispLabel());
					
					for (CuratedContent xmlCurContent : xmlCurGroup.getCuratedContent()) {
						int j = CompareValuesUtility.getPositionInList(xmlCurContent.getContentType(), gbCuratedGrps.get(i).getContent(), "type", com.generated.vos.contentbco.Content.class);
						if (j != -1) {
							com.generated.vos.contentbco.Content currentGbContent = gbCuratedGrps.get(i).getContent().get(j);
							compareValues("CurContType", xmlCurContent.getContentType(), currentGbContent.getType());
							verifyNullOrEqual("CurContName", xmlCurContent.getContentName(), currentGbContent.getName());
							verifyNullOrEqual("CurContCol", xmlCurContent.getColumn(), GenericUtil.convertToString(currentGbContent.getColumn()));
							verifyNullOrEqual("CurContRow", xmlCurContent.getRow(), GenericUtil.convertToString(currentGbContent.getRow()));
							verifyNullOrEqual("CurContData", xmlCurContent.getData(), currentGbContent.getData());
	
							if (xmlCurContent.getContentType().equalsIgnoreCase("asset")) {
								verifyNullOrEqual("CurContAsstName", xmlCurContent.getAsset().getName(), currentGbContent.getAsset().getName());
								verifyNullOrEqual("CurContAsstType", xmlCurContent.getAsset().getCuratedAssetTypeType()==null?null:xmlCurContent.getAsset().getCuratedAssetTypeType().toString(), currentGbContent.getAsset().getType()==null?null:currentGbContent.getAsset().getType().toString());
								verifyNullOrEqual("CurContAsstUrl", xmlCurContent.getAsset().getUrl(), currentGbContent.getAsset().getUrl());
								verifyNullOrEqual("CurContAsstHeight", xmlCurContent.getAsset().getHeight(), GenericUtil.convertToString(currentGbContent.getAsset().getHeight()));
								verifyNullOrEqual("CurContAsstWidth", xmlCurContent.getAsset().getWidth(), GenericUtil.convertToString(currentGbContent.getAsset().getWidth()));
							}
	
						} else {
							logFailed("CurContType", xmlCurContent.getContentType(), "Not found in GB");
						}
					}
				} else {
					compareValues("CurGrpName", xmlCurGroup.getCuratedGroupName(), "Not found in GB");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}
	
	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	List<String> lstAttributeVals = new ArrayList<String>();
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	List<String>  lstAttribsNotFound = new ArrayList<>();
	String brandCodeId = null, autoFitmentType = null;
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "1109310","12206","798110","1025310","777310","781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });

	boolean isPrimaryAvlbl = false; 
	
	private void verifyTaxonomy(com.generated.xmls.collections.Site[] sites, com.generated.vos.contentbco.Bundle gbBundleContent) {
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();

		for ( com.generated.xmls.collections.Site site : sites) {

			long lSiteId = site.getId();

			if(lSiteId > 11 || lSiteId == 10)
				continue;
			/*if(!isCrossFormatted && ((sSiteToTest.equals("sears") && lSiteId == 1) || (sSiteToTest.equals("kmart") && lSiteId == 2)))
				continue;*/

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				if(hierarchy.getPrimary().toString().equals("true"))
					isPrimaryAvlbl = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		/*if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, 
							gbBundleContent.getTaxonomy() == null? null : gbBundleContent.getTaxonomy().getWeb(),
							sSiteToTest,
							isCrossFormatted);*/

		commonUtils.compareMasterhierarchyGB(Long.parseLong(itemClassId), 
				gbBundleContent.getTaxonomy() == null? null : gbBundleContent.getTaxonomy().getMaster().getHierarchy());
	}

}
