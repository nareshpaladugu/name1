package com.shi.content.storeloadtests;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.shc.autocontent.db.DBConnecter;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

/**
 * @author skadam
 *
 */

public class StoreLoadMatchJob implements Runnable
{

	String lineToProcess;
	StoreLoadDataVO expectedSearsObjectVo;
	MatchingStoreData matchData;
	com.generated.vos.store.Unit actualUnit=null;
	public StoreLoadMatchJob(String lineToProcess)
	{
		this.lineToProcess=lineToProcess;
	}

	@Override
	public void run() 
	{		
		expectedSearsObjectVo= prepareExpectedObjectFromFile();

		matchData = new MatchingStoreData();

		if(expectedSearsObjectVo!=null)
		{
			//Code for Report Generation.  
			CompareValuesUtility.init();

			//Get Data from North star Mysql
			getInputFromMySql(expectedSearsObjectVo);

			//Get Store Schema
			actualUnit=RestExecutor.getDataById(CollectionValuesVal.STORE_UNIT, expectedSearsObjectVo.getStoreId());

			if(actualUnit==null)
			{
				CompareValuesUtility.addFailedDataFieldForReport("GB-Sears-Store-Unit", "Not Found");
			}			
			else
			{
				matchData.matchExpectedActualData(expectedSearsObjectVo, actualUnit, "Sears");
			}

			CompareValuesUtility.setupResult(expectedSearsObjectVo.getStoreId(), true);
		}
	}

	
	//To prepare data from text file
	private StoreLoadDataVO prepareExpectedObjectFromFile()
	{
		StoreLoadDataVO vo=new StoreLoadDataVO();        

		vo.setStoreId(lineToProcess.substring(0, 7));
		vo.setStrType1(lineToProcess.substring(7, 10));
		vo.setStrType2(lineToProcess.substring(10,12));
		vo.setName(lineToProcess.substring(12,42));
		vo.setAddress(lineToProcess.substring(42,102).trim());
		vo.setCity(lineToProcess.substring(102,115));
		vo.setDistrict(lineToProcess.substring(115,117));
		vo.setZipcode(lineToProcess.substring(117,122));
		vo.setCode(lineToProcess.substring(122,127));
		vo.setMgrName(lineToProcess.substring(126,156));
		vo.setPhoneNo(getphNo(lineToProcess.substring(157, 170)));
		vo.setStartDate(lineToProcess.substring(169,179));
		vo.setEndDate(lineToProcess.substring(179, 189));
		vo.setStrStatus();
		vo.setDistNo(lineToProcess.substring(198,201));
		vo.setRegion(lineToProcess.substring(204,208));
		System.out.println(getSiteByStoreId(lineToProcess.substring(0, 7)+"--> "+vo.getStrType1()+vo.getStrType2()));
		vo.setLocalAd(getSiteByStoreId(lineToProcess.substring(0, 7)), vo.getStrType1(), vo.getStrType2());
		System.out.println(vo.isLocalAd());
		return vo;
	}
	
	//To get Site Name by Store ID
	private String getSiteByStoreId(String storeID)
	{
		actualUnit=RestExecutor.getDataById(CollectionValuesVal.STORE_UNIT, storeID);
		return actualUnit.getSiteId().toString();
	}
	
	//To get phone No. from text file
	private String getphNo(String strInput)
	{
		String phNo="";
		phNo=strInput.substring(0,3);
		phNo=phNo+strInput.substring(4, 7);
		phNo=phNo+strInput.substring(8, 12);
		return phNo;
	}	

	//To get Data from North Star MySql Database
	private void getInputFromMySql(StoreLoadDataVO expectedObjectVo)
	{

		Statement stmnt=null;
		Statement stmnt2= null;

		//code to get data from mysql database
		try{

			stmnt= DBConnecter.getConnection().createStatement();
			stmnt2= DBConnecter.getConnection().createStatement();
			String query1="select latitude,longitude from zipcode where zipcode="+expectedObjectVo.getZipcode();
			String query2="select NS_NEW_VAL from nstar_audit where ns_unit_number="+expectedObjectVo.getStoreId()+" order by UPDATED Limit 1";

			ResultSet latlong=stmnt.executeQuery(query1);
			ResultSet strAttr=stmnt2.executeQuery(query2);

			while(latlong.next())
			{
				expectedObjectVo.setLattitude(latlong.getString("latitude"));			 
				expectedObjectVo.setLongitude(latlong.getString("longitude"));
			}
			while(strAttr.next())
			{
				expectedObjectVo.setStoreAttr(strAttr.getString("NS_NEW_VAL"));
			}	    

		}catch(SQLException e)
		{			
			e.printStackTrace();
		}
		finally
		{
			try {
				if(stmnt!=null)
					stmnt.close();

				if(stmnt2!=null)
					stmnt2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

