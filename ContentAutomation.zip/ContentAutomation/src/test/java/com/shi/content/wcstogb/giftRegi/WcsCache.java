package com.shi.content.wcstogb.giftRegi;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import com.shc.autocontent.db.DBUtil;

public class WcsCache 
{
	
	public static ResultSet getGRPURREC(String giftregistry_id)
	{
		//String sQuery ="select * from GRPURREC where giftregistry_id='"+giftregistry_id+"' with ur";

		String sQuery = "select * from GRPURREC a,X_GR_PUR_REC b where a.purchaserecord_id=b.purchase_record_id and giftregistry_id='"+giftregistry_id+"' with ur";

		return DBUtil.executeQueryReturnAll(sQuery);
	}


	public static ResultSet getGRGFTITM(String giftregistry_id)
	{
		String sQuery ="select * from GRGFTITM where giftregistry_id='"+giftregistry_id+"' with ur";

		return DBUtil.executeQueryReturnAll(sQuery);
	}

	public static Map<String, Map<String, String>> getDataForXGRGFTITM(String giftregistry_id)
	{

		String sQueryXGRGFTITM ="select * from XGRGFTITM where giftitem_id in " +
				"(select giftitem_id from GRGFTITM where giftregistry_id='"+giftregistry_id+"') with ur";

		return DBUtil.executeQueryMultiRowMultiColumnMap(sQueryXGRGFTITM, "giftitem_id");
	}



	public static String getEventTypeName(String eventTypeId)
	{
		String sQuery = "select EVENTTYPENAME from GREVNTTYPE where EVENTTYPE_ID='"+eventTypeId+"'";

		return DBUtil.executeQuerySingleResult(sQuery);
	}

	public static String getdefaultRegistryId(String store,String userId)
	{
		if(store.equalsIgnoreCase("sears") || store.equalsIgnoreCase("10153"))
		{
			store="111";
		}

		else if(store.equalsIgnoreCase("kmart")|| store.equalsIgnoreCase("10151"))
		{
			store="222";
		}

		String query = "select STRINGVALUE from MBRATTRVAL where MBRATTR_ID="+store+" and MEMBER_ID in " +
				"(select users_id from USERPROF where field2='"+userId+"') with ur";

		return DBUtil.executeQuerySingleResult(query);

	}

	public static String getUserRole(String userid)
	{
		String query ="select RGSTRNTTYPE from GRRGSTRNT where userid='"+userid+"' with ur";  

		return DBUtil.executeQuerySingleResult(query);
	}

	public static String getSYWRIDVal(String userId)
	{
		String query ="select SYWRID from XGRGFTREG where xgrgftreg_id in (select giftregistry_id from GRRGSTRNT where userid='"+userId+"') with ur";

		try {
			return DBUtil.executeQuerySingleResult(query);
		} catch (Exception e) {

			e.printStackTrace();
			return null;
		}
	}

	public static List<Map<String, String>> getAllGrDetails(String userId)
	{
		String sQuery ="select * from GRGFTREG where giftregistry_id in (select giftregistry_id from GRRGSTRNT where userid='"+userId+"') with ur";

		//System.out.println("getAllGrDetails.... "+sQuery);

		return DBUtil.executeQueryMultiRowMultiColumnMapLIST(sQuery) ;

	}

	/*
	public static Map<String, Map<String, String>> getAllGrDetails(List<String> grIds)
	{
		String sQuery ="select * from GRGFTREG where giftregistry_id in ("+grIds+") with ur";

		//System.out.println("getAllGrDetails.... "+sQuery);

		return DB2Utils.executeQueryMultiRowMultiColumnMap(sQuery,"giftregistry_id") ;

	}

	public static String getGiftregistry_id(String userid)
	{
		String query ="select giftregistry_id from GRRGSTRNT where userid='"+userid+"' with ur";  

		return DB2Utils.executeQuerySingleResult(query);
	}

	 */
}
