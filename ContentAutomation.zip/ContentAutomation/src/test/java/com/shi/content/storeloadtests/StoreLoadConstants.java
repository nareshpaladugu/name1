package com.shi.content.storeloadtests;

public class StoreLoadConstants {
	
	public static final double THREASHHOLD=0.1500;
	

}
