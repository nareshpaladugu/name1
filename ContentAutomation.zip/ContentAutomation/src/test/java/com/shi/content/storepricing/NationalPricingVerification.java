package com.shi.content.storepricing;

import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.content.Content;
import com.generated.vos.offer.Offer;
import com.google.gson.JsonObject;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;


public class NationalPricingVerification implements Runnable {

	static Map<String, Boolean> storeIds = new HashMap<String, Boolean>();
	String finalId=null;
	List<String> singlePricingBlob;
	int currentCount;
	
	public NationalPricingVerification(List<String> pricingDataForProduct, int currentC){
		this.singlePricingBlob = pricingDataForProduct;
		this.currentCount = currentC;
	}
	


	public void run() {
		long l1 = System.currentTimeMillis();
        CompareValuesUtility.init();
		// Fill code here
     
        List<PriceDetailVO> lstParentData = new ArrayList<PriceDetailVO>();
        String[] singlePriceData = singlePricingBlob.get(0).split("\\|");
        String mainId = singlePriceData[0] + singlePriceData[1];
        List<String> divPricingBlob=new ArrayList<String>();
		List<String> skuPricingBlob=new ArrayList<String>();
		ShcPricing storePricingGB;
		Content contentPartGB =null;
		Offer offerPartGB=null;
		
		for (String s : singlePricingBlob) {
			String[] afterSplit = s.split("\\|");
			String storeId=afterSplit[0];
			String productId=afterSplit[1];
		
				if (!validateStore(storeId)) // //check if store exists in store collection
					return; 
			    else{
						 if (productId.substring(8, 11).equals("000")) {
							 divPricingBlob.add(s) ;
						 }else{
							 skuPricingBlob.add(s);
						 }
					 }
		}
				if(divPricingBlob!=null && !(divPricingBlob.isEmpty())){
					
					for(String div :divPricingBlob ){
						
						String[] afterSplit1 = div.split("\\|");
						String divstoreId=afterSplit1[0];
						String divproductId=afterSplit1[1];
						String partId = divproductId.substring(0, 8);
						String divChk = "divitem";
						String id1 = divstoreId + "-" + partId;
						List<String> divtemList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,divChk,partId);
						if(divtemList.isEmpty()){
							CompareValuesUtility.logFailed("Comments","","No item Found in Offer");	
						}else{
							//String product = divtemList.get(0); 
							String product = divtemList.get(divtemList.size() - 1);
							offerPartGB = RestExecutor.getDataById(CollectionValuesVal.OFFER,product);	
							URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING,id1);
							URI offerURI = RestAPIs.getByIdURI(LoadProperties.GREENVIP, CollectionValuesVal.OFFER,product); 
							APIResponse<Offer> fullResponse= RestExecutor.getEntireResponseAsObject(offerURI, CollectionValuesVal.OFFER,Offer.class);
							 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
							if(offerPartGB!=null){
								 String parentPartNo = offerPartGB.getIdentity().getParentId();
								 contentPartGB = RestExecutor.getDataById(CollectionValuesVal.CONTENT,parentPartNo);
							}
						 if(offerPartGB==null || contentPartGB==null){
							 CompareValuesUtility.logPassed("Comments","","No item Found in Offer/Content");	
							return;
						 }else{
							 if(fullResponse != null){
									JsonObject obj2 = fullResponse.getSearchFields();
									if(obj2 != null && obj2.has("divitem")) { 
										 CompareValuesUtility.logPassed("divitem",obj2.get("divitem").toString(),obj2.get("divitem").toString());	
									}
								}
							 if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null){
								 CompareValuesUtility.logPassed("FFMChannel",offerPartGB.getFfm().getChannel().toString(),offerPartGB.getFfm().getChannel().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("FFMChannel","","Not Present"); 
							 }
							 if(offerPartGB.getReplenishment()!=null && offerPartGB.getReplenishment().getInternalRimSts()!=null){
								 CompareValuesUtility.logPassed("InternalRimSts",offerPartGB.getReplenishment().getInternalRimSts().toString(),offerPartGB.getReplenishment().getInternalRimSts().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("InternalRimSts","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()!=null){
								 CompareValuesUtility.logPassed("IsPrcAlrtExcln",offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln().toString(),offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsPrcAlrtExcln","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null){
								 CompareValuesUtility.logPassed("IsExcptVal",offerPartGB.getPriceDispAttr().getIsExcptVal().toString(),offerPartGB.getPriceDispAttr().getIsExcptVal().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsExcptVal","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsAvail()!=null){
								 CompareValuesUtility.logPassed("IsAvail",offerPartGB.getOperational().getSites().getSears().getIsAvail().toString(),offerPartGB.getOperational().getSites().getSears().getIsAvail().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsAvail","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsOnline()!=null){
								 CompareValuesUtility.logPassed("IsOnline",offerPartGB.getOperational().getSites().getSears().getIsOnline().toString(),offerPartGB.getOperational().getSites().getSears().getIsOnline().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsOnline","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsDispElig()!=null){
								 CompareValuesUtility.logPassed("IsDispElig",offerPartGB.getOperational().getSites().getSears().getIsDispElig().toString(),offerPartGB.getOperational().getSites().getSears().getIsDispElig().toString());	 	 
							 }else{
								 CompareValuesUtility.logPassed("IsDispElig","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapThrshld() !=null){
								 CompareValuesUtility.logPassed("MapThrshld",offerPartGB.getPriceDispAttr().getMapThrshld().toString(),offerPartGB.getPriceDispAttr().getMapThrshld().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapThrshld","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapVal() !=null){
								 CompareValuesUtility.logPassed("MapVal",offerPartGB.getPriceDispAttr().getMapVal().toString(),offerPartGB.getPriceDispAttr().getMapVal().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapVal","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapValMode() !=null){
								 CompareValuesUtility.logPassed("MapValMode",offerPartGB.getPriceDispAttr().getMapValMode().toString(),offerPartGB.getPriceDispAttr().getMapValMode().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapValMode","","Not Present"); 
							 }
							 if(storePricingGB!=null){
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
						 					CompareValuesUtility.logPassed("X Price", storePricingGB.getP().getX().get(k).getIp().toString(), storePricingGB.getP().getX().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("X StartDate", storePricingGB.getP().getX().get(k).getSt().toString(), storePricingGB.getP().getX().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("X EndDate",storePricingGB.getP().getX().get(k).getEt().toString(),storePricingGB.getP().getX().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("X Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("X StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("X EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null && storePricingGB.getP().getR().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
						 					CompareValuesUtility.logPassed("R Price", storePricingGB.getP().getR().get(k).getIp().toString(), storePricingGB.getP().getR().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("R StartDate", storePricingGB.getP().getR().get(k).getSt().toString(), storePricingGB.getP().getR().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("R EndDate",storePricingGB.getP().getR().get(k).getEt().toString(),storePricingGB.getP().getR().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("R Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("R StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("R EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
						 					CompareValuesUtility.logPassed("P Price", storePricingGB.getP().getS().get(k).getIp().toString(), storePricingGB.getP().getS().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("P StartDate", storePricingGB.getP().getS().get(k).getSt().toString(), storePricingGB.getP().getS().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("P EndDate",storePricingGB.getP().getS().get(k).getEt().toString(),storePricingGB.getP().getS().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("P Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("P StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("P EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getMpf()!=null){
									 CompareValuesUtility.logPassed("MPFValue", storePricingGB.getMpf().getMp().toString(),storePricingGB.getMpf().getMp().toString());
									 if(storePricingGB.getMpf().getSt()!=null){
									 CompareValuesUtility.logPassed("MPFStartDate", storePricingGB.getMpf().getSt().toString(),storePricingGB.getMpf().getSt().toString());
									 }else{
										 CompareValuesUtility.logPassed("MPFStartDate","","Not Present"); 
									 }
									 if(storePricingGB.getMpf().getEt()!=null){
									 CompareValuesUtility.logPassed("MPFEndDate", storePricingGB.getMpf().getEt().toString(),storePricingGB.getMpf().getEt().toString());	 
									 }else{
										 CompareValuesUtility.logPassed("MPFEndDate","","Not Present"); 
									 }
									 
								 }else{
				 					 CompareValuesUtility.logPassed("MPFValue","","Not Present"); 
				 					 CompareValuesUtility.logPassed("MPFStartDate","","Not Present"); 
				 					 CompareValuesUtility.logPassed("MPFEndDate","","Not Present"); 
				 				}
								 
								 if(storePricingGB.getDp()!=null && storePricingGB.getDp().getS()!=null){
									 if(storePricingGB.getDp().getS().get(0).getSt()!=null){
										 CompareValuesUtility.logPassed("DP StartDate", storePricingGB.getDp().getS().get(0).getSt(), storePricingGB.getDp().getS().get(0).getSt()); 
									 }else{
										 CompareValuesUtility.logPassed("DP StartDate","","Not Present");  
									 }
									 if(storePricingGB.getDp().getS().get(0).getIp()!=null){
										 CompareValuesUtility.logPassed("DP Price", storePricingGB.getDp().getS().get(0).getIp(), storePricingGB.getDp().getS().get(0).getIp()); 
									 }else{
										 CompareValuesUtility.logPassed("DP Price","","Not Present");  
									 }
									 if(storePricingGB.getDp().getS().get(0).getEt()!=null){
										 CompareValuesUtility.logPassed("DP EndDate", storePricingGB.getDp().getS().get(0).getEt(), storePricingGB.getDp().getS().get(0).getEt()); 
									 }else{
										 CompareValuesUtility.logPassed("DP EndDate","","Not Present");  
									 }
								 }
								 if(storePricingGB.getDp()!=null){
									 if(storePricingGB.getDp().getOi()!=null){
										 CompareValuesUtility.logPassed("Oi",storePricingGB.getDp().getOi(), storePricingGB.getDp().getOi()); 
									 }else{
										 CompareValuesUtility.logPassed("Oi","","Not Present");  
									 } 
									 if(storePricingGB.getDp().getAdv()!=null){
										 CompareValuesUtility.logPassed("Adv",storePricingGB.getDp().getAdv(), storePricingGB.getDp().getAdv()); 
									 }else{
										 CompareValuesUtility.logPassed("Adv","","Not Present");  
									 }
								 }
								 /*if(storePricingGB.getCp()!=null && storePricingGB.getCp().size()!=0){
									 for (int k = 0; k < storePricingGB.getCp().size(); k++) { 
										 CompareValuesUtility.logPassed("Ap", "", storePricingGB.getCp().get(k).getAp().toString());
										 CompareValuesUtility.logPassed("Vn", "", storePricingGB.getCp().get(k).getVn().toString());
									 }
								 }else{
				 					 CompareValuesUtility.logPassed("Ap","","Not Present"); 
				 					 CompareValuesUtility.logPassed("Vn","","Not Present"); 
								 }*/
							 }else{
								 CompareValuesUtility.logPassed("X Price","","Not Item Found in SHC pricing");  
							 }
				}
						}
					}
				}
                if(skuPricingBlob!=null && !(skuPricingBlob.isEmpty())){
					
					for(String sku :skuPricingBlob ){
						
						String[] afterSplit1 = sku.split("\\|");
						String divstoreId=afterSplit1[0];
						String divproductId=afterSplit1[1];
						String id1 = divstoreId + "-" + divproductId;
							offerPartGB = RestExecutor.getDataById(CollectionValuesVal.OFFER, divproductId);	
							URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, id1);
							URI offerURI = RestAPIs.getByIdURI(LoadProperties.GREENVIP, CollectionValuesVal.OFFER, divproductId); 
							APIResponse<Offer> fullResponse= RestExecutor.getEntireResponseAsObject(offerURI, CollectionValuesVal.OFFER,Offer.class);
							 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
							if(offerPartGB!=null){
								 String parentPartNo = offerPartGB.getIdentity().getParentId();
								 contentPartGB = RestExecutor.getDataById(CollectionValuesVal.CONTENT, parentPartNo);
							}
						 if(offerPartGB==null || contentPartGB==null){
							 CompareValuesUtility.logPassed("Comments","","No item Found in Offer/Content");	
							return;
						 }else{
							 if(fullResponse != null){
								 JsonObject obj2 = fullResponse.getSearchFields();
									if(obj2 != null && obj2.has("divitem")) { 
										 CompareValuesUtility.logPassed("divitem",obj2.get("divitem").toString(),obj2.get("divitem").toString());	
									}
								}
							 if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null){
								 CompareValuesUtility.logPassed("FFMChannel",offerPartGB.getFfm().getChannel().toString(),offerPartGB.getFfm().getChannel().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("FFMChannel","","Not Present"); 
							 }
							 if(offerPartGB.getReplenishment()!=null && offerPartGB.getReplenishment().getInternalRimSts()!=null){
								 CompareValuesUtility.logPassed("InternalRimSts",offerPartGB.getReplenishment().getInternalRimSts().toString(),offerPartGB.getReplenishment().getInternalRimSts().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("InternalRimSts","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()!=null){
								 CompareValuesUtility.logPassed("IsPrcAlrtExcln",offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln().toString(),offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsPrcAlrtExcln","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null){
								 CompareValuesUtility.logPassed("IsExcptVal",offerPartGB.getPriceDispAttr().getIsExcptVal().toString(),offerPartGB.getPriceDispAttr().getIsExcptVal().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsExcptVal","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsAvail()!=null){
								 CompareValuesUtility.logPassed("IsAvail",offerPartGB.getOperational().getSites().getSears().getIsAvail().toString(),offerPartGB.getOperational().getSites().getSears().getIsAvail().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsAvail","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsOnline()!=null){
								 CompareValuesUtility.logPassed("IsOnline",offerPartGB.getOperational().getSites().getSears().getIsOnline().toString(),offerPartGB.getOperational().getSites().getSears().getIsOnline().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("IsOnline","","Not Present"); 
							 }
							 if(offerPartGB.getOperational()!=null && offerPartGB.getOperational().getSites()!=null && offerPartGB.getOperational().getSites().getSears()!=null && offerPartGB.getOperational().getSites().getSears().getIsDispElig()!=null){
								 CompareValuesUtility.logPassed("IsDispElig",offerPartGB.getOperational().getSites().getSears().getIsDispElig().toString(),offerPartGB.getOperational().getSites().getSears().getIsDispElig().toString());	 	 
							 }else{
								 CompareValuesUtility.logPassed("IsDispElig","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapThrshld() !=null){
								 CompareValuesUtility.logPassed("MapThrshld",offerPartGB.getPriceDispAttr().getMapThrshld().toString(),offerPartGB.getPriceDispAttr().getMapThrshld().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapThrshld","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapVal() !=null){
								 CompareValuesUtility.logPassed("MapVal",offerPartGB.getPriceDispAttr().getMapVal().toString(),offerPartGB.getPriceDispAttr().getMapVal().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapVal","","Not Present"); 
							 }
							 if(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getMapValMode() !=null){
								 CompareValuesUtility.logPassed("MapValMode",offerPartGB.getPriceDispAttr().getMapValMode().toString(),offerPartGB.getPriceDispAttr().getMapValMode().toString());	 
							 }else{
								 CompareValuesUtility.logPassed("MapValMode","","Not Present"); 
							 }
							 if(storePricingGB!=null){
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
						 					CompareValuesUtility.logPassed("X Price",storePricingGB.getP().getX().get(k).getIp().toString(), storePricingGB.getP().getX().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("X StartDate",storePricingGB.getP().getX().get(k).getSt().toString(), storePricingGB.getP().getX().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("X EndDate",storePricingGB.getP().getX().get(k).getEt().toString(),storePricingGB.getP().getX().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("X Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("X StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("X EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null && storePricingGB.getP().getR().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
						 					CompareValuesUtility.logPassed("R Price",storePricingGB.getP().getR().get(k).getIp().toString(), storePricingGB.getP().getR().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("R StartDate", storePricingGB.getP().getR().get(k).getSt().toString(), storePricingGB.getP().getR().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("R EndDate",storePricingGB.getP().getR().get(k).getEt().toString(),storePricingGB.getP().getR().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("R Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("R StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("R EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
						 					CompareValuesUtility.logPassed("P Price",storePricingGB.getP().getS().get(k).getIp().toString(), storePricingGB.getP().getS().get(k).getIp().toString());
						 					CompareValuesUtility.logPassed("P StartDate",storePricingGB.getP().getS().get(k).getSt().toString(), storePricingGB.getP().getS().get(k).getSt().toString());
						 					CompareValuesUtility.logPassed("P EndDate",storePricingGB.getP().getS().get(k).getEt().toString(),storePricingGB.getP().getS().get(k).getEt().toString());
						 					
						 					}
						 				}else{
						 					 CompareValuesUtility.logPassed("P Price","","Not Present"); 
						 					 CompareValuesUtility.logPassed("P StartDate","","Not Present"); 
						 					 CompareValuesUtility.logPassed("P EndDate","","Not Present"); 
						 				}
								 if(storePricingGB.getMpf()!=null){
									 CompareValuesUtility.logPassed("MPFValue",storePricingGB.getMpf().getMp().toString(),storePricingGB.getMpf().getMp().toString());
									 if(storePricingGB.getMpf().getSt()!=null){
									 CompareValuesUtility.logPassed("MPFStartDate",storePricingGB.getMpf().getSt().toString(),storePricingGB.getMpf().getSt().toString());
									 }else{
										 CompareValuesUtility.logPassed("MPFStartDate","","Not Present"); 
									 }
									 if(storePricingGB.getMpf().getEt()!=null){
									 CompareValuesUtility.logPassed("MPFEndDate",storePricingGB.getMpf().getEt().toString(),storePricingGB.getMpf().getEt().toString());	 
									 }else{
										 CompareValuesUtility.logPassed("MPFEndDate","","Not Present"); 
									 }
									 
								 }else{
				 					 CompareValuesUtility.logPassed("MPFValue","","Not Present"); 
				 					 CompareValuesUtility.logPassed("MPFStartDate","","Not Present"); 
				 					 CompareValuesUtility.logPassed("MPFEndDate","","Not Present"); 
				 				}
								 if(storePricingGB.getDp()!=null && storePricingGB.getDp().getS()!=null){
									 if(storePricingGB.getDp().getS().get(0).getSt()!=null){
										 CompareValuesUtility.logPassed("DP StartDate",storePricingGB.getDp().getS().get(0).getSt(), storePricingGB.getDp().getS().get(0).getSt()); 
									 }else{
										 CompareValuesUtility.logPassed("DP StartDate","","Not Present");  
									 }
									 if(storePricingGB.getDp().getS().get(0).getIp()!=null){
										 CompareValuesUtility.logPassed("DP Price", storePricingGB.getDp().getS().get(0).getIp(), storePricingGB.getDp().getS().get(0).getIp()); 
									 }else{
										 CompareValuesUtility.logPassed("DP Price","","Not Present");  
									 }
									 if(storePricingGB.getDp().getS().get(0).getEt()!=null){
										 CompareValuesUtility.logPassed("DP EndDate",storePricingGB.getDp().getS().get(0).getEt(), storePricingGB.getDp().getS().get(0).getEt()); 
									 }else{
										 CompareValuesUtility.logPassed("DP EndDate","","Not Present");  
									 }
								 }
								 if(storePricingGB.getDp()!=null){
									 if(storePricingGB.getDp().getOi()!=null){
										 CompareValuesUtility.logPassed("Oi",storePricingGB.getDp().getOi(), storePricingGB.getDp().getOi()); 
									 }else{
										 CompareValuesUtility.logPassed("Oi","","Not Present");  
									 } 
									 if(storePricingGB.getDp().getAdv()!=null){
										 CompareValuesUtility.logPassed("Adv",storePricingGB.getDp().getAdv(), storePricingGB.getDp().getAdv()); 
									 }else{
										 CompareValuesUtility.logPassed("Adv","","Not Present");  
									 }
								 }
								 /*if(storePricingGB.getCp()!=null && storePricingGB.getCp().size()!=0){
									 for (int k = 0; k < storePricingGB.getCp().size(); k++) { 
										 CompareValuesUtility.logPassed("Ap", "", storePricingGB.getCp().get(k).getAp().toString());
										 CompareValuesUtility.logPassed("Vn", "", storePricingGB.getCp().get(k).getVn().toString());
									 }
								 }else{
				 					 CompareValuesUtility.logPassed("Ap","","Not Present"); 
				 					 CompareValuesUtility.logPassed("Vn","","Not Present"); 
								 }*/
							 }else{
								 CompareValuesUtility.logPassed("X Price","","Not Item Found in SHC pricing");  
							 }
				}
						
					}
				}
						 CompareValuesUtility.setupResult(mainId, true);
							CompareValuesUtility.teardown();
								
	}


	
	
	/**
	 * Marks price data as failed
	 * @param priceType
	 * @param startDate
	 * @param endDate
	 * @param price
	 */
	private void logPriceFailed(String priceType, String startDate, String endDate, String price){
		CompareValuesUtility.logFailed("PriceType", priceType, "Not found");
		CompareValuesUtility.logFailed("StartDate", startDate,"Not found");
		CompareValuesUtility.logFailed("EndDate", endDate, "Not found");
		CompareValuesUtility.logFailed("Price",price,"price not found in GB");
	}

	public boolean compareDates(String a, String b) { // method to check if date
														// is valid or not
		
		Date d = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date c1 = sf.parse(sf.format(d)); // /to get current date

			Date b1 = sf.parse(b);

			if (b1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
																// dates in the
																// input file
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
		
	}

	/**
	 * validates if store exists in store collection and adds the store to map
	 * if exists with value as true
	 * 
	 * @param stor
	 * @return
	 */
	public boolean validateStore(String stor) {
		if (storeIds.containsKey(stor)) {
			return  storeIds.get(stor);
		} else {

			String com = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, stor);
			if (com != "[]" || com != null) {
				storeIds.put(stor, true);
				return true;
			} else {
				storeIds.put(stor, false);
				return false;
			}
		}

	}
	
	
	class PriceDetailVO{
		String type, price, startDate, endDate;
		public PriceDetailVO(String type, String startDate, String endDate, String price) {
			
			this.type = type;
			this.price = price;
			this.startDate = startDate;
			this.endDate = endDate;
			
		}
	}

		
	
	


}
