package com.shi.content.acme.threezero;

import com.shc.autocontent.LoadProperties;


/**
 * @author ddaphal
 *
 */
public class KafkaPush implements Runnable 
{

	String msg;

	public KafkaPush(String msg)
	{
		this.msg=msg;
	}

	public void run() 
	{
		System.out.println("Pushing to kafka qa queue :  "+LoadProperties.KAFKATOPIC2);

		String param[]={LoadProperties.ZOOKEEPER2,LoadProperties.KAFKABROKER2,LoadProperties.KAFKATOPIC2,msg};

		com.shi.content.matching.KafkaProducer.publish(param);
	}
}