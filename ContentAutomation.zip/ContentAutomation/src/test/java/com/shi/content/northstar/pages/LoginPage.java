package com.shi.content.northstar.pages;

import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.TextField;

public class LoginPage extends BasePage{

	
	TextField txtUserName = new TextField("frm-login:txt-uname", "Username");
	TextField txtUserPassword = new TextField("frm-login:txt-pword", "Password");
	Button btnLogin = new Button("frm-login:btn-login", "Login button");
	
	public LoginPage(String pageName) {
		super(pageName);
	}
	
	public void login(String userName, String password){
		txtUserName.sendKeys(userName);
		txtUserPassword.sendKeys(password);
		btnLogin.click();
	}
	
	

}
