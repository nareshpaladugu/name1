package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.utils.URIBuilder;

import com.generated.vos.hierarchy.Path;
import com.generated.vos.offer.AltIds;
import com.generated.vos.offer.DispTags;
import com.generated.vos.offer.Ffm;
import com.generated.vos.offer.Grocery;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.PriceDispAttr;
import com.generated.vos.offer.Replenishment;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.types.ChokingHazardType;
//import com.generated.vos.productoffering.types.UpcTypeType;
import com.generated.xmls.serviceofferings.ProductContent;
import com.generated.xmls.serviceofferings.ProductOffer;
import com.generated.xmls.serviceofferings.SingleServiceProductOffer;
import com.generated.xmls.serviceofferings.Site;
import com.generated.xmls.serviceofferings.types.UpcTypeType;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.tests.HomeService_OfferLoadTest;

public class HomeService_OfferVerifications implements Runnable
{
	SingleServiceProductOffer singleProductOffer;

	ProductContent prodContent;
	ProductOffer prodOffer;
	SHCContentCommons commonUtils;
	private String parentId;
	String siteToTest, partNumberToTest;
	List<String> errorPartNumbers;
	String upcToCheck = null;

	public HomeService_OfferVerifications(SingleServiceProductOffer wNodeListToTest,
			SHCContentCommons commonUtils, String sSite,
			List<String> erroredPartNumbers) {
		this.singleProductOffer = wNodeListToTest;
		this.commonUtils = commonUtils;
		this.siteToTest = sSite;
		this.errorPartNumbers = erroredPartNumbers;
	}

	@Override
	public void run() {

		this.getContentToTest();

		APIResponse<Offer> allResponse;

		if (partNumberToTest == null)
		{
			System.out.println("Skipping as partNumber in xml does not exist: " + partNumberToTest);
		}
		else if (errorPartNumbers.contains(partNumberToTest)
				|| errorPartNumbers.contains(parentId)) {
			System.out.println("Part number is prestent in the list of Error Part Numbers so skipping  " + partNumberToTest);
		}
		else{
			allResponse = RestExecutor.getAllDataById(
					CollectionValuesVal.OFFER, partNumberToTest);
			callVerifs(prodOffer, allResponse, partNumberToTest);
		}
	}

	private void callVerifs(ProductOffer xmlProductOffer, APIResponse<Offer> allResponse, String offerId) {
		try {
			CompareValuesUtility.init();
			Offer gbOffer = (Offer) allResponse.getT();

			if (gbOffer == null) {
				CompareValuesUtility.logFailed("Id", offerId, " Not found");
				CompareValuesUtility.setupResult(offerId, true);
				return;
			}

			verifyOffer(xmlProductOffer, gbOffer, allResponse, offerId, siteToTest);

			verifySearch(xmlProductOffer, allResponse);

			CompareValuesUtility.setupResult(offerId, true);

		} catch (Throwable e) {
			System.out.println("Check this id :" + offerId);
			e.printStackTrace();
		} finally {
			CompareValuesUtility.teardown();
		}
	}

	private void getContentToTest() {

		partNumberToTest = singleProductOffer.getProductOfferings() == null ? null :
			singleProductOffer.getProductOfferings().getProductOffer() == null ? null :
				singleProductOffer.getProductOfferings().getProductOffer().getPartNumber() == null ? null :
					singleProductOffer.getProductOfferings().getProductOffer().getPartNumber().getSearsPartNumber() == null ? null :
						singleProductOffer.getProductOfferings().getProductOffer().getPartNumber().getSearsPartNumber().substring(0, 8).concat("292");

		parentId = partNumberToTest + "P";

		prodContent = singleProductOffer.getProductContent();

		prodOffer = singleProductOffer.getProductOfferings() ==null ? null :
			singleProductOffer.getProductOfferings().getProductOffer();
	}

	OfferCommons offerCommon;

	private void verifyOffer(ProductOffer xmlProductOffer, Offer gbOffer, APIResponse<Offer> allResponse, String sOfferId, String site)
	{

		//System.out.println("Testing offer id: " + sOfferId + " : " + Thread.currentThread().getName());

		offerCommon = new OfferCommons(gbOffer);


		//*****Id, name, parentId*****
		offerCommon.commonVerifications(sOfferId, parentId, prodContent.getName(), false);


		//*****ssin, uid*****
		if(HomeService_OfferLoadTest.checkSSINAndUID)
		{
			CompareValuesUtility.verifyNullOrEqual("_search", xmlProductOffer.getSsin(), xmlProductOffer.getSsin() == null ? null
					: allResponse.getSearchFieldValue("ssin"), "SSIN");
			CompareValuesUtility.verifyNullOrEqual("_search", xmlProductOffer.getGuid(), xmlProductOffer.getGuid() == null ? null
					: allResponse.getSearchFieldValue("uid"), "UID");
		}


		//*****brand, modelNo*****
		offerCommon.verifyBrandModel(prodContent.getBrand() == null ? null : prodContent.getBrand().getName(), prodContent.getManufacturerModelNumber());


		//*****offerType*****
		String xmlOfferType = "HS";
		String gbOfferType = gbOffer.getClassifications().getOfferType().toString();
		CompareValuesUtility.verifyNullOrEqual("OfferType", xmlOfferType, gbOfferType);


		//*****sites*****
		verifySites(prodContent, gbOffer.getSites());


		//*****altIds*****
		verifyAltIds(xmlProductOffer, gbOffer.getAltIds());


		//*****mainImg*****
		//		verifyImages(xmlProductOffer, gbOffer.getMainImg(), gbOffer.getSwatchImg());


		//*****alternateImg*****
		CompareValuesUtility.verifyNull("AlternateImg", gbOffer.getAlternateImg().isEmpty()?null:"AltImg found in GB");


		//shipping
		verifyShipping(xmlProductOffer.getShipDimension(), gbOffer);


		//*****ffm*****
		verifyFFM(xmlProductOffer, gbOffer.getFfm(), site);


		//*****isRgnPriceElig*****
		try {
			if (site.equalsIgnoreCase("sears")) {
				verifyIsRgnEligible(gbOffer);
			}
		} catch (Exception e) {

			System.out.println("Exception .. for IsRgnEligible .. "+e.getMessage());
		}


		//*****store taxonomy*****
		verifyStoreTaxonomy(xmlProductOffer, gbOffer.getTaxonomy().getStore().getHierarchy());


		//*****master taxonomy*****
		verifyTaxonomy(gbOffer);


		//*****legal*****
		Gson gson = new Gson();
		String json = gson.toJson(gbOffer);

		Legal legalTagGb = null;
		if(json.contains("\"legal\":{\"chokingHazards\":[]}"))
		{
			legalTagGb = null;
		}
		else
		{
			legalTagGb = gbOffer.getLegal();
		}

		verifyLegal(xmlProductOffer, legalTagGb);

		CompareValuesUtility.addNewMultiValuedFields();


		//*****isPerishable*****
		Grocery grocery = gbOffer.getGrocery();
		CompareValuesUtility.verifyNullOrTrue("Grocery", xmlProductOffer.getImaAttributes().getPerishableCode(),
				grocery==null?null:grocery.getIsPerishable(), "IsPerishable");


		//*****dispTags*****
		DispTags dis = gbOffer.getDispTags();
		compareValues("DispTags",
				checkInAttributeGroup("Good Housekeeping - Seal of Approval"),
				dis == null ? null : dis.getIsGhkApproved(), false, true, "GHK");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getViewOnlyCode(), dis == null ? null : dis.getViewOnly(),
						false, true, "ViewOnly");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getSearsExclusive(),
				dis == null ? null : dis.getIsSearsExclusive(), false, true,
				"SearsExcl");
		compareValues("DispTags", true,
				dis == null ? null : dis.getIsSearchSupression(), false, true,
				"SearchSupp");

		checkFlagsFromAttribs(gbOffer.getDispTags(),
				gbOffer.getPriceDispAttr());


		//*****_blob.offer.matchData.upc*****
		CompareValuesUtility.verifyNullOrEqual("matchData.Upc", prodOffer.getUpc(), gbOffer.getMatchData() == null ? null : gbOffer.getMatchData().getUpc());


		//		//*****_blob.offer.matchData.mfg*****
		//		CompareValuesUtility.verifyNullOrEqual("mfg", prodOffer.getCoreItemNumber(), gbOffer.getMatchData() == null ? null : gbOffer.getMatchData().getModelNo());


		//*****_blob.offer.modelNo*****
		//		CompareValuesUtility.verifyNullOrEqual("modelNo", prodOffer.getCoreItemNumber(), gbOffer.getModelNo());


		//*****replenishment*****
		verifyReplenishment(xmlProductOffer, gbOffer.getReplenishment());


		//*****desc*****
		String xmlDesc = prodContent.getMarketingDescription() == null ? null : TestUtils.cleanDesc(prodContent.getMarketingDescription());
		String gbDesc = gbOffer.getDesc() == null ? null : TestUtils.cleanDesc(gbOffer.getDesc());
		CompareValuesUtility.verifyNullOrEqual("Desc", xmlDesc, gbDesc);
	}


	private Boolean checkInAttributeGroup(String attrToCheck) {
		if (prodContent.getGlobalAttributes() != null) {
			for (com.generated.xmls.serviceofferings.types.GlobalAttributeType attGroup : prodContent
					.getGlobalAttributes().getAttribute()) {
				if (attGroup.value().equals(attrToCheck))
				{
					return true;
				}

			}
			return false;
		} else
		{
			return null;
		}

	}

	private void checkFlagsFromAttribs(DispTags dispTags,
			PriceDispAttr priceDispAttr) {

		if (prodContent.getProductAttributes() == null)
		{
			return;
		}
		for (com.generated.xmls.serviceofferings.ProductAttribute attrib : prodContent.getProductAttributes()
				.getProductAttribute()) {
			switch (String.valueOf(attrib.getAttributeId())) {
			case "499910": {
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19))
				{
					compareValues("DispTags", true, dispTags == null ? null: dispTags.getIsConfigureTech(), "isConfigureTech:");
				}
				break;

			}
			case "848810": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("PriceDispHotBuy",true,priceDispAttr == null ? null : priceDispAttr.getIsHotBuy());
				}
				break;
			}
			case "848610": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues(
							"PriceDispUpp",
							true,
							priceDispAttr == null ? null : priceDispAttr
									.getIsUPP());
				}
				break;
			}
			case "1774": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEnergyStar(), "isEnergyStar");
				}
				break;
			}
			case "1130610": {
				// CompareValuesUtility.addNewMultiValuedFields();

				String response = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE,"1130610");


				//System.out.println("attr : "+response);
				//System.out.println("attr val : "+responseVal);
				if(!TestUtils.isEmptyJsonResponse(response) && OfferTestCache.checkAttrAssoc("1130610", "19"))
				{
					if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
						compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
					} else
					{
						CompareValuesUtility.verifyNull("DispTags", dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
					}
				}

				break;

			}
			//Added isDeliverySetupElig validation for Kmart on 12/18/2014
			case "886810": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (siteToTest.equalsIgnoreCase("kmart")) {
					if(attrib.getProductAttributeTypeChoice().getAttributeValueFlag() == true) {
						compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}else {
						CompareValuesUtility.verifyNullOrFalse("DispTags", false, dispTags == null ? null : dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}
				}
				break;
			}

			default: {

			}
			}
		}

	}

	private void verifyAltIds(ProductOffer xmlProductOffer, AltIds altIds) {

		verifyNullOrEqual("AltIds", xmlProductOffer.getSpinUniqueId(), altIds.getSpinId(), "SpinId");
		verifyNullOrEqual("AltIds", xmlProductOffer.getImaAttributes().getKsnId(), altIds.getKsn(), "Ksn");
		verifyNullOrEqual("AltIds", xmlProductOffer.getOfferingIndicatorsGroup()==null?null:xmlProductOffer.getOfferingIndicatorsGroup().getLinkedKsn(),
				altIds.getLinkedKsn(), "LinkedKsn");

		upcToCheck = xmlProductOffer.getUpc();
		if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_0.value())){
			upcToCheck = validateUPC(upcToCheck, 12);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_1.value())
				|| xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_2.value())){
			upcToCheck = validateUPC(upcToCheck, 8);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_3.value())){
			upcToCheck = validateUPC(upcToCheck, 13);
		}
		else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_7.value())){
			upcToCheck = validateUPC(upcToCheck, 14);
		}
		compareValues("AltIds", upcToCheck, altIds.getUpc(), "Upc");
		compareValues("AltIds", xmlProductOffer.getUpcType(), GenericUtil.convertToString(altIds.getUpcType()), "UpcType");

		//		for(com.generated.xmls.serviceofferings.VendorPack vendorPack : xmlProductOffer.getImaAttributes().getVendorPack()){
		//			if(vendorPack.getStoreName().equalsIgnoreCase(siteToTest)){
		//				verifyNullOrEqual("AltIds", vendorPack.getVendorStockNumber(), altIds.getVendorStockNo(), "VendorStockNo");
		//				break;
		//			}
		//		}
		verifyNullOrEqual("AltIds", GenericUtil.convertToString(xmlProductOffer.getImaAttributes().getImaItemId()),
				GenericUtil.convertToString(altIds.getImaItemId()), "ImaItemId");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private String validateUPC(String upc, int length){

		if(upc==null)
		{
			return null;
		}

		if(upc.length()>length)
		{
			StringBuffer buf = new StringBuffer(upc);
			upc = buf.reverse().toString();

			upc = upc.substring(0, length);

			StringBuffer buf2 = new StringBuffer(upc);

			return buf2.reverse().toString();
		}
		else
		{
			return StringUtils.leftPad(upc, length, "0");
		}
	}

	private void verifyFFM(ProductOffer xmlProductOffer, Ffm ffm, String site) {
		if (ffm == null) {
			logFailed("FFM", "sears", "No ffm tag found");
			return;
		}
		compareValues("FFM", site.substring(0, 1).toUpperCase() + site.substring(1), ffm.getSoldBy(), "SoldBy");
		String sFFMBy = site.substring(0, 1).toUpperCase() + site.substring(1);
		/*
		 * if(xmlProductOffer.getFulfillment().equals(FulfillmentType.FBM)){
		 * sFFMBy = "Sears Authorized Supplier"; compareValues("FFM", "VD",
		 * ffm.getChannel(),"Channel"); }else
		 * CompareValuesUtility.verifyNull("FFM",ffm.getChannel(),"Channel");
		 */

		if ((ffm.getChannel() != null) && ffm.getChannel().equals("VD")) {
			sFFMBy = "Sears Authorized Supplier";
		}
		compareValues("FFM", sFFMBy, ffm.getFulfilledBy(), "FulfilledBy");
		CompareValuesUtility.verifyNullOrEqual("FFM", xmlProductOffer.getOfferingIndicatorsGroup().isWebOnlyFlag() == false ? null : true,
				ffm.getIsWebExcl(), "isWebExcl");

		//		compareValues("FFM", bSingleProductOffer ? singleProductOffer.getProductContent().getVendorId().toString() : varProdOffer.getProductContent().getVendorId().toString(),
		//				ffm.getSpinVendorId(), "SpinVendorId");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifySites(ProductContent pContent, List<String> sites) {

		for(Site s : pContent.getSite()){

			if(siteToTest.equalsIgnoreCase("kmart") && ((s.getId()==11) || (s.getId()==6)))
			{
				System.out.println("ignore "+s.getId()+" site for Kmart ..."+partNumberToTest);
				continue;
			}

			if((s.getId() == 10) || (s.getId() == 13) || (s.getId() == 11))
			{
				continue;
			}
			if((siteToTest.equalsIgnoreCase("sears") && (s.getId() == 1)) || (siteToTest.equalsIgnoreCase("kmart") && (s.getId() == 2)))
			{
				continue;
			}
			CompareValuesUtility.verifyItemInList("Site", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyShipping(com.generated.xmls.serviceofferings.ShipDimension shipDimension, Offer gbOffer ) {

		String xmlHeight = shipDimension == null ? "0.0" : shipDimension.getHeight().toString();
		String gbHeight = gbOffer.getShipping().getDimensions().getHeight().toString();

		String xmlWidth = shipDimension == null ? "0.0" : shipDimension.getWidth().toString();
		String gbWidth = gbOffer.getShipping().getDimensions().getWidth().toString();

		String xmlLength = shipDimension == null ? "0.0" : shipDimension.getLength().toString();
		String gbLength = gbOffer.getShipping().getDimensions().getLength().toString();

		String xmlWeight = shipDimension == null ? "0.0" : shipDimension.getWeight().toString();
		String gbWeight = gbOffer.getShipping().getWeight().toString();

		CompareValuesUtility.verifyNullOrEqual("Shipping", xmlHeight, gbHeight,"Height");

		CompareValuesUtility.verifyNullOrEqual("Shipping", xmlWidth, gbWidth,"Width");

		CompareValuesUtility.verifyNullOrEqual("Shipping", xmlLength, gbLength,"Length");

		CompareValuesUtility.verifyNullOrEqual("Shipping", xmlWeight, gbWeight,"Weight");

		CompareValuesUtility.addNewMultiValuedFields();


	}

	private void verifyReplenishment(ProductOffer xmlProductOffer,
			Replenishment replenishment) {

		com.generated.xmls.serviceofferings.VendorPack vendorPToTest = null;
		for (com.generated.xmls.serviceofferings.VendorPack vPack : xmlProductOffer.getImaAttributes()
				.getVendorPack()) {
			if (vPack.getStoreName().equalsIgnoreCase(siteToTest)) {
				vendorPToTest = vPack;
				break;
			}
		}
		if (vendorPToTest != null) {
			// Cost will be updated by operational load - 7-30 changes
			// compareValues("Replenishment",
			// vendorPToTest.getCost(),replenishment.getUnitCost(),"Cost");
			compareValues(
					"Replenishment",
					vendorPToTest.getVendorPackId(),
					replenishment == null ? null : replenishment
							.getVendorPackId(), "VendorPackId");
			verifyNullOrEqual("Replenishment", vendorPToTest.getFlowType(),
					replenishment == null ? null : replenishment.getFlowType(),
					"FlowType");
		}
		verifyNullOrEqual("Replenishment",
				GenericUtil.convertToString(xmlProductOffer.getImaAttributes()
						.getCancarryGroup()), replenishment == null ? null
								: replenishment.getCanCarryGrp(), "CanCarryGrp");
		verifyNullOrEqual("Replenishment", xmlProductOffer.getImaAttributes()
				.getCountryOfOrigin(), replenishment == null ? null
						: replenishment.getCntryOfOrig(), "CntryOfOrig");
		// verifyNullOrEqual("RplnishPurchaseSet",
		// xmlProductOffer.getImaAttributes().getVendorPack()[0].getPurchaseStatus(),replenishment.getPurchaseSts());
		//commented by daffy - ECOM-361820
		/*for (VendorPack vp : xmlProductOffer.getImaAttributes().getVendorPack()) {
			if (vp.getStoreName().equalsIgnoreCase(siteToTest))
				verifyNullOrEqual(
						"replenishment.PurchaseStatus",
						vp.getPurchaseStatus(),
						replenishment == null ? null : replenishment
								.getPurchaseSts());
		}*/
		verifyNullOrEqual("Replenishment", xmlProductOffer.getImaAttributes().getRecallFlag(),
				replenishment==null?null:replenishment.getIsRecalled(), "IsRecalled");

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyIsRgnEligible(Offer gbOffer) {
		try {
			//			String s = "divitem";
			String partnumber=partNumberToTest.substring(0, 8);
			//List<String> divtemList = RestExecutor.getIdsByAltKey(CollectionValuesVal.RGNPRICING, s, partnumber);

			URIBuilder u = new URIBuilder("http://pricegbapi.prod.global.s.com:80/gbox/gb/s/data/get-by-alt-key/rgn_pricing?divitem="+partnumber);

			String singleJSonObject = RestExecutor.getJSonResponse(u.toString());

			List<String> divtemList = JSONParser.parseJSONToArray(singleJSonObject);

			verifyNullOrEqual("isRgnPriceElig", divtemList.isEmpty()?null:true,
					gbOffer.getPriceDispAttr()==null?null: gbOffer.getPriceDispAttr().getIsRgnpriceElig());
		} catch (URISyntaxException e) {
			System.out.println("Exception .. "+e.getMessage());
		}

	}

	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,List<Hierarchy> hierarchy)
	{

		long XMLHierarchyId;

		if (siteToTest.equalsIgnoreCase("sears")) {
			if (xmlProductOffer.getCoreHierarchyId() == null)
			{
				return;
			}
			XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();
		} else {
			if (xmlProductOffer.getShcHierarchyId() == null)
			{
				return;
			}
			XMLHierarchyId = xmlProductOffer.getShcHierarchyId();
		}

		List<String> lstPaths = new LinkedList<String>();
		List<String> lstids = new LinkedList<String>();
		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, XMLHierarchyId+"");

		String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");

		String idpath = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{path{idPath}}}}");

		name = name.replace("SRWI", "");
		name = name.replace("KWSC", "");

		lstPaths.addAll(Arrays.asList(name.split("-")));

		lstids.addAll(Arrays.asList(idpath.split("\\|")));

		if (lstPaths.isEmpty()) {
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId",
					"null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0,
					"StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (hierarchy.size() == 0) {
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		int iHierarchy = 0;

		for (Hierarchy hrchy_ : hierarchy)
		{
			compareValues("store-taxo-name", lstPaths.get(iHierarchy),hrchy_ == null ? null : hrchy_.getName());

			compareValues("store-taxo-id", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getId());

			compareValues("store-taxo-spinid", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getSpinId());

			iHierarchy++;
		}

		CompareValuesUtility.addNewMultiValuedFields();

	}


	private void verifyTaxonomy(Offer gbOffer) {

		String itemClassId = GenericUtil.convertToString(prodContent.getItemClassId());

		if (gbOffer.getTaxonomy() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"
					+ itemClassId, "Taxonomy is null");
			return;
		} else if (gbOffer.getTaxonomy().getMaster() == null) {
			CompareValuesUtility.logFailed("TaxonomyMaster", "Itemclassid:"
					+ itemClassId, "Taxonomy-master is null");
			return;
		}

		compareMasterhierarchyGB(Long.parseLong(itemClassId), gbOffer.getTaxonomy().getMaster().getHierarchy());

		boolean isCrossFormatted = this.isCrossFormattedItem( prodContent, siteToTest, singleProductOffer, null, true);

		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for (Site site : prodContent.getSite()) {

			long lSiteId = site.getId();
			if ((lSiteId > 11) || (lSiteId == 10))
			{
				continue;
			}
			String siteName = TestUtils.getSite(lSiteId);
			if ((siteToTest.equalsIgnoreCase("sears") && siteName.equalsIgnoreCase("kmart") && !isCrossFormatted)
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName.equalsIgnoreCase("sears") && !isCrossFormatted)) {
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for (com.generated.xmls.serviceofferings.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()) {
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		CompareValuesUtility.addNewMultiValuedFields();

		commonUtils.verifyMeetWExpert(siteToTest, mpSiteHiearachies, gbOffer.getDispTags());

	}

	public boolean isCrossFormattedItem(ProductContent pContent,String  sSiteToTest
			,	SingleServiceProductOffer singleProductOffer2,	VariationProductOffer varProdOffer,boolean bSingleProductOffer )
	{
		Site[] sites = pContent.getSite();

		boolean bSearsSitePresent = false;
		boolean bKmartSitePresent = false;

		for (Site site : sites)
		{
			int siteId = site.getId().intValue() ;

			if(siteId==1)
			{
				bKmartSitePresent = true;
			} else
				if(siteId==2)
				{
					bSearsSitePresent = true;
				}

		}

		String kmartPart = null;
		String searsPart = null;

		if(bSingleProductOffer)
		{
			kmartPart = singleProductOffer2.getProductOfferings().getProductOffer().getPartNumber().getKmartPartNumber();
			searsPart = singleProductOffer2.getProductOfferings().getProductOffer().getPartNumber().getSearsPartNumber();
		}
		else
		{
			kmartPart = varProdOffer.getProductOfferings().getProductOffer()[0].getPartNumber().getKmartPartNumber();
			searsPart = varProdOffer.getProductOfferings().getProductOffer()[0].getPartNumber().getSearsPartNumber();
		}

		if(sSiteToTest.equalsIgnoreCase("sears"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && ((kmartPart==null)||kmartPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && ((searsPart==null)||searsPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		return false;

	}

	public void compareMasterhierarchyGB(long l, List<com.generated.vos.content.Hierarchy> list)
	{

		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath =GreenBoxCache.getPathForItemClass(l+"");

		if(masterHierarchyPath == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "No hierarchy exists");
			return;
		}

		if(list == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master", hierarchyMap);

		compareValues("Master", masterHierarchyPath.getIdPath(),hierarchyMap.get("no-site-required-for-master").getLstIds().get(0),"IDPath");
		compareValues("Master", masterHierarchyPath.getDisplayPath(),hierarchyMap.get("no-site-required-for-master").getDisplayPaths().get(0),"DisplayPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private class HierarchyPathVo
	{
		private List<String> lstIds;
		private List<String> displayPaths;

		public List<String> getLstIds() {
			return lstIds;
		}
		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}
		public void setLstCIds(List<String> lstCIds) {
		}
		public List<String> getDisplayPaths() {
			return displayPaths;
		}
		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}


	}

	private String hierarchySeparator = "/";
	private void setGBHierarchySeparator(){
		this.hierarchySeparator = "|";
	}

	public void processMasterHierarchy(List<com.generated.vos.content.Hierarchy> list ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();
		List<String> lstCids  = new LinkedList<String>();

		String id=null, name=null,cid=null;

		for (com.generated.vos.content.Hierarchy hierarchy : list) {

			if(id==null)
			{
				id= GenericUtil.convertToString(hierarchy.getSpinId()); //replaced getId
			} else
			{
				id = id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());
			}

			if(name==null)
			{
				name=hierarchy.getName();
			} else
			{
				name = name+this.hierarchySeparator+hierarchy.getName();
			}

			if(cid==null)
			{
				cid=GenericUtil.convertToString(hierarchy.getSpinId());
			} else
			{
				cid = cid+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());
			}

		}

		/* ======  For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	//	private void verifyImages(ProductOffer xmlProductOffer,
	//			List<MainImg> mainImg, List<SwatchImg> lstSwatchImgs) {
	//		com.generated.xmls.serviceofferings.ImageUrl primImageURL = xmlProductOffer.getImageUrl();
	//
	//		if (primImageURL != null)
	//		{
	//			if (primImageURL.getImageElementsGroup() != null) {
	//				if (mainImg.size() == 0)
	//				{
	//					compareValues("PrimaryImage", primImageURL.getImageElementsGroup().getUrl(), "Not found");
	//				} else {
	//					compareValues("PrimaryImage", TestUtils.modifyURL(primImageURL.getImageElementsGroup().getUrl()), mainImg.get(0)
	//							.getSrc(), "Src");
	//					CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getName(), mainImg.get(0).getTitle(), "Title");
	//					CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getHeight(),GenericUtil.convertToIntFromDouble(mainImg.get(0)
	//							.getHeight()), "Height");
	//					CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getWidth(),
	//							GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()), "Width");
	//					CompareValuesUtility.addNewMultiValuedFields();
	//				}
	//			}
	//		}
	//	}

	private void verifyLegal(ProductOffer xmlProductOffer, Legal legal) {

		String jewelry_disclosure_52="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care";

		String jewelry_disclosure_53="Diamond weights may not be exact, but are never more than .05 carats below the stated weight";

		String jewelry_disclosure_84="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight";


		boolean bDisclosurePresent = false;

		Integer dicValueId = null;

		if((prodContent.getProductAttributes()!=null) && (prodContent.getProductAttributes().getProductAttribute()!=null))
		{
			com.generated.xmls.serviceofferings.ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();
			for (com.generated.xmls.serviceofferings.ProductAttribute productAttribute : attrs) {

				if(productAttribute.getAttributeId().intValue()==30201)
				{
					bDisclosurePresent = true;
					dicValueId = productAttribute.getProductAttributeTypeChoice().getAttributeValueId().intValue();
					break;
				}
			}
		}

		if (  !bDisclosurePresent && (xmlProductOffer.getImaAttributes().getHazardMaterialCode() == null)
				&& (xmlProductOffer.getImaAttributes().getHazardStorageCode() == null)
				&& (checkInAttributeGroup("California Emission Compliant") == null)
				&& ((xmlProductOffer.getImaAttributes().getProp65Flag() == false) || (xmlProductOffer
						.getImaAttributes().getProp65Flag() == null))
						//&& xmlProductOffer.getGeoLimiters() == null
						&& ((prodContent.getGlobalAttributes() == null) || (prodContent
								.getGlobalAttributes().getChokingHazard() == null))) {
			CompareValuesUtility.verifyNull("Legal", legal);
		} else {

			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getHazardMaterialCode(), legal.getHazmatMaterialCd(),
					"HazmatMtrCd:");
			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getHazardMaterialCode(), legal.getUsDotType(),
					"usDotType:");
			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getHazardStorageCode(), legal.getHazmatStorageCd(),
					"HazmatStrgCd:");
			verifyNullOrEqual("Legal",
					checkInAttributeGroup("California Emission Compliant"),
					legal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getProp65Flag() == false ? null : true,
							legal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			/*if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),
								legal.getLimitedGeos());*/

			if(bDisclosurePresent)
			{
				if(dicValueId==52)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_52, legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==53)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_53, legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==84)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_84, legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==2534)
				{
					CompareValuesUtility.verifyNull("Legal", legal.getJewelry()==null?null:legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else
				{
					System.out.println(" ===================== check this dicValueId : "+dicValueId+"===================");
				}
			}
		}
		verifyChokingHazards(legal);
	}

	private void verifyChokingHazards(Legal legal) {
		Boolean isWarn = false;
		Boolean safetyWarn = false;

		if (prodContent.getGlobalAttributes() != null) {
			for (com.generated.xmls.serviceofferings.types.ChokingHazardType cType : prodContent.getGlobalAttributes()
					.getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
				{
					isWarn = true;
				} else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
				{
					safetyWarn = true;
				} else
				{
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.value(), legal.getChokingHazards());
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}

		if(isWarn)
		{
			compareValues("LegalIsNoWarn", true, legal.getIsNoWarning());
		}
		if(safetyWarn)
		{
			compareValues("LegalsafetyWarn", true, legal.getSafetyWarnings());
		}
	}

	private void verifySearch(ProductOffer xmlProductOffer,
			APIResponse<Offer> allResponse) {
		CompareValuesUtility.addNewMultiValuedFields();
		CompareValuesUtility.verifyNullOrEqual("_Search", prodContent.getManufacturerModelNumber() == null ? null : prodContent
				.getManufacturerModelNumber().replaceAll("[^a-zA-Z0-9]", "").toUpperCase(), allResponse.getSearchFieldValue("model_no"),
				"Model_no");
		compareValues("_Search", upcToCheck, allResponse.getSearchFieldValue("upc"), "Upc");
		compareValues("_Search", parentId, allResponse.getSearchFieldValue("parentId"), "ParentId");
		CompareValuesUtility.verifyNullOrEqual("_Search", xmlProductOffer.getImaAttributes().getKsnId(), allResponse.getSearchFieldValue("ksn"), "Ksn");
		if(siteToTest.equalsIgnoreCase("sears")) {
			compareValues("_Search", partNumberToTest.substring(0, 8),
					allResponse.getSearchFieldValue("divitem"), "DivItem");
		}
		CompareValuesUtility.verifyNullOrEqual("_Search", parentId, allResponse.getSearchFieldValue("ssin"), "SSIN");
		CompareValuesUtility.verifyNullOrEqual("_Search", xmlProductOffer.getGuid(), xmlProductOffer.getGuid() == null ? null
				: allResponse.getSearchFieldValue("uid"), "UID");
	}

}
