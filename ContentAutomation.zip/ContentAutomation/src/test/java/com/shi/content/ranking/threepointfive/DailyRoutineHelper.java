package com.shi.content.ranking.threepointfive;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;

public class DailyRoutineHelper {

	public static DRMetadata getMetaData()
	{
		DRMetadata drMetadata = new DRMetadata();

		String respTelluride = RestExecutor.getJSonResponse(LoadProperties.rankingMongoConfig+"/ranking.bonus.qa.telluride");
		String bonusPointsUri =   JsonStringParser.getJsonValueNew(respTelluride,
				"item.attributes.bonusPointsUri",true);

		drMetadata.setTellurideApi(bonusPointsUri);

		String respEmail = RestExecutor.getJSonResponse(LoadProperties.rankingMongoConfig+"/ranking.bonus.qa.email");
		String recipientAddresses= JsonStringParser.getJsonValueNew(respEmail,
				"item.attributes.recipientAddresses",true);

		drMetadata.setEmailReceipents(recipientAddresses);

		String resp = RestExecutor.getJSonResponse(LoadProperties.rankingMongoConfig+"/ranking.bonus.qa.dailyRoutine");

		Boolean isForFuture= Boolean.parseBoolean(
				JsonStringParser.getJsonValueNew(resp,
						"item.attributes.isForFuture",true));

		drMetadata.setForFuture(isForFuture);

		String dealsStartDate = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.dealsStartDate",true);

		drMetadata.setDealsStartDate(dealsStartDate);

		String emailNotificationsEnabled = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.emailNotificationsEnabled",true);

		drMetadata.setEmailNotificationsEnabled(Boolean.parseBoolean(emailNotificationsEnabled));

		drMetadata.setDealsStartDate(dealsStartDate);

		String bucket = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.serverBucketDistribution.iftrank301p_qa_ch3_s_com",true);

		String sp[] = bucket.split("-");

		int startBucket=0;
		int endBucket=4095;
		try {
			startBucket = Integer.parseInt(sp[0]);

			endBucket = Integer.parseInt(sp[1]);
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}

		drMetadata.setStartBucket(startBucket);
		drMetadata.setEndBucket(endBucket);

		resp = RestExecutor.getJSonResponse(LoadProperties.rankingBonusService+"/getaccesstoken");

		String access_token = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.dealsStartDate",true);

		drMetadata.setAccessToken(access_token);


		resp = RestExecutor.getJSonResponse(LoadProperties.rankingMongoConfig+"/ranking.bonus.qa.greenbox");

		String gb = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.greenBoxGetUri",true);

		drMetadata.setGb(gb);

		resp = RestExecutor.getJSonResponse(LoadProperties.rankingMongoConfig+"/ranking.bonus.qa.priceGrid");

		String priceGrid = JsonStringParser.getJsonValueNew(resp,
				"item.attributes.apiUri",true);

		drMetadata.setPricinggrid(priceGrid);

		return drMetadata;
	}
}
