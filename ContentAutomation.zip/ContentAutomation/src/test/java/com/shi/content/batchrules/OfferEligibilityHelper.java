package com.shi.content.batchrules;

import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shi.content.wcsmigration.commons.ConditionParser.Conditions;
import com.shi.content.wcsmigration.commons.OfferEligibilityUtils;
import com.shi.content.wcsmigration.commons.vos.ConditionVO;

/**
 * @author ddaphal
 *
 */
public class OfferEligibilityHelper {

	/**
	 * This method evaluates single condition in batch rule, one rule can contain multiple conditions
	 * @param storeName e.g. Sears
	 * @param conditionVO 
	 * @param defaultValues
	 * @param conditionsSatisFied
	 * @param sOfferId
	 * @param sJsonResponse
	 * @return
	 */
	public static boolean evaluateConditon(String parentStore,String storeName,ConditionVO conditionVO,
			Map<String,String >defaultValues,List<String> conditionsSatisFied,String sOfferId
			,String sJsonResponse,boolean sywItmTyp)
	{

		if(!conditionVO.getSpecificCase().isEmpty())
		{
			switch(conditionVO.getSpecificCase())
			{
			
			case "##VndStatusCheck-invalid":
				conditionsSatisFied.add("invalidVndStatusCheck");
				return SpecificConditionsCheck.invalidVndStatusCheck(sJsonResponse,storeName);
				
			case "##Inactive-date-equal-check":
				conditionsSatisFied.add("Inactive-date-equals-check");
				return SpecificConditionsCheck.inactiveDateCheck(sJsonResponse,storeName);
			
			case "##UAS-response-check":
			{
				conditionsSatisFied.add("UAS-response-check");
				return UASCheck.checkUASResponse(sOfferId,storeName);
			}

			case "##Valid-price-check":
			{
				conditionsSatisFied.add("Valid-price-check");
				return PricingCheckHelper.isValidPrice(parentStore,storeName,sOfferId,sywItmTyp);
			}
			
			case "##InValid-price-check":
			{
				conditionsSatisFied.add("InValid-price-check");
				return !PricingCheckHelper.isValidPrice(parentStore,storeName,sOfferId,sywItmTyp);
			}

			case "##Non-clearnce":
			{
				conditionsSatisFied.add("Non - Clearnce check");
				return !PricingCheckHelper.isValidClearancePriceSet(parentStore,storeName,sOfferId);
			}

			case "##clearnce-check":
			{
				conditionsSatisFied.add("Clearnce check");
				return PricingCheckHelper.isValidClearancePriceSet(parentStore,storeName,sOfferId);
			}

			case "##Regional-price-check":
			{
				conditionsSatisFied.add("Regional-price-check");
				return SpecificConditionsCheck.checkRgnPricing(sOfferId);
			}

			case "##dimension-check":	
			{
				conditionsSatisFied.add("shipping-dimension-check");
				return SpecificConditionsCheck.isDimAllowedForMailable(sJsonResponse, sOfferId);
			}

			case "##kmart-pr-price-check":
			{
				conditionsSatisFied.add("kmart-pr-price-check");
				return PricingCheckHelper.isInvalidPriceKmartPr(sOfferId);
			}

			case "##Kmart-parent-upc-check":
			{
				String upc = JsonStringParser.getJsonValueNew(sJsonResponse,"_search.upc");
				if(upc==null || upc.isEmpty())
					return false;
				else
					upc = upc.replaceAll("\"","");

				conditionsSatisFied.add("Kmart-parent-upc-check");
				return SpecificConditionsCheck.checkKmartUpcParentCheck(sOfferId,upc);
			}


			case "##SAM-rules-valid-clearance":
			{
				conditionsSatisFied.add("SAM-rules-valid-clearance");
				return PricingCheckHelper.isValidClearancePriceSet(parentStore, storeName, sOfferId);
			}

			case "##SAM-rules-valid-sale":
			{

				conditionsSatisFied.add("SAM-rules-valid-sale");
				return PricingCheckHelper.isValidSalePriceSet(parentStore, storeName, sOfferId);
			}

			case "##SAM-rules-valid-regular":
			{
				conditionsSatisFied.add("SAM-rules-valid-regular");
				return PricingCheckHelper.isValidRegPriceSet(parentStore, storeName, sOfferId);
			}


			}

			if(conditionVO.getSpecificCase().contains("##generic-price-check"))
			{
				String price = conditionVO.getSpecificCase().split(":")[1];

				conditionsSatisFied.add("generic-price-check");
				return PricingCheckHelper.isValidPriceGenericCheck(parentStore, storeName, sOfferId, price);
			}

			return false;
		}

		String opr1=null;
		String opr2=null;
		String opr1Value=null;
		Double opr1Dbl=null;
		Double opr2Dbl=null;

		DateTime opr1DateTime=null;
		DateTime opr2DateTime=null;

		opr1=conditionVO.getOpr1();
		opr2=conditionVO.getOpr2();

		if(opr1!=null)
		{
			opr1=opr1.replaceAll("\"","");
		}

		if(opr2!=null)
		{
			opr2=opr2.replaceAll("\"","");
		}

		/*-------------get value from another field of same document--------------*/

		if(opr2.startsWith("@"))
		{
			opr2=opr2.replaceFirst("@", "");
			opr2 = JsonStringParser.getJsonValueNew(sJsonResponse, opr2);
		}

		if(conditionVO.getOthercollectionName().isEmpty())
		{
			//default collection i.e. offerattrs collection

			try {

				if(!opr1.startsWith("_"))
				{
					opr1 = OfferEligibilityUtils.OfferAttrsPrefix+opr1;
				}

				opr1Value = JsonStringParser.getJsonValueNew(sJsonResponse, opr1);
				//System.out.println(" opr1Value.. "+opr1 +"  : "+opr1Value);
			} catch (Exception e) {
				System.out.println("Please check, not able to extract value for "+opr1  );
				e.printStackTrace();
				return false;
			}
		}
		else
		{
			//example programs.vd.vndStatus.sears.isInvalid=True@collection:seller#desc.ffmsrc

			String sCollectionName = conditionVO.getOthercollectionName();

			String sFieldNameFromOfferAttrs = conditionVO.getFieldNameForOtherCollection();

			String sIdToHitFromOtherCollection = JsonStringParser.getJsonValueNew(sJsonResponse, OfferEligibilityUtils.OfferAttrsPrefix+sFieldNameFromOfferAttrs);

			sIdToHitFromOtherCollection = JsonStringParser.clean(sIdToHitFromOtherCollection);

			String sOtherCollectionRespose = HitCollectionAndGetRespose.getResponse(storeName, sCollectionName,
					sIdToHitFromOtherCollection);

			try {

				opr1 = "_blob."+CollectionValuesVal.getCollection(conditionVO.getOthercollectionName().toLowerCase()).getTypeOfObject()+"."+opr1;

				opr1Value = JsonStringParser.getJsonValueNew(sOtherCollectionRespose, opr1);
				//System.out.println("opr1Value other coll  : "+opr1+" :  "+opr1Value);
			} catch (Exception e) {
				System.out.println("Please check, not able to extract value for "+opr1  );
				e.printStackTrace();
				return false;
			}
		}

		if(opr1Value!=null)
		{		
			opr1Value=opr1Value.replaceAll("\"","");
		}


		if((opr1Value==null || opr1Value.equals("null") ) && defaultValues!=null && defaultValues.get(opr1)!=null)
		{
			opr1Value =  defaultValues.get(opr1);
		}

		Conditions condition = conditionVO.getConditon();

		if(condition==null)
		{
			System.out.println("Please check condition ....  ");
			return false;
		}
		else
		{
			switch (condition) 
			{

			/* ----------------- String to Number/Date conversion required for >, >=, <, <= conditions only ----------------- */
			case GREATER_THAN: 
			case GREATER_THAN_EQUALS:
			case LESS_THAN:
			case LESS_THAN_EQUALS:

				if(JodaDateTimeUtility.isValidDate(opr1Value) || JodaDateTimeUtility.isValidDate(opr2))
				{
					/*------------ means its a date comparison -------------*/

					if(opr1Value!=null && !opr1Value.equals("null"))
						opr1DateTime = JodaDateTimeUtility.convertToJodaFormat(opr1Value);

					if(opr2!=null && !opr2.equals("null") )
						opr2DateTime = JodaDateTimeUtility.convertToJodaFormat(opr2);

					return dateComparion(opr1DateTime,opr2DateTime,condition);

				}
				else
				{
					/*------------ non date comparison, has to be numeric values -------------*/
					try {
						opr1Dbl = Double.parseDouble(opr1Value);
					} catch (Exception e) {
						//System.out.println(" Error : Not a numeric value "+opr1Value);
						return false;
					}

					try {
						opr2Dbl = Double.parseDouble(opr2);
					} catch (Exception e) {
						//System.out.println(" Error : Not a numeric value "+opr2);
						return false;
					}
				}
				break;
			default:
				break;
			}


			switch (condition) 
			{

			case EQUALS:

				conditionsSatisFied.add(opr1 +"("+opr1Value+") = "+opr2);

				opr1Value = opr1Value==null?"null":opr1Value;

				if((opr1Value==null || opr1Value.equalsIgnoreCase("null"))  && (opr2==null||opr2.equalsIgnoreCase("null")))
				{
					return true;
					//both NULL
				}

				else if(opr1Value.equalsIgnoreCase("true") || opr1Value.equalsIgnoreCase("false"))
				{
					if(opr1Value.equalsIgnoreCase(opr2))
					{
						return true;
					}
				}

				if(opr1.contains("desc.soldBy"))
				{
					if(opr1Value.equalsIgnoreCase(opr2))
					{
						return true;
					}
				}
				else
				{
					if(opr1Value.equals(opr2))
					{
						return true;
					}
				}
				break;

			case GREATER_THAN:

				conditionsSatisFied.add(opr1 +"("+opr1Dbl+") > "+opr2Dbl);

				if(opr1Dbl==null|| opr2Dbl==null)
				{
					//System.out.println("One of the operand is null : "+opr1 +"("+opr1Dbl+") > "+opr2Dbl);
					return false;
				}

				if(opr1Dbl>opr2Dbl)
				{
					return true;
				}

				break;

			case GREATER_THAN_EQUALS:

				conditionsSatisFied.add(opr1 +"("+opr1Dbl+") >= "+opr2Dbl);

				if(opr1Dbl==null|| opr2Dbl==null)
				{
					//System.out.println("One of the operand is null : "+opr1 +"("+opr1Dbl+") >= "+opr2Dbl);
					return false;
				}

				if(opr1Dbl>=opr2Dbl)
				{
					return true;
				}
				break;

			case LESS_THAN:

				conditionsSatisFied.add(opr1 +"("+opr1Dbl+") < "+opr2Dbl);


				if(opr1Dbl==null|| opr2Dbl==null)
				{
					//System.out.println("One of the operand is null : "+opr1 +"("+opr1Dbl+") < "+opr2Dbl);
					return false;
				}

				if(opr1Dbl<opr2Dbl)
				{
					return true;
				}
				break;

			case LESS_THAN_EQUALS:

				if(opr1Dbl==null|| opr2Dbl==null)
				{
					//System.out.println("One of the operand is null : "+opr1 +"("+opr1Dbl+") <= "+opr2Dbl);
					return false;
				}

				conditionsSatisFied.add(opr1 +"("+opr1Dbl+") <= "+opr2Dbl);

				if(opr1Dbl<=opr2Dbl)
				{
					return true;
				}
				break;

			case IN:

				conditionsSatisFied.add(opr1 + "("+opr1Value+") IN "+opr2);

				String[] spValues = opr2.split(",");
				for (String string : spValues) {

					if(string.equals(opr1Value))
					{
						return true;
					}
				}
				return false;

			case NON_IN:

				conditionsSatisFied.add(opr1 + "("+opr1Value+") NOT IN "+opr2);

				spValues = opr2.split(",");
				for (String string : spValues) {

					if(string.equals(opr1Value))
					{
						return false;
					}
				}

				return true;

			case NOT_EQUALS:

				conditionsSatisFied.add(opr1 +"("+opr1Value+") != "+opr2);

				if(opr1Value==null||opr1Value.equalsIgnoreCase("null"))
				{
					opr1Value="null";
				}

				if(opr2.equalsIgnoreCase("null"))
				{
					opr2="null";
				}

				if(!opr1Value.equals(opr2))
				{
					return true;
				}
				break;

			case START_WITH:

				conditionsSatisFied.add(opr1 + "("+opr1Value+") START_WITH "+opr2);

				spValues = opr2.split(",");
				for (String string : spValues) {

					if(opr1Value.startsWith(string.trim()))
					{
						return true;
					}
				}
				return false;


			case CONTAINS:

				conditionsSatisFied.add(opr1 + "("+opr1Value+") CONTAINS "+opr2);

				if(opr1Value.startsWith("[") &&  opr1Value.endsWith("]"))
				{
					opr1Value=opr1Value.substring(1,opr1Value.length()-1);
				}

				String[] spValuesw = opr1Value.split(",");

				for (String string : spValuesw) {

					if(opr2.equals(string))
					{
						return true;
					}
				}
				return false;

			default:

				System.out.println("Invalid condition ..... "+condition);
				break;
			}
		}

		return false;
	}


	/**
	 * This method compares two dates based on given condition
	 * @param date1
	 * @param date2
	 * @param condition
	 * @return
	 */
	public static boolean dateComparion(DateTime date1, DateTime date2, Conditions condition)
	{
		boolean result;


		if(date1==null &&  date2==null)
		{
			//both NULL - result TRUE irrespective of condition 
			result =  true;
		}

		else if(date1==null || date2==null)
		{
			//any one NULL - result FALSE irrespective of condition 
			result = false;
		}

		else
		{
			switch (condition) 
			{
			case GREATER_THAN: 
				//date1 > date2
				result= date1.isAfter(date2);
				break;

			case GREATER_THAN_EQUALS:

				result= date1.isAfter(date2) || date1.isEqual(date2);
				break;

			case LESS_THAN:

				//date1 < date2
				result= date1.isBefore(date2);
				break;

			case LESS_THAN_EQUALS:

				result= date1.isBefore(date2) || date1.isEqual(date2);
				break;

			case EQUALS:
				result= date1.isEqual(date2);
				break;

			default:
				System.out.println("Error : Unknown date comparison condition ");
				result= false;
				break;
			}
		}

		return result;
	}

	public static String getValueFromCollection(String storeName, String sCollectionName, String sIdToHitFromOtherCollection,String fieldToExtract)
	{
		String sCollectionRespose = HitCollectionAndGetRespose.getResponse(storeName, sCollectionName,
				sIdToHitFromOtherCollection);

		try {

			fieldToExtract = "_blob."+CollectionValuesVal.getCollection(sCollectionName.toLowerCase()).getTypeOfObject()+"."+fieldToExtract;

			return JsonStringParser.getJsonValueNew(sCollectionRespose, fieldToExtract);
		} catch (Exception e) {
			System.out.println("Please check, not able to extract value for "+fieldToExtract );
			e.printStackTrace();
			return null;
		}
	}

	public static String getPricingId(String parentStore, String sStoreName, String sOfferId)
	{
		String sStoreId="";

		switch (sStoreName.toLowerCase()) 
		{

		case "sears": 
			sStoreId="0009300";
			break;

		case "kmart":
			sStoreId="7840";
			break;

		case "puertorico":
			if(parentStore.equalsIgnoreCase("sears"))
				sStoreId="0009313";
			else if(parentStore.equalsIgnoreCase("kmart"))
				sStoreId="7783";
			break;

		case "mygofer":
			if(parentStore.equalsIgnoreCase("sears"))
				sStoreId="0009300";
			else if(parentStore.equalsIgnoreCase("kmart"))
				sStoreId="7840";
			break;

		default:
			break;
		}

		sOfferId = sStoreId+"-"+sOfferId;

		return sOfferId;

	}
}
