package com.shi.content.Variations;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.generated.vos.content.AltIds;
import com.generated.vos.content.Assets;
import com.generated.vos.content.Attachment;
import com.generated.vos.content.Attr;
import com.generated.vos.content.Brand;
import com.generated.vos.content.Content;
import com.generated.vos.content.ContentExtension;
import com.generated.vos.content.ContentSchema;
import com.generated.vos.content.Content_;
import com.generated.vos.content.CuratedContents;
import com.generated.vos.content.CuratedGrp;
import com.generated.vos.content.Desc;
import com.generated.vos.content.Grocery;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Nutrition;
import com.generated.vos.content.Operational;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Static;
import com.generated.vos.content.Val;
import com.generated.vos.content.Video;
import com.generated.vos.contentkafka.Attribute;
import com.generated.vos.contentkafka.CuratedContent;
import com.generated.vos.contentkafka.CuratedContentList;
import com.generated.vos.contentkafka.Datum;
import com.generated.vos.contentkafka.FeatureImageList;
import com.generated.vos.contentkafka.ProductAsset;
import com.generated.vos.contentkafka.Site;
import com.generated.vos.contentkafka.Taxonomy;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Label;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class SHCStaticKafkaVerifications<T> implements Runnable {
	//com.generated.vos.contentkafka.Content iaContent;
	com.generated.vos.contentkafka.ContentKafkaSchema iaContentMsg;
	String partNumberToTest;
	String sSite=null;
	String itemClassId=null;
	String brandCodeId = null, autoFitmentType = null;
	SHCContentCommons commons = new SHCContentCommons(null,"sears");
	Attrs masterHierarchyAttributes;
	List<String>  lstAttribsNotFound = new ArrayList<>();
	boolean isPrimaryAvlbl = false; 
	
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });
	
	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	
	List<String> lstAttributeVals = new ArrayList<String>();
	
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	
	public SHCStaticKafkaVerifications(
			com.generated.vos.contentkafka.ContentKafkaSchema iaContentMsg) {
		this.iaContentMsg = iaContentMsg;
		this.partNumberToTest = iaContentMsg.getContent().getSsin();
		

	}

	public void run() {

		System.out.println(partNumberToTest);

		ContentSchema gbData = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.CONTENTSCHEMA, partNumberToTest);

		if (partNumberToTest != null) {
			/*
			 * if(!partNumberToTest.contains("00842911000")) return;
			 */
			
			try {
				CompareValuesUtility.init();
				CompareValuesUtility.addDataFieldForReport("UID",iaContentMsg.getContent().getUid());
				if (gbData == null) {
					CompareValuesUtility.addFailedDataFieldForReport("ContentId","Not found in GB");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return;
				}
				if(JodaDateTimeUtility.isFirstDateBeforeSecond(iaContentMsg.getMetaData().getCreatedTs(), gbData.getBlob().getContent().getMeta().getIaCreatedTs())){
					CompareValuesUtility.addDataFieldForReport("ContentId","Message not latest. Exp TS:"+iaContentMsg.getMetaData().getCreatedTs() + "Actual "+ gbData.getBlob().getContent().getMeta().getIaCreatedTs());
					CompareValuesUtility.addDataFieldForReport("LastModBy",gbData.getBlob().getContent().getMeta().getLastModifiedBy());
					CompareValuesUtility.setupResult(partNumberToTest, true);
					
					return;
				}
				
				CompareValuesUtility.addDataFieldForReport("LastModBy",gbData.getBlob().getContent().getMeta().getLastModifiedBy());

				CompareValuesUtility.compareValues("Partnumbers",partNumberToTest, gbData.getId());

				verifyProduct(iaContentMsg, gbData, partNumberToTest);

				CompareValuesUtility.setupResult(partNumberToTest, true);
			} catch (Throwable e) {
				System.out.println("Check this id :" + partNumberToTest);
				e.printStackTrace();
				CompareValuesUtility.addDataFieldForReport("Exception", e.toString(), INFOTYPE.FAILED);
				CompareValuesUtility.setupResult(partNumberToTest, true);
				
			} finally {
				CompareValuesUtility.teardown();
			}
		}
	}

	private void verifyProduct(com.generated.vos.contentkafka.ContentKafkaSchema iaContentMsg, ContentSchema gbData, String ssin) {

		Content gbContentDoc = gbData.getBlob().getContent();
		com.generated.vos.contentkafka.Content iaContent = iaContentMsg.getContent();
		com.generated.vos.contentkafka.MetaData iaMetaData = iaContentMsg.getMetaData();
		
//		findSites(partNumberToTest);
		sSite = "Sears";
		itemClassId = iaContent.getItemClassId().intValue()+"";
		CompareValuesUtility.addDataFieldForReport("ItemClassId", itemClassId);
		compareValues("Content_Id", ssin, gbContentDoc.getId());
		compareValues("Identity_Ssin", ssin, gbContentDoc.getIdentity()
				.getSsin());
		compareValues("Search_Ssin", ssin, gbData.getSearch().getSsin());

		compareValues("Name", iaContent.getTitle(), gbContentDoc.getName());

		CompareValuesUtility.verifyTrue(gbData.getFt().getCatentrySubType().contains(iaContent.getClassification().equals("P")?"V":iaContent.getClassification()), "Ft.CatSubType", iaContent.getClassification().equals("P")?"V":iaContent.getClassification(),gbData.getFt().getCatentrySubType() );
		
		// Verify Desc
		verifyDesc(iaContent.getLongDesc(), iaContent.getShortDesc(),iaContent.getTopDesc(), gbContentDoc.getDesc());
		commons.compareOnlyIfNotNull("AutoType", iaContent.getAutoType(), gbContentDoc.getAutomotive()==null?null:gbContentDoc.getAutomotive().getAutoType());
		Brand gbBrand = gbContentDoc.getBrand()==null?null:gbContentDoc.getBrand();
		verifyNullOrEqual("Brand", iaContent.getBrandName(), gbBrand==null?null:gbBrand.getName(),"Name");
		verifyNullOrEqual("Brand", iaContent.getBrandId(), gbBrand == null?null:gbBrand.getId(),"Id");
		verifyNullOrEqual("Brand", iaContent.getBrandImage()==null? null: TestUtils.modifyURL(iaContent.getBrandImage().getImageUrl()), gbBrand ==null? null:(gbContentDoc.getBrand().getImg() ==null?null:
			gbContentDoc.getBrand().getImg().getSrc()), "ImageURL");
		CompareValuesUtility.addNewMultiValuedFields();

		
		verifyNullOrEqual("ManufacturerName", iaContent.getManufacturerName(),gbContentDoc.getMfr().getName());
		verifyNullOrEqual("ModelNumber", iaContent.getModelNumber(), gbContentDoc.getMfr().getModelNo());

		verifySites(gbContentDoc.getSites(), gbContentDoc.getOperational());
		verifyDispSites(gbData.getSearch().getDispSite());
		
		if(iaContent.getProgramType().equalsIgnoreCase("sears"))
			compareValues("Search_isDispElig", true, gbData.getSearch().getIsDispElig());
		
		// Verify assets
		verifyAllAssets(iaContent, gbContentDoc.getAssets());

		// Verify Facets
		
		verifyFacetsGB(gbContentDoc);
		CompareValuesUtility.addNewMultiValuedFields();
		
		validateGroupOrder(gbContentDoc.getSpecs());
		verifySpecsGB(gbContentDoc.getSpecs());
		
		if(lstAttribsNotFound.size() > 0)
			CompareValuesUtility.addDataFieldForReport("Attributes Not found", lstAttribsNotFound.toString());

		this.verifyTaxonomy(iaContent.getSites(), gbContentDoc);

		verifyNullOrEqual("MatureContent",iaContent.getIsMatureContent(),gbContentDoc.getLegal() == null? null:gbContentDoc.getLegal().getIsMatureContent());
		verifyNullOrEqual("BannedContent",iaContent.getIsBannedContent(),gbContentDoc.getLegal() == null? null:gbContentDoc.getLegal().getIsBanned());
		verifyNullOrEqual("SywItemType",iaContent.getSywItemType(),gbContentDoc.getDispTags() == null? null : gbContentDoc.getDispTags().getSywItemType());
		
		
		// Verify seo
		verifySeo(iaContent.getSeo(), gbContentDoc);

		AltIds gbAltIds = gbContentDoc.getAltIds();
		verifyNullOrEqual("DummyPid", iaContent.getDummyPid(), gbAltIds ==null? null: gbAltIds.getDummyPID());
		verifyNullOrEqual("ImaPId", iaContent.getImaClassControlPid(), gbAltIds ==null? null: gbAltIds.getImaClassControlPid());
		verifyNullOrEqual("AltIds_Spinid", iaContent.getSpinId(), gbAltIds ==null? null: gbAltIds.getSpinId());
		verifyNullOrEqual("Search_Spinid", iaContent.getSpinId(), gbData.getSearch().getSpinId());
		verifyNullOrEqual("Identity_uid", iaContent.getClassification().equals("P")?null:iaContent.getUid(), gbContentDoc.getIdentity().getUid());
		verifyNullOrEqual("Search_uid", iaContent.getClassification().equals("P")?null:iaContent.getUid(), gbData.getSearch().getUid());
		verifyNullOrEqual("PrevSsin", iaContent.getPrevSsin(), gbContentDoc.getIdentity().getPrevSsin());
		
		CompareValuesUtility.verifyNullOrEqual("TotalContribCount", iaContent.getClassification().equals("P")?null:iaContent.getTotalContribCount(),gbContentDoc.getIdentity().getOfferCnt());
		
		/***Newly Added****/
		CompareValuesUtility.verifyNullOrEqual("ContentSource", iaContent.getContribSource(),gbContentDoc.getMeta().getContentSource());
		CompareValuesUtility.verifyNullOrEqual("iaCreatedTs", iaMetaData.getCreatedTs(),gbContentDoc.getMeta().getIaCreatedTs());
		CompareValuesUtility.verifyNullOrEqual("iaSchemaVer", iaMetaData.getVersionNumber(),gbContentDoc.getMeta().getIaSchemaVer());
		/*****/
		
		if (iaContent.getIsLongDescSuppress() == null|| iaContent.getIsLongDescSuppress().equals(false))
			CompareValuesUtility.verifyNull("SuppresLongDesc",gbContentDoc.getIsLongDescSuppress());
		else
			compareValues("SuppresLongDesc", iaContent.getIsLongDescSuppress(),gbContentDoc.getIsLongDescSuppress());

		if (iaContent.getCuratedContents().size() > 0) {
			CompareValuesUtility.addNewMultiValuedFields();
			this.verifyCuratedContents(iaContent.getCuratedContents(),gbContentDoc.getCuratedContents());
		}
		
		if(iaContent.getGrocery() != null)
			verifyGrocery(gbContentDoc.getGrocery());
		
		if(iaContent.getAutoFitment() != null){
			compareValues("Automotive", iaContent.getAutoFitment(), gbContentDoc.getAutomotive().getIsFitmentRequired(), "IsFitmentReq");
			if(brandCodeId != null)
				compareValues("Automotive", brandCodeId, gbContentDoc.getAutomotive().getBrandCodeId(), "BrandCodeId");
			if(autoFitmentType != null)
				compareValues("Automotive", autoFitmentType, gbContentDoc.getAutomotive().getAutoFitment(), "AutoFitment");
			
		}
		
		/*isAutomotive validation*/
		String storeHierName = iaContent.getStoreHierId()==null?null:ContentCache.getNameForStoreHierId(iaContent.getStoreHierId());
		String div = storeHierName==null?null:storeHierName.substring(0, storeHierName.indexOf("-"));
		Boolean isAuto = null;
		//System.out.println("div="+div);
		if((div!=null && (div.equals("095") || div.equals("028"))) || (iaContent.getAutoFitment()!=null && iaContent.getAutoFitment()))
			isAuto=true;
		
		compareValues("Classifications", "P", gbContentDoc.getClassifications().getCatentryType(),"Catentrytype");
		compareValues("Classifications", iaContent.getClassification().equals("P")?"V":iaContent.getClassification(), gbContentDoc.getClassifications().getCatentrySubType(),"CatentrySubtype");
		verifyNullOrEqual("Classifications", iaContent.getEnrichmentProvider(), gbContentDoc.getClassifications().getEnrichmentProvider(),"EnrichmentProvider");
		if(iaContent.getAutoType() != null && iaContent.getAutoType().equalsIgnoreCase("uvd"))
			compareValues("Classifications", true, gbContentDoc.getClassifications().getIsUvd(),"isUVD");
		verifyNullOrEqual("Classifications", isAuto, gbContentDoc.getClassifications().getIsAutomotive(), "isAutomotive");
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void verifySites(List<String> sites, Operational operationalFields) {
		
		List<String> lstOperationalSites = Arrays.asList(new String[]{"1","2","4","11"});
		for(Site site : iaContentMsg.getContent().getSites()){
			if(site.getId().equals("10") || site.getId().equals("13"))
				continue;
			CompareValuesUtility.verifyItemInList("Site", TestUtils.getSite(Long.parseLong(site.getId())), sites);
			if(lstOperationalSites.contains(site.getId())){
				compareValues("Oper.DispElig", true, commons.getDispEligValue(site.getId(), operationalFields));
			}
			
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
	}
	
	private void verifyDispSites(List<String> dispSite) {
		if(iaContentMsg.getContent().getProgramType() == null)
			return;
		if(iaContentMsg.getContent().getProgramType().equalsIgnoreCase("SEARS")) {
			for(Site site : iaContentMsg.getContent().getSites()){
				if(site.getId().equals("10") || site.getId().equals("13"))
					continue;
				CompareValuesUtility.verifyItemInList("_search.dispSite", TestUtils.getSite(Long.parseLong(site.getId())), dispSite);
			}
		}else {
			String[] expDispSite = {"MP", iaContentMsg.getContent().getProgramType()};
			for(String site : expDispSite) {
				CompareValuesUtility.verifyItemInList("_search.dispSite", site, dispSite);
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyGrocery(Grocery gbGrocery){
		if(iaContentMsg.getContent().getGrocery().getNutrition() !=null){
			com.generated.vos.contentkafka.Nutrition iaNutrition = iaContentMsg.getContent().getGrocery().getNutrition();
			if(gbGrocery == null || gbGrocery.getNutrition() == null){
				logFailed("Grocery", iaContentMsg.getContent().getGrocery().getNutrition(),"Not found");
				return;
			}
			Nutrition gbNutrition = gbGrocery.getNutrition();
			
			commons.grocerySpecificChecks("Allergen", iaNutrition.getAllergen(), gbNutrition.getAllergen());
			commons.grocerySpecificChecks("HtmlLabel", iaNutrition.getHtmlLabel(), gbNutrition.getHtmlLabel());
			commons.grocerySpecificChecks("Ingredients", iaNutrition.getIngredients(), gbNutrition.getIngredients());
			commons.grocerySpecificChecks("Warnings", iaNutrition.getWarnings(), gbNutrition.getWarnings());
			commons.grocerySpecificChecks("GreenInformation", iaNutrition.getGreenInformation(), gbNutrition.getGreenInformation());
			commons.grocerySpecificChecks("GauranteeAnys", iaNutrition.getGuaranteeAnalysis(), gbNutrition.getGuaranteeAnalysis());
			commons.grocerySpecificChecks("Gaurantees", iaNutrition.getGuarantees(), gbNutrition.getGuarantees());
			commons.grocerySpecificChecks("Indications", iaNutrition.getIndications(), gbNutrition.getIndications());
			commons.grocerySpecificChecks("Instructions", iaNutrition.getInstructions(), gbNutrition.getInstructions());
			commons.grocerySpecificChecks("Interactions", iaNutrition.getInteractions(), gbNutrition.getInteractions());
		}
	}
	
	private void verifyFacetsGB( Content content){
			
			masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
			if(masterHierarchyAttributes == null){
				CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
				return;
			}
			segregateAttributes(iaContentMsg.getContent().getAttributes());
			
			if(lstFacetAttributes.isEmpty()){
				CompareValuesUtility.verifyNull("FacetName", content.getFacets());
				CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
				return;
			}
			
			//Hit all attributes
			Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
			Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);
			
			List<Static> staticFacets;
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
			
			for(String facetAttributeId : lstFacetAttributes){
				boolean bFound = false;
				boolean bAttrValueFound = false;
				if(staticFacets ==  null){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found");
					continue;
				}
				for(Static gbFacet : staticFacets){
					if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
						if(!bFound){
							bFound = true;
							CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId));
						}
						if(bFound && (attributeToVal.get(facetAttributeId).equals(gbFacet.getValue()) || attributeValData.get(attributeToVal.get(facetAttributeId)).equals(gbFacet.getValue()))){
							bAttrValueFound = true;
							if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
								compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue());
							else //free value
								compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue());
							break;
						}
					}
				}
				
					
				if(!bFound){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found");
				}
				
				if(!bAttrValueFound){
					CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found");
				}
			}
		
			
		}
			
	
	
	
	public void verifyDesc(String sLongDescription, String sShortDescription,
			List<String> sTopDescription, List<Desc> desc) {
		int i = getPositionInList("L", desc, "type", Desc.class);
		// System.out.println("i : "+i);
		if (sLongDescription != null) {
			if (i > -1) {
				verifyTrue(i != -1, "DescType", "L", "L");
				compareValues("DescVal", sLongDescription,desc.get(i).getVal());
			} else {
				verifyTrue(i != -1, "DescType", "L", false);
				compareValues("DescVal", sLongDescription, false);

			}
		}

		i = getPositionInList("S", desc, "type", Desc.class);
		// System.out.println("i (S)= "+i);
		if (sShortDescription != null) {
			//Added shortDesc truncate 2000 logic
			if(sShortDescription.length()>2000){
				sShortDescription=sShortDescription.substring(0, 2000);
			}
			if (i > -1) {
				verifyTrue(i != -1, "DescType", "S", "S");
				compareValues("DescVal",sShortDescription, desc.get(i).getVal());
			} else {
				verifyTrue(i != -1, "DescType", "S", false);
				compareValues("DescVal", sShortDescription, false);
			}
		}

		/*for(String sTopDesc : sTopDescription){
			boolean bFound = false;
			for(Desc singleDesc : desc){
				if(singleDesc.getType().toString().equals("T") && singleDesc.getVal().equals(sTopDesc)){
					bFound = true;
					logPassed("DescType", "T", "T");
					logPassed("DescVal", sTopDesc, sTopDesc);
					break;
				}
			}
			
			if(!bFound){
				logFailed("DescType", "T", "T");
				logFailed("DescVal", sTopDesc, "Not found");
				
			}
		
		}*/
		
		String sFinalTopDesc = null;
		for(String sTopDesc : sTopDescription){
			if(!(sFinalTopDesc==null))
				sFinalTopDesc = sFinalTopDesc+sTopDesc+"|";
			else
				sFinalTopDesc = sTopDesc+"|";
		}
		if(!(sFinalTopDesc==null))
			sFinalTopDesc = sFinalTopDesc.substring(0, (sFinalTopDesc.length()-1));
		
		i = getPositionInList("T", desc, "type", Desc.class);
		// System.out.println("i (S)= "+i);
		if (sFinalTopDesc != null) {
			if (i > -1) {
				verifyTrue(i != -1, "DescType", "T", "T");
				compareValues("DescVal",sFinalTopDesc, desc.get(i).getVal());
			} else {
				verifyTrue(i != -1, "DescType", "T", false);
				compareValues("DescVal", sFinalTopDesc, false);
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyAllAssets(com.generated.vos.contentkafka.Content iaContent, Assets contentAssets) {

		verifyAssets(iaContent.getPrimaryImage(),iaContent.getFeatureImageList(), contentAssets);

		if (iaContent.getProductAssets().size() > 0) {

			verifyAssetAttachments(iaContent.getProductAssets(),contentAssets.getAttachments());

			verifyAssetVideo(iaContent.getProductAssets(),contentAssets.getVideos());
		}

		if (iaContent.getContentExtensions().size() > 0) {
			if (contentAssets.getContentExtensions().size() > 0)
				verifyContentExtension(iaContent.getContentExtensions().get(0), contentAssets.getContentExtensions().get(0));
			else
				verifyNullOrEqual("ContentExtension", iaContent.getContentExtensions().get(0), false);
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void verifyAssets(com.generated.vos.contentkafka.PrimaryImage primaryImage,
			List<FeatureImageList> featureImageList, Assets assets) {
		
		if(primaryImage == null && featureImageList.isEmpty())
			return;
		

		int primaryImageIndex = getPositionInList("P", assets.getImgs(), "type", Img_.class);
		int altImageIndex = getPositionInList("A", assets.getImgs(), "type", Img_.class);
		
		
		if(primaryImageIndex == -1 && primaryImage != null)
			logFailed("PrimaryImg", primaryImage.getClass(), "Not found");
		else{
			
			compareValues("PrimaryImg", "P", assets.getImgs().get(primaryImageIndex).getType(),"Type");
			
			//Defaulting to 1000 if no height width is received
			int height = primaryImage.getImageHeight() == null? 1000: primaryImage.getImageHeight().intValue();
			int width = primaryImage.getImageWidth() == null? 1000: primaryImage.getImageWidth().intValue();
			
			verifyNullOrEqual("PrimaryImg", height,assets.getImgs().get(primaryImageIndex).getVals().get(0).getHeight().intValue(), "Height");
			verifyNullOrEqual("PrimaryImg", width, assets.getImgs().get(primaryImageIndex).getVals().get(0).getWidth().intValue(), "Width");
			compareValues("PrimaryImg",TestUtils.modifyURL(primaryImage.getImageUrl()), 
					assets.getImgs().get(primaryImageIndex).getVals().get(0).getSrc(), "Src");
			verifyNullOrEqual("PrimaryImg",primaryImage.getName(), 
					assets.getImgs().get(primaryImageIndex).getVals().get(0).getTitle(), "Title");
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		if (!featureImageList.isEmpty()) {
			
			if(altImageIndex == -1){
				logFailed("FeaturedImg", featureImageList, "Not found");
				
			}
			else{
				compareValues("FeaturedImg", "A", assets.getImgs().get(altImageIndex).getType(), "Type");
				for (FeatureImageList fImage : featureImageList) {
					boolean bFound = false;

					for (Val assetImgVal : assets.getImgs().get(altImageIndex).getVals()) {
						if (assetImgVal.getSrc().equals(TestUtils.modifyURL(fImage.getImageUrl()))) {
							
							bFound = true;
							CompareValuesUtility.logPassed("FeaturedImg",TestUtils.modifyImgURL(fImage.getImageUrl()),assetImgVal.getSrc(),"Src");
							//Defaulting to 1000 if no height width is received
							int height = fImage.getImageHeight() == null? 1000: fImage.getImageHeight().intValue();
							int width = fImage.getImageWidth() == null? 1000: fImage.getImageWidth().intValue();
							
							verifyNullOrEqual("FeaturedImg",width,assetImgVal.getWidth().intValue(),"Width");
							verifyNullOrEqual("FeaturedImg",height,assetImgVal.getHeight().intValue(),"Height");
							verifyNullOrEqual("FeaturedImg",fImage.getName(), assetImgVal.getTitle(), "Title");
							break;
						}
					}
					if (!bFound) {
						CompareValuesUtility.logFailed("FeaturedImg", fImage.getImageUrl(), "Not found","Src");
					}
				}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		}
	}



	private void verifyAssetAttachments(List<ProductAsset> iaProductAssets, List<Attachment> attachments) {

		for (ProductAsset attachmentAsset : iaProductAssets) {
			Boolean bFound = false;
			commons.convertType(attachmentAsset.getAssetType());
			for (Attachment gbAttachment : attachments) {
				
				if (attachmentAsset.getImageUrl().equals(gbAttachment.getLink().getAttrs().getHref()) && !commons.assetTypeGB.equals("PRODUCT_VIDEO")
						&& commons.assetTypeGB.equals(gbAttachment.getType().toString())) {

					bFound = true;
					verifyTrue(true, "AttchmtLinkHref",attachmentAsset.getImageUrl(),gbAttachment.getLink().getAttrs().getHref());
					compareValues("AttType", commons.assetTypeGB,gbAttachment.getType());

					if(commons.assetTypeGB.equals("MS")){
						compareValues("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					}
					else
						compareValues("AttchmtName", commons.assetName, gbAttachment.getName());
					
					if (commons.assetName != null && commons.assetName.contains("Spanish"))
						compareValues("AttchLang", "Spanish",gbAttachment.getLang());
					else
						compareValues("AttchLang", "English",gbAttachment.getLang());
					break;
				}

			}
			if (!bFound && !commons.assetTypeGB.equals("PRODUCT_VIDEO")) {
				CompareValuesUtility.logFailed("AttchmtLinkHref",attachmentAsset.getImageUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", commons.assetTypeGB,"Not found");

			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyAssetVideo(List<ProductAsset> list, List<Video> videos) {

		for (ProductAsset videoAsset : list) {
			commons.convertType(videoAsset.getAssetType());
			// System.out.println("videoAsset.getAssetType()"+videoAsset.getAssetType());
			if (commons.assetTypeGB.equals("PRODUCT_VIDEO")) {
				Boolean bFound = false;
				for (Video video : videos) {
					if (videoAsset.getImageUrl().equals(
							video.getLink().getAttrs().getHref())) {
						verifyTrue(true, "VideoURL", videoAsset.getImageUrl(), video.getLink());
						bFound = true;
						compareValues("VideoType", commons.assetTypeGB, video.getType());
						compareValues("VideoName", commons.assetName, video.getName());
					}
				}
				if (!bFound)
					CompareValuesUtility.logFailed("Video",videoAsset.getImageUrl(), "Not found");
			}
		}
	}

	public void verifyContentExtension(
			com.generated.vos.contentkafka.ContentExtension iaContentExt,
			ContentExtension contentExtension) {

		compareValues("ContentExt", iaContentExt.getName(),contentExtension.getName(), "Name");
		compareValues("ContentExt", iaContentExt.getType(),contentExtension.getType(), "Type");
		
		for(Datum iaContentExtDatum : iaContentExt.getData()){
			boolean bFound = false;
			for(com.generated.vos.content.Datum gbData : contentExtension.getData()){
				if(iaContentExtDatum.getKey().equals(gbData.getKey())){
					bFound = true;
					CompareValuesUtility.logPassed("ContExt.Data", iaContentExtDatum.getKey(),gbData.getKey(),"Key" );
					compareValues("ContExt.Data", iaContentExtDatum.getValue(),gbData.getVal(),"Value" );
				}
			}
			
			if(!bFound){
				CompareValuesUtility.logFailed("ContExt.Data", iaContentExtDatum.getKey(),"Not found","Key" );
			}
			
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	
	
	private void verifyTaxonomy(List<Site> kafkaSites, Content content) {
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
	
		for ( Site site : kafkaSites) {

			long lSiteId = Long.parseLong(site.getId());
			if(lSiteId > 11 || lSiteId == 10)
				continue;
			
			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Taxonomy hierarchy : site.getTaxonomy()){
				if(hierarchy.getPrimary().equals("true"))
					isPrimaryAvlbl = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}
			
			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		
		//TODO  - need to pass cross format flag
		if(!(mpSiteHiearachies.size() == 0))
			commons.compareWebhierarchyGB(mpSiteHiearachies, content.getTaxonomy() == null? null : content.getTaxonomy().getWeb(),sSite,false);
		commons.compareMasterhierarchyGB(Long.parseLong(itemClassId), content.getTaxonomy() == null? null : content.getTaxonomy().getMaster().getHierarchy());
	}

	public void verifySeo(com.generated.vos.contentkafka.Seo seo, Content gbContent) {
		if (seo != null) {
			
			com.generated.vos.content.Seo gbSeoData = gbContent.getSeo();
			
			compareValues("SEO",seo.getRobotFollowFlag() == null ? true : seo.getRobotFollowFlag(), gbSeoData.getIsRobotFollow(),
					"RobotFollow");
			compareValues("SEO",seo.getRobotIndexFlag() == null ? true : seo.getRobotIndexFlag(), gbSeoData.getIsRobotIndex(),
					"RobotIndex");
			verifyNullOrEqual("SEO", seo.getFeatureAltTag(),gbSeoData.getFeatureAltTag(), "FeatureAlt");
			verifyNullOrEqual("SEO", seo.getProductAltTag(),gbSeoData.getProductAltTag(), "ProdAlt");
			if (seo.getTitle() == null) {
				commons.verifySeoTitle(gbContent, isPrimaryAvlbl);
			} else {
				compareValues("SEO", seo.getTitle(), gbSeoData.getTitle(), "Title");
			}

			if (seo.getMetaDescription() != null)
				compareValues("SEO", seo.getMetaDescription(), gbSeoData.getDesc(),"Desc");
			else
				verifyAutoSEODesc(gbContent);

			 if(seo.getUrl() != null)
				 verifyNullOrEqual("SEO", seo.getUrl(),gbSeoData.getUrl(),"Url");
			 
			 CompareValuesUtility.addNewMultiValuedFields();
			 
		} else {
			commons.verifySeoTitle(gbContent, isPrimaryAvlbl);
			verifyAutoSEODesc(gbContent);
		}
	}
	
	/**
	 * Generates desc if no desc in input and verifies gb value
	 * @param gbContent
	 */
	private void verifyAutoSEODesc(Content gbContent){
		String sModelNumber = gbContent.getMfr() == null?"":gbContent.getMfr().getModelNo();
		int i = CompareValuesUtility.getPositionInList("L", gbContent.getDesc(), "type", Desc.class);
		String desc = null;
		
		if(i != -1)
			desc = gbContent.getDesc().get(i).getVal();
		
		//If long desc is not available or if long desc length is greater than 255, use short desc value
		if(i==-1 || desc.length()>= 255){
			i = CompareValuesUtility.getPositionInList("S", gbContent.getDesc(), "type", Desc.class);
			desc = gbContent.getDesc().get(i).getVal();
		}
				

		String seodesc=  (gbContent.getBrand()==null?"":(gbContent.getBrand().getName()+"-"))+gbContent.getName()+"-"+sModelNumber+"-"+desc;
		seodesc=seodesc.replaceAll("\\s+", " ").replaceAll("--", "-");
		seodesc=seodesc.substring(0, 1).equals("-")?seodesc.substring(1).replaceAll("--", "-"):seodesc.replaceAll("--", "-"); //to remove first hyphen and replace --
		compareValues("SEO", seodesc, gbContent.getSeo().getDesc(),"Desc");
	}
	
	
	public void verifyCuratedContents(List<CuratedContent> iaCurateds, CuratedContents curatedContents) {

		List<CuratedGrp> gbCuratedGrps = curatedContents.getCuratedGrp();// curatedContents.get(0).getCuratedGrp();

		for (CuratedContent iaCuratedContent : iaCurateds) {
			int i = CompareValuesUtility.getPositionInList(String.valueOf((Long.valueOf(iaCuratedContent.getRank()).doubleValue())),
					gbCuratedGrps, "rank", CuratedGrp.class);
					
			if (i != -1) {
				compareValues("CuratedGrpType", iaCuratedContent.getType(),gbCuratedGrps.get(i).getType());
				compareValues("CuratedGrpRank", iaCuratedContent.getRank(),GenericUtil.convertToString(gbCuratedGrps.get(i).getRank()));
				verifyNullOrEqual("CuratedGrpName", iaCuratedContent.getName(),gbCuratedGrps.get(i).getName());
				
				for (CuratedContentList iaCurContent : iaCuratedContent.getCuratedContentList()) {
					int j = CompareValuesUtility.getPositionInList(iaCurContent.getContentType(), gbCuratedGrps.get(i).getContent(), "type", Content_.class);
					if (j != -1) {
						
						Content_ currentGbContent = gbCuratedGrps.get(i).getContent().get(j);
						
						compareValues("ContentType",iaCurContent.getContentType(),currentGbContent.getType());
						verifyNullOrEqual("ContentName",iaCurContent.getContentName(),currentGbContent.getName());
						compareValues("ContentColumn",iaCurContent.getColumn(),GenericUtil.convertToString(currentGbContent.getColumn()));
						compareValues("ContentRow", iaCurContent.getRow(),GenericUtil.convertToString(currentGbContent.getRow()));
						verifyNullOrEqual("ContentData", iaCurContent.getData(), currentGbContent.getData());

						if (iaCurContent.getContentType().equalsIgnoreCase("asset")) {
							
							verifyNullOrEqual("CurAssetName", iaCurContent.getAsset().getName(), currentGbContent.getAsset().getName());
							compareValues("CurAssetURL", iaCurContent.getAsset().getImageUrl(), currentGbContent.getAsset().getUrl());
							verifyNullOrEqual("CurAssetWidth", iaCurContent.getAsset().getImageHeight(),
									GenericUtil.convertToString(currentGbContent.getAsset().getHeight()));
							verifyNullOrEqual("CurAssetHeight", iaCurContent.getAsset().getImageWidth(),
									GenericUtil.convertToString(currentGbContent.getAsset().getWidth()));
							verifyNullOrEqual("CurAssetType", iaCurContent.getAsset().getAssetType(),	GenericUtil.convertToString(currentGbContent.getAsset().getType()));
						}

					} else {
						logFailed("ContentType", iaCurContent.getContentType(),
								"Not found in GB");
					}
				}
			} else {
				compareValues("CuratedGrpName", iaCuratedContent.getName(),
						"Not found in gb");
			}
		}
		
		CompareValuesUtility.addNewMultiValuedFields();

	}

	
	
	/**
	 * Reads all attributes from published content and segregates attributes based on whether they are
	 * facet attributes or spec attributes. <br>
	 * Sets lstFacetAttributes, lstSpecAttributes, <br>
	 * attributeToVal map - Map which maps an attribute id to it's expected value (can be trademark text, value free or value id)
	 * lstAttributeVals - List of attribute value ids
	 * 
	 * @param lstPublishedAttributes - Attributes from published content
	 */
	private void segregateAttributes(List<Attribute> lstPublishedAttributes){
		
		
		for(Attribute iaContentAttr : lstPublishedAttributes ){
			if(autoIds.contains(iaContentAttr.getId())){
				if(iaContentAttr.getId().equals("873910")){
					brandCodeId = iaContentAttr.getValueFree();
				}
				if(iaContentAttr.getId().equals("1035210")){
					switch(iaContentAttr.getValueId()){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}
						
					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(iaContentAttr.getId()) )
				continue;
			boolean bFound = false;
			for(Label label : masterHierarchyAttributes.getLabels()){
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs()){
					if(iaContentAttr.getId().equals(attr.getId()) && (attr.getType().contains("search") || attr.getType().contains("label"))){
						bFound = true;
						if(attr.getType().contains("search"))
							lstFacetAttributes.add(iaContentAttr.getId());
						if( attr.getType().contains("label")){
							lstSpecAttributes.add(iaContentAttr.getId());
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());
							
						}
						attributeToGroup.put(iaContentAttr.getId(), label.getName());
						
						if(iaContentAttr.getTrademarkText() != null){
							attributeToVal.put(iaContentAttr.getId(), iaContentAttr.getTrademarkText());
						}
						else if(iaContentAttr.getValueFree() != null)
							attributeToVal.put(iaContentAttr.getId(), iaContentAttr.getValueFree());
						else if(iaContentAttr.getValueFlag() != null)
							attributeToVal.put(iaContentAttr.getId(), iaContentAttr.getValueFlag().toString());
						else if(iaContentAttr.getValueId() != null){
							lstAttributeVals.add(iaContentAttr.getValueId());
							attributeToVal.put(iaContentAttr.getId(), iaContentAttr.getValueId());
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
//							throw new IllegalArgumentException("No attribute val data found");
						
						break;
					}
					
				}
			if(bFound)
				break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(iaContentAttr.getId());
			}
		}
	}
	
	public void verifySpecsGB(List<Spec> specsJson) {
		
		if(masterHierarchyAttributes == null){
			return;
		}
		
		if(lstSpecAttributes.isEmpty()){
			CompareValuesUtility.verifyTrue(specsJson.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsJson.isEmpty(),"SpecName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsJson.isEmpty(),"SpecVal", "No specs expected", "Specs found");
			
			return;
		}
		
		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstSpecAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);
		
		verifySpecValues(attributeData, attributeValData, specsJson);
		
	}
	
	/**
	 * Validates that the groups order in specs is as per rank 
	 * @param specsJson
	 */
	private void validateGroupOrder(List<Spec> specsJson){
		
		if(!groupRanks.isEmpty() && specsJson == null){
			logFailed("SpecGroupNameOrder", groupRanks, "Specs not found");
			return;
		}
		if(groupRanks.isEmpty())
			return;
		int i =1;
		
		//Store index number of groups as found in content document
		int iSpecIndex = 1;
		Map<String, Integer> mpSpecsOrder = new HashMap<String, Integer>();
		for(Spec spec : specsJson){
			mpSpecsOrder.put(spec.getGrpName(), iSpecIndex++);
		}
		
		//Check expected order of groups with specs order found in content
		for(Integer rank : groupRanks.keySet()){
			
			if(!mpSpecsOrder.containsKey(groupRanks.get(rank))){
				logFailed("SpecGroupNameOrder",i+" :"+groupRanks.get(rank)+"("+rank+")" , "Group not found" );
				continue;
			}
			
			//If others then skip validation - validation will be done at the end
			if(rank == -1)
				continue;
			
			//If group is present then check index
			if(mpSpecsOrder.get(groupRanks.get(rank)) == i)
				CompareValuesUtility.logPassed("SpecGroupNameOrder", i+" :"+groupRanks.get(rank)+"("+rank+")",i+++" :" +groupRanks.get(rank));
			else{
				logFailed("SpecGroupNameOrder", i+" :"+groupRanks.get(rank)+"("+rank+")",mpSpecsOrder.get(groupRanks.get(rank))+" :"+ groupRanks.get(rank));
				i++;
			}
			
		}
		
		if(groupRanks.keySet().contains(-1)){
			if(mpSpecsOrder.get("Others:") != null && (mpSpecsOrder.get("Others:") == mpSpecsOrder.size()-1))
				CompareValuesUtility.logPassed("SpecGroupNameOrder", "Last :Others:",mpSpecsOrder.size()+" :Others:");
			else
				compareValues("SpecGroupNameOrder", "Last :Others:", "Index "+mpSpecsOrder.get("Others:")+" :Others:");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void verifySpecValues(Map<String, String> attribData,  Map<String, String> attribValData,
			 List<Spec> specsJson){
		
		for(String attributeId : lstSpecAttributes){
			String grpNameIA = attributeToGroup.get(attributeId)==null?"Others:":attributeToGroup.get(attributeId);
			boolean bAttributeFound = false;
			boolean bGroupFound = false;
			boolean bAttrValueFound = false;
			boolean bIsDoNotDisplaySpecFound = false;
			String displayEligibility = GreenBoxCache.isDoNotDisplay(attributeId);
			for (Spec spec : specsJson) {
				String grpNameJson = spec.getGrpName();
				if(grpNameIA.equals(grpNameJson)){
					bGroupFound = true;
					for(Attr attr : spec.getAttrs()){
						
						if(displayEligibility!= null && attr.getName().equals(displayEligibility)){
							bIsDoNotDisplaySpecFound = true;
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName",displayEligibility+ ": Do not display set("+attributeId+").  Attribute should not be in specs.", attr.getName() + " found in specs");
							break;
						}
						//Checking to prevent it getting printed everytime the same attribute is found 
						if (attr.getName().equals(attribData.get(attributeId))){
							if(!bAttributeFound){
								CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
								bAttributeFound = true;
								CompareValuesUtility.logPassed("SpecName",attribData.get(attributeId), attr.getName());
							}
							
							if(bAttributeFound && 
									(attributeToVal.get(attributeId).equals(attr.getVal()) || TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()))){
								bAttrValueFound = true;
								
								if(attributeToVal.get(attributeId).equals(attr.getVal())){
									compareValues("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}else
									compareValues("SpecVal", TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))) , attr.getVal());
								
								break;
							}
						}
					}
					
					//If attribute is donotdisplay type and is not displayed, mark as passed
					if(displayEligibility!= null && !bIsDoNotDisplaySpecFound){
						CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
						CompareValuesUtility.logPassed("SpecName", attributeId+":"+displayEligibility, "Do not display set.Not found in specs.");
					}
					//Do the following checks only for displayable attributes
					if(displayEligibility == null){
						if(!bAttributeFound){
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
						}
						if(bAttributeFound && !bAttrValueFound){
							CompareValuesUtility.logFailed("SpecVal", attributeToVal.get(attributeId), "Not found");
						}
					}
					break;
				}
			}
			
			if(!bAttributeFound && !bGroupFound)
				CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
			
			
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	
}