package com.shi.content.urlredirect;

public class URLVo {

	public String calculatedNewUrl;
	
	public String getCalculatedNewUrl() {
		if(calculatedNewUrl==null)
			calculatedNewUrl="";
		return calculatedNewUrl;
	}
	public void setCalculatedNewUrl(String calculatedNewUrl) {
		this.calculatedNewUrl = calculatedNewUrl;
	}
	public String getOldUrl() {
		return oldUrl;
	}
	public void setOldUrl(String oldUrl) {
		this.oldUrl = oldUrl;
	}
	public String getNewUrl() {
		return newUrl;
	}
	public void setNewUrl(String newUrl) {
		this.newUrl = newUrl;
	}
	public String getCatalogId() {
		return catalogId;
	}
	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}
	public URLVo(String id, String oldUrl, String newUrl, String catalogId, String createDate) {
		super();
		this.id=id;
		this.oldUrl = oldUrl;
		this.newUrl = newUrl;
		this.catalogId = catalogId;
		this.createDate = createDate;
	}
	
	public String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String oldUrl;
	public String newUrl;
	public String catalogId;
	public String createDate;
	
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
}
