package com.shi.content.wcsmigration.commons.vos;
public class CommonHierarchyVO
	{
		public CommonHierarchyVO(String idd, String name, String spinidd) {
			super();
			
			if(idd!=null)
			{
				idd=idd.replace(".0", "");
			}
			if(spinidd!=null)
			{
				spinidd=spinidd.replace(".0", "");
			}
			this.id = idd;
			this.name = name;
			this.spinid = spinidd;
		}
		private String id;
		private String name;
		private String spinid;
		public String getId() {
			return id;
		}
		public void setId(String idd) {
			
			if(idd!=null)
			{
				idd=idd.replace(".0", "");
			}
			this.id = idd;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSpinid() {
			return spinid;
		}
		public void setSpinid(String spinidd) {
			
			if(spinidd!=null)
			{
				spinidd=spinidd.replace(".0", "");
			}
			this.spinid = spinidd;
		}
		@Override
		public String toString() {
			return "[ name=" + name
					+ ", spinid=" + spinid + ", id=" + id +"]";
		}
	}
