package com.shi.content.gbcomparetests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

import com.generated.vos.content.ContentSchema;
import com.generated.vos.offer.OfferSchema;
import com.generated.vos.promos.PromoMetaSchema;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.listeners.SimpleReporter;
import com.shc.content.restutils.RestExecutor;

/**
 * 
 * Utility to fetch data based on gb apis <br>
 * Properties Used : <br>
 * 1. fields - Specify the fields to fetch <br>
 * 2. criteria - Filter criteria 
 * @Usage eg :  _blob.offer.classifications.offerType=NV,_ft.prgmType=!null
 * @author nvarsh0
 *
 */

public class FieldFetchUtilityArrayCriteria implements Runnable{

	String idToTest;
	public FieldFetchUtilityArrayCriteria(String id) {

		idToTest = id;
	}

	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp", groups="FieldFetchArray")
	public void fetchFields(String sRunParam){

		if(LoadProperties.IS_LISTBASED_RUN){
			Thread runSingleData = new Thread(new FieldFetchUtilityArrayCriteria(sRunParam));
			runSingleData.start();
			try {
				runSingleData.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		else if(LoadProperties.IS_BUCKETBASED_RUN){

			List<String> lstIdsInBucket;
			String[] filters = getFilterIfAvailable();
			if(filters != null)
				lstIdsInBucket  = RestExecutor.getFilteredIds(CollectionValuesVal.getCollection(LoadProperties.collection),
						Integer.parseInt(sRunParam),filters[0], filters[1]);
			else
				lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.getCollection(LoadProperties.collection),
						Integer.parseInt(sRunParam));
			System.out.println("Running for bucket : "+ sRunParam+"  Size "+ lstIdsInBucket.size());
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			int currentCount = 0;
			for(String id : lstIdsInBucket){
				if(LoadProperties.TESTDATALIMIT > 0 && ++currentCount > LoadProperties.TESTDATALIMIT)
					break;
				pool.execute(new FieldFetchUtilityArrayCriteria(id));

			}

			pool.shutdown();

			try {
				pool.awaitTermination(400, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} else {
			Thread runSingleData = new Thread(new FieldFetchUtilityArrayCriteria(sRunParam));
			runSingleData.start();
			try {
				runSingleData.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Checks if a ft field is specified in criteria.  If yes, then that is used to filter ids while fetching from bucket
	 * 
	 * @return
	 * String[] - String[0] is key and String[1] is val<br>
	 * null - if no ft key is specified or value of ft key is null
	 */
	private String[] getFilterIfAvailable() {
		for(String criterion : LoadProperties.CRITERIA){
			if(criterion.startsWith("_ft.") && !criterion.contains("null")){
				criterion = criterion.replaceFirst("_ft.?", "");
				String[] filters = criterion.split("=");
				filters[0] = filters[0].trim();
				filters[1] = filters[1].trim();
				return filters;
			}

		}
		return null;
	}

	@BeforeGroups(groups="FieldFetch")
	public void setupHeaders(){
		List<String> headers = new ArrayList<>();
		headers.add("Id");
		for(String field : LoadProperties.FIELDSTOFETCH){
			headers.add(field);
		}
		try {
			SimpleReporter.resultsQueue.put(headers);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		SimpleReporter.markDataResults();
	}

	/**
	 * Fetches id from the collection
	 * Validates the criteria if set and then fetches corresponding fields
	 */
	@Override
	public void run() {

		CollectionValues collectionToTest = CollectionValuesVal.getCollection(LoadProperties.collection);
		String data = RestExecutor.getJSonResponseById(collectionToTest, idToTest);		
		//System.out.println("Data : "+ data);

		if(data.equals("[]"))
			return;

		Resultvo vo = validateCriteria(data);

		if(LoadProperties.CRITERIA.size()>0 && !LoadProperties.CRITERIA.get(0).isEmpty()){
			if(!vo.isResult())
				return;
		}

		/****/
		try{
			String dataNew = "";
			if(Boolean.valueOf(System.getProperty("parseJson"))){
				switch(LoadProperties.collection){
				case "content":
					dataNew = data.substring(1, data.length()-1);
					ContentSchema content = JSONParser.parseJSON(dataNew, ContentSchema.class);
					System.out.println("Content json parse successful for " + idToTest);
					break;
				case "offer":
					dataNew = data.substring(1, data.length()-1);
					OfferSchema offer = JSONParser.parseJSON(dataNew, OfferSchema.class);
					System.out.println("Offer json parse successful for " + idToTest);
					break;
				case "previewpromo":
					dataNew = data.substring(1, data.length()-1);
					PromoMetaSchema previewpromo = JSONParser.parseJSON(dataNew, PromoMetaSchema.class);
					System.out.println("Previewpromo json parse successful for " + idToTest);
					break;
				case "promo":
					dataNew = data.substring(1, data.length()-1);
					PromoMetaSchema promo = JSONParser.parseJSON(dataNew, PromoMetaSchema.class);
					System.out.println("Promo json parse successful for " + idToTest);
					break;
				default:
					//System.out.println("Collection is not content/offer");
				}
				String _tmstmp = JsonStringParser.getJsonValueNew(dataNew, "_tmstmp");
				System.out.println(idToTest + ": _tmstmp: " + JodaDateTimeUtility.convertUnixTSToTZFormat(Long.valueOf(_tmstmp)));
			}
		}catch(Exception e){
			System.out.println("Parse exception for id: " + idToTest);
		}
		/****/

		List<String> allResults = new ArrayList<String>();
		allResults.add("=\""+idToTest+"\"");
		try{

			String val = null;
			String valout = null;

			for(String field : LoadProperties.FIELDSTOFETCH){

				if(field.contains("["))
				{
					//array field
					Set<Integer> setOfInd = vo.getMatchingIndicesMain();

					
					field=field.substring(0,field.indexOf("["));
					
					val = JsonStringParser.getJsonValueNew(data, field.trim());

					String spVals[]= val.split(";");

					for (Integer integer : setOfInd) {
						String string = spVals[integer];
					
						if(string.startsWith("\"")){
							string = string.substring(1,string.length()-1);}
						
						valout=valout==null?string:valout+","+string;
						
						
					}
					
					val = valout;
	
				}
				else
				{
					val = JsonStringParser.getJsonValueNew(data, field.trim());

					System.out.println("Val is for field "+ field+ "  "+ val);
				}


				if(field.equals("_tmstmp"))
					val = JodaDateTimeUtility.convertUnixTSToTZFormat(Long.valueOf(val));

				if(val!=null && val.startsWith("\"") && val.endsWith("\""))
					val = val.substring(1, val.length()-1);
				if(val!=null && val.startsWith("0") && StringUtils.isNumeric(val)){
					allResults.add("=\""+val+"\"");
				}
				else
					allResults.add(val);			
			}
		}catch(NullPointerException e){
			e.printStackTrace();
			System.out.println("Check id "+ idToTest);
			return;
		}

		SimpleReporter.logPassed(allResults);
	}

	private class Resultvo
	{
		public Set<Integer> getMatchingIndicesMain() {
			return matchingIndicesMain;
		}
		public void setMatchingIndicesMain(Set<Integer> matchingIndicesMain) {
			this.matchingIndicesMain = matchingIndicesMain;
		}
		public boolean isResult() {
			return result;
		}
		public void setResult(boolean result) {
			this.result = result;
		}
		Set<Integer> matchingIndicesMain;
		boolean result;
		public Resultvo(boolean result, Set<Integer> matchingIndicesMain) {
			super();
			this.result = result;
			this.matchingIndicesMain = matchingIndicesMain;
		}
	}

	/**
	 * Validates criteria.  Criteria are anded.<br>
	 * Checks each criteria value in the jsonResponse and returns true or false based on matche and mismatches
	 * 
	 * 
	 * @param jsonResponse
	 * @return true - if criteria meets<br>
	 * false - if any single criterion doesn't meet
	 */
	private Resultvo validateCriteria(String jsonResponse) {


		Set<Integer> matchingIndicesMain = null;
		Set<Integer> matchingIndices = null;
		boolean arrayField;
		boolean atLeastOneArrayCriteria=false;

		for(String criterion : LoadProperties.CRITERIA){
			String[] fieldToValue =  criterion.split("=");
			String val;
			try{
				val = JsonStringParser.getJsonValueNew(jsonResponse, fieldToValue[0].trim());
			}catch(NullPointerException e){
				System.out.println("Please check criteria field : "+ criterion);
				return new Resultvo(false,null);
			}

			if(!(val == null)){

				matchingIndices = new java.util.HashSet<Integer>();
				//"2015-11-25T00:00:00.000Z";"2015-11-25T18:00:00.000Z"
				if(val.contains(";"))
				{
					atLeastOneArrayCriteria=true;
					arrayField = true;
					String spVals[]= val.split(";");

					for (int i = 0; i < spVals.length; i++) {

						String string = spVals[i];

						if(string.startsWith("\"")){
							string = string.substring(1,string.length()-1);}

						if(string.equals(fieldToValue[1].trim()))
						{
							matchingIndices.add(i);
						}

					}

					if(matchingIndicesMain==null)
					{
						//first time
						matchingIndicesMain = new java.util.HashSet<Integer>();
						matchingIndicesMain.addAll(matchingIndices);
					}
					else
					{
						matchingIndicesMain.retainAll(matchingIndices);
					}

					continue;
				}
				else
				{
					arrayField = false;
				}


				if(!val.equals("null") && val.startsWith("\"")){
					val = val.substring(1,val.length()-1);}
			}

			if(fieldToValue[1].startsWith("!")){
				String fieldExpVal = fieldToValue[1].trim().replaceFirst("!", "");

				if(fieldExpVal.equalsIgnoreCase("null") && val == null)
					return new Resultvo(false,null);

				if(val ==null)
					continue;

				if(!(val.equals(fieldExpVal))){
					continue;
				}else
					return new Resultvo(false,null);
			}else{

				//Null check
				if(val == null){
					if(fieldToValue[1].trim().equalsIgnoreCase("null"))
						continue;
					else
						return new Resultvo(false,null);
				}

				if(val.equals(fieldToValue[1].trim())){
					continue;
				}else
					return new Resultvo(false,null);

			}
		}

		if(atLeastOneArrayCriteria)
		{
			System.out.println("matchingIndices...."+Arrays.toString(matchingIndices.toArray()));
			if(matchingIndices.isEmpty())
				return new Resultvo(false,null);
			else
				return new Resultvo(true,matchingIndicesMain);

		}
		return new Resultvo(true,null);
	}


	/**
	 * String pattern = "_blob.offer.assocs.maintAgreemt["
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode node = mapper.readTree(data);
//			System.out.println(node.get(0).get("_blob").get("offer").get("sites").g);
			System.out.println(node.get(0).get("_blob").get("offer").get("assocs").get("linkedSwatch").get(0).get("swatchImg"));
//			System.out.println(node);
		} catch (IOException e) {
			e.printStackTrace();
		}
	 */


}
