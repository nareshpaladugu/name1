package com.shi.content.utilitytests;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.utils.EmailUtils;

/**
 * @author ddaphal
 *
 */
public class UpdateDbGenericTest 
{

	private static int totalProductstoUpdate;
	private static String field = System.getProperty("fieldToAdd","");
	private static String type = System.getProperty("fieldType","STRING");
	private static String value = System.getProperty("fieldValue","");
	private static long startTime;
	private static long stopTime;
	@Test(groups="UpdateDbGenericTest")
	public void chkAvailReqTest()
	{
		try
		{
			
			startTime = System.currentTimeMillis();
			
			String ids = System.getProperty("ids","");
			String inputFile = System.getProperty("inputFile","");
			
			MongoClient mongoClient = MongoDBClient.connectToMongoDB();

			DB db = mongoClient.getDB(LoadProperties.collection);

			DBCollection dbCollection = db.getCollection(LoadProperties.collection);
			
			List<String> criteria = LoadProperties.CRITERIA;

			BasicDBObject query = new BasicDBObject();
			
			for(String c : criteria){
				if(!c.isEmpty()){
					String[] s = c.split("=");
					if(s[1].equals("true")){
						query.append(s[0],true);
					}else if(s[1].equals("false")){
						query.append(s[0],false);
					}else{
						if(s[1].equals("{}"))
						{
							query.append(s[0],new BasicDBObject());
						}
						else
						{
							query.append(s[0],s[1]);
						}
					}
				}
			}
			
			
			if(ids!=null && !ids.isEmpty())
			{
				query.append("_id",new BasicDBObject("$in",ids.split(",")));
			}
			else if(inputFile!=null && !inputFile.isEmpty()){
				try{
					FileInputStream fstream = new FileInputStream(inputFile);
					DataInputStream in = new DataInputStream(fstream);
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String strLine;
					while ((strLine = br.readLine()) != null)   {
						if(!strLine.isEmpty())
							if(ids!=null && !ids.isEmpty()){
								ids = ids + "," + strLine;
							}else{
								ids = strLine;
							}
					}
					in.close();
				}catch (Exception e){
					System.err.println("Error: " + e.getMessage());
				}
				query.append("_id",new BasicDBObject("$in",ids.split(",")));
			}
			
			//DBCursor result = dbCollection.find(query);

			//totalProductstoUpdate = result.size();

			//System.out.println("totalProductstoUpdate .... "+totalProductstoUpdate);

			BasicDBObject whatToSet = new BasicDBObject();
			
			BasicDBObject whatToUpdate = new BasicDBObject();
			
			if(value.isEmpty()){
				System.out.println("Value is empty, hence will remove field "+ field);
				whatToUpdate.append(field, "");
				whatToSet.append("$unset", whatToUpdate);
			}else{
				if(type.equals("BOOLEAN")){
					whatToUpdate.append(field, Boolean.valueOf(value));
				}
				else if(type.equals("NUMBER")){
					whatToUpdate.append(field, Integer.valueOf(value));
				}
				else if(type.equals("OBJECT")){
					BasicDBObject setObject = (BasicDBObject) com.mongodb.util.JSON.parse(value);
					whatToUpdate.append(field, setObject);
				}
				else{	
					whatToUpdate.append(field, value);
				}
				
				System.out.println("Value is not empty, hence will set field "+ field +" with value "+ value);
				whatToSet.append("$set", whatToUpdate);
			}
				
			WriteResult result = dbCollection.update(query,whatToSet,false,true);

			totalProductstoUpdate = result.getN();
			
			stopTime = (System.currentTimeMillis());
			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	@AfterClass(groups="GBCountUtility")
	public void result()
	{

		String sCustomeBody="<br><font face='Calibri' color='black' size='2'> "
				+"<br>GB : "+LoadProperties.gbServer
				+"<br>Collection : "+LoadProperties.collection
				+"<br>Field : "+field
				+"<br>Type : "+type
				+"<br>Value : "+value
				+"<br>Total Products Updated : "+totalProductstoUpdate
				+"<br>Total Execution Time : "+EmailUtils.getDurationString((stopTime-startTime)/1000)
				+ "<font face='Calibri' color='red' size='2'>" 
				+"<br><br><font face='Calibri' color='black' size='2'>";

		EmailUtils.sendEmail("GB Update Test ", sCustomeBody, null);

	}
}
