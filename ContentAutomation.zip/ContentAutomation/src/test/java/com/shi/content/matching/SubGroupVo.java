package com.shi.content.matching;

import java.util.ArrayList;
import java.util.List;

public class SubGroupVo {

	public SubGroupVo(String groupNumber,List<SingleOfferMatchDataVo> volst)
	{
		this.listOfOffers=volst;
		this.groupNumber = groupNumber;
	}

	public SubGroupVo(String groupNumber,SingleOfferMatchDataVo vo)
	{
		this.listOfOffers=new ArrayList<SingleOfferMatchDataVo>();
		this.listOfOffers.add(vo);
		this.groupNumber = groupNumber;
	}

	public SubGroupVo(String groupNumber)
	{
		this.groupNumber = groupNumber;
	}
	
	public SubGroupVo(int groupNumber)
	{
		this.groupNumber = String.valueOf(groupNumber);
	}

	public List<SingleOfferMatchDataVo> getListOfOffers() {
		return listOfOffers;
	}
	public void setListOfOffers(List<SingleOfferMatchDataVo> listOfOffers) {
		this.listOfOffers = listOfOffers;
	}
	public String getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}
	private List<SingleOfferMatchDataVo> listOfOffers;
	private String groupNumber;

}
