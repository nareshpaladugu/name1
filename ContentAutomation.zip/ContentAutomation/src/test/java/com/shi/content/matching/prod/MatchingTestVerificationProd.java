package com.shi.content.matching.prod;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.content.Kmart;
import com.generated.vos.content.Sears;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.OfferSchema;
import com.google.common.collect.Lists;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.matching.MatchingExclusionConstants;
import com.shi.content.matching.SingleOfferMatchDataVo;
import com.shi.content.matching.SubGroupVo;

/**
 * @author ddaphal
 *
 */
public class MatchingTestVerificationProd implements Runnable
{
	private String sSSINUnderTest;

	Set<String> setOfBrandsSSINLevel;

	Set<String> setOfModelsSSINLevel;

	Set<String> setOfUPCsSSINLevel;

	Set<String> setOfParentIdsSSINLevel;

	Set<String> setOfOfferIdsSSINLevel;

	String sOfferTypeSSINLevel="-NA-";

	String sMasterVerticalSSINLevel="-NA-";

	String sPkgQtySSINLevel="-NA-";

	Map<List<DefiningAttr>, Integer> mapDefAttrSSINLevel;

	Set<String> sExpectedSSINSet = null;

	public MatchingTestVerificationProd(String ssinUnderTest)
	{
		this.sSSINUnderTest = ssinUnderTest;
	}

	List<OfferSchema> offerSchemas;
	public void run() 
	{
		System.out.println("Testing SSIN : "+sSSINUnderTest);
		
		offerSchemas = new ArrayList<OfferSchema>();

		List<String> allOfferIdsUnderSSIN = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin="+sSSINUnderTest);

		List<List<String>> subList = Lists.partition(allOfferIdsUnderSSIN, 25);

		for (List<String> list : subList) {

			List<OfferSchema> offerObjs = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_SCHEMA, list);
			offerSchemas.addAll(offerObjs);
		}

		int groupNumberTracker = 1;

		setOfBrandsSSINLevel = new HashSet<String>();
		setOfModelsSSINLevel = new HashSet<String>();
		setOfUPCsSSINLevel = new HashSet<String>();
		setOfOfferIdsSSINLevel=new HashSet<String>();
		setOfParentIdsSSINLevel=new HashSet<String>();
		mapDefAttrSSINLevel=new HashMap<List<DefiningAttr>, Integer>();

		Map<String,SubGroupVo> mapOfSubGroupedByUID = new java.util.LinkedHashMap<String, SubGroupVo>();

		CompareValuesUtility.init();

		boolean siteOnlyOffer=false;

		boolean parentLevelExclusion=false;

		if(allOfferIdsUnderSSIN.isEmpty())
		{
			//Rare case
			CompareValuesUtility.addFailedDataFieldForReport("Data Error", "No Offers Found under SSIN");
		}	
		else
		{
			sExpectedSSINSet = getExpectedSSIN(offerSchemas);

			for (OfferSchema offerSchemaObj  : offerSchemas) 
			{
				/* ============= JSON Document to Matching Data VO =============*/

				SingleOfferMatchDataVo vo = getMatchingData(offerSchemaObj);

				/*============================== Check for exclusion rules ====================*/

				checkForExclusionRule(vo);

				checkForSearsOrKmartOnlyOffer(vo);

				siteOnlyOffer = siteOnlyOffer || vo.isSiteOnlySpecificOffer;

				SubGroupVo subGroupVo = mapOfSubGroupedByUID.get(vo.getUid());

				if(subGroupVo==null)
					subGroupVo=new SubGroupVo(groupNumberTracker++);

				List<SingleOfferMatchDataVo> offerListBySingleUID = subGroupVo.getListOfOffers();

				if(offerListBySingleUID == null)
					offerListBySingleUID = new ArrayList<SingleOfferMatchDataVo>();

				vo.setOfferNumberInSubGroup(offerListBySingleUID.size()+1);

				offerListBySingleUID.add(vo);
				if(vo.isExcludedAtParentLevel())
					parentLevelExclusion=true;

				subGroupVo.setListOfOffers(offerListBySingleUID);

				mapOfSubGroupedByUID.put(vo.getUid(),subGroupVo);

				setOfBrandsSSINLevel.add(vo.getBrandName());

				setOfModelsSSINLevel.add(vo.getModelNumber());

				if(!vo.getUpc().isEmpty())
					setOfUPCsSSINLevel.add(vo.getUpc());

				setOfOfferIdsSSINLevel.add(vo.getOfferid());

				setOfParentIdsSSINLevel.add(vo.getParentId());

				if(vo.getParentId().equals(sSSINUnderTest))
				{
					/*============================== if ParentId=SSIN, capture expected vertical, offer type and pkgQty ====================*/

					sMasterVerticalSSINLevel = vo.getMasterVerticalId();
					sOfferTypeSSINLevel = vo.getOfferType();
					sPkgQtySSINLevel = vo.getPackageQty();
				}
			}

			Iterator<Entry<String, SubGroupVo>> uidKeyIterator = mapOfSubGroupedByUID.entrySet().iterator();

			Set<String> upcSetByUID = null;

			Map<List<DefiningAttr>, Integer> mapAccordingtoDefAttrsUIDLevel =new LinkedHashMap<List<DefiningAttr>, Integer>();

			int ctrUID = -1;

			boolean excluded=false;
			while (uidKeyIterator.hasNext()) 
			{
				ctrUID ++;

				Entry<String, SubGroupVo> subGroupbyUIDEntry =  uidKeyIterator.next();

				List<SingleOfferMatchDataVo> offerListByUID = subGroupbyUIDEntry.getValue().getListOfOffers();

				upcSetByUID = new HashSet<String>();

				mapAccordingtoDefAttrsUIDLevel.clear();

				mapAccordingtoDefAttrsUIDLevel.put(offerListByUID.get(0).getDefiningAttrs(), 1);

				excluded=false;
				//all offer should have same UPC, for offer having null UPC, it should have matching brand model
				for (int i = 0; i < offerListByUID.size(); i++) 
				{
					SingleOfferMatchDataVo matchingDataVo = offerListByUID.get(i);


					if(!matchingDataVo.getUpc().isEmpty())
						upcSetByUID.add(matchingDataVo.getUpc());

					CompareValuesUtility.addDataFieldForReport("GroupNumber", subGroupbyUIDEntry.getValue().getGroupNumber()+"."+ matchingDataVo.getOfferNumberInSubGroup());

					CompareValuesUtility.addDataFieldForReport("OfferId", matchingDataVo.getOfferid());

					if(MatchingTestProd.exceptionVerticals.contains(matchingDataVo.getMasterVerticalId())    //if vertical is from exception list
							&& 	matchingDataVo.isSiteOnlySpecificOffer   // and if its site only specific offer
							&&  allOfferIdsUnderSSIN.size()>1) // and there are other offers also in group
					{
						CompareValuesUtility.addFailedDataFieldForReport("SiteOnly-Specific-Offer-grouped", "should be excluded from group" );
					}
					else
					{
						CompareValuesUtility.addDataFieldForReport("Missing-OfferId", "");
						CompareValuesUtility.addDataFieldForReport("Missing-Offer-Reason", "");

						//For NV items group all offer should same UID, UID subgroup size should be 1 
						if(sOfferTypeSSINLevel.equalsIgnoreCase("NV") && ctrUID>=1)
						{
							CompareValuesUtility.addFailedDataFieldForReport("UID", matchingDataVo.getUid());
						}
						else
						{
							CompareValuesUtility.addDataFieldForReport("UID", matchingDataVo.getUid());
						}

						CompareValuesUtility.addDataFieldForReport("UPC", matchingDataVo.getUpc());

						CompareValuesUtility.addDataFieldForReport("ParentId", matchingDataVo.getParentId());

						if(sMasterVerticalSSINLevel.equals(matchingDataVo.getMasterVerticalId()))
						{
							CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
						}
						else
						{
							CompareValuesUtility.logFailed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
						}

						CompareValuesUtility.compareValues("OfferType", sOfferTypeSSINLevel,matchingDataVo.getOfferType());

						CompareValuesUtility.addDataFieldForReport("Brand", matchingDataVo.getBrandName());

						CompareValuesUtility.addDataFieldForReport("Model", matchingDataVo.getModelNumber());

						CompareValuesUtility.addDataFieldForReport("ProgramType", matchingDataVo.getProgramType());

						CompareValuesUtility.compareValues("PackageQty", sPkgQtySSINLevel,matchingDataVo.getPackageQty());

						CompareValuesUtility.addDataFieldForReport("DivLine", matchingDataVo.getDivLine());

						if(mapAccordingtoDefAttrsUIDLevel.get(matchingDataVo.getDefiningAttrs())==null)
						{
							CompareValuesUtility.addFailedDataFieldForReport("DefAttrs", matchingDataVo.getDefiningAttrsStr());
						}
						else
						{
							CompareValuesUtility.addDataFieldForReport("DefAttrs", matchingDataVo.getDefiningAttrsStr());
						}

						Integer ys2 = mapDefAttrSSINLevel.get(matchingDataVo.getDefiningAttrs());

						if(ys2==null)
						{
							mapDefAttrSSINLevel.put(matchingDataVo.getDefiningAttrs(),1);
						}
						else
						{
							mapDefAttrSSINLevel.put(matchingDataVo.getDefiningAttrs(),ys2++);
						}

						if(matchingDataVo.isSingleItemGroupNeeded())
						{
							try {
								if(isGroupContainsSingleItemByUID(matchingDataVo.getUid()))
								{
									excluded=true;
									CompareValuesUtility.addDataFieldForReport("Single-Offer-SubGroup-Reason", matchingDataVo.getSingleItemGroupReason());
								}
								else
								{
									CompareValuesUtility.addFailedDataFieldForReport("Single-Offer-SubGroup-offercount", "Found No/Multiple Offers");
								}
							} catch (Exception e) {

								CompareValuesUtility.addFailedDataFieldForReport("Exception", "Single-Offer-SubGroup check : "+e.getMessage());
							}
						}

						if(!excluded && i == offerListByUID.size())
						{
							//OfferCount-By-UID check
							CompareValuesUtility.compareValues("OfferCount-By-UID",offerListByUID.size(),RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"uid="+subGroupbyUIDEntry.getKey().toString()).size());
						}
					}
				}

				//here UPC set should not be more than 1 (it can be 0 or 1)

				Set<String> upcSetByUIDChk = new HashSet<String>();
				for (String singleupc : upcSetByUID) {
					upcSetByUIDChk.add(StringUtils.leftPad(singleupc, 14, "0"));
				}
				
				if(upcSetByUIDChk.size()>1)
				{
					CompareValuesUtility.addFailedDataFieldForReport("MultipleUPC under same UID", StringUtils.join(upcSetByUID, ","));
				}

			}

			/*================ ensure parent item is not grouped with any other item as its excluded at parent level===========*/
			if( parentLevelExclusion  )
			{
				try {
					if( !isGroupContainsSingleItemBySsinAndParentId(sSSINUnderTest, sSSINUnderTest))
						CompareValuesUtility.addDataFieldForReport("Single-Offer-Group", "Found Multiple Items(ParentIds)");
				} catch (Exception e) {
					CompareValuesUtility.addDataFieldForReport("Exception","Single-Offer-Group check : "+ e.getMessage());
				}
			}

			if(sExpectedSSINSet.contains(sSSINUnderTest))
				CompareValuesUtility.logPassed("SSIN", sSSINUnderTest, sSSINUnderTest);
			else
				CompareValuesUtility.logFailed("SSIN", StringUtils.join(sExpectedSSINSet, ","), sSSINUnderTest);
		}

		CompareValuesUtility.setupResult(this.sSSINUnderTest, true);

		clean();

	}

	/**
	 * Set all instance variable to null
	 */
	public void clean()
	{
		sSSINUnderTest=null;

		setOfBrandsSSINLevel=null;

		setOfModelsSSINLevel=null;

		setOfUPCsSSINLevel=null;

		setOfParentIdsSSINLevel=null;

		setOfOfferIdsSSINLevel=null;

		sOfferTypeSSINLevel=null;

		sMasterVerticalSSINLevel=null;

		sPkgQtySSINLevel=null;

		mapDefAttrSSINLevel=null;

	}

	/**
	 * Checks for exclusion logic w.r.t Model_no,Model,ProgramType,Division,Division Line
	 * @param offerSchema
	 * @return
	 */
	private void checkForExclusionRule(SingleOfferMatchDataVo vo)
	{
		vo.setSingleItemGroupNeeded(false);
		vo.setExcludedAtParentLevel(false);
		//----------------------------------------------------------------------------------


		if(vo.getOfferType().equalsIgnoreCase("S") || vo.getOfferType().equalsIgnoreCase("HS") || vo.getIsUvd())
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setExcludedAtParentLevel(true);
		}

		//----------------------------------------------------------------------------------

		if(vo.getUpc().equals("000000000000") || vo.getUpc().equals("0000000000000") )
		{
			//for these upcs single group needed
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("UPC exclusion : 00000000000000");
		}
		List<String> brandsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedBrands.split(","));

		List<String> modelsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedModels.split(","));

		if(vo.getOfferid().startsWith("028") || vo.getOfferid().startsWith("095") || vo.getOfferid().startsWith("090") )
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Division :  028,090,095");	
		}

		if(brandsToExclude.contains(vo.getBrandName()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Brand");
		}

		if(modelsToExclude.contains(vo.getModelNumber()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Models");
		}

		List<String> divLinesToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedDivLines.split(","));

		if(vo.getDivLine()!=null && !vo.getDivLine().isEmpty())
		{
			for (String divline : divLinesToExclude) {

				if(vo.getDivLine().startsWith(divline))
				{
					vo.setSingleItemGroupNeeded(true);
					vo.setSingleItemGroupReason("Execluded DivLines");
				}
			}
		}
	}

	/**
	 * Json Document to Matching Data VO
	 * @param jsonObject
	 * @return
	 */
	private SingleOfferMatchDataVo getMatchingData(OfferSchema  offSch)
	{
		Offer offer = offSch.getBlob().getOffer();

		SingleOfferMatchDataVo vo =new SingleOfferMatchDataVo();

		vo.setOfferid(offer.getId());

		vo.setBrandName(offer.getBrandName()==null?"":offer.getBrandName().toString());

		try {
			vo.setMasterVerticalId(String.valueOf(offer.getTaxonomy().getMaster().getHierarchy().get(0).getId()));
		} catch (Exception e) {
			vo.setMasterVerticalId("");
			System.out.println("Master vertical not found..."+vo.getOfferid());
		}

		vo.setUpc( offer.getAltIds().getUpc()==null?"": offer.getAltIds().getUpc());
		
		vo.setBrandCodeId(offer.getBrandCodeId()==null?"":offer.getBrandCodeId());

		vo.setSpinId( offer.getAltIds().getSpinId()==null?"": offer.getAltIds().getSpinId());

		vo.setProgramType(offSch.getFt().getPgrmType());

		vo.setUid(offer.getIdentity().getUid()==null?"": offer.getIdentity().getUid());

		vo.setSsin( offer.getIdentity().getSsin()==null?"": offer.getIdentity().getSsin());

		vo.setWebSitesHie(offer.getTaxonomy().getWeb().getSites());

		vo.setParentId(offer.getIdentity().getParentId());

		vo.setModelNumber(offer.getModelNo()==null?"":offer.getModelNo());

		vo.setDivLine(offSch.getSearch().getHierarchy());

		vo.setOfferType(offer.getClassifications().getOfferType().toString());

		vo.setIsUvd(offer.getClassifications().getIsUvd()==null?false: offer.getClassifications().getIsUvd());

		vo.setPackageQty(offer.getPackageQty()==null?"":offer.getPackageQty());

		vo.setDefiningAttrs(offer.getDefiningAttrs());

		return vo;
	}

	/**
	 * No. of offers returned for SSIN and parentId has to be same	
	 * @param ssin
	 * @param parentId
	 * @return
	 */
	private boolean isGroupContainsSingleItemBySsinAndParentId(String ssin, String parentId)
	{
		List<String> offIdsListBySSIN = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin="+ ssin);

		List<String> offIdsListByParId = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+ parentId);

		offIdsListBySSIN=offIdsListBySSIN==null?new ArrayList<String>():offIdsListBySSIN;

		offIdsListByParId=offIdsListByParId==null?new ArrayList<String>():offIdsListByParId;

		if(offIdsListBySSIN.isEmpty() && offIdsListByParId.isEmpty() )
		{
			return false;
		}

		Set<String> ssinOfferList = new HashSet<>(offIdsListBySSIN);

		Set<String> parentIdOfferList = new HashSet<>(offIdsListByParId);

		parentIdOfferList.removeAll(ssinOfferList);

		if(parentIdOfferList.isEmpty())
		{
			//yes single group
			return true;
		}

		return false;
	}

	private boolean isGroupContainsSingleItemByUID(String uid)
	{
		List<String> offersByUID = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid="+ uid);

		offersByUID=offersByUID==null?new ArrayList<String>():offersByUID;

		if(offersByUID.size()==1 )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	private void checkForSearsOrKmartOnlyOffer(SingleOfferMatchDataVo vo)
	{
		String programType = vo.getProgramType();

		Sears sears = vo.getWebSitesHie().getSears();
		Kmart kmart = vo.getWebSitesHie().getKmart();


		if( (programType.equalsIgnoreCase("sears")  && (kmart==null )) ||
				(programType.equalsIgnoreCase("kmart")  && (sears==null )) )
		{

			List<String> idsList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"spinId="+vo.getSpinId());

			if(idsList!=null && idsList.size()==1)
			{
				vo.setSiteOnlySpecificOffer(true);
			}
		}

		vo.setSiteOnlySpecificOffer(false);
	}


	public static Set<String> getExpectedSSIN(List<OfferSchema> offerDataForSSINCalc)
	{
		/*Picking SSIN(Content of an offer) rules: 			SEARS -->KMART-> FBM --> FBS --> DSS --> CPC*/
		/*		CPC		DSS		FBM		FBS		HS		Kmart		S		Sears		UVD		UVD-DUMMY		 */

		Map<String,Set<String>> searsMap = new TreeMap<String, Set<String>>();

		String sPgrmType = "";
		String currentKey = null;
		for (OfferSchema  offVo : offerDataForSSINCalc) 
		{
			sPgrmType = offVo.getFt().getPgrmType();

			switch(sPgrmType.toUpperCase())
			{
			case "SEARS":	currentKey="s1";		break;
			case "KMART":	currentKey="s2";		break;
			case "FBM":	 
			case "FBS":		currentKey="s3";		break;

			case "DSS":		currentKey="s4";		break;
			case "CPC":		currentKey="s5";		break;
			default:		
			{
				currentKey="s6";		break;
			}
			}

			Set<String> setOfParentIds = searsMap.get(currentKey);

			if(setOfParentIds==null)
			{
				setOfParentIds=new HashSet<String>();
			}

			setOfParentIds.add(offVo.getBlob().getOffer().getIdentity().getParentId());

			searsMap.put(currentKey, setOfParentIds);
		}

		Set<Entry<String, Set<String>>> entrySet = searsMap.entrySet();
		Iterator<Entry<String, Set<String>>> iterator = entrySet.iterator();

		while (iterator.hasNext()) {
			Entry<String, Set<String>> entry = iterator.next();

			if(entry.getValue()!=null)
			{
				return entry.getValue();
			}
		}

		return null;
	}
}