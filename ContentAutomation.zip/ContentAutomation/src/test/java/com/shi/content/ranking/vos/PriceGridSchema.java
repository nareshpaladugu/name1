package com.shi.content.ranking.vos;

public class PriceGridSchema {
	private Priceresponse priceresponse;

	public Priceresponse getPriceresponse() {
		return priceresponse;
	}

	public void setPriceresponse(Priceresponse priceresponse) {
		this.priceresponse = priceresponse;
	}



}
