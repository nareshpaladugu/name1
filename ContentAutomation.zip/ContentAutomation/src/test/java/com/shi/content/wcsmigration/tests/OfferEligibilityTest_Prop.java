package com.shi.content.wcsmigration.tests;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.generated.vos.offerattrs.Offerattrs;
import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.commons.vos.SyncVo;
import com.shi.content.wcsmigration.verifications.OfferEligibilityTest_Prop_Verifications;

/**
 * @author ddaphal
 *
 */
public class OfferEligibilityTest_Prop {

	public static List<SyncVo> SyncFieldsList = new LinkedList<SyncVo>();

	@Test(dataProvider="sourceIdProvider",groups="OfferattrsToOfferTest_PropMode")


	public void offerSyncTest(ArrayList<String> offerIds)
	{
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("bucket"))
		{
			List<String> lstValues = new ArrayList<String>();

			if(LoadProperties.RUN_PARAMS.contains("-")){
				String[] range = LoadProperties.RUN_PARAMS.split("-");
				for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
					lstValues.add(i.toString());
				}
				System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

			}else{
				lstValues = Arrays.asList(LoadProperties.RUN_PARAMS.split(","));
			}

			for (Iterator<String> iterator = lstValues.iterator(); iterator.hasNext();) 
			{
				String string = iterator.next();

				//List<String> lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER, Integer.parseInt(string));
				List<String> lstIdsInBucket  = RestExecutor.getFilteredIds(gb1,CollectionValuesVal.OFFER_ATTR, Integer.parseInt(string), "pgrmType", "Kmart");
				lstIdsInBucket.addAll(RestExecutor.getFilteredIds(gb1,CollectionValuesVal.OFFER_ATTR, Integer.parseInt(string), "pgrmType", "Sears"));

				System.out.println("Running for bucket : "+ string+"  Size "+ lstIdsInBucket.size());

				List<List<String>> subList = Lists.partition(lstIdsInBucket, 25);

				for (Iterator<List<String>> iterator2 = subList.iterator(); iterator2.hasNext();) 
				{
					List<String> list =  iterator2.next();

					List<Offerattrs> allOffersAttrsGB = RestExecutor.getDataById(gb1,CollectionValuesVal.OFFER_ATTR, list);

					pool.execute(new OfferEligibilityTest_Prop_Verifications(allOffersAttrsGB,list));

				}
			}
		}
		else
		{
			List<List<String>> subList = Lists.partition(offerIds, LoadProperties.CHUNK_SIZE);

			for (Iterator<List<String>> iterator = subList.iterator(); iterator.hasNext();) 
			{
				List<String> list =  iterator.next();

				List<Offerattrs> allOffersGB = RestExecutor.getDataById(gb1,CollectionValuesVal.OFFER_ATTR, list);

				pool.execute(new OfferEligibilityTest_Prop_Verifications(allOffersGB,list));

			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

	}

	@DataProvider(name="sourceIdProvider", parallel=true)
	public Object[][] sourceIdProvider()
	{
		List<String> offerIds = new java.util.ArrayList<String>();

		String sOfferIds = LoadProperties.RUN_PARAMS;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("fileMode"))
		{

			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");

			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty() )
					{
						offerIds.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}
		else
		{
			offerIds.addAll(Arrays.asList(sOfferIds.split(",")));
		}

		return new Object[][] { { offerIds} };
	}

	public static String gb1 ;

	public static String gb2 ;

	public static String GroupName="Entire";
	@BeforeSuite(groups="OfferattrsToOfferTest_PropMode")
	public void read()
	{
		/*gb1 = System.getProperty("gb1","greenvip.qa.ch3.s.com:8080");

		gb2 = System.getProperty("gb2","greenvip.qa.ch3.s.com:8080");
		*/
		gb1 = System.getProperty("gb1","batchgbapivip.prod.ch4.s.com");

		gb2 = System.getProperty("gb2","greenvip.prod.ch4.s.com");
		
		
		System.out.println("GB1 .... "+gb1);
		System.out.println("GB2 .... "+gb2);

		GroupName= System.getProperty("GroupName","Entire");

		LoadProperties.setCustomMsgForEmail("GroupName .......... "+GroupName, MSGTYPE.SUCCESS  );

		System.out.println("------------------- \n GroupName : "+GroupName +"\n------------------- ");

		SyncFieldsList = new LinkedList<SyncVo>();

		String f1,f2,f3,f4,f5,f6,f7;

		try{

			String sMappingFile=System.getProperty("rulesMappingFile","src/test/resources/offersync/offerSyncFields.csv");

			File f=new File(sMappingFile);

			if(!f.exists())
			{
				System.out.println("################ Taking default file, file specified by user not exists ##########");

				sMappingFile = "src/test/resources/offersync/offerSyncFields.csv";
			}


			FileInputStream fstream = new FileInputStream(sMappingFile);


			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			int i=0;
			int y=0;
			while ((strLine = br.readLine()) != null)   {
				if(i==0)
				{
					i++;
					continue;
				}

				i++;
				System.out.println (strLine);

				String strLineSp[]= strLine.split(",");

				y=0;

				try { f1=strLineSp[y++];} catch (Exception e) {	f1=""; 	}
				try { f2=strLineSp[y++];} catch (Exception e) {	f2=""; 	}
				try { f3=strLineSp[y++];} catch (Exception e) {	f3=""; 	}
				try { f4=strLineSp[y++];} catch (Exception e) {	f4=""; 	}
				try { f5=strLineSp[y++];} catch (Exception e) {	f5=""; 	}
				try { f6=strLineSp[y++];} catch (Exception e) {	f6=""; 	}
				try { f7=strLineSp[y++];} catch (Exception e) {	f7=""; 	}

				if(GroupName.equalsIgnoreCase("Entire") || GroupName.equalsIgnoreCase(f5))
				{
					SyncFieldsList.add(new SyncVo(f1,f2,f3,f4,f5,f6,f7));
				}
			}
			in.close();

			System.out.println("got field : "+SyncFieldsList.size());
		}catch (Exception e){//Catch exception if any
			e.printStackTrace();
			System.err.println("Error: " + e.getMessage());
		}
	}
}
