package com.shi.content.acme.publish;

import java.net.URI;

import com.generated.vos.acmematchdata.AcmeMatchData;
import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.content.Content;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class AcmeKafkaToGBVerifications<T> implements Runnable {

	com.generated.vos.acmematchdata.Item kafkaAcmeMsg;
	String idToTest;
	String sGuid;
	String sSsin;
	String createdTS;
	String reconciledTS;
	Boolean isVarParent;

	public AcmeKafkaToGBVerifications(AcmeMatchData acmeMatchData) {
		this.kafkaAcmeMsg = acmeMatchData.getItem();
		this.createdTS = acmeMatchData.getMetaData().getCreatedTs();
		this.idToTest = kafkaAcmeMsg.getItemId();
		this.reconciledTS = acmeMatchData.getItem().getReconciledTs();
		this.sGuid = acmeMatchData.getItem().getGuid();
		this.sSsin = acmeMatchData.getItem().getSsin();

	}

	public void run() {

		System.out.println("Acme id: " + idToTest);
		String offerId = null;
		String contentId = null;

		try {

			/*{"item":{"guid":"fafe4aa7-b626-45f0-b126-28723c09e271","matchAuthority":"ACME"
			 * ,"matchContentId":"6445880899","matchContentOwnerId":"9371","sellerId":"9371",
			 * "ssin":"SPM6445880899","matchedTs":"2016-09-07T17:34:30Z","reconciledTs":"2016-09-07T17:34:30Z",
			 * "itemId":"6445880899","contributionCount":2},"metaData":{"createdTs":"2016-09-07T17:34:38Z","versionNumber":"5.0"}}*/


			String acmeSourceId = kafkaAcmeMsg.getItemId();

			String sSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+acmeSourceId;
			String parentResponse = RestExecutor.getJSonResponse(new URI(sSrcURL));
			AcmeSourceById acmeSource = JSONParser.parseJSON(parentResponse, AcmeSourceById.class);

			if(acmeSource==null || acmeSource.getItem()==null)
			{
				CompareValuesUtility.addFailedDataFieldForReport("acmeSource", acmeSourceId);
				CompareValuesUtility.addFailedDataFieldForReport("acmeSource-error", "Source Not Found");
				CompareValuesUtility.setupResult(idToTest, true);
				return;
			}

			if(acmeSource.getItem().getAttributes().getClassifier().equalsIgnoreCase("P"))
				isVarParent = true;
			else
				isVarParent = false;

			CompareValuesUtility.init();

			if(acmeSource.getItem().getAttributes().getIsPreferredContent()!=null  && acmeSource.getItem().getAttributes().getIsPreferredContent())
			{
				//its MCR record
				System.out.println(" its MCR source ............... "+idToTest);
				
				contentId =  "MCR" + idToTest;
				offerId = null;
				
				APIResponse<Content> contentResp = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, contentId);
				Content gbContent = (Content) contentResp.getT();

				if (gbContent == null) {
					CompareValuesUtility.addFailedDataFieldForReport("contentId", contentId);
					CompareValuesUtility.addFailedDataFieldForReport("Error", "Content Not found in GB");
					CompareValuesUtility.setupResult(idToTest, true);
					return;
				}
			}
			else
			{

				if(!isVarParent){

					switch(acmeSource.getItem().getAttributes().getProgramType()){
					case "FBM":
					case "DSS":
						offerId = "SPM" + idToTest;
						contentId = offerId;
						break;

					case "FBS":
						offerId = acmeSource.getItem().getAttributes().getDartPartNumber();
						contentId = offerId;
						break;

					case "CPC":
						String sellerResp = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, kafkaAcmeMsg.getSellerId());
						String aggrId = JsonStringParser.getJsonValue(sellerResp, "{_blob{seller{programs{cpc{aggregatorId}}}}}");
						if(aggrId!=null && !aggrId.equals("0")){
							offerId = "SP" + aggrId + "A" + kafkaAcmeMsg.getSellerId() + "S" + idToTest;
						}else{
							offerId = "SPA" + kafkaAcmeMsg.getSellerId() + "S" + idToTest;
						}						
						contentId = offerId;
						break;

					case "SEARS":
						offerId = acmeSource.getItem().getAttributes().getPartNumber().getSearsPartNumber();
						contentId = offerId + "P";
						break;

					case "KMART":
						offerId = acmeSource.getItem().getAttributes().getPartNumber().getKmartPartNumber();
						contentId = offerId + "P";
						break;

					default:
						System.out.println("Invalid programType for id: " + idToTest);
						return;	
					}

					
					//String resp = RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER, offerId);
					APIResponse<Offer> offerResp = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId);
					Offer gbOffer = (Offer) offerResp.getT();

					if (gbOffer == null) {
						CompareValuesUtility.addFailedDataFieldForReport("offerId", offerId);
						CompareValuesUtility.addFailedDataFieldForReport("Error", "Offer Not found in GB");
						CompareValuesUtility.setupResult(idToTest, true);
						return;
					}

					if(JodaDateTimeUtility.isFirstDateBeforeSecond(kafkaAcmeMsg.getReconciledTs(), gbOffer.getTimeChecker()==null?null:gbOffer.getTimeChecker().getIaSsinUidUpdate())){
						CompareValuesUtility.addDataFieldForReport("offerId", offerId);
						CompareValuesUtility.addDataFieldForReport("Error", "Message not latest. Message TS=" + kafkaAcmeMsg.getReconciledTs() + " GB offer TS=" + gbOffer.getTimeChecker().getIaSsinUidUpdate());
						CompareValuesUtility.setupResult(idToTest, true);
						return;
					}

					String offerType="";
					try {
						offerType = gbOffer.getClassifications().getOfferType().toString();
					} catch (Exception e) {
						offerType="Not Available";
					}
					//offerResp.getFtFieldValue("offerType");

					if(offerType.equals("NV")){
						APIResponse<Content> contentResp = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, contentId);
						Content gbContent = (Content) contentResp.getT();

						if (gbContent == null) {
							CompareValuesUtility.addFailedDataFieldForReport("contentId", contentId);
							CompareValuesUtility.addFailedDataFieldForReport("Error", "NV Content Not found in GB");
							CompareValuesUtility.setupResult(idToTest, true);
							return;
						}

						verifyOffer(offerResp, offerId);
						verifyContent(contentResp, contentId);

					}else if(offerType.equals("V")){
						verifyOffer(offerResp, offerId);

					}else{
						CompareValuesUtility.addFailedDataFieldForReport("offerId", offerId);
						CompareValuesUtility.addFailedDataFieldForReport("Error", "OfferType Not valid in GB");
						CompareValuesUtility.setupResult(idToTest, true);
						return;			
					}
				}else{

					switch(acmeSource.getItem().getAttributes().getProgramType()){
					case "FBM":
					case "DSS":
					case "FBS":
						contentId = TestUtils.generateVariationId(kafkaAcmeMsg.getSellerId(), 
								acmeSource.getItem().getAttributes().getVarGroupId(), acmeSource.getItem().getAttributes().getProgramType());;
								break;

					case "SEARS":
						contentId = acmeSource.getItem().getAttributes().getPartNumber().getSearsPartNumber() + "P";
						break;

					case "KMART":
						contentId = acmeSource.getItem().getAttributes().getPartNumber().getKmartPartNumber() + "P";
						break;

					default:
						System.out.println("Invalid programType for id: " + idToTest);
						return;	
					}

					APIResponse<Content> contentResp = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, contentId);
					Content gbContent = (Content) contentResp.getT();

					if (gbContent == null) {
						CompareValuesUtility.addFailedDataFieldForReport("contentId", contentId);
						CompareValuesUtility.addFailedDataFieldForReport("Error", "V Content Not found in GB");
						CompareValuesUtility.setupResult(idToTest, true);
						return;
					}

					if(JodaDateTimeUtility.isFirstDateBeforeSecond(kafkaAcmeMsg.getReconciledTs(), gbContent.getTimeChecker()==null?null:gbContent.getTimeChecker().getIaSsinUidUpdate())){
						CompareValuesUtility.addDataFieldForReport("contentId", contentId);
						CompareValuesUtility.addDataFieldForReport("Error", "Message not latest. Message TS=" + kafkaAcmeMsg.getReconciledTs() + " GB content TS=" + gbContent.getTimeChecker().getIaSsinUidUpdate());
						CompareValuesUtility.setupResult(idToTest, true);
						return;
					}

					verifyContent(contentResp, contentId);
				}
			}
			CompareValuesUtility.setupResult(idToTest, true);

		} catch (Throwable e) {
			System.out.println("Check this id :" + idToTest);
			e.printStackTrace();
			CompareValuesUtility.addDataFieldForReport("Exception", e.toString(), INFOTYPE.FAILED);
			CompareValuesUtility.setupResult(idToTest, true);

		} finally {
			CompareValuesUtility.teardown();
		}
	}

	private void verifyContent(APIResponse<Content> contentResp, String contentId) {

		Content gbContent = (Content) contentResp.getT();

		CompareValuesUtility.addDataFieldForReport("contentId", contentId);
		CompareValuesUtility.addDataFieldForReport("cntLastModifiedBy", gbContent.getMeta().getLastModifiedBy());

		CompareValuesUtility.compareValues("cntIdenSsin", sSsin, gbContent.getIdentity()==null?null:gbContent.getIdentity().getSsin());
		CompareValuesUtility.compareValues("cntSrchSsin", sSsin, contentResp.getSearchFieldValue("ssin"));

		if(!isVarParent){
			CompareValuesUtility.compareValues("cntIdenUid", sGuid, gbContent.getIdentity()==null?null:gbContent.getIdentity().getUid());
			CompareValuesUtility.compareValues("cntSrchUid", sGuid, contentResp.getSearchFieldValue("uid"));
			CompareValuesUtility.compareValues("offerCnt", kafkaAcmeMsg.getContributionCount()==null?null:kafkaAcmeMsg.getContributionCount().intValue(), gbContent.getIdentity()==null?null:gbContent.getIdentity().getOfferCnt().intValue());
		}else{
			//TODO - to check time
			//CompareValuesUtility.compareValues("iaSsinUidUpdateTS", kafkaAcmeMsg.getReconciledTs(), gbContent.getTimeChecker()==null?null:gbContent.getTimeChecker().getIaSsinUidUpdate());
		}

	}

	private void verifyOffer(APIResponse<Offer> offerResp, String offerId) {

		Offer gbOffer = (Offer) offerResp.getT();

		CompareValuesUtility.addDataFieldForReport("offerId", offerId);
		CompareValuesUtility.addDataFieldForReport("ofrLastModifiedBy", gbOffer.getMeta().getLastModifiedBy());

		CompareValuesUtility.compareValues("ofrIdenSsin", sSsin, gbOffer.getIdentity().getSsin());
		CompareValuesUtility.compareValues("ofrSrchSsin", sSsin, offerResp.getSearchFieldValue("ssin"));
		CompareValuesUtility.compareValues("ofrIdenUid", sGuid, gbOffer.getIdentity().getUid());
		CompareValuesUtility.compareValues("ofrSrchUid", sGuid, offerResp.getSearchFieldValue("uid"));

		//TODO - to check time stamp
		//CompareValuesUtility.compareValues("iaSsinUidUpdateTS", kafkaAcmeMsg.getReconciledTs(), gbOffer.getTimeChecker()==null?null:gbOffer.getTimeChecker().getIaSsinUidUpdate());
	}

}