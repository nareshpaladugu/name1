package com.shi.content.utilitytests;

import java.io.BufferedWriter;

import org.testng.annotations.Test;

public class XMLGenerator {

	@Test(groups="XMLGenerator")
	public void testGen()
	{

		String header = " <catalog xmlns=\"http://spin.sears.com/catalog/v6\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
				"xsi:schemaLocation=\"http://spin.sears.com/SPIN/s/schema/rest/item/export/v6/spin-storeonly-offering.xsd\" store-id=\"##DAFFY_STORE##\" " +
				"store-hierarchy-id=\"##DAFFY_SHID##\">";

		String footer =  " <summary-stats> "+ 
				" \n<item-counts> "+
				" \n<total>11166</total> "+
				" \n<expected>10565</expected> "+
				" \n<banned>601</banned> "+
				" \n<errored-out>0</errored-out> "+
				" \n</item-counts> "+
				" \n<processing-times> "+
				" \n<per-item-average-ms>0</per-item-average-ms> "+
				" \n<total-seconds>0</total-seconds> "+
				" \n</processing-times> "+
				" \n</summary-stats> " +
				" \n</catalog>";

		//String footer = "\n</catalog>";

		String sSingleOffer = FileOperations.readTextFile("src/test/resources/store_single_product_offer.txt");

		int division = Integer.parseInt(System.getProperty("divisions",""));

		String sOutputFolder = System.getProperty("output_folder","");

		String sStore = System.getProperty("store","");

		if(sStore==null||sStore.isEmpty())
		{

			sStore="Sears";
		}

		String partString ="";

		//int division = 2;

		String sStartPart = System.getProperty("StartPartNumber","10000000000");

		long part = Long.parseLong(sStartPart);


		int iNoOfPartNumbersPerFile = Integer.parseInt(System.getProperty("NoOfPartNumbersPerFile",""));

		System.out.println("================================================");

		System.out.println("division.."+division);

		System.out.println("sOutputFolder.."+sOutputFolder);

		System.out.println("iNoOfPartNumbersPerFile.."+iNoOfPartNumbersPerFile);

		System.out.println("sStartPart.... "+sStartPart);

		System.out.println("sStore ... "+sStore);

		System.out.println("================================================");

		for (int dd = 1; dd <= division; dd++) 
		{

			BufferedWriter bw = FileOperations.openFileToWrite(sOutputFolder+"spin-storeonly-offering_"+sStore.toLowerCase()+"_"+dd+".xml");

			FileOperations.writeToFile(bw, header.replaceFirst("##DAFFY_SHID##",String.valueOf(dd) ));

			for (int i = 0; i < iNoOfPartNumbersPerFile; i++) 
			{
				if(sStore.equalsIgnoreCase("sears"))
				{
					header=header.replace("##DAFFY_STORE##", "2");
					partString="<sears-part-number>"+part+"</sears-part-number>";
				}
				else
				{
					header=header.replace("##DAFFY_STORE##", "1");
					partString="<kmart-part-number>"+part+"</kmart-part-number>";
				}

				FileOperations.writeToFile(bw, sSingleOffer.replaceFirst("##DAFFY_PNUMBER##",partString)
						.replaceFirst("##DAFFY_PNAME##",part+""));
				
				part++;
			}

			FileOperations.writeToFile(bw, footer);

			FileOperations.closeFileToWrite(bw);

		}
	}

}
