package com.shi.content.uvdTest;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.uvd.AutomotiveProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

/**
 * @author ddaphal
 *
 */
public class UvdTest7_30
{

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void testUvdLoad7_30(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);

		String sSite = sFileName.split("\\.")[0].split("-")[1];
		System.out.println(sSite);

		BlockingQueue<List<AutomotiveProductOffer>> productOfferQueue = new LinkedBlockingQueue<List<AutomotiveProductOffer>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<AutomotiveProductOffer> prodThread = new ChunkProducerThread<AutomotiveProductOffer>(sFileName, productOfferQueue, AutomotiveProductOffer.class,"automotive-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<AutomotiveProductOffer> nodeToTest = productOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new UvdLoadContentVerification(nodeToTest.get(0)));
					//pool.execute(new UVDLoadOfferVerification(nodeToTest.get(0)));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
