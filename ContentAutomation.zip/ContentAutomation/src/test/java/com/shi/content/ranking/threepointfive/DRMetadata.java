package com.shi.content.ranking.threepointfive;

public class DRMetadata {

	@Override
	public String toString() {
		return "DRMetadata [gb=" + gb + ", pricinggrid=" + pricinggrid
				+ ", startBucket=" + startBucket + ", endBucket=" + endBucket
				+ ", tellurideApi=" + tellurideApi + ", emailReceipents="
				+ emailReceipents + ", isForFuture=" + isForFuture
				+ ", emailNotificationsEnabled=" + emailNotificationsEnabled
				+ ", dealsStartDate=" + dealsStartDate + ", accessToken="
				+ accessToken + "]";
	}
	
	public String getGb() {
		return gb;
	}
	public void setGb(String gb) {
		this.gb = gb;
	}
	public String getPricinggrid() {
		return pricinggrid;
	}
	public void setPricinggrid(String pricinggrid) {
		this.pricinggrid = pricinggrid;
	}

	private String gb;
	private String pricinggrid;
	
	public int getStartBucket() {
		return startBucket;
	}
	public void setStartBucket(int startBucket) {
		this.startBucket = startBucket;
	}
	public int getEndBucket() {
		return endBucket;
	}
	public void setEndBucket(int endBucket) {
		this.endBucket = endBucket;
	}
	public String getTellurideApi() {
		return tellurideApi;
	}
	public void setTellurideApi(String tellurideApi) {
		this.tellurideApi = tellurideApi;
	}
	public String getEmailReceipents() {
		return emailReceipents;
	}
	public void setEmailReceipents(String emailReceipents) {
		this.emailReceipents = emailReceipents;
	}
	public boolean isForFuture() {
		return isForFuture;
	}
	public void setForFuture(boolean isForFuture) {
		this.isForFuture = isForFuture;
	}
	public boolean isEmailNotificationsEnabled() {
		return emailNotificationsEnabled;
	}
	public void setEmailNotificationsEnabled(boolean emailNotificationsEnabled) {
		this.emailNotificationsEnabled = emailNotificationsEnabled;
	}
	public String getDealsStartDate() {
		return dealsStartDate;
	}
	public void setDealsStartDate(String dealsStartDate) {
		this.dealsStartDate = dealsStartDate;
	}
	private int startBucket;
	private int endBucket;
	private String tellurideApi;
	private String emailReceipents;
	private boolean isForFuture;
	private boolean emailNotificationsEnabled;
	private String dealsStartDate;
	private String accessToken;
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
}
