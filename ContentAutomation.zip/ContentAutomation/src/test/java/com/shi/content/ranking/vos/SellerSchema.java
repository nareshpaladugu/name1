package com.shi.content.ranking.vos;

public class SellerSchema {
	private _Blob _blob;

	public _Blob get_blob() {
		return _blob;
	}

	public void set_blob(_Blob _blob) {
		this._blob = _blob;
	}
	

}
