package com.shi.content.international;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;

public class FixrateTest {

	@Test(groups="FixrateTests")
	public void FixrateTests() {
	
			//List<String> lstBundleIds = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER_ATTR_SCHEMA, Integer.parseInt(sRunParam));
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
				pool.execute(new FixrateVerification());
			pool.shutdown();

			try {
				pool.awaitTermination(40, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
		} 
	}




