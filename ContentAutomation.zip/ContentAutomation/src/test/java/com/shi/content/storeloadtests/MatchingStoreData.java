package com.shi.content.storeloadtests;

import java.util.List;

import com.generated.vos.store.Unit;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shi.content.storeloadtests.StoreLoadConstants;
import com.shi.content.storeloadtests.StoreLoadDataVO;
import com.shi.content.storeloadtests.StoreLoadMatchJob;
import com.shi.content.storeloadtests.StoreLoadTest;
import com.shi.content.storeloadtests.TaxGeoCountyVO;

public class MatchingStoreData {
	
	StoreLoadDataVO inputData;
	
	StoreLoadMatchJob sears;
	
	
	public void matchExpectedActualData(StoreLoadDataVO expectedObjectVo, Unit actualUnit,String site)
	{		
		
		CompareValuesUtility.addDataFieldForReport("Site",getCleanString(actualUnit.getSiteId()));
		CompareValuesUtility.compareValues("StoreID", expectedObjectVo.getStoreId() ,actualUnit.getId());
		CompareValuesUtility.compareValues("StoreName", expectedObjectVo.getName(),actualUnit.getNm());		
		CompareValuesUtility.compareValues("Address",expectedObjectVo.getAddress(),actualUnit.getStrAddr().getAddr1()==null?"":actualUnit.getStrAddr().getAddr1());
		CompareValuesUtility.compareValues("City", expectedObjectVo.getCity(),actualUnit.getStrAddr()==null?null:actualUnit.getStrAddr().getCity());
		CompareValuesUtility.compareValues("State", expectedObjectVo.getDistNo(),actualUnit.getDistrict()==null?"":actualUnit.getDistrict());
		CompareValuesUtility.compareValues("strType1", expectedObjectVo.getStrType1(),actualUnit.getStrType1()==null?"":actualUnit.getStrType1());		
		CompareValuesUtility.compareValues("strType2", expectedObjectVo.getStrType2(),actualUnit.getStrType2()==null?"":actualUnit.getStrType2());			
		CompareValuesUtility.compareValues("MngrName",expectedObjectVo.getMgrName(),actualUnit.getMgrName()==null?"":actualUnit.getMgrName());		
		CompareValuesUtility.compareValues("OpenDate", expectedObjectVo.getStartDate(),actualUnit.getOpenDt());
		CompareValuesUtility.compareValues("CloseDate",expectedObjectVo.getEndDate(),actualUnit.getCloseDt());
		CompareValuesUtility.compareValues("storeStatus",expectedObjectVo.getStrStatus(),actualUnit.getStrStatus());		
		CompareValuesUtility.compareValues("PhoneNumber",expectedObjectVo.getPhoneNo(),getCleanString(actualUnit.getStrAddr().getPhNo()));		
		CompareValuesUtility.compareValues("Zipcode", expectedObjectVo.getZipcode(), actualUnit.getStrAddr().getZipCd()==null?"":actualUnit.getStrAddr().getZipCd());
		CompareValuesUtility.verifyTrue(isLRWithinRange(actualUnit.getLatitude(),expectedObjectVo.getLattitude()), "Latitude",expectedObjectVo.getLattitude(),actualUnit.getLatitude());
		CompareValuesUtility.verifyTrue(isLRWithinRange(actualUnit.getLongitude(),expectedObjectVo.getLongitude()), "Longitude",expectedObjectVo.getLongitude(),actualUnit.getLongitude());
		CompareValuesUtility.compareValues("District", expectedObjectVo.getDistrict(), actualUnit.getStrAddr().getState()==null?null:actualUnit.getStrAddr().getState().getCd());				
		CompareValuesUtility.compareValues("DistrictNumber", expectedObjectVo.getDistNo(),actualUnit.getDistrict());
		CompareValuesUtility.compareValues("Region", expectedObjectVo.getRegion(),actualUnit.getRgn()==null?"":actualUnit.getRgn());
		
		//TODO-Null check, Site Check
		 String siteName=getCleanString(actualUnit.getSiteId()).trim();
		if(siteName.equals("sears"))
		{
		 CompareValuesUtility.compareValues("localAd", expectedObjectVo.isLocalAd(), actualUnit.getStrAttr().getSites().getSears().getLocalAd());
		}
		else if(siteName.equals("kmart"))
		{
			CompareValuesUtility.compareValues("localAd", expectedObjectVo.isLocalAd(), actualUnit.getStrAttr().getSites().getKmart().getLocalAd());
		}
		
		TaxGeoCountyVO taxGeoCountyVO = StoreLoadTest.geo_countyCode.get(expectedObjectVo.getStoreId());
		if(taxGeoCountyVO!=null)
		{
			CompareValuesUtility.compareValues("GeoCode",(taxGeoCountyVO.getGeoCode()==null)?"":taxGeoCountyVO.getGeoCode(), actualUnit.getGeoCde()==null?"":actualUnit.getGeoCde());
			CompareValuesUtility.compareValues("CountyCode",taxGeoCountyVO.getCountyCode(),actualUnit.getCountyNum());
			
		}else
		{
			CompareValuesUtility.compareValues("GeoCode","", actualUnit.getGeoCde()==null?"":actualUnit.getGeoCde());
			CompareValuesUtility.compareValues("CountyCode","",actualUnit.getCountyNum()==null?"":actualUnit.getCountyNum());
		}
		
	}
	public boolean isLRWithinRange(double valueToCheck, String expectedValue){

		double lower=calculateLowerRange(valueToCheck);
		double upper=calculateUpperRange(valueToCheck);

		if( Double.parseDouble(expectedValue) >= lower &&  Double.parseDouble(expectedValue) <= upper)
			return true;
		else
			return false;
	}	

	private  double calculateUpperRange(Double dblValue)
	{		
		return dblValue+StoreLoadConstants.THREASHHOLD;
	}
	private double calculateLowerRange(Double dblValue)
	{		
		return dblValue-StoreLoadConstants.THREASHHOLD;
	}

	// To remove Square Brackets
	public String getCleanString(List<String> strInput)
	{
		String strClean="";
		for(String strEach:strInput)
			strClean=strEach;
		return strClean;					
	}
}
