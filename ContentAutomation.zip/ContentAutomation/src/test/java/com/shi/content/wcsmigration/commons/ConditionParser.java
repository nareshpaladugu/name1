package com.shi.content.wcsmigration.commons;

import com.shi.content.wcsmigration.commons.vos.ConditionVO;


public class ConditionParser {


	public static enum Conditions
	{
		EQUALS,
		NOT_EQUALS,
		LESS_THAN,
		GREATER_THAN,
		LESS_THAN_EQUALS,
		GREATER_THAN_EQUALS,
		IN,
		NON_IN,
		START_WITH,
		CONTAINS,
	}

	public static ConditionVO parseCondition(String conditionString)
	{
		try {
			if(conditionString.contains(">="))
			{
				return new ConditionVO(conditionString.split(">=")[0],conditionString.split(">=")[1],Conditions.GREATER_THAN_EQUALS);
			}
			else if(conditionString.contains("<="))
			{
				return new ConditionVO(conditionString.split("<=")[0],conditionString.split("<=")[1],Conditions.LESS_THAN_EQUALS);
			}
			else if(conditionString.contains(">"))
			{
				return new ConditionVO(conditionString.split(">")[0],conditionString.split(">")[1],Conditions.GREATER_THAN);
			}
			else if(conditionString.contains("<"))
			{
				return new ConditionVO(conditionString.split("<")[0],conditionString.split("<")[1],Conditions.LESS_THAN);
			}
			else if(conditionString.contains("#in"))
			{
				return new ConditionVO(conditionString.split("#in")[0],conditionString.split("#in")[1],Conditions.IN);
			}
			else if(conditionString.contains("#nin"))
			{
				return new ConditionVO(conditionString.split("#nin")[0],conditionString.split("#nin")[1],Conditions.NON_IN);
			}
			else if(conditionString.contains("!="))
			{
				return new ConditionVO(conditionString.split("!=")[0],conditionString.split("!=")[1],Conditions.NOT_EQUALS);
			}
			else if(conditionString.contains("#startwith"))
			{
				return new ConditionVO(conditionString.split("#startwith")[0],conditionString.split("#startwith")[1],Conditions.START_WITH);
			}
			else if(conditionString.contains("#contains"))
			{
				return new ConditionVO(conditionString.split("#contains")[0],conditionString.split("#contains")[1],Conditions.CONTAINS);
			}
			else if(conditionString.contains("="))
			{
				return new ConditionVO(conditionString.split("=")[0],conditionString.split("=")[1],Conditions.EQUALS);
			}
			else if(conditionString.startsWith("##"))
			{
				return new ConditionVO(conditionString);
			}
					

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static String getConditionSymbol(Conditions condition)
	{
		switch (condition) 
		{

		case EQUALS:		return " = ";

		case GREATER_THAN:    return " > ";

		case GREATER_THAN_EQUALS: return " >= ";

		case LESS_THAN: return " < ";

		case LESS_THAN_EQUALS: return " <= ";

		case IN: return " IN ";

		case NON_IN:return " NOT IN ";

		case NOT_EQUALS:return " !=";

		case CONTAINS:return " CONTAINS ";

		default:

			return " UNKNOWN ";
		}
	}
}
