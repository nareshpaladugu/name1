package com.shi.content.wcstogb.giftRegi.temp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.shc.autocontent.db.DBUtil;

public class UserCollectionCache 
{
	public static Map<String,List<Map<String, String>>> mapGRGFTREG_U = new HashMap<String, List<Map<String,String>>>();

	public static Map<String,String> EVENTTYPENAME_MAP = new HashMap<String, String>();
	
	public static Map<String,String> UserRole_MAP = new HashMap<String, String>();
	
	public static void initEventTypes()
	{
		EVENTTYPENAME_MAP.putAll(DBUtil.executeQueryMultiRowMultiColumnSingleMap("select EVENTTYPE_ID,EVENTTYPENAME from GREVNTTYPE with ur"));
	}

	private static void initUserRoles(String userids)
	{
		UserRole_MAP.putAll(DBUtil.executeQueryMultiRowMultiColumnSingleMap("select userid,RGSTRNTTYPE from GRRGSTRNT where userid in ("+userids+") with ur"));
	}
	
	private static void getAllGrDetailsMap(String userIds)
	{
		String sQuery ="select * from GRGFTREG a,GRRGSTRNT b where a.giftregistry_id=b.giftregistry_id" +
				"  and b.userid in("+userIds+") order by b.userid with ur";

		mapGRGFTREG_U.putAll(DBUtil.executeQuery(sQuery ,"USERID"));
	}
	
	public static Map<String,List<Map<String, String>>> RegistryIdMap = new HashMap<String, List<Map<String,String>>>();
	
	public static void initRegistryId(String userIds)
	{
		String query = "select MEMBER_ID,MBRATTR_ID,STRINGVALUE from MBRATTRVAL where  MEMBER_ID in ("+userIds+") with ur";
		
		RegistryIdMap.putAll(DBUtil.executeQuery(query,"MEMBER_ID"));

	}
	
	public static String getListToString(Set<String> sp)
	{
		String giftregistry_ids = null;

		for (String string : sp) 
		{
			if(string!=null && !string.isEmpty())
			{
				if(giftregistry_ids==null)
					giftregistry_ids="'"+string+"'";
				else
					giftregistry_ids=giftregistry_ids+",'"+string+"'";
			}
		}

		return giftregistry_ids;
	}
	
	public static void init(Set<String> wcsUserIds)
	{
		String userids = getListToString(wcsUserIds);
		
		getAllGrDetailsMap(userids);

		System.out.println("Init 1 of 4 done ...");
		
		initUserRoles(userids);
		
		System.out.println("Init 2 of 4 done ...");
		
		initRegistryId(userids);
		
		System.out.println("Init 3 of 4 done ...");
		
		initEventTypes();
		
		System.out.println("Init 4 of 4 done ...");
		
	}
}
