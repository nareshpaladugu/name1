package com.shi.content.acme.publish;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.acmematchdata.AcmeMatchData;
import com.generated.vos.acmematchdata.Item;
import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.itemauthority.reconciled.ContentId;
import com.generated.vos.itemauthority.reconciled.OwnerId;
import com.generated.vos.itemauthority.reconciled.ReconciledResponse;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.matching.acme.AcmeMatchingCommon;



public class AcmeToKafkaVerifications<T> implements Runnable {

	com.generated.vos.acmematchdata.Item kafkaAcmeMsg;
	String idToTest;
	String sGuid;
	String createdTS;
	String reconciledTS;

	public AcmeToKafkaVerifications(AcmeMatchData acmeMatchData) {
		this.kafkaAcmeMsg = acmeMatchData.getItem();
		this.createdTS = acmeMatchData.getMetaData().getCreatedTs();
		this.idToTest = kafkaAcmeMsg.getItemId();
		this.reconciledTS = acmeMatchData.getItem().getReconciledTs();
		this.sGuid = acmeMatchData.getItem().getGuid();
	}

	public void run() {

		System.out.println("Acme Id: " + idToTest);

		CompareValuesUtility.init();

		try{
			String sSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+idToTest;
			String srcResponse = RestExecutor.getJSonResponse(new URI(sSrcURL));

			if (!srcResponse.contains("item")) {
				CompareValuesUtility.addDataFieldForReport("Exception", "Source Response Not found", INFOTYPE.FAILED);
				CompareValuesUtility.setupResult(idToTest, true);
				return;

			}

			AcmeSourceById srcJson = JSONParser.parseJSON(srcResponse, AcmeSourceById.class);

			String sReconURL = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled/"+sGuid;
			String reconResponse = RestExecutor.getJSonResponse(new URI(sReconURL));
			ReconciledResponse reconJson = JSONParser.parseJSON(reconResponse, ReconciledResponse.class);

			String reconLastUpdated = JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(reconJson.getItem().getLastUpdated()));
			String srcLastUpdated = JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(srcJson.getItem().getLastUpdated()));

			if(JodaDateTimeUtility.isFirstDateBeforeSecond(reconciledTS, srcLastUpdated)
					|| JodaDateTimeUtility.isFirstDateBeforeSecond(reconciledTS, reconLastUpdated)){
				System.out.println("Returning because source/reconciled document was updated after message was published");
				return;
			}

			if(srcJson.getItem().getAttributes().getClassifier().equals("V")){
				String pid = srcJson.getItem().getAttributes().getPid();
				String sPidSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+pid;
				String srcPidResponse = RestExecutor.getJSonResponse(new URI(sPidSrcURL));

				if (!srcPidResponse.contains("item")) {
					CompareValuesUtility.addDataFieldForReport("Exception", "Parent Source Response Not found", INFOTYPE.FAILED);
					CompareValuesUtility.setupResult(idToTest, true);
					return;
				}
				AcmeSourceById srcPidJson = JSONParser.parseJSON(srcPidResponse, AcmeSourceById.class);

				String srcPidLastUpdated = JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(srcPidJson.getItem().getLastUpdated()));

				if(JodaDateTimeUtility.isFirstDateBeforeSecond(reconciledTS, srcPidLastUpdated)){
					System.out.println("Returning because parent source document was updated after message was published");
					return;
				}
			}

			verifyItem(srcJson, reconJson);

			
			validateMatchMsg(this.kafkaAcmeMsg);

		}catch(Exception e){
			System.out.println("Exception for id:" + idToTest);
			e.printStackTrace();
			CompareValuesUtility.addDataFieldForReport("Exception", e.getStackTrace().toString(), INFOTYPE.FAILED);
		}
		CompareValuesUtility.setupResult(idToTest, true);
	}

	private void verifyItem(AcmeSourceById acmeSourceById, ReconciledResponse reconJson) {

		/*{
			  "item": {
			   -----> "guid": "35f01a8e-b579-410e-a47b-067ea33a9ba1",
			    ----->   "matchAuthority": "ACME",
			    ----->   "matchContentId": "244356547",
			    ----->   "matchContentOwnerId": "6919",
			    ----->   "sellerId": "6919",
			  ----->  "ssin": "UVD82345064P",
			 ----->   "matchedTs": "2016-09-12T15:27:41Z",
			  ----->  "reconciledTs": "2016-09-12T15:27:41Z",
			   -----> "itemId": "1117912701",
			    ----->   "contributionCount": 1
			  },
			  "metaData": {
			    "createdTs": "2016-09-12T15:27:52Z",
			    "versionNumber": "5.0"
			  }
			}
		 */
		//AcmeSourceById acmeSourceById = JSONParser.parseJSON(srcResponse, AcmeSourceById.class);

		compareValues("ItemId", acmeSourceById.getItem().getId(), idToTest);
		compareValues("Guid", acmeSourceById.getItem().getGuid(), sGuid);

		if(acmeSourceById.getItem().getAttributes().getClassifier().equals("V")){

			try {
				String sSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+acmeSourceById.getItem().getAttributes().getPid();
				String parentResponse = RestExecutor.getJSonResponse(new URI(sSrcURL));
				AcmeSourceById parentSrc = JSONParser.parseJSON(parentResponse, AcmeSourceById.class);
				String parentSSIN = parentSrc.getItem().getSsin();

				compareValues("Ssin", parentSSIN, kafkaAcmeMsg.getSsin());

			} catch (URISyntaxException e) {
				System.out.println("Exception for id:" + idToTest);
				e.printStackTrace();
			}

		}else{
			compareValues("Ssin", acmeSourceById.getItem().getSsin(), kafkaAcmeMsg.getSsin());
		}

		if(acmeSourceById.getItem().getAttributes().getProgramType().equals("SEARS") || acmeSourceById.getItem().getAttributes().getProgramType().equals("KMART")){
			compareValues("SellerId", acmeSourceById.getItem().getAttributes().getSvid(), kafkaAcmeMsg.getSellerId());
		}else{
			compareValues("SellerId", acmeSourceById.getItem().getVendorId(), kafkaAcmeMsg.getSellerId());
		}

		boolean needToHitSource = false;

		OwnerId owner = reconJson.getItem().getAttributes().getOwnerId();

		if(owner!=null && owner.getValue()!=null)
		{
			compareValues("MatchOwnerId", reconJson.getItem().getAttributes().getOwnerId().getValue()
					, kafkaAcmeMsg.getMatchContentOwnerId());
		}
		else
		{
			needToHitSource = true;
		}

		ContentId content = reconJson.getItem().getAttributes().getContentId();

		if(content!=null && content.getValue()!=null)
		{
			compareValues("MatchContentId", reconJson.getItem().getAttributes().getContentId().getValue()
					, kafkaAcmeMsg.getMatchContentId());
		}
		else
		{
			needToHitSource = true;
		}

		if(needToHitSource)
		{
			System.out.println("Hitting ssinSource as recon db not having required fields : "+reconJson.getItem().getId());
			try {
				String sSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+reconJson.getItem().getAttributes().getSsinSourceId().getValue();
				String parentResponse = RestExecutor.getJSonResponse(new URI(sSrcURL));
				AcmeSourceById src = JSONParser.parseJSON(parentResponse, AcmeSourceById.class);
				
				compareValues("MatchContentId-fromSrc", src.getItem().getAttributes().getContentId()
						, kafkaAcmeMsg.getMatchContentId());
				
				compareValues("MatchOwnerId-fromSrc", src.getItem().getAttributes().getOwnerId()
						, kafkaAcmeMsg.getMatchContentOwnerId());
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		compareValues("ContributionCount", reconJson.getItem().getAttributes().getCCnt().getValue(), kafkaAcmeMsg.getContributionCount().intValue());

		compareValues("MatchAuthority", "ACME", kafkaAcmeMsg.getMatchAuthority());

		compareValues("MatchedTs", JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(reconJson.getItem().getLastUpdated())), kafkaAcmeMsg.getMatchedTs());

		compareValues("ReconciledTs", JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(reconJson.getItem().getLastUpdated())), kafkaAcmeMsg.getReconciledTs());
	}
	
	private void validateMatchMsg(Item matchedITem)
	{
		try {
			//CompareValuesUtility.init();
			List<JsonObject> sourceData = new ArrayList<JsonObject>();

			String matchContentId = matchedITem.getMatchContentId();
			String matchOwnerId = matchedITem.getMatchContentOwnerId();
			String ssin = matchedITem.getSsin();

			System.out.println("ssin : "+ssin);

			JsonParser jParser = new JsonParser();

			JsonElement jsonElement = jParser.parse(RestExecutor.getJSonResponse
					("http://"+LoadProperties.IA_SERVER+"/acme/source?ssin="+ssin+"&page-size=100"));

			JsonArray array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

			// Sources by SSIN
			for (int i = 0; i < array.size(); i++) 
				sourceData.add(array.get(i).getAsJsonObject());

			AcmeMatchingCommon acmeMatchingCommon =  new AcmeMatchingCommon();

			Set<String> expectedSSINs =acmeMatchingCommon.getExpectedSSIN(sourceData);

			//Validate SSIN
			if(expectedSSINs.contains(ssin))
				CompareValuesUtility.logPassed("SSIN(val)", ssin, ssin);
			else
				CompareValuesUtility.logFailed("SSIN(val)", StringUtils.join(expectedSSINs, ","), ssin);

			JsonObject attributes;

			String calcSSIN  ="";

			for (JsonObject jsonObject : sourceData) 
			{
				attributes =  jsonObject.get("attributes").getAsJsonObject();

				attributes=attributes==null?new JsonObject():attributes;

				CompareValuesUtility.addDataFieldForReport("Source-Id", jsonObject.get("id")==null?"": jsonObject.get("id").getAsString());
				
				calcSSIN = jsonObject.get("calcSsin")==null?"": jsonObject.get("calcSsin").getAsString();

				CompareValuesUtility.addDataFieldForReport("calcSSIN(val)", calcSSIN);
				
				if(calcSSIN.equals(ssin))
				{
					CompareValuesUtility.compareValues("ownerId(val)",matchOwnerId,attributes.get("ownerId")==null?"": attributes.get("ownerId").getAsString());
					CompareValuesUtility.compareValues("contentId(val)",matchContentId,attributes.get("contentId")==null?"": attributes.get("contentId").getAsString());
				}
			}

			/*{
			  "item": {
			    "guid": "fafe4aa7-b626-45f0-b126-28723c09e271",
			    "matchAuthority": "ACME",
			    "matchContentId": "6445880899",
			    "matchContentOwnerId": "9371",
			    "sellerId": "9371",
			    "ssin": "SPM6445880899",
			    "matchedTs": "2016-09-07T17:34:30Z",
			    "reconciledTs": "2016-09-07T17:34:30Z",
			    "itemId": "6445880899",
			    "contributionCount": 2
			  },
			  "metaData": {
			    "createdTs": "2016-09-07T17:34:38Z",
			    "versionNumber": "5.0"
			  }
			}*/

		//	CompareValuesUtility.setupResult(matchedITem.getItemId(),true);
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		}

	}
}
