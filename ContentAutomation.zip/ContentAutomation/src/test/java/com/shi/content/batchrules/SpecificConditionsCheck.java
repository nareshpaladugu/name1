package com.shi.content.batchrules;

import java.util.Arrays;
import java.util.List;

import com.generated.vos.offerattrs.Offerattrs;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.commons.OfferEligibilityUtils;

public class SpecificConditionsCheck {

	public static boolean isDimAllowedForMailable(String sResponse,String offerId)
	{
		//##dimension-check

		String slen= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"desc.leng");

		String swidth= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"desc.wdth");

		String shgt= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"desc.hgt");

		String sWeight= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"desc.weight");

		/*max.weight=150
				max.dimension=108
				max.pack.dimension=130*/
		/*
		 a) Weight < maxweight 
		    b) LagestDim < maxdim 
		    c) PackMeasurement < maxpack
		    (PackMeasurement = Largest Dim + 2 * (Sum of other two))*/

		try {
			Double dWeight = Double.parseDouble(sWeight);

			Double dLen = Double.parseDouble(slen);

			Double dhgt = Double.parseDouble(shgt);

			Double dwidth = Double.parseDouble(swidth);

			return checkIsMailable(dWeight, dLen, dhgt, dwidth);

		} catch (NumberFormatException e) {
			System.out.println("Dim paramter read error..."+offerId);
			return false;
		}
	}

	/**
	 * Method to calculate whether the offer is mailable based on dimensions
	 * @param dWeight
	 * @param dLen
	 * @param dhgt
	 * @param dwidth
	 * @return
	 */
	public static boolean  checkIsMailable(Double dWeight, Double dLen, Double dhgt, Double dwidth){
		if(dWeight>=150)
		{
			//weight greater than maxdim - false case
			return false;
		}
		List<Double> numbers =  Arrays.asList(dLen,dhgt,dwidth);

		java.util.Collections.sort(numbers);
		java.util.Collections.reverse(numbers);

		if(numbers.get(0)>= 108)
		{
			//largest dim greater than maxdim - false case
			return false;
		}

		if(numbers.get(0) + (2 * (numbers.get(1) + numbers.get(2))) >= 130)
		{
			//PackMeasurement is greater than  maxpack
			return false;
		}

		return true;
	}

	public static boolean checkRgnPricing(String offerId)
	{
		try {
			if(offerId.length()>=8)
			{
				offerId  = offerId .substring(0, 8);
			}

			List<String> list = RestExecutor.getIdsByAltKey(CollectionValuesVal.RGNPRICING, "divitem="+offerId);

			if(list==null || list.isEmpty())

				return false;
			else
				return true;

		} catch (Exception e) {
			return false;
		}
	}


	public static boolean checkKmartUpcParentCheck(String offerId,String upc)
	{
		try
		{
			List<String> list = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER_ATTR, "upc="+upc);

			if(list==null || list.isEmpty())
			{
				return false;
			}
			else
			{	
				List<APIResponse<Offerattrs>> lstOffer = RestExecutor.getAllDataById(CollectionValuesVal.OFFER_ATTR, list);

				for (APIResponse<Offerattrs> apiResponse : lstOffer) {

					Offerattrs offerObj = (Offerattrs)apiResponse.getT();

					if(offerObj.getDesc().getSoldBy().equalsIgnoreCase("kmart"))
					{
						Env.OUTPUT=offerObj.getId();
						return true;
					}
				}
			}
		}
		catch(Exception e)
		{

		}

		return false;
	}


	public static boolean inactiveDateCheck(String sResponse,String site)
	{
		String startDate= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"oper.sites."+site+".inactive.startDt",true);

		String endDate= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"oper.sites."+site+".inactive.endDt",true);

		if(startDate!=null && endDate!=null)
		{
			if(startDate.indexOf("T")!=-1 && endDate.indexOf("T")!=-1)
				return startDate.substring(0,startDate.indexOf("T")).equals(endDate.substring(0,endDate.indexOf("T")));
		}

		return false;

	}

	public static boolean invalidVndStatusCheck(String sResponse,String site)
	{
		String ffmSrc= JsonStringParser.getJsonValueNew(sResponse, OfferEligibilityUtils.OfferAttrsPrefix+"desc.ffmsrc",true);

		String sts;
		
		String sResponseSeller = null;
		
		//programs.vd.vndStatus.[SITE].isInvalid=True@collection:seller#desc.ffmsrc

		if(ffmSrc!=null && !ffmSrc.isEmpty())
		{
			sResponseSeller  = RestExecutor.getJSonResponseById("seller","shc_"+ffmSrc);
			
			if(TestUtils.isEmptyJsonResponse(sResponseSeller))
				return true;

			if(sResponseSeller.startsWith("["))
				sResponseSeller=sResponseSeller.substring(1,sResponseSeller.length()-1);
			
			sts = JsonStringParser.getJsonValueNew(sResponseSeller, "_blob.seller.programs.vd.vndStatus."+site+".isInvalid",true);
			
			if(sts!=null && sts.equalsIgnoreCase("true"))
				return true;
		}
		
		return false;
	}
}
