package com.shi.content.ranking;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class RankingTest
{
	private static Set<String> ProccessedUIDs = new HashSet<String>();

	private static Set<String> ProccessedOffers = new HashSet<String>();

	public static boolean serialAcceesFlag;
	public static boolean dbBonusPointsFlag;
	public static boolean itemConditionFlag;
	private static Integer uidCount = 0;

	@Test(dataProvider="partNumberProvider",groups="BuyboxTests")

	public void rankingTest(List<String> uidList)
	{
		String sUidTemp = null;

		System.out.println("IAS Flag : "+ RestExecutor.getJSonResponse(LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + "ranking-service/getIas").toString());
		System.out.println("Ship Flag : "+ RestExecutor.getJSonResponse(LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + "ranking-service/getShip").toString());
		System.out.println("Regional Price Flag : "+ RestExecutor.getJSonResponse(LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + "ranking-service/getRegionalPrice").toString());
		
		//In ranking if you want MP price from price grid:
		//http://iftrank302p.qa.ch3.s.com:8180/ranking-service/setSerialAcceesFlag?serialAcceesFlag=false
		//In ranking if you want MP price from pricing collection:
		//http://iftrank302p.qa.ch3.s.com:8180/ranking-service/setSerialAcceesFlag?serialAcceesFlag=true
		System.out.println("serialAcceesFlag : " + RestExecutor.getJSonResponse(
				LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + 
				"ranking-service/setSerialAcceesFlag?serialAcceesFlag="+serialAcceesFlag));
		
		System.out.println("dbBonusPointsFlag : " + RestExecutor.getJSonResponse(
				LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + 
				"ranking-service/setDbBonusPointsFlag?dbBonusPointsFlag="+dbBonusPointsFlag));
		
		System.out.println("ItemConditionFlag : " + RestExecutor.getJSonResponse(
				LoadProperties.IFTRANKVIP.substring(0, LoadProperties.IFTRANKVIP.indexOf("ranking-service")) + 
				"ranking-service/setItemConditionFlag?itemConditionFlag="+itemConditionFlag));
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.trim().equalsIgnoreCase("bucket"))
		{
			List<String> lstBuckets = getBucketRange();
			
			for (String sBucketNumber : lstBuckets) {

				List<String> offerIdsByBucket = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER,Integer.parseInt(sBucketNumber));

				for (String offerId : offerIdsByBucket)
				{
					if(!ProccessedOffers.contains(offerId))
					{
						sUidTemp = getUIDByOfferId(offerId);
						List<String> offers = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid", sUidTemp);

						//Remove offers.size() check, if non-grouped UIDs also need to be validated
						if(sUidTemp!=null ){

							pool.execute(new RankingTestValidations(sUidTemp));

							//Add UID to processed UIDs list
							ProccessedUIDs.add(sUidTemp);

							//Add all offers under the UID to processed Offers list
							updateProcessedOffers(offers);

							uidCount++;
						}
					}
					if((LoadProperties.TESTDATALIMIT!=-1) && (uidCount>=LoadProperties.TESTDATALIMIT)){
						break;
					}
				}
				if((LoadProperties.TESTDATALIMIT!=-1) && (uidCount>=LoadProperties.TESTDATALIMIT)){
					break;
				}
			}
		}
		else
		{
			for (String singleUID : uidList)
			{
				if(!ProccessedUIDs.contains(singleUID)){

					pool.execute(new RankingTestValidations(singleUID.trim()));

					ProccessedUIDs.add(singleUID);
				}
			}
		}
		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}

	public static synchronized void updateProcessedOffers(List<String> offers)
	{
		ProccessedOffers.addAll(offers);
	}

	public String getUIDByOfferId(String offerId)
	{
		try {
			Offer offer  = RestExecutor.getDataById(CollectionValuesVal.OFFER,offerId);

			if(offer==null)
			{
				System.out.println("Offer Not found : "+offerId);
				return null;
			}

			if((offer.getIdentity()==null) || (offer.getIdentity().getUid()==null))
			{
				System.out.println("Offer Uid Not found : "+offerId);
				return null;
			}

			String uid =  offer.getIdentity().getUid();

			if(ProccessedUIDs.contains(uid))
			{
				uid  = null;
			}

			return uid;

		} catch (Exception e) {

			e.printStackTrace();

			return null;
		}
	}

	public List<String> getBucketRange()
	{
		List<String> lstValues = new ArrayList<String>();

		if(LoadProperties.RUN_PARAMS.contains("-")){
			String[] range = LoadProperties.RUN_PARAMS.split("-");
			for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
				lstValues.add(i.toString());
			}
			System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

		}
		else
		{
			lstValues.add(LoadProperties.RUN_PARAMS);
		}

		return lstValues;
	}

	@DataProvider(name="partNumberProvider", parallel=true)
	public Object[][] partNumberProvider()
	{

		System.out.println("LoadProperties.EXECUTION_MODE  : "+LoadProperties.EXECUTION_MODE);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("bucket"))
		{
			return new Object[][] { { null } };
		}
		String 	partNumbers=null;
		List<String> uidList = new ArrayList<String>();

		if(LoadProperties.EXECUTION_MODE.trim().equalsIgnoreCase("list"))
		{
			partNumbers=LoadProperties.RUN_PARAMS;
			uidList  =  Arrays.asList(partNumbers.split(","));
		}

		if(LoadProperties.EXECUTION_MODE.contains("file")){
			try{
				FileInputStream fstream = new FileInputStream(LoadProperties.RUN_PARAMS);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty())
					{
						uidList.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}

		return new Object[][] { { uidList } };
	}
	
	@BeforeTest(groups="BuyboxTests")
	public void beforeTestSetup()
	{
		serialAcceesFlag = Boolean.parseBoolean(LoadProperties.serialAcceesFlag);
		System.out.println("serialAcceesFlag... . "+serialAcceesFlag);
		
		dbBonusPointsFlag = Boolean.parseBoolean(LoadProperties.dbBonusPointsFlag);
		System.out.println("dbBonusPointsFlag... . "+dbBonusPointsFlag);
		
		itemConditionFlag = Boolean.parseBoolean(LoadProperties.itemConditionFlag);
		System.out.println("itemConditionFlag... . "+itemConditionFlag);
	}
}