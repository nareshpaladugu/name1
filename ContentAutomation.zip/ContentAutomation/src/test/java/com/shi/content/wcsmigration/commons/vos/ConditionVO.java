package com.shi.content.wcsmigration.commons.vos;

import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shi.content.wcsmigration.commons.ConditionParser;
import com.shi.content.wcsmigration.commons.ConditionParser.Conditions;

public class ConditionVO {

	public ConditionVO(String specificCase)
	{
		this.specificCase=specificCase;
	}
	
	private String specificCase;

	public String getSpecificCase() {
		specificCase=specificCase==null?"":specificCase;
		return specificCase.trim();
	}
	public void setSpecificCase(String specificCase) {
		this.specificCase = specificCase;
	}
	private String othercollectionName;
	public String getOthercollectionName() {
		othercollectionName=othercollectionName==null?"":othercollectionName;
		return othercollectionName;
	}
	public void setOthercollectionName(String othercollectionName) {
		this.othercollectionName = othercollectionName;
	}
	public String getFieldNameForOtherCollection() {
		return fieldNameForOtherCollection;
	}
	public void setFieldNameForOtherCollection(String fieldNameForOtherCollection) {
		this.fieldNameForOtherCollection = fieldNameForOtherCollection;
	}
	private String fieldNameForOtherCollection;

	public ConditionVO(String opr1, String opr2, Conditions conditon) {
		super();
		this.opr1 = opr1;

		//programs.vd.vndStatus.sears.isInvalid=True@collection:seller#"shc_"desc.ffmsrc

		String tmp;

		if(opr2.contains("@collection:"))
		{
			tmp = opr2.split("@collection:")[1];

			othercollectionName = tmp.split("#")[0];

			fieldNameForOtherCollection = tmp.split("#")[1];

			opr2 = opr2.split("@collection:")[0];

		}

		if(opr2.equals("[BLANK]"))
		{
			opr2="";
		}

		if(opr2.equals("[CURRENTDATE]"))
		{
			opr2=JodaDateTimeUtility.getTodaysDateTime();
		}

		this.opr2 = opr2;
		this.conditon = conditon;
	}
	private String opr1;
	private String opr2;
	private ConditionParser.Conditions conditon;
	public ConditionParser.Conditions getConditon() {
		return conditon;
	}
	public void setConditon(ConditionParser.Conditions conditon) {
		this.conditon = conditon;
	}
	public String getOpr1() {

		return opr1.trim();
	}
	public void setOpr1(String opr1) {
		this.opr1 = opr1;
	}
	public String getOpr2() {
		return opr2.trim();
	}
	public void setOpr2(String opr2) {
		this.opr2 = opr2;
	}
}
