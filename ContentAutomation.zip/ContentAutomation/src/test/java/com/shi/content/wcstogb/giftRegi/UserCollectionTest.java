package com.shi.content.wcstogb.giftRegi;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.db.DBUtil;

public class UserCollectionTest 
{

	@Test(groups="GiftRegistry-UserCollectionTest")
	public void userCollectionTest()
	{

		if(CommonGiftReg.database==null)
		{
			LoadProperties.setCustomMsgForEmail("Check MongoDb Connection",MSGTYPE.ERROR);
			return;
		}

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		String userIdsFromWcs = null;

		int dataLimit = LoadProperties.TESTDATALIMIT;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("LIST"))
		{
			//String ids = null;
			//String sp[] = LoadProperties.RUN_PARAMS.split(",");
			
			String idsALL = readFile();			
			/*for (String string : sp) {

				if(ids==null)
					ids="'"+string+"'";
				else
					ids=ids+",'"+string+"'";
			}*/
			
			System.out.println("idsALL... "+idsALL);
			
			userIdsFromWcs = "select users_id,field2 from USERPROF where field2 in ("+idsALL+") with ur";
		}
		else
		{
			if(dataLimit!=-1)
				userIdsFromWcs = "select users_id,field2 from USERPROF where field2 is not null and field2 <> '' fetch first "+dataLimit+" rows only with ur";
			else
				userIdsFromWcs = "select users_id,field2 from USERPROF where field2 is not null and field2 <> '' with ur";
		}


		ResultSet resultSet = DBUtil.executeQueryReturnAll(userIdsFromWcs);

		try {
			while(resultSet.next())
			{
				pool.execute(new UserCollectionVerifications(resultSet.getString(1),resultSet.getString(2)));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}


		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
		finally
		{
			DBUtil.closeCursor(resultSet);
		}
	}

	private String readFile(){
			 
		String output = "";
		
			BufferedReader br = null;
	 
			try {
	 
				String sCurrentLine;
	 
				br = new BufferedReader(new FileReader("src/test/resources/userIds.txt"));
	 
				while ((sCurrentLine = br.readLine()) != null) {
					//System.out.println(sCurrentLine);
					output=output+","+"'"+sCurrentLine.trim()+"'";
				}
	 
				output=output.replaceFirst(",","");
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (br != null)br.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
			
			return output;
	}
	@BeforeSuite(groups="GiftRegistry-UserCollectionTest")
	public void startUp()
	{
		CommonGiftReg.getGiftRegMongoDB();
	}
}
