package com.shi.content.wcsmigration.tests;

import java.net.URI;
import java.util.List;
import java.util.Map;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.content.Content;
import com.generated.vos.offer.Attrs__;
import com.generated.vos.offer.Attrs___;
import com.generated.vos.offer.Bal;
import com.generated.vos.offer.Classifications.OfferType;
import com.generated.vos.offer.InstServ;
import com.generated.vos.offer.LinkedSwatch;
import com.generated.vos.offer.MaintAgreemt;
import com.generated.vos.offer.MaintServ;
import com.generated.vos.offer.MfrRecmdPart;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.Operational;
import com.generated.vos.offer.OptAcc;
import com.generated.vos.offer.ProdProtecPlan;
import com.generated.vos.offer.ReqAcc;
import com.generated.vos.offer.RoadHazPlusAggrmt;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.ValveStem;
import com.generated.vos.offer.XSell;
import com.generated.xmls.assocsnew.ParentPartnumber;
import com.generated.xmls.assocsnew.ProductAssociation;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;

public class AssocsLoadVerification implements Runnable{

	private ParentPartnumber parentPartnumberXML;

	private String sSiteName;

	private Map<String, Boolean> paPriceMap;

	public AssocsLoadVerification(ParentPartnumber parentPartnumberXML,String sSiteName, Map<String, Boolean> paPriceMap)
	{
		this.parentPartnumberXML=parentPartnumberXML;
		this.sSiteName=sSiteName;
		this.paPriceMap=paPriceMap;
	}


	public void run() 
	{
		String sPartNumber;

		if(sSiteName.equalsIgnoreCase("sears"))
		{
			sPartNumber = parentPartnumberXML.getParentSearsPartNumber();
		}
		else
		{
			sPartNumber = parentPartnumberXML.getParentKmartPartNumber();
		}

		if(sPartNumber==null || sPartNumber.isEmpty())
		{
			return;
		}

		CompareValuesUtility.init();

		//System.out.println("test part : "+sPartNumber);

		APIResponse< Offer> offerRes = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, sPartNumber);
		Offer offer = offerRes.getT();

		if(offer==null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("Offer-Not-Found",sPartNumber);
		}
		else
		{

			if(isMarkForDelete(offer) || siteCheckCondition(offer.getSites()) || operationalTagCheck(offer) || isStoreOnly(offer))
			{
				return;
			}

			String partNumberInner;
			String type;
			boolean found;
			String parId;

			ProductAssociation[] allAssocsXML  = parentPartnumberXML.getProductAssociation();

			for (ProductAssociation productAssociation : allAssocsXML) {

				type = productAssociation.getType().value();
				
				if(!System.getProperty("assocType").equals(type) && !System.getProperty("assocType").equals("ALL"))
					return;
				
				if(sSiteName.equalsIgnoreCase("sears"))
				{
					partNumberInner = productAssociation.getPartNumber().getSearsPartNumber();
				}
				else
				{
					partNumberInner = productAssociation.getPartNumber().getKmartPartNumber();
				}

				if(partNumberInner==null)
				{
					//System.out.println("Need to ignore this product-association tag, no site part found ... ");
				}
				else
				{
					Boolean hasValidPrc = false;
					//child part-number SKU should be 292 for PA items
					if(type.equals("PROTECTION_AGREEMENT") && sSiteName.equalsIgnoreCase("sears")){
						partNumberInner = partNumberInner.substring(0, 8) + "292";
						hasValidPrc = validatePrice(partNumberInner);
					}
					
					APIResponse< Offer> offerResInner = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, partNumberInner);
					Offer offerInner = offerResInner.getT();
					
					if(offerInner==null)
					{
						//System.out.println("Need to ignore this product-association tag, site part found ... but not present ... "+partNumberInner);
					}
					else
					{

						if(isMarkForDelete(offerInner) || siteCheckCondition( offerInner.getSites()) || operationalTagCheck(offerInner) || isStoreOnly(offerInner))
						{
							continue;
						}

						parId = offerInner.getIdentity()==null||offerInner.getIdentity().getParentId()==null?partNumberInner+"P":offerInner.getIdentity().getParentId();

						if(offer.getAssocs()==null)
						{
							if(type.equals("PROTECTION_AGREEMENT") && !hasValidPrc){
								//System.out.println("Ignoring PA assoc with no valid price");
							}else{
								CompareValuesUtility.logFailed(type, partNumberInner, "Not found", "Id");
							}
						}
						else
						{
							System.out.println("Testing assoc: parent="+sPartNumber+", child="+partNumberInner+", type="+type);
							switch(type)
							{
							case "REQUIRED_ACCESSORY": 

								List<ReqAcc> reqAccs = offer.getAssocs().getReqAccs();

								found = false;
								if(reqAccs!=null)
									for (ReqAcc reqAcc : reqAccs) {
										if(reqAcc.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, reqAcc.getQty() , "REQUIRED_ACCESSORY");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("REQUIRED_ACCESSORY", partNumberInner,"Not Found","Id");
								}
								break;

							case "OPTIONAL_ACCESSORY": 

								List<OptAcc> optAccs = offer.getAssocs().getOptAccs();

								found = false;

								if(optAccs!=null)
									for (OptAcc optAcc : optAccs) {
										if(optAcc.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, optAcc.getQty() , "OPTIONAL_ACCESSORY");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("OPTIONAL_ACCESSORY", partNumberInner,"Not Found","Id");
								}
								break;

							case "X_SELL": 

								List<XSell> xSells = offer.getAssocs().getXSell();

								found = false;
								if(xSells!=null)
									for (XSell xXell : xSells) {
										if(xXell.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, xXell.getQty() , "X_SELL");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("X_SELL", partNumberInner,"Not Found","Id");
								}
								break;

							case "BALANCING": 

								List<Bal> bals = offer.getAssocs().getBal();

								found = false;
								if(bals!=null)
									for (Bal bal : bals) {
										if(bal.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, bal.getQty() , "BALANCING");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("BALANCING", partNumberInner,"Not Found","Id");
								}
								break;

							case "INSTALLATION_SERVICES": 

								List<InstServ> instServs = offer.getAssocs().getInstServ();

								found = false;
								if(instServs!=null)
									for (InstServ instServ : instServs) {
										if(instServ.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, instServ.getQty() , "INSTALLATION_SERVICES");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("INSTALLATION_SERVICES", partNumberInner,"Not Found","Id");
								}

								break;

							case "MAINTENANCE_SERVICES": 

								List<MaintServ> maintServs = offer.getAssocs().getMaintServ();

								found = false;
								if(maintServs!=null)
									for (MaintServ maintServ : maintServs) {
										if(maintServ.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, maintServ.getQty() , "MAINTENANCE_SERVICES");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("MAINTENANCE_SERVICES", partNumberInner,"Not Found","Id");
								}
								break;

							case "ROAD_HAZARD_PLUS_AGREEMENT": 

								List<RoadHazPlusAggrmt> roadHazPlusAggrmts = offer.getAssocs().getRoadHazPlusAggrmt();

								found = false;
								if(roadHazPlusAggrmts!=null)
									for (RoadHazPlusAggrmt roadHazPlusAggrmt : roadHazPlusAggrmts) {
										if(roadHazPlusAggrmt.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, roadHazPlusAggrmt.getQty() , "ROAD_HAZARD_PLUS_AGREEMENT");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("ROAD_HAZARD_PLUS_AGREEMENT", partNumberInner,"Not Found","Id");
								}

								break;

							case "VALVE_STEMS": 

								List<ValveStem> valveStems = offer.getAssocs().getValveStems();

								found = false;
								if(valveStems!=null)
									for (ValveStem valveStem : valveStems) {
										if(valveStem.getId().equals(parId))
										{
											verifyAssoc(partNumberInner, productAssociation, valveStem.getQty() , "VALVE_STEMS");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("VALVE_STEMS", partNumberInner,"Not Found","Id");
								}


								break;

							case "PROTECTION_AGREEMENT": 
								
								List<MaintAgreemt> maintAgreemts = offer.getAssocs().getMaintAgreemt();

								found = false;
								if(maintAgreemts!=null)
									for (MaintAgreemt maintAgreemt : maintAgreemts) {
										if(maintAgreemt.getId().equals(parId))
										{
											if(!hasValidPrc){
												CompareValuesUtility.logFailed("PROTECTION_AGREEMENT", partNumberInner, "PA item without valid price shouldn't be present", "Id");
											}else{
												verifyAssoc(partNumberInner, productAssociation, maintAgreemt.getQty() , "PROTECTION_AGREEMENT");
											}
											found=true;
											break;
										}
									}

								if(!found && hasValidPrc)
								{
									CompareValuesUtility.logFailed("PROTECTION_AGREEMENT", partNumberInner,"Not Found","Id");
								}

								break;

							case "LINKED_SWATCH":
									
								List<LinkedSwatch> linkedSwatchs = offer.getAssocs().getLinkedSwatch();

								found = false;
								if(linkedSwatchs!=null)
									for (LinkedSwatch linkedSwatch : linkedSwatchs) {
										if(linkedSwatch.getId().equals(parId))
										{

											CompareValuesUtility.logPassed("LINKED_SWATCH", partNumberInner,partNumberInner,"Id");
											CompareValuesUtility.compareAsNumbers("LINKED_SWATCH", productAssociation.getQuantity(),linkedSwatch.getQty(),"Qty");

											APIResponse<Content> content = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, parId);
											Content contentObj = content.getT();

											if(contentObj.getSeo()!=null)
											{
												CompareValuesUtility.verifyNullOrEqual("LINKED_SWATCH",contentObj.getSeo().getUrl(), linkedSwatch.getUrl(),"url");
											}
											
											/******/
											/*List<String> offerIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId", parId);
											
											for(String offerId : offerIds){
												
												Offer offerLinkedSwtch = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerId);
												
												if(offerLinkedSwtch==null)
													continue;
												else{*/

													Attrs___ actaulSwatch = linkedSwatch.getSwatchImg()==null?null:linkedSwatch.getSwatchImg().getAttrs();

													List<SwatchImg> allswatchImagesOffer = offerInner.getSwatchImg();
													/*List<SwatchImg> allswatchImagesOffer = offerLinkedSwtch.getSwatchImg();*/
													
													if(allswatchImagesOffer!=null  && !allswatchImagesOffer.isEmpty())
													{
														SwatchImg singleSwatch = allswatchImagesOffer.get(0);
														
														if(actaulSwatch==null)
														{
															CompareValuesUtility.logFailed("LINKED_SWATCH", singleSwatch.getSrc(),"Not Found","imgSrc");
														}
														else
														{
															CompareValuesUtility.verifyNullOrEqual
															("LINKED_SWATCH",singleSwatch.getSrc(),actaulSwatch.getSrc(),"imgSrc");
															CompareValuesUtility.verifyNullOrEqual
															("LINKED_SWATCH",singleSwatch.getHeight(),actaulSwatch.getHeight(),"imgHeight");
															CompareValuesUtility.verifyNullOrEqual
															("LINKED_SWATCH",singleSwatch.getWidth(),actaulSwatch.getWidth(),"imgWidth");
															CompareValuesUtility.verifyNullOrEqual
															("LINKED_SWATCH",singleSwatch.getAlt(),actaulSwatch.getAlt(),"imgAlt");
														}
													}
												/*}
												break;
											}*/
											/************/
											found=true;
											break;
										}
									}
								if(!found)
								{
									CompareValuesUtility.logFailed("LINKED_SWATCH", partNumberInner,"Not Found","Id");
								}									
								CompareValuesUtility.addNewMultiValuedFields();
								break;

							//IB level associations
							case "MANUFACTURE_RECOMMENDED_PARTS": 

								List<MfrRecmdPart> mfrRecmdParts = offer.getAssocs().getMfrRecmdParts();

								found = false;
								if(mfrRecmdParts!=null)
									for (MfrRecmdPart mfrRecmdPart : mfrRecmdParts) {
										if(mfrRecmdPart.getId().equals(partNumberInner))
										{
											verifyAssoc(partNumberInner, productAssociation, mfrRecmdPart.getQty() , "MANUFACTURE_RECOMMENDED_PARTS");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("MANUFACTURE_RECOMMENDED_PARTS", partNumberInner,"Not Found","Id");
								}

								break;

							case "REPLACEMENT_AGREEMENT": 

								List<ProdProtecPlan> prodProtecPlans = offer.getAssocs().getProdProtecPlan();

								found = false;
								if(prodProtecPlans!=null)
									for (ProdProtecPlan prodProtecPlan : prodProtecPlans) {
										if(prodProtecPlan.getId().equals(partNumberInner))
										{
											verifyAssoc(partNumberInner, productAssociation, prodProtecPlan.getQty() , "REPLACEMENT_AGREEMENT");
											found=true;
											break;
										}
									}

								if(!found)
								{
									CompareValuesUtility.logFailed("REPLACEMENT_AGREEMENT", partNumberInner,"Not Found","Id");
								}

								break;
							}
						}
					}
				}
			}
		}
		CompareValuesUtility.setupResult(sPartNumber,true);
	}


	private Boolean validatePrice(String partNumberInner) {	
		
		if(paPriceMap.containsKey(partNumberInner)){
			System.out.println("PA price found from Map: " + partNumberInner + ", isValid=" + paPriceMap.get(partNumberInner));
			return paPriceMap.get(partNumberInner);
		}
		URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, "0009300"+"-"+partNumberInner.substring(0, 8));
		ShcPricing shcPrice = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
		
		Boolean isValidPrice = false;
        Double pprice = null;
        Double rprice = null;
        Double xprice = null;
        try{
        	if(shcPrice !=null){
        		pprice = shcPrice.getP().getS().isEmpty()?null:shcPrice.getP().getS().get(0).getIp();
        		rprice = shcPrice.getP().getR().isEmpty()?null:shcPrice.getP().getR().get(0).getIp();
        		xprice = shcPrice.getP().getX().isEmpty()?null:shcPrice.getP().getX().get(0).getIp();
        		if((pprice!=null || rprice!=null || xprice!=null)){                                             
        			if(xprice==null){
        				isValidPrice = true;                                                                     
        			}else if(xprice.compareTo(0.02) > 0){
        				isValidPrice = true;
        			}
        		}
        	}
        }catch (Exception e) {
        	System.out.println("Error in validatePrice ::"+ e);
        }
        
        if(!isValidPrice){
        	pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, "0009313"+"-"+partNumberInner.substring(0, 8));
    		shcPrice = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
    		
    		try{
            	if(shcPrice !=null){
            		pprice = shcPrice.getP().getS().isEmpty()?null:shcPrice.getP().getS().get(0).getIp();
            		rprice = shcPrice.getP().getR().isEmpty()?null:shcPrice.getP().getR().get(0).getIp();
            		xprice = shcPrice.getP().getX().isEmpty()?null:shcPrice.getP().getX().get(0).getIp();
            		if((pprice!=null || rprice!=null || xprice!=null)){                                             
            			if(xprice==null){
            				isValidPrice = true;                                                                     
            			}else if(xprice.compareTo(0.02) > 0){
            				isValidPrice = true;
            			}
            		}
            	}
            }catch (Exception e) {
            	System.out.println("Error in validatePrice ::"+ e);
            }
        }
        
        System.out.println("PA price found from GB: " + partNumberInner + ", isValid=" + isValidPrice);
        paPriceMap.put(partNumberInner, isValidPrice);
        return isValidPrice;
	}


	private boolean siteCheckCondition(List<String> listOFSitesMain)
	{
		if(listOFSitesMain==null)
		{
			//System.out.println(" ---------- Exclude offer(sites tag condition) : Null");
			return true;
		}
		else
		{
			if(sSiteName.equalsIgnoreCase("sears") && !listOFSitesMain.contains("sears"))
			{
				//System.out.println(" ---------- Exclude offer(sites tag condition) : sears");
				return true;
			}
			else if(sSiteName.equalsIgnoreCase("kmart") && !listOFSitesMain.contains("kmart"))
			{
				//System.out.println(" ---------- Exclude offer(sites tag condition) : kmart");
				return true;
			}
		}

		return false;
	}


	private boolean operationalTagCheck(Offer offer)
	{
		Operational opTag = offer.getOperational();
		
		if(opTag==null)
			return true;
		
		if(sSiteName.equalsIgnoreCase("sears") && (opTag.getSites()==null||opTag.getSites().getSears()==null))
		{
			//System.out.println(" ---------- Exclude offer(sites tag condition) : sears");
			return true;
		}
		else if(sSiteName.equalsIgnoreCase("kmart") && (opTag.getSites()==null||opTag.getSites().getKmart()==null))
		{
			//System.out.println(" ---------- Exclude offer(sites tag condition) : kmart");
			return true;
		}
		
		return false;
	}
	
	private boolean isMarkForDelete(Offer offerI)
	{
		Boolean isMarkForDeleteMain;

		try {
			isMarkForDeleteMain = offerI.getOperational().getIsMarkForDelete();
		} catch (Exception e1) {
			isMarkForDeleteMain = null;
		}

		if(isMarkForDeleteMain!=null && isMarkForDeleteMain)
		{
			//System.out.println("Ignore main offer ... as isMarkForDeleteMain=true");
			return true;
		}

		return false;
	}
	
	private boolean isStoreOnly(Offer offer) {
		if(offer.getClassifications().getOfferType().equals(OfferType.S))
			return true;
		else 
			return false;
	}

	private void verifyAssoc(String partNumberInner,ProductAssociation productAssociation,Object qty,String sTitle)
	{
		CompareValuesUtility.logPassed(sTitle, partNumberInner,partNumberInner,"Id");
		CompareValuesUtility.compareAsNumbers(sTitle, productAssociation.getQuantity(),qty,"Qty");
		CompareValuesUtility.addNewMultiValuedFields();
	}
}
