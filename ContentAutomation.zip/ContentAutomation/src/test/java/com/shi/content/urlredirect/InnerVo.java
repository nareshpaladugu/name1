package com.shi.content.urlredirect;

import java.util.LinkedList;
import java.util.Map;

public class InnerVo {

	public Map<String, Map<String, LinkedList<URLVo>>> getOldMapMap() {
		return oldMapMap;
	}

	public void setOldMapMap(Map<String, Map<String, LinkedList<URLVo>>> oldMapMap) {
		this.oldMapMap = oldMapMap;
	}

	public LinkedList<URLVo> getSimpleListOfUrlData() {
		return simpleListOfUrlData;
	}

	public void setSimpleListOfUrlData(LinkedList<URLVo> simpleListOfUrlData) {
		this.simpleListOfUrlData = simpleListOfUrlData;
	}

	private Map<String, Map<String,LinkedList<URLVo>>>  oldMapMap;
	
	private LinkedList<URLVo> simpleListOfUrlData;
}
