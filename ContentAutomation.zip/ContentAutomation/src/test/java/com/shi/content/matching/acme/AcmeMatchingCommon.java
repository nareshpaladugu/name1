package com.shi.content.matching.acme;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.contentscore.Attributes;
import com.generated.vos.contentscore.Contentscore;
import com.generated.vos.contentscore.Image;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.threezero.AcmeMisClassIngestTests;
import com.shi.content.matching.MatchingExclusionConstants;
import com.shi.content.matching.SingleOfferMatchDataVo;

/**
 * @author ddaphal
 *
 */
public class AcmeMatchingCommon 
{
	public SingleOfferMatchDataVo getMatchingData(JsonObject jsonObject,boolean featuresDb)
	{
		SingleOfferMatchDataVo vo =new SingleOfferMatchDataVo();

		JsonObject attributes =  jsonObject.get("attributes").getAsJsonObject();

		attributes=attributes==null?new JsonObject():attributes;

		vo.setSourceDbId(jsonObject.get("id")==null?"":jsonObject.get("id").getAsString());

		vo.setBrandName(attributes.get("brandName")==null?"":attributes.get("brandName").getAsString());

		vo.setBrandCodeId( attributes.get("brandCodeId")==null?"": attributes.get("brandCodeId").getAsString());
		
		vo.setUpc( attributes.get("upcCode")==null?"": attributes.get("upcCode").getAsString());

		vo.setSpinId(jsonObject.get("id")==null?"":jsonObject.get("id").getAsString());

		vo.setProgramType( attributes.get("programType")==null?"": attributes.get("programType").getAsString());

		if(featuresDb)
		{
			vo.setAcmeSourceStatus( attributes.get("status")==null?"": attributes.get("status").getAsString() );
			
			vo.setMasterVerticalId( attributes.get("itemClassId")==null?"": attributes.get("itemClassId").getAsString() );
			
			vo.setVarAttrs( attributes.get("defAttr")==null?"": attributes.get("defAttr").getAsString() );
			
			vo.setUid( attributes.get("guid")==null?"": attributes.get("guid").getAsString() );
		}
		else
		{
			vo.setAcmeSourceStatus( attributes.get("status")==null?"": 
				(attributes.get("status").getAsJsonObject()==null?"":
					attributes.get("status").getAsJsonObject().get("status")==null?"":attributes.get("status").getAsJsonObject().get("status").getAsString()));
			
			vo.setUid( jsonObject.get("guid")==null?"": jsonObject.get("guid").getAsString());
		}

		vo.setSsin( jsonObject.get("ssin")==null?"": jsonObject.get("ssin").getAsString());

		vo.setWebHierarchy( attributes.get("sites")==null?"": attributes.get("sites").toString());

		//calcSsin=item id in gb
		vo.setParentId( jsonObject.get("calcSsin")==null?"": jsonObject.get("calcSsin").getAsString());

		vo.setModelNumber(attributes.get("modelNumber")==null?"":attributes.get("modelNumber").getAsString());

		vo.setOfferType( attributes.get("classifier")==null?"": attributes.get("classifier").getAsString());

		vo.setIsUvd( jsonObject.get("isUvd")==null?false: Boolean.parseBoolean(jsonObject.get("isUvd").getAsString()));

		vo.setPackageQty(attributes.get("packageQuantity")==null?"":attributes.get("packageQuantity").getAsString());

		//Master Vertical and defAttr and div lines from features 
		return vo;
	}

	public Set<String> getExpectedSSIN(List<JsonObject> sourcesInGroup)
	{
		/*Picking SSIN(Content of an offer) rules: 			SEARS -->KMART-> FBM --> FBS --> DSS --> CPC*/
		/*		CPC		DSS		FBM		FBS		HS		Kmart		S		Sears		UVD		UVD-DUMMY		 */

		Set<String> defEmpty = new HashSet<String>();
		Map<String,Set<String>> searsMap = new TreeMap<String, Set<String>>();

		JsonObject attributes =  null;

		String sPgrmType = "";
		String sParentId = "";
		String status = "";

		String currentKey = null;

		if(sourcesInGroup.size()==1)
		{
			//only one item in group
			defEmpty.add(sourcesInGroup.get(0).get("calcSsin")==null?"": 
				sourcesInGroup.get(0).get("calcSsin").getAsString());
			return defEmpty;
		}
		for (JsonObject  jsonObject : sourcesInGroup) 
		{
			attributes =  jsonObject.get("attributes").getAsJsonObject();

			sPgrmType =  attributes==null?"":attributes.get("programType")==null?"": attributes.get("programType").getAsString();

			sParentId =  jsonObject.get("calcSsin")==null?"": jsonObject.get("calcSsin").getAsString();

			status= attributes.get("status")==null?"": 
				(attributes.get("status").getAsJsonObject()==null?"":
					attributes.get("status").getAsJsonObject().get("status")==null?"":attributes.get("status").getAsJsonObject().get("status").getAsString());

			if(!status.equalsIgnoreCase("Active"))
			{
				continue;
			}
			switch(sPgrmType.toUpperCase())
			{
			case "SEARS":	currentKey="s1";		break;
			case "KMART":	currentKey="s2";		break;
			case "FBM":	 
			case "FBS":		currentKey="s3";		break;

			case "DSS":		currentKey="s4";		break;
			case "CPC":		currentKey="s5";		break;
			default:		
			{
				currentKey="s6";		break;
			}
			}

			Set<String> setOfParentIds = searsMap.get(currentKey);

			if(setOfParentIds==null)
			{
				setOfParentIds=new HashSet<String>();
			}

			setOfParentIds.add(sParentId);

			searsMap.put(currentKey, setOfParentIds);
		}

		Set<Entry<String, Set<String>>> entrySet = searsMap.entrySet();
		Iterator<Entry<String, Set<String>>> iterator = entrySet.iterator();

		while (iterator.hasNext()) {
			Entry<String, Set<String>> entry = iterator.next();

			if(entry.getValue()!=null)
			{
				return entry.getValue();
			}
		}

		return defEmpty;
	}

	public int getActiveGuidSources(String field)
	{
		int activeCtr = 0;
		String jsonResponse=null;

		try {
			String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source?"+field+"&page-size=200";

			jsonResponse = RestExecutor.getJSonResponse(sUrl);
			jsonResponse=jsonResponse==null?"":jsonResponse;

			JsonParser jParser = new JsonParser();
			JsonElement jsonElement = jParser.parse(jsonResponse);
			JsonArray array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();


			for (int i = 0; i < array.size(); i++)
			{
				if(array.get(i).getAsJsonObject().get("ssin")!=null &&
						array.get(i).getAsJsonObject().get("status").getAsString().equalsIgnoreCase("Active"))
				{
					activeCtr++;
				}
			}
		} catch (Exception e) 
		{
			activeCtr= StringUtils.countMatches(jsonResponse,"\"status\":{\"status\":\"ACTIVE\"}");
		}

		return activeCtr;
	}

	public boolean fetchFeaturesDataByGuid(String guid, List<SingleOfferMatchDataVo> offerListByUID )
	{
		String jsonResponse = RestExecutor.getJSonResponse
				("http://"+LoadProperties.IA_SERVER+"/acme/features?guid="+guid+"&page-size=200");

		jsonResponse=jsonResponse==null?"":jsonResponse;

		JsonParser jParser = new JsonParser();

		JsonElement jsonElement;

		JsonArray array =null;

		jsonElement = jParser.parse(jsonResponse);

		JsonObject attributes;

		String sourceId ;

		if(jsonElement.getAsJsonObject().get("items")!=null)
		{
			array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

			for (int ii = 0; ii < array.size(); ii++) 
			{
				sourceId = array.get(ii).getAsJsonObject().get("id").getAsString();

				attributes =  array.get(ii).getAsJsonObject().get("attributes").getAsJsonObject();

				attributes=attributes==null?new JsonObject():attributes;

				for (SingleOfferMatchDataVo singleOffer : offerListByUID) {

					if(singleOffer.getSourceDbId().equals(sourceId))
					{
						singleOffer.setMasterVerticalId(attributes.get("itemClassId")==null?"0":attributes.get("itemClassId").getAsString());
						singleOffer.setVarAttrs(attributes.get("defAttr")==JsonNull.INSTANCE  || attributes.get("defAttr")==null?"":attributes.get("defAttr").getAsString());
						singleOffer.setDivLine( attributes.get("divLine")==JsonNull.INSTANCE || attributes.get("divLine")==null?"": attributes.get("divLine").getAsString());
					}
				}
			}
		}
		return jsonResponse.contains("forceGuid");

	}


	/**
	 * Find missing offers in group
	 */
	public Map<String,SingleOfferMatchDataVo > getFeaturesItemsByField(String field,String expVertical,String expOfferType,Set<String> setOfUPCs,
			Set<String> setOfBrands,Set<String> setOfModels,String expPkgQty,Set<String> defAttrs)
			{

		expPkgQty=expPkgQty.equals("-NA-")?"":expPkgQty;

		Map<String,SingleOfferMatchDataVo> sourceIdMap = new HashMap<String, SingleOfferMatchDataVo>();
		if(field==null)
			return sourceIdMap;

		String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/features?"+encodeField(field)+"&count";
		
		try {

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);

			int totalSourceCount = Integer.parseInt(JsonStringParser.getJsonValue(jsonResponse, "{count}"));

			int totalPages = 0;
			int lastPageSize = 0;
			int pageSize =  150;

			totalPages = totalSourceCount/pageSize;
			lastPageSize = totalSourceCount%pageSize;
			if(totalSourceCount%pageSize == 0)
				totalPages--;


			String status;
			JsonElement jsonElement;
			JsonArray array =null;

			JsonParser jParser = new JsonParser();

			String offerType;
			String upc;
			String veritcal;
			String model;
			String brand;
			String pkgQty;
			JsonObject attributes;
			String sourceId ;
			String defAttr;

			for(int i = 0 ; i <=totalPages; i++)
			{
				if(i==totalPages)
					pageSize=lastPageSize;

				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/features?"+field+"page-size="+pageSize+"&page="+i;

				jsonResponse = RestExecutor.getJSonResponse(sUrl);

				jsonElement = jParser.parse(jsonResponse);

				boolean emptyUpc;

				if(jsonElement.getAsJsonObject().get("items")!=null)
				{
					array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

					for (int ii = 0; ii < array.size(); ii++) 
					{
						sourceId = array.get(ii).getAsJsonObject().get("id").getAsString();

						attributes =  array.get(ii).getAsJsonObject().get("attributes").getAsJsonObject();

						attributes=attributes==null?new JsonObject():attributes;

						status= attributes.get("status")==null?"": (attributes.get("status").getAsString());

						offerType = attributes.get("classifier")==null?"": (attributes.get("classifier").getAsString());

						upc =  attributes.get("upcCode")==null?"": attributes.get("upcCode").getAsString();

						brand = attributes.get("brandName")==null?"":attributes.get("brandName").getAsString();

						model=	attributes.get("modelNumber")==null?"":attributes.get("modelNumber").getAsString();

						veritcal =  attributes.get("itemClassId")==null?"0":attributes.get("itemClassId").getAsString();

						pkgQty = attributes.get("packageQuantity")==null?"":attributes.get("packageQuantity").getAsString();

						defAttr = attributes.get("defAttr")==null?"":attributes.get("defAttr").getAsString();
						emptyUpc = upc.isEmpty();

						//1. should be active source 
						//2. should have matching offer type
						//3. should match vertical
						//4. should match package quantity
						if( status.equalsIgnoreCase("Active") 
								&& offerType.equals(expOfferType)
								&& pkgQty.equals(expPkgQty) )
						{
							
							if(!MatchingTestACME.excludeVerticalFromMatching && !veritcal.equals(expVertical))
							{
								continue;
							}
							
							//5 matching upc
							//6. UPC blank - then  should have matching brand + model
							if( ( !emptyUpc && setOfUPCs.contains(upc) )  ||
									( emptyUpc && setOfBrands.contains(brand) 
											&& setOfModels.contains(model)))
							{
								if(offerType.equalsIgnoreCase("NV"))
								{
									sourceIdMap.put(sourceId,getMatchingData(array.get(ii).getAsJsonObject(),true));
								}
								else
								{
									if(defAttrs.contains(defAttr.toLowerCase()))
									{
										sourceIdMap.put(sourceId,getMatchingData(array.get(ii).getAsJsonObject(),true));
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}

		return sourceIdMap;
			}


	/**
	 * Checks for exclusion logic w.r.t Model_no,Model,ProgramType,Division,Division Line
	 * @param offerSchema
	 * @return
	 */
	public void checkForExclusionRule(SingleOfferMatchDataVo vo)
	{
		vo.setSingleItemGroupNeeded(false);
		vo.setExcludedAtParentLevel(false);
		//----------------------------------------------------------------------------------

		if(vo.getOfferType().equalsIgnoreCase("S") || vo.getOfferType().equalsIgnoreCase("HS") || vo.getIsUvd())
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setExcludedAtParentLevel(true);
		}

		//----------------------------------------------------------------------------------

		if(vo.getUpc().equals("000000000000") || vo.getUpc().equals("0000000000000") )
		{
			//for these upcs single group needed
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("UPC exclusion : 00000000000000");
		}
		List<String> brandsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedBrands.split(","));

		List<String> modelsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedModels.split(","));

		if(vo.getOfferid().startsWith("028") || vo.getOfferid().startsWith("095") || vo.getOfferid().startsWith("090") )
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Division :  028,090,095");	
		}

		if(vo.getUpc().isEmpty() && brandsToExclude.contains(vo.getBrandName()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Brand");
		}

		if(vo.getUpc().isEmpty() && modelsToExclude.contains(vo.getModelNumber()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Models");
		}

		List<String> divLinesToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedDivLines.split(","));

		if(vo.getDivLine()!=null && !vo.getDivLine().isEmpty())
		{
			for (String divline : divLinesToExclude) {

				if(vo.getDivLine().startsWith(divline))
				{
					vo.setSingleItemGroupNeeded(true);
					vo.setSingleItemGroupReason("Execluded DivLines");
				}
			}
		}
	}
	
	private String encodeField(String field)
	{
		field = field.replaceAll("&","%26").replaceAll("\"", "%22").replaceAll("&", "%26")
		.replaceAll(" ", "%20").replaceAll("!","%21").replaceAll("$", "%24").replaceAll("'", "%27");
		
		return field;
	}
	
	public Double getContentScore(String id)
	{
		String resp = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/contentscore/"+id);

		if(TestUtils.isEmptyJsonResponse(resp))
			return null;
		
		Gson g=new Gson();

		Contentscore contentscore  = g.fromJson(resp, Contentscore.class);

		if(contentscore==null || contentscore.getItem()==null)
			return null;
		
		try {
			Double aggregateActual = contentscore.getItem().getAttributes().getAggregateScore();

			System.out.println("aggregateActual... "+aggregateActual);
			
			return aggregateActual;
		} catch (Exception e) {
			return null;
		}

	}
	
	
	public String getMisClass(String spinId)
	{
		String resp = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/misclass/"+spinId);

		if(TestUtils.isEmptyJsonResponse(resp))
		{
			return null;
		}
		else
		{
			String actualFlag = 	JsonStringParser.getJsonValueNew(resp, "item.attributes.misclass",true);
			actualFlag=actualFlag==null||actualFlag.equals("null")?null:actualFlag;

			return actualFlag;
		}
		
	}
}
