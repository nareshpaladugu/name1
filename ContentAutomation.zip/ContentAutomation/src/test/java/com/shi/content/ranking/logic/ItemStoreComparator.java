package com.shi.content.ranking.logic;

import java.util.Comparator;


public class ItemStoreComparator implements Comparator<GBRankBean>{
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
		}
		//System.out.println("ItemStoreComparator....."+e1.getPartnumber() +" <->"+e2.getPartnumber());
		return e1.getStorePriority().compareTo(e2.getStorePriority());
	}

}
