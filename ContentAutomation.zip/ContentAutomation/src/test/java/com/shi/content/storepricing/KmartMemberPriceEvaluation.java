package com.shi.content.storepricing;

import java.io.IOException;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.OfferSchema;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;

public class KmartMemberPriceEvaluation implements Runnable {

	String processLine;
	String storeID;
	boolean pricingHit = false;
	String currentProductId ;
	static AtomicInteger countOfNullPricedItems = new AtomicInteger(0);
	String eventFlag;
	
	public KmartMemberPriceEvaluation(String lineToProcess){
		
		this.processLine = lineToProcess;
	}
	
	
	public void run()
	
	
	{
		
		String[] AfterLineSplit= processLine.split("\\|");
		storeID=AfterLineSplit[0];
		String upcCode1=AfterLineSplit[2];       //upc no of item. catentry_id.field4
		String upcTypeCode=AfterLineSplit[22];
		String upcPriceTypeCode=AfterLineSplit[26];  /////will determin the type of upc code .....value 1 for regular and value 3 for clearnce
		String UpcPriceAmt=AfterLineSplit[21];    //value for regular and clearance price
		String UpcPriceMul=AfterLineSplit[17];    //multiple value for regular and clearance price
		String AssosDisPrice=AfterLineSplit[32];  //Associated price amount
		String AssoDiscMul=AfterLineSplit[33];     ////associated price multiple
		String wasPrice=AfterLineSplit[41];         ////was price amount
		String wasPriceMul=AfterLineSplit[42];     ///was price multiple
		String eventPrice=AfterLineSplit[20];       //Sale price
		String eventPriceMul=AfterLineSplit[16];     //sale price multiple
		eventFlag=AfterLineSplit[36];         ///Sale flag
		String eventEndDate=AfterLineSplit[35];      ///sale end date
		String mpViolation=MapVal(AfterLineSplit);
			try {

				if((Double.parseDouble(allPriceMultipiler(eventPrice, eventPriceMul)) < 0.03)
						&& Double.parseDouble(allPriceMultipiler(AssosDisPrice, AssoDiscMul)) < 0.03
						&& ((Double.parseDouble(allPriceMultipiler(UpcPriceAmt, UpcPriceMul)) < 0.03) && (upcPriceTypeCode.equals("1")))
						){  //reg, sale and associate price 
					// if zero will not be loaded
					/*System.out.println("UPC " +upcCode1+ " Was price : "+ wasPrice + " AssocDisPrice "+ AssosDisPrice + " eventPrice "+ eventPrice
							+"  UPCPrice "+ UpcPriceAmt+ " Multipliers "+ AssoDiscMul);*/
					countOfNullPricedItems.getAndIncrement();
					String upcCode=getUpc(upcTypeCode, upcCode1);
					upcFileWriting(upcCode);
					return;
				}
				///logic to get each line from file
				//String Line="7840| |0028332473842|N|N| |N|1|N|0000000000000| |Y| |048|00|00|00|01|00|00000000|00000000|00000001|0|N|000|022|3|0|25954411|000|        |010|00000001|01|      | |N| |0000|0000|00|00000399|01|        | |";

				String upcCode=getUpc(upcTypeCode, upcCode1); //this method will extract the actual upc code


				if (storeID.equals("7840")||storeID.equals("7783"))
				{
					List<String> pIds=new ArrayList<String>();   //to get list of products under the upc.
					pIds=RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"upc",upcCode); 
					
					
					if (pIds.isEmpty()==true)    ///check if upc has no records
					{
						upcFileWriting(upcCode);
						System.out.println("upc that is not present in GB"+upcCode);
						return;
					}
					else{
						if (pIds.size() > 2)
							System.out.println("UPC is "+ upcCode + " Size "+ pIds.size());
						System.out.println("upc that is  present in GB"+upcCode);
						List<OfferSchema> offerObjs = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_SCHEMA, pIds);
						Map<String, ShcPricing> allPricingDocs = null;
						
						
//						for(int i=0;i<pIds.size();i++)    //after getting list of products under the pid, checking prices for all the products in the list
						for(OfferSchema ofd: offerObjs)
						{
							CompareValuesUtility.init();
//							String productId=pIds.get(i);//ofd.getId();//
							String productId=ofd.getId();//
//							OfferSchema ofd=RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFERSCHEMA, productId);
						    String pgType=ofd.getFt().getPgrmType();
						    System.out.println(productId+pgType);
						   
							if (pgType == null || !pgType.equals("Kmart"))          /// to filter out only kmart partnumbers under below upc  
							{  
								String storeProductId=storeID+"-"+productId;
								if (validateSearsNotPresent(storeProductId))
								{	
									CompareValuesUtility.logFailed("Id", storeProductId, "Found in GB");    /////////
								    CompareValuesUtility.setupResult(storeProductId, true);
								     continue;                       
								}
								else {  
									productFileWriting(storeProductId);  ///write in log file that invalid store product Id is not written to the GB
									continue;
								     }
							}
							
							/////incase a VD item gets upcprice code as 3 and has price less than 0.02, it should also get rejected
							String channel1=ofd.getBlob().getOffer().getFfm().getChannel();
							if (channel1!=null && channel1.equals("VD") && (upcPriceTypeCode.equals("3")))
							{  if (Double.parseDouble(allPriceMultipiler(UpcPriceAmt, UpcPriceMul)) < 0.03)
							   { countOfNullPricedItems.getAndIncrement();
								 upcFileWriting(upcCode);
								 return; }
							}
							String storeProductId=(storeID+"-"+productId);
							 
							ShcPricing storePricingGB;
							
							
							URI pricingURI2;
							if(pIds.size() > 1){
								if(!pricingHit)
									allPricingDocs = hitSHCPricingForMultipleIds(pIds, storeID);
								storePricingGB = allPricingDocs.get(productId);
							}
							else
								
							{ 
								pricingURI2 = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, storeProductId);
							  
								storePricingGB = RestExecutor.getDataById(pricingURI2, CollectionValuesVal.SHCPRICING);}
								
								//storePricingGB = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,storeProductId);
								if (storePricingGB==null)
								{
									//System.out.println("No data found for the "+ storeProductId);
									//CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
									CompareValuesUtility.logFailed("Id", storeProductId, "Not found in GB");
									CompareValuesUtility.setupResult(storeProductId, true);
									continue;
								}
								else{
	
									CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
									//to check if item is giftcard or if it is giftwrap eligible
									
									//TODO:: Change this after holidays - NV
									CompareValuesUtility.logPassed("EventFlag", eventFlag, eventFlag);
									
									
									String channel=ofd.getBlob().getOffer().getFfm().getChannel();
									if (channel!=null && channel.equals("VGC"))
									{ 
										compareVGCPrices(storePricingGB,productId);
										CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
										CompareValuesUtility.setupResult(storeProductId, true);
										continue;
									}
									
									if (channel!=null && channel.equals("VD"))
									{   
										compareVDItemPrices(storePricingGB,storeProductId,upcCode,upcPriceTypeCode,UpcPriceAmt,UpcPriceMul,AssosDisPrice,AssoDiscMul,wasPrice,wasPriceMul,eventPrice,eventPriceMul,eventFlag,eventEndDate,mpViolation);
										 									
										CompareValuesUtility.setupResult(storeProductId, true);
										continue;
									}
									
									//compareVDItemPrices
	
									compareAllPrices(storePricingGB,storeProductId,upcCode,upcPriceTypeCode,UpcPriceAmt,UpcPriceMul,AssosDisPrice,AssoDiscMul,wasPrice,wasPriceMul,eventPrice,eventPriceMul,eventFlag,eventEndDate,mpViolation);
	
									//////DP method to check expire Dp dates or not
	
	
									CompareValuesUtility.setupResult(storeProductId, true);
									
	
								}  ////end of else for checking storePricingGB==null
							
						}/////end of else for checking  if list of pids is not empty

					}

				}


				else {          ////for stores other than national store
					long l1 = System.currentTimeMillis();
					List<String> pIds;  //to get list of products under the upc.
					System.out.println(upcCode);
					pIds= RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"upc",upcCode);  
					if (pIds.isEmpty()==true)    ///check if upc has no partnumbers associated with upc no are processed
					{ 
						upcFileWriting(upcCode);
						return;
					}
					
					for(int i=0;i<pIds.size();i++)    //after getting list of products under the pid, checking prices for all the products in the list
					{
						
						String productId=pIds.get(i);
						currentProductId = productId;
						if (productId.length()<12)          /// to filter out only kmart partnumbers under below upc  
						{ continue;                       
						}
						String storeProductId=storeID+"-"+productId;
                        
						CompareValuesUtility.init();
						
						URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, storeProductId);
						 
						ShcPricing	 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
						
					//	ShcPricing storePricingGB = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, storeProductId);
						if (storePricingGB==null)
							CompareValuesUtility.logPassed("Id", "not expected in DB "+storeProductId, "Not occuring in DB");
						else {  
							
							CompareValuesUtility.logFailed("Id", "Not expected in DB "+storeProductId, "Data occuring in DB");

						     }

						CompareValuesUtility.setupResult(storeProductId, true);

					}
					
					System.out.println("Time for non-store "+ (System.currentTimeMillis() - l1));

				}
			} catch (Exception e) {

				System.out.println("[Exception occured]Please check this storeID : "+storeID+ "  upc code id:"+ upcCode1);
				
				e.printStackTrace();
			}


	}
	
	private Map<String, ShcPricing> hitSHCPricingForMultipleIds(List<String> pids, String storeId){
		
		Map<String, ShcPricing> pricingDocs = new HashMap<String, ShcPricing>();
		List<String> pricingIds = new ArrayList<String>();
		for(String pid : pids){
			pricingIds.add(storeID+"-"+pid);
		}
		
		
			URI pricingURI1 = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING,pricingIds );
			
			System.out.println("URI in hitSHCPricingForMultipleIds " + pricingURI1);
		List<ShcPricing> storePricingDocs = RestExecutor.getDataByListOfIds(pricingURI1, CollectionValuesVal.SHCPRICING);
			//System.out.println("Size of storePricingDocs "+ storePricingDocs.size());
			
			if(!(storePricingDocs == null)){
			for(ShcPricing storePricingDoc : storePricingDocs){
				pricingDocs.put(storePricingDoc.getPid(), storePricingDoc);
			}
		}
		pricingHit = true;
		return pricingDocs;
		
	}
	
	
	public String MapVal(String[] AfterLineSp)	
	{if (AfterLineSp.length==46)
		{return AfterLineSp[45];
		}
	else return " ";
    }

	/*
	 * will multiply the prices with multiplier and return value. For null prices will return zero
	 * 
	 * */
	public String allPriceMultipiler(String a,String b)   
	{  
		if ((a.equals("") && b.equals(""))|| a.equals(""))
			return "0.0";
		else if (b==null || b.equals("00") || b.equals("000") || b.equals("0"))
		{
			Double a1 =  0.0;
			return a1.toString();
		} else {
			Double a1 = Double.parseDouble(a);
			Double b1 = Double.parseDouble(b);
			a1 = (a1 / 100) / b1;
//			a1 = ;
			Double returnVal = Double.parseDouble(TestUtils.roundToNDigits(a1, 2));
			return returnVal.toString();
		}
	}
	

		
	
	
	/**
	 * to check for 89 percantage rule....if ((R-P)/R)*100 > 89 ignore sale price
	 * @param R  regular price
	 * @param P  sale price 
	 * @param upctypeR upctype=1
	 * @return
	 */
	public boolean checkPercentage(Double R,Double P, Double W,String upctypeR)
	{  boolean b=false;
		if (upctypeR.equals("1"))
		{	double val=((R-P)/R)*100;
		    val=Double.parseDouble(TestUtils.roundToNDigits(val,2));
			if (val>89.00)
			{b=true;
			return b;}
			else return b;
		}
		else if (upctypeR.equals("3"))
		{   double val1=((W-P)/R)*100;
			val1=Double.parseDouble(TestUtils.roundToNDigits(val1,2));
			if (val1>89.00)
			{b=true;
			return b;}
			
		}
		return b;
			
	}
	
	
	public boolean checkPercentageVD(Double R,Double P,String upctypeR)
	{boolean b=false;
	if (upctypeR.equals("1"))
	{	double val=((R-P)/R)*100;
	    val=Double.parseDouble(TestUtils.roundToNDigits(val,2));
		if (val>89.00)
		b=true;
		return b;
		
		}
	else return b;
	}
	
	public boolean validateStore(String stor) {
		if (KmartMemberPricingTest.storeIds.containsKey(stor)) {
			boolean storeStatus = KmartMemberPricingTest.storeIds.get(stor);
			return storeStatus;
		} else {

			String com = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, stor);
			if (com != "[]" || com != null) {
				KmartMemberPricingTest.storeIds.put(stor, true);
				return true;
			} else {
				KmartMemberPricingTest.storeIds.put(stor, false);
				return false;
			}
		}

	}

	/**
	 * Check if sears id is added in the kmart store pricing
	 * @param Searspid
	 * @return
	 */
	public boolean validateSearsNotPresent(String otherpid)
	{
		
		URI pricingURI1 = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING,otherpid );
		String Sr = RestExecutor.getDataById(pricingURI1, CollectionValuesVal.SHCPRICING);
		//String Sr=RestExecutor.getJSonResponseById(CollectionValuesVal.SHCPRICING,otherpid);
		if (Sr==null||Sr.equals("[]"))
		{
			//System.out.println("Partnumber not added to collection"+ otherpid);
			return false;
		}
		else
			return true;    //sears partnumber present in shc_pricing for kmart national pricing
	}



	public boolean compareSaleEndDate(String d1) { // method to check if date is valid or not
		Date d = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date c1 = sf.parse(sf.format(d)); // /to get current date

			Date a1 = sf.parse(convertDate(d1));
			if (a1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
	}




	public String convertDate(String d)
	{  String MM=d.substring(0, 2);
	String dd=d.substring(2, 4);
	String yyyy=d.substring(4,8);
	String date1=(yyyy+"-"+MM+"-"+dd);
	return date1;
	}

	public void compareVGCPrices(ShcPricing storePricingGB1,String storeProductId1)
	{
		if(storePricingGB1.getP().getR().size()== 1)
		{
			CompareValuesUtility.compareValues("Regular Price","10.0", storePricingGB1.getP().getR().get(0).getIp().toString());
		}
		else 
			CompareValuesUtility.logFailed("Regular Price","10.0", "Regular price not loaded for Gift card");

	}

	public void compareAllPrices(ShcPricing storePricingGB1,String storeProductId1,String upcCode1,String upcTypeCode1,String UpcPriceAmt1,String UpcPriceMul1,String AssosDisPrice1,String AssoDiscMul1,String wasPrice1,String wasPriceMul1,String eventPrice1,String eventPriceMul1,String eventFlag1,String eventEndDate1,String mpv)
	{   
		
		boolean PcRule=false;
		  
		  Double Rprice=Double.parseDouble(allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1));
		  Double Wprice=Double.parseDouble(allPriceMultipiler(wasPrice1,wasPriceMul1));
		  Double Pprice=Double.parseDouble(allPriceMultipiler(eventPrice1, eventPriceMul1));
		 
		  
		  PcRule=checkPercentage(Rprice,Pprice,Wprice,upcTypeCode1);
		if(eventFlag1.equals("Y") && compareSaleEndDate(eventEndDate1) && PcRule==false)   //to compare sale price   //PcRule is false when 89% rule is exceeded
		{ String EventPrice=allPriceMultipiler(eventPrice1, eventPriceMul1);

		String convertedDate=DateConverts(eventEndDate1.toString());

		if (Double.parseDouble(EventPrice)>0.02)
		{ if(storePricingGB1.getP().getS().size()== 1)
		    {   CompareValuesUtility.compareValues("Sale Price",  EventPrice.toString(), storePricingGB1.getP().getS().get(0).getIp().toString());
		        CompareValuesUtility.compareValues("Sale End Date",convertedDate,storePricingGB1.getP().getS().get(0).getEt().toString().substring(0,10));
		      //to compare member price values
		        CompareValuesUtility.compareValues("MemberPricing",mpv.equals("1")? true: false,storePricingGB1.getMpf() == null? null : storePricingGB1.getMpf().getMp());
		        System.out.println(storePricingGB1.getPid()+' '+storePricingGB1.getMpf().getMp());
		     }
		  else 
			  CompareValuesUtility.logFailed("Sale Price",EventPrice.toString() , "Sale price not loaded");
		}  
		else 
		{ 
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
		}  
		}		
	}
	
	public void compareVDItemPrices(ShcPricing storePricingGB1,String storeProductId1,String upcCode1,String upcTypeCode1,String UpcPriceAmt1,String UpcPriceMul1,String AssosDisPrice1,String AssoDiscMul1,String wasPrice1,String wasPriceMul1,String eventPrice1,String eventPriceMul1,String eventFlag1,String eventEndDate1,String mpv)
	{   
		 boolean PcRule=false;
		  
		 Double Rprice=Double.parseDouble(allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1));
		 Double Pprice=Double.parseDouble(allPriceMultipiler(eventPrice1, eventPriceMul1));
		 
		  
		  PcRule=checkPercentageVD(Rprice,Pprice,upcTypeCode1);	

		if(eventFlag1.equals("Y") && compareSaleEndDate(eventEndDate1)  && PcRule==false)   //to compare sale price
		{ String EventPrice=allPriceMultipiler(eventPrice1, eventPriceMul1);

		String convertedDate=DateConverts(eventEndDate1.toString());

		if (Double.parseDouble(EventPrice)>0.02)
		{ if(storePricingGB1.getP().getS().size()== 1)
		    {   CompareValuesUtility.compareValues("Sale Price",  EventPrice.toString(), storePricingGB1.getP().getS().get(0).getIp().toString());
		        CompareValuesUtility.compareValues("Sale End Date",convertedDate,storePricingGB1.getP().getS().get(0).getEt().toString().substring(0,10));
		       //to compare member price values
		        CompareValuesUtility.compareValues("MemberPricing",mpv.equals("1")? true: false,storePricingGB1.getMpf() == null? null : storePricingGB1.getMpf().getMp());
		        System.out.println(storePricingGB1.getPid()+' '+storePricingGB1.getMpf().getMp());
		     }
		  else 
			  CompareValuesUtility.logFailed("Sale Price",EventPrice.toString() , "Sale price not loaded");
		}  
		else 
		{ 
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
		}  
		}
		
	}
	
	
	
	
	
	public boolean nationalValidation(String product_Id)
	{
		boolean NationalValidation=false; 
		Offer offer=RestExecutor.getDataById(CollectionValuesVal.OFFER, product_Id);  ///get offer
		if(offer.getDispTags().getIsGiftWrapElig())
			return NationalValidation;
		else 
		{
			NationalValidation=true;
			return NationalValidation;
		}

	}

	/**
	 * 
	 * @param upcTypeCode   will be 0 (12 digit upc)  
	 * 1,2(8 digit upc)  ,3 (13 digit upc) ,7 (14 digit upc) 
	 * @param upc
	 * @return
	 */
	public String getUpc(String upcTypeCode, String upc)
	{  String tmp=upc;
		String upcCode;
		if(upcTypeCode.equalsIgnoreCase("0"))
		{
			upcCode=tmp.substring(tmp.length()-12, tmp.length());
			return upcCode;
		}       
		else if(upcTypeCode.equalsIgnoreCase("1") || upcTypeCode.equalsIgnoreCase("2"))
		{
			upcCode=tmp.substring(tmp.length()-8, tmp.length());
			return upcCode;
		}       
	
		else if(upcTypeCode.equalsIgnoreCase("3"))
		{
			upcCode=tmp.substring(tmp.length()-13, tmp.length());
			return upcCode;
		}       
		else if(upcTypeCode.equalsIgnoreCase("7"))
		{
			upcCode=tmp.substring(tmp.length()-14, tmp.length());
			return upcCode;
		}
		return upc;  ///meaning invalid upc which will get rejected
	}

	/***
	 * to get the dat in format as in response in GB. however not exactly in iso format
	 * @param s
	 * @return
	 */
	public String DateConverts(String s)
	{   String mm=s.substring(0, 2);
	String dd=s.substring(2, 4);
	String yy=s.substring(4,8);
	//Date d=new Date();
	//String a=(yy+"-"+mm+"-"+dd);

	return (yy+"-"+mm+"-"+dd);

	}
	
	public static synchronized void upcFileWriting(String u)
	{
		try {
			KmartMemberPricingTest.invalidPartNumberWriter.write("No data returned for the upc " + u);
			KmartMemberPricingTest.invalidPartNumberWriter.newLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}
	
	public static synchronized void productFileWriting(String p)
	{
		try {
			KmartMemberPricingTest.invalidPartNumberWriter.write("_ft.prgmtype is not Kmart. Hence not written in shc_pricing collection "
					+ p);
			KmartMemberPricingTest.invalidPartNumberWriter.newLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
