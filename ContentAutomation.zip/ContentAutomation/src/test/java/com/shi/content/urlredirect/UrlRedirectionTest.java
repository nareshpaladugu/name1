package com.shi.content.urlredirect;

import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.testng.annotations.BeforeSuite;

import com.shc.autocontent.LoadProperties;

/**
 * @author ddaphal
 *
 */
public class UrlRedirectionTest 
{
	public static String sSearsURL = System.getProperty("SearsURL","http://www.sears.com/");

	public static String sKmartURL = System.getProperty("KmartURL","http://www.kmart.com/");

	@BeforeSuite
	public void set()
	{
		sSearsURL = System.getProperty("SearsURL","http://www.sears.com/");

		sKmartURL = System.getProperty("KmartURL","http://www.kmart.com/");
	}

	@org.testng.annotations.Test(groups="UrlRedirectionTest")
	public void testUrlRedirection()
	{

		System.out.println("SearsURL ... "+sSearsURL);
		System.out.println("KmartURL ... "+sKmartURL);

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		InnerVo vo = UrlRedirectionUtil.getOldURLMapData();

		Map<String, Map<String,LinkedList<URLVo>>>  oldMap = vo.getOldMapMap();

		LinkedList<URLVo> listUrls = vo.getSimpleListOfUrlData();

		int processed = 0;

		for (URLVo urlVo : listUrls) 
		{
			pool.execute(new UrlRedirectionTestVerification(UrlRedirectionUtil.getRedirectedUrl(urlVo,oldMap)));	

			processed++;

			if(LoadProperties.TESTDATALIMIT!=-1 && processed==LoadProperties.TESTDATALIMIT)
			{
				System.out.println("Processed required Data....");
				break;
			}
		}
	}
}
