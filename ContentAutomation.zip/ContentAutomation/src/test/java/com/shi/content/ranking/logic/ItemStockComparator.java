package com.shi.content.ranking.logic;
import java.io.Serializable;
import java.util.Comparator;

public class ItemStockComparator implements Comparator<GBRankBean> ,Serializable{
	public static final ItemStockComparator TRUE_LOW = new ItemStockComparator(false);
	public static final ItemStockComparator TRUE_HIGH = new ItemStockComparator(true);
	private final boolean trueLow;
	public ItemStockComparator(boolean trueLow) {
	    this.trueLow = trueLow;
	  }
	  
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
	}
		//System.out.println("ItemStockComparator.... "+e1.getPartnumber()+" : "+e1.getStoreName()+"   "+e2.getPartnumber()+" : "+e2.getStoreName());
		boolean v1 = e1.getStoreName().equals("Sears")||e1.getStoreName().equals("Kmart")?(e1.getInstock()||e1.getSpuEligible()||e1.getSresEligible()):e1.getInstock();
	    boolean v2 = e2.getStoreName().equals("Sears")||e2.getStoreName().equals("Kmart")?(e2.getInstock()||e2.getSpuEligible()||e2.getSresEligible()):e2.getInstock();
	    return (v1 ^ v2) ? ((v1 ^ this.trueLow) ? 1 : -1) : 0;
	}	

}

