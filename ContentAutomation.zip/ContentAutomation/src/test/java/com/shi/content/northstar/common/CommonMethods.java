package com.shi.content.northstar.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebElement;

import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.CheckBox;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.TextField;

public class CommonMethods extends BasePage {

	public CommonMethods(String pageName) {
		super(pageName);
	}

	public static String getFormattedDate(String date){
		
		if(date.equalsIgnoreCase("")||date==null){
			return null;
		}
		final String format1="m/d/yy";
		final String format2="mm/dd/yyyy";
		final String formatNew="yyyy-mm-dd";
		Date dObj= new Date();
		String newDate= date;
	
		if(date.length()>6&date.indexOf("/")==2){
			SimpleDateFormat sdf=new SimpleDateFormat(format2);
			sdf = new SimpleDateFormat(format2);
			try {
				dObj = sdf.parse(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			sdf.applyPattern(formatNew);
			newDate = sdf.format(dObj);		
		}else if(date.length()<7) {
			
			SimpleDateFormat sdf=new SimpleDateFormat(format1);
			sdf = new SimpleDateFormat(format1);
			
			try {
				dObj = sdf.parse(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sdf.applyPattern(formatNew);
			newDate = sdf.format(dObj);
	}
		return newDate;
		
	}
	
	public static String getRandomNumber(){
		Random rand = new Random();
		return Integer.toString(rand.nextInt(((5 - 1) + 1) + 1)); 
	}
	
	public static String getFormattedTime(String time){
		
		if(time.substring(0, 2).equalsIgnoreCase("12")){
			time=time.substring(0, 2).replace("12", "00");
		}
		return time; 
	}
	

}
