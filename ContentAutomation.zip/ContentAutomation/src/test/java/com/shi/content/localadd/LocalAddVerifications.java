package com.shi.content.localadd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.localadgrp.Localadgrp_;
import com.generated.vos.localoffer.Localoffer;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class LocalAddVerifications implements Runnable {

	static Map<String, Boolean> storeIds = new HashMap<String, Boolean>();
	String finalId = null;
	List<String> localadddata;
	int currentCount;

	public LocalAddVerifications(List<String> pricingDataForProduct,
			int currentC) {
		this.localadddata = pricingDataForProduct;
		this.currentCount = currentC;
	}

	public void run() {
		long l1 = System.currentTimeMillis();
		CompareValuesUtility.init();
		List<String> localadd = new ArrayList<String>();
		String[] singlePriceData = localadddata.get(0).split("\\|");
		// this Gbid is the main id that we hit with api in the greenbox
		/*String GbId = singlePriceData[1] + "_" + singlePriceData[0] + "_"
				+ singlePriceData[10] + "_" + singlePriceData[11] + "_"
				+ singlePriceData[5].replaceAll("/", "").substring(0, 8) + "_"
				+ singlePriceData[6].replaceAll("/", "").substring(0, 8);*/
		// storing data in each line in the list
		String gbMainid="";
		
		try{
		for (String s : localadddata) {
			localadd.add(s);

		}
		// getting data for each line and each field
		
		for (String id : localadd) {
			String[] afterSplit = id.split("\\|");
			String unitNumber = afterSplit[0];
			String Ksn = afterSplit[1];
			//String ProductRegPrice = afterSplit[2];
			String ProductRegPrice = afterSplit[3];
			//String ProductSalePrice = afterSplit[3];
			String ProductSalePrice = afterSplit[4];
			//String ProductClearancePrice = afterSplit[4];
			String ProductClearancePrice = afterSplit[5];
			String SaleStartDate = afterSplit[6];
			String SaleEndDate = afterSplit[7];
			String AdditionalDealInfo = afterSplit[8];
			String PriceQualifier = afterSplit[10];
			String FinePrint = afterSplit[12];
			String StoreID = afterSplit[11];
			String GroupID = afterSplit[30];
			String PostStartDate = afterSplit[13];
			String PostEndDate = afterSplit[14];
			String ListingStatus = afterSplit[31];
			
			Localoffer localGB1 = null;
			Localadgrp_ localgrp=null;
			int grpStoreId=0;
			 if(GroupID.equals("")){
	        	 gbMainid = Ksn + "_" + unitNumber + "_" + StoreID + "_"
	        				+ "X" + "_"
	        				+ SaleStartDate.replaceAll("/", "").substring(0, 8) + "_"
	        				+ SaleEndDate.replaceAll("/", "").substring(0, 8);
	         }else{
				 gbMainid = Ksn + "_" + unitNumber + "_" + StoreID + "_"
						+ GroupID + "_"
						+ SaleStartDate.replaceAll("/", "").substring(0, 8) + "_"
						+ SaleEndDate.replaceAll("/", "").substring(0, 8);
				 localgrp=RestExecutor.getDataById(CollectionValuesVal.LOCALADGRP,
							GroupID); 	
				 if(localgrp==null){
					 CompareValuesUtility.logFailed("Id",gbMainid, "localaddgrpnotpresent ");
					 CompareValuesUtility.setupResult(gbMainid, true);
					 return;
				 }
				 grpStoreId = localgrp.getStoreId().intValue();
	         }
			 double Cp=0; 
			 boolean cpvalue=false;
			 
			double Sp= Double.parseDouble(ProductSalePrice);
			if(!(ProductClearancePrice.equals(""))){
				if(ProductClearancePrice.matches("[0-9]+\\.[0-9]+$")){
			 Cp= Double.parseDouble(ProductClearancePrice);
			 cpvalue=true;
				}
			}else{
				cpvalue=true;	
			}
			double Rp= Double.parseDouble(ProductRegPrice);
		if(SaleStartDate.equals("") ||SaleEndDate.equals("")||!(unitNumber.matches("\\d+")) ||!(Ksn.matches("[a-zA-Z0-9]+$")) 
				||!(LoadProperties.Local_Store.contains(StoreID))||!(ProductRegPrice.matches("[0-9]+\\.[0-9]+$"))
				||!(ProductSalePrice.matches("[0-9]+\\.[0-9]+$"))||!(cpvalue)
				||(Sp>Rp)||(Cp>Rp) ||(!(SaleStartDate.equals("")) && !(AdditionalDealInfo.equals(""))) 
				||(!(ProductClearancePrice.equals("")) && !(AdditionalDealInfo.equals("")))||!(LoadProperties.Status.contains(ListingStatus))){
			localGB1 = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,
					gbMainid);
			if(localGB1==null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer notfound");
				CompareValuesUtility.setupResult(gbMainid, true);
			}
			//CompareValuesUtility.logFailed("Id","Not Valid","");
		}else{
		
			if(PostStartDate.equals(""))
				PostStartDate=SaleStartDate;
			if(PostEndDate.equals(""))
				PostEndDate=SaleEndDate;
		 
       int stId = Integer.parseInt(StoreID);
         if(!(GroupID.equals("")) && !(grpStoreId==stId) && !(GroupID.matches("\\d+"))){
        	System.out.println("Group ID mismatch"); 
        	CompareValuesUtility.logFailed("Id",gbMainid, "Group ID mismatch");
			CompareValuesUtility.setupResult(gbMainid, true);
         }else{
			System.out.println(gbMainid);
			
			localGB1 = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,
					gbMainid);
			if(localGB1==null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer notfound");
				CompareValuesUtility.setupResult(gbMainid, true);
				return;
			}
			System.out.println("*****************************************");
			APIResponse<Object> offerAllreponse = null;
			Offer offerGB = null;
			if(localGB1!=null && localGB1.getOfferId()!=null){
			offerAllreponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, localGB1.getOfferId());
			offerGB = offerAllreponse.getT();
			}
//			if(offerGB==null){
//				CompareValuesUtility.logFailed("Id",gbMainid,"Item deosnt have any offer id in offer collection");
//				CompareValuesUtility.setupResult(gbMainid, true);
//				return;
//			}

			if (StoreID.equals("10153")) {
				if(offerGB!=null && offerGB.getTaxonomy().getWeb().getSites()
						.getSears()==null){
					/*System.out.println("Ignoring sears item with out searssite"+gbMainid);
					CompareValuesUtility.logPassed("Id",gbMainid,"Ignoring sears item with out searssite");
					CompareValuesUtility.setupResult(gbMainid, true);
					return;*/
					VerifySears(gbMainid, Ksn,offerAllreponse,localGB1);	
				}
				CompareValuesUtility.compareValues("Id", gbMainid, localGB1.getId());
				
				if(localGB1!=null){
				CompareValuesUtility.compareValues("SaleStartDate",
						SaleStartDate==null?null:SaleStartDate, localGB1.getSaleStDt()
								==null?null:localGB1.getSaleStDt());
				CompareValuesUtility.compareValues("SaleEndDate", SaleEndDate
						.toString(), localGB1.getSaleEndDt().toString());
				CompareValuesUtility.compareValues("PostStartDate",
						PostStartDate.toString(), localGB1.getPostStDt()
								.toString());
				CompareValuesUtility.compareValues("PostEndDate", PostEndDate
						.toString(), localGB1.getPostEndDt().toString());
				CompareValuesUtility.compareValues("ksn", Ksn
						, localGB1.getKsn()==null?null:localGB1.getKsn());
				CompareValuesUtility.verifyNullOrEqual("PriceQualifier", PriceQualifier
						, localGB1.getPrcQlfr()==null?null:localGB1.getPrcQlfr());
				CompareValuesUtility.compareValues("SalePrice", ProductSalePrice
						, localGB1.getSp()==null?null:localGB1.getSp());
				CompareValuesUtility.compareValues("RegularPrice", ProductRegPrice
						, localGB1.getRp()==null?null:localGB1.getRp());
				CompareValuesUtility.verifyNullOrEqual("ClearancePrice", ProductClearancePrice
						, localGB1.getCp()==null?null:localGB1.getCp());
				CompareValuesUtility.compareValues("Status", ListingStatus
						, localGB1.getStatus()==null?null:localGB1.getStatus());
				CompareValuesUtility.compareValues("StoreId", StoreID
						, localGB1.getStoreId()==null?null:localGB1.getStoreId().intValue());
				CompareValuesUtility.compareValues("UnitNumber", unitNumber
						, localGB1.getUnitNbr()==null?null:localGB1.getUnitNbr());
				CompareValuesUtility.verifyNullOrEqual("AdditionalDealInfo", AdditionalDealInfo
						, localGB1.getAdtnlDeal()==null?null:localGB1.getAdtnlDeal());
				CompareValuesUtility.verifyNullOrEqual("FinePrint", FinePrint
						, localGB1.getFinePnt()==null?null:localGB1.getFinePnt());
				if(localgrp!=null){
				CompareValuesUtility.compareValues("grpid",localGB1.getGrpId(),localgrp.getId());	
				CompareValuesUtility.compareValues("grpDesc",localGB1.getGrpDesc(),localgrp.getDesc());	
				CompareValuesUtility.compareValues("grpName",localGB1.getGrpName(),localgrp.getName());	
				CompareValuesUtility.compareValues("grpSTdt",localGB1.getGrpStDt(),localgrp.getSttdt());	
				CompareValuesUtility.compareValues("grpEnddt",localGB1.getGrpEndDt(),localgrp.getEnddt());	
				CompareValuesUtility.compareValues("grpType",localGB1.getGrpType(),localgrp.getType());
				CompareValuesUtility.compareValues("grpDispOrd",localGB1.getGrpDispOrd(),localgrp.getDispOrd().intValue());
				CompareValuesUtility.compareValues("grpStatus",localGB1.getGrpStatus(),localgrp.getStatus().intValue());
				CompareValuesUtility.compareValues("grpStoreId",localGB1.getGrpStoreId(),localgrp.getStoreId().intValue());
				}
				}else{
					CompareValuesUtility.logFailed("Id",gbMainid,"No result found in gb");
				}
				
				
			} else if (StoreID.equals("10151")) {
				
				if(offerGB!=null && offerGB.getTaxonomy().getWeb().getSites()
						.getKmart()==null){
					/*System.out.println("Ignoring kmart item with out kmartsite"+gbMainid);
					CompareValuesUtility.logPassed("Id",gbMainid,"Ignoring kmart item with out kmartsite");
					CompareValuesUtility.setupResult(gbMainid, true);
					return;*/
					VerifyKmart(gbMainid, Ksn,offerAllreponse,localGB1);	
				}
				CompareValuesUtility.compareValues("Id", gbMainid, localGB1.getId());
				
				CompareValuesUtility.compareValues("SaleStartDate",
						SaleStartDate.toString(), localGB1.getSaleStDt()
								.toString());
				CompareValuesUtility.compareValues("SaleEndDate", SaleEndDate
						.toString(), localGB1.getSaleEndDt().toString());
				CompareValuesUtility.compareValues("PostStartDate",
						PostStartDate.toString(), localGB1.getPostStDt()
								.toString());
				CompareValuesUtility.compareValues("PostEndDate", PostEndDate
						.toString(), localGB1.getPostEndDt().toString());
				CompareValuesUtility.compareValues("ksn", Ksn
						, localGB1.getKsn()==null?null:localGB1.getKsn());
				CompareValuesUtility.verifyNullOrEqual("PriceQualifier", PriceQualifier
						, localGB1.getPrcQlfr()==null?null:localGB1.getPrcQlfr());
				CompareValuesUtility.compareValues("SalePrice", ProductSalePrice
						, localGB1.getSp()==null?null:localGB1.getSp());
				CompareValuesUtility.compareValues("RegularPrice", ProductRegPrice
						, localGB1.getRp()==null?null:localGB1.getRp());
				CompareValuesUtility.verifyNullOrEqual("ClearancePrice", ProductClearancePrice
						, localGB1.getCp()==null?null:localGB1.getCp());
				CompareValuesUtility.compareValues("Status", ListingStatus
						, localGB1.getStatus()==null?null:localGB1.getStatus());
				CompareValuesUtility.compareValues("StoreId", StoreID
						, localGB1.getStoreId()==null?null:localGB1.getStoreId().intValue());
				CompareValuesUtility.compareValues("UnitNumber", unitNumber
						, localGB1.getUnitNbr()==null?null:localGB1.getUnitNbr());
				CompareValuesUtility.verifyNullOrEqual("AdditionalDealInfo", AdditionalDealInfo
						, localGB1.getAdtnlDeal()==null?null:localGB1.getAdtnlDeal());
				CompareValuesUtility.verifyNullOrEqual("FinePrint", FinePrint
						, localGB1.getFinePnt()==null?null:localGB1.getFinePnt());
				
				if(localgrp!=null){
					CompareValuesUtility.compareValues("grpid",localGB1.getGrpId(),localgrp.getId());	
					CompareValuesUtility.compareValues("grpDesc",localGB1.getGrpDesc(),localgrp.getDesc());	
					CompareValuesUtility.compareValues("grpName",localGB1.getGrpName(),localgrp.getName());	
					CompareValuesUtility.compareValues("grpSTdt",localGB1.getGrpStDt(),localgrp.getSttdt());	
					CompareValuesUtility.compareValues("grpEnddt",localGB1.getGrpEndDt(),localgrp.getEnddt());	
					CompareValuesUtility.compareValues("grpType",localGB1.getGrpType(),localgrp.getType());
					CompareValuesUtility.compareValues("grpDispOrd",localGB1.getGrpDispOrd(),localgrp.getDispOrd().intValue());
					CompareValuesUtility.compareValues("grpStatus",localGB1.getGrpStatus(),localgrp.getStatus().intValue());
					CompareValuesUtility.compareValues("grpStoreId",localGB1.getGrpStoreId(),localgrp.getStoreId().intValue());
				}
			} else {
				CompareValuesUtility.logFailed("Id",gbMainid,"No result found in gb");
				CompareValuesUtility.setupResult(gbMainid, true);
			}
			
			// Here starts the actual code api...Currenlty once you run this
			// with the small csv file that was there we are getting the output
			// correclty----
		}
		//CompareValuesUtility.setupResult(GbId, true);
		
		}
		CompareValuesUtility.setupResult(gbMainid, true);
		}
		}catch(Throwable e){
			System.out.println("Check this id :"+ gbMainid);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	
	public void VerifySears(String Mainid, String Ksnid, APIResponse<Object> offerAllreponse, Localoffer localGB) {
		String ksnname = "ksn";
		//Localoffer localGB = null;
		//APIResponse<Object> offerAllreponse = null;
		//localGB = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,Mainid);
		List<String> divtemList = RestExecutor.getIdsByAltKey(
				CollectionValuesVal.OFFER, ksnname, Ksnid);
		if (divtemList.isEmpty()||!(divtemList.contains(localGB.getOfferId()))) {
			System.out.println("No Offers Found");
		} else {
				//offerAllreponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, localGB.getOfferId());
			if (offerAllreponse.getFtFieldValue("pgrmType").equals("Sears")) {
				String contentId = offerAllreponse.getSearchFieldValue("parentId");
				Offer offerGB = offerAllreponse.getT();
				String offerid = offerGB.getId();
				String vertical=null;
				String category=null;
				String subcategory=null;
				String leaf=null;
				String path=null;
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getSears()!=null){
				vertical = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(0).getName();
				category = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getName();
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().size()>2){
				 subcategory = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(2).getName();
				}
				int j = (offerGB.getTaxonomy().getWeb().getSites().getSears()
						.getHierarchies().get(0).getSpecificHierarchy().size()) - 1;
				leaf = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(j).getName();
				path = vertical;
				for (int m = 1; m < offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().size(); m++) {
					path = path
							+ "/"
							+ offerGB.getTaxonomy().getWeb().getSites()
									.getSears().getHierarchies().get(0)
									.getSpecificHierarchy().get(m).getName();

				}
				}else{
					CompareValuesUtility.logFailed("Id",Mainid,"No SearsHierarchy value in offer");	
				}
				if(localGB!=null){
			
				CompareValuesUtility.verifyNullOrEqual("BrandName", localGB
						.getBrandName()==null?null:localGB
								.getBrandName(), offerGB.getBrandName()==null?null:offerGB.getBrandName()
						);
				CompareValuesUtility.compareValues("offerId", localGB
						.getOfferId().toString(), offerid);
				CompareValuesUtility.compareValues("ContentId", localGB
						.getContentId().toString(), contentId);
				CompareValuesUtility.verifyNullOrEqual("vertical", localGB
						.getVertical()==null?null:localGB
								.getVertical(), vertical);
				CompareValuesUtility.verifyNullOrEqual("Category", localGB
						.getCategory()==null?null:localGB
								.getCategory(), category);
				CompareValuesUtility.verifyNullOrEqual("SubCategory", localGB
						.getSubcategory()==null?null:localGB
								.getSubcategory(), subcategory);
				CompareValuesUtility.verifyNullOrEqual("Leaf", localGB.getLeaf()==null?null:localGB.getLeaf()
						, leaf);
				CompareValuesUtility.verifyNullOrEqual("Catgrppath", localGB
						.getCtgrpPath()==null?null:localGB
								.getCtgrpPath(), path);
				}
			}
			
			
		}

	}
	
	
	
	public void VerifyKmart(String Mainid, String Ksnid, APIResponse<Object> offerAllreponse, Localoffer localGB) {
		String ksnname = "ksn";
		//Localoffer localGB = null;
		//APIResponse<Object> offerAllreponse = null;
		//localGB = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,
				//Mainid);
		List<String> divtemList = RestExecutor.getIdsByAltKey(
				CollectionValuesVal.OFFER, ksnname, Ksnid);
		if (divtemList.isEmpty()||!(divtemList.contains(localGB.getOfferId()))) {
			System.out.println("No Offers Found");
		} else {
				//offerAllreponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, localGB.getOfferId().toString());
				

			if (offerAllreponse.getFtFieldValue("pgrmType").equals("Kmart")) {
				
				String contentId = offerAllreponse.getSearchFieldValue("parentId");
				Offer offerGB = offerAllreponse.getT();

				String offerid = offerGB.getId();
				String vertical=null;
				String category=null;
				String subcategory=null;
				String leaf=null;
				String path=null;
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getKmart()!=null){
				vertical = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(0).getName();
				category = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getName();
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().size()>2){
				 subcategory = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(2).getName();
				}
				int j = (offerGB.getTaxonomy().getWeb().getSites().getKmart()
						.getHierarchies().get(0).getSpecificHierarchy().size()) - 1;
			leaf = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(j).getName();
				path = vertical;
				for (int m = 1; m < offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().size(); m++) {
					path = path
							+ "/"
							+ offerGB.getTaxonomy().getWeb().getSites()
									.getKmart().getHierarchies().get(0)
									.getSpecificHierarchy().get(m).getName();

				}
				}else{
					CompareValuesUtility.logFailed("Id",Mainid,"No KmartHierarchy value in offer");	
				}
				if(localGB!=null){
				
				CompareValuesUtility.verifyNullOrEqual("BrandName", localGB
						.getBrandName()==null?null:localGB
								.getBrandName(), offerGB.getBrandName()==null?null:offerGB.getBrandName()
						);
				CompareValuesUtility.compareValues("offerId", localGB
						.getOfferId().toString(), offerid);
			    CompareValuesUtility.compareValues("contentId", localGB
						.getContentId().toString(), contentId);
				CompareValuesUtility.verifyNullOrEqual("vertical", localGB
						.getVertical()==null?null:localGB
								.getVertical(), vertical);
				CompareValuesUtility.verifyNullOrEqual("Category", localGB
						.getCategory()==null?null:localGB
								.getCategory(), category);
				CompareValuesUtility.verifyNullOrEqual("SubCategory", localGB
						.getSubcategory()==null?null:localGB
								.getSubcategory(), subcategory);
				CompareValuesUtility.verifyNullOrEqual("Leaf", localGB.getLeaf()==null?null:localGB.getLeaf()
						, leaf.toString());
				CompareValuesUtility.verifyNullOrEqual("Catgrppath", localGB
						.getCtgrpPath()==null?null:localGB
								.getCtgrpPath(), path);
				}
			
			}
			
			}
		}

	

}