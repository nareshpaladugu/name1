package com.shi.content.ranking.vos;

import java.util.List;

public class Shippingdetailsresponse {
	
	private List<SuccessItem> successItems;

	public List<SuccessItem> getSuccessItems() {
		return successItems;
	}

	public void setSuccessItems(List<SuccessItem> successItems) {
		this.successItems = successItems;
	}

}
