package com.shi.content.wcsmigration.commons;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.shi.content.wcsmigration.commons.vos.EligibilityVo;
import com.shi.content.wcsmigration.commons.vos.RuleVO;
import com.shi.content.wcsmigration.tests.OfferEligibilityTest_Evaluate;

/**
 * @author ddaphal
 *
 */
public class OfferEligibilityUtils 
{
	public static final String OfferAttrsPrefix ="_blob.offerattrs.";
	
	public static 	List<EligibilityVo> readMappingFile()
	{
		Row row= null;
		String sheetName=null;
		int colInd = 0;

		List<EligibilityVo> output = new ArrayList<EligibilityVo>();

		Cell defaultValsCell;

		try {

			File f=new File("src/test/resources/wcsmigration/rules_mapping1.xlsx");

			Workbook wb = WorkbookFactory.create(f);

			int sheetCount = wb.getNumberOfSheets();

			String fieldsToVerify = System.getProperty("fieldsToVerify", "SAMs Rules").trim();

			OfferEligibilityTest_Evaluate.fieldsToVerify = fieldsToVerify;
			List <String> rulesToExecute =null;

			boolean bRuleBasedExecution = false;

			if(fieldsToVerify.startsWith("rules="))
			{
				fieldsToVerify=fieldsToVerify.replaceFirst("rules=", "");
				//specific rules
				rulesToExecute = Arrays.asList(fieldsToVerify.toLowerCase().split(","));
				bRuleBasedExecution = true;
			}

			List <String> tabsToExecute = Arrays.asList(fieldsToVerify.toLowerCase().split(","));

			Sheet sheet =null;

			for (int i = 0; i < sheetCount; i++) {

				sheet =	wb.getSheetAt(i);

				sheetName = sheet.getSheetName();

				
				if(sheetName.equals("Master") || sheetName.contains("#"))
				{
					// Ignore Master sheet 
					continue;
				}

				System.out.println(sheetName);
				if(!bRuleBasedExecution && !fieldsToVerify.equalsIgnoreCase("ALL") && !tabsToExecute.contains(sheetName.toLowerCase()))
				{
					//not all? then check for specific sheets
					continue;
				}

				int rows = sheet.getPhysicalNumberOfRows();

				if(rows<=1)
				{
					System.out.println("\t EMPTY SHEET");
					continue;
				}

				Map<String,LinkedList<RuleVO>> ruleListMap=new HashMap<String, LinkedList<RuleVO>>();

				EligibilityVo eligibilityVo = new EligibilityVo();

				String sTempRuleName;

				eligibilityVo.setTabName(sheetName);

				for (int ii =1; ii <=rows; ii++) 
				{
					row = sheet.getRow(ii);

					if(row==null)
					{
						continue;
					}

					RuleVO ruleVO = new RuleVO();

					//output field should be there
					if(row.getCell(2)==null || row.getCell(2).toString().trim().isEmpty())
					{
						continue;
					}

					List<String> conditions = new ArrayList<>();

					colInd = 0;

					try { 

						sTempRuleName = row.getCell(colInd++).toString().trim();

						if(bRuleBasedExecution)
						{
							if(sTempRuleName.isEmpty())
							{
								//rule name is must
								continue;
							}

							if(!rulesToExecute.contains(sTempRuleName.toLowerCase()))
							{
								//Not a required rule
								continue;
							}
						}

						ruleVO.setRuleName(sTempRuleName);

					} catch (Exception e)
					{	
						if(bRuleBasedExecution) 
							continue;	

						ruleVO.setRuleName("");		
					}


					try { 	ruleVO.setSkip(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setSkip("");			}

					if(ruleVO.getSkip().equalsIgnoreCase("x"))
					{
						continue;
					}
					try { 	ruleVO.setOutputField(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setOutputField("");			}
					try { 	ruleVO.setOutputValue(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setOutputValue("");			}

					try { 	ruleVO.setSite(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setSite("");			}

					//read conditions
					for (int j = 0; j < 10; j++) {

						try { 	conditions.add(row.getCell(colInd++).toString());		} catch (Exception e) {			}
					}

					//try { 	ruleVO.setComments(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setComments("");			}

					ruleVO.setConditions(conditions);


					try { 	 defaultValsCell = row.getCell(colInd++);

					if(defaultValsCell!=null)
					{
						String defaultVals = defaultValsCell.toString();
						if(defaultVals!=null && !defaultVals.isEmpty())
						{
							String sp[] = defaultVals.split(",");

							if(sp.length>0)
							{
								Map<String,String> defaultValMap = new HashMap<String, String>();

								for (String string : sp) {

									defaultValMap.put(string.split("=")[0].trim(),string.split("=")[1].trim());
								}

								ruleVO.setDefaultValues(defaultValMap);
							}
						}
					}
					} catch (Exception e) {			

						e.printStackTrace();
						System.out.println("Default values error........");
					}

					try { 	ruleVO.setComments(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setComments("");			}

					//try { 	ruleVO.setDefaultOutputValue(row.getCell(colInd++).toString());		} catch (Exception e) {		ruleVO.setDefaultOutputValue("");			}

					LinkedList<RuleVO> list = ruleListMap.get(row.getCell(2).toString().trim());

					if(list == null )
					{
						list = new LinkedList<RuleVO>();
					}

					list.add(ruleVO);

					ruleListMap.put(row.getCell(2).toString().trim(),list);

				}

				if(ruleListMap.isEmpty())
				{
					//no rules to process
					continue;
				}
				eligibilityVo.setRuleList(ruleListMap);

				output.add(eligibilityVo);
			}

			
			System.out.println("-----------------");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return output;

	}
}
