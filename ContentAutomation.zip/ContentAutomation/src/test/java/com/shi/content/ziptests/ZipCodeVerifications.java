package com.shi.content.ziptests;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.zipNew.Kmart_;
import com.generated.vos.zipNew.Mp;
import com.generated.vos.zipNew.Mygofer_;
import com.generated.vos.zipNew.NonMp;
import com.generated.vos.zipNew.Puertorico_;
import com.generated.vos.zipNew.Sears_;
import com.generated.vos.zipNew.Zip;
import com.generated.vos.zipOld.AutoFee;
import com.generated.vos.zipOld.ChargeDet;
import com.generated.vos.zipOld.ConsldtrDet;
import com.generated.vos.zipOld.Kmart;
import com.generated.vos.zipOld.LdOrdCon;
import com.generated.vos.zipOld.LmpArea;
import com.generated.vos.zipOld.Mygofer;
import com.generated.vos.zipOld.PkupOrdCon;
import com.generated.vos.zipOld.Puertorico;
import com.generated.vos.zipOld.Sears;
import com.generated.vos.zipOld.StrAttr;
import com.generated.vos.zipOld.ZipDist;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class ZipCodeVerifications implements Runnable
{
	private String zipCode;

	public ZipCodeVerifications(String zipCode)
	{
		this.zipCode=zipCode;
	}

	public void run() 
	{
		System.out.println("Testing zip : "+zipCode);

		String unitId =  null;

		CompareValuesUtility.init();

		com.generated.vos.zipOld.ZipcodeOld oldZip = ZipCodeHelper.getOldZip(zipCode);

		if(oldZip == null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("zipcode", "Not Found");
		}
		else
		{
			Zip newZip = RestExecutor.getDataById(CollectionValuesVal.ZIP_NEW, zipCode);

			if(newZip==null)
			{
				CompareValuesUtility.addFailedDataFieldForReport("zip", "Not Found");
			}
			else
			{
				com.generated.vos.zipOld.Zip oldZipobj = oldZip.getBlob().getZip();

				CompareValuesUtility.verifyNullOrEqual("City", oldZipobj.getCity(),newZip.getCity() );
				CompareValuesUtility.verifyNullOrEqual("ConcatDDCNo", oldZipobj.getConcatDDCNo(),newZip.getConcatDDCNo() );
				CompareValuesUtility.verifyNullOrEqual("County", oldZipobj.getCounty(),newZip.getCounty() );
				CompareValuesUtility.verifyNullOrEqual("DelvFee", oldZipobj.getDelvFee(),newZip.getDelvFee() );
				CompareValuesUtility.verifyNullOrEqual("Latitude", oldZipobj.getLatitude(),newZip.getLatitude() );
				CompareValuesUtility.verifyNullOrEqual("Longitude", oldZipobj.getLongitude(),newZip.getLongitude() );
				CompareValuesUtility.verifyNullOrEqual("SpuArea", oldZipobj.getSpuArea(),newZip.getSpuArea() );
				CompareValuesUtility.verifyNullOrEqual("State", oldZipobj.getState(),newZip.getState() );
				CompareValuesUtility.verifyNullOrEqual("WhiteSpaceFl", oldZipobj.getWhiteSpaceFl(),newZip.getWhiteSpaceFl() );
				CompareValuesUtility.verifyNullOrEqual("UnHdlvNo", oldZipobj.getUnHdlvNo(),newZip.getUnHdlvNo() );


				AutoFee autoFee = oldZipobj.getAutoFee();

				if(autoFee!=null)
				{
					if(newZip.getAutoFee()==null)
					{
						CompareValuesUtility.logFailed("AutoFee",autoFee,"Not Found");
					}
					else
					{
						CompareValuesUtility.verifyNullOrEqual("AutoFee.Disposal",autoFee.getDisposal(), newZip.getAutoFee().getDisposal());
						CompareValuesUtility.verifyNullOrEqual("AutoFee.DispPct",autoFee.getDispPct(), newZip.getAutoFee().getDispPct());
						CompareValuesUtility.verifyNullOrEqual("AutoFee.IsTaxElig",autoFee.getIsTaxElig(), newZip.getAutoFee().getIsTaxElig());
					}
				}

				LmpArea lmpArea = oldZipobj.getLmpArea();
				if(lmpArea!=null)
				{
					if(newZip.getLmpArea()==null)
					{
						CompareValuesUtility.logFailed("LmpArea",lmpArea,"Not Found");
					}
					else
					{
						CompareValuesUtility.verifyNullOrEqual("LmpArea.CldenrDays", lmpArea.getCldenrDays(),newZip.getLmpArea().getCldenrDays() );
						CompareValuesUtility.verifyNullOrEqual("LmpArea.Nm", lmpArea.getNm(),newZip.getLmpArea().getNm() );

						ConsldtrDet ConsldtrDet = lmpArea.getConsldtrDet();

						if(ConsldtrDet!=null)
						{
							if(newZip.getLmpArea().getConsldtrDet()==null)
							{
								CompareValuesUtility.logFailed("LmpArea.ConsldtrDet",ConsldtrDet,"Not Found");
							}
							else
							{
								CompareValuesUtility.verifyNullOrEqual("LmpArea.ConsldtrDet.Nm", ConsldtrDet.getNm(),newZip.getLmpArea().getConsldtrDet().getNm() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.ConsldtrDet.PrepTm", ConsldtrDet.getPrepTm(),newZip.getLmpArea().getConsldtrDet().getPrepTm() );
							}
						}

						PkupOrdCon PkupOrdCo = lmpArea.getPkupOrdCon();

						if(PkupOrdCo!=null)
						{
							if(newZip.getLmpArea().getPkupOrdCon()==null)
							{
								CompareValuesUtility.logFailed("LmpArea.PkupOrdCo",PkupOrdCo," Not Found");
							}
							else
							{
								CompareValuesUtility.verifyNullOrEqual("LmpArea.PkupOrdCo.EndTm", PkupOrdCo.getEndTm(),newZip.getLmpArea().getPkupOrdCon().getEndTm() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.PkupOrdCo.Rate", PkupOrdCo.getRate(),newZip.getLmpArea().getPkupOrdCon().getRate() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.PkupOrdCo.StrtTm", PkupOrdCo.getStrtTm(),newZip.getLmpArea().getPkupOrdCon().getStrtTm() );
							}
						}

						LdOrdCon LdOrdCon = lmpArea.getLdOrdCon();
						if(LdOrdCon!=null)
						{
							if(newZip.getLmpArea().getLdOrdCon()==null)
							{
								CompareValuesUtility.logFailed("LmpArea.LdOrdCon",LdOrdCon," Not Found");
							}
							else
							{
								CompareValuesUtility.verifyNullOrEqual("LmpArea.LdOrdCon.CutOffTm", LdOrdCon.getCutOffTm(),newZip.getLmpArea().getLdOrdCon().getCutOffTm() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.LdOrdCon.EndTm", LdOrdCon.getEndTm(),newZip.getLmpArea().getLdOrdCon().getEndTm() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.LdOrdCon.Rate", LdOrdCon.getRate(),newZip.getLmpArea().getLdOrdCon().getRate() );
								CompareValuesUtility.verifyNullOrEqual("LmpArea.LdOrdCon.StrtTm", LdOrdCon.getStrtTm(),newZip.getLmpArea().getLdOrdCon().getStrtTm() );
							}
						}

						List<ChargeDet> chdet  = lmpArea.getChargeDet();


						if(chdet!=null)
						{
							if(newZip.getLmpArea().getChargeDet()==null)
							{
								CompareValuesUtility.logFailed("LmpArea.ChargeDet",chdet," Not Found");
							}
							else
							{
								List<com.generated.vos.zipNew.ChargeDet> actaulChargeDet = newZip.getLmpArea().getChargeDet();

								for (ChargeDet chargeDet : chdet) 
								{
									boolean bFound = false;
									for (com.generated.vos.zipNew.ChargeDet chargeDetAct : actaulChargeDet) 
									{

										if(chargeDet.getSiteId().equals(chargeDetAct.getSiteId()))
										{
											CompareValuesUtility.verifyNullOrEqual("LmpArea.chargeDet.Charge", chargeDet.getCharge(), chargeDetAct.getCharge());
											CompareValuesUtility.verifyNullOrEqual("LmpArea.chargeDet.SiteId", chargeDet.getSiteId(), chargeDetAct.getSiteId());
											CompareValuesUtility.verifyNullOrEqual("LmpArea.chargeDet.MaxAmt", chargeDet.getMaxAmt(), chargeDetAct.getMaxAmt());
											CompareValuesUtility.verifyNullOrEqual("LmpArea.chargeDet.minAmt", chargeDet.getMinAmt(), chargeDetAct.getMinAmt());
											CompareValuesUtility.verifyNullOrEqual("LmpArea.chargeDet.Type", chargeDet.getType(), chargeDetAct.getType());
											bFound = true;
										}

									}

									if(!bFound){
										CompareValuesUtility.logFailed("LmpArea.ChargeDet",chargeDet," Not Found");
									}
								}
							}
						}
					}

				}else
				{
					if(newZip.getLmpArea()!=null)
					{
						CompareValuesUtility.logFailed("LmpArea","null",newZip.getLmpArea() + " Not Expected");
					}
				}

				if(oldZip.getBlob().getZip().getZipDist()==null && newZip.getZipDst() ==null )
				{
					CompareValuesUtility.logPassed("zipdist", "null", "null");
				}
				else if(oldZip.getBlob().getZip().getZipDist()==null && newZip.getZipDst() !=null )
				{
					CompareValuesUtility.logPassed("zipdist", "null", "Not Expected");
				}
				else if(oldZip.getBlob().getZip().getZipDist()!=null && newZip.getZipDst() ==null )
				{
					CompareValuesUtility.logPassed("zipdist", oldZip.getBlob().getZip().getZipDist(), "Not Found");
				}
				else
				{
					//get mp and non mp zipdist lists
					List<Mp> mpZipDist = newZip.getZipDst().getMp();

					List<NonMp> nonMpZipDist = newZip.getZipDst().getNonMp();

					Map<String,Mp> mpZipDistMap = new HashMap<String,Mp>();

					Map<String,NonMp> nonMpZipDistMap = new HashMap<String,NonMp>();

					//get mp and non mp zipdist lists --> map

					for (Mp mp : mpZipDist) 
					{
						mpZipDistMap.put(mp.getUnitId(), mp);
					}

					for (NonMp nonMp : nonMpZipDist) 
					{
						nonMpZipDistMap.put(nonMp.getUnitId(), nonMp);
					}

					//iterate old zipdist

					List<ZipDist> oldZipDist = oldZip.getBlob().getZip().getZipDist();

					/*=================== Non Mp ==============*/

					for (ZipDist zipDist : oldZipDist) 
					{
						unitId = zipDist.getUnitId();

						if(!unitId.contains("-"))
						{
							//non mp
							NonMp nonMp = nonMpZipDistMap.get(unitId);

							if(nonMp == null)
							{
								CompareValuesUtility.logFailed("Non-Mp-Zip",unitId,"Not Found");
							}
							else
							{
								CompareValuesUtility.verifyNullOrEqual("nonmp-unitId", zipDist.getUnitId(),nonMp.getUnitId() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-Dist", zipDist.getDist(),nonMp.getDist() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-DistrictCd", zipDist.getDistrictCd(),nonMp.getDistrictCd() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-StrStatus", zipDist.getStrStatus(),nonMp.getStrStatus() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-StrType", zipDist.getStrType(),nonMp.getStrType() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-StrType1", zipDist.getStrType1(),nonMp.getStrType1() );
								CompareValuesUtility.verifyNullOrEqual("nonmp-StrType2", zipDist.getStrType2(),nonMp.getStrType2() );


								CompareValuesUtility.verifyNullOrEqual("nonmp-IsRefrigeFlg", zipDist.getIsRefrigeFlg() ,nonMp.getIsRefrigeFlg());
								CompareValuesUtility.verifyNullOrEqual("nonmp-SellerId", zipDist.getSellerId() ,nonMp.getSellerId());

								List<String> siteIds  = zipDist.getSiteId();
								List<String> siteIdsMp  = nonMp.getSiteId();

								for (String string : siteIds) {
									if(siteIdsMp.contains(string))
									{
										CompareValuesUtility.logPassed("nonmp-SiteId", string, string);
									}
									else
									{
										CompareValuesUtility.logFailed("nonmp-SiteId", string, "Not Found");
									}
								}


								verifyStrAttrNonMp(zipDist, nonMp);
							}
						}
					}

					/*=================== Mp ==============*/

					for (ZipDist zipDist : oldZipDist) 
					{
						unitId = zipDist.getUnitId();

						if(unitId.contains("-"))
						{
							//mp
							Mp mp = mpZipDistMap.get(unitId);

							if(mp == null)
							{
								CompareValuesUtility.logFailed("Mp-Zip",unitId,"Not Found");
							}
							else
							{
								CompareValuesUtility.verifyNullOrEqual("mp-unitId", zipDist.getUnitId(),mp.getUnitId() );
								CompareValuesUtility.verifyNullOrEqual("mp-Dist", zipDist.getDist(),mp.getDist() );
								CompareValuesUtility.verifyNullOrEqual("mp-DistrictCd", zipDist.getDistrictCd(),mp.getDistrictCd() );
								CompareValuesUtility.verifyNullOrEqual("mp-StrStatus", zipDist.getStrStatus(),mp.getStrStatus() );
								CompareValuesUtility.verifyNullOrEqual("mp-StrType", zipDist.getStrType(),mp.getStrType() );
								CompareValuesUtility.verifyNullOrEqual("mp-StrType1", zipDist.getStrType1(),mp.getStrType1() );
								CompareValuesUtility.verifyNullOrEqual("mp-StrType2", zipDist.getStrType2(),mp.getStrType2() );

								CompareValuesUtility.verifyNullOrEqual("mp-IsRefrigeFlg", zipDist.getIsRefrigeFlg() ,mp.getIsRefrigeFlg());
								CompareValuesUtility.verifyNullOrEqual("mp-SellerId", zipDist.getSellerId() ,mp.getSellerId());

								List<String> siteIds  = zipDist.getSiteId();
								List<String> siteIdsMp  = mp.getSiteId();

								for (String string : siteIds) {
									if(siteIdsMp.contains(string))
									{
										CompareValuesUtility.logPassed("mp-SiteId", string, string);
									}
									else
									{
										CompareValuesUtility.logFailed("mp-SiteId", string, "Not Found");
									}
								}

								verifyStrAttrMp(zipDist, mp);

							}
						}
					}
				}
			}
		}

		CompareValuesUtility.setupResult(zipCode, true);

	}

	private void verifyStrAttrNonMp(ZipDist zipDist,NonMp nonMp)
	{
		StrAttr strAttr = zipDist.getStrAttr();

		if(strAttr!=null)
		{
			Sears searsattr = strAttr.getSears();

			if(searsattr!=null)
			{
				com.generated.vos.zipNew.Sears nonmpstrattrs = nonMp.getStrAttr().getSears();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-sears", searsattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-IsPharm", searsattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-LayElg", searsattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-PkupFlg", searsattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-ResvitElg", searsattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-StsElg", searsattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-sears-XfmtstsElg", searsattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(nonMp.getStrAttr().getSears()!=null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-sears", "", "Not Expected");
				}
			}


			Kmart kmartattr = strAttr.getKmart();

			if(kmartattr!=null)
			{
				com.generated.vos.zipNew.Kmart nonmpstrattrs = nonMp.getStrAttr().getKmart();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-kmart", kmartattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-IsPharm", kmartattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-LayElg", kmartattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-PkupFlg", kmartattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-ResvitElg", kmartattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-StsElg", kmartattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-XfmtstsElg", kmartattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );

					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-XrefStr", kmartattr.getXrefStr(), nonmpstrattrs.getXrefStr() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-kmart-XfmtDDC", kmartattr.getXfmtDDC(), nonmpstrattrs.getXfmtDDC() );

				}
			}
			else
			{
				if(nonMp.getStrAttr().getKmart()!=null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-kmart", "", "Not Expected");
				}
			}

			Mygofer mygoferattr = strAttr.getMygofer();

			if(mygoferattr!=null)
			{
				com.generated.vos.zipNew.Mygofer nonmpstrattrs = nonMp.getStrAttr().getMygofer();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-mygofer", mygoferattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-IsPharm", mygoferattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-LayElg", mygoferattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-PkupFlg", mygoferattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-ResvitElg", mygoferattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-StsElg", mygoferattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-mygofer-XfmtstsElg", mygoferattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(nonMp.getStrAttr().getMygofer()!=null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-mygofer", "", "Not Expected");
				}
			}

			Puertorico prattr = strAttr.getPuertorico();

			if(prattr!=null)
			{
				com.generated.vos.zipNew.Puertorico nonmpstrattrs = nonMp.getStrAttr().getPuertorico();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-mygofer", mygoferattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-IsPharm", prattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-LayElg", prattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-PkupFlg", prattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-ResvitElg", prattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-StsElg", prattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("nonmp-strattr-pr-XfmtstsElg", prattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(nonMp.getStrAttr().getPuertorico()!=null)
				{
					CompareValuesUtility.logFailed("nonmp-strattr-pr", "", "Not Expected");
				}
			}
		}
		else
		{
			if(nonMp.getStrAttr()!=null)
			{
				CompareValuesUtility.logFailed("nonmp-strattr", "null", "Not Expected");
			}
		}
	}

	private void verifyStrAttrMp(ZipDist zipDist,Mp mp)
	{
		StrAttr strAttr = zipDist.getStrAttr();

		if(strAttr!=null)
		{
			Sears searsattr = strAttr.getSears();

			if(searsattr!=null)
			{
				Sears_ nonmpstrattrs = mp.getStrAttr().getSears();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("mp-strattr-sears", searsattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-IsPharm", searsattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-LayElg", searsattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-PkupFlg", searsattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-ResvitElg", searsattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-StsElg", searsattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-sears-XfmtstsElg", searsattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(mp.getStrAttr().getSears()!=null)
				{
					CompareValuesUtility.logFailed("mp-strattr-sears", "", "Not Expected");
				}
			}


			Kmart kmartattr = strAttr.getKmart();

			if(kmartattr!=null)
			{
				Kmart_ nonmpstrattrs = mp.getStrAttr().getKmart();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("mp-strattr-kmart", kmartattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-IsPharm", kmartattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-LayElg", kmartattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-PkupFlg", kmartattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-ResvitElg", kmartattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-StsElg", kmartattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-XfmtstsElg", kmartattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );

					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-XrefStr", kmartattr.getXrefStr(), nonmpstrattrs.getXrefStr() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-kmart-XfmtDDC", kmartattr.getXfmtDDC(), nonmpstrattrs.getXfmtDDC() );

				}
			}
			else
			{
				if(mp.getStrAttr().getKmart()!=null)
				{
					CompareValuesUtility.logFailed("mp-strattr-kmart", "", "Not Expected");
				}
			}

			Mygofer mygoferattr = strAttr.getMygofer();

			if(mygoferattr!=null)
			{
				Mygofer_ nonmpstrattrs = mp.getStrAttr().getMygofer();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("mp-strattr-mygofer", mygoferattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-IsPharm", mygoferattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-LayElg", mygoferattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-PkupFlg", mygoferattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-ResvitElg", mygoferattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-StsElg", mygoferattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-mygofer-XfmtstsElg", mygoferattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(mp.getStrAttr().getMygofer()!=null)
				{
					CompareValuesUtility.logFailed("mp-strattr-mygofer", "", "Not Expected");
				}
			}

			Puertorico prattr = strAttr.getPuertorico();

			if(prattr!=null)
			{
				Puertorico_ nonmpstrattrs = mp.getStrAttr().getPuertorico();

				if(nonmpstrattrs==null)
				{
					CompareValuesUtility.logFailed("mp-strattr-mygofer", mygoferattr , "Not Found");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-IsPharm", prattr.getIsPharm(), nonmpstrattrs.getIsPharm() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-LayElg", prattr.getLayElg(), nonmpstrattrs.getLayElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-PkupFlg", prattr.getPkupFlg(), nonmpstrattrs.getPkupFlg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-ResvitElg", prattr.getResvitElg(), nonmpstrattrs.getResvitElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-StsElg", prattr.getStsElg(), nonmpstrattrs.getStsElg() );
					CompareValuesUtility.verifyNullOrEqual("mp-strattr-pr-XfmtstsElg", prattr.getXfmtstsElg(), nonmpstrattrs.getXfmtstsElg() );
				}
			}
			else
			{
				if(mp.getStrAttr().getPuertorico()!=null)
				{
					CompareValuesUtility.logFailed("mp-strattr-pr", "", "Not Expected");
				}
			}
		}
		else
		{
			if(mp.getStrAttr()!=null)
			{
				CompareValuesUtility.logFailed("mp-strattr", "null", "Not Expected");
			}
		}
	}
}
