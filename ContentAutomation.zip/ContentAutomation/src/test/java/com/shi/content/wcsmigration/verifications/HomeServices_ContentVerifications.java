package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;

import java.util.Arrays;
import java.util.List;

import com.generated.vos.content.Assets;
import com.generated.vos.content.Attachment;
import com.generated.vos.content.Content;
import com.generated.xmls.serviceofferings.ProductAsset;
import com.generated.xmls.serviceofferings.PrimaryImage;
import com.generated.xmls.serviceofferings.ProductContent;
import com.generated.xmls.serviceofferings.ProductOffer;
import com.generated.xmls.serviceofferings.SingleServiceProductOffer;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.SHCContentCommons;


public class HomeServices_ContentVerifications implements Runnable
{
	SingleServiceProductOffer serviceProductOffer ;
	SHCContentCommons commonUtils;
	ProductContent serviceContent;
	private String partNumber;
	ProductOffer serviceOffer;


	public HomeServices_ContentVerifications(
			SingleServiceProductOffer singleServiceProductOffer) {
		commonUtils = new SHCContentCommons();
		this.serviceProductOffer = singleServiceProductOffer;
		this.serviceContent = singleServiceProductOffer.getProductContent();
		this.partNumber = commonUtils.getHomeServicesPartNumber(
				singleServiceProductOffer.getProductOfferings().getProductOffer().getPartNumber().getSearsPartNumber())+"P";

		serviceOffer = singleServiceProductOffer.getProductOfferings().getProductOffer();
	}



	@Override
	public void run()
	{
		if(partNumber.equals("nullP"))
		{
			return;
		}

		try{
			CompareValuesUtility.init();
			APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,partNumber);
			if(allResponse == null){
				CompareValuesUtility.logFailed("Id", partNumber, " Not found");
				CompareValuesUtility.setupResult(partNumber, true);
				return;
			}

			Content gbContent = (Content)allResponse.getT();
			if(gbContent == null){
				CompareValuesUtility.logFailed("Id", partNumber, " Not found");
				CompareValuesUtility.setupResult(partNumber, true);
				return;
			}

			System.out.println("Testing content id: " + partNumber);
			verifyProduct( gbContent,partNumber  );

			verifyFtSearch(allResponse);

			CompareValuesUtility.setupResult(partNumber, true);
		}
		catch(Exception e){
			System.out.println("Check this id :"+ partNumber);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}

	}



	private void verifyProduct(Content gbContent, String partNumber) {

		compareValues("Id", partNumber,gbContent.getId());

		compareValues("SpinId", serviceContent.getContentItemId().toString(), gbContent.getAltIds().getSpinId());

		CompareValuesUtility.verifyNullOrEqual("Name", this.getName(serviceContent.getName()), gbContent.getName());

		List<String> expectedSites = Arrays.asList(new String[]{"sears","mygofer","puertorico","kmart","craftsman","kenmore"});

		compareValues("Sites", expectedSites, gbContent.getSites());

		compareValues("Classifications", "P", gbContent.getClassifications().getCatentryType(),"Catentrytype");
		compareValues("Classifications", "HS", gbContent.getClassifications().getCatentrySubType(),"CatentrySubtype");
		compareValues("Classifications", "S", gbContent.getClassifications().getEnrichmentProvider(),"EnrichmentProv");
		CompareValuesUtility.addNewMultiValuedFields();

		commonUtils.verifyDesc(serviceContent.getFeatureDescription(), serviceContent.getMarketingDescription(),gbContent.getDesc(),true);

		verifyNullOrEqual("MfrName", serviceContent.getManufacturerName(), gbContent.getMfr().getName());
		verifyNullOrEqual("ModelNum", serviceContent.getManufacturerModelNumber(), gbContent.getMfr().getModelNo());

		if(serviceContent.getBrand() != null){
			verifyNullOrEqual("Brand", serviceContent.getBrand().getId(), gbContent.getBrand().getId(),"Id");
			verifyNullOrEqual("Brand", serviceContent.getBrand().getName(), gbContent.getBrand().getName(),"Name");
			verifyNullOrEqual("Brand", TestUtils.modifyBrandImgURL(serviceContent.getBrand().getLogoImageUrl()), gbContent.getBrand().getImg().getSrc(),"Image");
			CompareValuesUtility.addNewMultiValuedFields();
		}


		verifyAssets(serviceContent.getPrimaryImage(), gbContent.getAssets());
		if(serviceContent.getProductAssets() != null){
			verifyAssetAttachments(serviceContent.getProductAssets().getProductAsset(), gbContent.getAssets().getAttachments());
		}
		verifyOperational(gbContent);

		commonUtils.compareMasterhierarchyGB(serviceContent.getItemClassId(), gbContent.getTaxonomy() == null? null : gbContent.getTaxonomy().getMaster().getHierarchy());

	}

	public void verifyAssetAttachments(ProductAsset[] productAsset, List<Attachment> attachments) {

		for (ProductAsset attachmentAsset : productAsset) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO"))
			{
				continue;
			}

			Boolean bFound = false;
			commonUtils.convertType(attachmentAsset.getType().name());
			for (Attachment gbAttachment : attachments) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(gbAttachment.getLink().getAttrs().getHref())
						&& !commonUtils.assetTypeGB.equals("PRODUCT_VIDEO")
						&& commonUtils.assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref", attachmentAsset.getUrl(), attachmentAsset.getUrl());
					compareValues("AttType", commonUtils.assetTypeGB, gbAttachment.getType());

					if (commonUtils.assetTypeGB.equals("MS"))
					{
						compareValues("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					} else
					{
						compareValues("AttchmtName", commonUtils.assetName, gbAttachment.getName());
					}

					if ((commonUtils.assetName != null) && commonUtils.assetName.contains("Spanish"))
					{
						compareValues("AttchLang", "Spanish", gbAttachment.getLang());
					} else
					{
						compareValues("AttchLang", "English", gbAttachment.getLang());
					}
					break;
				}


			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", commonUtils.assetTypeGB, "Not found");

			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifyAssets(PrimaryImage primaryImage, Assets assets) {

		if(primaryImage == null)
		{
			return;
		}
		compareValues("PrimaryImg", "P", assets==null ? null :
			assets.getImgs() == null ? null :
				assets.getImgs().get(0) == null ? null :
					assets.getImgs().get(0).getType(),"Type");

		verifyNullOrEqual("PrimaryImg", primaryImage == null ? null :
			primaryImage.getImageElementsGroup() == null ? null :
				primaryImage.getImageElementsGroup().getHeight(),
				assets == null ? null :
					assets.getImgs() == null ? null :
						assets.getImgs().get(0) == null ? null :
							assets.getImgs().get(0).getVals() == null ? null :
								assets.getImgs().get(0).getVals().get(0) == null ? null :
									assets.getImgs().get(0).getVals().get(0).getHeight() == null ? null :
										convertToString(assets.getImgs().get(0).getVals().get(0).getHeight()), "Height");

		verifyNullOrEqual("PrimaryImg", primaryImage == null ? null :
			primaryImage.getImageElementsGroup() == null ? null :
				primaryImage.getImageElementsGroup().getWidth(),
				assets == null ? null :
					assets.getImgs() == null ? null :
						assets.getImgs().get(0) == null ? null :
							assets.getImgs().get(0).getVals() == null ? null :
								assets.getImgs().get(0).getVals().get(0) == null ? null :
									assets.getImgs().get(0).getVals().get(0).getWidth() == null ? null :convertToString(assets.getImgs().get(0).getVals().get(0).getWidth()), "Width");

		compareValues("PrimaryImg", TestUtils.modifyURL(primaryImage == null ? null :
			primaryImage.getImageElementsGroup() == null ? null :
				primaryImage.getImageElementsGroup().getUrl()),
				assets == null ? null :
					assets.getImgs() == null ? null :
						assets.getImgs().get(0) == null ? null :
							assets.getImgs().get(0).getVals() == null ? null :
								assets.getImgs().get(0).getVals().get(0) == null ? null :
									assets.getImgs().get(0).getVals().get(0).getSrc(), "Src");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/**
	 * Verify isdispeligibility.  Based on future data value, isdispelig is true or false.
	 * @param gbContent
	 */
	private void verifyOperational(Content gbContent) {
		boolean expIsDisp = (serviceOffer.getFutureActiveStartDate() == null? true :
			!JodaDateTimeUtility.isCurrentDateBeforeEndDate(serviceOffer.getFutureActiveStartDate().toString()));
		compareValues("IsDispElig", expIsDisp, gbContent.getOperational().getSites().getSears().getIsDispElig(),"Sears");
		compareValues("IsDispElig", expIsDisp, gbContent.getOperational().getSites().getMygofer().getIsDispElig(),"MyGofer");
		compareValues("IsDispElig", expIsDisp, gbContent.getOperational().getSites().getPuertorico().getIsDispElig(),"PR");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	/**
	 * Rules to convert name
	 * @param xmlName
	 * @return
	 */
	private String getName(String xmlName){
		switch(xmlName){
		case "3Y SHOPRPA" :
			return "3-Year In-Shop Repair Protection Agreement";
		case "5Y HOMEMPA" :
			return "5-Year In-Home Master Protection Agreement";
		case "3Y HOMEMPA" :
			return "3-Year In-Home Master Protection Agreement";
		case "3Y HOMERPA" :
			return "3-Year In-Home Repair Protection Agreement";
		case "5Y HOMERPA" :
			return "5-Year In-Home Repair Protection Agreement";
		default :
			return xmlName;
		}
	}

	private void verifyFtSearch(APIResponse<Content> allResponse) {
		CompareValuesUtility.verifyNullOrEqual("_ft", "HS", allResponse.getFtFieldValue("catentrySubType").toString(),"catentrySubType");
		CompareValuesUtility.verifyNullOrEqual("_search", serviceContent.getContentItemId().toString(), allResponse.getSearchFieldValue("spinId").toString(),"spinId");
	}
}
