package com.shi.content.Variations;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;
import static com.shc.autocontent.utils.ReflectionUtils.getFieldFromObject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.Attributes;
import com.generated.vos.content.Assets;
import com.generated.vos.content.Attachment;
import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.ContentExtension;
import com.generated.vos.content.Content_;
import com.generated.vos.content.CuratedContents;
import com.generated.vos.content.CuratedGrp;
import com.generated.vos.content.Desc;
import com.generated.vos.content.Hierarchy;
import com.generated.vos.content.Hierarchy_;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Operational;
import com.generated.vos.content.Sites;
import com.generated.vos.content.Spec;
import com.generated.vos.content.SpecificHierarchy;
import com.generated.vos.content.Static;
import com.generated.vos.content.Val;
import com.generated.vos.content.Video;
import com.generated.vos.content.Web;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.hierarchy.Tag;
import com.generated.vos.offer.DispTags;
import com.generated.vos.productoffering.Brand;
import com.generated.vos.productoffering.CuratedGroup;
import com.generated.vos.productoffering.FeatureImage;
import com.generated.vos.productoffering.FeatureImages;
import com.generated.vos.productoffering.PrimaryImage;
import com.generated.vos.productoffering.ProductAsset;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.Provider;
import com.generated.vos.productoffering.Seo;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.ReflectionUtils;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;


public class SHCContentCommons {

	String sFileName;
	String sSite;
	boolean bUniqueSpinId = false;
	
	// Defaults to slash, changed to pipe in GB comparison method
	private String hierarchySeparator = "/";
	private boolean bOfferTest = false;

	public SHCContentCommons(String sFileName, String sSite) {
		this.sFileName = sFileName;
		this.sSite = sSite;
		
	}
	
	public SHCContentCommons(String sSite) {
		this.sSite = sSite;
		
	}
	
	public void setbUniqueSpinId(boolean value){
		this.bUniqueSpinId = value;
	}

	public void setOfferTest(){
		this.bOfferTest = true;
	}
	
	public SHCContentCommons() {
	}

	/**
	 * Returns isDispElig field inside operational tag. Returns null if site or
	 * field not found
	 * 
	 * @param sSiteId
	 *            - Site for which operational -> isDispElig field needs to be
	 *            checked
	 * @return
	 */
	public static Boolean getDispEligValue(String sSiteId,
			Operational operational) {
		// Long.valueOf(siteId).intValue()

		Object isDispEligValue = ReflectionUtils.getFieldFromObject(
				operational.getSites(),
				TestUtils.getSite(Long.parseLong(sSiteId)) + ">isDispElig");
		return isDispEligValue == null ? null :(isDispEligValue.equals("@no_such_field@")?null: (Boolean) isDispEligValue);

	}
	
	public static Boolean getOfferDispEligValue(String sSiteId,
			com.generated.vos.offer.Operational operational) {
		// Long.valueOf(siteId).intValue()

		Object isDispEligValue = ReflectionUtils.getFieldFromObject(
				operational.getSites(),
				TestUtils.getSite(Long.parseLong(sSiteId)) + ">isDispElig");
		return isDispEligValue == null ? null : (Boolean) isDispEligValue;

	}

	public void verifyDesc(String sLongDescription, String sShortDescription,
			List<Desc> desc, boolean cleanDesc) {
		int i = getPositionInList("L", desc, "type", Desc.class);
		if (sLongDescription != null) {
			CompareValuesUtility.verifyTrue(i != -1, "DescType", "L", "L");
			if (cleanDesc)
				compareValues("DescVal", TestUtils.cleanDesc(sLongDescription),
						desc.get(i).getVal());
			else
				compareValues("DescVal", sLongDescription, desc.get(i).getVal());
		}/*
		 * else CompareValuesUtility.verifyTrue(i == -1, "DescType",
		 * "null","null");
		 */

		i = getPositionInList("S", desc, "type", Desc.class);
		if (sShortDescription != null) {
			CompareValuesUtility.verifyTrue(i != -1, "DescType", "S", "S");
			if (cleanDesc)
				compareValues("DescVal",
						TestUtils.cleanDesc(sShortDescription), desc.get(i)
						.getVal());
			else
				compareValues("DescVal", sShortDescription, desc.get(i)
						.getVal());
		}/*
		 * else CompareValuesUtility.verifyTrue(i == -1, "DescType",
		 * "null","null" );
		 */

	}

	/**
	 * Verifies feature-top-descriptions from xml feed
	 * 
	 * @param lstTopDescriptions
	 * @param desc
	 */
	public void verifyTopDescriptions(String[] lstTopDescriptions,
			List<Desc> desc) {

		int i = getPositionInList("T", desc, "type", Desc.class);
		CompareValuesUtility.verifyTrue(i != -1, "DescType", "T", "Not found");
		if (i != -1) {
			String gbTopDesc = "";
			for (String topDesc : lstTopDescriptions) {
				gbTopDesc += "|" + topDesc;
			}
			compareValues("DescVal", gbTopDesc.substring(1), desc.get(i)
					.getVal());
		}

	}

	public void verifyBrand(Brand xmlBrand,
			com.generated.vos.content.Brand contentBrand) {

		if (xmlBrand == null)
			return;
		String imgSrc = null;
		try {
			imgSrc = contentBrand.getImg().getSrc();
		} catch (Exception e) {
		}

		CompareValuesUtility.verifyNullOrEqual("BrandId", xmlBrand.getId(),
				convertToString(contentBrand.getId()));
		CompareValuesUtility.verifyNullOrEqual("BrImage",
				xmlBrand.getLogoImageUrl(), imgSrc);
		compareValues("BrName", xmlBrand.getName(), contentBrand.getName());

	}

	public void verifyAssets(PrimaryImage primaryImage,
			FeatureImages featureImages, Assets assets) {

		compareValues("PrimaryImg", "P", assets.getImgs().get(0).getType(),
				"Type");
		verifyNullOrEqual("PrimaryImg", primaryImage.getImageElementsGroup()
				.getHeight(), convertToString(assets.getImgs().get(0).getVals()
						.get(0).getHeight()), "Height");
		verifyNullOrEqual("PrimaryImg", primaryImage.getImageElementsGroup()
				.getWidth(), convertToString(assets.getImgs().get(0).getVals()
						.get(0).getWidth()), "Width");
		compareValues("PrimaryImg", TestUtils.modifyURL(primaryImage
				.getImageElementsGroup().getUrl()), assets.getImgs().get(0)
				.getVals().get(0).getSrc(), "Src");
		CompareValuesUtility.addNewMultiValuedFields();

		if (featureImages != null) {
			for (FeatureImage fImage : featureImages.getFeatureImage()) {
				boolean bFound = false;
				int i = getPositionInList("A", assets.getImgs(), "type",
						Img_.class);
				for (Val assetImgVal : assets.getImgs().get(i).getVals()) {
					if (assetImgVal.getSrc().equals(
							TestUtils.modifyURL(fImage.getImageElementsGroup()
									.getUrl()))) {
						bFound = true;
						compareValues("FeaturedImg", "A",
								assets.getImgs().get(i).getType(), "Type");
						CompareValuesUtility.verifyTrue(true, "FeaturedImg",
								TestUtils.modifyImgURL(fImage
										.getImageElementsGroup().getUrl()),
										assetImgVal.getSrc());
						verifyNullOrEqual("FeaturedImg", fImage
								.getImageElementsGroup().getWidth(),
								convertToString(assetImgVal.getWidth()),
								"Width");
						verifyNullOrEqual("FeaturedImg", fImage
								.getImageElementsGroup().getHeight(),
								convertToString(assetImgVal.getHeight()),
								"Height");
					}
				}
				if (!bFound) {
					CompareValuesUtility.verifyTrue(false, "FImgSrc", fImage
							.getImageElementsGroup().getUrl(), "Not found");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	public void verifyContentExtension(Provider provider,
			ContentExtension contentExtension) {
		compareValues("ContentExt", provider.getName(),
				contentExtension.getName(), "Name");
		compareValues("ContentExt", provider.getType(),
				contentExtension.getType(), "Type");
		if (provider.getDataCount() > 0) {
			compareValues("ContentExt", provider.getData()[0].getKey(),
					contentExtension.getData().get(0).getKey(), "Key");
			compareValues("ContentExt", provider.getData()[0].getValue(),
					contentExtension.getData().get(0).getVal(), "Val");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifyContentExtension(com.generated.vos.uvd.Provider provider,
			ContentExtension contentExtension) {
		compareValues("ContentExt", provider.getName(), contentExtension.getName(), "Name");
		compareValues("ContentExt", provider.getType(), contentExtension.getType(), "Type");
		if (provider.getDataCount() > 0) {
			compareValues("ContentExt", provider.getData()[0].getKey(), contentExtension.getData().get(0).getKey(), "Key");
			compareValues("ContentExt", provider.getData()[0].getValue(), contentExtension.getData().get(0).getVal(), "Val");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/**
	 * Verifies seo from xml to gb in case seo tag is present in xml. If not,
	 * then verifies seo data against content document brand name, desc etc
	 * 
	 * @param seo
	 * @param gbContent
	 */
	public void verifySeo(Seo seo, Content gbContent) {
		if (seo != null) {
			com.generated.vos.content.Seo seo2 = gbContent.getSeo();
			compareValues("SEO", seo.getSeoRobotFollowFlag() == null ? true
					: seo.getSeoRobotFollowFlag(), seo2.getIsRobotFollow(),
					"RobotFollow");
			compareValues("SEO", seo.getSeoRobotIndexFlag() == null ? true
					: seo.getSeoRobotIndexFlag(), seo2.getIsRobotIndex(),
					"RobotIndex");
			verifyNullOrEqual("SEO", seo.getSeoFeatureAltTag(),
					seo2.getFeatureAltTag(), "FeatureAlt");
			verifyNullOrEqual("SEO", seo.getSeoProductAltTag(),
					seo2.getProductAltTag(), "ProdAlt");
			if (seo.getSeoTitle() == null || seo.getSeoTitle().isEmpty()) {
				verifySeoTitle(gbContent);
			} else {
				compareValues("SEO", seo.getSeoTitle(), seo2.getTitle(),
						"Title");
			}

			if (seo.getSeoMetaDescription() == null)
				;
			// verifySeoDescSHC(gbContent);
			else
				compareValues("SEO", seo.getSeoMetaDescription(),
						seo2.getDesc(), "Desc");

			CompareValuesUtility.addNewMultiValuedFields();
			// if(seo.getSeoUrl() == null)
			// checkSHCSEOURL(gbContent);
			/*
			 * else verifyNullOrEqual("SEO", seo.getSeoUrl(),
			 * seo2.getUrl(),"Url");
			 */
		} else {
			verifySeoTitle(gbContent);
			// verifySeoDescSHC(gbContent);
			// checkSHCSEOURL(gbContent);
		}

	}

	/**
	 * Given a partnumber, returns its catentry id from db2
	 * 
	 * @param partNumber
	 * @return
	 */
	public static String fetchCatentryId(String partNumber) {
		return DBUtil
				.executeQuerySingleResult("select catentry_id from wcsadm.catentry where PARTNUMBER = '"
						+ partNumber + "' with ur");

	}

	public String getFacetsQuery(String sCatentryId) {
		return "Select  att.DISPLAYLABEL as name, atval.STRINGVALUE as value from "
				+ "wcsadm.xcatentavrel as avrel, wcsadm.XATTRIBUTE as att, wcsadm.XATTRVALUE as atval"
				+ " where catentry_id in ("
				+ sCatentryId
				+ ") and  avrel.xattribute_id in (select xattribute_id from wcsadm.xcatgrpattrrel where  XCATGRPATTRRELTYPE_ID='SEARCH' "
				+ "and catgroup_id in (select catgroup_id from wcsadm.catgpenrel where catentry_id="
				+ sCatentryId
				+ "  and catalog_id=21101))"
				+ " and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID  with ur";
	}

	public String getFacetsQuery(String identifier, String attributeIds,
			String attributeValIds) {
		return "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1 "
				+ " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ("
				+ attributeValIds
				+ ")"
				+ " and g.catgroup_id in (select catgroup_id from catgroup where identifier = '"
				+ identifier
				+ "')"
				+ " and g.XCATGRPATTRRELTYPE_ID='SEARCH' and x.field2 in ("
				+ attributeIds + ")";
	}

	/**
	 * Verify static facets
	 * 
	 * @param sCatentryId
	 * @param content
	 */
	public void verifyFacets(String sQuery, Content content) {

		/*
		 * String sQuery =
		 * "Select  att.DISPLAYLABEL as name, atval.STRINGVALUE as value from "
		 * +
		 * "wcsadm.xcatentavrel as avrel, wcsadm.XATTRIBUTE as att, wcsadm.XATTRVALUE as atval"
		 * + " where catentry_id in ("+sCatentryId+
		 * ") and  avrel.xattribute_id in (select xattribute_id from wcsadm.xcatgrpattrrel where  XCATGRPATTRRELTYPE_ID='SEARCH' "
		 * +
		 * "and catgroup_id in (select catgroup_id from wcsadm.catgpenrel where catentry_id="
		 * +sCatentryId+"  and catalog_id=21101))" +
		 * " and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID  with ur"
		 * ;
		 */

		/*
		 * String sUVDQuery =
		 * "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1 "
		 * +
		 * " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in (182,1578110,346,23985,2509410)"
		 * +
		 * " and g.catgroup_id in (select catgroup_id from catgroup where identifier = '313310')"
		 * +
		 * " and g.XCATGRPATTRRELTYPE_ID='SEARCH' and x.field2 in (517810,518110,518310,518510,848810,1035210)"
		 * ;
		 */

		ResultSet result = DBUtil.executeQueryReturnAll(sQuery);

		if (result == null) {
			CompareValuesUtility.verifyNull("FacetName", content.getFacets());
			CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
			return;
		}

		sSite = sSite == null ? "sears" : sSite;

		List<Static> staticFacets;
		if (sSite.equalsIgnoreCase("sears"))
			staticFacets = content.getFacets().getSites().getSears()
			.getStatic();
		else
			staticFacets = content.getFacets().getSites().getKmart()
			.getStatic();

		try {
			while (result.next()) {
				String sName = result.getString("name");
				String sVal = result.getString("value");
				Boolean bFound = false;
				for (Static staticFacet : staticFacets) {
					if (sName.equals(staticFacet.getName())
							&& sVal.equals(staticFacet.getValue())) {
						bFound = true;
						CompareValuesUtility.verifyTrue(true, "FacetName",
								sName, staticFacet.getName());
						CompareValuesUtility.verifyTrue(true, "FacetVal", sVal,
								staticFacet.getValue());
					}
				}
				if (!bFound) {
					CompareValuesUtility.logFailed("FacetName", sName,
							"Not Found");
					CompareValuesUtility.logFailed("FacetVal", sVal,
							"Not Found");
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			DBUtil.closeCursor(result);
			e.printStackTrace();
		}
		DBUtil.closeCursor(result);

	}

	public void verifySpecs(ProductAttribute[] prodAttribs,
			List<Spec> specsJson, String itemClassId) {

		List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110",
				"797010", "250601", "796910", "796810", "1774" });
		List<String> autoIds = Arrays
				.asList(new String[] { "1035210", "873910" });

		String query = "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1"
				+ " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ('ATTVALID')"
				+ " and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"
				+ " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		String attributeOnlyQuery = "select x.displaylabel as name, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g"
				+ " where x.xattribute_id=g.xattribute_id and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"
				+ " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		if (prodAttribs != null) {

			String grpNameJson = "";
			String grpNameWCS = "";

			Long attrId, val_id;
			String val_free = "";
			String attrName = null, attrVal = null;
			for (ProductAttribute attribute : prodAttribs) {

				// It's a flag field - no need to check
				if (attribute.getProductAttributeTypeChoice()
						.getAttributeValueFlag() != null)
					continue;

				attrId = attribute.getAttributeId();

				// For content some attribute ids need to be skipped
				if (ignoreAttrIds.contains(attrId.toString())) {
					continue;
				}

				// If automotive attributes
				if (autoIds.contains(attrId.toString())) {
					// bIsAuto = true;
					continue;
				}

				val_id = attribute.getProductAttributeTypeChoice()
						.getAttributeValueId();
				val_free = attribute.getProductAttributeTypeChoice()
						.getAttributeValueFree();

				if (val_id != null) {
					String finalQuery = query
							.replace("ATTVALID", val_id.toString())
							.replace("ATTID", attrId.toString())
							.replace("IMACLASSID", itemClassId);
					List<String> attrData = DBUtil
							.executeQueryMultiColumnSingleRow(finalQuery);
					if (attrData == null)
						continue;
					attrName = attrData.get(0);
					attrVal = attrData.get(1);
					grpNameWCS = attrData.get(2);
				} else // Probably free text
				{
					String finalQuery = attributeOnlyQuery.replace("ATTID",
							attrId.toString()).replace("IMACLASSID",
									itemClassId);
					List<String> attrData = DBUtil
							.executeQueryMultiColumnSingleRow(finalQuery);
					attrName = attrData.get(0);
					grpNameWCS = attrData.get(1);
					attrVal = val_free;
				}

				if (grpNameWCS == null) {
					grpNameWCS = "Others:";
				}

				boolean found = false;
				for (Spec spec : specsJson) {

					grpNameJson = spec.getGrpName();
					List<Attr> attrsList = spec.getAttrs();
					for (Attr attr : attrsList) {

						if (attr.getName().equals(attrName)
								&& attr.getVal().equals(
										TestUtils.encodeHTML(attrVal))
										&& grpNameWCS.equals(grpNameJson)) {
							found = true;
							CompareValuesUtility.logPassed("SpecName",
									attrName, attr.getName());
							CompareValuesUtility.logPassed("SpecVal", attrVal,
									attr.getVal());
							CompareValuesUtility.logPassed("SpecGrpName",
									grpNameWCS, grpNameJson);
							break;
						}
					}

					if (found) {
						break;
					}
				}

				if (!found) {
					CompareValuesUtility.logFailed("SpecName", attrName, "");
					CompareValuesUtility.logFailed("SpecVal",
							attrVal == null ? "null" : attrVal, "");
					CompareValuesUtility.logFailed("SpecGrpName", grpNameWCS,
							grpNameJson);
				}

			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

		// If automotive attributes exist, go ahead and verify attributes in
		// content.automotive

		/*
		 * if(bIsAuto){ verifyAutomotive(content, attrs); }
		 */
	}

	/*
	 * public void verifySpecs(String lstOfAttIds, String lstOfAttValIds,
	 * List<Spec> specs, String itemClassId) {
	 * 
	 * String sQuery =
	 * "Select ATT.XATTRIBUTE_ID as attrid,aTT.DISPLAYLABEL as name, atval.STRINGVALUE as value, rel.LABELNAME as grpName"
	 * + " from xcatentavrel as avrel, XATTRIBUTE as att,xcatgrpattrrel REL," +
	 * " XATTRVALUE as atval where catentry_id in ("+sCatentryId+
	 * ") and  avrel.xattribute_id in (select xattribute_id from xcatgrpattrrel rel "
	 * +
	 * "where	XCATGRPATTRRELTYPE_ID='LABEL' and catgroup_id in (select catgroup_id from catgpenrel where catentry_id="
	 * + sCatentryId+
	 * "  and catalog_id=21101)) and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID"
	 * +
	 * " and rel.XATTRIBUTE_ID = avrel.XATTRIBUTE_ID and rel.XCATGRPATTRRELTYPE_ID = 'LABEL' "
	 * +
	 * "and rel.catgroup_id in (select catgroup_id from catgpenrel where catentry_id="
	 * +sCatentryId+" and catalog_id=21101) with ur";
	 * 
	 * String sQuery =
	 * "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from "
	 * +
	 * "wcsadm.xattribute x, wcsadm.xcatgrpattrrel g, wcsadm.xattrvalue x1 where"
	 * +
	 * " x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ("
	 * +lstOfAttValIds+")" +
	 * " and g.catgroup_id in (select catgroup_id from wcsadm.catgroup where identifier = '"
	 * +itemClassId+"')" +
	 * " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ("
	 * +lstOfAttIds+") with ur";
	 * 
	 * 
	 * ResultSet result = DB2Utils.executeQueryReturnAll(sQuery); if(result ==
	 * null){ CompareValuesUtility.verifyNull("SpecName",
	 * specs.size()==0?null:specs.get(0).getGrpName());
	 * CompareValuesUtility.addToHeaders(new
	 * String[]{"SpecValue","SpecGrpName"}); DB2Utils.closeCursor(result);
	 * return; } try { while (result.next()){ // String attrId =
	 * result.getString("attrid"); String sGrpName =
	 * result.getString("grpName"); if(sGrpName == null) sGrpName = "Others:";
	 * String sName = result.getString("name"); String sVal =
	 * result.getString("value"); Boolean bFound = false; for(Spec spec :
	 * specs){ for(Attr specAttr : spec.getAttrs()){
	 * if(spec.getGrpName().equals(sGrpName) &&
	 * sName.equals(specAttr.getName())){ bFound = true;
	 * CompareValuesUtility.verifyTrue(true, "SpecName", sName,
	 * specAttr.getName()); CompareValuesUtility.compareValues("SpecValue",
	 * sVal, specAttr.getVal()); CompareValuesUtility.verifyTrue(true,
	 * "SpecGrpName", sGrpName, spec.getGrpName()); } } } if(!bFound){
	 * CompareValuesUtility.logFailed("SpecName", sName, "Not Found");
	 * CompareValuesUtility.logFailed("SpecValue", sVal, "Not Found");
	 * CompareValuesUtility.logFailed("SpecGrpName", sVal, "Not Found");
	 * 
	 * }
	 * 
	 * } } catch (SQLException e) { // TODO Auto-generated catch block
	 * DB2Utils.closeCursor(result); e.printStackTrace(); }
	 * DB2Utils.closeCursor(result); }
	 */

	/**
	 * Needs item class id and Master object
	 * 
	 * @param lItemClassId
	 * @param master
	 */
	public void compareMasterhierarchy(long lItemClassId,
			List<Hierarchy> hierarchy) {

		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		// URI uri =
		// RestAPIs.getByIdURI(CollectionValuesVal.ITEM_CLASS_HIERARCHY,
		// lItemClassId+"");

		// String sQuery =
		// "select CATGROUP_ID_PATH, CATGROUP_CID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"+
		// " in(select CATGROUP_ID from wcsadm.CATGROUP where identifier = '"+lItemClassId+"') and CATALOG_ID = 21101 with ur";
		//
		// List<String> pathsList =
		// DB2Utils.executeQueryMultiColumnSingleRow(sQuery);

		List<String> pathsList = ContentCache.getPaths(lItemClassId);

		processMasterHierarchy(hierarchy, "no-site-required-for-master",
				hierarchyMap);

		compareValues("Master", pathsList.get(0),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getLstIds().get(0), "IDPath");
		compareValues("Master", pathsList.get(2),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getDisplayPaths().get(0), "DisplayPath");
		compareValues("Master", pathsList.get(1),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getLstCIds().get(0), "CIDPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void compareMasterhierarchyGB(long lItemClassId,	List<Hierarchy> hierarchy, Boolean... isContentMaster) {

		
		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();
		String masterFieldName = "Master";
		if(isContentMaster.length != 0 && isContentMaster[0] == true)
			masterFieldName = "ContentMasterHierarchy";
		Path masterHierarchyPath = GreenBoxCache
				.getPathForItemClass(lItemClassId + "");

		if (masterHierarchyPath == null) {
			logFailed(masterFieldName, "Hierarchy for " + lItemClassId	+ " should exist", "No hierarchy exists");
			return;
		}

		if (hierarchy == null) {
			logFailed(masterFieldName, "Hierarchy for " + lItemClassId	+ " should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(hierarchy, "no-site-required-for-master",
				hierarchyMap);

		String act = hierarchyMap
				.get("no-site-required-for-master").getLstIds().get(0);

		act=act==null?"null":act;

		String exp = masterHierarchyPath.getCidPath();

		exp=exp==null?"null":exp;

		CompareValuesUtility.verifyNullOrEqual(masterFieldName, exp , act ,	"IDPath");

		compareValues(masterFieldName, masterHierarchyPath.getDisplayPath(),
				hierarchyMap.get("no-site-required-for-master")
				.getDisplayPaths().get(0), "DisplayPath");

		compareValues(masterFieldName, masterHierarchyPath.getIdPath(), hierarchyMap
				.get("no-site-required-for-master").getLstCIds().get(0),
				"CIDPath");

		CompareValuesUtility.addNewMultiValuedFields();
	}
	public Map<String, String> hierarchyMeetWExpert = new HashMap<String, String>();

	private void setGBHierarchySeparator() {
		this.hierarchySeparator = "|";
	}

	/**
	 * 
	 * @param contentWebTaxonomy
	 * @param xmlSites
	 */
	public void compareWebhierarchy(Map<Long, List<String>> sitehiearchyMap,
			Web contentWebTaxonomy) {
		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();
		Sites contentSites = contentWebTaxonomy.getSites();
		String sQuery = "select CATGROUP_ID_PATH, CATGROUP_CID_PATH,"
				+ " CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD "
				+ " in (select CATGROUP_ID from wcsadm.CATGROUP where identifier = 'ATTR_ID') and CATALOG_ID = CATA_ID with ur ";

		for (Long lSiteId : sitehiearchyMap.keySet()) {
			String sSiteName = TestUtils.getSite(lSiteId);
			if (!processSiteForWebHierarchy(sSiteName, contentSites,
					hierarchyMap)) {
				logFailed("web-idPath", sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteName + " not found in gb");
				continue;
			}
			String sCIDpath = null, sNamePath = null;
			for (String sHierarchyId : sitehiearchyMap.get(lSiteId)) {
				// String pathFromWebHierarchyCollection =
				// Helper.getJsonValue(resp,"[{_blob{hierarchy{path[cidPath]}}}]");
				try {
					// ResultSet resultSet =
					// ContentCache.getCatGroupDetails(sQuery,sitehiearchyMap,
					// sHierarchyId, TestUtils.figureOutCatalogId(lSiteId+""));
					List<Map<String, String>> resultSetCatDetails = ContentCache
							.getCatGroupDetails(sQuery, sitehiearchyMap,
									sHierarchyId,
									TestUtils.figureOutCatalogId(lSiteId + ""));
					Map<String, String> pathMap = new HashMap<String, String>();
					// while(null != resultSet && resultSet.next())
					if (null != resultSetCatDetails) {
						for (int i = 0; i < resultSetCatDetails.size(); i++) {

							pathMap = resultSetCatDetails.get(i);
							sCIDpath = pathMap.get("CATGROUP_ID_PATH");
							sNamePath = pathMap.get("CATGROUP_NAME_PATH");
							// sCIDpath =
							// resultSet.getString("CATGROUP_ID_PATH");
							// sNamePath =
							// resultSet.getString("CATGROUP_NAME_PATH");
							// System.out.println("sCIDpath..... "+sCIDpath +
							// " and sNamePath ..... "+sNamePath);
							compareValues(
									"web-idPath",
									sCIDpath,
									checkInList(hierarchyMap.get(sSiteName)
											.getLstIds(), sCIDpath));
							compareValues(
									"web-displayPath",
									sNamePath,
									checkInList(hierarchyMap.get(sSiteName)
											.getDisplayPaths(), sNamePath));
						}
					} else {
						// DB2Utils.closeCursor(resultSet);
						// if(null == resultSet){
						String sQuery1 = sQuery
								.replace("ATTR_ID", sHierarchyId).replace(
										"CATA_ID",
										TestUtils.figureOutCatalogId(lSiteId
												+ ""));
						System.out.println("REsult set null for : " + lSiteId
								+ " " + sQuery1);
					}

				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception of sHierarchyId : "
							+ sHierarchyId);
					// e.printStackTrace();
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/**
	 * Hits the web-hierarchy collection to fetch paths and compares against gb
	 * paths for each site
	 * 
	 * @param sitehiearchyMap
	 * @param contentWebTaxonomy
	 */
	public void compareWebhierarchyGB(Map<Long, List<String>> sitehiearchyMap,
			Web contentWebTaxonomy, String sSiteToTest, boolean bCrossFormattedItem, Boolean... isContentTaxonomy) {
		
		
		
		String idPathfieldName = "web-idPath";
		String displayPathfieldName = "web-displayPath";
		String countfieldName = "webHierCountPerSite";
		String taxSite="TaxonomySite";
		if(isContentTaxonomy.length != 0 && isContentTaxonomy[0] == true){
			idPathfieldName = "content web-Path";
			displayPathfieldName = "content dispPath";
			countfieldName="content-CountPerSite";
			taxSite="content-TaxnmySite";
		}
		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		this.setGBHierarchySeparator();
		for (Long lSiteId : sitehiearchyMap.keySet()) {
			String sSiteFromWebHierarchy = TestUtils.getSite(lSiteId);


			if(!bCrossFormattedItem )
			{
				if(bOfferTest){
					if(sSiteToTest.equalsIgnoreCase("sears") && (sSiteFromWebHierarchy.equalsIgnoreCase("kmart")))
					{
						continue;
					}
					if(sSiteToTest.equalsIgnoreCase("kmart") && (sSiteFromWebHierarchy.equalsIgnoreCase("sears")))
					{
						continue;
					}
				}
			}
			if (sSiteToTest.equalsIgnoreCase("kmart")
					&& (sSiteFromWebHierarchy.equalsIgnoreCase("puertorico") 
							|| sSiteFromWebHierarchy.equalsIgnoreCase("craftsman"))) {
				continue;
			}

			List<com.generated.vos.hierarchy.Hierarchy> hierarchyInfoList = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY,
							sitehiearchyMap.get(lSiteId));
			
			if (hierarchyInfoList == null || hierarchyInfoList.size() == 0) {
				
				continue;
			} else {
				CompareValuesUtility.addDataFieldForReport(taxSite, sSiteFromWebHierarchy);
				if (contentWebTaxonomy == null) {
					/*logFailed(TestUtils.getSite(lSiteId)+".web-idPath", "Web Taxonomy expected for site :"
							+ lSiteId + " " + sitehiearchyMap.get(lSiteId),
							"No taxonomy found");*/
					logFailed(idPathfieldName, "Web Taxonomy expected for site :"	+ lSiteId + " " + sitehiearchyMap.get(lSiteId),
							"No taxonomy found");
					break;
				}
			}
			Sites contentSites = contentWebTaxonomy.getSites();

			if (!processSiteForWebHierarchy(sSiteFromWebHierarchy, contentSites,
					hierarchyMap)) {

				/*logFailed(TestUtils.getSite(lSiteId)+".web-idPath", sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteFromWebHierarchy + " not found in gb");*/
				logFailed(idPathfieldName, sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteFromWebHierarchy + " not found in gb");
				continue;
			}

			int gbWebHierPathCount = 0;

			for (com.generated.vos.hierarchy.Hierarchy specificHierarchy : hierarchyInfoList) {

				for (Path path : specificHierarchy.getPath()) {

					compareValues(idPathfieldName,	path.getIdPath(),checkInList(hierarchyMap.get(sSiteFromWebHierarchy).getLstIds(),
									path.getIdPath()));

					compareValues(displayPathfieldName,path.getDisplayPath(),
							checkInList(hierarchyMap.get(sSiteFromWebHierarchy).getDisplayPaths(),
									path.getDisplayPath()));

					gbWebHierPathCount++;
				}
			
				String meetWExpert = "";
				if(specificHierarchy.getAttrs()!=null && 
						specificHierarchy.getAttrs().getTags()!=null){
					for(Tag tag : specificHierarchy.getAttrs().getTags()){
						if(tag.getType().equals("wcs")){
							for(String tagName : tag.getName()){
								if(tagName.equals("Meet_w_Expert_All") || tagName.equals("Meet_w_Expert_Local")){
									meetWExpert = tagName;
								}
							}
						}
					}
				}
				if(!meetWExpert.equals(""))
					hierarchyMeetWExpert.put(specificHierarchy.getId(), meetWExpert);
				
				//System.out.println("hierarchyMeetWExpert:" + hierarchyMeetWExpert);
			}
			compareValues(countfieldName, gbWebHierPathCount, hierarchyMap.get(sSiteFromWebHierarchy).getLstIds().size());
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public static String checkInList(List<String> lst, String exp) {
		for (String string : lst) {

			if (string.equals(exp)) {
				return string;
			}
		}
		return "Not in list : " + lst.toString();
	}

	/**
	 * Process site for web hierarchy
	 * 
	 * @param siteName
	 * @param contentSites
	 * @param hierarchyMap
	 */
	public boolean processSiteForWebHierarchy(String siteName,
			com.generated.vos.content.Sites contentSites,
			Map<String, HierarchyPathVo> hierarchyMap) {
		List<Hierarchy_> lstHierarchies = null;

		try {

			switch (siteName) {

			case "kmart":
				lstHierarchies = contentSites.getKmart().getHierarchies();
				break;

			case "sears":
				lstHierarchies = contentSites.getSears().getHierarchies();
				break;
				
			case "scom":
				lstHierarchies = contentSites.getScom().getHierarchies();
				break;

			case "mygofer":
				lstHierarchies = contentSites.getMygofer().getHierarchies();
				break;

			case "kenmore":
				lstHierarchies = contentSites.getKenmore().getHierarchies();
				break;

			case "craftsman":
				lstHierarchies = contentSites.getCraftsman().getHierarchies();
				break;

			case "insco":
				lstHierarchies = contentSites.getInsco().getHierarchies();
				break;

			case "tgi":
				lstHierarchies = contentSites.getTgi().getHierarchies();
				break;

			case "puertorico":
				lstHierarchies = contentSites.getPuertorico().getHierarchies();
				break;

			default:
				break;
			}

			processWebHierarchy(lstHierarchies, siteName, hierarchyMap);
			return true;
		} catch (Exception e) {

			// System.out.println("Site not found in json");
			return false;
		}

	}

	/**
	 * Clubs the id and names under specificHierarchy separted by pipes
	 * 
	 * @param lstHierarchies
	 * @param siteName
	 * @param hierarchyMap
	 *            - Map to be updated with hierarchies. eg. <Sears, [{Kids|Kids'
	 *            Clothing|Boys' Clothing|Boys' Outerwear|All Boys'
	 *            Outerwear,Clothing, Shoes & Jewelry|Clothing|Kids'
	 *            Clothing|Boys' Clothing}]>
	 */
	public void processWebHierarchy(List<Hierarchy_> lstHierarchies,
			String siteName, Map<String, HierarchyPathVo> hierarchyMap) {
		List<String> lstIds = new LinkedList<String>();
		List<String> lstName = new LinkedList<String>();

		String id = "", name = "";

		String tempid ="";

		for (Hierarchy_ hierarchy : lstHierarchies) {

			List<SpecificHierarchy> spHie = hierarchy.getSpecificHierarchy();

			id = "";
			name = "";
			for (SpecificHierarchy specificHierarchy : spHie) {

				if (id.isEmpty() && hierarchySeparator.equals("|")) {
					tempid=  GenericUtil.convertToString(specificHierarchy.getSpinId());
					if(tempid!=null && !tempid.isEmpty() && !tempid.equals("null"))
					{
						id = tempid;
					}
				} else
				{
					tempid=  GenericUtil.convertToString(specificHierarchy.getSpinId());

					if(tempid!=null && !tempid.isEmpty() && !tempid.equals("null"))
					{
						id = id
								+ this.hierarchySeparator
								+ tempid;
					}


				}
				if (name.isEmpty() && hierarchySeparator.equals("|")) {
					name = specificHierarchy.getName();
				} else
					name = name + this.hierarchySeparator
					+ specificHierarchy.getName();

			}

			lstIds.add(id);
			lstName.add(name);

		}

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	/**
	 * Process Master hierarchy
	 * 
	 * @param lstHierarchies
	 * @param siteName
	 * @param hierarchyMap
	 */
	public void processMasterHierarchy(List<Hierarchy> lstHierarchies,
			String siteName, Map<String, HierarchyPathVo> hierarchyMap) {
		List<String> lstIds = new LinkedList<String>();
		List<String> lstName = new LinkedList<String>();
		List<String> lstCids = new LinkedList<String>();

		String id = null, name = null, cid = null;

		for (Hierarchy hierarchy : lstHierarchies) {

			if (id == null)
				id = GenericUtil.convertToString(hierarchy.getId());
			else
				id = id + this.hierarchySeparator
				+ GenericUtil.convertToString(hierarchy.getId());

			if (name == null)
				name = hierarchy.getName();
			else
				name = name + this.hierarchySeparator + hierarchy.getName();

			if (cid == null)
				cid = GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid + this.hierarchySeparator
				+ GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ====== For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	/**
	 * Common for web and Master
	 * 
	 * @author ddaphal
	 * 
	 */
	private class HierarchyPathVo {
		public List<String> getLstIds() {
			return lstIds;
		}

		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}

		public List<String> getLstCIds() {
			return lstCIds;
		}

		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}

		public List<String> getDisplayPaths() {
			return displayPaths;
		}

		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}

		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}

	/**
	 * Verifies curated contents from feeds
	 * 
	 * @param xmlCuratedGroups
	 * @param curatedContents
	 */
	public void verifyCuratedContents(CuratedGroup[] xmlCuratedGroups, CuratedContents curatedContents) {

		List<CuratedGrp> gbCuratedGrps = curatedContents.getCuratedGrp();// curatedContents.get(0).getCuratedGrp();

		for (CuratedGroup xmlCurGroup : xmlCuratedGroups) {
			int i = CompareValuesUtility.getPositionInList(String.valueOf((Long.valueOf(xmlCurGroup.getRank()).doubleValue())), gbCuratedGrps, "rank", CuratedGrp.class);
			if (i != -1) {
				compareValues("CurGrpType", xmlCurGroup.getCuratedType(), gbCuratedGrps.get(i).getType());
				compareValues("CurGrpRank", xmlCurGroup.getRank(), GenericUtil.convertToString(gbCuratedGrps.get(i).getRank()));
				verifyNullOrEqual("CurGrpName", xmlCurGroup.getCuratedGroupName(), gbCuratedGrps.get(i).getName());
				
				for (com.generated.vos.productoffering.CuratedContent xmlCurContent : xmlCurGroup.getCuratedContent()) {
					int j = CompareValuesUtility.getPositionInList(xmlCurContent.getContentType(), gbCuratedGrps.get(i).getContent(), "type", Content_.class);
					if (j != -1) {
						Content_ currentGbContent = gbCuratedGrps.get(i).getContent().get(j);
						compareValues("CurContType", xmlCurContent.getContentType(), currentGbContent.getType());
						verifyNullOrEqual("CurContName", xmlCurContent.getContentName(), currentGbContent.getName());
						verifyNullOrEqual("CurContCol", xmlCurContent.getColumn(), GenericUtil.convertToString(currentGbContent.getColumn()));
						verifyNullOrEqual("CurContRow", xmlCurContent.getRow(), GenericUtil.convertToString(currentGbContent.getRow()));
						verifyNullOrEqual("CurContData", xmlCurContent.getData(), currentGbContent.getData());

						if (xmlCurContent.getContentType().equalsIgnoreCase("asset")) {
							verifyNullOrEqual("CurContAsstName", xmlCurContent.getAsset().getName(), currentGbContent.getAsset().getName());
							compareValues("CurContAsstType", xmlCurContent.getAsset().getCuratedAssetTypeType().toString(), currentGbContent.getAsset().getType());
							compareValues("CurContAsstUrl", xmlCurContent.getAsset().getUrl(), currentGbContent.getAsset().getUrl());
							verifyNullOrEqual("CurContAsstHeight", xmlCurContent.getAsset().getHeight(), GenericUtil.convertToString(currentGbContent.getAsset().getHeight()));
							verifyNullOrEqual("CurContAsstWidth", xmlCurContent.getAsset().getWidth(), GenericUtil.convertToString(currentGbContent.getAsset().getWidth()));
						}

					} else {
						logFailed("CurContType", xmlCurContent.getContentType(), "Not found in GB");
					}
				}
			} else {
				compareValues("CurGrpName", xmlCurGroup.getCuratedGroupName(), "Not found in GB");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private List<SpecificHierarchy> getSpecificHieararchy(Content content) {
		try {
			List<Hierarchy_> lstHieararchies = new ArrayList<Hierarchy_>();
			if (sSite.equalsIgnoreCase("sears")) {
				if (content.getTaxonomy().getWeb().getSites().getSears() != null)
					lstHieararchies = content.getTaxonomy().getWeb().getSites().getSears().getHierarchies();
				else if (content.getTaxonomy().getWeb().getSites().getKmart() != null)
					lstHieararchies = content.getTaxonomy().getWeb().getSites().getKmart().getHierarchies();
				else
					lstHieararchies = getOtherHierarchies(content);

			} else {
				if (content.getTaxonomy().getWeb().getSites().getKmart() != null)
					lstHieararchies = content.getTaxonomy().getWeb().getSites().getKmart().getHierarchies();
				else if (content.getTaxonomy().getWeb().getSites().getSears() != null)
					lstHieararchies = content.getTaxonomy().getWeb().getSites().getSears().getHierarchies();
				else
					lstHieararchies = getOtherHierarchies(content);
			}

			return lstHieararchies.get(0).getSpecificHierarchy();
		} catch (Exception e) {
			return null;
		}
	}

	private List<Hierarchy_> getOtherHierarchies(Content content) {
		if (content.getTaxonomy().getWeb().getSites().getMygofer() != null)
			return content.getTaxonomy().getWeb().getSites().getMygofer().getHierarchies();
		else if (content.getTaxonomy().getWeb().getSites().getCraftsman() != null)
			return content.getTaxonomy().getWeb().getSites().getCraftsman().getHierarchies();
		
		else if (content.getTaxonomy().getWeb().getSites().getScom() != null)
			return content.getTaxonomy().getWeb().getSites().getScom().getHierarchies();
		else if (content.getTaxonomy().getWeb().getSites().getInsco() != null)
			return content.getTaxonomy().getWeb().getSites().getInsco().getHierarchies();
		else if (content.getTaxonomy().getWeb().getSites().getKenmore() != null)
			return content.getTaxonomy().getWeb().getSites().getKenmore().getHierarchies();
		else if (content.getTaxonomy().getWeb().getSites().getPuertorico() != null)
			return content.getTaxonomy().getWeb().getSites().getPuertorico().getHierarchies();
		else if (content.getTaxonomy().getWeb().getSites().getTgi() != null)
			return content.getTaxonomy().getWeb().getSites().getTgi().getHierarchies();
		return null;
	}

	private List<String> getSeoHierFromXml(ProductContent content, String sSiteToTest) {
		try {
			
			List<String> returnList = new ArrayList<String>();
			Map<String, List<String>> siteMap = new HashMap<String, List<String>>();
			
			for(Site site : content.getSite()){
				
				List<String> hierList = new ArrayList<String>();
				for(com.generated.vos.productoffering.Hierarchy hier : site.getTaxonomy().getHierarchy()){
					
					hierList.add(hier.getId().toString());
				}
				siteMap.put(site.getId().toString(), hierList);
			}
			
			if(sSiteToTest.equals("sears")){
				if(siteMap.get("2")!=null){
					returnList = siteMap.get("2");
				}else if(siteMap.get("1")!=null){
					returnList = siteMap.get("1");
				}else if(siteMap.get("4")!=null){
					returnList = siteMap.get("4");
				}else if(siteMap.get("13")!=null){
					returnList = siteMap.get("13");
				}else if(siteMap.get("11")!=null){
					returnList = siteMap.get("11");
				}
			}else{
				if(siteMap.get("1")!=null){
					returnList = siteMap.get("1");
				}else if(siteMap.get("2")!=null){
					returnList = siteMap.get("2");
				}else if(siteMap.get("4")!=null){
					returnList = siteMap.get("4");
				}else if(siteMap.get("13")!=null){
					returnList = siteMap.get("13");
				}else if(siteMap.get("11")!=null){
					returnList = siteMap.get("11");
				}
			}
			return returnList;
		} catch (Exception e) {
			return null;
		}
	}
	
	public static void checkSHCSEOURL(Content content) {
		String url = "";

		// 1. Combine brand + name i.e. Ex-Cell Combination Sand Urn/Waste
		// Receptacle Round Steel Black/Chrome
		if (content
				.getName()
				.toLowerCase()
				.startsWith(
						content.getBrand() == null ? "" : content.getBrand()
								.getName().toLowerCase()))
			url = content.getName();
		else
			url = content.getBrand() == null ? "" : content.getBrand()
					.getName() + "-" + content.getName();

		// url=url.replaceAll("&nbsp;", "unknown");

		url = TestUtils.trimURLBySpace(url);
		url = TestUtils.replacesSPecialCharsFromURL(url);
		// 4. Convert all to lower case i.e.
		// ex-cell-combination-sand-urn-waste-receptacle-round
		url = url.toLowerCase();

		// 5. Remove adjacent duplicate words
		url = TestUtils.removeAdjacentDuplicateWords(url, "-");

		// 6. Add a slash / at the start i.e.
		// /ex-cell-combination-sand-urn-waste-receptacle-round*/
		url = "/" + url;

		// 7. Remove hyphen from end
		if (url.endsWith("-"))
			url = url.substring(0, url.length() - 1);

		//System.out.println("Exp url : " + url);
		if (content.getSeo() == null) {
			CompareValuesUtility.addFailedDataFieldForReport(
					"Seo-tag-not-found", "Exp : " + url);
		} else {
			compareValues("SEO", url, content.getSeo().getUrl(), "URL");
		}
	}

	private static void verifySeoURL(Content content) {

		String url = "";

		// 1. Combine brand + name i.e. Ex-Cell Combination Sand Urn/Waste
		// Receptacle Round Steel Black/Chrome
		if (content.getName().startsWith(content.getBrand().getName()))
			url = content.getName();
		else
			url = content.getBrand().getName() + "-" + content.getName();

		// 2. Replace all spaces and other special characters with hyphen i.e.
		// Ex-Cell-Combination-Sand-Urn-Waste-Receptacle-Round-Steel-Black-Chrome
		url = TestUtils.replacesSPecialCharsFromURL(url);

		// 3. Take first 8 words only i.e.
		// Ex-Cell-Combination-Sand-Urn-Waste-Receptacle-Round
		url = TestUtils.trimURL(url);

		// 4. Convert all to lower case i.e.
		// ex-cell-combination-sand-urn-waste-receptacle-round
		url = url.toLowerCase();

		// 5. Add a slash / at the start i.e.
		// /ex-cell-combination-sand-urn-waste-receptacle-round*/
		url = "/" + url;

		compareValues("SEO", url, content.getSeo().getUrl(), "URL");
		/*
		 * String brandinseotitle = content.getBrand()!=
		 * null?content.getBrand().getName():""; String fullURL =
		 * brandinseotitle+" "+content.getName(); fullURL = fullURL.replace("&",
		 * "").replace("-", " ").replaceAll("\\s+"," ");
		 * System.out.println("Before trimming : "+ fullURL);
		 * System.out.println("On trimming : "+ TestUtils.trimURL(fullURL));
		 * compareValues
		 * ("seo-url","/"+TestUtils.processURL(TestUtils.trimURL(fullURL
		 * )),content.getSeo().getUrl());
		 */

	}

	public void verifySeoTitle(Content content, Boolean... bPrimaryAvlbl) {

		boolean bToAppendHierarchy = true;
		String hierarchy = null;
		if (bPrimaryAvlbl != null && bPrimaryAvlbl.length > 0
				&& !bPrimaryAvlbl[0])
			bToAppendHierarchy = false;
		if (bToAppendHierarchy) {
			List<SpecificHierarchy> spHie = getSpecificHieararchy(content);
			if (spHie != null) {
				for (SpecificHierarchy specificHierarchy : spHie) {

					if(hierarchy==null)
						hierarchy= specificHierarchy.getName();
					else
						hierarchy += " - " + specificHierarchy.getName();
				}
			}
		}

		hierarchy=hierarchy==null?"":hierarchy;
		if(!hierarchy.isEmpty())
		{
			hierarchy=" - "+hierarchy;
		}
		
		boolean bAddEnergyCompliance =  false;

		if(sSite.equalsIgnoreCase("sears")){
			if(content.getFacets() != null && content.getFacets().getSites().getSears().getStatic().size()>0){
			int i = getPositionInList("ENERGY STAR Compliant", content.getFacets().getSites().getSears().getStatic(), "name", Static.class);
			if(i != -1 && content.getFacets().getSites().getSears().getStatic().get(i).getValue().equals("Yes"))
				bAddEnergyCompliance = true;
			}
		}
		if(sSite.equalsIgnoreCase("kmart")){
			if(content.getFacets() != null && content.getFacets().getSites().getKmart().getStatic().size()>0){
			int i = getPositionInList("ENERGY STAR Compliant", content.getFacets().getSites().getKmart().getStatic(), "name", Static.class);
			if(i != -1 && content.getFacets().getSites().getKmart().getStatic().get(i).getValue().equals("Yes"))
				bAddEnergyCompliance = true;
			}
		}
		String seoTitle = (content.getBrand() == null
				|| content.getBrand().getName() == null ? "" : content
						.getBrand().getName() + " ")
						+ content.getName() +(bAddEnergyCompliance==true?" ENERGY STAR":"") + hierarchy;

		if (seoTitle.length() > 254)
			seoTitle = seoTitle.substring(0, 254);
		compareValues("SEO", seoTitle, content.getSeo().getTitle(), "Title");
	}


	private static void verifySeoDescSHC(Content content) {

		int i = CompareValuesUtility.getPositionInList("L", content.getDesc(),
				"type", Desc.class);
		if (i == -1) {
			i = CompareValuesUtility.getPositionInList("S", content.getDesc(),
					"type", Desc.class);
		}

		String formattedName = TestUtils.replacesSPecialCharsFromURL(
				content.getName()).toLowerCase();

		String sModelNumber = content.getMfr() == null ? "" : content.getMfr()
				.getModelNo();
		String desc = (content.getBrand() == null ? "" : content.getBrand()
				.getName() + "-")
				+ formattedName
				+ "-"
				+ (sModelNumber == null ? "" : sModelNumber)
				+ "-"
				+ content.getDesc().get(i).getVal();
		desc = desc.replaceAll("\\s+", " ").replaceAll("--", "-");
		compareValues("SEO", desc, content.getSeo().getDesc(), "Desc");
	}

	private static void verifySeoDesc(Content content) {

		int i = CompareValuesUtility.getPositionInList("L", content.getDesc(),
				"type", Desc.class);

		if (i == -1) {

			//long desc not found
			i = CompareValuesUtility.getPositionInList("S", content.getDesc(),
					"type", Desc.class);
		}
		else
		{

			String longDesc="";
			try {
				longDesc = content.getDesc().get(i).getVal();
			} catch (Exception e) {
				longDesc="";
			}

			if(longDesc.length()>255)
			{
				i = CompareValuesUtility.getPositionInList("S", content.getDesc(),
						"type", Desc.class);
			}
		}

		String sModelNumber = content.getMfr() == null ? "" : content.getMfr()
				.getModelNo();

		String txt = "";
		
		if(content.getBrand()!=null && content.getBrand().getName()!=null )
		{
			txt = content.getBrand().getName() + "-" ;
		}
		String desc =  txt + content.getName()
				+ "-" + sModelNumber + "-" + content.getDesc().get(i).getVal();

		desc = desc.replaceAll("\\s+", " ").replaceAll("--", "-");

		compareValues("SEO", desc, content.getSeo().getDesc(), "Desc");
	}

	public void compareSeo(Content content,boolean... urlFlag) {
		verifySeoTitle(content);
		verifySeoDesc(content);
		// verifySeoURL(content);
		if(urlFlag.length==0)
		{
			//default do it - url check
			checkSHCSEOURL(content);
		}
		else if(urlFlag[0])
		{
			//else in case of true only
			checkSHCSEOURL(content);
		}

		CompareValuesUtility.addNewMultiValuedFields();

	}

	public boolean isSiteTaxonomyAvailable(Site[] sites, long l){

		for(Site site : sites){
			if(site.getId().equals(l))
				return true;
		}
		return false;
	}

	/**
	 * Verify sites list
	 * 
	 * @param pContent
	 * @param sites
	 */
	public void verifySites(ProductContent pContent, List<String> sites, boolean bCrossformatted) {

		for (com.generated.vos.productoffering.Site s : pContent.getSite()) {
			if (s.getId() == 10)
				continue;
			
			if(sSite.equalsIgnoreCase("kmart") && (s.getId()==11 || s.getId() == 6))
				continue;
			
			//Changed based on INCO554932 - Sites should be loaded in all conditions for content
			// added to check only when verifying in offer
			if (bOfferTest &&((sSite.equalsIgnoreCase("sears") && s.getId() == 1)
					|| (sSite.equalsIgnoreCase("kmart") && s.getId() == 2))){
				//Adding conditions for Kmart MP project
				//If kmart site is present and sears site is not present, then kmart site shouldn't be loaded and viceversa
			/*	if(!isSiteTaxonomyAvailable(pContent.getSite(), 2L))
					continue;*/
				if( (bUniqueSpinId && bOfferTest) || (!bUniqueSpinId && !bCrossformatted) ||
						(sSite.equalsIgnoreCase("sears") && !isSiteTaxonomyAvailable(pContent.getSite(), 2L))
						|| (sSite.equalsIgnoreCase("kmart") && !isSiteTaxonomyAvailable(pContent.getSite(), 1L)))
					continue;
			}
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void verifySites(com.generated.vos.uvd.ProductContent pContent, List<String> sites) {

		for (com.generated.vos.uvd.Site s : pContent.getSite()) {
			if (s.getId() == 10 )
				continue;
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
			CompareValuesUtility.addNewMultiValuedFields();
		}

	}
	
	/**
	 * Verifies display sites in the _search tag.  
	 * @param pContent
	 * @param sites
	 * @param bCrossFormattedItem
	 */
	public void verifyDispSite(ProductContent pContent, List<String> sites, boolean bCrossFormattedItem, boolean validHierarchy) {

		for (com.generated.vos.productoffering.Site s : pContent.getSite()) {
			if (s.getId() == 10 
					|| s.getId() == 5 || s.getId() == 6 || s.getId() == 7 || s.getId() == 8) //ignoring craftsman, tgi, insco, kenmore for dispSite
				continue;
			
			if(sSite.equalsIgnoreCase("kmart") & s.getId()==11)
				continue;
			
			
			if(!bCrossFormattedItem )
			{
				//If non-xformatted item and offer collection, then no other site should be displayed
				//If content collection is being tested, and if common spinid is there in product, then dispsite should have sears and kmart both
				if(bOfferTest ){
					if ((sSite.equalsIgnoreCase("sears") && s.getId() == 1)
							|| (sSite.equalsIgnoreCase("kmart") && s.getId() == 2))
						continue;
			
				}
			}
			if(sites!=null && !sites.isEmpty())
				CompareValuesUtility.verifyItemInList("_search", TestUtils.getSite(s.getId()), sites, "dispSite");
			else
				if(validHierarchy)
				CompareValuesUtility.logFailed("_search", TestUtils.getSite(s.getId()), "Empty dispSite found in GB", "dispSite");
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}
	
	public void verifyDispSiteOffer(ProductOffer xmlProductOffer, List<String> sites, boolean bCrossFormattedItem, boolean validHierarchy) {
		
		for (com.generated.vos.productoffering.Site s : xmlProductOffer.getSite()) {
			if (s.getId() == 10 
					|| s.getId() == 5 || s.getId() == 6 || s.getId() == 7 || s.getId() == 8) //ignoring craftsman, tgi, insco, kenmore for dispSite
				continue;
			
			if(sSite.equalsIgnoreCase("kmart") & s.getId()==11)
				continue;
			
			
			if(!bCrossFormattedItem )
			{
				//If non-xformatted item and offer collection, then no other site should be displayed
				//If content collection is being tested, and if common spinid is there in product, then dispsite should have sears and kmart both
				if(bOfferTest ){
					if ((sSite.equalsIgnoreCase("sears") && s.getId() == 1)
							|| (sSite.equalsIgnoreCase("kmart") && s.getId() == 2))
						continue;
			
				}
			}
			if(sites!=null && !sites.isEmpty())
				CompareValuesUtility.verifyItemInList("_search", TestUtils.getSite(s.getId()), sites, "dispSite");
			else
				if(validHierarchy)
				CompareValuesUtility.logFailed("_search", TestUtils.getSite(s.getId()), "Empty dispSite found in GB", "dispSite");
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void verifyAssetVideo(ProductAsset[] productAsset, List<Video> videos) {

		for (ProductAsset videoAsset : productAsset) {

			convertType(videoAsset.getType().name());

			if (videoAsset.getType().value().equals("PRODUCT_VIDEO")) {
				Boolean bFound = false;
				for (Video video : videos) {
					if (videoAsset.getUrl().equals(video.getLink().getAttrs().getHref())) {
						CompareValuesUtility.compareValues("Video", videoAsset.getUrl(), video.getLink().getAttrs().getHref(), "Url");
						bFound = true;
						compareValues("Video", videoAsset.getType().name(), video.getType(), "Type");
						compareValues("Video", assetName, video.getName(), "Name");
						break;
					}
				}
				if (!bFound)
					CompareValuesUtility.logFailed("Video", videoAsset.getUrl(), "Not found", "Url");
			}
		}
	}

	public void verifyAssetVideo(com.generated.vos.uvd.ProductAsset[] productAsset, List<Video> videos) {

		for (com.generated.vos.uvd.ProductAsset videoAsset : productAsset) {

			convertType(videoAsset.getType().name());

			if (videoAsset.getType().value().equals("PRODUCT_VIDEO")) {
				Boolean bFound = false;
				for (Video video : videos) {
					if (videoAsset.getUrl().equals(video.getLink().getAttrs().getHref())) {
						compareValues("Video", videoAsset.getUrl(), videoAsset.getUrl(), "Url");
						bFound = true;
						compareValues("Video", videoAsset.getType().name(), video.getType(), "Type");
						compareValues("Video", assetName, video.getName(), "Name");
						CompareValuesUtility.addNewMultiValuedFields();
						break;
					}
				}
				if (!bFound)
					CompareValuesUtility.logFailed("Video", videoAsset.getUrl(), "Not found", "Url");
			}
		}
	}

	public void verifyAssetAttachments(ProductAsset[] productAsset, List<Attachment> attachments) {

		for (ProductAsset attachmentAsset : productAsset) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO"))
			{
				continue;
			}

			Boolean bFound = false;
			convertType(attachmentAsset.getType().name());
			for (Attachment gbAttachment : attachments) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(gbAttachment.getLink().getAttrs().getHref())
						&& !assetTypeGB.equals("PRODUCT_VIDEO")
						&& assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref", attachmentAsset.getUrl(), attachmentAsset.getUrl());
					compareValues("AttType", assetTypeGB, gbAttachment.getType());

					if (assetTypeGB.equals("MS"))
						compareValues("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					else
						compareValues("AttchmtName", assetName, gbAttachment.getName());

					if (assetName != null && assetName.contains("Spanish"))
						compareValues("AttchLang", "Spanish", gbAttachment.getLang());
					else
						compareValues("AttchLang", "English", gbAttachment.getLang());
					break;
				}


			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", assetTypeGB, "Not found");

			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifyAssetAttachments(com.generated.vos.uvd.ProductAsset[] productAsset, List<Attachment> attachments) {

		for (com.generated.vos.uvd.ProductAsset attachmentAsset : productAsset) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO")){
				continue;
			}

			Boolean bFound = false;
			convertType(attachmentAsset.getType().name());
			for (Attachment gbAttachment : attachments) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(gbAttachment.getLink().getAttrs().getHref())
						&& !assetTypeGB.equals("PRODUCT_VIDEO")
						&& assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					compareValues("Attachments", attachmentAsset.getUrl(), attachmentAsset.getUrl(), "Url");
					compareValues("Attachments", assetTypeGB, gbAttachment.getType(), "Type");

					if (assetTypeGB.equals("MS"))
						compareValues("Attachments", attachmentAsset.getName(), gbAttachment.getName(), "Name");
					else
						compareValues("Attachments", assetName, gbAttachment.getName(), "Name");

					if (assetName != null && assetName.contains("Spanish"))
						compareValues("Attachments", "Spanish", gbAttachment.getLang(), "Language");
					else
						compareValues("Attachments", "English", gbAttachment.getLang(), "Language");

					CompareValuesUtility.addNewMultiValuedFields();
					break;
				}
			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", assetTypeGB, "Not found");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}



	public String assetName, assetTypeGB;

	public void convertType(String assetType) {
		switch (assetType) {
		case "PRODUCT_WARRANTY": {
			assetTypeGB = "PW";
			assetName = "Product Warranty";
			break;
		}
		case "REBATES": {
			assetTypeGB = "RB";
			assetName = "Rebates";
			break;
		}
		case "MISCELLANEOUS": {
			assetTypeGB = "MS";
			assetName = null; // Explicitly setting in case previous loops set
			// it to some other value
			break;
		}
		case "ENGLISH_OWNER_MANUAL": {
			assetTypeGB = "EOM";
			assetName = "Owners manual - English";
			break;
		}
		case "ENERGY_GUIDE": {
			assetTypeGB = "EG";
			assetName = "Energy Guide";
			break;
		}
		case "SPANISH_OWNER_MANUAL": {
			assetTypeGB = "SOM";
			assetName = "Owners manual - Spanish";
			break;
		}
		case "SPANISH_WARRANTY": {
			assetTypeGB = "SW";
			assetName = "Spanish Warranty";
			break;
		}
		case "PRODUCT_VIDEO": {
			assetTypeGB = "PRODUCT_VIDEO";
			assetName = "Product Video";
			break;
		}
		default: {
			break;
		}
		}
	}

	/**
	 * Given a attribute id, returns displayname from gb attribute collection
	 * 
	 * @param id
	 * @return
	 */
	public String getAttributeFromGB(String id) {

		return RestExecutor.getSpecificValueFromJson(
				CollectionValuesVal.ATTRIBUTE, id,
				"[{_blob{attribute{displayName}}}]");
	}

	/**
	 * Given a attributeval id, returns displayname from gb attrvalue collection
	 * 
	 * @param id
	 * @return
	 */
	public String getAttributeValFromGB(String id) {

		return RestExecutor.getSpecificValueFromJson(
				CollectionValuesVal.ATTRIBUTE_VALUE, id,
				"[{_blob{attrvalue{displayName}}}]");
	}

	public String getEnrichmentProvider(String enrichmentProvider,
			boolean isSHCLoad) {
		switch (enrichmentProvider) {
		case "GLADSON": {
			return "G";
		}
		case "CNET": {
			return "CN";
		}
		case "EDGENET": {
			return "EN";
		}
		case "1WORLDSYNC": {
			return "1WS";
		}
		case "KWIKEE": {
			return "K";
		}
		default: {
			if (isSHCLoad)
				return "S";
			else
				return "SP";
		}
		}
	}

	/**
	 * Hits the uri for fitment validation and returns fitment value
	 * 
	 * @param brand
	 * @param modelNumber
	 * @return
	 */
	public boolean fitmentValidation(String brand, String modelNumber) {

		String fitmentPostResponse = RestExecutor.postForJSonResponse(
				RestAPIs.formFitmentURI(), "[{\"brand\":\"" + brand
				+ "\",\"part\":\"" + modelNumber + "\"}]");

		if (fitmentPostResponse == null) {
			return false;
		}
		String fitmentValidation = JsonStringParser.getJsonValueNew(
				fitmentPostResponse, "data.fitment");
		System.out.println("Fitment response " + fitmentValidation);
		return fitmentValidation == null ? false : Boolean
				.parseBoolean(fitmentValidation);
		// Json
	}

	/**
	 * Checks whether brandcodeid attribute is present
	 * 
	 * @param attrs
	 * @return
	 */
	public boolean isBrandCodeIdFound(Attributes attrs) {
		Attribute[] actAttrs = attrs.getAttribute();
		for (Attribute attribute : actAttrs) {
			String attributeId = attribute.getItemAttributeGroup()
					.getAttributeId().toString();
			if (attributeId.equals("873910")) {
				return true;
			}
		}
		return false;
	}

	public void grocerySpecificChecks(String fieldName, Object allergen,
			Object allergen2) {

		compareOnlyIfNotNull(fieldName,
				getFieldFromObject(allergen, "dispLabel"),
				getFieldFromObject(allergen2, "dispLabel"), "DispLabel");
		compareOnlyIfNotNull(fieldName,
				getFieldFromObject(allergen, "freeText"),
				getFieldFromObject(allergen2, "freeText"), "FreeText");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void compareOnlyIfNotNull(String fieldName, Object toVerify,
			Object actual, String... subFieldName) {
		if (toVerify != null) {
			compareValues(fieldName, toVerify, actual, subFieldName);
		}
	}

	public boolean isCrossFormattedItem(ProductContent pContent,String  sSiteToTest
			,	SingleProductOffer singleProductOffer,	ProductOffer pOffer,boolean bSingleProductOffer )
	{
		Site[] sites = pContent.getSite();

		boolean bSearsSitePresent = false;
		boolean bKmartSitePresent = false;

		for (Site site : sites) 
		{
			int siteId = site.getId().intValue() ; 

			if(siteId==1)
				bKmartSitePresent = true;
			else 
				if(siteId==2)
					bSearsSitePresent = true;

		}

		String kmartPart = null;
		String searsPart = null;

		if(bSingleProductOffer)
		{
			kmartPart = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber();
			searsPart = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber();
		}
		else
		{
			kmartPart = pOffer.getPartNumber().getKmartPartNumber();
			searsPart = pOffer.getPartNumber().getSearsPartNumber();
		}

		if(sSiteToTest.equalsIgnoreCase("sears"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && (kmartPart==null||kmartPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && (searsPart==null||searsPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		return false;

	}

	public void verifySeoNew(ProductContent pContent, Content gbContent, String sSiteToTest) {
		if (pContent.getSeo() != null) {
			Seo seo = pContent.getSeo();
			com.generated.vos.content.Seo seo2 = gbContent.getSeo();
			compareValues("SEO", seo.getSeoRobotFollowFlag() == null ? true : seo.getSeoRobotFollowFlag(), seo2.getIsRobotFollow(), "RobotFollow");
			compareValues("SEO", seo.getSeoRobotIndexFlag() == null ? true : seo.getSeoRobotIndexFlag(), seo2.getIsRobotIndex(), "RobotIndex");
			verifyNullOrEqual("SEO", seo.getSeoFeatureAltTag(), seo2.getFeatureAltTag(), "FeatureAlt"); 
			verifyNullOrEqual("SEO", seo.getSeoProductAltTag(), seo2.getProductAltTag(), "ProdAlt");
			if (seo.getSeoTitle() == null || seo.getSeoTitle().isEmpty()) {
				verifySeoTitleNew(pContent, gbContent.getSeo(), sSiteToTest);
			} else {
				compareValues("SEO", seo.getSeoTitle(), seo2.getTitle(), "Title");
			}

			if (seo.getSeoMetaDescription() == null)
				;
			// verifySeoDescSHC(gbContent);
			else
				compareValues("SEO", seo.getSeoMetaDescription(), seo2.getDesc(), "Desc");

			CompareValuesUtility.addNewMultiValuedFields();
		} else {
			verifySeoTitleNew(pContent, gbContent.getSeo(), sSiteToTest);
			// verifySeoDescSHC(gbContent);
			// checkSHCSEOURL(gbContent);
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
	}
	
	private Map<String, String> seoHierMap = new HashMap<String, String>();

	private void verifySeoTitleNew(ProductContent pContent, com.generated.vos.content.Seo gbSeo, String sSiteToTest, Boolean... bPrimaryAvlbl) {
		boolean bToAppendHierarchy = true;
		String hierarchy = null;
		if (bPrimaryAvlbl != null && bPrimaryAvlbl.length > 0 && !bPrimaryAvlbl[0])
			bToAppendHierarchy = false;
		if (bToAppendHierarchy) {
			List<String> hierIds = getSeoHierFromXml(pContent, sSiteToTest);
			if (hierIds != null) {
				for (String hierId : hierIds) {
					if(seoHierMap.get(hierId)!=null){
						hierarchy = seoHierMap.get(hierId);
						break;
					}else{
						com.generated.vos.hierarchy.Hierarchy hierarchyInfo = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, hierId);
						if(hierarchyInfo==null)
							continue;
						else{
							hierarchy = hierarchyInfo.getPath().get(0).getDisplayPath();
							seoHierMap.put(hierId, hierarchy);
							break;
						}
					}
				}
			}
		}

		hierarchy=hierarchy==null?"":hierarchy.replaceAll("\\|", " - ");

		String seoTitle = (pContent.getBrand() == null || pContent.getBrand().getName() == null ? "" : pContent.getBrand().getName() + " ")
						+ pContent.getName() + " - " + hierarchy;

		if (seoTitle.length() > 254)
			seoTitle = seoTitle.substring(0, 254);
		compareValues("SEO", seoTitle, gbSeo.getTitle(), "Title");
		
	}

	public void verifyMeetWExpert(
			String siteToTest, 
			Map<Long, List<String>> mpSiteHiearachies,
			DispTags dispTags) {
		
		String finalMeetWExpertValue = null;
		List<String> parentSiteHierList = new ArrayList<String>();
		
		if(siteToTest.equalsIgnoreCase("sears")){
			parentSiteHierList = mpSiteHiearachies.get(Long.valueOf(2));
		}else{
			parentSiteHierList = mpSiteHiearachies.get(Long.valueOf(1));
		}
		
		if(parentSiteHierList!=null && !parentSiteHierList.isEmpty()){
			for(String hierId : parentSiteHierList){
				if(hierarchyMeetWExpert.get(hierId)!=null){
					if(hierarchyMeetWExpert.get(hierId).equals("Meet_w_Expert_All")){
						finalMeetWExpertValue = "All";
						break;
					}else if(hierarchyMeetWExpert.get(hierId).equals("Meet_w_Expert_Local")){
						finalMeetWExpertValue = "Local";
					}
				}
			}
		}
		CompareValuesUtility.verifyNullOrEqual("meetWExpert", finalMeetWExpertValue, dispTags==null?null:dispTags.getMeetWExpert());
	}
	
	/**
	  * Returns home service specific partNumber
	  * @param id
	  * @return
	  */
	 public String getHomeServicesPartNumber(String id){
	  
	  return id.substring(0, 8).concat("292");
	 }
}

