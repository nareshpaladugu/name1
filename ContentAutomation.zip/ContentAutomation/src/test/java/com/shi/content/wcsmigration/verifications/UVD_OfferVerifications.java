package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.hierarchy.Attr;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.offer.AltIds;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.Replenishment;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.Val;
import com.generated.vos.productoffering.types.ChokingHazardType;
import com.generated.vos.uvd.AutomotiveProductOffer;
import com.generated.vos.uvd.OperationalAttribute;
import com.generated.vos.uvd.OperationalValue;
import com.generated.vos.uvd.ProductAttribute;
import com.generated.vos.uvd.ProductContent;
import com.generated.vos.uvd.ProductOffer;
import com.generated.vos.uvd.ShipDimension;
import com.generated.vos.uvd.Site;
import com.generated.vos.uvd.Source;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;

public class UVD_OfferVerifications implements Runnable{

	AutomotiveProductOffer automotiveProductOffer ;
	boolean isNV = false;
	String contentId=null;
	ProductContent productContent;
	String itemClassId;
	String jsonResp;
	String siteToTest;
	SHCContentCommons commonUtils;
	String hierarchy;
	List<String> errorPartNumbers;
	Map<String, Map<String, String>> vendorMap;
	String vendorId;
	ProductOffer productOffer;
	String relationType;
	String automotiveGroupId;
	String imaClassControlPid;
	Long ksnId;

	public UVD_OfferVerifications(
			List<String> errorPartNumbers,
			Map<String, Map<String, String>> vendorMap, 
			String vendorId,
			ProductOffer productOffer, 
			ProductContent productContent,
			String relationType, 
			String automotiveGroupId, 
			String imaClassControlPid, 
			Long ksnId) {
		this.productOffer = productOffer;
		this.productContent = productContent;
		this.errorPartNumbers = errorPartNumbers;
		this.vendorMap = vendorMap;
		this.vendorId = vendorId;
		this.relationType = relationType;
		this.automotiveGroupId = automotiveGroupId;
		this.imaClassControlPid = imaClassControlPid;
		this.ksnId = ksnId;
		itemClassId = productContent.getContentItemClassId().toString();
		if(relationType.equals("single")){
			contentId = "UVD"+ productOffer.getSpinUniqueId()+"P";
			isNV = true;
		}else{
			contentId = "UVD" + automotiveGroupId + "P";
		}
		siteToTest = "sears";
		commonUtils = new SHCContentCommons();
		hierarchy = "";
	}


	public void run()
	{
		String sOfferId = null;

		try{
			CompareValuesUtility.init();

			sOfferId = productOffer.getBrandCodeId()+productOffer.getManufacturerPartNumber();
			//System.out.println("Testing UVD Offer: " + sOfferId);

			jsonResp = RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER, sOfferId).trim();

			Offer offerObjectGb = JSONParser.parseJSONWithBlob(jsonResp, CollectionValuesVal.OFFER, Offer.class);
			
			if(offerObjectGb==null)
			{
				if(errorPartNumbers.contains(sOfferId) || errorPartNumbers.contains(contentId)){
					CompareValuesUtility.logPassed("Id", sOfferId, "Error Item, Not found in GB. ParentID:"+contentId);
				}else{
					CompareValuesUtility.logFailed("Id", sOfferId, "Not Found in GB");	
				}
				CompareValuesUtility.addDataFieldForReport("vendorId", vendorId);
			}else{
				testOffer(productOffer, offerObjectGb, productContent, sOfferId);
			}

			CompareValuesUtility.setupResult(sOfferId+"", true);

		}catch(Exception e){
			System.out.println("Check this id :"+ sOfferId);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	private void testOffer(ProductOffer xmlOffer, Offer gbUVDOffer, ProductContent prodContent, String sOfferId) {

		CompareValuesUtility.compareValues("Id", sOfferId, gbUVDOffer.getId());
		CompareValuesUtility.addDataFieldForReport("vendorId", vendorId);
		CompareValuesUtility.compareValues("Name", xmlOffer.getName(), gbUVDOffer.getName());
		String shortDesc = xmlOffer.getMarketingDescription()==null?prodContent.getMarketingDescription():xmlOffer.getMarketingDescription();
		String newShortDesc = TestUtils.plainEncodeHTML(shortDesc);
		CompareValuesUtility.compareValues("Desc", newShortDesc, gbUVDOffer.getDesc());
		verifySites(prodContent, gbUVDOffer.getSites());
		CompareValuesUtility.verifyNullOrEqual("MfrPartno", xmlOffer.getManufacturerPartNumber(), gbUVDOffer.getMfrPartno());
		CompareValuesUtility.verifyNullOrEqual("BrandName", prodContent.getBrand()==null?null:prodContent.getBrand().getName(), gbUVDOffer.getBrandName());
		CompareValuesUtility.compareValues("BrandCodeId", xmlOffer.getBrandCodeId(), gbUVDOffer.getBrandCodeId());

		Boolean isFitmentReqd = null;
		if(prodContent.getProductAttributes() != null && prodContent.getProductAttributes().getProductAttribute() != null)
		{
			for(ProductAttribute attr : prodContent.getProductAttributes().getProductAttribute()){
				if(attr.getAttributeId().toString().equals("1035210")){
					if(attr.getProductAttributeTypeChoice().getAttributeValueId().toString().equals("2509310")){
						isFitmentReqd = true;
					}else{
						isFitmentReqd = false;
					}
				}
			}
		}
		
		CompareValuesUtility.compareValues("Classifications", isNV?"NV":"V", gbUVDOffer.getClassifications().getOfferType(), "OfferType");
		CompareValuesUtility.compareValues("Classifications", "true", gbUVDOffer.getClassifications().getIsAutomotive(), "IsAutomotive");
		CompareValuesUtility.compareValues("Classifications", "true", gbUVDOffer.getClassifications().getIsUvd(), "IsUvd");
		CompareValuesUtility.verifyNullOrEqual("Classifications", isFitmentReqd == null ? false : isFitmentReqd , gbUVDOffer.getClassifications().getIsFitmentRequired(), "isFitmentReqd");
		CompareValuesUtility.addNewMultiValuedFields();
		
		verifyAltIds(xmlOffer, gbUVDOffer.getAltIds());
		this.verifyShipping(xmlOffer, gbUVDOffer);
		this.verifyReplenishment(xmlOffer, gbUVDOffer.getReplenishment());
		verifyFFM(gbUVDOffer);
		this.verifyTaxonomy(gbUVDOffer);
		verifyStoreTaxonomy(xmlOffer, gbUVDOffer.getTaxonomy().getStore().getHierarchy());

		if(xmlOffer.getVariantAttributes()!=null)
			verifyDefiningAttrs(xmlOffer.getVariantAttributes().getVariantAttribute(), gbUVDOffer.getDefiningAttrs());

//		verifyLegal(xmlOffer, gbUVDOffer.getLegal());

		try{
			verifyImages(xmlOffer, gbUVDOffer.getMainImg(), null, prodContent.getPrimaryImage());
		}catch (Exception e) {
			System.out.println("Please check verifyImages()  exception, offer id : "+gbUVDOffer.getId());
		}

		Boolean sywRdmElig = true;
		Boolean isHotBuy = false;
		if(xmlOffer.getOperationalAttributes()!=null){
			for(Source src : xmlOffer.getOperationalAttributes().getSource()){
				if(src.getName().equals("SPIN")){
					for(OperationalAttribute oper : src.getOperationalAttribute()){
						if(oper.getName().equals("SYWR Redemption Ineligible")){
							for(OperationalValue oprval : oper.getOperationalValue()){
								if(oprval.getValue().equals("Y")){
									sywRdmElig = false;
								}
							}
						}else if(oper.getName().equals("Hot Buy")){
							for(OperationalValue oprval : oper.getOperationalValue()){
								if(oprval.getValue().equals("Y")){
									isHotBuy = true;
								}
							}
						}
					}
				}
			}
		}
		CompareValuesUtility.verifyNullOrEqual("dispTags", prodContent.getSearchSuppressionFlag()?true:null, gbUVDOffer.getDispTags()==null?null:gbUVDOffer.getDispTags().getIsSearchSupression(), "isSearchSupression");
		CompareValuesUtility.verifyNullOrEqual("dispTags", sywRdmElig?true:null, gbUVDOffer.getDispTags()==null?null:gbUVDOffer.getDispTags().getSywRdmElig(), "sywRdmElig");
		CompareValuesUtility.addNewMultiValuedFields();
		CompareValuesUtility.verifyNullOrEqual("isHotBuy", isHotBuy?true:null, gbUVDOffer.getPriceDispAttr()==null?null:gbUVDOffer.getPriceDispAttr().getIsHotBuy());
		
		//TODO 
		//CompareValuesUtility.verifyNullOrEqual("IsSearsExclu", true, gbUVDOffer.getDispTags()==null?null:gbUVDOffer.getDispTags().getIsSearsExclusive());

		CompareValuesUtility.verifyNullOrEqual("Identity", contentId, gbUVDOffer.getIdentity().getParentId(),"parentId");
		//Identity.ssin
		
				if(productOffer != null && productOffer.getSsin() == null)
				{
					CompareValuesUtility.verifyNullOrEqual("Identity", productOffer.getSsin(), gbUVDOffer.getIdentity()== null ? null : gbUVDOffer.getIdentity().getSsin(),"ssin");
					
					if(gbUVDOffer.getIdentity().getPrevSsin() == null)
					{
						CompareValuesUtility.logFailed("Identity", "SSIN not in Feed", "PrevSsin is not set");
					}
					else
					{
						CompareValuesUtility.logPassed("Identity", "SSIN not in Feed", "PrevSsin="+gbUVDOffer.getIdentity().getPrevSsin());
					}
					
				}
				else if(productOffer != null && productOffer.getSsin() != null)
				{
					CompareValuesUtility.verifyNullOrEqual("Identity", productOffer.getSsin(), gbUVDOffer.getIdentity()== null ? null : gbUVDOffer.getIdentity().getSsin(),"ssin");
				}
				else 
				{
					CompareValuesUtility.logFailed("Identity", "xmlOffer="+productOffer, "offer in xml is not present for ssin="+gbUVDOffer.getIdentity().getSsin());
				}
				
				/* ---------------- Identity.uid --------------- */
				CompareValuesUtility.verifyNullOrEqual("Identity", xmlOffer.getGuid(), gbUVDOffer.getIdentity()== null ? null : gbUVDOffer.getIdentity().getUid(),"UID");

				/* ---------------- legal --------------- */

				Gson gson = new Gson();
				String json = gson.toJson(gbUVDOffer);
				Legal legalTagGb = null;
				if(json.contains("\"legal\":{\"chokingHazards\":[]}"))
				{
					legalTagGb = null;
				}
				else
				{
					legalTagGb = gbUVDOffer.getLegal();
				}

				verifyLegal(prodContent, legalTagGb);

				
				
		/*_ft fields*/
		CompareValuesUtility.compareValues("_ft", isNV?"NV":"V", JsonStringParser.getJsonValue(jsonResp,"{_ft{offerType}}"), "OfferType");
		CompareValuesUtility.compareValues("_ft", "UVD", JsonStringParser.getJsonValue(jsonResp,"{_ft{pgrmType}}"), "PgrmType");
		CompareValuesUtility.compareValues("_ft", vendorId, JsonStringParser.getJsonValue(jsonResp,"{_ft{sellerId}}"), "SellerId");
		CompareValuesUtility.addNewMultiValuedFields();
		
        /*_search fields*/
		CompareValuesUtility.verifyNullOrEqual("_search", xmlOffer.getManufacturerPartNumber().replaceAll("[^a-zA-Z0-9]", "").toUpperCase(), 
						JsonStringParser.getJsonValue(jsonResp,"{_search{model_no}}"), "model_no");
		CompareValuesUtility.verifyNullOrEqual("_search", contentId, JsonStringParser.getJsonValue(jsonResp,"{_search{parentId}}"), "parentId");
		CompareValuesUtility.verifyNullOrEqual("_search", "[\"UVD\"]", JsonStringParser.getJsonValue(jsonResp,"{_search{dispSite}}"), "dispSite");
		CompareValuesUtility.verifyNullOrEqual("_search", xmlOffer.getSpinUniqueId(), JsonStringParser.getJsonValue(jsonResp,"{_search{spinId}}"), "spinId");
		CompareValuesUtility.verifyNullOrEqual("_search", this.hierarchy, JsonStringParser.getJsonValue(jsonResp,"{_search{hierarchy}}"), "hierarchy");
		CompareValuesUtility.compareValues("_search", xmlOffer.getSsin(), JsonStringParser.getJsonValue(jsonResp,"{_search{ssin}}"), "ssin");
		CompareValuesUtility.compareValues("_search", xmlOffer.getGuid(), JsonStringParser.getJsonValue(jsonResp,"{_search{uid}}"), "uid");
		CompareValuesUtility.addNewMultiValuedFields();
	}

    public void verifyFFM(Offer gbUVDOffer){
    	
    	Map<String, String> vnd = vendorMap.get(vendorId);
    	
    	Boolean vndSres = vnd==null?false:(Boolean.valueOf(vnd.get("v2sCertified")) 
    			&& Boolean.valueOf(vnd.get("v2sElig")) 
    			&& (gbUVDOffer.getShipping().getIsMailable()==null?false:gbUVDOffer.getShipping().getIsMailable()));
    	
		CompareValuesUtility.verifyNullOrEqual("FFM","Sears", gbUVDOffer.getFfm().getSoldBy(), "SoldBy");
		CompareValuesUtility.verifyNullOrEqual("FFM","Sears", gbUVDOffer.getFfm().getFulfilledBy(), "FulfilledBy");
		CompareValuesUtility.verifyNullOrEqual("FFM","VD", gbUVDOffer.getFfm().getChannel(), "Channel");
		CompareValuesUtility.verifyNullOrEqual("FFM", true, gbUVDOffer.getFfm().getIsShipElig(), "IsShipElig");
		CompareValuesUtility.verifyNullOrEqual("FFM", false, gbUVDOffer.getFfm().getIsSpuElig(), "IsSpuElig");
		CompareValuesUtility.verifyNullOrEqual("FFM", vndSres, gbUVDOffer.getFfm().getIsSTSElig(), "IsSTSElig");
		CompareValuesUtility.verifyNullOrEqual("FFM", vndSres, gbUVDOffer.getFfm().getIsSResElig(), "IsSResElig");
		CompareValuesUtility.verifyNullOrEqual("FFM", vndSres?"VRES":null, gbUVDOffer.getFfm().getSTSChannel(), "STSChannel");
		CompareValuesUtility.verifyNullOrEqual("FFM", false,  gbUVDOffer.getFfm().getIsWebExcl(), "IsWebExcl");
		/*Fields from vendor map*/
		CompareValuesUtility.verifyNullOrEqual("FFM", vnd==null?null:vnd.get("name"),  gbUVDOffer.getFfm().getVendorName(), "VendorName");
		CompareValuesUtility.verifyNullOrEqual("FFM", vnd==null?null:vnd.get("ediRouteCode"), gbUVDOffer.getFfm().getEdiRouteCode(), "EdiRouteCode");
		CompareValuesUtility.verifyNullOrEqual("FFM", vnd==null?null:vnd.get("vendorDunsNo"), gbUVDOffer.getFfm().getVendorDunsNo(), "VendorDunsNo");
		if((vnd==null?null:vnd.get("vendorDunsNo"))!=null){
			CompareValuesUtility.verifyItemInList("FFM", vnd==null?null:vnd.get("vendorDunsNo"), gbUVDOffer.getFfm().getWrhsLcns(), "WrhsLcns");
		}else{
			CompareValuesUtility.verifyNullOrEqual("FFM", "[]", gbUVDOffer.getFfm().getWrhsLcns().toString(), "WrhsLcns");
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getSres(), "sres");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", vndSres, gbUVDOffer.getFfmElig().getVres(), "vres");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getCres(), "cres");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getDres(), "dres");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getSpu(), "spu");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getSfs(), "sfs");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getLayaway(), "layaway");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getCdfc(), "cdfc");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getDart(), "dart");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getCheetah(), "cheetah");
		CompareValuesUtility.verifyNullOrEqual("FFMElig", false, gbUVDOffer.getFfmElig().getRr(), "rr");
		CompareValuesUtility.addNewMultiValuedFields();
    }

	public void verifySites(ProductContent pContent, List<String> sites) {

		for(Site s : pContent.getSite()){
			if(s.getId() == 10 || s.getId() == 13)
				continue;
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void verifyImages(ProductOffer xmlProductOffer, List<MainImg> mainImg, List<SwatchImg> lstSwatchImgs,com.generated.vos.uvd.PrimaryImage primaryImageXml) {

		if(primaryImageXml !=  null){
			compareValues("PrimaryImage", TestUtils.modifyURL(primaryImageXml.getUrl()),mainImg.get(0).getSrc(),"Src");

			CompareValuesUtility.verifyNullOrEqual("PrimaryImage", primaryImageXml.getName(),mainImg.get(0).getTitle(),"Title");

			compareValues("PrimaryImage", primaryImageXml.getHeight(),GenericUtil.convertToIntFromDouble(mainImg.get(0).getHeight()),"Height");
			compareValues("PrimaryImage", primaryImageXml.getWidth(),GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()),"Width");
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	/*
		//Only check for swatch image for variant items
		if(isNV)
			return;

		//Verify if any of the variant attributes is of type swatch, if yes, only then continue
		boolean bSwatchAttribFound = false;
		for(com.generated.vos.uvd.VariantAttribute varAttri : xmlProductOffer.getVariantAttributes().getVariantAttribute()){
			if(varAttri.getAttributeType().equals(AttributeTypeType.SWATCH)){
				bSwatchAttribFound = true;
				break;
			}
		}

		if(!bSwatchAttribFound)
			return;

		ImageElementsGroup swatchImageURL = xmlProductOffer.getSwatchImage().getImageElementsGroup();
		if(lstSwatchImgs.size() == 0)
			compareValues("SwatchImg", swatchImageURL.getUrl(),"Not found");
		else{

			compareValues("SwatchImg", TestUtils.modifyURL(swatchImageURL.getUrl()),lstSwatchImgs.get(0).getSrc(),"Src");
			CompareValuesUtility.verifyNullOrEqual("SwatchImg", swatchImageURL.getName(),lstSwatchImgs.get(0).getTitle(),"Title");
			compareValues("SwatchImg", swatchImageURL.getHeight(),GenericUtil.convertToIntFromDouble(lstSwatchImgs.get(0).getHeight()),"Height");
			compareValues("SwatchImg", swatchImageURL.getWidth(),GenericUtil.convertToIntFromDouble(lstSwatchImgs.get(0).getWidth()),"Width");
			CompareValuesUtility.addNewMultiValuedFields();
		}
	 */


	/*public void verifyImaClassControlPid(ProductOffer productOffer,Offer gbUVDOffer)
	{
		String sImaClassControlPid = automotiveProductOffer.getImaClassControlPid();

		//String sOfferId = productOffer.getBrandCodeId()+productOffer.getManufacturerPartNumber();

		//System.out.println("sOfferId.... "+sOfferId);

		String sImaClassControlPidJson =gbUVDOffer.getAltIds().getImaClassControlPid();

		CompareValuesUtility.compareValues("ImaClassControlPid", sImaClassControlPid, sImaClassControlPidJson);

	}*/

	private void verifyShipping(ProductOffer xmlOffer, Offer gbUVDOffer){
		OfferCommons offerCommon = new OfferCommons(gbUVDOffer);
		ShipDimension shipDimension = xmlOffer.getShipDimension();
		offerCommon.verifyShipping(shipDimension.getLength(), shipDimension.getWidth(), 
				shipDimension.getHeight(), shipDimension.getWeight());


		compareValues("Shipping", xmlOffer.getTaxCode(), GenericUtil.convertToString(gbUVDOffer.getShipping().getTaxCode()), "TaxCode");
		//TODO
		//CompareValuesUtility.verifyNullOrEqual("Shipping", xmlOffer.getSopt(), GenericUtil.convertToString(gbUVDOffer.getShipping().getSoptDays()), "Sopt");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void verifyReplenishment(ProductOffer xmlProductOffer,
			Replenishment replenishment) {

		compareValues("Replenishment", "0", replenishment.getVendorPackId(),"VendorPackId");
		CompareValuesUtility.compareAsNumbers("Replenishment", xmlProductOffer.getPricing().getCost()+"", replenishment.getUnitCost(), "UnitCost");
		CompareValuesUtility.verifyNullOrEqual("Replenishment", xmlProductOffer.getCountryOfOrigin(), replenishment.getCntryOfOrig(), "CntryOfOrig");
		compareValues("Replenishment", "A", replenishment.getPurchaseSts(),"PurchaseSts");
		compareValues("Replenishment", "L", replenishment.getInternalRimSts(),"InternalRimSts");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	/*private void verifyTaxonomy(Offer gbOffer) {

		SHCContentCommons commonUtils = new SHCContentCommons();

		if(gbOffer.getTaxonomy() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+itemClassId, "Taxonomy is null");
			return;
		}else if(gbOffer.getTaxonomy().getMaster() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+itemClassId, "Taxonomy-master is null");
			return;
		}
		commonUtils.compareMasterhierarchy(Long.parseLong(itemClassId), gbOffer.getTaxonomy().getMaster().getHierarchy());


		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for ( Site site : prodContent.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId > 11 || lSiteId == 10)
				continue;
			String siteName = TestUtils.getSite(lSiteId);
			if((siteToTest.equalsIgnoreCase("sears") && siteName.equalsIgnoreCase("kmart"))
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName.equalsIgnoreCase("sears"))){
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if(gbOffer.getTaxonomy().getWeb() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+itemClassId, "Taxonomy-web is null");
			return;
		}
		commonUtils.compareWebhierarchy(mpSiteHiearachies, gbOffer.getTaxonomy().getWeb());
		CompareValuesUtility.addNewMultiValuedFields();


	}*/
	
	private void verifyTaxonomy(Offer gbOffer) {

		if (gbOffer.getTaxonomy() == null) {
			CompareValuesUtility.logFailed("MasterTaxonomy", "Itemclassid:" + itemClassId, "Taxonomy is null");
			return;
		} else if (gbOffer.getTaxonomy().getMaster() == null) {
			CompareValuesUtility.logFailed("MasterTaxonomy", "Itemclassid:" + itemClassId, "Taxonomy-master is null");
			return;
		}

		compareMasterhierarchyGB(Long.parseLong(itemClassId), gbOffer.getTaxonomy().getMaster().getHierarchy());

		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for (Site site : productContent.getSite()) {

			long lSiteId = site.getId();
			if (lSiteId > 11 || lSiteId == 10)
				continue;
		//	String siteName = TestUtils.getSite(lSiteId);
			/*if ((siteToTest.equalsIgnoreCase("sears") && siteName
					.equalsIgnoreCase("kmart"))
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName
							.equalsIgnoreCase("sears"))) {
				continue;
			}*/

			List<String> lstHieararchyIds = new ArrayList<String>();
			for (com.generated.vos.uvd.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()) {
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if (gbOffer.getTaxonomy().getWeb() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:" + itemClassId, "Taxonomy-web is null");
			return;
		}

		//boolean isCrossFormatted = commonUtils.isCrossFormattedItem(prodContent, siteToTest, singleProductOffer, varProdOffer, bSingleProductOffer);
		boolean isCrossFormatted = true;

		if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy()==null?null:gbOffer.getTaxonomy().getWeb(), siteToTest, isCrossFormatted);

		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void compareMasterhierarchyGB(long l, List<com.generated.vos.content.Hierarchy> list)
	{

		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath =GreenBoxCache.getPathForItemClass(l+"");

		if(masterHierarchyPath == null){
			logFailed("MasterTaxonomy", "Hierarchy for "+l+" should exist", "No hierarchy exists");
			return;
		}

		if(list == null){
			logFailed("MasterTaxonomy", "Hierarchy for "+l+" should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master", hierarchyMap);

		compareValues("MasterTaxonomy", masterHierarchyPath.getIdPath(),hierarchyMap.get("no-site-required-for-master").getLstIds().get(0),"IDPath");
		compareValues("MasterTaxonomy", masterHierarchyPath.getDisplayPath(),hierarchyMap.get("no-site-required-for-master").getDisplayPaths().get(0),"DisplayPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void setGBHierarchySeparator(){
		this.hierarchySeparator = "|";
	}

	private String hierarchySeparator = "/";

	public void processMasterHierarchy(List<com.generated.vos.content.Hierarchy> list ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();
		List<String> lstCids  = new LinkedList<String>();

		String id=null, name=null,cid=null;

		for (com.generated.vos.content.Hierarchy hierarchy : list) {

			if(id==null)
				id= GenericUtil.convertToString(hierarchy.getSpinId()); //replaced getId
			else
				id = id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

			if(name==null)
				name=hierarchy.getName();
			else
				name = name+this.hierarchySeparator+hierarchy.getName();

			if(cid==null)
				cid=GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ======  For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}


	private class HierarchyPathVo
	{
		public List<String> getLstIds() {
			return lstIds;
		}
		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}
		public List<String> getLstCIds() {
			return lstCIds;
		}
		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}
		public List<String> getDisplayPaths() {
			return displayPaths;
		}
		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}
		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}
	
	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,List<Hierarchy> hierarchy){

		long XMLHierarchyId;

		if (siteToTest.equalsIgnoreCase("sears")) {
			if (xmlProductOffer.getCoreHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();
		} else {
			if (xmlProductOffer.getShcHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getShcHierarchyId();
		}

		List<String> lstPaths = new LinkedList<String>();
		List<String> lstids = new LinkedList<String>();
		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, XMLHierarchyId+"");

		String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");
		this.hierarchy = name;
		String idpath = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{path{idPath}}}}");

		name = name.replace("SRWI", "");
		name = name.replace("KWSC", "");

		lstPaths.addAll(Arrays.asList(name.split("-")));

		lstids.addAll(Arrays.asList(idpath.split("\\|")));

		if (lstPaths.isEmpty()) {
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId", "null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (hierarchy.size() == 0) {
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		int iHierarchy = 0;

		for (Hierarchy hrchy_ : hierarchy) {
			compareValues("store-taxo-name", lstPaths.get(iHierarchy),hrchy_ == null ? null : hrchy_.getName());
			compareValues("store-taxo-id", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getId());
			//TODO
			//compareValues("store-taxo-spinid", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getSpinId());
			iHierarchy++;
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/*private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,
			List<com.generated.vos.offer.Hierarchy> hierarchy) {

		long XMLHierarchyId;

		if(xmlProductOffer.getCoreHierarchyId() == null)
			return;
		XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();

		String sQuery = "select CATGROUP_ID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"+
				"= (select CATgroup_id from wcsadm.CATGRPDESC where keyword = '"+XMLHierarchyId+"') with ur";

		List<String> lstPaths = DB2Utils.executeQueryMultiColumnSingleRow(sQuery);
		if(lstPaths == null){
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId", "null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if(hierarchy.size() == 0){
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		String lstCatgroupIds = Arrays.asList(lstPaths.get(0).split("/")).subList(1, lstPaths.get(0).split("/").length).toString();

		lstCatgroupIds = lstCatgroupIds.substring(1, lstCatgroupIds.length() - 1);

		sQuery = "select keyword from wcsadm.CATGRPDESC where catgroup_id in ("+lstCatgroupIds+") with ur";
		List<String> lstKeywords = DB2Utils.executeQuerySingleColMulRow(sQuery);
		List<String> lstNames = Arrays.asList(lstPaths.get(1).split("/")).subList(1, lstPaths.get(0).split("/").length);

		int iHierarchy = 0;
		for(String hierarchyId : lstKeywords){
			com.generated.vos.offer.Hierarchy gbHierarchy = hierarchy.get(iHierarchy);
			compareValues("StoreHId", hierarchyId, GenericUtil.convertToString(gbHierarchy==null? null:gbHierarchy.getId()));
			compareValues("StoreHName", lstNames.get(iHierarchy++), gbHierarchy==null? null:gbHierarchy.getName());
		}

		CompareValuesUtility.addNewMultiValuedFields();



	}*/

	/*private void verifyDefiningAttrs(com.generated.vos.uvd.VariantAttribute[] variantAttributes, List<DefiningAttr> definingAttrs) {
		CompareValuesUtility.addNewMultiValuedFields();
		for(com.generated.vos.uvd.VariantAttribute var  : variantAttributes){
			boolean bFound = false;

			List<String> names = fetchAttributeData(var.getAttributeId(),var.getVariantAttributeTypeChoice().getAttributeValueId());			
			for(DefiningAttr gbDefAttr : definingAttrs){
				if(String.valueOf(var.getAttributeId()).equals(gbDefAttr.getAttr().getId())){
					Val attrval = gbDefAttr.getVal();
					bFound=true;
					compareValues("DefAttrId", String.valueOf(var.getAttributeId()), gbDefAttr.getAttr().getId());
					compareValues("DefAttrValueId", String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()),
							attrval==null?null:gbDefAttr.getVal().getId());

					compareValues("DefAttrName", names==null?null:names.get(0), gbDefAttr.getAttr().getName());
					compareValues("DefAttrSeq", names==null?null:names.get(1), gbDefAttr.getAttr().getSeq());
					compareValues("DefAttrType", var.getAttributeType(), gbDefAttr.getAttr().getType());
					//DefAttrValName
					if(var.getTrademarkText()!= null)
						compareValues("DefAttrValName", var.getTrademarkText(),attrval==null?null:gbDefAttr.getVal().getName());
					else
						compareValues("DefAttrValName", names==null?null:names.get(2), attrval==null?null:gbDefAttr.getVal().getName());

					compareValues("DefAttrValFamily", names==null?null:names.get(2),attrval==null?null:gbDefAttr.getVal().getFamilyName());
					compareValues("DefAValSeq", names==null?null:names.get(3), attrval==null?null:gbDefAttr.getVal().getSeq());
					break;
				}
			}
			if(!bFound){
				logFailed("DefAttrId",var.getAttributeId(),"Not found");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private List<String> fetchAttributeData(long attributeId, long attributeValueId) {
		String sQuery = "select att.displaylabel, xcatgrpattrrel.ATTRIBUTESEQUENCE,  atval.STRINGVALUE, atval.SEQUENCE from"+
				" wcsadm.xattribute att, wcsadm.xattrvalue atval,wcsadm.xcatgrpattrrel where atval.NAME = '"+attributeValueId+"'"
				+" and atval.XATTRIBUTE_ID in (select XATTRIBUTE_ID from wcsadm.xattribute where field2 = '"+attributeId+"') and " +
				"atval.XATTRIBUTE_ID = att.XATTRIBUTE_ID and xcatgrpattrrel.XATTRIBUTE_ID = atval.XATTRIBUTE_ID and " +
				"xcatgrpattrrel.catgroup_id in (select catgroup_id from wcsadm.catgroup where identifier='"+itemClassId+"') with ur";
		return DB2Utils.executeQueryMultiColumnSingleRow(sQuery);
	}*/
	
	private void verifyDefiningAttrs(com.generated.vos.uvd.VariantAttribute[] variantAttributes,List<DefiningAttr> definingAttrs) 
	{
		CompareValuesUtility.addNewMultiValuedFields();

		for (com.generated.vos.uvd.VariantAttribute var : variantAttributes) 
		{
			boolean bFound = false;

			for (DefiningAttr gbDefAttr : definingAttrs) 
			{
				if (String.valueOf(var.getAttributeId()).equals(gbDefAttr.getAttr().getId())) 
				{
					Val attrval = gbDefAttr.getVal();

					bFound = true;

					//--------------attribute -------------
					//id,name,seq,type

					AttrVo attrVo = getAttribute(String.valueOf(var.getAttributeId()));
					compareValues("DefAttrId", String.valueOf(var.getAttributeId()), gbDefAttr.getAttr().getId());
					compareValues("DefAttrType", var.getAttributeType(), gbDefAttr.getAttr().getType());

					if(attrVo==null)
					{
						CompareValuesUtility.logFailed("DefAttrName", "Attribute "+String.valueOf(var.getAttributeId())+" not found in GB", gbDefAttr.getAttr().getName());
						CompareValuesUtility.logFailed("DefAttrSeq", "Attribute "+String.valueOf(var.getAttributeId())+" not found in GB under itemClass "+itemClassId, gbDefAttr.getAttr().getName());
					}
					else
					{
						compareValues("DefAttrName", attrVo.getName() , gbDefAttr.getAttr().getName());
						compareValues("DefAttrSeq", attrVo.getSeq(), gbDefAttr.getAttr().getSeq()==null?null:gbDefAttr.getAttr().getSeq().intValue());
					}

					//--------------attribute value-------------
					//id,name,familyname,seq

					AttrValVo attrVal = getAttrVal(String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()), String.valueOf(var.getAttributeId()));

					if (var.getVariantAttributeTypeChoice().getAttributeValueFree() != null) 
					{
						compareValues("DefAttrValueId", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getId());
						compareValues("DefAttrValName", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getName());
						compareValues("DefAttrValFamily", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getFamilyName());
					} 
					else
					{
						compareValues("DefAttrValueId", String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()),
								gbDefAttr.getVal() == null ? null: gbDefAttr.getVal().getId());

						String tdText = var.getTrademarkText();
						String sfinalVal  = tdText;
						if (var.getTrademarkText() != null)
							compareValues("DefAttrValName",	sfinalVal,	gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getName());
						else
						{
							sfinalVal = attrVal==null?" Attribute Id : "+String.valueOf(var.getAttributeId())+" AttrValueId : "+String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId())+ " Not found"
									:attrVal.getName();							
							//System.out.println("================= TD text not available ============== ItemClass : "+itemClassId);
							compareValues("DefAttrValName",	sfinalVal ,
									gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getName());
						}

						if(attrVal==null)
						{
							CompareValuesUtility.logFailed("DefAttrValFamily", " Attribute Id : "+String.valueOf(var.getAttributeId())+" AttrValueId : "+String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId())+ " Not found", 
									gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getFamilyName());
							CompareValuesUtility.logFailed("DefAValSeq", " Attribute Id : "+String.valueOf(var.getAttributeId())+" AttrValueId : "+String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId())+ " Not found",
									gbDefAttr.getVal() == null ? null : (gbDefAttr.getVal().getSeq() == null ? null : gbDefAttr.getVal().getSeq().intValue()));
						}
						else
						{
							sfinalVal = attrVal.getName();

							compareValues("DefAttrValFamily",	sfinalVal,
									gbDefAttr.getVal() == null ? null : gbDefAttr.getVal().getFamilyName());

							compareValues("DefAValSeq",	attrVal.getSeq(), 
									gbDefAttr.getVal() == null ? null : (gbDefAttr.getVal().getSeq() == null ? null : gbDefAttr.getVal().getSeq().intValue()));
						}
					}

					break;
				}
			}
			if (!bFound) {
				logFailed("DefAttrId", var.getAttributeId(), "Not found");
			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private AttrValVo getAttrVal(String attributeValId,String sAttrId)
	{
		AttrValVo attrValVo  =new AttrValVo();

		AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attributeValId);

		if(attrValsch==null)
		{
			return null;
		}
		attrValVo.setName(attrValsch.getDisplayName());
		List<AttrId> allAttrIds = attrValsch.getAttrIds();

		boolean found = false;

		for (AttrId attrId : allAttrIds) {

			if(attrId.getAttrId().equals(sAttrId))
			{
				attrValVo.setSeq(attrId.getRank());

				found=true;
				break;
			}
		}

		if(!found)
			return null;

		return attrValVo;
	}
	private AttrVo getAttribute(String attributeId)
	{
		AttrVo attrVo = new AttrVo();

		String attrResp = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE, attributeId);

		String name = JsonStringParser.getJsonValue(attrResp, "{_blob{attribute{displayName}}}");

		attrVo.setName(name);

		com.generated.vos.hierarchy.Hierarchy masterHierarchy = RestExecutor.getDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, itemClassId);

		List<Label> allLabels =masterHierarchy.getAttrs().getLabels();

		for (Label label : allLabels) {

			List<Attr> attrs = label.getAttrs();

			for (Attr attr : attrs) {

				if(attr.getId().equals(attributeId) && attr.getType().contains("variation"))
				{
					attrVo.setSeq(String.valueOf(attr.getRank().intValue()));
					return attrVo;
				}
			}
		}
		//

		return null;
	}

	class AttrVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		private String id;
		private String name;
		private String seq;
		private String type;
	}

	class AttrValVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getFamiliyName() {
			return familiyName;
		}
		public void setFamiliyName(String familiyName) {
			this.familiyName = familiyName;
		}
		private String id;
		private String name;
		private String seq;
		private String familiyName;
	}

	private void verifyAltIds(ProductOffer xmlProductOffer, AltIds altIds) {
		
		compareValues("AltIds", imaClassControlPid, altIds.getImaClassControlPid(), "ImaClassControlPid");
		compareValues("AltIds", xmlProductOffer.getSpinUniqueId(), altIds.getSpinId(), "SpinId");
		compareValues("AltIds", ksnId, altIds.getKsn(), "Ksn");
		CompareValuesUtility.verifyNullOrEqual("AltIds", xmlProductOffer.getUpc(), altIds.getUpc(), "Upc");
		
		/*	compareValues("AltIds", xmlProductOffer.getUpcType(),GenericUtil.convertToString(altIds.getUpcType()),"UpcType");
		if(xmlProductOffer.getImaAttributes().getVendorPack() !=null)
			verifyNullOrEqual("AltIds", xmlProductOffer.getImaAttributes().getVendorPack()[0].getVendorStockNumber() ,altIds.getVendorStockNo(),"VendorStockNo");*/
		CompareValuesUtility.addNewMultiValuedFields();
	}


//	private void verifyLegal(ProductOffer xmlProductOffer, Legal legal) {
//
//		/*if(xmlProductOffer.getImaAttributes().getHazardMaterialCode() == null && xmlProductOffer.getImaAttributes().getHazardStorageCode() == null &&
//				checkInAttributeGroup("California Emission Compliant") == null && (xmlProductOffer.getImaAttributes().getProp65Flag()==false || 
//				xmlProductOffer.getImaAttributes().getProp65Flag()==null) && xmlProductOffer.getGeoLimiters() == null ){
//			CompareValuesUtility.verifyNull("Legal", legal);
//		}
//		else{
//
//			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes().getHazardMaterialCode(), legal.getHazmatMaterialCd(),"HazmatMtrCd:");
//			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes().getHazardStorageCode(), legal.getHazmatStorageCd(),"HazmatStrgCd:");
//			verifyNullOrEqual("Legal", checkInAttributeGroup("California Emission Compliant"), legal.getIsCaEmmision(),"isCAEmsn?");
//			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes().getProp65Flag() == false?null:true, legal.getIsProp65(),"isProp65?");
//			CompareValuesUtility.addNewMultiValuedFields();*/
//
//
//			if(xmlProductOffer.getGeoLimiters() != null)
//				compareValues("Legal", Arrays.asList(xmlProductOffer.getGeoLimiters().getStates().split(",")), legal.getLimitedGeos(), "LimitedGeos");
//
//		//		verifyNullOrEqual("Legal", checkInAttributeGroup("California Emission Compliant")==false?null:true, legal.getIsCaEmmision());
//		//verifyChokingHazards(legal);
//
//
//	}
	/*private void verifyChokingHazards(Legal legal){
		if(prodContent.getGlobalAttributes() != null){
			for(ChokingHazardType cType : prodContent.getGlobalAttributes().getChokingHazard()){
				if(cType.equals("Hazard - No Warning"))
					compareValues("isNoWarning", true, legal.getIsNoWarning());
				else if(cType.equals("Other Safety Warning"))
					compareValues("isNoWarning", true, legal.getSafetyWarnings());
				else
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.name(), legal.getChokingHazards());
			}
		}
	}*/
	
	private void verifyLegal(ProductContent prodContent, Legal gbLegal) {

		String jewelry_disclosure_52="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care";

		String jewelry_disclosure_53="Diamond weights may not be exact, but are never more than .05 carats below the stated weight";

		String jewelry_disclosure_84="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight";


		boolean bDisclosurePresent = false;

		Integer dicValueId = null;

		if(prodContent.getProductAttributes()!=null && prodContent.getProductAttributes().getProductAttribute()!=null)
		{
			ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();
			for (ProductAttribute productAttribute : attrs) {

				if(productAttribute.getAttributeId().intValue()==30201)
				{
					bDisclosurePresent = true;
					dicValueId = productAttribute.getProductAttributeTypeChoice().getAttributeValueId().intValue();
					break;
				}
			}
		}

		if (  !bDisclosurePresent && prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getHazardMaterialCode() == null
				&& prodContent.getAggrLegalData().getHazardStorageCode() == null
				&& prodContent.getAggrLegalData().getIsCaEmmission() == null
				&& checkInAttributeGroup("California Emission Compliant", prodContent) == null
				&& (prodContent.getAggrLegalData().getProp65Flag() == false || prodContent.getAggrLegalData().getProp65Flag() == null)
				//&& xmlProductOffer.getGeoLimiters() == null
				&& (prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getChokingHazards() == null)) {
			CompareValuesUtility.verifyNull("Legal", gbLegal);
		} else {

			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getHazmatMaterialCd(),
					"HazmatMtrCd");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getUsDotType(),
					"usDotType");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardStorageCode(), gbLegal == null ? null : gbLegal.getHazmatStorageCd(),
					"HazmatStrgCd");
			verifyNullOrEqual("Legal",
					prodContent.getAggrLegalData().getIsCaEmmission() == null || prodContent.getAggrLegalData().getIsCaEmmission() == false ? null : true,
					gbLegal == null ? null : gbLegal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", (prodContent.getAggrLegalData().getProp65Flag() == null ||
					prodContent.getAggrLegalData().getProp65Flag() == false) ? null : true,
							gbLegal == null ? null : gbLegal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			if (productOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(productOffer.getGeoLimiters()
								.getStates().split(",")),
								gbLegal.getLimitedGeos());
			
			if(bDisclosurePresent)
			{
				if(dicValueId==52)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_52, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==53)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_53, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==84)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_84, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==2534)
				{
					CompareValuesUtility.verifyNull("Legal", gbLegal == null ? null : gbLegal.getJewelry()==null?null:gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else
				{
					System.out.println(" ===================== check this dicValueId : "+dicValueId+"===================");
				}
			}
		}
		verifyChokingHazards(gbLegal,prodContent);
	}
	
	private Boolean checkInAttributeGroup(String attrToCheck, ProductContent prodContent) {
		if (prodContent.getGlobalAttributes() != null) {
			for (com.generated.vos.uvd.types.GlobalAttributeType attGroup : prodContent
					.getGlobalAttributes().getAttribute()) {
				if (attGroup.value().equals(attrToCheck))
					return true;

			}
			return false;
		} else
			return null;

	}
	
	private void verifyChokingHazards(Legal gbLegal,ProductContent prodContent) {
		Boolean isWarn = false;
		Boolean safetyWarn = false;
		
		if (prodContent.getAggrLegalData() != null &&  prodContent.getAggrLegalData().getChokingHazards() != null) {
			for (com.generated.vos.uvd.types.ChokingHazardType cType : prodContent.getAggrLegalData().getChokingHazards().getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
					isWarn = true;
				else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
					safetyWarn = true;
				else
				{
					ArrayList<String> list1 = new ArrayList<String>();
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.value(), gbLegal == null ? list1 : gbLegal.getChokingHazards());
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		if(isWarn)
			compareValues("LegalIsNoWarn", true, gbLegal == null ? null : gbLegal.getIsNoWarning());
		if(safetyWarn)
			compareValues("LegalsafetyWarn", true, gbLegal == null ? null : gbLegal.getSafetyWarnings());
	}
	

}
