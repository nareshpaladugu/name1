package com.shi.content.acme.ingest;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class AcmeMPItemBanIngestTests {

	
	@Test(description="Tests to read from qa-1.0_itemban.RT queue and validate data against source db", groups="AcmeMPItemBanIngestTests")
	public void acmeMpItemBanIngestTests() throws Exception {


		BlockingQueue<List<String>> mpIBanDocs = new LinkedBlockingQueue<List<String>>();

		KafkaIAConsumer<String> mpIBanConsumerThread = new KafkaIAConsumer<String>(mpIBanDocs);		
		Thread tConsumerThread = new Thread(mpIBanConsumerThread);
		tConsumerThread.start();
		
		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<String> nodeToTest;

				nodeToTest = mpIBanDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == mpIBanConsumerThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					pool.execute(new AcmeMPItemBanIngestVerifications(nodeToTest));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}

}
