package com.shi.content.ziptests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class ZipCodeTest {

	@Test(groups="ZipCodeTest")
	public void zipCodeTest()
	{

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("bucket"))
		{
			List<String> lstValues = new ArrayList<String>();

			if(LoadProperties.RUN_PARAMS.contains("-")){
				String[] range = LoadProperties.RUN_PARAMS.split("-");
				for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
					lstValues.add(i.toString());
				}
				System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

			}else{
				lstValues = Arrays.asList(LoadProperties.RUN_PARAMS.split(","));
			}

			for (Iterator<String> iterator = lstValues.iterator(); iterator.hasNext();) 
			{
				String string = iterator.next();

				List<String> lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.ZIP_OLD,Integer.parseInt(string));

				System.out.println(" #### ######## Running for bucket : "+ string+"  Size "+ lstIdsInBucket.size());

				for (Iterator<String> iterator2 = lstIdsInBucket.iterator(); iterator2.hasNext();) 
				{
					String zipCode = iterator2.next();

					pool.execute(new ZipCodeVerifications(zipCode));
				}
			}
		}
		else
		{
			String zips[] = LoadProperties.RUN_PARAMS.split(",");

			for (String zip : zips) {

				pool.execute(new ZipCodeVerifications(zip));
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}
}
