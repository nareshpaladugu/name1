package com.shi.content.Variations;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;

public class GB_Assert_Node_Tests {
		
	@DataProvider(name="fileProvider")
	public Object[][] fileProvider(){

		String files = LoadProperties.LST_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		return lstOfFiles;
	}
	
	@Test(dataProvider="fileProvider", groups="AssertNodeAbsentTests")
	public void testNode(String sFileName) throws Exception{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		LinkedBlockingQueue<String> partNumberQueue = new LinkedBlockingQueue();
		String partNumber = null;
		Scanner s = null;
		
		try {
			s = new Scanner(new BufferedReader(new FileReader(sFileName)));
			while (s.hasNext()) {
				partNumber = s.next();
				partNumberQueue.offer(partNumber, 300, TimeUnit.SECONDS);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (s != null) {
				s.close();
			}
		}
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				String idToTest = partNumberQueue.poll(20, TimeUnit.SECONDS);

				if(idToTest == null){
					System.out.println("Got poison pill ..breaking out" + idToTest);
					break;
				}
				if(idToTest != null){
					pool.execute(new GB_Assert_Node_Verifications(idToTest));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}


}
