package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.parsers.XMLParser;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.SHC_ContentVerifications_New;

public class SHC_ContentLoadTest_New {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="SHCContentLoadTestNew")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing file : "+ sFileName);
		
		String sSite = sFileName.split("\\.")[0].split("-")[1];
		
		BlockingQueue<List<SingleProductOffer>> singleProductOfferQueue = new LinkedBlockingQueue<List<SingleProductOffer>>(); 
		
		BlockingQueue<List<VariationProductOffer>> variationProductOfferQueue = new LinkedBlockingQueue<List<VariationProductOffer>>();
				
		String sItemClassId = XMLParser.findNodeValue(sFileName, "catalog", "item-class-id");

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleProductOffer> prodThread = new ChunkProducerThread<SingleProductOffer>(sFileName, singleProductOfferQueue, SingleProductOffer.class,"single-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		ChunkProducerThread<VariationProductOffer> prodVariationThread = 
				new ChunkProducerThread<VariationProductOffer>(sFileName, variationProductOfferQueue, VariationProductOffer.class,"variation-product-offer");//, poison);
		prodVariationThread.setBucketSize(1);
		Thread variationProdThread = new Thread(prodVariationThread);
		variationProdThread.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				
				List<SingleProductOffer> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				
				if(nodeToTest == prodThread.POISON_PILL){
					//System.out.println("Got poison pill ..breaking out" );
					break;
				}
				
				if(nodeToTest != null)
					pool.execute(new SHC_ContentVerifications_New(nodeToTest.get(0), sItemClassId, null,sSite));
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		while(true){
			try {
				List<VariationProductOffer> varProdOfferList = variationProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(varProdOfferList == prodVariationThread.POISON_PILL){
					//System.out.println("Got poison pill ..breaking out" + varProdOfferList);
					break;
				}
				if(varProdOfferList != null)
					pool.execute(new SHC_ContentVerifications_New(null, sItemClassId, varProdOfferList.get(0),sSite));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public 	static List<String> errorPartNumbers = new ArrayList<String>();
	
	@BeforeClass(groups="SHCContentLoadTestNew")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			errorPartNumbers = ErrorPartReader.getErrorPartsFromLogFile(errorlogFile);
		}

	}
	
}
