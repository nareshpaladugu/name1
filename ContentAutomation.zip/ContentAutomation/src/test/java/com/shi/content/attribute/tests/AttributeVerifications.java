package com.shi.content.attribute.tests;

import java.util.Arrays;
import java.util.List;

import com.generated.vos.attribute.AttributeSchema;
import com.generated.vos.attribute.Tag;
import com.generated.vos.attribute.Uom;
import com.generated.xmls.attribute.Attribute;
import com.generated.xmls.attribute.AttributeType;
import com.generated.xmls.attribute.TagSet;
import com.generated.xmls.attribute.Tags;
import com.google.gson.JsonElement;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
//import com.shc.autocontent.attribute.commons.AttributeDBQueries;

public class AttributeVerifications implements Runnable{
	
	private List<Attribute> lstXmlAttribute;
	String wcsXAttributeId = null;
	
	public AttributeVerifications(List<Attribute> xmlAttribute){
		lstXmlAttribute = xmlAttribute;
	}
	
	@Override
	public void run() {
		
		//For each attribute assigned to this thread, do validations
		for(Attribute xmlAttribute : lstXmlAttribute){
			try{
				CompareValuesUtility.init();
				String sAttributeIdToTest = xmlAttribute.getId();
				
				System.out.println("Testing : "+ sAttributeIdToTest);
				//Fetch data of attribute id (gb or api)
				//AttributeSchema gbAttribute = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE, sAttributeIdToTest, AttributeSchema.class);
				
				APIResponse<AttributeSchema> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.ATTRIBUTE, sAttributeIdToTest);
				AttributeSchema gbAttribute = allResponse.getT();
				
				if(gbAttribute == null){
					CompareValuesUtility.logFailed("Id", xmlAttribute.getId(), "Not found");
					CompareValuesUtility.setupResult(String.valueOf(xmlAttribute.getId()), true);
					continue;
				}
				//Call verifications 
				this.compareAttributes(gbAttribute, xmlAttribute);
				this.verifySearch(allResponse, xmlAttribute.getTags());
				
				//Setup the result for this id
				CompareValuesUtility.setupResult(sAttributeIdToTest, true);
			}catch(Throwable e){
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	}
	
	public void validateMandatoryFields(AttributeType a, AttributeSchema gbAttrib){
		if(a.getId() == null || a.getName() == null || a.getEntryType().getName() == null || a.getDataType() == null){
				CompareValuesUtility.verifyRecordNotInserted();
		}
	}
	
	private void verifySearch(APIResponse<AttributeSchema> allResponse, Tags xmlTags) {
		CompareValuesUtility.addNewMultiValuedFields();
		//compareValues("_search.aid", wcsXAttributeId, allResponse.getSearchFieldValue("aid"));
		
		if(xmlTags!=null && xmlTags.getTagSet().length > 0){
			for(TagSet tSet : xmlTags.getTagSet()){
				for(String tag : tSet.getTag()) {
					Boolean bFound = false;
					for(JsonElement gbTag : allResponse.getSearchFields().getAsJsonArray("tagname")){
						if(tag.equals(gbTag.getAsString())){
							bFound = true;
							CompareValuesUtility.logPassed("_search.tagname", tag, gbTag.getAsString());
							break;
						}
					}
					if(!bFound){
						CompareValuesUtility.logFailed("_search.tagname", tag, "Not Found");
					}
				}
			}
		}else{
			if(allResponse.getSearchFields().getAsJsonArray("tagname").size() > 0){
				CompareValuesUtility.logFailed("_search.tagname", "[]", allResponse.getSearchFields().getAsJsonArray("tagname"));
			}
		}
	}	
	
	public void compareAttributes(AttributeSchema gbAttrib, Attribute a){
		CompareValuesUtility.compareValues("Id", a.getId(), gbAttrib.getId());
		CompareValuesUtility.compareValues("DisplayName", a.getDisplayName(), gbAttrib.getDisplayName());
		CompareValuesUtility.compareValues("EntryType", a.getEntryType().getName(), gbAttrib.getEntryType());
		//wcsXAttributeId = new AttributeDBQueries().fetchXAttributeId(a.getId());
		//CompareValuesUtility.compareValues("aid", wcsXAttributeId, gbAttrib.getAid());
		CompareValuesUtility.compareValues("Name", a.getName(), gbAttrib.getName());
		CompareValuesUtility.verifyNullOrEqual("Tooltip", a.getToolTip(), gbAttrib.getToolTip());
		CompareValuesUtility.verifyNullOrEqual("Type", a.getType().getName(), gbAttrib.getType());
		CompareValuesUtility.verifyNullOrEqual("FilterType", a.getFilterType(), gbAttrib.getFilterType());
		CompareValuesUtility.verifyNullOrEqual("DispFormat", a.getDisplayFormat(), gbAttrib.getDispFormat());
		
		if(a.getUom()!= null)
			compareUOM(a.getUom(), gbAttrib.getUom());
		else
			CompareValuesUtility.addToHeaders(new String[]{"Uom Abbrv","Uom Id","Uom Name","Uom Type"});
		if(a.getTags() != null){
			compareTags(a.getTags(), gbAttrib.getTags());
		}
		else
			CompareValuesUtility.addToHeaders(new String[]{"No. of tags","TagType","TagName"});
				
		/*CompareValuesUtility.addNewMultiValuedFields();
		new AttributeValVerifications().compareAttributeValuesForAttribute
		(a.getAllowedValues().getAllowedValue(), a.getId(), wcsXAttributeId);*/
		
	}
	
	public void compareTags(Tags xmlTags, List<Tag> gbTags){
		CompareValuesUtility.addNewMultiValuedFields();
		CompareValuesUtility.compareValues("No. of tags", xmlTags.getTagSetCount(), gbTags.size());
		
		
		//Should be only one..so hardcoding to 0
		if(gbTags.size()>0){
			for(TagSet tSet : xmlTags.getTagSet()){
				int i = CompareValuesUtility.verifyInListField("TagType", tSet.getNamespace(), gbTags, "type", Tag.class);
				if(i!= -1){
					List<String> lstTags = Arrays.asList(tSet.getTag());
					CompareValuesUtility.verifyTrue(lstTags.equals(gbTags.get(i).getName()), "TagName", lstTags,gbTags.get(i).getName());
				}
			}
		}
		}

	public void compareUOM(com.generated.xmls.attribute.Uom xmlUom, Uom gbUom){
		CompareValuesUtility.compareValues("Uom Abbrv", xmlUom.getAbbreviation(), gbUom.getAbbreviation());
		CompareValuesUtility.compareValues("Uom Id", xmlUom.getId(), gbUom.getId().longValue());
		CompareValuesUtility.compareValues("Uom Name", xmlUom.getName(), gbUom.getName());
		CompareValuesUtility.compareValues("Uom Type", xmlUom.getType(), gbUom.getType());
		
	}
	
	

	
}