package com.shi.content.ranking.vos;

public class ShipMode {
	
	Double shipCharge;

	public Double getShipCharge() {
		return shipCharge;
	}

	public void setShipCharge(Double shipCharge) {
		this.shipCharge = shipCharge;
	}
	
}
