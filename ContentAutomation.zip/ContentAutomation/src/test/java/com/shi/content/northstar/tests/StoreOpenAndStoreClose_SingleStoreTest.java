package com.shi.content.northstar.tests;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.Header;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * To test if user is able to Open and close Single Store
 * @author inaikwa
 *
 */
public class StoreOpenAndStoreClose_SingleStoreTest extends NorthStarBaseTest {
	private ArrayList<String> listStoreIds;
	private String storeId ;
	final static String STORECLOSEREASON = "In Liquidation";
	
	
	@Test(description="Test store closing and opening", groups="NS-P1")
	public void testStoreStateChange(){
		
		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();
		
		searchPage.searchByZipCode("00926");
		
		listStoreIds =  searchPage.getAllSearsOpenNonICEEStores();

//		Kmart
//		searchPage.searchByDistrict("40761");
//		listStoreIds = searchPage.getAllKmartOpenStores();
		
		Asserts.verifyNotNull(listStoreIds.size(), "Verifed required storeIds found");
		
		Assert.assertNotNull(listStoreIds.size(), listStoreIds.size()+ " =: Zero stores found, terminating......... ");
		
		storeId =listStoreIds.get(0);
		
		searchPage.clickStore(storeId);
		
		EditStoreDetails eView = new EditStoreDetails();
		
		eView.closeStoreSingleView();
	

//		Header header = new Header();
//		Asserts.verifyTrue(header.getStatusMessage().containsText("Close Store Success!"), "Verify store close message displayed");
//		Asserts.verifyTrue(!(eView.getBtnCloseStore().isVisible()), "Verify close store button is no longer visible");

		
		Asserts.verifyTrue(eView.closeStoreSuccessMsg(), "Verified that the Close Store success msg is displayed after closing store" );
	
		String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 
		String strCloseStatus =  JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strStatus", true);
		String strClsReason = JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strClsReason", true);
		Asserts.verifyEquals("0", strCloseStatus,"Verify store status is closed in strStatus");
		
		strCloseStatus = JsonStringParser.getJsonValueNew(sJsonRep, "_search.strStatus", true);
		Asserts.verifyEquals("0", strCloseStatus,"Verify store status is closed in _search.strStatus");
		Asserts.verifyEquals(STORECLOSEREASON, strClsReason,"Verify store close reason is "+ STORECLOSEREASON);
		
		// Opening the store
		
		eView.openStoreSingleView();
		
		Asserts.verifyTrue(eView.openStoreSuccessMsg(), "Verified that the Open Store success msg is displayed after opening store" );
		
		String sStore = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 
		String sStrStatus =  JsonStringParser.getJsonValueNew(sStore, "_blob.unit.strStatus", true);
		Asserts.verifyEquals("1", sStrStatus,"Verify store status is "+sStrStatus+" in strStatus");
		Asserts.verifyNull(JsonStringParser.getJsonValueNew(sStore, "_blob.unit.strClsReason").equals("null")?
				null:JsonStringParser.getJsonValueNew(sStore, "_blob.unit.strClsReason"), "strClsReason tag is successfully removed.");
		
	}
}
