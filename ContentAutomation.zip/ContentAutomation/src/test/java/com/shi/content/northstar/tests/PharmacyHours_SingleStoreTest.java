package com.shi.content.northstar.tests;


import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * Test Pharmacy hours updating for Single Stores
 * @Note Pharmacy hours are available for Kmart Stores only 
 * ,  Pharmacy hours not for Multiple stores
 * @author inaikwa
 * @storeId  provide only pharmacy store
 *
 */
public class PharmacyHours_SingleStoreTest extends NorthStarBaseTest {
	private ArrayList<String> listStoreIds;
	private String storeId="4862";
	private String SundayOpenTime;
	
	@Test(description="Test to verify if the Pharmacy Hours are updating ", groups = {"NS-P1"})
	public void testUpdatePharmacyHours() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();

		searchPage.searchByStoreNumber(storeId);
		
		searchPage.clickStore(storeId);
		
		EditStoreDetails eView = new EditStoreDetails();
		
		eView.goToPharmacyView();
		
		SundayOpenTime=eView.updateHours_Pharma();
		
		eView.saveDocument();
		
		Asserts.verifyTrue(eView.updateSuccessMsg(), "Verified that the Update success msg is displayed after updating Sunday Open Time for Pharamcy " );

		String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 

		String sSundayOpenTime = "0"+Integer.toString(Integer.parseInt(JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.pharm.hrs.sun.opn").replaceAll("\"", ""))/3600);
		
		Asserts.verifyEquals(SundayOpenTime,sSundayOpenTime,"Verified that the store time is updated for Pharmacy");
		
	}
	
}
