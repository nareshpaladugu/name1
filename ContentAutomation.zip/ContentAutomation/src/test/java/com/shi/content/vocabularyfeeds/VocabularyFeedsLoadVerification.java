package com.shi.content.vocabularyfeeds;

import java.util.ArrayList;
import java.util.List;

import com.generated.vos.offer.Offer;
import com.generated.vos.offer.VocTag;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.vocabularyfeeds.pojos.HierarchyVO;
import com.shc.content.vocabularyfeeds.pojos.NodeVO;
import com.shc.content.vocabularyfeeds.pojos.ProductVO;
import com.shc.content.vocabularyfeeds.pojos.VocabularyTermVO;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;

public class VocabularyFeedsLoadVerification implements Runnable {

	ProductVO productToTest = null;
	List<HierarchyVO> relatedList = null;
	List<HierarchyVO> deletedList = null;

	public VocabularyFeedsLoadVerification(ProductVO productVO) {
		this.productToTest = productVO;
	}

	@Override
	public void run() {
		try {
			CompareValuesUtility.init();
			if (productToTest != null) {
//				System.out.println("Verifying spin: "+productToTest.getId());

				// Check content id
				List<String> idsByAltKey = RestExecutor.getIdsByAltKey(CollectionValuesVal.CONTENT, "spinId", this.productToTest.getId());
				if (idsByAltKey == null || idsByAltKey.size() == 0) {
					throw new Exception("No content document present for spinId: "+this.productToTest.getId());
				}

				String contentId = idsByAltKey.get(0);

				if (contentId == null || contentId.equals("")) {
					throw new Exception("No content document present for spinId: "+this.productToTest.getId());
				}

				// Get offer ids
				List<String> offerIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId", contentId);
				if (offerIds == null || offerIds.size() == 0 ) {
					throw new Exception("No offer present for spinId: "+this.productToTest.getId());
				}

				relatedList = productToTest.getRelatedList();
				deletedList = productToTest.getDeletedList();

				List<VocabularyTermVO> vocTermList = null;

				// Test Vocabulary Deleted Terms
				if (deletedList != null && deletedList.size()>0) {
					for (HierarchyVO hierarchyVO : deletedList) {
						try {
							vocTermList = prepareVocabularyTermSequence(hierarchyVO.getLeafNode());
							if (vocTermList == null || vocTermList.size() == 0)
								throw new Exception("Exception: There is no vocTerm associated to hierarchy "+hierarchyVO.getLeafNode().getVocabularyTerm().getId());
							verifyDeletedAssociation(vocTermList, offerIds);
						} catch(Exception e) {
							System.out.println("Error: "+e.getMessage());
						}
					}
				}

				// Test Vocabulary Associated Terms
				for (HierarchyVO hierarchyVO : relatedList) {
					try {
						if (hierarchyVO.isDeleteActionHierarchy()) {
							vocTermList = prepareVocabularyTermSequence(hierarchyVO.getLeafNode());
							if (vocTermList == null || vocTermList.size() == 0)
								throw new Exception("Exception: There is no vocTerm associated to hierarchy "+hierarchyVO.getLeafNode().getVocabularyTerm().getId());
							verifyDeletedAssociation(vocTermList, offerIds);
						} else {
							vocTermList = prepareVocabularyTermSequence(hierarchyVO.getLeafNode());
							if (vocTermList == null || vocTermList.size() == 0)
								throw new Exception("Exception: There is no vocTerm associated to hierarchy "+hierarchyVO.getLeafNode().getVocabularyTerm().getId());
							verifyRelatedAssociation(vocTermList, offerIds);
						}
					} catch(Exception e) {
						System.out.println("Error: "+e.getMessage());
					}
				}
			}	
		} catch (Exception e) {
			System.out.println("Exception: "+e.getMessage());
//			CompareValuesUtility.addDataFieldForReport("Error", e.getMessage(), INFOTYPE.FAILED);
			
			if (e.getMessage().contains("No content document present") || e.getMessage().contains("No offer present")) {
//				CompareValuesUtility.addDataFieldForReport("Skipped", e.getMessage(), INFOTYPE.FAILED);
				CompareValuesUtility.logFailed("Skipped", "", e.getMessage(), "");
			} else {
				CompareValuesUtility.addDataFieldForReport("Error", e.getMessage(), INFOTYPE.FAILED);
			}
			
			CompareValuesUtility.setupResult(productToTest.getId(), true);
		} finally {
			CompareValuesUtility.teardown();
		}
	}

	public List<VocabularyTermVO> prepareVocabularyTermSequence(NodeVO leafNode) {
		NodeVO currentNode = leafNode;

		// Prepare Hierarchy Sequence
		List<VocabularyTermVO> vocTermList = new ArrayList<>();
		NodeVO tempNode = currentNode;

		while(true) {
			if (tempNode == null)
				break;
			VocabularyTermVO tempVocTerm = tempNode.getVocabularyTerm();
			vocTermList.add(tempVocTerm);
			tempNode = tempNode.getParentNode();
		}
		return vocTermList;
	}

	public void verifyRelatedAssociation(List<VocabularyTermVO> vocTermList, List<String> offerIdsList) {
		try {
//			System.out.println("Verifying Related Association: ");
			CompareValuesUtility.init();
			for (String offerId : offerIdsList) {
//				System.out.println("Started verifying Related Association for Offer: "+offerId);
				CompareValuesUtility.addDataFieldForReport("Offer Id", offerId, INFOTYPE.DATA);

				// Get json data
				APIResponse<Object> result = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId);
				if (result == null)
					throw new Exception("Offer Not present in offer collection: "+offerId);

				Offer offer = result.getT();

				// Check whether voc tag is present
				if (offer.getVocTags() == null || offer.getVocTags().size() == 0) {
					throw new Exception("Voc tag not populated in offer "+offer.getId());
				}

				List<VocTag> vocTags = offer.getVocTags();

				String spinIdPath = "";

				String expActDate = "1900-01-01T00:00:00.000Z";
				String expExpDate = "9999-12-31T23:59:59.000Z";

				for(int i=(vocTermList.size()-1); i>=0; i--) {
					VocabularyTermVO vocTerm = vocTermList.get(i);

					// Verify spinIdPath
					if (spinIdPath.equals(""))
						spinIdPath = vocTerm.getId();
					else
						spinIdPath = spinIdPath+"|"+vocTerm.getId();

					// Get required hierarchy
					VocTag vocTag = null;
					for (int j=0; j<vocTags.size(); j++) {
						vocTag = vocTags.get(j);
						if (vocTag.getSpinIdPath().equals(spinIdPath))
							break;
					}

					if (vocTag == null) {
						throw new Exception("No voc tag present for spinIdPath: "+vocTerm.getSpinIdPath());
					}

					// Match all the data
					CompareValuesUtility.compareValues("spinIdPath",spinIdPath,vocTag.getSpinIdPath());
					CompareValuesUtility.compareValues("dispPath",vocTerm.getDisplayPath(),vocTag.getDispPath());
					CompareValuesUtility.compareValues("name",vocTerm.getName(),vocTag.getName());

					if (!vocTerm.getActivationDate().equals("1900-01-01T00:00:00.000Z")) {
						expActDate = vocTerm.getActivationDate();
					}
					CompareValuesUtility.compareValues("actDt",expActDate,vocTag.getActDt());

					if (!vocTerm.getExpiryDate().equals("9999-12-31T23:59:59.000Z")) {
						expExpDate = vocTerm.getExpiryDate();
					}
					CompareValuesUtility.compareValues("expDt",expExpDate,vocTag.getExpDt());
				}
				System.out.println("Verified Related Association for Offer: "+offerId);
			}
		} catch (Exception e) {
			CompareValuesUtility.addDataFieldForReport("Error", e.getMessage(), INFOTYPE.FAILED);
		} finally {
			CompareValuesUtility.setupResult(productToTest.getId(), true);
			CompareValuesUtility.teardown();
		}
	}

	public void verifyDeletedAssociation(List<VocabularyTermVO> vocTermList, List<String> offerIdsList) {
		try {
//			System.out.println("Verifying Deleted Association: ");
			CompareValuesUtility.init();
			for (String offerId : offerIdsList) {
//				System.out.println("Started verifying Deleted Association for Offer: "+offerId);
				CompareValuesUtility.addDataFieldForReport("Offer Id", offerId, INFOTYPE.DATA);

				// Get json data
				APIResponse<Object> result = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId);
				if (result == null)
					throw new Exception("Offer Not present in offer collection: "+offerId);

				Offer offer = result.getT();

				List<VocTag> vocTags = offer.getVocTags();

				if (vocTags == null || vocTags.size() == 0) {
//					CompareValuesUtility.addDataFieldForReport("Deleted Term Verification", "PASS", INFOTYPE.DATA);
					CompareValuesUtility.logPassed("Deleted Term Verification", "All voc tags should be deleted", "");
				} else {
					VocTag vocTag = null;
					boolean flag = true;
					for (int j=0; j<vocTags.size(); j++) {
						vocTag = vocTags.get(j);
						if (vocTag.getSpinIdPath().equals(vocTermList.get(0).getSpinIdPath())) {
							CompareValuesUtility.logFailed("Deleted Term Verification", "All voc tags should be deleted", "Voc tag not deleted from offer: "+vocTermList.get(0).getSpinIdPath(), "");
//							CompareValuesUtility.addDataFieldForReport("Deleted Term Verification", "Fail", INFOTYPE.FAILED);
//							CompareValuesUtility.addDataFieldForReport("Failure Reason", "Voc tag still present in offer: "+vocTermList.get(0).getSpinIdPath(), INFOTYPE.DATA);
							flag = false;
							break;
						}
					}

					if (flag) {
//						CompareValuesUtility.addDataFieldForReport("Deleted Term Verification", "PASS", INFOTYPE.DATA);
						CompareValuesUtility.logPassed("Deleted Term Verification", "All voc tags should be deleted", "");
					}
					System.out.println("Verified Deleted Association for Offer: "+offerId);
				}
			}
		} catch (Exception e) {
			CompareValuesUtility.addDataFieldForReport("Error", e.getMessage(), INFOTYPE.FAILED);
		} finally {
			CompareValuesUtility.setupResult(productToTest.getId(), true);
			CompareValuesUtility.teardown();
		}
	}
}