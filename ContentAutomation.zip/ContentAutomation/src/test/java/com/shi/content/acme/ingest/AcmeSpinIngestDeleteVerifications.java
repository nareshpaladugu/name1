package com.shi.content.acme.ingest;

import java.net.URI;
import java.net.URISyntaxException;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.productoffering.Delete;
import com.generated.vos.productoffering.ItemDelete;
import com.generated.vos.productoffering.VariationDelete;
import com.generated.vos.productoffering.VariationGroupDelete;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

/**
 * @author ddaphal
 *
 */
public class AcmeSpinIngestDeleteVerifications implements Runnable 
{

	Delete deleteNode;

	public AcmeSpinIngestDeleteVerifications(Delete deleteNode) 
	{
		this.deleteNode=deleteNode;
	}

	public void run() {

		//=============================== ItemDelete =============================

		ItemDelete deleteItem = deleteNode.getItemDelete();
		if(deleteItem!=null)
		{
			verifySingleItemDelete(deleteItem);
		}

		//============================= VariationDelete=========================

		VariationDelete variationDelete = deleteNode.getVariationDelete();

		if(variationDelete!=null)
		{
			ItemDelete[] deleteItems = variationDelete.getItemDelete();

			for (ItemDelete itemDelete : deleteItems) {

				verifySingleItemDelete(itemDelete);
			}
		}

		//============================= VariationGroupDelete ===========================

		VariationGroupDelete variationGroupDelete = deleteNode.getVariationGroupDelete();

		if(variationGroupDelete!=null)
		{
			CompareValuesUtility.init();

			String variationGroupId = variationGroupDelete.getVariationGroupId();

			getIaSource(variationGroupId);

			if(iaSource == null){
				CompareValuesUtility.logPassed("Id", variationGroupId, " Not found");
			}else{

				String sExpStatus;

				if( variationGroupDelete.getItemStatusDetails()==null || variationGroupDelete.getItemStatusDetails().getItemStatus()==null )
				{
					sExpStatus ="DELETED";
				}
				else
				{
					sExpStatus =  variationGroupDelete.getItemStatusDetails().getItemStatus().name();
				}

				compareDeleteStatus(sExpStatus, iaSource);

				ItemAuthorityTestCommon.compareTwoLists(variationGroupDelete.getItemStatusDetails()==null?null:variationGroupDelete.getItemStatusDetails().getInactiveReason(), 
						iaSource.getItem().getAttributes().getStatus().getStatusReason(), "Inactive Reason");

			}

			CompareValuesUtility.setupResult(variationGroupId, true);
		}
	}

	/**
	 * @param deleteItem
	 */
	private void verifySingleItemDelete(ItemDelete deleteItem)
	{
		if(deleteItem!=null)
		{
			CompareValuesUtility.init();

			String itemId = deleteItem.getItemId()+"";

			getIaSource(itemId);

			if(iaSource == null){
				CompareValuesUtility.logPassed("Id", itemId, " Not found");
			}else{

				String sExpStatus;

				if(deleteItem.getItemStatusDetails()==null || deleteItem.getItemStatusDetails().getItemStatus()==null )
				{
					sExpStatus ="DELETED";
				}
				else
				{
					sExpStatus = deleteItem.getItemStatusDetails().getItemStatus().name();
				}

				compareDeleteStatus(sExpStatus, iaSource);

				ItemAuthorityTestCommon.compareTwoLists(deleteItem.getItemStatusDetails()==null?null:deleteItem.getItemStatusDetails().getInactiveReason(), 
						iaSource.getItem().getAttributes().getStatus().getStatusReason(), "Inactive Reason");

			}

			CompareValuesUtility.setupResult(itemId, true);
		}
	}

	AcmeSourceById iaSource;

	/**
	 * Hit source db using item id
	 * @param partNumberToTest
	 * @return
	 */
	public boolean  getIaSource(String partNumberToTest)
	{
		String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+partNumberToTest;
		System.out.println(sURL);
		URI uri=null;
		try {
			uri = new URI(sURL);
		} catch (URISyntaxException e) {

			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
			CompareValuesUtility.setupResult(partNumberToTest, true);
			return false;
		}

		String sSourceJson = RestExecutor.getJSonResponse(uri);

		if(!sSourceJson.contains("item")){
			iaSource=null;
			return false;
		}

		iaSource = JSONParser.parseJSON(sSourceJson, AcmeSourceById.class);

		return true;
	}

	/**
	 * Compares delete status with expected from isSource item
	 * @param sExpStatus
	 * @param iaSource
	 */
	private void compareDeleteStatus(String sExpStatus, AcmeSourceById iaSource)
	{
		//TODO re-check
		//default null 
		sExpStatus = sExpStatus==null?"null":sExpStatus;

		String sActStatus;

		if(iaSource.getItem()==null||iaSource.getItem().getStatus()==null)
		{
			sActStatus = "null";
		}
		else
		{
			sActStatus = iaSource.getItem().getStatus();
		}

		CompareValuesUtility.compareValues("Status", sExpStatus ,  sActStatus);
		CompareValuesUtility.compareValues("Attr.Status", sExpStatus ,  iaSource.getItem().getAttributes().getStatus().getStatus());
	}

}
