package com.shi.content.attribute.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.generated.xmls.attribute.AllowedValue;
import com.generated.xmls.attribute.Attribute;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
//import com.shc.autocontent.attribute.commons.AttributeDBQueries;

public class AttributeValTests {

	@DataProvider(name="fileProvider")
	public Object[][] fileProvider(){
		
		String files = LoadProperties.LST_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		return lstOfFiles;
	}
	
	@Test(dataProvider="fileProvider", groups="AttrvalueTests")
	public void testAttrFeed(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Attribute>> attributeQueue = new LinkedBlockingQueue<List<Attribute>>(); 
		//AttributeDBQueries db = new AttributeDBQueries();
		//Create producer thread
		ChunkProducerThread<Attribute> prodThread = new ChunkProducerThread<Attribute>(sFileName, attributeQueue, Attribute.class);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Attribute> nodeToTest = attributeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					for(Attribute xmlAttribute : nodeToTest){
						
						if(xmlAttribute.getAllowedValues() != null){
							String sAttributeIdToTest = xmlAttribute.getId();
							//String wcs_attrid = db.fetchXAttributeId(sAttributeIdToTest);
							for(AllowedValue allowedValue : xmlAttribute.getAllowedValues().getAllowedValue()){
								//pool.execute(new AttributeValVerifications(allowedValue, sAttributeIdToTest, wcs_attrid));
								pool.execute(new AttributeValVerifications(allowedValue, sAttributeIdToTest));
							}
						}else{
							System.out.println(xmlAttribute.getId());
						}
//					pool.execute(new AttributeValVerifications(attributeQueue.poll(10, TimeUnit.SECONDS)));
					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		pool.shutdown();
		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
