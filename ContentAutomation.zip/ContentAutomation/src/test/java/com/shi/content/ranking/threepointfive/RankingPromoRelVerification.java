package com.shi.content.ranking.threepointfive;

import java.util.List;

import com.generated.vos.content.Content;
import com.generated.vos.offer.OfferSchema;
import com.generated.vos.proto.itemPromo.PromoRel;
import com.generated.vos.proto.itemPromo.SYWPromo;
import com.generated.vos.rankingmongo.offer.Rankingmongo;
import com.generated.vos.rankingmongo.offer.SywOffer;
import com.generated.vos.rankingmongo.offer.SywPoints;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.ranking.threepointfive.helper.RankingMongoHelper;


/**
 * @author ddaphal
 *
 */
public class RankingPromoRelVerification implements Runnable 
{
	com.generated.vos.proto.itemPromo.PromoRelList promoRelList;

	public RankingPromoRelVerification(com.generated.vos.proto.itemPromo.PromoRelList promoRel) {
		this.promoRelList = promoRel;
	}
	

	public void run() 
	{
		String offerIdFromGB;//gggh
		
		
		
		boolean found;
		String spinId;

		Rankingmongo singleMongoDoc=null;

		for (PromoRel singlePromoRelInputMsg : promoRelList.getPromorelList()) 
		{
			spinId= String.valueOf(singlePromoRelInputMsg.getItemId());

			CompareValuesUtility.init();

			offerIdFromGB = RankingMongoHelper.getOfferIdbySpinId(spinId);

			singleMongoDoc = RankingApi.getSingleDoc(offerIdFromGB);

			if(isSingleActivePromo(singlePromoRelInputMsg))
			{
				System.out.println("spinId(input msg - Got at least one active promo) .. "+spinId);

				if(offerIdFromGB==null)
				{
					System.out.println("Offer not present in Gb for this spin : "+spinId);

					if(singleMongoDoc==null)
					{
						CompareValuesUtility.addDataFieldForReport("RankingMongoDocument"," As exp not found-gb offer not exist");
					}
				}
				else
				{
					OfferSchema offer = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_SCHEMA,offerIdFromGB);
					Content contentRecord = RestExecutor.getDataById(CollectionValuesVal.CONTENT,offer.getBlob().getOffer().getIdentity().getParentId());

					if(contentRecord==null)
					{
						if(singleMongoDoc==null)
						{
							CompareValuesUtility.addDataFieldForReport("RankingMongoDocument"," As exp not found-gb content not exist");
						}
					}
					else
					{
						if(singleMongoDoc==null)
						{
							CompareValuesUtility.addFailedDataFieldForReport("RankingMongoDocument","Not Found");
						}
						else
						{
							CompareValuesUtility.compareValues("_Id",offerIdFromGB,singleMongoDoc.getId());
							CompareValuesUtility.compareValues("SpinId",spinId,singleMongoDoc.getSpinId());
							CompareValuesUtility.compareValues("ProgType",singlePromoRelInputMsg.getPrgm().toString(),singleMongoDoc.getPgmType().toString());

							String catEntSubType = contentRecord.getClassifications().getCatentrySubType();

							int offerCnt=0;

							Integer offerCount=null;
							try {
								offerCount = contentRecord.getIdentity().getOfferCnt().intValue();
								offerCnt=offerCount.intValue();
							} catch (Exception e1) {
								System.out.println("Offer count not found..");
								offerCnt=0;
							}

							if(catEntSubType.equalsIgnoreCase("NV") && offerCnt ==1)
							{
								CompareValuesUtility.compareValues("isMultiOfferGroup",false,singleMongoDoc.getIsMultiOfferGroup());
							}
							else
							{
								CompareValuesUtility.compareValues("isMultiOfferGroup",true,singleMongoDoc.getIsMultiOfferGroup());
							}


							CompareValuesUtility.addDataFieldForReport("catEntSubTypeFromGB",catEntSubType+"");
							CompareValuesUtility.addDataFieldForReport("offerCountFromGB",offerCnt+"");

							String bucket;
							try {
								bucket = String.valueOf(offer.getBucket().intValue());
							} catch (Exception e) {
								bucket="-NA-";
							}

							CompareValuesUtility.compareValues("Bucket",bucket,
									singleMongoDoc.getBucket());

							List<SYWPromo> activeSWYPromo = singlePromoRelInputMsg.getActiveSYWPromoList();

							System.out.println("Input msg activeSWYPromo.. size : "+activeSWYPromo.size());

							for (SYWPromo sywPromoInputMsg : activeSWYPromo) {

								found=false;
								for (SywOffer sywPromoMongo : singleMongoDoc.getSywOffers()) {

									SywPoints swyPoints=  singleMongoDoc.getSywPoints();

									CompareValuesUtility.addDataFieldForReport("PromoCode-inputMsg",sywPromoInputMsg.getPromoId());

									if(sywPromoInputMsg.getPromoId().equals(sywPromoMongo.getSywId()))
									{
										//Mapping @
										//https://wiki.intra.sears.com/confluence/display/MarketplaceEngineering/Ranking+Bonus+Service+Schemas

										found=true;

										if(isActivePromo(sywPromoInputMsg))
										{
											//if its active compare with mongo
											CompareValuesUtility.compareValues("PromoCode",sywPromoInputMsg.getPromoId(),sywPromoMongo.getSywId());
											CompareValuesUtility.compareValues("PromoName",sywPromoInputMsg.getPromoName(),sywPromoMongo.getName());
											CompareValuesUtility.compareValues("offerTypeCode",sywPromoInputMsg.getTypeCde(),sywPromoMongo.getOfferTypeCode());
											CompareValuesUtility.compareValues("OfferSubType",sywPromoInputMsg.getSubTypeCde().toString(),sywPromoMongo.getOfferSubType());

											CompareValuesUtility.compareValues("Site",sywPromoInputMsg.getSite().toString(),sywPromoMongo.getSite());

											if(sywPromoInputMsg.getGenPromoFlag())
												CompareValuesUtility.compareValues("IsMemberSpecific","false",sywPromoMongo.getIsMemberSpecific());
											else
												CompareValuesUtility.compareValues("IsMemberSpecific","true",sywPromoMongo.getIsMemberSpecific());

											CompareValuesUtility.compareValues("StartDtm",String.valueOf(sywPromoInputMsg.getStartDtm()).toString(),
													String.valueOf(sywPromoMongo.getStartDt().longValue()));
											CompareValuesUtility.compareValues("EndDtm",String.valueOf(sywPromoInputMsg.getEndDtm()).toString(),
													String.valueOf(sywPromoMongo.getEndDt().longValue()));
										}
										else
										{
											CompareValuesUtility.logFailed("Promo",sywPromoInputMsg.getPromoId(),"Expired promo found");
										}

										break;
									}
								}

								if(!found)
								{
									//Not found
									if(isActivePromo(sywPromoInputMsg))
									{
										CompareValuesUtility.logFailed("Promo",sywPromoInputMsg.getPromoId(),"Active promo Not found in Mongo");
									}
									else
									{
										CompareValuesUtility.logPassed("Promo",sywPromoInputMsg.getPromoId(),"As expected expired promo not found");
									}
								}
							}
						}
					}

				}
			}
			else
			{
				System.out.println("None of the promo is active...");

				if(singleMongoDoc!=null)
				{
					CompareValuesUtility.addFailedDataFieldForReport("ItemRecord","Should not present in Mongo");
				}
				else
				{
					CompareValuesUtility.addDataFieldForReport("ItemRecord","As expected not present in Mongo");
				}
			}

			CompareValuesUtility.setupResult(spinId, true);
		}
	}

	private boolean isActivePromo(SYWPromo sywPromoInputMsg)
	{
		long startDate = sywPromoInputMsg.getStartDtm();
		long endDate = sywPromoInputMsg.getEndDtm();

		if(startDate<= RankingPromoRelVerificationTest.CURRENT_TIME && endDate>=RankingPromoRelVerificationTest.CURRENT_TIME)
		{
			return true;
		}

		System.out.println("this is expired promo "+sywPromoInputMsg.getPromoId());

		return false;
	}

	private boolean isSingleActivePromo(PromoRel singlePromoRelInputMsg)
	{
		List<SYWPromo> listOfPromos = singlePromoRelInputMsg.getActiveSYWPromoList();

		if(listOfPromos==null || listOfPromos.isEmpty())
		{
			return false;
		}
		for (SYWPromo singlePromo : listOfPromos) 
		{
			if(isActivePromo(singlePromo))
			{
				return true;
			}
		}

		return false;
	}

}
