package com.shi.content.matching.acme;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.matching.SingleOfferMatchDataVo;
import com.shi.content.matching.SubGroupVo;

/**
 * @author ddaphal
 *
 */
public class MatchingValidationACME implements Runnable
{
	private String ssin;

	Set<String> brandSetSSIN;

	Set<String> modelSetSSIN;

	Set<String> upcSetSSIN;

	Set<String> setOfParentIdsSSINLevel;

	String sOfferTypeSSINLevel="-NA-";

	String sMasterVerticalSSINLevel="-NA-";

	String sPkgQtySSINLevel="-NA-";

	Map<String, Integer> mapDefAttrSSINLevel;

	AcmeMatchingCommon acmeMatchingCommon;

	Set<String> setOfActiveSources;

	public MatchingValidationACME(String ssinUnderTest)
	{
		this.ssin = ssinUnderTest;
		acmeMatchingCommon = new AcmeMatchingCommon();
	}


	public void run() 
	{
		//System.out.println("Testing : "+ssin);

		Set<String> sExpectedSSINs = null;

		List<JsonObject> sourceData = new ArrayList<JsonObject>();

		getSourcesBySSIN(sourceData);

		int groupNumberTracker = 1;

		brandSetSSIN = new HashSet<String>();
		modelSetSSIN = new HashSet<String>();
		upcSetSSIN = new HashSet<String>();
		setOfParentIdsSSINLevel=new HashSet<String>();
		mapDefAttrSSINLevel=new HashMap<String, Integer>();
		setOfActiveSources=new HashSet<String>();

		Set<String> setOfBrandCoddIds=new HashSet<String>();

		Map<String,SubGroupVo> mapOfSubGroupedByUID = new LinkedHashMap<String, SubGroupVo>();

		SingleOfferMatchDataVo vo;
		CompareValuesUtility.init();

		boolean siteOnlyOffer=false;

		boolean init = false;

		boolean parentLevelExclusion=false;

		Set<String> upcSetByUID = null;

		Set<String> programTypes= new HashSet<String>();
		if(sourceData.isEmpty() && MatchingTestACME.printEmptySSINs)
		{
			CompareValuesUtility.addDataFieldForReport("Validation-skipped", "Empty SSIN");
			return;

		}	
		else
		{
			sExpectedSSINs = acmeMatchingCommon.getExpectedSSIN(sourceData);

			Set<String> sourceDataListByPid = new HashSet<String>();

			for (JsonObject objFromSource  : sourceData) 
			{
				vo = acmeMatchingCommon.getMatchingData(objFromSource,false);

				if(vo.getOfferType().equals("P"))
				{
					sourceDataListByPid.addAll(getSourceItemIdListByPID(vo.getSourceDbId()));
				}
			}

			getSourcesByList(sourceDataListByPid, sourceData);

			for (JsonObject objFromSource  : sourceData) 
			{
				/* ============= JSON Document to Matching Data VO =============*/

				vo = acmeMatchingCommon.getMatchingData(objFromSource,false);

				if(vo.getOfferType().equals("P") || !vo.getAcmeSourceStatus().equalsIgnoreCase("Active"))
					continue;
				/*============================== Check for exclusion rules ====================*/

				if(MatchingTestACME.LogMisClassAndContentScore.equalsIgnoreCase("true"))
				{
					vo.setContentScore(acmeMatchingCommon.getContentScore(vo.getSourceDbId()));
					vo.setMisClassStr(acmeMatchingCommon.getMisClass(vo.getSourceDbId()));
				}

				setOfActiveSources.add(vo.getSourceDbId());
				acmeMatchingCommon.checkForExclusionRule(vo);

				checkForSearsOrKmartOnlyOffer(vo);

				siteOnlyOffer = siteOnlyOffer || vo.isSiteOnlySpecificOffer;

				SubGroupVo subGroupVo = mapOfSubGroupedByUID.get(vo.getUid());

				if(subGroupVo==null)
					subGroupVo=new SubGroupVo(groupNumberTracker++);

				List<SingleOfferMatchDataVo> offerListBySingleUID = subGroupVo.getListOfOffers();

				if(offerListBySingleUID == null)
					offerListBySingleUID = new ArrayList<SingleOfferMatchDataVo>();

				vo.setOfferNumberInSubGroup(offerListBySingleUID.size()+1);

				offerListBySingleUID.add(vo);
				if(vo.isExcludedAtParentLevel())
					parentLevelExclusion=true;

				subGroupVo.setListOfOffers(offerListBySingleUID);

				mapOfSubGroupedByUID.put(vo.getUid(),subGroupVo);

				brandSetSSIN.add(vo.getBrandName());

				modelSetSSIN.add(vo.getModelNumber());

				if(!vo.getUpc().isEmpty())
					upcSetSSIN.add(vo.getUpc());

				setOfParentIdsSSINLevel.add(vo.getParentId());

				setOfBrandCoddIds.add(vo.getBrandCodeId());


			}

			if(!setOfActiveSources.isEmpty())
			{
				Iterator<Entry<String, SubGroupVo>> uidKeyIterator = mapOfSubGroupedByUID.entrySet().iterator();

				upcSetByUID = null;

				Map<String, Integer> mapAccordingtoDefAttrsUIDLevel =new LinkedHashMap<String, Integer>();

				int ctrUID = -1;

				boolean excluded = false;

				boolean forceMatched   = false;

				while (uidKeyIterator.hasNext()) 
				{
					ctrUID ++;

					Entry<String, SubGroupVo> subGroupbyUIDEntry =  uidKeyIterator.next();

					List<SingleOfferMatchDataVo> offerListByUID = subGroupbyUIDEntry.getValue().getListOfOffers();

					forceMatched = acmeMatchingCommon.fetchFeaturesDataByGuid(subGroupbyUIDEntry.getKey(),offerListByUID);

					//assume first offers 
					if(!init)
					{
						sMasterVerticalSSINLevel = offerListByUID.get(0).getMasterVerticalId();
						sOfferTypeSSINLevel = offerListByUID.get(0).getOfferType();
						sPkgQtySSINLevel = offerListByUID.get(0).getPackageQty();
						init  = true;
					}

					upcSetByUID = new HashSet<String>();

					mapAccordingtoDefAttrsUIDLevel.clear();

					mapAccordingtoDefAttrsUIDLevel.put(offerListByUID.get(0).getVarAttrs(), 1);

					excluded=false;
					//all offer should have same UPC, for offer having null UPC, it should have matching brand model
					for (int i = 0; i < offerListByUID.size(); i++) 
					{
						SingleOfferMatchDataVo matchingDataVo = offerListByUID.get(i);

						if(!matchingDataVo.getUpc().isEmpty())
							upcSetByUID.add(matchingDataVo.getUpc());

						CompareValuesUtility.addDataFieldForReport("GroupNumber", subGroupbyUIDEntry.getValue().getGroupNumber()+"."+ matchingDataVo.getOfferNumberInSubGroup());

						logDataToResult(matchingDataVo);

						programTypes.add(matchingDataVo.getProgramType());

						if(MatchingTestACME.exceptionVerticals.contains(matchingDataVo.getMasterVerticalId())    //if vertical is from exception list
								&& 	matchingDataVo.isSiteOnlySpecificOffer   // and if its site only specific offer
								&&  sourceData.size()>1
								&&  (matchingDataVo.getProgramType().equalsIgnoreCase("sears")||matchingDataVo.getProgramType().equalsIgnoreCase("kmart")))
						{

							CompareValuesUtility.addFailedDataFieldForReport("SiteOnly-Specific-Offer-grouped", "should be excluded from group" );
						}
						else
						{
							//For NV items group all offer should same UID, UID subgroup size should be 1 
							if(sOfferTypeSSINLevel.equalsIgnoreCase("NV") && ctrUID>=1)
							{
								CompareValuesUtility.addFailedDataFieldForReport("UID", matchingDataVo.getUid());
							}
							else
							{
								CompareValuesUtility.addDataFieldForReport("UID", matchingDataVo.getUid());
							}

							if(!MatchingTestACME.excludeVerticalFromMatching)
							{
								//UPC set empty - can be transitive match
								if(sMasterVerticalSSINLevel.equals(matchingDataVo.getMasterVerticalId()) || forceMatched)
								{
									CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
								}
								else
								{

									if(upcSetByUID.isEmpty())
									{
										CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
									}
									else
									{
										CompareValuesUtility.logFailed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
									}

								}
							}
							else
							{
								CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
							}

							if(mapAccordingtoDefAttrsUIDLevel.get(matchingDataVo.getVarAttrs())==null)
							{
								CompareValuesUtility.addFailedDataFieldForReport("varAttr", matchingDataVo.getVarAttrs());
							}
							else
							{
								CompareValuesUtility.addDataFieldForReport("varAttr", matchingDataVo.getVarAttrs());
							}

							Integer ys2 = mapDefAttrSSINLevel.get(matchingDataVo.getVarAttrs());

							if(ys2==null)
							{
								mapDefAttrSSINLevel.put(matchingDataVo.getVarAttrs(),1);
							}
							else
							{
								mapDefAttrSSINLevel.put(matchingDataVo.getVarAttrs(),ys2++);
							}

							if(matchingDataVo.isSingleItemGroupNeeded())
							{
								try {
									if(acmeMatchingCommon.getActiveGuidSources("guid="+matchingDataVo.getUid())==1)
									{
										excluded=true;
										CompareValuesUtility.addDataFieldForReport("Single-Offer-SubGroup-Reason", matchingDataVo.getSingleItemGroupReason());
									}
									else
									{
										CompareValuesUtility.addFailedDataFieldForReport("Single-Offer-SubGroup-offercount", "Found No/Multiple Offers");
									}
								} catch (Exception e) {

									CompareValuesUtility.addFailedDataFieldForReport("Exception", "Single-Offer-SubGroup check : "+e.getMessage());
								}
							}

							if(!excluded && i == offerListByUID.size()-1)
							{
								CompareValuesUtility.compareValues("OfferCount-By-GUID",offerListByUID.size(),
										acmeMatchingCommon.getActiveGuidSources("guid="+subGroupbyUIDEntry.getKey().toString()));
							}

							if((sPkgQtySSINLevel.isEmpty() || sPkgQtySSINLevel.equals("1") ) && (matchingDataVo.getPackageQty().isEmpty()||matchingDataVo.getPackageQty().equals("1")))
								CompareValuesUtility.logPassed("PackageQty", sPkgQtySSINLevel,matchingDataVo.getPackageQty());
							else
								CompareValuesUtility.compareValues("PackageQty", sPkgQtySSINLevel,matchingDataVo.getPackageQty());

							CompareValuesUtility.addDataFieldForReport("DivLine", matchingDataVo.getDivLine());


							CompareValuesUtility.addDataFieldForReport("MisClass", matchingDataVo.getMisClassStr());
							String scr = matchingDataVo.getContentScore()==null?"null":(matchingDataVo.getContentScore()+"");
							CompareValuesUtility.addDataFieldForReport("ContentScore", scr);

						}
					}
					//here UPC set should not be more than 1 (it can be 0 or 1)

					Set<String> upcSetByUIDChk = new HashSet<String>();
					for (String singleupc : upcSetByUID) {
						upcSetByUIDChk.add(StringUtils.leftPad(singleupc, 14, "0"));
					}

					if(programTypes.contains("UVD"))
					{
						//UVD Grp

						if(setOfBrandCoddIds.size()>1)
						{
							//Check for force match
							if(!forceMatched)
							{
								CompareValuesUtility.addFailedDataFieldForReport("Multiple BrandCodeIds under same UID", StringUtils.join(setOfBrandCoddIds, ","));
							}
						}

					}
					else
					{
						if(upcSetByUIDChk.size()>1)
						{
							//Check for force match
							if(!forceMatched)
							{
								CompareValuesUtility.addFailedDataFieldForReport("MultipleUPC under same UID", StringUtils.join(upcSetByUID, ","));
							}
						}
					}

				}

				/*================ ensure parent item is not grouped with any other item as its excluded at parent level===========*/
				if( parentLevelExclusion && setOfParentIdsSSINLevel.size()!=1 )
				{
					CompareValuesUtility.addDataFieldForReport("Single-Offer-Group", "Found Multiple Items(ParentIds)");
				}

				if(sExpectedSSINs.contains(ssin))
					CompareValuesUtility.logPassed("SSIN", ssin, ssin);
				else
					CompareValuesUtility.logFailed("SSIN", StringUtils.join(sExpectedSSINs, ","), ssin);
			}
			else
			{
				if(MatchingTestACME.printEmptySSINs)
				{
					CompareValuesUtility.addDataFieldForReport("Validation-skipped", "No active item in grp");
					return;
				}
			}
		}

		if(MatchingTestACME.findMissingOffers)
			findMissingOffers();

		CompareValuesUtility.setupResult(this.ssin, true);

		clean();
	}

	private void checkForSearsOrKmartOnlyOffer(SingleOfferMatchDataVo vo)
	{
		vo.setSiteOnlySpecificOffer(true);

		String programType = vo.getProgramType();

		String webHierarchy = vo.getWebHierarchy();

		if( (programType.equalsIgnoreCase("sears") || programType.equalsIgnoreCase("kmart")) 
				&& webHierarchy!=null && !webHierarchy.isEmpty())
		{
			JsonParser jParser = new JsonParser();

			JsonArray array=null;
			JsonElement jsonElement = jParser.parse(webHierarchy);
			array = jsonElement.getAsJsonArray();

			String kmart=null, sears=null;

			//1 kmart 2 sears
			for (JsonElement jsonElement2 : array) 
			{
				if(jsonElement2.getAsJsonObject().get("id").getAsString().equals("1"))
					kmart="1";
				else if(jsonElement2.getAsJsonObject().get("id").getAsString().equals("2"))
					sears="2";
			}

			if( (programType.equalsIgnoreCase("sears") || programType.equalsIgnoreCase("kmart")) &&
					(kmart!=null && sears!=null))
			{

				vo.setSiteOnlySpecificOffer(false);
			}
		}
	}

	/**
	 * Find Missing offers
	 */
	private void findMissingOffers()
	{
		String sUpcs = null;

		for (String upc : upcSetSSIN) 
		{
			for (int i = 14; i > upc.length(); i--) 
			{
				sUpcs = sUpcs==null?"upcCode="+StringUtils.leftPad(upc, i,"0"):sUpcs+"&upcCode="+StringUtils.leftPad(upc, i,"0");
			}
			sUpcs = sUpcs==null?"upcCode="+upc:sUpcs+"&upcCode="+upc;
		}

		Map<String,SingleOfferMatchDataVo> sourceIdMap = new HashMap<String, SingleOfferMatchDataVo>();

		//fetch features data by UPC
		sourceIdMap.putAll(acmeMatchingCommon.getFeaturesItemsByField(sUpcs,sMasterVerticalSSINLevel,sOfferTypeSSINLevel,
				upcSetSSIN,brandSetSSIN,modelSetSSIN,sPkgQtySSINLevel,mapDefAttrSSINLevel.keySet()));

		String brandNModel= null;

		for (String model : modelSetSSIN) 
		{
			if(!model.toLowerCase().contains("nbsp;"))
				brandNModel = brandNModel==null?"modelNumber="+model:brandNModel+"&modelNumber="+model;
		}

		for (String brand : brandSetSSIN) 
		{
			if(!brand.toLowerCase().contains("nbsp;"))
				brandNModel = brandNModel==null?"modelNumber="+brand:brandNModel+"&modelNumber="+brand;
		}

		//fetch features data by upc and model
		sourceIdMap.putAll(acmeMatchingCommon.getFeaturesItemsByField(brandNModel,sMasterVerticalSSINLevel,sOfferTypeSSINLevel,
				upcSetSSIN,brandSetSSIN,modelSetSSIN,sPkgQtySSINLevel,mapDefAttrSSINLevel.keySet()));

		sourceIdMap.keySet().removeAll(setOfActiveSources);

		for (Map.Entry<String,SingleOfferMatchDataVo> entry : sourceIdMap.entrySet()) 
		{
			CompareValuesUtility.addFailedDataFieldForReport("Missing-Source",entry.getKey() );
			logDataToResult(entry.getValue());
			CompareValuesUtility.addDataFieldForReport("UID", entry.getValue().getUid());

			if(MatchingTestACME.excludeVerticalFromMatching)
				CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,entry.getValue().getMasterVerticalId());
			else
				CompareValuesUtility.compareValues("MasterVertical", sMasterVerticalSSINLevel,entry.getValue().getMasterVerticalId());
		}

	}

	/**
	 * Log common data fields
	 * @param matchingDataVo
	 */
	private void logDataToResult(SingleOfferMatchDataVo matchingDataVo)
	{
		CompareValuesUtility.addDataFieldForReport("sourceid", matchingDataVo.getSourceDbId());

		CompareValuesUtility.addDataFieldForReport("statuc", matchingDataVo.getAcmeSourceStatus());

		CompareValuesUtility.addDataFieldForReport("UPC", matchingDataVo.getUpc());

		CompareValuesUtility.addDataFieldForReport("ParentId", matchingDataVo.getParentId());

		CompareValuesUtility.addDataFieldForReport("Brand", matchingDataVo.getBrandName());

		CompareValuesUtility.addDataFieldForReport("Model", matchingDataVo.getModelNumber());

		CompareValuesUtility.addDataFieldForReport("ProgramType", matchingDataVo.getProgramType());

		CompareValuesUtility.addDataFieldForReport("brandCodeId", matchingDataVo.getBrandCodeId());

		CompareValuesUtility.compareValues("OfferType", sOfferTypeSSINLevel,matchingDataVo.getOfferType());

	}

	/**
	 * Set all instance variable to null
	 */
	public void clean()
	{
		ssin=null;

		brandSetSSIN=null;

		modelSetSSIN=null;

		upcSetSSIN=null;

		setOfParentIdsSSINLevel=null;

		sOfferTypeSSINLevel=null;

		sMasterVerticalSSINLevel=null;

		sPkgQtySSINLevel=null;

		mapDefAttrSSINLevel=null;
	}


	/**
	 * Gets all sources by ssin in one go
	 * @param sourceData
	 */
	private void getSourcesBySSIN(List<JsonObject> sourceData)
	{
		JsonParser jParser = new JsonParser();

		JsonElement jsonElement = jParser.parse(RestExecutor.getJSonResponse
				("http://"+LoadProperties.IA_SERVER+"/acme/source?ssin="+ssin+"&page-size=500"));

		JsonArray array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

		// Sources by SSIN
		for (int i = 0; i < array.size(); i++) 
			sourceData.add(array.get(i).getAsJsonObject());
	}

	/**
	 * Captures all source data in lots of 100
	 * @param sourceIdSet
	 * @param sourceData
	 */
	private void getSourcesByList(Set<String> sourceIdSet, List<JsonObject> sourceData)
	{
		JsonParser jParser = new JsonParser();
		JsonElement jsonElement;
		List<String> sourceList = new ArrayList<>();
		sourceList.addAll(sourceIdSet);

		List<List<String>> subList = Lists.partition(sourceList, 100);
		JsonArray array;

		String subUrl = "";
		for (List<String> sublist : subList) {

			subUrl="";

			for (String singleSrcId : sublist) 
			{
				subUrl=subUrl.isEmpty()?"id="+singleSrcId:subUrl+"&id="+singleSrcId;
			}

			jsonElement = jParser.parse(RestExecutor.getJSonResponse
					("http://"+LoadProperties.IA_SERVER+"/acme/source?"+subUrl+"&page-size=100"));

			array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

			for (int i = 0; i < array.size(); i++) 
			{
				sourceData.add(array.get(i).getAsJsonObject());
			}
		}
	}

	/**
	 * Returns all source ids for given pid
	 * @param pid
	 * @return
	 */
	private Set<String> getSourceItemIdListByPID (String pid)
	{
		Set<String> sourceDataList = new HashSet<String>();

		String jsonResponse = RestExecutor.getJSonResponse
				("http://"+LoadProperties.IA_SERVER+"/acme/features?pid="+pid+"&page-size=1000");

		jsonResponse=jsonResponse==null?"":jsonResponse;

		JsonParser jParser = new JsonParser();

		JsonElement jsonElement;

		JsonArray array =null;

		jsonElement = jParser.parse(jsonResponse);

		if(jsonElement.getAsJsonObject().get("items")!=null)
		{
			array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

			for (int ii = 0; ii < array.size(); ii++) 
			{
				sourceDataList.add( array.get(ii).getAsJsonObject().get("id").getAsString());
			}
		}

		return sourceDataList;
	}
}