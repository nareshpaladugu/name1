package com.shi.content.acme.reconcile;

public class ItemDetails {

	String itemId;
	String pgmType;
	String isPreferredContent;
	String isForceSSIN;
	String ssin;
	String calcSsin;
	String lastUpdatedTime;
	String vendorId;
	String ownerId;
	
	public ItemDetails(String itemId, String pgmType, String isPreferredContent, String isForceSSIN, String ssin, String calcSsin, String lastUpdatedTime, String vendorId, String ownerId) {
		this.itemId = itemId;
		this.pgmType = pgmType;
		this.isPreferredContent = isPreferredContent;
		this.isForceSSIN = isForceSSIN;
		this.ssin = ssin;
		this.calcSsin = calcSsin;
		this.lastUpdatedTime = lastUpdatedTime;
		this.vendorId = vendorId;
		this.ownerId = ownerId;	
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getCalcSsin() {
		return calcSsin;
	}

	public void setCalcSsin(String calcSsin) {
		this.calcSsin = calcSsin;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getPgmType() {
		return pgmType;
	}

	public void setPgmType(String pgmType) {
		this.pgmType = pgmType;
	}

	public String getIsPreferredContent() {
		return isPreferredContent;
	}

	public void setIsPreferredContent(String isPreferredContent) {
		this.isPreferredContent = isPreferredContent;
	}

	public String getIsForceSSIN() {
		return isForceSSIN;
	}

	public void setIsForceSSIN(String isForceSSIN) {
		this.isForceSSIN = isForceSSIN;
	}

	public String getSsin() {
		return ssin;
	}

	public void setSsin(String ssin) {
		this.ssin = ssin;
	}

	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}
}