package com.shi.content.acme;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.Attributes;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.VariantAttribute;
import com.generated.vos.productoffering.VariantAttributes;
import com.generated.vos.uvd.ProductAttributes;
import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.BeanComparor;
import com.shc.autocontent.testcommons.TestUtils;
/**
 * @author ddaphal
 *
 */


public class ItemAuthorityTestCommon 
{
	/**
	 * @param expectedMap
	 * @param actualMap
	 * @return
	 */
	public  boolean compareAttributesMaps(Map<String, List<VarAttr>> expectedMapOrg, Map<String, List<VarAttr>> actualMapOrg,boolean logResult,String sAttributeName,boolean... mpFlag)
	{

		if((expectedMapOrg==null || expectedMapOrg.isEmpty()) && ( actualMapOrg ==null || actualMapOrg.isEmpty()))
		{
			return true;
		}

		Map<String, List<VarAttr>> expectedMap= new HashMap<>(expectedMapOrg);
		Map<String, List<VarAttr>> actualMap= new HashMap<>(actualMapOrg);


		//Defaults to true, mp will send false explicitly
		boolean encodeFlag = true;

		if(mpFlag.length>0)
		{
			encodeFlag = mpFlag[0];
		}
		else
		{
			encodeFlag = true;
		}

		Set<String> keysALL;

		if(expectedMap==null || expectedMap.isEmpty())
			keysALL=new HashSet<String>();
		else
			keysALL = expectedMap.keySet();

		MapDifference<String, List<VarAttr>> diff = Maps.difference(expectedMap,actualMap);

		Map<String, ValueDifference<List<VarAttr>>> r1 = diff.entriesDiffering();

		Map<String, List<VarAttr>> r2 = diff.entriesOnlyOnLeft();

		Map<String, List<VarAttr>> r3 = diff.entriesOnlyOnRight();

		if(r1.isEmpty() && r2.isEmpty() && r3.isEmpty())
		{
			//System.out.println(" ============== Maps are Equal ======= "+sAttributeName);

			if(logResult)
			{
				for (String key : keysALL) 
				{
					CompareValuesUtility.logPassed(sAttributeName, TestUtils.getDisplayableObject(expectedMap.get(key)), TestUtils.getDisplayableObject(actualMap.get(key)));
					//return true;
				}
				CompareValuesUtility.addNewMultiValuedFields();
			}

			return true;
		}
		else
		{
			if(!logResult)
				return false;
			//System.out.println(" ============== Maps are Not Equal ======= "+sAttributeName);

			if(logResult)
			{
				// Field Level Mismatch
				for (String key : r1.keySet()) 
				{
					List<VarAttr> expectedObject = expectedMap.get(key);

					List<VarAttr> actualObject = actualMap.get(key);

					for (Iterator<VarAttr> iterator = expectedObject.iterator(); iterator.hasNext();) 
					{
						VarAttr expVarAttr =  iterator.next();

						boolean found = false;

						for (Iterator<VarAttr> iterator2 = actualObject.iterator(); iterator2.hasNext();)
						{
							VarAttr varAttrAct =  iterator2.next();

							try {
								if(BeanComparor.compareObjects(expVarAttr, varAttrAct))
								{
									found=true;
									CompareValuesUtility.logPassed(sAttributeName, TestUtils.getDisplayableObject(expVarAttr), TestUtils.getDisplayableObject(varAttrAct));
								}
							} catch (Exception e) {
								e.printStackTrace();
								System.out.println("Excpetion while comparing attributes.....");
								CompareValuesUtility.addFailedDataFieldForReport("Exception ","please check log ");
							}

						}

						if(!found)
						{
							VarAttr varAttrAct  = actualObject.get(0);
							if(expectedObject.size()==1 && actualObject.size()==1)
							{
								//both side have only one object, so we can expand failure
								//Expanding only failed result
								CompareValuesUtility.verifyNullOrEqual(sAttributeName, expVarAttr.getId(), varAttrAct.getId(),"Id");

								if(encodeFlag)
									CompareValuesUtility.verifyNullOrEqual(sAttributeName, TestUtils.replaceDoubleQuote(TestUtils.plainEncodeHTML(expVarAttr.getTrademarkText())), varAttrAct.getTrademarkText(),"TradeMarkText");
								else
									CompareValuesUtility.verifyNullOrEqual(sAttributeName, expVarAttr.getTrademarkText(), varAttrAct.getTrademarkText(),"TradeMarkText");

								String sExpValId =  expVarAttr.getValueId();
								sExpValId=sExpValId==null?"null":sExpValId;

								String sActValId = varAttrAct.getValueId();
								//System.out.println("sActValId......"+sActValId);
								sActValId=sActValId==null?"null": (sActValId.contains(".")? sActValId.substring(0, sActValId.indexOf(".")):sActValId);

								CompareValuesUtility.compareValues(sAttributeName, sExpValId , sActValId, "ValueId");

								CompareValuesUtility.verifyNullOrEqual(sAttributeName, expVarAttr.getValueFlag(), varAttrAct.getValueFlag(), "ValueFlag");

								if(encodeFlag)
									CompareValuesUtility.verifyNullOrEqual(sAttributeName, TestUtils.replaceDoubleQuote(TestUtils.plainEncodeHTML(expVarAttr.getValueFree())),varAttrAct.getValueFree(),"ValueFree");
								else
									CompareValuesUtility.verifyNullOrEqual(sAttributeName, expVarAttr.getValueFree(), varAttrAct.getValueFree(), "ValueFree");

							}
							else
							{
								//HERE expansion not needed, e.g. case expected are 3 attributes and got only 1
								CompareValuesUtility.logFailed(sAttributeName, TestUtils.getDisplayableObject(expVarAttr), "NOT FOUND");
							}
						}
					}
				}
			}
			// Entire Object Not found - LEFT
			for (String key : r2.keySet()) 
			{
				if(logResult)
				{
					CompareValuesUtility.logFailed(sAttributeName, TestUtils.getDisplayableObject(expectedMap.get(key)), "NOT FOUND");
				}
				return false;
			}

			// Entire Object Not found - RIGHT
			for (String key : r3.keySet()) 
			{
				if(logResult)
				{
					CompareValuesUtility.logFailed(sAttributeName, "", TestUtils.getDisplayableObject(actualMap.get(key)));
				}
				return false;
			}

			keysALL.removeAll(r1.keySet());
			keysALL.removeAll(r2.keySet());
			keysALL.removeAll(r3.keySet());

			// Entire Object MATCH PASS case
			for (String key : keysALL) 
			{
				if(logResult)
				{
					CompareValuesUtility.logPassed(sAttributeName, TestUtils.getDisplayableObjectForList(expectedMap.get(key)), TestUtils.getDisplayableObjectForList(actualMap.get(key)	),key+"");
				}
			}
			if(logResult)
			{
				CompareValuesUtility.addNewMultiValuedFields();
			}
			//return false;
		}

		return true;

	}

	public static Map<String, List<VarAttr>> getAttributesMapListFromJsonNew(String json)
	{
		Map<String, List<VarAttr>> attributesMapList = new HashMap<String, List<VarAttr>>();

		if(json==null || json.isEmpty())
			return attributesMapList;

		JsonParser jParser = new JsonParser();

		JsonElement jsonElement = jParser.parse(json);

		Gson gson = new Gson();

		JsonArray allAttributesArray  = jsonElement.getAsJsonArray();

		for(int i=0; i < allAttributesArray.size(); i++)
		{
			String id = null;
			List<VarAttr> varAttrList = new ArrayList<VarAttr>();
			JsonObject singleAttribute = allAttributesArray.get(i).getAsJsonObject();
			for(Entry<String, JsonElement> abc : singleAttribute.entrySet())
			{
				JsonObject jsonObj = singleAttribute.get(abc.getKey()).getAsJsonObject();
				VarAttr varAttr = new VarAttr();
				id = abc.getKey();
				varAttr.setId(id);
				varAttr.setValueId(jsonObj.get("valueId")==null?null:jsonObj.get("valueId").getAsString());
				varAttr.setValueFree(jsonObj.get("valueFree")==null?null:jsonObj.get("valueFree").getAsString());
				varAttr.setValueFlag(jsonObj.get("valueFlag")==null?null:jsonObj.get("valueFlag").getAsBoolean());
				varAttr.setTrademarkText(jsonObj.get("trademarkText")==null?null:jsonObj.get("trademarkText").getAsString());

				varAttrList = attributesMapList.get(id);

				if(varAttrList==null){
					varAttrList = new ArrayList<VarAttr>();
				}

				varAttrList.add(varAttr);
			}

			attributesMapList.put(id,varAttrList);
		}

		return attributesMapList;
	}

	public static String getSubUrlForSourceAutoFetchMode()
	{
		String sSubUL = null;

		String sRunParam = LoadProperties.RUN_PARAMS;

		String spRunParam[] = sRunParam.split("&");

		if(spRunParam.length==1)
		{
			//either vendors or item class
			if(spRunParam[0].contains("vendor"))
			{
				sSubUL = "?";
				//vendor
				String[] spilltedVendorIds = spRunParam[0].split("=")[1].split(",");

				//1,2,3
				for (String string : spilltedVendorIds) {

					if(sSubUL.length()==1)
						sSubUL = sSubUL +"vendorId="+string;
					else
						sSubUL = sSubUL +"&vendorId="+string;
				}
			}
			else
			{
				//item class

				sSubUL = "?";
				//vendor
				String[] spilltedItemClassIds = spRunParam[0].split("=")[1].split(",");

				//1,2,3
				for (String string : spilltedItemClassIds) {

					if(sSubUL.length()==1)
						sSubUL = sSubUL +"itemClassId="+string;
					else
						sSubUL = sSubUL +"&itemClassId="+string;
				}
			}
		}
		else if(spRunParam.length==2)
		{
			//both vendors or item class

			sSubUL = "?";

			//vendor
			String[] spilltedVendorIds = spRunParam[0].split("=")[1].split(",");

			//1,2,3
			for (String string : spilltedVendorIds) {

				if(sSubUL.length()==1)
					sSubUL = sSubUL +"vendorId="+string;
				else
					sSubUL = sSubUL +"&vendorId="+string;
			}
			//vendor
			String[] spilltedItemClassIds = spRunParam[1].split("=")[1].split(",");

			//1,2,3
			for (String string : spilltedItemClassIds) {

				sSubUL = sSubUL +"&itemClassId="+string;
			}

			System.out.println("sSubUL................... "+sSubUL);
		}


		return sSubUL;
	}

	public static Map<String, List<VarAttr>> getVarAttrMapFromKafkaMsg(List<com.generated.vos.proto.catalogcommons.Attribute> skuAttr) {

		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		for (com.generated.vos.proto.catalogcommons.Attribute variantAttribute : skuAttr) 
		{
			String attrId = variantAttribute.getId()+"";

			VarAttr varAttr = new VarAttr();

			varAttr.setId(variantAttribute.getId()+"");
			varAttr.setTrademarkText(variantAttribute.getTrademarkTxt());
			varAttr.setValueFlag(variantAttribute.getValueFlag());
			varAttr.setValueFree(variantAttribute.getValueFree());
			varAttr.setValueId(variantAttribute.getValueId()+"");

			List<VarAttr> innerList = output.get(attrId);	
			if(innerList==null)
			{
				innerList=new ArrayList<VarAttr>();
			}

			innerList.add(varAttr);
			output.put(attrId, innerList);
		}

		return output;
	}

	public static Map<String, List<VarAttr>>  getVarAttrMapXml(VariantAttributes varAttrs )
	{
		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		VariantAttribute[] varAttrsList = varAttrs.getVariantAttribute();

		for (VariantAttribute variantAttribute : varAttrsList) 
		{
			String attrId = variantAttribute.getAttributeId()+"";

			VarAttr varAttr = new VarAttr();

			varAttr.setId(variantAttribute.getAttributeId()+"");
			varAttr.setTrademarkText(variantAttribute.getTrademarkText());
			varAttr.setValueFlag(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueFlag());
			varAttr.setValueFree(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueFree());
			varAttr.setValueId(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueId()+"");


			List<VarAttr> innerList = output.get(attrId);

			if(innerList==null)
			{
				innerList=new ArrayList<VarAttr>();
			}

			innerList.add(varAttr);

			output.put(attrId, innerList);
		}

		return output;
	}
	public static Map<String, List<VarAttr>> getVarAttrMapXml(
			com.generated.vos.catdelta.VariantAttribute[] variantAttributes) {

		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		for (com.generated.vos.catdelta.VariantAttribute variantAttribute : variantAttributes) 
		{
			String attrId = variantAttribute.getItemAttributeGroup().getAttributeId()+"";

			VarAttr varAttr = new VarAttr();

			varAttr.setId(variantAttribute.getItemAttributeGroup().getAttributeId()+"");
			varAttr.setTrademarkText(variantAttribute.getItemAttributeGroup().getTrademarkText());
			varAttr.setValueFlag(variantAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag());
			varAttr.setValueFree(variantAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree());
			varAttr.setValueId(variantAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()+"");

			List<VarAttr> innerList = output.get(attrId);	
			if(innerList==null)
			{
				innerList=new ArrayList<VarAttr>();
			}

			innerList.add(varAttr);
			output.put(attrId, innerList);
		}

		return output;

	}

	public static Map<String, List<VarAttr>> getattributesMapXml(
			Attributes attributes2) {

		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		if(attributes2!=null)
		{
			for (Attribute productAttribute : attributes2.getAttribute()) 
			{
				VarAttr varAttr = new VarAttr();

				varAttr.setId(productAttribute.getItemAttributeGroup().getAttributeId()+"");
				varAttr.setTrademarkText(productAttribute.getItemAttributeGroup().getTrademarkText());
				varAttr.setValueFlag(productAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag());
				varAttr.setValueFree(productAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree());
				varAttr.setValueId(productAttribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()+"");

				List<VarAttr> innerList = output.get(productAttribute.getItemAttributeGroup().getAttributeId()+"");
				if(innerList==null)
				{
					innerList =new ArrayList<VarAttr>();
				}
				innerList.add(varAttr);

				output.put(productAttribute.getItemAttributeGroup().getAttributeId()+"",innerList);
			}
		}
		return output;

	}
	public static void compareTwoLists(List<String> list1Expected ,List<String> list2Actual,String sAattributeName)
	{

		if((list1Expected==null || list1Expected.isEmpty()) && (list2Actual==null || list2Actual.isEmpty()))
		{
			//BOTH NULL/EMPTY
			CompareValuesUtility.logPassed(sAattributeName, "null", "null");
		}
		else if( (list1Expected==null || list1Expected.isEmpty()) && (list2Actual!=null && !list2Actual.isEmpty()))
		{
			//expected NULL or EMPTY and actual not NULL or EMPTY
			CompareValuesUtility.logFailed(sAattributeName, "null", list2Actual);
		}
		else if((list1Expected!=null  && !list1Expected.isEmpty()) && ( list2Actual==null || list2Actual.isEmpty()))
		{
			//expected not NULL or EMPTY and actual is
			CompareValuesUtility.logFailed(sAattributeName, list1Expected, "null");
		}
		else
		{
			if(list1Expected.size() != list2Actual.size())
			{
				//size mismatch
				CompareValuesUtility.logFailed(sAattributeName, list1Expected, list2Actual);
			}

			//do comparision for availabale values irrespective of size 
			for (String xmlTopDescSingle : list1Expected) {

				if(list2Actual.contains(xmlTopDescSingle))
				{
					CompareValuesUtility.logPassed(sAattributeName, xmlTopDescSingle, xmlTopDescSingle,"");
				}
				else
				{
					CompareValuesUtility.logFailed(sAattributeName, xmlTopDescSingle, "NOT FOUND","");
				}
			}
		}
	}

	public static void compareTwoLists(String list1Expected[] ,List<String> list2Actual,String sAattributeName)
	{
		List<String> arraylist1Expected =  list1Expected==null?null:Arrays.asList(list1Expected);

		compareTwoLists(arraylist1Expected, list2Actual, sAattributeName);

		CompareValuesUtility.addNewMultiValuedFields();
	}

	public static Map<String, List<VarAttr>>  getattributesMapXml(com.generated.vos.productoffering.ProductAttributes productAttributes)
	{
		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		if(productAttributes!=null)
		{
			ProductAttribute[] allAttributes= productAttributes.getProductAttribute();

			for (ProductAttribute productAttribute : allAttributes) 
			{
				VarAttr varAttr = new VarAttr();

				varAttr.setId(productAttribute.getAttributeId()+"");
				varAttr.setTrademarkText(productAttribute.getTrademarkText());
				varAttr.setValueFlag(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueFlag());
				varAttr.setValueFree(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueFree());
				varAttr.setValueId(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueId()+"");


				List<VarAttr> innerList = output.get(productAttribute.getAttributeId()+"");

				if(innerList==null)
				{
					innerList = new ArrayList<VarAttr>();
				}
				innerList.add(varAttr);

				output.put(productAttribute.getAttributeId()+"", innerList);
			}
		}
		return output;
	}
	public static String readJsonFromFile(String sFileName)
	{
		String sFilePath = "src/test/resources/"+sFileName;

		StringBuffer sJson = new StringBuffer("");

		try{
			FileInputStream fstream = new FileInputStream(sFilePath);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)   {
				if(!strLine.isEmpty() && !strLine.startsWith("@") )
				{
					sJson.append(strLine);
				}
			}
			in.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}

		return sJson.toString();
	}

	public static Map<String, List<VarAttr>> getVarAttrMapXml(com.generated.vos.uvd.VariantAttributes varAttrs) 
	{
		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		com.generated.vos.uvd.VariantAttribute[] varAttrsList = varAttrs.getVariantAttribute();

		for (com.generated.vos.uvd.VariantAttribute variantAttribute : varAttrsList) 
		{
			String attrId = variantAttribute.getAttributeId()+"";

			VarAttr varAttr = new VarAttr();

			varAttr.setId(variantAttribute.getAttributeId()+"");
			varAttr.setTrademarkText(variantAttribute.getTrademarkText());
			varAttr.setValueFlag(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueFlag());
			varAttr.setValueFree(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueFree());
			varAttr.setValueId(variantAttribute.getVariantAttributeTypeChoice().getAttributeValueId()+"");


			List<VarAttr> innerList = output.get(attrId);

			if(innerList==null)
			{
				innerList=new ArrayList<VarAttr>();
			}

			innerList.add(varAttr);

			output.put(attrId, innerList);
		}

		return output;
	}

	public static Map<String, List<VarAttr>> getattributesMapXml(ProductAttributes productAttributes) 
	{
		Map<String, List<VarAttr>> output = new HashMap<String, List<VarAttr>>();

		if(productAttributes!=null)
		{
			com.generated.vos.uvd.ProductAttribute[] allAttributes= productAttributes.getProductAttribute();

			for (com.generated.vos.uvd.ProductAttribute productAttribute : allAttributes) 
			{
				VarAttr varAttr = new VarAttr();

				varAttr.setId(productAttribute.getAttributeId()+"");
				varAttr.setTrademarkText(productAttribute.getTrademarkText());
				varAttr.setValueFlag(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueFlag());
				varAttr.setValueFree(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueFree());
				varAttr.setValueId(productAttribute.getProductAttributeTypeChoice()==null?null:productAttribute.getProductAttributeTypeChoice().getAttributeValueId()+"");


				List<VarAttr> innerList = output.get(productAttribute.getAttributeId()+"");

				if(innerList==null)
				{
					innerList = new ArrayList<VarAttr>();
				}
				innerList.add(varAttr);

				output.put(productAttribute.getAttributeId()+"", innerList);
			}
		}
		return output;
	}

}
