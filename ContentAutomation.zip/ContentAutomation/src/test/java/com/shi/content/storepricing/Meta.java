
package com.shi.content.storepricing;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * lists the schema details
 * 
 */
@Generated("org.jsonschema2pojo")
public class Meta {

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Created Timestamp
     * (Required)
     * 
     */
    @Expose
    private String crts;
    /**
     * Indicates the user who lastly modified
     * 
     */
    @Expose
    private String lmdfy;
    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Modified Timestamp
     * 
     */
    @Expose
    private String mdts;
    /**
     * indicates json schema version
     * (Required)
     * 
     */
    @Expose
    private String sv;

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Created Timestamp
     * (Required)
     * 
     */
    public String getCrts() {
        return crts;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Created Timestamp
     * (Required)
     * 
     */
    public void setCrts(String crts) {
        this.crts = crts;
    }

    /**
     * Indicates the user who lastly modified
     * 
     */
    public String getLmdfy() {
        return lmdfy;
    }

    /**
     * Indicates the user who lastly modified
     * 
     */
    public void setLmdfy(String lmdfy) {
        this.lmdfy = lmdfy;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Modified Timestamp
     * 
     */
    public String getMdts() {
        return mdts;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). Modified Timestamp
     * 
     */
    public void setMdts(String mdts) {
        this.mdts = mdts;
    }

    /**
     * indicates json schema version
     * (Required)
     * 
     */
    public String getSv() {
        return sv;
    }

    /**
     * indicates json schema version
     * (Required)
     * 
     */
    public void setSv(String sv) {
        this.sv = sv;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
