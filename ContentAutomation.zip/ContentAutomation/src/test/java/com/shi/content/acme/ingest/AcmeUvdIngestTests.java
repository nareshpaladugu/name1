package com.shi.content.acme.ingest;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;
import com.generated.vos.uvd.AutomotiveProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class AcmeUvdIngestTests {
	
	public static boolean bVerifyNotNullSsinGuid;
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="AcmeUvdIngestTests")
	public void acmeUvdIngestTest(String sFileName) throws InterruptedException
	{
		
		String orgValue =System.getProperty("verifyNotNullSsinGuid","false"); 
		System.out.println(" ############# orgValue ..."+orgValue);
		
		bVerifyNotNullSsinGuid= Boolean.parseBoolean(System.getProperty("validateOnlySSINnGUID","false"));
		
		System.out.println("--------------------------------- bVerifyNotNullSsinGuid.... "+bVerifyNotNullSsinGuid);
		
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		String vendorId = sFileName.split("\\.")[0].split("-")[3];
		
		BlockingQueue<List<AutomotiveProductOffer>> uvdProductQueue = new LinkedBlockingQueue<List<AutomotiveProductOffer>>();
		
		ChunkProducerThread<AutomotiveProductOffer> prodThread = new ChunkProducerThread<AutomotiveProductOffer>(sFileName, uvdProductQueue, AutomotiveProductOffer.class,"automotive-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		while(true){
			try {
				List<AutomotiveProductOffer> nodeToTest = uvdProductQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){
					if(nodeToTest.get(0).getRelationType().equals("single")){
						pool.execute(new AcmeUvdIngestVerifications(
								nodeToTest.get(0).getProductContent(), 
								nodeToTest.get(0).getProductOfferings().getProductOffer(0), 
								vendorId, 
								nodeToTest.get(0).getProductOfferings().getProductOffer(0).getSpinUniqueId(),
								true,
								null,
								false)); //single
					}else{
						pool.execute(new AcmeUvdIngestVerifications(
								nodeToTest.get(0).getProductContent(), 
								nodeToTest.get(0).getProductOfferings().getProductOffer(0), 
								vendorId, 
								nodeToTest.get(0).getAutomotiveGroupId(),
								false,
								null,
								false));
						
						for(com.generated.vos.uvd.ProductOffer prodOffer : nodeToTest.get(0).getProductOfferings().getProductOffer()){
							pool.execute(new AcmeUvdIngestVerifications(
									nodeToTest.get(0).getProductContent(),
									prodOffer,
									vendorId,
									prodOffer.getSpinUniqueId(),
									false,
									nodeToTest.get(0).getAutomotiveGroupId(),
									true));
						}
					}		
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
