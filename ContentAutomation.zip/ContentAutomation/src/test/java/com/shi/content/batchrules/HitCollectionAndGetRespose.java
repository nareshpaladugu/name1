package com.shi.content.batchrules;

import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class HitCollectionAndGetRespose 
{
	/**
	 * @param sStoreName like sears/kmart etc
	 * @param collection like seller/shc_pricing etc
	 * @param sId id to hit(before transforming the same)
	 * @return json response
	 */

	public static String getResponse(String sStoreName, String collection, String sId)
	{
		//TODO case statements for collections
		//e.g. for seller we need id as "shc_"+sId

		//for pricing url formation is diff

		String sResponse=null;

		switch (collection.toLowerCase()) {

		case "seller":

			sId = "shc_"+sId;

			break;

		case "shc_pricing":

			String sStoreId = "";

			if(sId.length()>=8)
			{
				sId  = sId .substring(0, 8);
			}

			switch (sStoreName.toLowerCase()) 
			{
			case "sears":
				sStoreId="0009300";
				break;

			case "kmart":
				sStoreId="7840";
				break;

			case "puertorico":
				sStoreId="0009313";
				break;

			default:
				break;
			}

			sId = sStoreId+"-"+sId;

			break;

		default:
			break;
		}

		try {
			sResponse = RestExecutor.getJSonResponseById(collection.toLowerCase(),sId);
		} catch (Exception e) {
			e.printStackTrace();
			sResponse=null;
		}

		return sResponse;
	}
}
