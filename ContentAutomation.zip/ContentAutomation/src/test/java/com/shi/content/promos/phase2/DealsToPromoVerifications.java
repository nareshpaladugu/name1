package com.shi.content.promos.phase2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.generated.vos.promokafka.Promo;
import com.generated.vos.promokafka.PromoKafka;
import com.generated.vos.promokafka.Rule;
import com.generated.vos.promokafka.RuleDetail;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.BeanComparor;
import com.shc.autocontent.testcommons.TestUtils;

public class DealsToPromoVerifications implements Runnable {
	
	Promo kafkaPromo;
	
	
	public DealsToPromoVerifications(PromoKafka promoDetails){
	
		this.kafkaPromo = promoDetails.getPromo();
		
	}

	@Override
	public void run() {
		
		
		CompareValuesUtility.init();
		String id = kafkaPromo.getPromoId();
		System.out.println("Testing id "+ id);
		
		ResultSet rs = DBUtil.executeQueryReturnAll("select * from PROMO_DATA pd inner join promo_rule pr on pd.PROMO_ID = pr.PROMO_ID "+  
				"inner join promo_rule_details prd on  pr.PROMO_RULE_ID = prd.PROMO_RULE_ID "+ 
				"left outer join promo_attributes pa on prd.PROMO_RULEDT_ID = pa.PROMO_RULEDT_ID "+ 
				"left outer join promo_categories pc on prd.PROMO_RULEDT_ID = pc.PROMO_RULEDT_ID where pd.PROMO_ID = "+ id);
		
		if (rs == null){
			CompareValuesUtility.addDataFieldForReport("Id", "No data found in sql db", INFOTYPE.FAILED);
			CompareValuesUtility.setupResult(id, true);
		}
		try{
			rs.next();
			this.fetchFieldsAndVerify(rs);
			
			Map<String, Rule> allRules = PromoCommons.buildRuleObjects(rs);
			
			this.verifyAllRules(allRules);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.closeCursor(rs);
		}
		
		CompareValuesUtility.setupResult(id, true);
		
		
	}
	
	
	/**
	 * 
	 * @param allRules
	 */
	private void verifyAllRules(Map<String, Rule> allRules){
		
		List<Rule> rulesNotMatched = new ArrayList<Rule>();
		List<Rule> rulesNotMatchedToCompareAgainst = new ArrayList<Rule>();
		Set<Integer> ruleFoundIndexInKafka = new java.util.HashSet<Integer>();
		
		for(Rule dbRule : allRules.values()){
			
			boolean bFound = false;
			
			for (int i = 0; i < kafkaPromo.getRules().size(); i++) {
			
				Rule currentRule =  kafkaPromo.getRules().get(i);
//				System.out.println("Comparing...  Exp "+ dbRule + " Got "+ currentRule);
				
				
				try {
					if(BeanComparor.compareObjects(dbRule, currentRule) || (allRules.size() ==1)){
							bFound = true;
							//Rules validation
							compareRules(dbRule, currentRule);
							ruleFoundIndexInKafka.add(i);
							
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(!bFound){
				//Add to list of rules which are not matched, to do index based comparison of 
				//unmatched rules
				rulesNotMatched.add(dbRule);
			}
		}
		
		//Adding all rules from kafka message to list for index based comparison
		for (int i = 0; i < kafkaPromo.getRules().size(); i++) {
			if(ruleFoundIndexInKafka.contains(i))
				continue;
			rulesNotMatchedToCompareAgainst.add(kafkaPromo.getRules().get(i));
		}
		
		if(rulesNotMatched.size() > 0)
			findBestMatchFailureByIndex(rulesNotMatched, rulesNotMatchedToCompareAgainst);
		
	}
	
	/**
	 * Fall back method to try to find best match item.  Comparison is defaulted to index based method
	 * i.e. all rules not matched will be compared against Kafka rules which are not yet matched.
	 * @param rulesNotMatched
	 * @param rulesNotMatchedToCompareAgainst
	 */
	private void findBestMatchFailureByIndex(List<Rule> rulesNotMatched,List<Rule> rulesNotMatchedToCompareAgainst) {

		int iKafkaRuleCounter = 0;
		for(Rule dbRule : rulesNotMatched){
			try{
				compareRules(dbRule, rulesNotMatchedToCompareAgainst.get(iKafkaRuleCounter++));
			}catch(IndexOutOfBoundsException iExcp){
				CompareValuesUtility.logFailed("ItemType", dbRule, "Not found");
			}
		}

	}

	
	/**
	 * Method to compare kafka rule with rule generated from db details
	 * @param dbRule
	 * @param kafkaRule
	 */
	private void compareRules(Rule dbRule, Rule kafkaRule){
		
		CompareValuesUtility.compareValues("ItemType", dbRule.getItemType(), kafkaRule.getItemType());
		CompareValuesUtility.compareValues("ThrshldName", dbRule.getThresholdName(), kafkaRule.getThresholdName());
		CompareValuesUtility.compareValues("ThrshldCond", dbRule.getThresholdCondition(), kafkaRule.getThresholdCondition());
		CompareValuesUtility.compareValues("DiscAmount", dbRule.getDiscountAmount(), kafkaRule.getDiscountAmount());
		
		int iRDCounter = 0;
		//RuleDetails Validation
		for(RuleDetail dbRuleDetail : dbRule.getRuleDetails()){
			
			RuleDetail kafkaRuleDetail = kafkaRule.getRuleDetails().get(iRDCounter++);
			CompareValuesUtility.compareValues("RuleType", dbRuleDetail.getRuleType(), kafkaRuleDetail.getRuleType());
			CompareValuesUtility.compareValues("RuleName", dbRuleDetail.getRuleName(), kafkaRuleDetail.getRuleName());
			CompareValuesUtility.compareValues("Catalog", dbRuleDetail.getCatalog(), kafkaRuleDetail.getCatalog());
			CompareValuesUtility.compareValues("AttributeName", TestUtils.removeUnderscoreCharsAndToCamelCase(dbRuleDetail.getAttributeName()), kafkaRuleDetail.getAttributeName());
			CompareValuesUtility.compareValues("AttributeOper", dbRuleDetail.getAttributeOperator(), kafkaRuleDetail.getAttributeOperator());
			CompareValuesUtility.compareValues("AttributeVal", dbRuleDetail.getAttributeValue(), kafkaRuleDetail.getAttributeValue());
			CompareValuesUtility.compareValues("Category", dbRuleDetail.getCategoryName(), kafkaRuleDetail.getCategoryName());
		}
	}
	
	

	

	
	/**
	 * Read all field mappings of promo_data table from file and reflectively compare the kafka field with the column data fetched from sql
	 * @param rs - Result set to fetch sql data from
	 */
	@SuppressWarnings("unchecked")
	private void fetchFieldsAndVerify(ResultSet rs){

		Properties prop = new Properties();

		try {
			File propFile = new File("src/test/resources/PromoTestData/DealsDBToKafkaMapping");
			prop.load(new FileInputStream(propFile));
		} catch (IOException e) {
			e.printStackTrace();
		}

		try{

			for(Object key : prop.keySet()){
				String fieldToVerify = (String)key;

				String fieldValue = rs.getString(prop.getProperty(fieldToVerify));

				Field field = Promo.class.getDeclaredField(fieldToVerify);
				field.setAccessible(true);

				//					System.out.println("Verifying "+ fieldToVerify + " type "+ field.getType());

				Object value = 	field.get(kafkaPromo);
				String kafkaValue;
				if( value instanceof List){
					kafkaValue = ((List<String>) field.get(kafkaPromo)).toString();
					kafkaValue = kafkaValue.replaceFirst("\\[", "");
					kafkaValue = kafkaValue.replace("]", "");
				}else
					kafkaValue = (String) field.get(kafkaPromo);

				//					System.out.println("Verifying "+ fieldToVerify + " sql "+ fieldValue +" Kafka  " + kafkaValue);					
				CompareValuesUtility.verifyNullOrEqual(fieldToVerify, PromoCommons.convertDefaults(fieldValue), kafkaValue);

			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

	
	
}
