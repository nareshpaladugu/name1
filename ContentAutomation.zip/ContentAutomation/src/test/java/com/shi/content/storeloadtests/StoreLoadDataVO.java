package com.shi.content.storeloadtests;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.shc.autocontent.LoadProperties;

/**
 * @author skadam
 * 
 */
public class StoreLoadDataVO {
	String lineToProcess;
	Date cur_dt;
	DateFormat dateFormat;
	List<String> strExcepCloseStore;
	String storeId;
	boolean isLocalAd = false;

	public boolean isLocalAd() {
		return isLocalAd;
	}

	public void setLocalAd(String site, String strType1, String strType2) {
		if (site.equals("sears")) {
			if (strType1 == "001"
					&& (strType2 == "A" || strType2 == "B" || strType2 == "O"))
			{
				this.isLocalAd = true;
			    System.out.println("True");
			}
		} else if (site.equals("kmart")) {
			if (strType1 == "002" && (strType2 == "A")) {
				this.isLocalAd = true;
			}
		}
	}

	public void setStoreId(String storeID) {
		this.storeId = storeID;

	}

	public String getStoreId() {

		return this.storeId;

	}

	String strType1;

	public void setStrType1(String strType1) {

		this.strType1 = strType1;
	}

	public String getStrType1() {
		return this.strType1;
	}

	String countyNo;

	public void setCountyNo(String countyNo) {
		this.countyNo = countyNo;
	}

	public String getCountyNo() {
		return this.countyNo;
	}

	String geoCode;

	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}

	public String getGeoCode() {
		return geoCode;
	}

	String strType2;

	public void setStrType2(String strType2) {
		this.strType2 = strType2.trim();

	}

	public String getStrType2() {
		return this.strType2;

	}

	String Name;

	public void setName(String Name) {
		this.Name = Name;

	}

	public String getName() {
		return this.Name;

	}

	String Address;

	public void setAddress(String Address) {
		this.Address = Address;

	}

	public String getAddress() {
		return this.Address;
	}

	String City;

	public void setCity(String City) {
		this.City = City;

	}

	public String getCity() {
		return this.City;

	}

	String district;

	public void setDistrict(String district) {
		this.district = district;

	}

	public String getDistrict() {
		return this.district;
	}

	String Zipcode;

	public void setZipcode(String zipcode) {
		this.Zipcode = zipcode;
	}

	public String getZipcode() {
		return this.Zipcode;
	}

	String code;

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	String mgrName;

	public void setMgrName(String mgrName) {
		this.mgrName = mgrName;

	}

	public String getMgrName() {
		return this.mgrName;

	}

	String phoneNo;

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;

	}

	public String getPhoneNo() {
		return this.phoneNo;

	}

	String rgn;

	public void setRegion(String rgn) {
		this.rgn = rgn;
	}

	public String getRegion() {
		return this.rgn;
	}

	String startDate;

	public void setStartDate(String startDate) {
		try {
			this.startDate = getDateAsString(startDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getStartDate() {
		return this.startDate;

	}

	String endDate;

	public void setEndDate(String endDate) {
		try {
			this.endDate = getDateAsString(endDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getEndDate() {
		return this.endDate;

	}

	String lat;

	public void setLattitude(String lat) {
		this.lat = lat;

	}

	public String getLattitude() {
		return this.lat;

	}

	String longi;

	public void setLongitude(String longi) {
		this.longi = longi;

	}

	public String getLongitude() {
		return this.longi;

	}

	String storeAttr;

	public void setStoreAttr(String storeAttr) {
		this.storeAttr = storeAttr;

	}

	public String getStoreAttr() {
		return this.storeAttr;

	}

	String jsonSchema;

	public void setJsonSchema(String jsonSchema) {
		this.jsonSchema = jsonSchema;
	}

	public String getJsonSchema() {
		return jsonSchema;

	}

	String strStatus;

	public void setStrStatus() {
		DateFormat sts = new SimpleDateFormat("yyyy-MM-dd");
		cur_dt = new Date();
		strExcepCloseStore = getExcepCloseStore(LoadProperties.LST_FILES_FOLDER
				+ LoadProperties.LST_CONF_FILE); // ****LoadProperties.LST_FILES_FOLDER****

		try {
			if (sts.parse(this.startDate).before(this.cur_dt)
					&& sts.parse(this.endDate).after(this.cur_dt)
					&& !(strExcepCloseStore.contains(this.storeId))) {
				this.strStatus = "1";

			} else {

				this.strStatus = "0";
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getStrStatus() {
		return this.strStatus;
	}

	String dist_no;

	public void setDistNo(String dist_no) {
		this.dist_no = dist_no;

	}

	public String getDistNo() {
		return this.dist_no;
	}

	public String getDateAsString(String endDate1) throws ParseException {

		Date temp;
		String strDate;
		dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		temp = dateFormat.parse(endDate1);

		strDate = dateFormat.format(temp);
		return strDate;

	}

	// To read property File and get Array of Closed Store
	public List<String> getExcepCloseStore(String fileName) {
		int intStart;
		int intLast;
		String[] strItems = null;
		List<String> excepCloseStore;

		excepCloseStore = new ArrayList<String>();
		BufferedReader br;
		FileReader fr;
		try {
			fr = new FileReader(fileName);
			br = new BufferedReader(fr);
			String strInput;
			while ((br.readLine()) != null) {
				strInput = br.readLine();
				if (strInput.contains("excep_close_store")) {
					intStart = strInput.indexOf("=") + 1;
					intLast = strInput.length();
					strItems = strInput.substring(intStart, intLast).split(",");
				}
			}

			for (String strEach : strItems)
				excepCloseStore.add(strEach);

			br.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return excepCloseStore;
	}
}
