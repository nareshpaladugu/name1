package com.shi.content.northstar.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.support.ui.Select;

import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.SelectList;
import com.shc.content.webdriver.html.TextField;

public class StoreReportPage extends BasePage{

    	
	public StoreReportPage(String pageName) {
		super(pageName);
	}
	Button btnSearch = new Button("frm-report-search:btn-search-report", "Search");
	Button btnClear= new Button("frm-report-search:btn-reset", "Clear");
	SelectList reportType = new SelectList("frm-report-search:sel-reporttype_input", "Report Type");
	SelectList condition = new SelectList("frm-report-search:sel-reporttype_input", "Value");
	List<String>  allReportTypes = new ArrayList<String>();
	/*List <WebElement> elementCount = oSelect.getOptions();
	public static void StoreReports(){
	
		
		int iSize = elementCount.size();
	 
		for(int i =0; i>iSize ; i++){
			String sValue = elementCount.get(i).getText();
			System.out.println(sValue);
			}
			}
		*/
	    public static void getAllElements(){
	     //fetch the optionlist and store it in List of string and iterate through them one by one 
	    	
	    	
	     
	    }
	

	 

}
