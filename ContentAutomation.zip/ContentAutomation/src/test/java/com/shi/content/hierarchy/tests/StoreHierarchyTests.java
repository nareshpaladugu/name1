package com.shi.content.hierarchy.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.storehierarchy.Level1;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class StoreHierarchyTests {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="StoreHierarchyTests")
	public void testStoreHierarchyFeed(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		String sSiteId = sFileName.split("\\.")[0].split("-")[2];
		System.out.println("Site id "+ sSiteId);
		
		/*Figure out store SRWI or KWSC*/
		String storeAppender;
		if (sSiteId.equals("1"))
			storeAppender = "KWSC";
		else if (sSiteId.equals("2"))
			storeAppender = "SRWI";
		else
			storeAppender = "null";
		
		BlockingQueue<List<Level1>> storeHierarchyQueue = new LinkedBlockingQueue<List<Level1>>(); 
		
		HierarchyCommons hierarchyUtils = new HierarchyCommons(sFileName, HierarchyCommons.figureOutCatalogId(sSiteId + "_STORE"));
		ChunkProducerThread<Level1> prodThread = new ChunkProducerThread<Level1>(sFileName, storeHierarchyQueue, Level1.class);
		prodThread.setBucketSize(1);
//		prodThread.setCutOffNode("link-nodes");
//		prodThread.run();
		Thread t = new Thread(prodThread);
		t.start();
		
		//final ExecutorService pool = Executors.newFixedThreadPool(20);
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		while(true){
			try {
				List<Level1> levelToTest = storeHierarchyQueue.poll(20, TimeUnit.SECONDS);
				if(levelToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + levelToTest);
					break;
				}
				if(levelToTest != null)
					//pool.execute(new StoreHierarchyVerifications(storeHierarchyQueue.poll(10, TimeUnit.SECONDS),hierarchyUtils, storeAppender, sSiteId));
					pool.execute(new StoreHierarchyVerifications(levelToTest, hierarchyUtils, storeAppender, sSiteId));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();
		try {
			pool.awaitTermination(30, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
