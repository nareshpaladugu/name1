package com.shi.content.storepricing;

import java.util.ArrayList;
import java.util.List;

import com.shc.autocontent.parsers.FileParser;

public class KmartDoorBusterFileParser implements FileParser<String>{

	List<String> lstOutput;
	String storeId, partNumber;
	int storeidIndex = 0;
	int partNumberIndex = 1;


	/**
	 * Parse each line to check with previous line data
	 * Add to list if part of same group else 
	 * create new list and return the last one
	 */
	public List<String> parseLine(String line) {
		String[] values = line.split("\\|");
			//If store matches, check partnumber match
		if (storeId == null) {
			addToNewOutput(line);
			return null;
		}

			if (values[partNumberIndex].equals(partNumber)) {
				lstOutput.add(line);
				return null;
			}
			else {
				return prepareOutput(line);
			}
		
		

	}
	
	/**
	 * Prepares the output and returns a chunk of output
	 * @param line
	 * @return
	 */
	private List<String> prepareOutput(String line){
		
		//Save the old one in new list
		List<String> lstToSend = new ArrayList<String>(lstOutput);
		
		//Add current line to new output list
		addToNewOutput(line);
		
		return lstToSend;
	}
	
	
	/**
	 * Create a new list with current line.  
	 * Adds store number and partnumber for next line checks
	 * @param line
	 */
	private void addToNewOutput(String line){
		
		String[] values = line.split("\\|");
		
		lstOutput = new ArrayList<String>();
		lstOutput.add(line);
		storeId = values[storeidIndex];
		partNumber = values[partNumberIndex];
	}
	
	public List<String> getCurrentOutput(){
		return lstOutput;
	}

}
