package com.shi.content.northstar.tests;


import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * Test Regular hours are updating for Single Store
 * 
 * @author inaikwa
 *
 */
public class RegularHours_SingleStoreTest extends NorthStarBaseTest {
	private ArrayList<String> listStoreIds;
	private String storeId;
	private String SundayOpenTime;
	
	@Test(description="Test to verify if the UnitRegHour are updating ", groups = {"NS-P1"})
	public void testUpdateHours() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();

//		searchPage.searchByZipCode("07052");
//		
//		listStoreIds= searchPage.getAllSearsOpenNonICEEStores();
		
//		Kmart
		searchPage.searchByZipCode("02886");
		listStoreIds = searchPage.getAllSearsOpenNonICEEStores();
		
		Assert.assertNotNull(listStoreIds ," Zero stores found, terminating......... ");
		
		storeId =listStoreIds.get(0);
		
		searchPage.clickStore(storeId);
		
		EditStoreDetails eView = new EditStoreDetails();
		
		eView.goToRegHoursView();
		
		SundayOpenTime=eView.updateHours_Single();
		
		eView.saveDocument();
		
		Asserts.verifyTrue(eView.updateSuccessMsg(), "Verified that the Update success msg is displayed after updating Sunday Open Time" );
		
		String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 

		String sSundayOpenTime = "0"+Integer.toString(Integer.parseInt(JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strHrs.sun.opn").replaceAll("\"", ""))/3600);
		
		Asserts.verifyEquals(SundayOpenTime,sSundayOpenTime,"Verified that the store time is updated");
		
	}
	
}
