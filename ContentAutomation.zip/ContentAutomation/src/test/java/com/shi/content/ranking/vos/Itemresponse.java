package com.shi.content.ranking.vos;

public class Itemresponse {
	private float sywrmemberprice;
	private float regularprice;
	private float nddprice;
	private float promoprice;
	private Sellprice sellprice;
	private Mapdetails mapdetails;
	private Meta meta;
  
		
	

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}

	public float getNddprice() {
		return nddprice;
	}

	public void setNddprice(float nddprice) {
		this.nddprice = nddprice;
	}

	public float getPromoprice() {
		return promoprice;
	}

	public void setPromoprice(float promoprice) {
		this.promoprice = promoprice;
	}

	public float getRegularprice() {
		return regularprice;
	}

	public void setRegularprice(float regularprice) {
		this.regularprice = regularprice;
	}

	public float getSywrmemberprice() {
		return sywrmemberprice;
	}

	public void setSywrmemberprice(float sywrmemberprice) {
		this.sywrmemberprice = sywrmemberprice;
	}

	public Sellprice getSellprice() {
		return sellprice;
	}

	public void setSellprice(Sellprice sellprice) {
		this.sellprice = sellprice;
	}

	public Mapdetails getMapdetails() {
		return mapdetails;
	}

	public void setMapdetails(Mapdetails mapdetails) {
		this.mapdetails = mapdetails;
	}
	

}
