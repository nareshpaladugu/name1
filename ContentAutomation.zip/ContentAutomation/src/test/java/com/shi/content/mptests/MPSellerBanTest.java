package com.shi.content.mptests;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class MPSellerBanTest implements Runnable {

	static Map<String, Long> idToTS = new HashMap<String, Long>();
	static boolean bFileFound = false;
	private List<String> mpSBanMessages;
	// private static final String FILENAME =
	// "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+".txt";

	// private static final String PROCESSED_FILENAME =
	// "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+"_Processed.txt";

	private String itemId;

	public MPSellerBanTest() {
	}

	public MPSellerBanTest(String itemId) {

		this.itemId = itemId;
	}

	/**
	 * Return list of item ids from text file
	 * 
	 * @return
	 */
	private List<String> getItemIdsFromTextFile() {
		List<String> itemsFromTextFile = new ArrayList<String>();

		String sFilePath = LoadProperties.LST_FILES_FOLDER
				+ LoadProperties.LST_FILES;

		System.out.println("sFilePath .." + sFilePath);

		try {
			FileInputStream fstream = new FileInputStream(sFilePath);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null) {
				itemsFromTextFile.add(strLine.trim());
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		return itemsFromTextFile;
	}

	@Test(description = "Test MP SellerBan messages", groups = "MPSellerBanVerifs")
	public void MPSellerBanTests() {

		final ExecutorService pool = Executors
				.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if (LoadProperties.EXECUTION_MODE.equalsIgnoreCase("TEXT")) {
			List<String> itemsFromTextFile = getItemIdsFromTextFile();
			for (String string : itemsFromTextFile) {
				pool.execute(new MPSellerBanTest(string));
			}
		} else {
			BlockingQueue<List<String>> mpIBanDocs = new LinkedBlockingQueue<List<String>>();

			KafkaIAConsumer<String> mpIBanConsumerThread = new KafkaIAConsumer<String>(
					mpIBanDocs);
			Thread tConsumerThread = new Thread(mpIBanConsumerThread);
			tConsumerThread.start();

			try {
				while (true) {
					List<String> nodeToTest;

					nodeToTest = mpIBanDocs.poll(50, TimeUnit.SECONDS);

					if (nodeToTest == mpIBanConsumerThread.POISON_PILL) {
						System.out.println("Got poison pill ..breaking out");
						break;
					}
					if (nodeToTest != null) {
						pool.execute(new MPSellerBanTest(nodeToTest));
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			pool.shutdown();

			try {
				pool.awaitTermination(240, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				System.out.println("pool.awaitTermination - Exception");
			}

			
		}

	}

	private List checkSellerItem(String id) {
		CompareValuesUtility.init();
		List ids = null;
		Offer offerDoc = RestExecutor
				.getDataById(CollectionValuesVal.OFFER, id);
		if (offerDoc == null) {
			CompareValuesUtility.logPassed("ItemId", id, "Offer NOT found");
		} else {
			CompareValuesUtility.logFailed("ItemId", id, "Offer found");
		}

		return ids;
	}

	private void checkSingleItem(String id) {
		CompareValuesUtility.init();

		Offer offerDoc = RestExecutor
				.getDataById(CollectionValuesVal.OFFER, id);
		if (offerDoc == null) {
			CompareValuesUtility.logPassed("ItemId", id, "Offer NOT found");
		} else {
			CompareValuesUtility.logFailed("ItemId", id, "Offer found");
		}

		CompareValuesUtility.setupResult(id, true);
	}

	public MPSellerBanTest(List<String> ids) {
		mpSBanMessages = ids;
	}

	@Override
	public void run() {


		final ExecutorService pool2 = Executors
				.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		if (LoadProperties.EXECUTION_MODE.equalsIgnoreCase("TEXT")) {
			System.out.println("testing ... " + this.itemId);
			checkSingleItem(this.itemId);
		} else {
			for (String mpIBanMessage : this.mpSBanMessages) {
				try {
					String seller_id = JsonStringParser.getJsonValueNew(
							mpIBanMessage, "sellerBan.sellerId");
					String type = JsonStringParser.getJsonValueNew(
							mpIBanMessage, "sellerBan.prgm");
					// http://greenvip.qa.ch3.s.com:8080/gbox/gb/s/data/filter-ids/offer/1107?sellerId=23061
					for (int bucketCounter = 0; bucketCounter <= 4095; bucketCounter++) 
					{
						pool2.execute(new MPSellerBanVerifications(bucketCounter, seller_id));
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Check this message " + mpIBanMessage);
				}
			}
			
			pool2.shutdown();

			try {
				pool2.awaitTermination(240, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				System.out.println("pool.awaitTermination - Exception");
			}

		}
	}

	/**
	 * Formats unix timestamp in specified {@code dateFormat}
	 * 
	 * @param unixTS
	 *            - Timestamp
	 * @param dateFormat
	 *            - Format to convert to
	 * @return Converted date
	 */
	public static String getDate(long unixTS, String dateFormat) {

		// Create a DateFormatter object for displaying date in specified
		// format.
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));

		// Create a calendar object that will convert the date and time value in
		// milliseconds to date.
		Calendar calendar = Calendar.getInstance(TimeZone
				.getTimeZone("US/Central"));
		calendar.setTimeInMillis(unixTS);
		return formatter.format(calendar.getTime());
	}

}
