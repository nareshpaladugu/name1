package com.shi.content.hierarchy.tests;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logPassed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyInListField;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNotNull;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.List;

import com.generated.vos.hierarchy.Attr;
import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.hierarchy.ParentId;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.hierarchy.Tag;
import com.generated.xmls.masterhierarchy.Attribute;
import com.generated.xmls.masterhierarchy.Label;
import com.generated.xmls.masterhierarchy.Node;
import com.generated.xmls.masterhierarchy.TagSet;
import com.generated.xmls.masterhierarchy.types.TypeType;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;

public class MasterHierarchyVerifications implements Runnable{
	
	List<Node> wNodeList;
	String sFileName;
	HierarchyCommons hierarchyUtils;
	boolean isLeaf;
	int iLevelToverify = 1;
	String sCID;
	
	
	public MasterHierarchyVerifications(List<Node> wNodeListToTest, HierarchyCommons commonUtils){
		this.wNodeList = wNodeListToTest;
		this.hierarchyUtils = commonUtils;
	}
	
	@Override
	public void run() {

		//For each node fetch from hierarchy collection
		for(Node n : wNodeList){
			CompareValuesUtility.init();
			try{
				if(n.getId() == 0)
					continue;
				
				APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, String.valueOf(n.getId()));
				Hierarchy gbHierarchy = allResponse.getT();
				
				//No record found in gb for id
				if(gbHierarchy == null){
					CompareValuesUtility.logFailed("Id", n.getId(), "Not found");
					CompareValuesUtility.setupResult(String.valueOf(n.getId()), true);
					continue;
				}
				
				compareMasterNode(gbHierarchy, n);
				verifyFt(allResponse);
				verifySearch(allResponse);
				CompareValuesUtility.setupResult(String.valueOf(n.getId()), true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ n.getId());
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}	
	}
	
	private void verifySearch(APIResponse<Hierarchy> allResponse) {
		CompareValuesUtility.addNewMultiValuedFields();
		//compareValues("_search.cid", sCID, allResponse.getSearchFieldValue("cid")); //WCS Migration
		verifyNotNull("_search.cid", allResponse.getSearchFieldValue("cid"));
	}

	/*public void printNodeVals(Node masterHierarchyNode){
		System.out.println("Id:"+masterHierarchyNode.getId()+" Name: "+ masterHierarchyNode.getName()+" ParentNode: "+ masterHierarchyNode.getParentNodeId());
	}*/
	public void compareMasterNode(Hierarchy gbHierarchy, Node masterHierarchyNode){
		//Id
		compareValues("Id", masterHierarchyNode.getId(),gbHierarchy.getId());
		sCID = hierarchyUtils.fetchCatGroupId(masterHierarchyNode.getId());
		//compareValues("CId", sCID,gbHierarchy.getCid()); //WCS Migration
		verifyNotNull("CId", gbHierarchy.getCid());
		compareValues("Name", masterHierarchyNode.getName(), gbHierarchy.getName());
		compareValues("Type", "master", gbHierarchy.getType());
		
		isLeaf = hierarchyUtils.isLeafNode(masterHierarchyNode.getId(),true);
		compareValues("isLeaf",isLeaf, gbHierarchy.getIsLeaf());
		
		//Verify parent id in xml node is part of parent ids array
		int j = verifyInListField("ParentId", String.valueOf(masterHierarchyNode.getParentNodeId()), gbHierarchy.getParentIds(),"id", ParentId.class);
		if(j!= -1)
			compareValues("PrimaryParent?", true, gbHierarchy.getParentIds().get(j).getIsPrimary());
		
		int i = verifyInListField("DisplayPath", masterHierarchyNode.getDisplayPath(), gbHierarchy.getPath(),"displayPath",Path.class);

		if(masterHierarchyNode.getParentNodeId() == 0){
				//compareValues("CIDPath", sCID, (i!= -1)?gbHierarchy.getPath().get(i).getCidPath():"Not found"); //WCS Migration
				verifyNotNull("CIDPath", (i!= -1)?gbHierarchy.getPath().get(i).getCidPath():null);
				compareValues("IdPath", masterHierarchyNode.getId(), (i!= -1)?gbHierarchy.getPath().get(i).getIdPath():"Not found");
				
		}else{
				String sExpIDPath = hierarchyUtils.formPrimaryIdPath(masterHierarchyNode.getId(), true);//formIdPath(masterHierarchyNode.getId());
				iLevelToverify = sExpIDPath.split("\\"+HierarchyCommons.SEPARATOR).length;
				
				//compareValues("CIDPath", hierarchyUtils.fetchPrimaryCIDPath(masterHierarchyNode.getId()), (i!= -1)?gbHierarchy.getPath().get(i).getCidPath():"Not found"); //WCS Migration
				verifyNotNull("CIDPath", (i!= -1)?gbHierarchy.getPath().get(i).getCidPath():null);
				compareValues("IdPath", sExpIDPath, (i!= -1)?gbHierarchy.getPath().get(i).getIdPath():"Not found");
		}
		compareValues("IsPrimaryPath", true, (i!= -1)?gbHierarchy.getPath().get(i).getIsPrimary():"Not found");
		compareValues("Level", String.valueOf(iLevelToverify), (i!= -1)?gbHierarchy.getLevel():"Not found");

		if(!(masterHierarchyNode.getLabel().length == 0)){
			verifyLabels(masterHierarchyNode.getLabel(), gbHierarchy.getAttrs().getLabels());
		}else{
			CompareValuesUtility.addToHeaders(new String[]{"No of Labels","LabelName","LabelRank"});
		}
		
		if(masterHierarchyNode.getTags() == null ||masterHierarchyNode.getTags().getTagSet().length == 0){
			CompareValuesUtility.addToHeaders(new String[]{"No. of Tags","TagType","TagName"});
		}else{
			CompareValuesUtility.addNewMultiValuedFields();
			verifyTags(masterHierarchyNode.getTags().getTagSet(), gbHierarchy.getAttrs().getTags());
		}
		
	}
	
	public void verifyFt(APIResponse<Hierarchy> fullResponse){
		CompareValuesUtility.addNewMultiValuedFields();
		compareValues("_ft.leaf", isLeaf, fullResponse.getFtFieldValue("leaf"));
		compareValues("_ft.level", iLevelToverify, fullResponse.getFtFieldValue("level"));
	}
	
	public void verifyLabels(Label[] xmlLabels, List<com.generated.vos.hierarchy.Label> gbLabels){
		
		compareValues("No of Labels", xmlLabels.length, gbLabels.size());
		for(int i=0; i< xmlLabels.length; i++){
			Label l = xmlLabels[i];
			boolean bLabelFound = false;
			for(int j = 0; j< gbLabels.size(); j++){
				com.generated.vos.hierarchy.Label currentgbLabel= gbLabels.get(j);
				if(l.getName()!= null){
					if(l.getName().equals(currentgbLabel.getName())){
						logPassed("LabelName", l.getName(), currentgbLabel.getName());
						verifyNullOrEqual("LabelRank", (l.getRank()==0||l.getRank()==null)?null:l.getRank(), GenericUtil.convertToString(currentgbLabel.getRank()));
						verifyLabelAttributes(l.getAttribute(), currentgbLabel.getAttrs(), l.getName());
						bLabelFound = true;
						break;
					}
				}
				else{
					for(int attrCount = 0; attrCount < currentgbLabel.getAttrs().size(); attrCount++){
						if(l.getAttribute()[0].getId().toString().equals(currentgbLabel.getAttrs().get(attrCount).getId())){
							bLabelFound = true;
							String xmlLabelRank = GenericUtil.convertToString(l.getRank());
							logPassed("LabelName", "null", "null");
							verifyNullOrEqual("LabelRank", (xmlLabelRank==null||xmlLabelRank.equals(0))?null:xmlLabelRank, GenericUtil.convertToString(currentgbLabel.getRank()));
							verifyLabelAttributes(l.getAttribute(), currentgbLabel.getAttrs(), l.getName());
							break;
						}
						//If label was found then break out and go to next label
						if(bLabelFound)
							break;
					}
				}
				//if last label in gb found and label is still not found then mark as failed
				if(j == gbLabels.size() -1 && bLabelFound == false){
					logFailed("LabelName", (l.getName() != null? l.getName(): "Label at position "+ (i+1)), "Not found");
				}
			}
		}
	}
		
	public void verifyLabelAttributes(Attribute[] attributes, List<Attr> gbLabelAttrList, String label){
		compareValues("LabelAttributeCount", attributes.length, gbLabelAttrList.size());
		for(int i = 0; i < attributes.length ; i++){
			for(int j=0; j < gbLabelAttrList.size(); j++){
				if(attributes[i].getId().toString().equals(gbLabelAttrList.get(j).getId())){
					compareValues("AttrId", attributes[i].getId(), gbLabelAttrList.get(j).getId());
					compareValues("AttrRank", attributes[i].getRank(), GenericUtil.convertToString(gbLabelAttrList.get(j).getRank()));
					compareValues("AttrReqFlag", attributes[i].getRequiredFlag(), gbLabelAttrList.get(j).getRequiredFlag());
					for(TypeType t : attributes[i].getType())
						CompareValuesUtility.verifyTrue(gbLabelAttrList.get(j).getType().contains((t.toString()=="LABEL" && label==null)?"donotdisplay":t.toString().toLowerCase()), "AttrType", (t.toString()=="LABEL" && label==null)?"donotdisplay":t.toString().toLowerCase(), gbLabelAttrList.get(j).getType());
					break;
				}
			}
		}
	}

	
	public void verifyTags(TagSet[] xmlTags, List<Tag> gbTags){
		compareValues("No. of Tags", xmlTags.length, gbTags.size());
		
		for(TagSet xmlTSet: xmlTags){
			int i = verifyInListField("TagType", xmlTSet.getNamespace(), gbTags, "type", Tag.class);
			if(i != -1){
				for(String s : xmlTSet.getTag()){
					if(gbTags.get(i).getName().contains(s))
						logPassed("TagName", s, s);
					else
						logFailed("TagName", s, "Found : "+gbTags.get(i).getName());
				}
			}
		}
		
		/*for(int i=0; i< xmlTags.length; i++){
			TagSet tSet = xmlTags[i];
			for(int j=0; j<gbTags.size(); j++){
				if(tSet.getNamespace() == gbTags.get(j).getType()){
					compareValues("TagNamespace", tSet.getNamespace(), gbTags.get(j).getType());
					compareValues("TagValue", tSet.getTag()[0], gbTags.get(j).getName());
					//go to next tag
					break;
				}
				if(j == gbTags.size() - 1){
					logFailed("Tag", tSet.getNamespace(), "Not found");
				}
			}
		}*/
		
	}
	
	
	
}
 
