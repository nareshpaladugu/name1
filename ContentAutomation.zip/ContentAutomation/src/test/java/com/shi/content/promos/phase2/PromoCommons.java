package com.shi.content.promos.phase2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.promokafka.Rule;
import com.generated.vos.promokafka.RuleDetail;

public class PromoCommons {


	public static String convertDefaults(String value){

		if(value == null)
			return null;
		switch(value){
		case "Dollar Off":
			return "PMD_DOLLAR_OFF";
		case "BMGMSYWRPoints":
			return "SYWRPOINTS";
		case "Fixed Price":
			return "PMD_FIXED_PRICE";
		case "Percent Off":
			return "PMD_PERCENT_OFF";

		
		}

		return value;
	}
	
	
	/**
	 * Utility method to build Rule objects based on data in mysql db
	 * @param rs
	 * @return
	 */
	static Map<String,Rule> buildRuleObjects(ResultSet rs){
		Map<String, Rule> ruleIdToRuleObjects = new HashMap<String, Rule>();
		Map<String, RuleDetail> ruleDetailIds =  new HashMap<String, RuleDetail>();
		List<String> attributeIds =  new ArrayList<String>();
		List<String> categoryIds =  new ArrayList<String>();
		try{
			do{

				String ruleId = rs.getString("PROMO_RULE_ID");
				Rule ruleToWorkOn;
				//Gather rule data
				if(!ruleIdToRuleObjects.keySet().contains(ruleId)){
					Rule rule = new Rule();
					rule.setItemType( rs.getString("ITEM_TYPE"));
					rule.setThresholdName(rs.getString("THRESHOLD_NAME"));
					String threshold_cond = rs.getString("THRESHOLD_CONDITION");
					String	threshold_amount=rs.getString("DISCOUNT_AMOUNT");

					if(threshold_cond == null)
						rule.setThresholdCondition(null);
					else
						rule.setThresholdCondition(Arrays.asList(threshold_cond.split(",")));

					if(threshold_amount == null)
						rule.setDiscountAmount(null);
					else
						rule.setDiscountAmount(Arrays.asList(threshold_amount.split(",")));

					ruleIdToRuleObjects.put(ruleId, rule);
					ruleToWorkOn = rule;
				}else{
					ruleToWorkOn = ruleIdToRuleObjects.get(ruleId);
				}

				//Get Rule details
				String ruleDetId = rs.getString("PROMO_RULEDT_ID");
				RuleDetail ruleDetailToWorkOn;
				if(!ruleDetailIds.keySet().contains(ruleDetId)){

					//new ruledetail
					RuleDetail currentRuleDetail = new RuleDetail(); 

					currentRuleDetail.setRuleName(rs.getString("RULE_NAME"));
					currentRuleDetail.setRuleType(rs.getString("RULE_TYPE"));
					currentRuleDetail.setCatalog(rs.getString("CATALOG"));
					ruleDetailToWorkOn = currentRuleDetail;
					ruleDetailIds.put(ruleDetId, ruleDetailToWorkOn);

					//Add to ruleDetail of current rule
					List<RuleDetail> existingRuleDetails = ruleToWorkOn.getRuleDetails();
					existingRuleDetails.add(ruleDetailToWorkOn);
					ruleToWorkOn.setRuleDetails(existingRuleDetails);


				}else{
					ruleDetailToWorkOn = ruleDetailIds.get(ruleDetId);
				}

				String attributeId = rs.getString("ATTRIBUTE_ID");

				if(attributeId!= null && !attributeIds.contains(attributeId)){

					attributeIds.add(attributeId);

					List<String> attributesAdded = ruleDetailToWorkOn.getAttributeName();
					attributesAdded.add(rs.getString("ATTRIBUTE_NAME"));
					List<String> attribOperators = ruleDetailToWorkOn.getAttributeOperator();
					attribOperators.add(rs.getString("ATTRIBUTE_OPERATOR"));
					List<String> attribValues = ruleDetailToWorkOn.getAttributeValue();
					attribValues.add(rs.getString("ATTRIBUTE_VALUE"));

					ruleDetailToWorkOn.setAttributeName(attributesAdded);
					ruleDetailToWorkOn.setAttributeOperator(attribOperators);
					ruleDetailToWorkOn.setAttributeValue(attribValues);

				}

				String categoryId = rs.getString("CATEGORY_ID");

				if(categoryId!= null && !categoryIds.contains(categoryId)){
					List<String> categoriesAdded = ruleDetailToWorkOn.getCategoryName();
					categoriesAdded.add(rs.getString("CATEGORY_NAME"));
					ruleDetailToWorkOn.setCategoryName(categoriesAdded);

				}

			}while(rs.next());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ruleIdToRuleObjects;
	}
}