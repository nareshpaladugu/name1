package com.shi.content.featureperftests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

public class TestPageSizesDegradation {

	@DataProvider(name="dp", parallel=true)
	public Object[][] dp(){
		Object[][] toSend = new Object[3000][];
		for(int i=0; i<3000; i++){
			toSend[i] = new Object[]{i,150};
			
		}
		return toSend;
	}
	
	@DataProvider(name="dp500", parallel=true)
	public Object[][] dp500(){
		System.out.println("In dp500");
		Object[][] toSend = new Object[900][];
		for(int i=0; i<900; i++){
			toSend[i] = new Object[]{i,500};
			
		}
		return toSend;
	}
	
	
	//To run with dp tc 15
	@Test(dataProvider="dp", groups="PgSize150")
	public void testPS150(Integer pageNumber, Integer pageSize){
		
		long l1= System.currentTimeMillis();
		
		String sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source?page-size="+pageSize+"&page="+pageNumber;
		String sSubUrl = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
			sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source"+sSubUrl+"&page-size="+pageSize+"&page="+pageNumber;
			
			System.out.println("sUrl.... "+sUrl);

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);
			long l4 = System.currentTimeMillis();
			System.out.println("Thread data ids fetch completed "+ Thread.currentThread().getId()+ " "+ (l4-l1) + " ms");
		
	}
	
	
	
	
	//To run with dp tc 500
	@Test(dataProvider="dp", groups="PgSize1")
	public void testPS1(Integer pageNumber, Integer pageSize){
		
		long l1= System.currentTimeMillis();
		int init = pageNumber*pageSize;
		int end = ((pageNumber+1)*pageSize)-1;
		String sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source?page-size=1&page="+pageNumber;
		String sSubUrl = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
		
		for(int startIndex = init; startIndex <= end; startIndex++ ){
			sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source"+sSubUrl+"&page-size=1&page="+startIndex;
			System.out.println("sUrl.... "+sUrl);

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);
			long l4 = System.currentTimeMillis();
			System.out.println("Single data fetch "+ Thread.currentThread().getId()+ " "+ (l4-l1) + " ms");
		}
		
		long l2 = System.currentTimeMillis();
		
		System.out.println("All ids fetched"+ (l2-l1)+ " ms");
	}
	
	//To run with dp tc 15
		@Test(dataProvider="dp500", groups="PgSize500")
		public void testPS500(Integer pageNumber, Integer pageSize){
			
			long l1= System.currentTimeMillis();
			
			String sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source?page-size=500&page="+pageNumber;
			String sSubUrl = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
				sUrl = "http://"+LoadProperties.IA_SERVER+"/iaserver/source"+sSubUrl+"&page-size="+pageSize+"&page="+pageNumber;
				
//				System.out.println("sUrl.... "+sUrl);

				RestExecutor.getJSonResponse(sUrl);
				long l4 = System.currentTimeMillis();
				System.out.println("Thread data ids fetch completed "+ Thread.currentThread().getId()+ " "+ (l4-l1) + " ms");
				sleep();
			
		}
		
		private void sleep(){
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
