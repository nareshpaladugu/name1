package com.shi.content.storeLocalAd;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.storelocalad.Media;
import com.generated.xmls.storelocalad.Page;
import com.generated.xmls.storelocalad.Variant;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;

public class StoreLocaladTest
{
	static String searsExcludeStores = System.getProperty("searsExcludeStores", "");
	static String kmartExcludeStores = System.getProperty("kmartExcludeStores", "");
	static Boolean ignorePageImage = Boolean.parseBoolean(System.getProperty("ignorePageImage", ""));

	@Test(dataProviderClass = FileProviderClass.class, dataProvider = "fileProvider", groups = "StoreLocaladTest")
	public void testStoreLocalAd(String sFileName) throws InterruptedException
	{
		// Create a blocking queue per thread
		System.out.println("Testing sFileName : " + sFileName);
		BlockingQueue<List<Media>> localAdQueue = new LinkedBlockingQueue<List<Media>>();

		// Create producer thread
		ChunkProducerThread<Media> prodThread = new ChunkProducerThread<Media>(sFileName, localAdQueue, Media.class);
		prodThread.setBucketSize(10);
		Thread t = new Thread(prodThread);
		t.start();

		// Create consumer threads. Each thread does validation for attribute and attribute value
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		while (true)
			try
			{
				List<Media> lstXmlMedia = localAdQueue.poll(20, TimeUnit.SECONDS);

				if (lstXmlMedia == prodThread.POISON_PILL)
				{
					System.out.println("Got poison pill ..breaking out" + lstXmlMedia);
					break;

				}

				if (lstXmlMedia != null)
					for (Media xmlMedia : lstXmlMedia)
						try
						{

							String activityId = xmlMedia.getImport_name();
							String mediaType = xmlMedia.getMedia_type().toLowerCase();
							String activityName = xmlMedia.getName();
							String startDate = xmlMedia.getValid_from();
							String endDate = xmlMedia.getValid_to();
							
							// Map of Variant as a key and list of stores as value
							Map<String,List<String>> mapVariantIdStoreIdList = new HashMap<String,List<String>>();
							
							// Get variant id and list of store id from single media tag
							for (Variant variant : xmlMedia.getVariants().getVariant())
								mapVariantIdStoreIdList.put(variant.getId(),Arrays.asList(variant.getStores()));

							
							for (Map.Entry<String,List<String>> variantIdStoreIdList : mapVariantIdStoreIdList.entrySet())
							{
									Map<String, String> mapPageIdPageNum = new HashMap<String, String>();
								
									// Get all the pages for a single variant
									for (Page page : Arrays.asList(xmlMedia.getSection(0).getPage()))
										
										if (Arrays.asList(page.getVariant_ids()).contains(variantIdStoreIdList.getKey()))
											
											mapPageIdPageNum.put(page.getId(), page.getFolio());
											 
									// Now ready with input. Start testing for each store id.
									for(String storeId : variantIdStoreIdList.getValue())
										
										pool.execute(new StoreLocalAdVerification(storeId, mediaType, activityId, activityName, startDate, endDate, mapPageIdPageNum));	
							}

						} 
				catch (Throwable e)
				{
					CompareValuesUtility.init();
					CompareValuesUtility.logFailed("Exception","Failed", e.getMessage());
					CompareValuesUtility.setupResult(sFileName, true);
				} 
				finally
				{
					 CompareValuesUtility.teardown();
				}
				else
					System.out.println("got null");

			} // End of try block

			catch (InterruptedException e)
			{
				e.getStackTrace();

			}
		pool.shutdown();

		try
		{
			pool.awaitTermination(20, TimeUnit.MINUTES);

		} catch (InterruptedException e)
		{
			e.getStackTrace();
		}
	} // End of testStoreLocalAd method
} // End of class