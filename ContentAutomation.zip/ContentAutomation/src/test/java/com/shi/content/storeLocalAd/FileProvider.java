package com.shi.content.storeLocalAd;

import org.testng.annotations.DataProvider;

import com.shc.autocontent.LoadProperties;

public class FileProvider {

	@DataProvider(name="fileProvider", parallel=true)
	public static Object[][] fileProvider(){
		String files = LoadProperties.LOCGRP_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			sFileName = sFileName.trim();
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		System.out.println("-------------------------------------- ");
		System.out.println("No. of files to test .. "+lstOfFiles.length);
		System.out.println("-------------------------------------- ");
		return lstOfFiles;
	}
}
