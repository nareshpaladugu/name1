package com.shi.content.wcstogb.giftRegi.temp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shi.content.wcstogb.giftRegi.CommonGiftReg;

public class UserCollectionTest 
{
	private Map<String,String> userMap = new HashMap<String, String>();

	@Test(groups="GiftRegistry-UserCollectionTest1")
	public void userCollectionTest()
	{

		if(CommonGiftReg.database==null)
		{
			LoadProperties.setCustomMsgForEmail("Check MongoDb Connection",MSGTYPE.ERROR);
			return;
		}

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		readFile();			

		UserCollectionCache.init(userMap.keySet());

		for (Map.Entry<String, String> entry : userMap.entrySet()) {

			pool.execute(new UserCollectionVerifications(entry.getKey(),entry.getValue()));
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
		finally
		{
		}
	}

	private void readFile(){

		BufferedReader br = null;

		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader("src/test/resources/userIds_1.txt"));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);
				userMap.put(sCurrentLine.split(",")[1].trim(),sCurrentLine.split(",")[0].trim());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}
	@BeforeSuite(groups="GiftRegistry-UserCollectionTest1")
	public void startUp()
	{
		CommonGiftReg.getGiftRegMongoDB();
	}
}
