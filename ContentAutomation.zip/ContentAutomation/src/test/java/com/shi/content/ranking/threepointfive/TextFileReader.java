package com.shi.content.ranking.threepointfive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TextFileReader {

	public static String getFile(String file,boolean org)
	{
		BufferedReader br = null;
		StringBuffer sCurrentLineAll=new StringBuffer("");
		try {

			String sCurrentLine;


			br = new BufferedReader(new FileReader(file));

			while ((sCurrentLine = br.readLine()) != null) {
				if(org)
					sCurrentLineAll.append(sCurrentLine +"\n");
				else
					sCurrentLineAll.append(sCurrentLine +" ");
			}


			//System.out.println("sCurrentLineAll .. "+sCurrentLineAll);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		return sCurrentLineAll.toString();
	}
}