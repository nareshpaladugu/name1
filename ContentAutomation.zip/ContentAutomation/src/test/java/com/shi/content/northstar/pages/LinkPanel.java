package com.shi.content.northstar.pages;

import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Menu;
import com.shc.content.webdriver.html.WaitUtils;

public class LinkPanel extends BasePage{

	private Link linkWelCome = new Link("frm-menu:j_idt54", "WelCome");
	private Link linkAbout = new Link("frm-menu:j_idt55", "About");
	private Link linkStoreLocator = new Link("frm-menu:j_idt56", "StoreLocator");
	private Link linkStoreReport = new Link("frm-menu:j_idt57", "StoreReport");
	private Link linkLogSearch = new Link("frm-menu:j_idt58", "LogSearch");
	private Link linkCheetah = new Link("frm-menu:j_idt59", "Cheetah");
	private Link linkBulkUpload = new Link("frm-menu:j_idt60", "BulkUpload");
	private Link linkClearCache = new Link("frm-menu:j_idt61", "ClearCache");
	private Link linkICCE = new Link("frm-menu:j_idt63", "ICCE");
	private Menu menuHome=  new Menu("frm-menu:j_idt52","HomeMenu");
	public LinkPanel() {
		super("Links Panel");
	}

	public void goToStoreLocator(){
		WaitUtils.waitUntilElementIsVisible(linkStoreLocator);
		linkStoreLocator.click();
		System.out.println("Clicked on Store Locator");
	}

	public Menu getMenuHome() {
		return menuHome;
	}

	public Link getStoreLocator() {
		return linkStoreLocator;
	}
	
	public void goToStoreReport(){
		WaitUtils.waitUntilElementIsVisible(linkStoreReport);
		linkStoreReport.click();
		System.out.println("Clicked on Store Report");
	}

	public void goToLogSearch(){
		WaitUtils.waitUntilElementIsVisible(linkLogSearch);
		linkLogSearch.click();
		System.out.println("Clicked on Log Search");
	}
	
	public void goToCheetah(){
		WaitUtils.waitUntilElementIsVisible(linkCheetah);
		linkCheetah.click();
		System.out.println("Clicked on Cheetah");
	}
	
	public void goToBulkUpload(){
		WaitUtils.waitUntilElementIsVisible(linkBulkUpload);
		linkBulkUpload.click();
		System.out.println("Clicked on Bulk Upload");
	}
	
	public void goToClearCache(){
		WaitUtils.waitUntilElementIsVisible(linkClearCache);
		linkClearCache.click();
		System.out.println("Clicked on Clear Cache");
	}
	
	public void goToICCE(){
		WaitUtils.waitUntilElementIsVisible(linkICCE);
		linkICCE.click();
		System.out.println("Clicked on ICCE");
	}
	
	public void goToWelCome(){
		WaitUtils.waitUntilElementIsVisible(linkWelCome);
		linkWelCome.click();
		System.out.println("Clicked on WelCome");
	}
	
	public void goToAbout(){
		WaitUtils.waitUntilElementIsVisible(linkAbout);
		linkAbout.click();
		System.out.println("Clicked on About");
	}
}
