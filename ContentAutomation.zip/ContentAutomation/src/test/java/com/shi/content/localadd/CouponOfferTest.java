package com.shi.content.localadd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.localadgrp.Localadgrp_;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.content.restutils.RestExecutor;

public class CouponOfferTest {

	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider" , groups="CouponOffer")
	public void testcouponOffer(String fileName) {

		BlockingQueue<List<String>> singlelocalid = new LinkedBlockingQueue<List<String>>();
		TextFileParser<String> myParser = new TextFileParser<String>(fileName, singlelocalid,new LocaladdParser());
		Thread t = new Thread(myParser);
		t.start();


		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while (true) {
			List<String> newData;
			int i=0;
			try {
				newData = singlelocalid.poll(20, TimeUnit.SECONDS);
				
			if(newData.contains("Title|Description|OfferStartDate|OfferEndDate|PostStartDate|PostEndDate|FinePrint|ProductRegPrice|ProductSalePrice|OfferMessage|ImageFileName|OfferType|CategoryGroupID|StoreID|AvailableOnlineProductCode|Status|")){
				continue;
			}
				if (newData == myParser.POISON_PILL) {
					break;
				}
				if(newData != null){
					pool.execute(new CouponOfferVerification(newData,i++,localAdGrpMap));
					System.out.println("Sent "+ newData);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		
	}
	
	public static Map<String, Localadgrp_> localAdGrpMap = new HashMap<String, Localadgrp_>();

	@BeforeClass(groups = "CouponOffer")
	public void populateLocalAdGrpMap() {

		List<String> grpIds = new ArrayList<String>();

		long start = System.currentTimeMillis();
		for (int bucket = 0; bucket < 4096; bucket++) {
			grpIds = RestExecutor.getIdsForBucket(CollectionValuesVal.LOCALADGRP, bucket);
			for (String grpId : grpIds) {
				Localadgrp_ localAdGrp=RestExecutor.getDataById(CollectionValuesVal.LOCALADGRP, grpId);
				if(localAdGrp!=null){
					String strIdType = null;
					if(localAdGrp.getType().equals("SYWR") || localAdGrp.getType().equals("FINANCEOFFER"))
						strIdType = "0"+"-"+localAdGrp.getType();
					else
						strIdType = localAdGrp.getStoreId().intValue()+"-"+localAdGrp.getType();
					
					localAdGrpMap.put(strIdType, localAdGrp);
				}
			}
		}
		System.out.println("localAdGrpMap size..." + localAdGrpMap.size());
	}

}
