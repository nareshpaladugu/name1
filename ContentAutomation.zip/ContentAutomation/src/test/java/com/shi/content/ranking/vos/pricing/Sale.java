package com.shi.content.ranking.vos.pricing;

public class Sale {
	private float salePrice;
	private String saleEndDate;

	public float getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(float salePrice) {
		this.salePrice = salePrice;
	}
	
	public String getSaleEndDate() {
        return saleEndDate;
    }
	
	public void setSaleEndDate(String saleEndDate) {
        this.saleEndDate = saleEndDate;
    }
	
}
