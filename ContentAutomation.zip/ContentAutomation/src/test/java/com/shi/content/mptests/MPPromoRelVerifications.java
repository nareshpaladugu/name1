package com.shi.content.mptests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.joda.time.Instant;

import com.generated.vos.offer.Offer;
import com.generated.vos.promo.Financing;
import com.generated.vos.promo.PromoDetails;
import com.generated.vos.promo.neww.Promorel;
import com.generated.vos.promo.neww.SywPoint;
import com.generated.vos.promos.Desc;
import com.generated.vos.promos.EligCriteria;
import com.generated.vos.promos.Promo;
import com.generated.vos.promos.Target;
import com.generated.vos.promos.UrgencyDetails;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.mptests.MP_Promorel_DataCreation_Script.Domain;
import com.shi.content.mptests.MP_Promorel_DataCreation_Script.Mode;
import com.shi.content.mptests.MP_Promorel_DataCreation_Script.PromoGroup;

public class MPPromoRelVerifications implements Runnable {

	String message;
	String modifiedDtm;
	HashMap<String, HashMap<String, String>> itemInfo = null;
	String executionMode = "";
	String partNumber = null;
	HashMap<String,String> promoInfo = null;
	String offerId = null;
	//Avinash
	JsonElement sywPointJsonElement = null;
	
	String sywSite = null;
	CollectionValues sywPointCollection = null;
	String sywPointItemId = null;
	String itemId = null;
	Boolean isStaleMessageAlreadyChecked = false;

	public MPPromoRelVerifications(String message) {
		this.message = message;
		this.executionMode = "message";
	}

	public MPPromoRelVerifications(String partNumber, HashMap<String,String> promoInfo) {
		this.partNumber = partNumber;
		this.promoInfo = promoInfo;
		this.executionMode = "list";
	}

	public MPPromoRelVerifications(String offerId, boolean b) {
		this.offerId = offerId;
		this.executionMode = "bucket";
	}

	public void run() {
		if (executionMode.equals("message")) {
			verifyPromorelForMessageMode();
		} else if (executionMode.equals("list")) {
			verifyPromoDataByPartNumber(this.partNumber, this.promoInfo);
		} if (executionMode.equals("bucket")) {
			verifyPromotionForOffer(this.offerId);
		}
	}

	public void verifyPromoDataByPartNumber(String partNumber, HashMap<String,String> promoInfo) {
		try {
			CompareValuesUtility.init();

			// Get FBM Type of part number
			if (partNumber != null && !partNumber.equals("")) {
				List<String> itemIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"parentId", partNumber);

				if (itemIds == null || itemIds.size() == 0) {
					throw new Exception("No offer available in offer collection for part number "+partNumber);
				}

				CollectionValues promoCollection = null, promorelCollection = null;

				for (String itemId : itemIds) {
					try {
						CompareValuesUtility.init();
						for (String promoId : promoInfo.keySet()) {
							CompareValuesUtility.addDataFieldForReport("PROMO ID", promoId, INFOTYPE.DATA);

							CompareValuesUtility.init();
							String tempItemId = "";
							String domain = "";
							String mode = "";
							try {
								mode = promoInfo.get(promoId).trim().toLowerCase();
								CompareValuesUtility.addDataFieldForReport("Mode", mode, INFOTYPE.DATA);

								switch (mode) {
								case "preview":
									promoCollection = CollectionValuesVal.PREVIEWPROMO;
									promorelCollection = CollectionValuesVal.PREVIEWPROMOREL;
									break;
								case "production":
									promoCollection = CollectionValuesVal.PROMO;
									promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
								}

								APIResponse<Object> promoDoc = RestExecutor.getAllDataById(promoCollection, promoId);
								Promo promo = promoDoc.getT();

								if (promo == null) {
									throw new Exception("Promo "+promoId+" not present in promo collection.");
								}

								domain =  promoDoc.getSearchFieldValue("domain").trim().toLowerCase();
								CompareValuesUtility.addDataFieldForReport("Domain", domain, INFOTYPE.DATA);
								//Avinash added on 12/01/2017
								this.itemId = itemId;
								tempItemId = domain+"_"+itemId;
								CompareValuesUtility.addDataFieldForReport("Item Id", tempItemId, INFOTYPE.DATA);

								validateInactivePromotion(promo);	

								// Get promorel doc
								APIResponse<Object> promorelDoc = RestExecutor.getAllDataById(promorelCollection, tempItemId);
								Promorel promorel = promorelDoc.getT();

								if (promorel != null) {
									// Get promo group
									verifyPromorelData(promo, promorel);
								} else {
									throw new Exception("Promorel doc not created for "+tempItemId);
								}
							} catch (Exception e) {
								CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
							} finally {
								CompareValuesUtility.setupResult(itemId, true);
							}
						}
					} catch (Exception e) {
						CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
					}
				}
			} else {
				throw new Exception("Part number is either null or blank");
			}
		} catch (Exception e) {
			CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
			CompareValuesUtility.setupResult(partNumber, true);
			CompareValuesUtility.teardown();
		}
	}

	public void parseMessage() throws Exception {
		// Validate message
		if (isValidMessage()) {
			itemInfo = new HashMap<>();
			HashMap<String, String> promoInfo = null;

			String value = JsonStringParser.getJsonValueNew(message, "promorel", true);
			JsonArray itemsArr = new JsonParser().parse(value).getAsJsonArray();

			for(int i=0; i<itemsArr.size(); i++) {
				JsonObject jItem = itemsArr.get(i).getAsJsonObject();
				
							
				
			
				String itemId = jItem.get("itemId").getAsString();
				String pgmType = jItem.get("prgm").getAsString();
				String dartPartNo = "";
				String removeAllPromo = "";

				if (jItem.get("dartPartNbr") != null) {
					dartPartNo = jItem.get("dartPartNbr").getAsString();
				}

				if (jItem.get("removeAllPromo") != null) {
					removeAllPromo = jItem.get("removeAllPromo").getAsString().trim();
				}

				// Prepare itemId for promorel
				if (pgmType.trim().equalsIgnoreCase("FBM")) {
					itemId = "SPM"+itemId;
				} else if (pgmType.trim().equalsIgnoreCase("FBS")) {
					if (jItem.get("dartPartNbr") != null && !jItem.get("dartPartNbr").getAsString().equals("")) {
						itemId = dartPartNo;
					}
				}

				// Get promo details
				promoInfo = new HashMap<>();

				if (removeAllPromo == null || removeAllPromo.equals("") || removeAllPromo.equalsIgnoreCase("false")) {
					JsonArray promosArr = null;
					if(jItem.get("activePromo") != null)
					{
						promosArr = jItem.get("activePromo").getAsJsonArray();
						for(int j=0; j<promosArr.size(); j++) {
							JsonObject jPromo = promosArr.get(j).getAsJsonObject();
							String promoId = jPromo.get("promoId").getAsString();
							String promoType = jPromo.get("promoType").getAsString();
							String mode = jPromo.get("mode").getAsString();

						if(promoType.trim().equalsIgnoreCase("Financing"))
							promoId += "_z";
						else
							promoId += "_p";
						promoInfo.put(promoId, mode);
					}
					}
				} else if(removeAllPromo.equalsIgnoreCase("true")) {
					promoInfo.put("removeAllPromo", "true");
				}
				itemInfo.put(itemId, promoInfo);
			}
		} else {
			throw new Exception("Invalid Message: "+this.message);
		}
	}

	public void verifyPromorelForMessageMode() {
		try {
			CompareValuesUtility.init();

			// validate & parse message
			parseMessage();

			Promo promo = null;
			APIResponse<Promo> promoDoc = null;
			Promorel promorelDoc = null;
			CollectionValues promorelCollection = null;
			String tempItemId = "";

			// Verification
			if(itemInfo != null  && itemInfo.size() > 0 )
			{
				
				for (String itemId : itemInfo.keySet()) {
					try {
						CompareValuesUtility.init();
						
						Boolean isStale = checkStaleMessage(itemId);
						if(isStale)
							throw new Exception("Its a stale message");
						
						HashMap<String, String> promoInfo = itemInfo.get(itemId);
						if ( promoInfo.get("removeAllPromo") != null && promoInfo.containsKey("removeAllPromo") && promoInfo.get("removeAllPromo").equalsIgnoreCase("true")) {
							// Verify this item should get deleted from promore/previewpromorel for all the domains
							for (Domain domain : Domain.values()) {
								for (Mode mode : Mode.values()) {
									switch (mode) {
									case PREVIEW:
										promorelCollection = CollectionValuesVal.PREVIEWPROMOREL;
										break;
									case PRODUCTION:
										promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
									}

									promorelDoc = RestExecutor.getAllDataById(promorelCollection, domain.toString().toLowerCase()+"_"+itemId).getT();

									if (promorelDoc != null) {
										throw new Exception("promorel doc not deleted for mode "+mode.toString()+" & domain "+domain.toString());
									}
								}
							}
							CompareValuesUtility.addDataFieldForReport("removeAllPromo", "Verified", INFOTYPE.DATA);
							CompareValuesUtility.setupResult(itemId, true);//added on 16/01/2017
						} else { 
							CompareValuesUtility.init(); //added on commented on 15/01/2017
							for ( String promoId : promoInfo.keySet()) {
								//CompareValuesUtility.init(); existingcommented on 15/01/2017
								tempItemId = "";
								CompareValuesUtility.addDataFieldForReport("PROMO ID", promoId, INFOTYPE.DATA);

								try {
									String mode = promoInfo.get(promoId).trim();

									// Get Promo Doc
									if (mode.equalsIgnoreCase("preview")) {
										promoDoc = RestExecutor.getAllDataById(CollectionValuesVal.PREVIEWPROMO, promoId);
										promorelCollection = CollectionValuesVal.PREVIEWPROMOREL;
										
									} else if (mode.equalsIgnoreCase("production")) {
										promoDoc = RestExecutor.getAllDataById(CollectionValuesVal.PROMO, promoId);
										promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
										
									} else {
										// Add code for throwing exception
									}

									promo = promoDoc.getT();
									if (promo == null) {
										throw new Exception("Promo "+promoId+" not present in promorel collection");
									}

									String domain = promoDoc.getSearchFieldValue("domain").toLowerCase();
									CompareValuesUtility.addDataFieldForReport("Domain", domain, INFOTYPE.DATA);
									CompareValuesUtility.addDataFieldForReport("Mode", mode, INFOTYPE.DATA);

									// Prepare Promorel Item Id to test
									tempItemId = itemId;
									sywPointItemId = itemId;
									if (domain.equalsIgnoreCase("sears")) {
										tempItemId = "sears_"+itemId;
										
									} else if (domain.equalsIgnoreCase("kmart")) {
										tempItemId = "kmart_"+itemId;
										
									} else {
										// Add logic for other domains
									}

									CompareValuesUtility.addDataFieldForReport("Item Id", tempItemId, INFOTYPE.DATA);

									// Validate promo
									validateInactivePromotion(promo);

									// Get promorel document
									promorelDoc = (Promorel) RestExecutor.getDataById(promorelCollection, tempItemId);

									if (promorelDoc == null) {
										throw new Exception("Promorel document not created");
									}

									// Validate message Time and promorel doc time			
									/*if(isStaleMessage(promorelDoc)) {
										isStaleMessageAlreadyChecked = true;
										throw new Exception("Its a stale message");
									}*/

									// Verify all promo rules
									verifyPromorelData(promo, promorelDoc);
								} catch(Exception e) {
									System.out.println(e.getMessage());
									CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
								} finally {
									//CompareValuesUtility.setupResult(itemId, true); //existing commented on 15/01/2017 
								}
							}// for loop close for promoId
							
							
							//==============================================Added on 14/01/2017
							
							
							String value1 = JsonStringParser.getJsonValueNew(message, "promorel", true);				
							JsonArray itemsArr1 = new JsonParser().parse(value1).getAsJsonArray();
							if(itemsArr1 != null  && itemsArr1.size() > 0)
							{
								String removeAllPromo = "false";
								String value = JsonStringParser.getJsonValueNew(message, "promorel", true);				
								JsonArray itemsArr = new JsonParser().parse(value).getAsJsonArray();
								
								for(int ii=0; ii<itemsArr.size(); ii++) 
								{
									
									
									JsonObject jItem = itemsArr.get(ii).getAsJsonObject();
									sywPointItemId = jItem.get("itemId").getAsString();
									
									String itemId2 = jItem.get("itemId").getAsString();
									String pgmType = jItem.get("prgm").getAsString();
									
									String dartPartNo = "";
							
									if (jItem.get("dartPartNbr") != null) 
									{
										dartPartNo = jItem.get("dartPartNbr").getAsString();
									}

									/*if (jItem.get("removeAllPromo") != null) 
									{
										removeAllPromo = jItem.get("removeAllPromo").getAsString().trim();
									}*/

									// Prepare itemId for promorel
									if (pgmType.trim().equalsIgnoreCase("FBM")) 
									{
										sywPointItemId = "SPM"+itemId2;
										//this.itemId = sywPointItemId;
									} 
									else if (pgmType.trim().equalsIgnoreCase("FBS")) 
									{
										if (jItem.get("dartPartNbr") != null && !jItem.get("dartPartNbr").getAsString().equals("")) 
										{
											sywPointItemId = dartPartNo;
											//this.itemId = sywPointItemId;
										}
									}
									
									
									if(itemId.equalsIgnoreCase(sywPointItemId))
									{
										JsonArray sywPointArray = null;
										try
										{
										//CompareValuesUtility.init();
												
										if(jItem.get("activeSYWPromo") != null)
										{
											sywPointJsonElement = jItem.get("activeSYWPromo");				
											sywPointArray = sywPointJsonElement.getAsJsonArray();
										}
										
										if( jItem.get("activeSYWPromo") != null && sywPointArray.size()>0  )
										{
											
										ArrayList<JsonElement> lst = null;
										boolean isBoth = false;
										boolean isSears = false;
										boolean isKmart = false;
										
										//for(int i=0; i< sywPointArray.size(); i++)
										//{
											List<SywPoint> sywPoints = null;
											 lst = new ArrayList<JsonElement>();
											for(int j=0;j<sywPointArray.size();j++)
											{
												lst.add(sywPointArray.get(j));
												System.out.println(lst);
												
											}
										//}
										
										/*for(int k = 0; k < lst.size(); k++)
										{
											JsonObject sywPointMessage = lst.get(k).getAsJsonObject();
											String site = sywPointMessage.get("site").getAsString();
											if(site.equalsIgnoreCase("both"))
											{
												isBoth = true;
												break;
											}
											else if(site.equalsIgnoreCase("sears"))
											{
												isSears = true;
											}
											else if(site.equalsIgnoreCase("kmart"))
											{
												isKmart = true;
											}
										}
											
										if(isBoth)
										{
											promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
											promorelDoc = getPromoRelDoc("sears",sywPointItemId);
											
											// Validate message Time and promorel doc time			
											if(isStaleMessage(promorelDoc)) {												
												throw new Exception("Its a stale message");
											}
											
											if( removeAllPromo.equalsIgnoreCase("false"))
											{
												//promorelCollection = CollectionValuesVal.PROMO_REL_NEW;				
												//promorelDoc = RestExecutor.getAllDataById(promorelCollection, "sears_"+sywPointItemId).getT();
												
												
												if (promorelDoc == null) 
													throw new Exception("promorel doc is deleted for site : sears in production mode");
												
												promorelDoc = getPromoRelDoc("kmart",sywPointItemId);
												if (promorelDoc == null) 
													throw new Exception("promorel doc is deleted for site : kmart in production mode");												
											}
											else
											{
												//promorelDoc = getPromoRelDoc("sears",sywPointItemId);
												if (promorelDoc != null) {
													throw new Exception("promorel doc is not deleted for site: sears in production mode");
												}
												
												promorelDoc = getPromoRelDoc("kmart",sywPointItemId);
												if (promorelDoc != null) {
													throw new Exception("promorel doc is not deleted for site: kmart in production mode");
												}
											}
										}
										
										if(isKmart )
										{
											promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
											promorelDoc = getPromoRelDoc("kmart",sywPointItemId);
											
											// Validate message Time and promorel doc time			
											if(isStaleMessage(promorelDoc)) {
												isStaleMessageAlreadyChecked = true;
												throw new Exception("Its a stale message");
											}
											
											if(removeAllPromo.equalsIgnoreCase("false"))
											{
												//promorelDoc = getPromoRelDoc("kmart",sywPointItemId);
												if (promorelDoc == null) 
													throw new Exception("promorel doc is deleted for site : kmart in production mode");											
											}
											else
											{
												//promorelDoc = getPromoRelDoc("kmart",sywPointItemId);
												if (promorelDoc != null) 
													throw new Exception("promorel doc is not deleted for site: kmart in production mode");																							
											}
												
										}
										if(isSears )
										{
											promorelCollection = CollectionValuesVal.PROMO_REL_NEW;
											promorelDoc = getPromoRelDoc("sears",sywPointItemId);
											
											// Validate message Time and promorel doc time			
											if(isStaleMessage(promorelDoc)) {
												isStaleMessageAlreadyChecked = true;
												throw new Exception("Its a stale message");
											}
											if(removeAllPromo.equalsIgnoreCase("false"))
											{
												//promorelDoc = getPromoRelDoc("sears",sywPointItemId);
												if (promorelDoc == null) 
													throw new Exception("promorel doc is deleted for site : sears in production mode");												
											}
											else
											{
												//promorelDoc = getPromoRelDoc("sears",sywPointItemId);
												if (promorelDoc != null) {
													throw new Exception("promorel doc is not deleted for site: sears in production mode");
												}
											}
											
										}
										
										
										*/
										
										
										//Verify SYWPoint promo if it is not removeAllPromo = true										
										//if( !(removeAllPromo.equalsIgnoreCase("true")) && sywPointArray.size() > 0)
											if(sywPointArray.size() > 0)
											
											checkSYWPointPromo(sywPointArray);
											
										}
									}catch(Exception e)
									{
										CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);//added on 16/01/2017
									}
									/*finally
									{CompareValuesUtility.setupResult(itemId, true); commented on 15/01/2017
									}*/
									}//if close
							
								} // Number of messages/promotions/sywpoints in a single message
							}
							
							System.out.println("Hi");
							
							//===============================================End SYW
							CompareValuesUtility.setupResult(itemId, true);//added on 15/01/2017
							System.out.println("hi");
						}//else close
					} catch (Exception e) {
						CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
						CompareValuesUtility.setupResult(itemId, true);
					}
				}
			} 
					
		} catch(Throwable e){
			CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.WARNING);
			CompareValuesUtility.setupResult(this.message, true);
		} finally{
			CompareValuesUtility.teardown();
		}
	}

	
	/***
	 * 
	 * @param site Site should be either sears/kmart
	 * @param sywPointItemId ItemId to get promorel document
	 * @return	Promorel document for site sears/kmart  
	 */
	public Promorel getPromoRelDoc(String site, String sywPointItemId)
	{
		Promorel promorelDoc = null;
		CollectionValues promorelCollection = null;
		
		promorelCollection = CollectionValuesVal.PROMO_REL_NEW;				
		promorelDoc = RestExecutor.getAllDataById(promorelCollection, site.trim()+"_"+sywPointItemId).getT();
		
		return promorelDoc;
	}
	
	
	public void verifyPromorelData(Promo promo, Promorel promorel) throws Exception {
		// Verify promotion is present in correct group in promorel document 
		String promoId = promo.getPromoIds().getId();
		PromoGroup expPromoGroup = getPromoGroup(promo);

		List<PromoDetails> promoDetailsList = null;
		List<SywPoint> sywPoints = null;
		List<Financing> financingDetailsList = null;
		boolean isFinancePromo = false, isPromoPresent = false;

		switch (expPromoGroup) {
		case BILLFREEDELIVERY:
			promoDetailsList = promorel.getPromoList().getBillFreeDelivery();
			break;
		case COUPON:
			promoDetailsList = promorel.getPromoList().getCoupons();
			break;
		case CRAFTCLB:
			promoDetailsList = promorel.getPromoList().getCraftClb();
			break;
		case FINANCING:
			financingDetailsList = promorel.getPromoList().getFinancing();
			isFinancePromo = true;
			break;
		case INSTSAVINGS:
			promoDetailsList = promorel.getPromoList().getInstSavings();
			break;
		case SYWMAX:
			promoDetailsList = promorel.getPromoList().getSywMax();
			break;
		case SYWMBR:
			promoDetailsList = promorel.getPromoList().getSywMbr();
			break;
		case SYWRDMPT:
			promoDetailsList = promorel.getPromoList().getSywRdmpt();
			break;
		case REGULAR:
			promoDetailsList = promorel.getPromoList().getRegular();
			break;
		case MISC:
			promoDetailsList = promorel.getPromoList().getMisc();
		}
			
		if (!isFinancePromo) {
			if (promoDetailsList == null || promoDetailsList.size() == 0) {
				throw new Exception("Promo not present in group "+expPromoGroup.toString());
			}

			PromoDetails promoDetails = null;
			for(int i=0; i<promoDetailsList.size(); i++) {
				promoDetails = promoDetailsList.get(i);
				if (promoDetails.getPromoId().equals(promo.getPromoIds().getId())) {
					isPromoPresent = true;
					break;
				}
			}

			if (isPromoPresent) {
				// Compare fields in promo & promorel collections
				validatePromo(promoDetails, promo);
			} else {
				throw new Exception("Promo "+promoId+" not present in expected group "+expPromoGroup.toString());
			}
		} else {
			if (financingDetailsList == null || financingDetailsList.size() == 0) {
				throw new Exception("Promo "+promoId+" not present in expected group "+expPromoGroup.toString());
			}

			Financing financingDetails = null;
			for(int i=0; i<financingDetailsList.size(); i++) {
				financingDetails = financingDetailsList.get(i);
				if (financingDetails.getPromoId().equals(promo.getPromoIds().getId())) {
					isPromoPresent = true;
					break;
				}
			}

			if (isPromoPresent) {
				// Compare fields in promo & promorel collections
				validateFinancePromo(financingDetails, promo);
			} else {
				throw new Exception("Promo "+promoId+" not present in expected group "+expPromoGroup.toString());
			}
		}
		
		//Handle SYW Promo
		//Avinash
		
				//sywPoints =  promorel.getPromoList().getSywPoints();
				
				//JsonArray ja = sywPromoArray.getAsJsonArray();
		//checkSYWPointPromo();
	}
	
	
	public void checkSYWPointPromo(JsonArray sywPointArray)
	{
		//CompareValuesUtility.init();
		//try
		//{
		List<SywPoint> sywPoints = null;
		ArrayList<JsonElement> lst = new ArrayList<JsonElement>();
		for(int i=0;i<sywPointArray.size();i++)
		{
			lst.add(sywPointArray.get(i));		
			
		}
		
		for(int i=0; i<lst.size(); i++)
		{
			try
			{
				String sywPromoId = null;
				JsonObject sywPointMessage = lst.get(i).getAsJsonObject();
				
				//Mandatory field
				if(sywPointMessage.get("promoId") == null)
					throw new Exception("SYWPromoId is null");
				else
					sywPromoId = sywPointMessage.get("promoId").getAsString();
				
				//Mandatory field
				if(sywPointMessage.get("typeCde") == null)
					throw new Exception("SYWPoint typeCde is null");
				//Mandatory field
				if(sywPointMessage.get("subTypeCde") == null)
					throw new Exception("SYWPoint subTypeCde is null");
				//Mandatory field			
				if(sywPointMessage.get("startDtm") == null)
					throw new Exception("SYWPoint startDtm is null");
				//Mandatory field
				if(sywPointMessage.get("endDtm") == null)
					throw new Exception("SYWPoint endDt is null");
				//Mandatory field
				if(sywPointMessage.get("site") == null)
					throw new Exception("SYWPoint site is null");
				
				
				
				
				
				
				if(sywPointMessage.get("endDtm").getAsLong() > Instant.now().getMillis())
				{
					if(sywPointMessage.get("site").getAsString().equalsIgnoreCase("both"))
					{
						boolean isSYWPromoExists = false; 
						sywPoints = getSYWPointPromorel("sears_"+sywPointItemId);
						if(sywPoints == null)
							throw new Exception("SYWPoint promo is not created for site Both");
						for(int j=0; j<sywPoints.size(); j++)
						{
							if(sywPromoId.toString().equalsIgnoreCase(sywPoints.get(j).getPromoId().toString()))
							{
								validateSYWPointsPromo(sywPointMessage, sywPoints.get(j), "sears");
								isSYWPromoExists = true;
							}
							
						}
						if(isSYWPromoExists == false)
						{
							CompareValuesUtility.logFailed("SYWPromo", sywPromoId.toString(), "SYWPoints promo is not a valid promo");
							
						}
						
						//kmart
						isSYWPromoExists = false;
						sywPoints = getSYWPointPromorel("kmart_"+sywPointItemId);
						
						if(sywPoints == null)
							throw new Exception("SYWPoint promo is not created for site Both");
						
						for(int j=0; j<sywPoints.size(); j++)
						{
							if(sywPromoId.toString().equalsIgnoreCase(sywPoints.get(j).getPromoId().toString()))
							{
								validateSYWPointsPromo(sywPointMessage, sywPoints.get(j), "kmart");
								isSYWPromoExists = true;
							}
						}
							if(isSYWPromoExists == false)
							{
								CompareValuesUtility.logFailed("SYWPromo", sywPromoId.toString(), "SYWPoints promo is not a valid promo");
							}
						
					} 
					//Site = sears only 
					if(sywPointMessage.get("site").getAsString().equalsIgnoreCase("sears"))
					{
						boolean isSYWPromoExists = false;
						sywPoints = getSYWPointPromorel("sears_"+sywPointItemId);
						if(sywPoints == null)
							throw new Exception("SYWPoint is not created for sears site.");
						for(int j=0; j<sywPoints.size(); j++)
						{
							if(sywPromoId.toString().equalsIgnoreCase(sywPoints.get(j).getPromoId().toString()))
							{
								validateSYWPointsPromo(sywPointMessage, sywPoints.get(j), "sears");
								isSYWPromoExists = true;
							}
						
						}
						if(isSYWPromoExists == false)
						{
							CompareValuesUtility.logFailed("SYWPromo", sywPromoId.toString(), "SYWPoints promo is not a valid promo");
						}
					}
					//site = kmart only
					if(sywPointMessage.get("site").getAsString().equalsIgnoreCase("kmart"))
					{
						boolean isSYWPromoExists = false;
						sywPoints = getSYWPointPromorel("kmart_"+sywPointItemId);
						System.out.println("hii");
						if(sywPoints == null)
							throw new Exception("SYWPoint promo is not created for Kmart site");
						for(int j=0; j<sywPoints.size(); j++)
						{
							if(sywPromoId.toString().equalsIgnoreCase(sywPoints.get(j).getPromoId().toString()))
							{
								validateSYWPointsPromo(sywPointMessage, sywPoints.get(j), "kmart");
								isSYWPromoExists = true;
							}							
						}
						if(isSYWPromoExists == false)
						{
							CompareValuesUtility.logFailed("SYWPromo", sywPromoId.toString(), "SYWPoints promo is not a valid promo");
						}
					}
				}
				else
				{
					CompareValuesUtility.logPassed("SYWPoints Promo", "Null", "As endDate is not in the range of current/future date");
				}
			}
			catch(Exception  e)
			{
				CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
			}
		}
		//}catch(Exception e) {
				//System.out.println(e.getMessage());
				//CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
			//} finally {
				//CompareValuesUtility.setupResult(sywPointItemId, true);
			//}
		}
		
	
	
	
	
	
	
	/***
	 * Hit the specified domain promorel and get the promorel document in return.
	 * @param itemId itemId to hit promorel collection
	 * @return promorel document.
	 * @throws Exception 
	 */
	public List<SywPoint> getSYWPointPromorel(String itemId) throws Exception
	{
		Promorel promorelDocForOtherSite = null;
		if(sywPointCollection == null)
			sywPointCollection = CollectionValuesVal.PROMO_REL_NEW;
		promorelDocForOtherSite = (Promorel) RestExecutor.getDataById(sywPointCollection, itemId);	
		if(promorelDocForOtherSite == null)
		{
			String site[] = itemId.split("_");
			throw new Exception("SYWPoint promo is not created for site "+site[0]);
		}
		List<SywPoint> sywPoints  = promorelDocForOtherSite.getPromoList().getSywPoints();
		return sywPoints;
	}
				
		

	/***
	 * Validate SYWPoints promo
	 * @param sywPointMessage	Json message
	 * @param sywPoints	sywPoints from promorel documents
	 */
	public void validateSYWPointsPromo(JsonObject sywPointMessage,SywPoint sywPoints, String site)
	{
		
		//site (both/sears/kmart)
		CompareValuesUtility.addDataFieldForReport("SYWPromoSites", site, INFOTYPE.DATA);
		
		if(sywPointMessage.get("promoId") != null)
			CompareValuesUtility.compareValues("SYWpromoId",sywPointMessage.get("promoId").getAsString(),sywPoints.getPromoId());
		
		//Title
		if(sywPointMessage.get("promoName").getAsString() != null)
		{
			if(sywPoints.getTitle() != null)
				CompareValuesUtility.compareValues("promoName",sywPointMessage.get("promoName").getAsString(),sywPoints.getTitle());
			else			
				CompareValuesUtility.logFailed("promoName", sywPointMessage.get("promoName").getAsString(), "promoName/title field not present under sywPoints in promorel collection");			
		}
		else
		{
			CompareValuesUtility.logFailed("promoName", "Not null", "promoName/title field is not present in message");
		}
		
		//typeCde
		if(sywPointMessage.get("typeCde").getAsString() != null)
		{
			if(sywPoints.getTypeCde() != null)
			{
				CompareValuesUtility.compareValues("typeCde",sywPointMessage.get("typeCde").getAsString(),sywPoints.getTypeCde());
			}
			else
			{
				CompareValuesUtility.logFailed("typeCde", sywPointMessage.get("typeCde").getAsString(), "typeCde field not present under sywPoints in promorel collection");
			}
		}
		else
		{
			CompareValuesUtility.logFailed("typeCde", "Not null", "typeCde field is not present in message");
		}
		
		//subTypeCde
		if(sywPointMessage.get("subTypeCde").getAsString() != null)
		{
			if(sywPoints.getSubTypeCde() != null)
			{
				CompareValuesUtility.compareValues("subTypeCde",sywPointMessage.get("subTypeCde").getAsString(),sywPoints.getSubTypeCde());
			}
			else
			{
				CompareValuesUtility.logFailed("subTypeCde", sywPointMessage.get("subTypeCde").getAsString(), "subTypeCde field not present under sywPoints in promorel collection");
			}
		}
		else
		{
			CompareValuesUtility.logFailed("subTypeCde", "Not null", "subTypeCde field is not present in message");
		}
		
		//startDt		
		//Need conversion to unixtimestamp
		if(sywPointMessage.get("startDtm").getAsString() != null)
		{
			String startDate = JodaDateTimeUtility.convertUnixTSToTZ_CSTFormat(Long.parseLong(sywPointMessage.get("startDtm").getAsString()), "GMT-6:00");
			
			if(sywPoints.getStartDt() != null )
			{
				CompareValuesUtility.compareValues("startDtm",startDate,sywPoints.getStartDt());
			}
			else
			{
				CompareValuesUtility.logFailed("startDtm", "Not null", "startDt field is not present in message");
			}
		}
		else
		{
			CompareValuesUtility.logFailed("startDtm", sywPointMessage.get("startDtm").getAsString(), "startDtm field not present under sywPoints in promorel collection");
		}
		
		//endDt
		if(sywPointMessage.get("endDtm").getAsString() != null)
		{
			String endDate = JodaDateTimeUtility.convertUnixTSToTZ_CSTFormat(Long.parseLong(sywPointMessage.get("endDtm").getAsString()), "GMT-6:00");
			
			if(sywPoints.getEndDt() != null)
			{
				CompareValuesUtility.compareValues("endDtm",endDate,sywPoints.getEndDt());
			}
			else
			{
				CompareValuesUtility.logFailed("endDtm", sywPointMessage.get("endDtm").getAsString(), "endDtm field not present under sywPoints in promorel collection");
			}
		}
		else
		{
			CompareValuesUtility.logFailed("endDtm", "Not null", "endDt field is not present in message");
		}
		
		//genPromoFlag
		/***
		 * If genPromoFlag = false in message then It will not get populated in promorel document under sywPoints promo.
		 */
		if(sywPointMessage.get("genPromoFlag") != null)
		{
			if(sywPoints.getIsGeneric() != null)
			{
				CompareValuesUtility.compareValues("genPromoFlag",sywPointMessage.get("genPromoFlag").getAsString(),sywPoints.getIsGeneric());
			}
			else
			{
				CompareValuesUtility.logPassed("genPromoFlag", sywPointMessage.get("genPromoFlag").getAsString(), "genPromoFlag field not present under sywPoints in promorel collection when genPromoFlag=false in message");
			}
		}
		else
		{
			CompareValuesUtility.logFailed("genPromoFlag", "Not null", "genPromoFlag field is not present in message");
		}
		
		//Status is pending
		if(sywPointMessage.get("typeCde") != null	&&  sywPointMessage.get("startDtm") != null	&& sywPointMessage.get("endDtm") != null && sywPointMessage.get("site") !=null && sywPointMessage.get("subTypeCde") != null && 
				sywPoints.getTypeCde() != null && sywPoints.getStartDt() != null && sywPoints.getEndDt() != null )
		{
			if(sywPoints.getStatus() != null)
			{
				CompareValuesUtility.compareValues("SYWstatus", "a" , sywPoints.getStatus());
			}			
		}
		else
		{
			CompareValuesUtility.logFailed("SYWstatus", "Not null", "status field is not present in message");
		}

						
	}
	
	
	
	/**
	 * Validate each individual promotion
	 * @param promorelDoc
	 * @param promo
	 */
	public void validatePromo(PromoDetails promorelPromoDetails, Promo promo){
		// Promo Id
		System.out.println("Hi");
		
		if (promo.getPromoIds().getId() != null) {
			if (promorelPromoDetails.getPromoId() != null) {
				CompareValuesUtility.compareValues("promoId",promo.getPromoIds().getId(),promorelPromoDetails.getPromoId());
			} else {
				CompareValuesUtility.logFailed("promoId", promo.getPromoIds().getId(), "promoId field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("promoId", "Not null", "promoId field not present in promo collection");
		}
		
		//lmtQty
		if(promo.getPromoDetails().getUrgencyDetails() != null && promo.getPromoDetails().getUrgencyDetails().getLmtQty() != null)
		{
			if(promorelPromoDetails.getLmtQty() != null)
			{
				CompareValuesUtility.compareValues("lmtQty", promo.getPromoDetails().getUrgencyDetails().getLmtQty(), promorelPromoDetails.getLmtQty());
			}
			else
			{
				CompareValuesUtility.logFailed("lmtQty", promo.getPromoDetails().getUrgencyDetails().getLmtQty(), "lmtQty field not present in promorel collection");
			}
		}
		/*else {
			CompareValuesUtility.logFailed("lmtQty", "Not null", "lmtQty field not present in promo collection");
		}*/
		
		//urgencyType
		if(promo.getPromoDetails().getUrgencyDetails() != null && promo.getPromoDetails().getUrgencyDetails().getType() != null)
		{			
			if(promorelPromoDetails.getUrgencyType() != null && promorelPromoDetails.getUrgencyType().name() != null )
			{
				CompareValuesUtility.compareValues("urgencyType", promo.getPromoDetails().getUrgencyDetails().getType(), promorelPromoDetails.getUrgencyType().name());
			}
			else
			{
				CompareValuesUtility.logFailed("urgencyType", promo.getPromoDetails().getUrgencyDetails().getType(), "urgencyType field not present in promorel collection");
			}			
		}
		/*else
		{
			CompareValuesUtility.logFailed("urgencyType", "Not null", "urgencyType field not present in promo collection");
		}*/
		// Promo Type
		if (promo.getPromoDetails().getType() != null) {
			if (promorelPromoDetails.getPromoType() != null) {
				CompareValuesUtility.compareValues("promoType",promo.getPromoDetails().getType(), promorelPromoDetails.getPromoType());
			} else {
				CompareValuesUtility.logFailed("promoType", promo.getPromoDetails().getType(), "promoType field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("promoType", "Not null", "promoType field not present in promo collection");
		}

		// Min Purchase Value
		if(promo.getRestrictions() != null
				&& promo.getRestrictions().getCartThreshold() != null
				&& promo.getRestrictions().getCartThreshold().getMin() != null) {
			if (promorelPromoDetails.getMinPurchaseVal() != null) {
				CompareValuesUtility.compareAsNumbers("minPurchaseVal", promo.getRestrictions().getCartThreshold().getMin(), promorelPromoDetails.getMinPurchaseVal());
			} else {
				CompareValuesUtility.logFailed("minPurchaseVal", promo.getRestrictions().getCartThreshold().getMin(), "minPurchase field not present in promorel collection");
			}
		}

		// Start Date
		if (promo.getPromoDetails().getStartDt() != null) {
			if (promorelPromoDetails.getStartDt() != null) {
				CompareValuesUtility.compareValues("startDt",promo.getPromoDetails().getStartDt(),promorelPromoDetails.getStartDt());
				//CompareValuesUtility.compareValues("startDt",promo.getPromoDetails().getStartDt(),com.generated.vos.promo.neww.PromoList.);
				//Avinash
			} else {
				CompareValuesUtility.logFailed("startDt", promo.getPromoDetails().getStartDt(), "startDt field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("startDt", "Not null", "startDt field not present in promo collection");
		}

		// End Date
		if (promo.getPromoDetails().getEndDt() != null) {
			if (promorelPromoDetails.getEndDt() != null) {
				CompareValuesUtility.compareValues("endDt",promo.getPromoDetails().getEndDt(),promorelPromoDetails.getEndDt());
			} else {
				CompareValuesUtility.logFailed("endDt", promo.getPromoDetails().getEndDt(), "endDt field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("endDt", "Not null", "endDt field not present in promo collection");
		}

		// Group Name
		if (promo.getClassification() != null && promo.getClassification().getPromoGrpName() != null) {
			if (promorelPromoDetails.getGrpName() != null) {
				CompareValuesUtility.compareValues("GrpName",promo.getClassification().getPromoGrpName(),promorelPromoDetails.getGrpName());
			} else {
				CompareValuesUtility.logFailed("GrpName", promo.getClassification().getPromoGrpName(), "GrpName field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("GrpName", "Not null", "GrpName field not present in promo collection");
		}

		// Title
		if (promo.getPromoDetails().getDesc() != null && 
				promo.getPromoDetails().getDesc().size() > 0) {
			for(int i = 0; i < promo.getPromoDetails().getDesc().size(); i++) {
				Desc desc = promo.getPromoDetails().getDesc().get(i);
				if (desc != null && desc.getType().equals("S")) {
					String expTitle = desc.getValue();

					if (promorelPromoDetails.getTitle() != null) {
						CompareValuesUtility.compareValues("title",expTitle,promorelPromoDetails.getTitle());
					} else {
						CompareValuesUtility.logFailed("title", expTitle, "title field not present in promorel collection");
					}		
				}
			}
		} else {
			CompareValuesUtility.logFailed("title", "Not null", "promoDetails->desc->value field not present in promo collection");
		}

		// Disc Amt
		List<EligCriteria> eligCriteriaList = promo.getEligCriterias();
		if (eligCriteriaList != null && eligCriteriaList.size() > 0) {
			List<Target> targetsList = eligCriteriaList.get(0).getTargets();
			if (targetsList != null && targetsList.size() > 0) {
				List<Double> values;
				if (targetsList.get(0).getReductions() != null 
						&& (values = targetsList.get(0).getReductions().getValues()) != null
						&& values.size() > 0) {
					if (promorelPromoDetails.getDiscAmt() != null) {
						CompareValuesUtility.compareValues("discAmt",values.get(0),promorelPromoDetails.getDiscAmt());	
					} else {
						CompareValuesUtility.logFailed("discAmt", "Not null", "discAmt field not present in promorel collection");
					}
				}
			} else {
				CompareValuesUtility.logFailed("discAmt", "Not null", "eligCriteria->targets->reductions->values field not present in promo collection");
			}
		}

		// Free promo flag
		if (promo.getFreePromoFlag() != null) {
			if (promorelPromoDetails.getFreePromoFlag() != null) {
				CompareValuesUtility.compareValues("freePromoFlag",promo.getFreePromoFlag(),promorelPromoDetails.getFreePromoFlag());
			} else {
				CompareValuesUtility.logFailed("freePromoFlag", promo.getFreePromoFlag(), "freePromoFlag field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("freePromoFlag", "Not null", "freePromoFlag field not present in promo collection");
		}

		// Disc Type
		if (promo.getPromoDetails().getDiscType() != null) {
			if (promorelPromoDetails.getDiscType() != null) {
				switch (promo.getPromoDetails().getDiscType()) {
				case PMD_DOLLAR_OFF:
					CompareValuesUtility.compareValues("discType","Dollar Off",promorelPromoDetails.getDiscType());
					break;
				case PMD_FIXED_PRICE:
					CompareValuesUtility.compareValues("discType","Fixed Price",promorelPromoDetails.getDiscType());
					break;
				case PMD_PERCENT_OFF:
					CompareValuesUtility.compareValues("discType","Percent Off",promorelPromoDetails.getDiscType());
					break;
				case PT_FIXED:
					CompareValuesUtility.compareValues("discType","Fixed Price",promorelPromoDetails.getDiscType());
					break;
				case PT_MULTIPLIER:
					CompareValuesUtility.compareValues("discType","MULTIPLIER",promorelPromoDetails.getDiscType());
					break;
				case PT_PERCENT:
					CompareValuesUtility.compareValues("discType","PERCENT",promorelPromoDetails.getDiscType());
					break;
				}
			} else {
				CompareValuesUtility.logFailed("discType", promo.getPromoDetails().getDiscType(), "discType field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("discType", "Not null", "discType field not present in promo collection");
		}

		/*		 // Disp Rank
		 if (promo.getPromoDetails().getDispRank() != null) {
			 if (promorelPromoDetails.getRank() != null) {
				 Object act = promorelPromoDetails.getRank();
				 if(act instanceof Double)
					 act = ((Double) act).intValue();
				 CompareValuesUtility.compareValues("dispRank",promo.getPromoDetails().getDispRank(),act);
			 } else {
				 CompareValuesUtility.logFailed("dispRank", promo.getPromoDetails().getDispRank(), "rank field not present in promorel collection");
			 }
		 } else {
			 CompareValuesUtility.logFailed("dispRank", "Not null", "rank field not present in promo collection");
		 }
		 */

		// promo Code
		if (promo.getPromoDetails().getCode() != null) {
			if (promorelPromoDetails.getPromoCode() != null) {
				CompareValuesUtility.compareValues("promoCode",promo.getPromoDetails().getCode(),promorelPromoDetails.getPromoCode());
			} else {
				CompareValuesUtility.logFailed("promoCode", promo.getPromoDetails().getCode(), "promoCode field not present in promorel collection");
			}
		}

		// threshold Condn
		if (promo.getEligCriterias().get(0) != null 
				&& promo.getEligCriterias().get(0).getSources() != null 
				&& promo.getEligCriterias().get(0).getSources().size() > 0 
				&& promo.getEligCriterias().get(0).getSources().get(0) != null
				&& promo.getEligCriterias().get(0).getSources().get(0).getBps() != null
				&& promo.getEligCriterias().get(0).getSources().get(0).getBps().getThresholdCond() != null) {
			if (promorelPromoDetails.getThresholdCond() != null) {
				CompareValuesUtility.compareValues("thresholdCond", promo.getEligCriterias().get(0).getSources().get(0).getBps().getThresholdCond(), promorelPromoDetails.getThresholdCond());
			} else {
				CompareValuesUtility.logFailed("thresholdCond", promo.getEligCriterias().get(0).getSources().get(0).getBps().getThresholdCond(), "thresholdCond field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("thresholdCond", "Not null", "thresholdCond field not present in promo collection");
		}

		// status
		if (promo.getMeta().getStatus() != null) {
			if (promorelPromoDetails.getStatus() != null) {
				CompareValuesUtility.compareValues("status",promo.getMeta().getStatus(),promorelPromoDetails.getStatus());
			} else {
				CompareValuesUtility.logFailed("status", promo.getMeta().getStatus(), "status field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("status", "Not null", "status field not present in promo collection");
		}

		/*		 // priority
		 if (promo.getMeta().getPriority() != null) {
			 if (promorelPromoDetails.getPriority() != null) {
				 CompareValuesUtility.compareValues("priority",promo.getMeta().getPriority(),promorelPromoDetails.getPriority());
			 } else {
				 CompareValuesUtility.logFailed("priority", promo.getMeta().getPriority(), "priority field not present in promorel collection");
			 }
		 }
		 */
		/*// details
		if (promo.getExclusionText() != null) {
			if (promorelPromoDetails.getDetails() != null) {
				CompareValuesUtility.compareValues("details",promo.getExclusionText(),promorelPromoDetails.getDetails());
			} else {
				CompareValuesUtility.logFailed("details", promo.getExclusionText(), "details field not present in promorel collection");
			}
		}*/
	}

	public void validateFinancePromo(Financing promorelPromoDetails, Promo promo) {
		// Promo Id
		if (promo.getPromoIds().getId() != null) {
			if (promorelPromoDetails.getPromoId() != null) {
				CompareValuesUtility.compareValues("promoId",promo.getPromoIds().getId(),promorelPromoDetails.getPromoId());
			} else {
				CompareValuesUtility.logFailed("promoId", promo.getPromoIds().getId(), "promoId field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("promoId", "Not null", "promoId field not present in promo collection");
		}

		//lmtQty
		if(promo.getPromoDetails().getUrgencyDetails().getLmtQty() != null)
		{
			if(promorelPromoDetails.getLmtQty() != null)
			{
				CompareValuesUtility.compareValues("lmtQty", promo.getPromoDetails().getUrgencyDetails().getLmtQty(), promorelPromoDetails.getLmtQty());
			}
			else
			{
				CompareValuesUtility.logFailed("lmtQty", promo.getPromoDetails().getUrgencyDetails().getLmtQty(), "lmtQty field not present in promorel collection");
			}
		}
		else {
			CompareValuesUtility.logFailed("lmtQty", "Not null", "lmtQty field not present in promo collection");
		}
		
		//urgencyType
		if(promo.getPromoDetails().getUrgencyDetails().getType() != null)
		{			
			if(promorelPromoDetails.getUrgencyType().name() != null )
			{
				CompareValuesUtility.compareValues("urgencyType", promo.getPromoDetails().getUrgencyDetails().getType(), promorelPromoDetails.getUrgencyType().name());
			}
			else
			{
				CompareValuesUtility.logFailed("urgencyType", promo.getPromoDetails().getUrgencyDetails().getType(), "urgencyType field not present in promorel collection");
			}			
		}
		else
		{
			CompareValuesUtility.logFailed("urgencyType", "Not null", "urgencyType field not present in promo collection");
		}
		
		// Promo Type
		if (promo.getPromoDetails().getType() != null) {
			if (promorelPromoDetails.getPromoType() != null) {
				CompareValuesUtility.compareValues("promoType",promo.getPromoDetails().getType(), promorelPromoDetails.getPromoType());
			} else {
				CompareValuesUtility.logFailed("promoType", promo.getPromoDetails().getType(), "promoType field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("promoType", "Not null", "promoType field not present in promo collection");
		}

		// Start Date
		if (promo.getPromoDetails().getStartDt() != null) {
			if (promorelPromoDetails.getStartDt() != null) {
				CompareValuesUtility.compareValues("startDt",promo.getPromoDetails().getStartDt(),promorelPromoDetails.getStartDt());
			} else {
				CompareValuesUtility.logFailed("startDt", promo.getPromoDetails().getStartDt(), "startDt field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("startDt", "Not null", "startDt field not present in promo collection");
		}

		// End Date
		if (promo.getPromoDetails().getEndDt() != null) {
			if (promorelPromoDetails.getEndDt() != null) {
				CompareValuesUtility.compareValues("endDt",promo.getPromoDetails().getEndDt(),promorelPromoDetails.getEndDt());
			} else {
				CompareValuesUtility.logFailed("endDt", promo.getPromoDetails().getEndDt(), "endDt field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("endDt", "Not null", "endDt field not present in promo collection");
		}

		// Group Name
		if (promo.getClassification() != null && promo.getClassification().getPromoGrpName() != null) {
			if (promorelPromoDetails.getGrpName() != null) {
				CompareValuesUtility.compareValues("GrpName",promo.getClassification().getPromoGrpName(),promorelPromoDetails.getGrpName());
			} else {
				CompareValuesUtility.logFailed("GrpName", promo.getClassification().getPromoGrpName(), "GrpName field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("GrpName", "Not null", "GrpName field not present in promo collection");
		}

		// status
		if (promo.getMeta().getStatus() != null) {
			if (promorelPromoDetails.getStatus() != null) {
				CompareValuesUtility.compareValues("status",promo.getMeta().getStatus(),promorelPromoDetails.getStatus());
			} else {
				CompareValuesUtility.logFailed("status", promo.getMeta().getStatus(), "status field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("status", "Not null", "status field not present in promo collection");
		}

		// desc
		if (promo.getPromoDetails().getDesc() != null && 
				promo.getPromoDetails().getDesc().size() > 0 
				&& promo.getPromoDetails().getDesc().get(0).getValue() != null) {
			if (promorelPromoDetails.getTitle() != null) {
				CompareValuesUtility.compareValues("desc",promo.getPromoDetails().getDesc().get(0).getValue(),promorelPromoDetails.getDesc());
			} else {
				CompareValuesUtility.logFailed("desc", promo.getPromoDetails().getDesc().get(0).getValue(), "desc field not present in promorel collection");
			}
		} else {
			CompareValuesUtility.logFailed("desc", "Not null", "desc field not present in promo collection");
		}

	}

	public PromoGroup getPromoGroup(Promo promo) {
		// Check for finance promo
		if (promo.getPromoDetails().getType() != null && promo.getPromoDetails().getType().trim().equals("Financing"))
			return PromoGroup.FINANCING;

		// Check for El5FreeShipping Promos
		if (promo.getPromoIds().getMarkdownCodeName() != null && promo.getPromoIds().getMarkdownCodeName().equals("EI5FreeShip")) 
			return PromoGroup.MISC;
		
		// Check if it has promo code
		String promoCode = promo.getPromoDetails().getCode();
		if (promoCode != null && !promoCode.equals("")) {
			switch (promoCode.trim()) {
			case "SHIPVANTAGEPROMO":
				return PromoGroup.SYWMAX;
			case "NOSPECIALFINANCEPROMO":
				return PromoGroup.INSTSAVINGS;
			case "BILLINGFREEDELIVERY":
				return PromoGroup.BILLFREEDELIVERY;
			case "SYWRXRPROMOCODE":
				return PromoGroup.SYWRDMPT;
			}
		}

		// Check for member group
		List<String> memberGrpList = promo.getClassification().getMemberGrp();
		if (memberGrpList != null 
				&& memberGrpList.size()>0 
				&&  !memberGrpList.get(0).equals("")) {
			switch (memberGrpList.get(0).trim()) {
			case "SYWR Member GROUP":
				return PromoGroup.SYWMBR;
			case "Sears Craftsman Club Member Group":
				return PromoGroup.CRAFTCLB;
			}
		}

		// Check for coupons
		if (promo.getPromoDetails().getCode() != null) {
			String reservedPromoCodes = "SEARSCARDPROMO|KIOSKPROMO|DEALERPROMO|RETRYPROMO|BILLINGFREEDELIVERY|MOBILEPOSPROMOCODE|NOSPECIALFINANCEPROMO|MGSOCIALCLICK|PD4FREE|THRESHOLD25|THRESHOLDSYWMAX25|THRESHOLD39|THRESHOLDSYWMAX39|THRESHOLD49|THRESHOLDSYWMAX49|THRESHOLD59|THRESHOLDSYWMAX59|THRESHOLD79|THRESHOLDSYWMAX79|THRESHOLD0";
			for (String code : reservedPromoCodes.split("|")) {
				if (code.equals(promo.getPromoIds().getMarkdownCodeName()))
					return PromoGroup.COUPON;
			}
			
			if (promo.getPromoIds().getMarkdownCodeName() != null && promo.getPromoIds().getMarkdownCodeName().trim().equals("Sitewide") 
					&& promo.getClassification().getMemberGrp() != null && promo.getClassification().getMemberGrp().size() > 1) {
				return PromoGroup.COUPON;
			}
			
			return PromoGroup.MISC;
		}
		
		if (promo.getPromoDetails().getType() != null && promo.getPromoDetails().getType().trim().equals("SYWRPromo")) {
			if (promo.getClassification().getIsAprDeal() != null && promo.getClassification().getIsAprDeal() == true) {
				return PromoGroup.SYWMBR;	
			} else {
				return PromoGroup.COUPON;
			}
		}

		// Check for regular
		if (promo.getPromoDetails().getCode() == null && (promo.getClassification().getMemberGrp() == null || promo.getClassification().getMemberGrp().size() == 0)) {
			return PromoGroup.REGULAR;
		} 
		if (promo.getClassification().getIsAprDeal()!=null 
				&& promo.getClassification().getIsAprDeal() == true
				&& !promo.getPromoDetails().getType().trim().equals("SYWRPromo")) {
			return PromoGroup.REGULAR;
		}

		// If nothing is matched, it must be MISC
		return PromoGroup.MISC;
	}

	private boolean isValidMessage() throws Exception {
		JsonObject jMessage = null;

		try {
			// Check for valid json message
			try {
				jMessage = (JsonObject) new JsonParser().parse(this.message);
			} catch (Exception e) {
				throw new Exception("Message is not correct json: "+ this.message);
			}

			// Verify all header fields
			if (jMessage.get("header") != null) {
				JsonObject jHeader = jMessage.get("header").getAsJsonObject();
				// Verify all required fields are available
				if (jHeader.get("ver")==null || (jHeader.get("ver").getAsString()).equals(""))
					throw new Exception("ver tag is missing or has blank value "+jHeader);
				if (jHeader.get("msgId")==null || (jHeader.get("msgId").getAsString()).equals(""))
					throw new Exception("msgId tag is missing or has blank value "+jHeader);
				if (jHeader.get("modifiedDtm")==null || (modifiedDtm=jHeader.get("modifiedDtm").getAsString()).equals(""))
					throw new Exception("modifiedDtm tag is missing or has blank value "+jHeader);
			} else {
				throw new Exception("Header data is missing "+jMessage);
			}

			// Verify all promorel fields
			String itemId,acctId,pgmType = null,dartPartNo,removeAllPromo,promoId, promoType, mode;
			JsonArray jPromoArr = null;

			if (jMessage.get("promorel") != null) {
				JsonArray jPromorelArr = jMessage.get("promorel").getAsJsonArray();

				if (jPromorelArr.size()>0) {
					for(int i=0; i<jPromorelArr.size(); i++) {
						if (jPromorelArr.get(i).getAsJsonObject() != null) {
							JsonObject itemData = jPromorelArr.get(i).getAsJsonObject();

							// check item id
							if (itemData.get("itemId") == null || (itemId=itemData.get("itemId").getAsString()).equals("")) {
								throw new Exception("itemId is missing or blank: " +itemData.toString());
							}

							// check account Id
							if (itemData.get("accountId") == null || (acctId=itemData.get("accountId").getAsString()).equals("")) {
								throw new Exception("accountId is missing or blank: " +itemData.toString());
							}

							// check prgm
							if (itemData.get("prgm") == null || (pgmType=itemData.get("prgm").getAsString()).equals("")) {
								throw new Exception("prgm is missing or blank: " +itemData.toString());
							}

							// check dartPartNo if prgm=FBS
							if (pgmType.equals("FBS")) {
								if (itemData.get("dartPartNbr") == null || (dartPartNo=itemData.get("dartPartNbr").getAsString()).equals("")) {
									throw new Exception("dartPartNbr is missing or blank for FBS item: " +itemData.toString());
								}	
							}

							// Check if activePromo is not available when removeAllPromo=false/null
							if (itemData.get("remoAllPromo") == null || (removeAllPromo=itemData.get("removeAllPromo").getAsString()).equals("false")) 
							{
								if (itemData.get("activePromo") == null || (jPromoArr=itemData.get("activePromo").getAsJsonArray()).size()==0 ||itemData.get("activeSYWPromo") != null || (jPromoArr=itemData.get("activePromo").getAsJsonArray()).size()>0 ) 
								{
									/*String value = JsonStringParser.getJsonValueNew(message, "promorel", true);
									JsonArray itemsArr = new JsonParser().parse(value).getAsJsonArray();

									for(int ii=0; ii<itemsArr.size(); ii++) {
										JsonObject jItem = itemsArr.get(ii).getAsJsonObject();
										
										if(jItem.get("activeSYWPromo") != null)
										{
											sywPointJsonElement = jItem.get("activeSYWPromo");				
											sywPointArray = sywPointJsonElement.getAsJsonArray();
										}
									}
										
									checkSYWPointPromo();*/
								}
								else if(itemData.get("activePromo") == null || (jPromoArr=itemData.get("activePromo").getAsJsonArray()).size()==0 ||itemData.get("activeSYWPromo") == null || (jPromoArr=itemData.get("activePromo").getAsJsonArray()).size() == 0)
								{
									throw new Exception("activePromo is missing or blank: " +itemData.toString());
								}
								else {
									// Check for each promo
									for(int j=0; j<jPromoArr.size(); j++) {
										if (jPromoArr.get(j).getAsJsonObject() != null) {
											JsonObject promoData = jPromoArr.get(j).getAsJsonObject();

											// check promo Id
											if (promoData.get("promoId") == null || (promoId=promoData.get("promoId").getAsString()).equals("")) {
												throw new Exception("promoId is missing or blank: " +itemData.toString());
											}

											// check promoType
											if (promoData.get("promoType") == null || (promoType=promoData.get("promoType").getAsString()).equals("")) {
												throw new Exception("promoType is missing or blank: " +itemData.toString());
											}

											// check mode
											if (promoData.get("mode") == null || (mode=promoData.get("mode").getAsString()).equals("")) {
												throw new Exception("mode is missing or blank: " +itemData.toString());
											}
										} else {
											throw new Exception("activePromo is missing or blank: " +itemData.toString());
										}
									}
								}
							}
						} else {
							throw new Exception("Item info is blank or null : " +jPromorelArr.toString());
						}
					}
				} else {
					throw new Exception("No item present in promorel tag : "+this.message);
				}
			}
			return true;
		} catch (Exception e) {
			throw new Exception("Exception while validating message: "+e.getMessage());
		}
	}

	public void validateInactivePromotion(Promo promo) throws Exception {
		if(!JodaDateTimeUtility.validateDate(promo.getPromoDetails().getStartDt(), promo.getPromoDetails().getEndDt())) {   
			throw new Exception("Inactive Promo");
		}

		if (!promo.getMeta().getStatus().trim().equals("a")) {
			throw new Exception("Promo cannot be pushed since its status is not 'a'");
		}
	}

	public boolean isStaleMessage(Promorel promorelDoc) {
		String Msgtimestamp =JodaDateTimeUtility.convertUnixTSToTZFormat(Long.parseLong(modifiedDtm), "GMT-5:00");
		String promorelUpdateTimestamp = "";
		if(promorelDoc.getMeta().getMsgTs() != null)
		{
			promorelUpdateTimestamp = promorelDoc.getMeta().getMsgTs();
		}
		
		
		
		
		/*if(promorelDoc.getMeta().getLastUpdate() != null)
		{
			promorelUpdateTimestamp = promorelDoc.getMeta().getLastUpdate();
		}
		else
		{
			promorelUpdateTimestamp = promorelDoc.getMeta().getCreate();
		}
		if (promorelDoc.getMeta().getLastModifiedBy() != null) {
			promorelUpdateTimestamp = promorelDoc.getMeta().getLastModifiedBy();
		} else {
			promorelUpdateTimestamp = promorelDoc.getMeta().getCreatedTs();
		}*/
System.out.println("Hi");
		//if(JodaDateTimeUtility.isFirstDateBeforeSecond(promorelUpdateTimestamp,Msgtimestamp))
System.out.println("msg date"+ Msgtimestamp);
System.out.println("promorel date"+ promorelUpdateTimestamp);
if(JodaDateTimeUtility.isFirstDateBeforeSecond(Msgtimestamp,promorelUpdateTimestamp))
			return true;
		return false;
	}

	
	public boolean checkStaleMessage(String itemId)
	{		
		Promorel promorelDoc = null;
		boolean isStale = false;		
System.out.println("Hi");		
		promorelDoc = getPromoRelDoc("sears",itemId);
		if(promorelDoc == null)
		{
			promorelDoc = getPromoRelDoc("kmart",itemId);
			if(promorelDoc == null)
			{
				isStale = false;
			}
			else
			{
				isStale = isStaleMessage(promorelDoc);
			}
				
		}
		else
		{
			isStale = isStaleMessage(promorelDoc);
		}				
		
		return isStale;
	}
	
	
	public void verifyPromotionForOffer(String offerId) {
		HashMap<Promorel, String> promorelMap = new HashMap<>();
		Offer offerDoc = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId).getT(); 

		try {
			CompareValuesUtility.init();
			if (offerDoc != null) {
				// Check for Sears & Kmart Promotions for this offer
				APIResponse<Object> searsPromorelObj = RestExecutor.getAllDataById(CollectionValuesVal.PROMO_REL_NEW, "sears_"+offerId);
				APIResponse<Object> kmartPromorelObj = RestExecutor.getAllDataById(CollectionValuesVal.PROMO_REL_NEW, "kmart_"+offerId);

				if (searsPromorelObj != null && searsPromorelObj.getT() != null) {
					promorelMap.put((Promorel) searsPromorelObj.getT(), "sears_"+offerId);
				}

				if (kmartPromorelObj != null && kmartPromorelObj.getT() != null) {
					promorelMap.put((Promorel) kmartPromorelObj.getT(), "kmart_"+offerId);
				}

				if (promorelMap.size() == 0) {
					// Add message in report that this offer doesn't have any promotion
					System.out.println("Skipped Offer: "+offerId+" (No Promorel Doc Present)");
					CompareValuesUtility.addDataFieldForReport("Reason", "No Promorel Document Present", INFOTYPE.DATA);
				} else {
					verifyPromotions(promorelMap);
					System.out.println("Verified Offer: "+offerId);
				}
			} else {
				throw new Exception("Offer Document Not Present For Offer: "+offerId);
			}
		} catch (Exception e) {
			
			CompareValuesUtility.logFailed("Reason", "", e.getMessage(), "");
		} finally {
			CompareValuesUtility.setupResult(offerId, true);
			CompareValuesUtility.teardown();
		}
	}

	public void verifyPromotions(HashMap<Promorel, String> promorelMap) {
		for (Promorel promorelDoc : promorelMap.keySet()) {
			String promorelId = promorelMap.get(promorelDoc);
			CompareValuesUtility.addDataFieldForReport("PromorelId", promorelId, INFOTYPE.DATA);
			CompareValuesUtility.addDataFieldForReport("Reason", "", INFOTYPE.DATA);
			
			Gson gson = new Gson();
			String promorelJson = gson.toJson(promorelDoc.getPromoList());

			List<String> promoList = getPromoList(promorelJson);
			for (String promoId : promoList) {
				CompareValuesUtility.addDataFieldForReport("Promo", promoId, INFOTYPE.DATA);
				Promo promoDoc = RestExecutor.getAllDataById(CollectionValuesVal.PROMO, promoId).getT();
				if (promoDoc != null) {
					try {
						verifyPromorelData(promoDoc, promorelDoc);
					} catch (Exception e) {
						CompareValuesUtility.addDataFieldForReport("Reason", e.getMessage(), INFOTYPE.FAILED);
					} 
				}
			}
		}
	}

	public List<String> getPromoList(String promorelString) {
		List<String> list = new ArrayList<>();
		JsonObject jsonObj = new JsonParser().parse(promorelString).getAsJsonObject();
		Set<Entry<String, JsonElement>> entrySet = jsonObj.entrySet();
		for (Entry<String, JsonElement> entry : entrySet) {
			JsonArray jsonArr = entry.getValue().getAsJsonArray();
			for (JsonElement jsonElement : jsonArr) {
				JsonObject jsonObj2 = jsonElement.getAsJsonObject();
				String promoId = jsonObj2.get("promoId").getAsString();
				list.add(promoId);
			}
		}
		return list;
	}
}
