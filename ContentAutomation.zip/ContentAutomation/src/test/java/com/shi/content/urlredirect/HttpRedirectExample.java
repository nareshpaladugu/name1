package com.shi.content.urlredirect;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class HttpRedirectExample {

	public static void main(String[] args) {

		test();
	}


	public static void test()
	{


		try {

			URLConnection conn = new URL( "http://www.sears.com/food-grocery-meat--meat-alternatives/s-1039049" ).openConnection();
			System.out.println( "orignal url: " + conn.getURL() );
			conn.connect();
			System.out.println( "connected url: " + conn.getURL() );
			InputStream is = conn.getInputStream();
			System.out.println( "redirected url: " + conn.getURL() );
			is.close();
			
			System.out.println("--------------------------------");
			
			HttpURLConnection con = (HttpURLConnection)(new URL( "http://www.sears.com/food-grocery-meat--meat-alternatives/s-1039049" ).openConnection());
			con.setInstanceFollowRedirects( false );
			con.connect();
			int responseCode = con.getResponseCode();
			System.out.println( responseCode );
			String location = con.getHeaderField( "Location" );
			System.out.println( location );
			
			System.out.println("Done");

		} catch (Exception e) {
			e.printStackTrace();
		}


	}

}