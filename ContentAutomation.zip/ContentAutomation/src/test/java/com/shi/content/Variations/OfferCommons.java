package com.shi.content.Variations;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.generated.vos.offer.Dimensions;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class OfferCommons {

	Offer gbOffer;
	public OfferCommons(Offer gbOffer){
		this.gbOffer = gbOffer;
	}

	public static String escapeNewline(String name){
		if(name==null)
			return name;
		else
		{
			name= name.replaceAll("[\t]", "");
			return name.replaceAll("[\n\r]", " ");
		}
	}
	
	public static String replaceNewline(String name){
		if(name==null)
			return name;
		else
		{
			name= name.replaceAll("[\t]", "");
			return name.replaceAll("[\n\r]", "\n").replaceAll("[\r]", "\n");
		}
	}

	public void verifyIdentity(String ssin, String uid){
		
		if(ssin == null)
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", ssin, gbOffer.getIdentity()== null ? null : gbOffer.getIdentity().getSsin(),"ssin");
			
			if(gbOffer.getIdentity().getPrevSsin() == null)
			{
				CompareValuesUtility.logFailed("Identity", "SSIN not in Feed", "PrevSsin is not set");
			}
			else
			{
				CompareValuesUtility.logPassed("Identity", "SSIN not in Feed", "PrevSsin="+gbOffer.getIdentity().getPrevSsin());
			}
			
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", ssin, gbOffer.getIdentity()== null ? null : gbOffer.getIdentity().getSsin(),"ssin");
		}
		
		CompareValuesUtility.verifyNullOrEqual("Identity", uid, uid==null?null:gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getUid(),"UID");
	}

	public void commonVerifications(String sOfferId, String parentId, String name,boolean plainEncode){
		compareValues("Id", sOfferId,gbOffer.getId());
		compareValues("ParentId", parentId, gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getParentId());
		if(plainEncode)
			compareValues("Name", TestUtils.encodeHTML(escapeNewline(name.trim())), gbOffer.getName());
		else
			compareValues("Name", TestUtils.plainEncodeHTML(escapeNewline(name.trim())), gbOffer.getName());
		//		commonUtils.verifySites(prodContent, gbOffer.getSites());

	}

	public void verifyClassifications(boolean bSingleProductOffer, String... prgrmType){
		compareValues("OfferType",bSingleProductOffer?"NV":"V" , gbOffer.getClassifications().getOfferType());
		if(prgrmType.length > 0 )
			compareValues("isMPPgmType", prgrmType[0], gbOffer.getClassifications().getIsMpPgmType());
		//		CompareValuesUtility.verifyNullOrFalse("isAutomotive", false, gbOffer.getClassifications().getIsAutomotive());		
		//		CompareValuesUtility.verifyNullOrFalse("isUVD", false, gbOffer.getClassifications().getIsUvd());
	}

	public void verifyBrandModel(String brandName,String manufacturerModelNumber) {

		CompareValuesUtility.verifyNullOrEqual("BrandName", TestUtils.plainEncodeHTML(brandName == null?null: brandName.trim()), gbOffer.getBrandName());
		CompareValuesUtility.verifyNullOrEqual("ModelNo", manufacturerModelNumber, gbOffer.getModelNo());

	}

	public void verifyShipping(BigDecimal length,BigDecimal width,BigDecimal height,BigDecimal weight) {

		Dimensions shippingDim = gbOffer.getShipping().getDimensions();
		compareValues("Shipping", height, shippingDim.getHeight(),"Height");
		compareValues("Shipping", width, shippingDim.getWidth(),"Width");
		compareValues("Shipping", length, shippingDim.getLength(),"Length");
		compareValues("Shipping", weight, gbOffer.getShipping().getWeight(),"Weight");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public static List<String> getSellerData(String id,String programtype){

		String sellerDocument = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, id);
		List<String> sellerData = new ArrayList<String>();
		if(!sellerDocument.contains("_blob"))
			return null;
		else{
			sellerData.add(JsonStringParser.getJsonValue(sellerDocument,"[{_blob{seller{programs{"+programtype.toLowerCase()+"{dunsNumber}}}}}]"));
			sellerData.add(JsonStringParser.getJsonValue(sellerDocument,"[{_blob{seller{name}}}]"));
			sellerData.add(JsonStringParser.getJsonValue(sellerDocument,"[{_blob{seller{programs{"+programtype.toLowerCase()+"{wareHouseLocations[locationId]}}}}}]"));
			if(programtype.equals("CPC"))
				sellerData.add(JsonStringParser.getJsonValue(sellerDocument,"[{_blob{seller{programs{"+programtype.toLowerCase()+"{aggregatorId}}}}}]"));
		}
		return sellerData;
	}


}
