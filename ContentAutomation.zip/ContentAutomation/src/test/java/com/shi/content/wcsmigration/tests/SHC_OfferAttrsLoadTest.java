package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.parsers.XMLParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.SHC_OfferAttrsVerifications;

/**
 * @author ddaphal
 *
 */
public class SHC_OfferAttrsLoadTest {

	public static List<String> erroredPartNumbers = new ArrayList<String>();
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="ItemLoadOfferAttrs")
	public void backFillTest(String sFileName)
	{
		System.out.println("Testing file : "+ sFileName);

		if(CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Skipping file since threshold exceeded "+ sFileName);
			return;
		}

		String siteToTest = sFileName.split("\\.")[0].split("-")[1];
		System.out.println(siteToTest);

		String sItemClassId = XMLParser.findNodeValue(sFileName, "catalog", "item-class-id");
		
		BlockingQueue<List<SingleProductOffer>> singleProductOfferQueue = new LinkedBlockingQueue<List<SingleProductOffer>>(500); 

		BlockingQueue<List<VariationProductOffer>> variationProductOfferQueue = new LinkedBlockingQueue<List<VariationProductOffer>>(500);

		ChunkProducerThread<SingleProductOffer> prodThread = new ChunkProducerThread<SingleProductOffer>(sFileName, singleProductOfferQueue, SingleProductOffer.class,"single-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		ChunkProducerThread<VariationProductOffer> prodVariationThread = 
				new ChunkProducerThread<VariationProductOffer>(sFileName, variationProductOfferQueue, VariationProductOffer.class,"variation-product-offer");//, poison);
		prodVariationThread.setBucketSize(1);
		Thread variationProdThread = new Thread(prodVariationThread);
		variationProdThread.start();


		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
					pool.shutdownNow();
					break;
				}
				List<SingleProductOffer> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){
					pool.execute(new SHC_OfferAttrsVerifications(nodeToTest.get(0), null, siteToTest,sItemClassId));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();

			}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else{

			while(true){
				try {
					List<VariationProductOffer> varProdOfferList = variationProductOfferQueue.poll(20, TimeUnit.SECONDS);
					if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
						pool.shutdownNow();
						break;
					}
					if(varProdOfferList == prodVariationThread.POISON_PILL || CompareValuesUtility.getTotalResultsCount() >= LoadProperties.CONSUMER_THREADCOUNT){
						System.out.println("Got poison pill ..breaking out" + varProdOfferList);
						break;
					}
					if(varProdOfferList != null ){
						pool.execute(new SHC_OfferAttrsVerifications(null,varProdOfferList.get(0), siteToTest,sItemClassId));
					}

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else
			pool.shutdown();

		while ((CompareValuesUtility.getFinalResult().getFailedCount() < LoadProperties.FAILURE_THRESHOLD) && !pool.isTerminated()){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Failure count exceed "+ CompareValuesUtility.getFinalResult().getFailedCount());
			pool.shutdownNow();
			CompareValuesUtility.setRunAborted(true);


		}
		System.out.println("Pool terminated "+ pool.isTerminated());
	}
	
	@BeforeClass(groups="ItemLoadOfferAttrs")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			erroredPartNumbers = ErrorPartReader.  getErrorPartsFromLogFile(errorlogFile);
		}

	}
}
