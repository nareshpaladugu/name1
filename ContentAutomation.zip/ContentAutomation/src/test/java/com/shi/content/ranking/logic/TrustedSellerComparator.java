package com.shi.content.ranking.logic;

import java.util.Comparator;

public class TrustedSellerComparator implements Comparator<GBRankBean>{
	public static final TrustedSellerComparator TRUE_LOW = new TrustedSellerComparator(false);
	public static final TrustedSellerComparator TRUE_HIGH = new TrustedSellerComparator(true);
	private final boolean trueLow;
	public TrustedSellerComparator(boolean trueLow) {
	    this.trueLow = trueLow;
	  }
	  public boolean equals(Object obj) {
		    if (this == obj) {
		      return true;
		    }
		    if (!(obj instanceof TrustedSellerComparator)) {
		      return false;
		    }
		    return (this.trueLow == ((TrustedSellerComparator) obj).trueLow);
		  }
	  public int hashCode() {
		    return (this.trueLow ? -1 : 1) * getClass().hashCode();
		  }

		  public String toString() {
		    return "TrustedSellerComparator: " + (this.trueLow ? "true low" : "true high");
		  }
	  
	  
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
	}
		boolean v1 = e1.getTrustedSeller();
	    boolean v2 = e2.getTrustedSeller();
	    return (v1 ^ v2) ? ((v1 ^ this.trueLow) ? 1 : -1) : 0;
	}	

}
