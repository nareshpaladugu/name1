package com.shi.content.storepricing;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.testcommons.FileProviderClass;

public class GBMemberPriceTests {

	HashMap<String, Boolean> storeIds = new HashMap<String, Boolean>();
	String finalId=null;
	StorePricing storePricingGB;

	
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void testGBMemberPrice(String fileName) {

		BlockingQueue<List<String>> singleStoreProductPrice = new LinkedBlockingQueue<List<String>>();
		TextFileParser<String> myParser = new TextFileParser<String>(fileName, singleStoreProductPrice,new StorePricingFileParser());
		Thread t = new Thread(myParser);
		t.start();


		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while (true) {
			List<String> newData;
			try {
				newData = singleStoreProductPrice.poll(20, TimeUnit.SECONDS);
			
				if (newData == myParser.POISON_PILL) {
					break;
				}
				if(newData != null){
					pool.execute(new GBCompareMPFVerification(newData));
					System.out.println("Sent "+ newData);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		
	}

}
