package com.shi.content.matching.prod;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.offer.OfferSchema;
import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class MatchingTestProd 
{
	public static List<String> exceptionVerticals = null;

	public static Set<String> lstOfTestedSSINs = new HashSet<String>();

	@Test(groups="MatchingTestProd",dataProviderClass=ParamBasedDataProvider.class,dataProvider="executionModeBasedDp")
	public void verifyMatching(String sRunParam)
	{
		exceptionVerticals = Arrays.asList(System.getProperty("exceptionVerticals","8").split(","));

		boolean returnFg=false;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.IS_BUCKETBASED_RUN){

			int currentCount = 0;

			List<String> lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER,Integer.parseInt(sRunParam));

			System.out.println("Running for bucket : "+ sRunParam+"  Size "+ lstIdsInBucket.size());

			List<List<String>> subList = Lists.partition(lstIdsInBucket, 25);

			for (List<String> list : subList) {

				List<OfferSchema> offerObjs = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_SCHEMA, list);
				for (OfferSchema offerSchema : offerObjs) {

					if(offerSchema.getSearch()!=null && offerSchema.getSearch().getSsin()!=null)
					{
						if(!lstOfTestedSSINs.contains(offerSchema.getSearch().getSsin()))
						{
							if(LoadProperties.TESTDATALIMIT > 0 && ++currentCount > LoadProperties.TESTDATALIMIT)
							{
								returnFg=true;
								break;
							}

							lstOfTestedSSINs.add(offerSchema.getSearch().getSsin());
							pool.execute(new MatchingTestVerificationProd(offerSchema.getSearch().getSsin()));	
						}
					}
				}

				if(returnFg)
					break;
			}
		}
		else
		{
			if(LoadProperties.RUN_PARAMS.isEmpty())
			{
				LoadProperties.setCustomMsgForEmail("RunParams need to be specified in list mode",MSGTYPE.ERROR);
				return;
			}

			pool.execute(new MatchingTestVerificationProd(sRunParam));	
		}


		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

		System.out.println("END of Test !");
	}
}