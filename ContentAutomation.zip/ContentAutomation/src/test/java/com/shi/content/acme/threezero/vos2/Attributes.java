
package com.shi.content.acme.threezero.vos2;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Generated("org.jsonschema2pojo")
public class Attributes {

    @Expose
    private Integer FBM;
    @Expose
    private Integer SEARS;
    @Expose
    private Integer UVD;
    @Expose
    private Integer forceSsin;
    @Expose
    private Integer selectedContent;
    @Expose
    private Integer KMART;
    @Expose
    private Integer DSS;
    @Expose
    private Integer FBS;
    @Expose
    private Integer preferredContent;

    /**
     * 
     * @return
     *     The FBM
     */
    public Integer getFBM() {
        return FBM;
    }

    /**
     * 
     * @param FBM
     *     The FBM
     */
    public void setFBM(Integer FBM) {
        this.FBM = FBM;
    }

    /**
     * 
     * @return
     *     The SEARS
     */
    public Integer getSEARS() {
        return SEARS;
    }

    /**
     * 
     * @param SEARS
     *     The SEARS
     */
    public void setSEARS(Integer SEARS) {
        this.SEARS = SEARS;
    }

    /**
     * 
     * @return
     *     The UVD
     */
    public Integer getUVD() {
        return UVD;
    }

    /**
     * 
     * @param UVD
     *     The UVD
     */
    public void setUVD(Integer UVD) {
        this.UVD = UVD;
    }

    /**
     * 
     * @return
     *     The forceSsin
     */
    public Integer getForceSsin() {
        return forceSsin;
    }

    /**
     * 
     * @param forceSsin
     *     The forceSsin
     */
    public void setForceSsin(Integer forceSsin) {
        this.forceSsin = forceSsin;
    }

    /**
     * 
     * @return
     *     The selectedContent
     */
    public Integer getSelectedContent() {
        return selectedContent;
    }

    /**
     * 
     * @param selectedContent
     *     The selectedContent
     */
    public void setSelectedContent(Integer selectedContent) {
        this.selectedContent = selectedContent;
    }

    /**
     * 
     * @return
     *     The KMART
     */
    public Integer getKMART() {
        return KMART;
    }

    /**
     * 
     * @param KMART
     *     The KMART
     */
    public void setKMART(Integer KMART) {
        this.KMART = KMART;
    }

    /**
     * 
     * @return
     *     The DSS
     */
    public Integer getDSS() {
        return DSS;
    }

    /**
     * 
     * @param DSS
     *     The DSS
     */
    public void setDSS(Integer DSS) {
        this.DSS = DSS;
    }

    /**
     * 
     * @return
     *     The FBS
     */
    public Integer getFBS() {
        return FBS;
    }

    /**
     * 
     * @param FBS
     *     The FBS
     */
    public void setFBS(Integer FBS) {
        this.FBS = FBS;
    }

    /**
     * 
     * @return
     *     The preferredContent
     */
    public Integer getPreferredContent() {
        return preferredContent;
    }

    /**
     * 
     * @param preferredContent
     *     The preferredContent
     */
    public void setPreferredContent(Integer preferredContent) {
        this.preferredContent = preferredContent;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
