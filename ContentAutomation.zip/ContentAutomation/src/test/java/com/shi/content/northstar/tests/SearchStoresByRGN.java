package com.shi.content.northstar.tests;


import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.ICCEStores;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
* Test search by rgn
* @author inaikwa
* 
*/
public class SearchStoresByRGN extends NorthStarBaseTest {

	private ArrayList<String> listStoreIds;
	
	@Test(description="Test to verify search by store number ", groups = {"NS-P1"})
	public void testSearchByStore() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();
	
		searchPage.searchByStoreNumber("0005157");
		
		listStoreIds= searchPage.getAllStoreIds();
		
		System.out.println("\nonline "+listStoreIds.size());
	
		System.out.println(listStoreIds);
		
		String sStores =  RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, "0005157"); 

		String type =JsonStringParser.getJsonValueNew(sStores, "_blob.unit.id");

		Asserts.verifyEquals(listStoreIds.get(0), type.replaceAll("\"", ""), "Stores fecthed are equal to stores displayed");

	
	}
	
}