package com.shi.content.ranking.logic;
import java.io.Serializable;
import java.util.Comparator;

public class ItemWebStatusComparator implements Comparator<GBRankBean> ,Serializable{
	public static final ItemWebStatusComparator TRUE_LOW = new ItemWebStatusComparator(false);
	public static final ItemWebStatusComparator TRUE_HIGH = new ItemWebStatusComparator(true);
	private final boolean trueLow;
	public ItemWebStatusComparator(boolean trueLow) {
	    this.trueLow = trueLow;
	  }
	 /* public boolean equals(Object obj) {
		    if (this == obj) {
		      return true;
		    }
		    if (!(obj instanceof ItemStockComparator)) {
		      return false;
		    }
		    return (this.trueLow == ((ItemStockComparator) obj).trueLow);
		  }
	  public int hashCode() {
		    return (this.trueLow ? -1 : 1) * getClass().hashCode();
		  }

		  public String toString() {
		    return "ItemStockComparator: " + (this.trueLow ? "true low" : "true high");
		  }*/
	  
	  
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
	}
		boolean v1 = e1.getWebStatus();
	    boolean v2 = e2.getWebStatus();
	    return (v1 ^ v2) ? ((v1 ^ this.trueLow) ? 1 : -1) : 0;
	}	

}

