package com.shi.content.ranking.logic;

import java.util.Comparator;

public class ItemConditionComparator implements Comparator<GBRankBean>{
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
		}
		return e1.getItemCondition().compareTo(e2.getItemCondition());
	}

}
