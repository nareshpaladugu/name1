package com.shi.content.ranking.logic;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.generated.vos.rankingauto.Offer;
import com.generated.vos.rankingauto.RankingResponseFull;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shi.content.ranking.RankingDataExtractor;
import com.shi.content.ranking.RankingTest;
public class CompareResponses {

	final float BONUS_POINTS_VALUE = 0.0004f;
	//Map<String, String> offerToRankMap = new LinkedHashMap<String, String>();

	//static final Logger LOG = (Logger) LoggerFactory.getLogger("analytics");


	private boolean checkMissingOffersInErrortag(List<GBRankBean> qaRank,RankingResponseFull buyboxRank) {
		boolean bFound = false;
		int count=0;
		//TBD for multiple offers condition where one is there another is not  there
		List<String> errorOffer = buyboxRank.getGroups().get(0).getErrors().getPrice();

		if (errorOffer.size() > 0) {

			for (int i = 0; i < errorOffer.size(); i++) {

				for (int j = 0; j < qaRank.size(); j++) {

					String gbPartnumber = qaRank.get(j).getPartnumber().toString();

					if (gbPartnumber.equalsIgnoreCase(errorOffer.get(i))) {

						if(qaRank.get(j).getPrice()==0.0){
							CompareValuesUtility.compareValues("Price Error",gbPartnumber,errorOffer.get(i).toString().replaceAll("[^a-zA-Z0-9]",""));

							count++;
						}
					}
				}
			}

		}else{

			Set<String> expectedParts= new HashSet<>();

			for (GBRankBean gbRankBean : qaRank) {
				expectedParts.add(gbRankBean.getPartnumber());
			}

			Set<String> actualParts= new HashSet<>();

			for (Offer gbRankBean : buyboxRank.getGroups().get(0).getOffers()) {
				actualParts.add(gbRankBean.getId());
			}

			for (String string : expectedParts) {

				if(!actualParts.contains(string))
				{
					CompareValuesUtility.logFailed("Part Number in Group", string, "Not Found");
				}

			}

		}


		if(count==errorOffer.size()) bFound=true; // all error offers captured

		return bFound;
	}


	public void CompareRankResponses(List<GBRankBean> qaRank,RankingResponseFull buyboxRank, String sUID) {
		
		if(qaRank.size()>=buyboxRank.getGroups().get(0).getOffers().size()){

			if(qaRank.size()>buyboxRank.getGroups().get(0).getOffers().size()){

				checkMissingOffersInErrortag(qaRank,buyboxRank);

			}

			Integer offerCount = getOfferCount(qaRank);

			ItemConditionBean objLowestPrice = (isAllCpcGroup(qaRank)||hasMapViolation(qaRank))? null : getLowestPrice(qaRank,buyboxRank);
			

			CompareValuesUtility.compareValues("isOpen", true, buyboxRank.getGroups().get(0).getIsOpen());
			CompareValuesUtility.compareValues("isSearsGroup", isSearsGroup(qaRank), buyboxRank.getGroups().get(0).getIsSearsGroup());	
			CompareValuesUtility.compareValues("isKmartGroup", isKmartGroup(qaRank), buyboxRank.getGroups().get(0).getIsKmartGroup());
			CompareValuesUtility.verifyNullOrEqual("lowestPrice", objLowestPrice == null ? null : round(objLowestPrice.getLowestPrice(),2), buyboxRank.getGroups().get(0).getLowestPrice()==null?null:roundToTwoDecimal(buyboxRank.getGroups().get(0).getLowestPrice().toString()));
			if(RankingTest.itemConditionFlag)
			{	
				ItemConditionBean rankingResponseLowestPriceAll =getRankingResponseLowestPrice(sUID);
				ItemConditionBean lowestPriceAll = getLowestPrice(qaRank,buyboxRank);
				
				CompareValuesUtility.verifyNullOrEqual("lowestPriceNew", round(lowestPriceAll.getLowestPriceNew(),2), round(rankingResponseLowestPriceAll.getLowestPriceNew(),2));
				CompareValuesUtility.verifyNullOrEqual("lowestPriceRefurbished", round(lowestPriceAll.getLowestPriceRefurbished(),2), round(rankingResponseLowestPriceAll.getLowestPriceRefurbished(),2));
				CompareValuesUtility.verifyNullOrEqual("RefurbishedOfferId", lowestPriceAll.getRefurbishedOfferId() , rankingResponseLowestPriceAll.getRefurbishedOfferId());
				CompareValuesUtility.verifyNullOrEqual("lowestPriceUsed", round(lowestPriceAll.getLowestPriceUsed(),2) , round(rankingResponseLowestPriceAll.getLowestPriceUsed(),2));
				CompareValuesUtility.verifyNullOrEqual("UsedOfferId", lowestPriceAll.getUsedOfferId(), rankingResponseLowestPriceAll.getUsedOfferId());
				CompareValuesUtility.verifyNullOrEqual("Offers_count_new", lowestPriceAll.getOffers_count_new(), rankingResponseLowestPriceAll.getOffers_count_new());
				CompareValuesUtility.verifyNullOrEqual("Offers_count_refurbished", lowestPriceAll.getOffers_count_refurbished(), rankingResponseLowestPriceAll.getOffers_count_refurbished());
				CompareValuesUtility.verifyNullOrEqual("Offers_count_used", lowestPriceAll.getOffers_count_used(), rankingResponseLowestPriceAll.getOffers_count_used());
			}
			CompareValuesUtility.compareValues("offers_found", offerCount, buyboxRank.getGroups().get(0).getOffersFound().intValue());

			for (int i = 0; i < qaRank.size(); i++) {
				String gbPartnumber = qaRank.get(i).getPartnumber().toString();
				Integer gbRank = qaRank.get(i).getRank();
				for (int j = 0; j < buyboxRank.getGroups().get(0).getOffers().size(); j++) {
					String bbPartnumber = buyboxRank.getGroups().get(0).getOffers().get(j).getId().toString();
					if (gbPartnumber.equalsIgnoreCase(bbPartnumber)) {

						CompareValuesUtility.addDataFieldForReport("Offerid", bbPartnumber);

						Integer bbRank = Integer.parseInt(buyboxRank.getGroups().get(0).getOffers().get(j).getRank());

						if (gbRank == bbRank) {

							CompareValuesUtility.logPassed("Rank", gbRank, bbRank);
							CompareValuesUtility.addDataFieldForReport("TieBreakRanks","");
							CompareValuesUtility.compareValues("storeName", qaRank.get(i).getStoreName().toUpperCase(), buyboxRank.getGroups().get(0).getOffers().get(j).getStoreName().toUpperCase());
							CompareValuesUtility.compareValues("sellerTier", qaRank.get(i).getSellerTier(), buyboxRank.getGroups().get(0).getOffers().get(j).getSellerTier());
							CompareValuesUtility.verifyNullOrEqual("sellerStoreUrl", qaRank.get(i).getSellerStoreUrl(), buyboxRank.getGroups().get(0).getOffers().get(j).getSellerStoreUrl());
							//							if (Boolean.valueOf(LoadProperties.LOCALADFLAG))
							CompareValuesUtility.verifyNullOrEqual("metaPriceType", qaRank.get(i).getPriceType(), buyboxRank.getGroups().get(0).getOffers().get(j).getPriceType());
							CompareValuesUtility.compareValues("condition", qaRank.get(i).getItemCondition(), buyboxRank.getGroups().get(0).getOffers().get(j).getCondition());
							CompareValuesUtility.compareValues("conditionString", qaRank.get(i).getConditionString().toLowerCase(), buyboxRank.getGroups().get(0).getOffers().get(j).getConditionString().toLowerCase());
							if(RankingTest.itemConditionFlag)
							{
								CompareValuesUtility.compareValues("conditionDispName", qaRank.get(i).getConditionDispName(), buyboxRank.getGroups().get(0).getOffers().get(j).getConditionDisplayName());
							}
							CompareValuesUtility.compareValues("webStatus", qaRank.get(i).getWebStatus(), buyboxRank.getGroups().get(0).getOffers().get(j).getWebStatus());
							CompareValuesUtility.compareValues("availability", qaRank.get(i).getInstock()?"1":"0", buyboxRank.getGroups().get(0).getOffers().get(j).getAvailability());
							CompareValuesUtility.compareValues("spuEligible", qaRank.get(i).getSpuEligible(), buyboxRank.getGroups().get(0).getOffers().get(j).getSpuEligible());
							CompareValuesUtility.compareValues("sresEligible", qaRank.get(i).getSresEligible(), buyboxRank.getGroups().get(0).getOffers().get(j).getSresEligible());
							CompareValuesUtility.compareValues("categoryConfidence", qaRank.get(i).getConfidenceScore(), buyboxRank.getGroups().get(0).getOffers().get(j).getCategoryConfidence());
							if(RankingTest.dbBonusPointsFlag)
							{
									CompareValuesUtility.compareValues("bonusPoints", qaRank.get(i).getBonusPoints() == null ? 0 : qaRank.get(i).getBonusPoints() , buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints() == null ? 0 : Float.parseFloat(buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints()));
							}
							float bonusPointPrice = buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints() == null ? 0 : Float.parseFloat(buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints())*BONUS_POINTS_VALUE;
							CompareValuesUtility.compareValues("totalPrice", round(qaRank.get(i).getPrice()+bonusPointPrice,2).toString(), roundToTwoDecimal(buyboxRank.getGroups().get(0).getOffers().get(j).getTotalPrice()));

							if((qaRank.get(i).getShipPrice()==null || qaRank.get(i).getShipPrice().equals(0d))
									&& (buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice()==null || 
									buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice().equals("0") ||
									buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice().equals("0.0")))
								CompareValuesUtility.logPassed("shippingPrice", qaRank.get(i).getShipPrice()==null?"null":qaRank.get(i).getShipPrice()
										, buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice()==null?"null":buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice());
							else
								CompareValuesUtility.verifyNullOrEqual("shippingPrice", qaRank.get(i).getShipPrice(), buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice());

							CompareValuesUtility.compareValues("trustedSeller", qaRank.get(i).getTrustedSeller()?"1":"0", buyboxRank.getGroups().get(0).getOffers().get(j).getTrustedSeller());
							CompareValuesUtility.verifyNullOrEqual("soptDays", qaRank.get(i).getStoreName().toUpperCase().equalsIgnoreCase("CPC")?null:qaRank.get(i).getSopt().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getSoptDays());
							CompareValuesUtility.verifyNullOrEqual("transitDays", qaRank.get(i).getTransitDays()==null?null:qaRank.get(i).getTransitDays().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getTransitDays());
							CompareValuesUtility.verifyNullOrEqual("totalTransitDays",  qaRank.get(i).getStoreName().toUpperCase().equalsIgnoreCase("CPC")?null:qaRank.get(i).getTotalTransitDays().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getTotalTransitDays());
							CompareValuesUtility.verifyNullOrEqual("mapViolation", qaRank.get(i).getMapViolation(), buyboxRank.getGroups().get(0).getOffers().get(j).getMapViolation());
							break;
						}else {

							if(buyboxRank.getGroups().get(0).getTiebreakranks()!=null 
									&& buyboxRank.getGroups().get(0).getTiebreakranks().contains(gbRank.toString())){
								CompareValuesUtility.logPassed("Rank", gbRank, bbRank);
								CompareValuesUtility.addDataFieldForReport("TieBreakRanks",buyboxRank.getGroups().get(0).getTiebreakranks());
							}else{
								CompareValuesUtility.compareValues("Rank", gbRank, bbRank);
								CompareValuesUtility.addDataFieldForReport("TieBreakRanks","");
							}

							CompareValuesUtility.compareValues("storeName", qaRank.get(i).getStoreName().toUpperCase(), buyboxRank.getGroups().get(0).getOffers().get(j).getStoreName().toUpperCase());
							CompareValuesUtility.compareValues("sellerTier", qaRank.get(i).getSellerTier(), buyboxRank.getGroups().get(0).getOffers().get(j).getSellerTier());
							//if (LoadProperties.LOCALADFLAG.equals("true"))
							CompareValuesUtility.verifyNullOrEqual("sellerStoreUrl", qaRank.get(i).getSellerStoreUrl(), buyboxRank.getGroups().get(0).getOffers().get(j).getSellerStoreUrl());
							CompareValuesUtility.verifyNullOrEqual("metaPriceType", qaRank.get(i).getPriceType(), buyboxRank.getGroups().get(0).getOffers().get(j).getPriceType());
							CompareValuesUtility.compareValues("condition", qaRank.get(i).getItemCondition(), buyboxRank.getGroups().get(0).getOffers().get(j).getCondition());
							CompareValuesUtility.compareValues("conditionString", qaRank.get(i).getConditionString().toLowerCase(), buyboxRank.getGroups().get(0).getOffers().get(j).getConditionString().toLowerCase());
							if(RankingTest.itemConditionFlag)
							{
								CompareValuesUtility.compareValues("conditionDispName", qaRank.get(i).getConditionDispName(), buyboxRank.getGroups().get(0).getOffers().get(j).getConditionDisplayName());
							}
							CompareValuesUtility.compareValues("webStatus", qaRank.get(i).getWebStatus(), buyboxRank.getGroups().get(0).getOffers().get(j).getWebStatus());
							CompareValuesUtility.compareValues("availability", qaRank.get(i).getInstock()?"1":"0", buyboxRank.getGroups().get(0).getOffers().get(j).getAvailability());
							CompareValuesUtility.compareValues("spuEligible", qaRank.get(i).getSpuEligible(), buyboxRank.getGroups().get(0).getOffers().get(j).getSpuEligible());
							CompareValuesUtility.compareValues("sresEligible", qaRank.get(i).getSresEligible(), buyboxRank.getGroups().get(0).getOffers().get(j).getSresEligible());
							CompareValuesUtility.compareValues("categoryConfidence", qaRank.get(i).getConfidenceScore().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getCategoryConfidence());
							if(RankingTest.dbBonusPointsFlag)
							{
									CompareValuesUtility.compareValues("bonusPoints", qaRank.get(i).getBonusPoints() == null ? 0 : qaRank.get(i).getBonusPoints() , buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints() == null ? 0 : Float.parseFloat(buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints()));
							}
							float bonusPointPrice = buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints() == null ? 0 : Float.parseFloat(buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints())*BONUS_POINTS_VALUE;
							CompareValuesUtility.compareValues("totalPrice", round(qaRank.get(i).getPrice()+bonusPointPrice,2).toString(), roundToTwoDecimal(buyboxRank.getGroups().get(0).getOffers().get(j).getTotalPrice()));

							if((qaRank.get(i).getShipPrice()==null || qaRank.get(i).getShipPrice().equals(0d))
									&& (buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice()==null || 
									buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice().equals("0") ||
									buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice().equals("0.0")))
								CompareValuesUtility.logPassed("shippingPrice", qaRank.get(i).getShipPrice()==null?"null":qaRank.get(i).getShipPrice()
										, buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice()==null?"null":buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice());
							else
								CompareValuesUtility.verifyNullOrEqual("shippingPrice", qaRank.get(i).getShipPrice(), buyboxRank.getGroups().get(0).getOffers().get(j).getShippingPrice());
							
							CompareValuesUtility.compareValues("trustedSeller", qaRank.get(i).getTrustedSeller()?"1":"0", buyboxRank.getGroups().get(0).getOffers().get(j).getTrustedSeller());
							CompareValuesUtility.verifyNullOrEqual("soptDays", qaRank.get(i).getSopt() == null ? null : qaRank.get(i).getSopt().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getSoptDays());
							CompareValuesUtility.verifyNullOrEqual("transitDays", qaRank.get(i).getTransitDays()==null?null:qaRank.get(i).getTransitDays().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getTransitDays());							
							CompareValuesUtility.verifyNullOrEqual("totalTransitDays", qaRank.get(i).getTotalTransitDays() == null ? null : qaRank.get(i).getTotalTransitDays().toString(), buyboxRank.getGroups().get(0).getOffers().get(j).getTotalTransitDays());
							CompareValuesUtility.verifyNullOrEqual("mapViolation", qaRank.get(i).getMapViolation(), buyboxRank.getGroups().get(0).getOffers().get(j).getMapViolation());
							
							//CompareValuesUtility.addDataFieldForReport("GBData", qaRank.get(i).toString());
							//CompareValuesUtility.addDataFieldForReport("IFTData", buyboxRank.getGroups().get(0).getOffers().get(j).toString());
							//System.out.println("QA Calculated Rank : " + qaRank.toString());
							//System.out.println("Buybox Rank : "+ buyboxRank.toString());
							break;
						}
					}
				}
			}
			//System.out.println("Thank GOD No Ranking Issues for uid :" + buyboxRank.getGroups().get(0).getId());
		}else
		{

			Set<String> expectedParts= new HashSet<>();

			for (GBRankBean gbRankBean : qaRank) {
				expectedParts.add(gbRankBean.getPartnumber());
			}

			Set<String> actualParts= new HashSet<>();

			for (Offer gbRankBean : buyboxRank.getGroups().get(0).getOffers()) {
				actualParts.add(gbRankBean.getId());
			}

			for (String string : actualParts) {

				//(2) finding unexpected parts
				if(!expectedParts.contains(string))
				{
					CompareValuesUtility.logFailed("Part Number in Group", string, "Not Expected");
				}
			}

			CompareValuesUtility.logFailed("Number of Items in Group", expectedParts.size(), actualParts.size());


			//			System.out.println("Number of Items not Matching."  + buyboxRank.getGroups().get(0).getId());
		}
	}




	private boolean hasMapViolation(List<GBRankBean> qaRank) {
		boolean hasMapVioltn = false;
		/*Loop through all valid items and check if atleast one Map violated offer is present*/
		for(GBRankBean q : qaRank){
			if(q.getRank()!=-1 && q.getMapViolation()){
				hasMapVioltn = true;
				break;
			}
		}
		return hasMapVioltn;
	}

	private boolean isSearsGroup(List<GBRankBean> qaRank) {
		boolean isSearsGrp = false;
		/*Loop through all valid items and check if atleast one Sears offer is present*/
		//if(q.getRank()!=-1 && q.getStoreName().equals("Sears") || q.getRank()!=-1 && q.getStoreName().equals("SEARS")){
		for(GBRankBean q : qaRank){
			if(q.getStoreName().equals("Sears") || q.getStoreName().equals("SEARS")){
				isSearsGrp = true;
				break;
			}
		}
		return isSearsGrp;
	}

	private boolean isKmartGroup(List<GBRankBean> qaRank) {
		boolean isKmartGrp = false;
		/*Loop through all valid items and check if atleast one Sears offer is present*/
		//if(q.getRank()!=-1 && q.getStoreName().equals("Sears") || q.getRank()!=-1 && q.getStoreName().equals("SEARS")){
		for(GBRankBean q : qaRank){
			if(q.getStoreName().equals("Kmart") || q.getStoreName().equals("KMART")){
				isKmartGrp = true;
				break;
			}
		}
		return isKmartGrp;
	}

	private boolean isAllCpcGroup(List<GBRankBean> qaRank) {
		boolean isAllCpc = true;
		/*Loop through all valid items and check if atleast one non-CPC offer is present*/
		for(GBRankBean q : qaRank){
			if(q.getRank()!=-1 && q.getStorePriority()==0){
				isAllCpc = false;
				break;
			}
		}
		return isAllCpc;
	}

	private ItemConditionBean getLowestPrice(List<GBRankBean> qaRank, RankingResponseFull buyboxRank) 
	{
		ItemConditionBean lowestPriceAll = new ItemConditionBean();
		
		GBRankUid objGB = new GBRankUid();
	//		Float.parseFloat(buyboxRank.getGroups().get(0).getOffers().get(j).getBonusPoints())*BONUS_POINTS_VALUE;
		/*Assign first valid non-CPC item's price as lowestPrice*/

		for(GBRankBean q : qaRank){
			float bonusPointPrice = objGB.getBonusPoints(buyboxRank, q.getPartnumber()) * BONUS_POINTS_VALUE;
			if(q.getRank()!=-1 && q.getStorePriority()==0 && (q.getPrice()+bonusPointPrice) !=0){
				lowestPriceAll.setLowestPrice((float) (q.getPrice() + bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));

				break;
			}
		}
		if(RankingTest.itemConditionFlag)
		{
			for(GBRankBean q : qaRank){
				float bonusPointPrice = objGB.getBonusPoints(buyboxRank, q.getPartnumber()) * BONUS_POINTS_VALUE;
				if(q.getConditionString().startsWith("N") && q.getRank()!=-1 && q.getStorePriority()==0 && (q.getPrice()+bonusPointPrice) !=0){
					lowestPriceAll.setLowestPriceNew((float) (q.getPrice() + bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
					break;
				}
			}
			for(GBRankBean q : qaRank){
				float bonusPointPrice = objGB.getBonusPoints(buyboxRank, q.getPartnumber()) * BONUS_POINTS_VALUE;
				if( q.getConditionString().startsWith("U") && q.getRank()!=-1 && q.getStorePriority()==0 && (q.getPrice()+bonusPointPrice) !=0){
					lowestPriceAll.setLowestPriceUsed((float) (q.getPrice() + bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
					lowestPriceAll.setUsedOfferId( q.getPartnumber());
					break;
				}
			}
			for(GBRankBean q : qaRank){
				float bonusPointPrice = objGB.getBonusPoints(buyboxRank, q.getPartnumber()) * BONUS_POINTS_VALUE;
				if(q.getConditionString().startsWith("R") && q.getRank()!=-1 && q.getStorePriority()==0 && (q.getPrice()+bonusPointPrice) !=0){
					lowestPriceAll.setLowestPriceRefurbished( (float) (q.getPrice() + bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
					lowestPriceAll.setRefurbishedOfferId( q.getPartnumber());
					break;
				}
			}
		}
		/*Loop through all valid non-CPC items to find the lowestPrice*/
		for(GBRankBean q : qaRank){
			float bonusPointPrice = objGB.getBonusPoints(buyboxRank, q.getPartnumber()) * BONUS_POINTS_VALUE;
			if( (q.getPrice()+bonusPointPrice) !=0 && q.getRank()!=-1 && q.getStorePriority()==0 && (q.getPrice()+bonusPointPrice-(q.getShipPrice()==null?0:q.getShipPrice())) < lowestPriceAll.getLowestPrice()){
				lowestPriceAll.setLowestPrice( (float) (q.getPrice()+bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
			}
			if(RankingTest.itemConditionFlag)
			{
				if( q.getConditionString().startsWith("N") && (q.getPrice()+bonusPointPrice) !=0 && q.getRank()!=-1 && q.getStorePriority()==0){
					if((q.getPrice()+bonusPointPrice-(q.getShipPrice()==null?0:q.getShipPrice())) < lowestPriceAll.getLowestPriceNew())
						lowestPriceAll.setLowestPriceNew( (float) (q.getPrice()+bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
					lowestPriceAll.setOffers_count_new(lowestPriceAll.getOffers_count_new()+1);
				}
				if( q.getConditionString().startsWith("U") && (q.getPrice()+bonusPointPrice) !=0 && q.getRank()!=-1 && q.getStorePriority()==0 ){
					if((q.getPrice()+bonusPointPrice-(q.getShipPrice()==null?0:q.getShipPrice())) < lowestPriceAll.getLowestPriceUsed())
					{
						lowestPriceAll.setLowestPriceUsed( (float) (q.getPrice()+bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
						lowestPriceAll.setUsedOfferId( q.getPartnumber());
					}
					lowestPriceAll.setOffers_count_used(lowestPriceAll.getOffers_count_used()+1);
				}
				if( q.getConditionString().startsWith("R") && (q.getPrice()+bonusPointPrice) !=0 && q.getRank()!=-1 && q.getStorePriority()==0 ){
					if((q.getPrice()+bonusPointPrice-(q.getShipPrice()==null?0:q.getShipPrice())) < lowestPriceAll.getLowestPriceRefurbished())
					{
						lowestPriceAll.setLowestPriceRefurbished((float) (q.getPrice()+bonusPointPrice - (q.getShipPrice()==null?0:q.getShipPrice())));
						lowestPriceAll.setRefurbishedOfferId(q.getPartnumber());
					}
					lowestPriceAll.setOffers_count_refurbished(lowestPriceAll.getOffers_count_refurbished()+1);
				}
			}
		}
		return lowestPriceAll;
	}
	
	private ItemConditionBean getRankingResponseLowestPrice(String sUID) 
	{
		String rankingResponseJson = RankingDataExtractor.getRankingResponse(sUID);
		List<String> arrayRefurbishedOfferId = new ArrayList<>();
		List<String> arrayUsedOfferId = new ArrayList<>();;
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.refurbishedOfferId").equalsIgnoreCase("null"))
			arrayRefurbishedOfferId = Arrays.asList(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.refurbishedOfferId").split("\""));
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.usedOfferId").equalsIgnoreCase("null"))
			arrayUsedOfferId = Arrays.asList(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.usedOfferId").split("\""));
		
		ItemConditionBean lowestPriceAll = new ItemConditionBean();
	
		if(arrayRefurbishedOfferId.size() >=2)
			lowestPriceAll.setRefurbishedOfferId(arrayRefurbishedOfferId.get(1));
		
		if(arrayUsedOfferId.size() >=2)
			lowestPriceAll.setUsedOfferId(arrayUsedOfferId.get(1));	
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.new").equalsIgnoreCase("null"))
			lowestPriceAll.setLowestPriceNew(Float.parseFloat(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.new")));
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.refurbished").equalsIgnoreCase("null"))
			lowestPriceAll.setLowestPriceRefurbished(Float.parseFloat(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.refurbished")));
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.used").equalsIgnoreCase("null"))
			lowestPriceAll.setLowestPriceUsed(Float.parseFloat(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.lowest_price.used")));
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.new").equalsIgnoreCase("null"))
			lowestPriceAll.setOffers_count_new(Integer.parseInt(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.new")));
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.refurbished").equalsIgnoreCase("null"))
			lowestPriceAll.setOffers_count_refurbished(Integer.parseInt(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.refurbished")));
		
		if(!JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.used").equalsIgnoreCase("null"))
			lowestPriceAll.setOffers_count_used(Integer.parseInt(JsonStringParser.getJsonValueNew(rankingResponseJson, "groups.offers_count.used")));
		
		return lowestPriceAll;		
	}

	private Integer getOfferCount(List<GBRankBean> qaRank) {
		Integer offerCount = 0;

		for(GBRankBean q : qaRank){
			if(q.getRank()!=-1 && q.getPrice()!=0){
				offerCount++;
			}
		}
		return offerCount;
	}
	
	

	private String roundToTwoDecimal(String p) {
		try {
			return p.equals("0")?"0.00":(p.substring(p.indexOf(".")+1).length()==1?p+"0":p);
		}catch (Exception e){
			return p;
		}

	}

	public static BigDecimal round(float d, int decimalPlace) {
		BigDecimal bd = new BigDecimal(Float.toString(d));
		bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);       
		return bd;
	}
}