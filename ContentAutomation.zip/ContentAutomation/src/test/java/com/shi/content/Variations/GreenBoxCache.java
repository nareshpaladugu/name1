package com.shi.content.Variations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.generated.vos.attribute.AttributeSchema;
import com.generated.vos.attribute.Tag;
import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.hierarchy.Path;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class GreenBoxCache 
{

	private static Map<String, Path> mpItemClassToPath = new ConcurrentHashMap<String, Path>();
	private static Map<String, Attrs> mpItemClassToAttrs = new ConcurrentHashMap<String, Attrs>();
	private static Map<String, String> mpAttributeIdToName = new ConcurrentHashMap<String, String>();
	private static Map<String,String> mpDoNotDisplayAttIds = new ConcurrentHashMap<String, String>();
	private static Map<String, String> mpAttributeValToName = new ConcurrentHashMap<String, String>();
	
	/**
	 * Fetches master hierarchy for given itemclass id from saved cache.
	 * If not found in cache, hits the itemclasshierarchy collection to fetch relevant data
	 * 
	 * @param itemClassId
	 * @return
	 */
	public static Path getPathForItemClass(String itemClassId){
		
		if(!mpItemClassToPath.containsKey(itemClassId))
			fetchInfoForItemClassId(itemClassId);

		return mpItemClassToPath.get(itemClassId);
		
	}

	private static void fetchInfoForItemClassId(String itemClassId){
		Hierarchy masterHierarchy = RestExecutor.getDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, itemClassId);
		if(masterHierarchy == null)
			return;
		if( masterHierarchy.getAttrs()!=null)
			mpItemClassToAttrs.put(itemClassId, masterHierarchy.getAttrs());
		mpItemClassToPath.put(itemClassId, masterHierarchy.getPath().get(0));
	}
	
	/**
	 * Fetches attributes for given itemclass id from saved cache.
	 * If not found in cache, hits the itemclasshierarchy collection to fetch relevant data
	 * 
	 * @param itemClassId
	 * @return
	 */
	public static Attrs getAttrsForItemClass(String itemClassId){
		
		if(!mpItemClassToAttrs.containsKey(itemClassId))
			fetchInfoForItemClassId(itemClassId);
		
		return mpItemClassToAttrs.get(itemClassId);
		
	}
	
	/**
	 * Generates map of attribute id to display name.  If attribute collection has already been hit for the attribute,
	 * it is not hit again.
	 * @param attributeIds
	 * @return
	 */
	public static Map<String, String> getAttributeData(List<String> attributeIds){
		

		List<String> attributeList = new ArrayList<>(attributeIds);
		attributeList.removeAll(mpAttributeIdToName.keySet());
		
		Map<String, String> toReturnData = new HashMap<String, String>();
		if(attributeList.size() > 0){
			List<AttributeSchema> allAttributes = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE, attributeList);
			if(allAttributes != null){
				for(AttributeSchema attribute : allAttributes){
					boolean bDoNotDisplay = false;
					for(Tag attribTag: attribute.getTags()){
						if(attribTag.getType().equalsIgnoreCase("donotdisplay"))
						{
							//bDoNotDisplay = true;
							mpDoNotDisplayAttIds.put(attribute.getId(), attribute.getDisplayName());
							break;
						}
							
					}
					if(!bDoNotDisplay)
						mpAttributeIdToName.put(attribute.getId(), attribute.getDisplayName());
				}
			}
		}
		for(String attributeId : attributeIds){
				toReturnData.put(attributeId, mpAttributeIdToName.get(attributeId));
		}
			
		return toReturnData;
	}
	
	public static String isDoNotDisplay(String attributeId){

		if (mpDoNotDisplayAttIds.containsKey(attributeId))
			return mpDoNotDisplayAttIds.get(attributeId);
		else
			return null;
	}

	/**
	 * Fetches attribute Val data.  Hits the Attrvalue collection and fetches name from collection
	 * Builds a static map of attrvalid to name
	 * @param attributeValIds
	 * @return
	 */
	public static Map<String, String> getAttributeValData(List<String> attributeValIds){
	
		List<String> attributeValList = new ArrayList<>(attributeValIds);
		Map<String, String> toReturnData = new HashMap<String, String>();
		
		synchronized (mpAttributeValToName) {
			if(!mpAttributeValToName.isEmpty()){
				attributeValList.removeAll(mpAttributeValToName.keySet());
			}
		}
		
		
		if(attributeValList.size() > 0){
			List<AttributeValueSchema> allAttributesVals = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attributeValIds);
			if(allAttributesVals != null){
				for(AttributeValueSchema attrValue : allAttributesVals){
					mpAttributeValToName.put(attrValue.getId(), attrValue.getDisplayName());
				}
			}
		}
		
		for(String attributeValId : attributeValIds){
				toReturnData.put(attributeValId, mpAttributeValToName.get(attributeValId));
		}
			
		return toReturnData;
	}

	public static Map<String, String> getAttributeValDataNew(
			List<String> attributeValIds, 
			List<String> attributesIds,
			Map<String, String> attributeToVal) {
		
		List<String> attributeValList = new ArrayList<>(attributeValIds);
		Map<String, String> toReturnData = new HashMap<String, String>();
		
		synchronized (mpAttributeValToName) {
			if(!mpAttributeValToName.isEmpty()){
				attributeValList.removeAll(mpAttributeValToName.keySet());
			}
		}
		
		if(attributeValList.size() > 0){
			List<AttributeValueSchema> allAttributesVals = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attributeValIds);
			if(allAttributesVals != null){
				for(AttributeValueSchema attrValue : allAttributesVals){
					
					for(String attr : attributesIds){
						String mapVal = attributeToVal.get(attr);
						if(attrValue.getId().equals(mapVal)){
							for(AttrId attrList : attrValue.getAttrIds()){
								if(attrList.getAttrId().equals(attr)){
									mpAttributeValToName.put(attrValue.getId(), attrValue.getDisplayName());
									break;
								}
							}
							break;
						}
					}
					
				}
			}
		}
		
		for(String attributeValId : attributeValIds){
				toReturnData.put(attributeValId, mpAttributeValToName.get(attributeValId));
		}
			
		return toReturnData;
	}
}
