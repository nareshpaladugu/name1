package com.shi.content.ranking.vos;

public class Mapdetails {
	private String violation;

	public String getViolation() {
		return violation;
	}

	public void setViolation(String violation) {
		this.violation = violation;
	}
}
