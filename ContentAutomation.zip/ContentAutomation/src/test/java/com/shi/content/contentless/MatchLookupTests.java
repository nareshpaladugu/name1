package com.shi.content.contentless;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.acmesourcebyid.Item;
import com.shc.autocontent.LoadProperties;

public class MatchLookupTests {
	String POISON_PILL = new String();
	
	public static enum MatchData{
		
		SSINQTY_BASIC("+SSIN+PACKAGEQUANTITY",90),
		SSINQTYNULL_BASIC("+SSIN+~PACKAGEQUANTITY",85),
		SSIN_DECR("-SSIN",-7),
		SSIN_QTYMISMATCH("+SSIN-PACKAGEQUANTITY",0),
		
		UPCQTY_BASIC("+UPC+PACKAGEQUANTITY",75),
		UPCQTYNULL_BASIC("+UPC+~PACKAGEQUANTITY",70),
		UPC_DECR("-UPC",-5),
		UPCQTY_INCR("+UPC+PACKAGEQUANTITY",5),
		UPCQTYNULL_INCR("+UPC+~PACKAGEQUANTITY",3),
		UPC_QTYMISMATCH("+UPC-PACKAGEQUANTITY",0),
		
		MMNQTY_BASIC("+MODELNO+~PACKAGEQUANTITY",65),
		MMNQTYNULL_BASIC("+MODELNO+~PACKAGEQUANTITY",60),
		MMN_DECR("-MODELNO",-3),
		MMNQTY_INCR("+MODELNO+PACKAGEQUANTITY",3),
		MMNQTYNULL_INCR("+MODELNO+~PACKAGEQUANTITY",1),
		MMN_QTYMISMATCH("+MODELNO-PACKAGEQUANTITY",0);
		
		private MatchData(String matchReason, int matchScore) {
			this.matchReason = matchReason;
			this.matchScore = matchScore;
		}
		private final String matchReason;
		private final int matchScore;
		
		public String matchReason() {
			return matchReason;
		}
		public int matchScore() {
			return matchScore;
		}
		
		
		
		
	}
	static final int SSINQTY_BASIC = 90;
	static final int UPCQTY_BASIC = 75;
	static final int MMNQTY_BASIC = 65;
	
	
	static final int UPC_BASIC = 80;
	static final int MMN_BASIC = 60;
	

	@Test(groups="MatchLookupTests")
	public void testMatchAPI(){
		

		
		//http://iavip.qa.ch3.s.com/acme/source?page-size=100&page=0
		//Hit for multiple pages
		//Fetch ssins
		//Build a set
		//Form the request
		//Send to thread
		//Producer thread should be seperate
		//Can implement randomizer code there
		
		//Randomizer - single data randomizer
		//Randomizer - multi data randomizer
		
		BlockingQueue<Item> itemSet = new LinkedBlockingQueue<Item>(); 
		AcmeProducerThread<Item> producerThread = new AcmeProducerThread<Item>(itemSet, Item.class);
		Thread acmeProducer = new Thread(producerThread);
		acmeProducer.start();
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			Item itemToLookup;
			
			try {
				itemToLookup = itemSet.poll(20, TimeUnit.SECONDS);
			if(itemToLookup == producerThread.POISON_PILL){
				System.out.println("Got poison pill ..breaking out" + itemToLookup);
				break;
			}
			if(itemToLookup != null){
			
				pool.execute(new MatchLookupVerifications
						(itemToLookup));
			}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public static Set<String> getUniqueData(String listOfData){
		listOfData = listOfData.replaceAll("\"", "");
		
		return new HashSet<>(Arrays.asList(listOfData.split(";")));
	}
	
	
	
}

