package com.shi.content.northstar.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.testng.annotations.BeforeMethod;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.LoginPage;
import com.thoughtworks.selenium.webdriven.commands.IsVisible;

public class NorthStarBaseTest {

	public static ArrayList<String> storeIdsBeingUsed = new ArrayList<>();
	public static List<String> searsStoreIds = null;
	public static List<String> kmartStoreIds = null;
	public enum StoreType {SEARS, KMART};
	public static ArrayList<String> storeTypes = null;
	public static List<String> requiredStoreIds = new ArrayList<>();


	@BeforeMethod
	public void login(){
		System.out.println("In beforemethod");
		LoginPage login = new LoginPage("");
		LinkPanel linkPanel = new LinkPanel();
		login.login("sdhinga", "4444");
		WaitUtils.waitUntilElementIsVisible(linkPanel.getMenuHome());
	}

	/**
	 * Method to get random Sears or Kmart Store Ids. 
	 * Gives only those store ids which are not being used in any other script
	 * Takes care of providing different Store Ids each time it is hit
	 * @param storeType - Sears or Kmart
	 * @param n - required number of Store Ids
	 * @return
	 */
	public static List<String> getRandomStoreIds(StoreType storeType, int n) {
		String storeId;
		
		switch (storeType) {
		case SEARS:
			searsStoreIds = (searsStoreIds != null ? searsStoreIds : RestExecutor.getIdsByAltKey(CollectionValuesVal.STORE,"siteId","sears"));
			synchronized (searsStoreIds) {
				Collections.shuffle(searsStoreIds);	// To test different storeIds each time
				for (int i=0, cnt=0; i<searsStoreIds.size() && cnt < n; i++) {
					storeId = searsStoreIds.get(i);
					if (!storeIdsBeingUsed.contains(storeId) && storeId.startsWith("000") && isValidStore(storeId)) {
						requiredStoreIds.add(storeId);
						storeIdsBeingUsed.add(storeId);
						cnt++;
					}
				}
			}
			break;
		case KMART:
			kmartStoreIds = (kmartStoreIds != null ? kmartStoreIds : RestExecutor.getIdsByAltKey(CollectionValuesVal.STORE,"siteId","kmart"));
			synchronized (kmartStoreIds) {

				Collections.shuffle(kmartStoreIds);	// To test different storeIds each time
				for (int i=0, cnt=0; i<kmartStoreIds.size() && cnt < n; i++) {
					storeId = kmartStoreIds.get(i);
					if (!storeIdsBeingUsed.contains(storeId) && !storeId.startsWith("000") && isValidStore(storeId)) {
						requiredStoreIds.add(storeId);
						storeIdsBeingUsed.add(storeId);
						cnt++;
					}
				}
			}
		}
		return requiredStoreIds;
	}

	public static boolean isValidStore(String storeId){
		String jResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, storeId);

		String strType = JsonStringParser.getJsonValueNew(jResponse,"_search.strType");
		storeTypes = new ArrayList<String>(Arrays.asList("001_D","001_H","001_H3","001_L","001_L3","001_O","001_A","001_B","001_C","001_N1","001_N2","001_N3","002_C","002_2A","002_2B"));

		if(storeTypes.contains(strType)){
			System.out.println("This is a valid StoreType");
			return true;
		}	
		return false;
	}
}