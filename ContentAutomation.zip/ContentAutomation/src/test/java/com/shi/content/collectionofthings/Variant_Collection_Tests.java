package com.shi.content.collectionofthings;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.xmls.collections.VariantCollection;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.SHCCollectionBundleCommons;

public class Variant_Collection_Tests {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="COT_StaticLoadTest")
	public void testCOT_StaticLoad(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);
		String sSite = sFileName.split("\\.")[0].split("-")[1];

		BlockingQueue<List<VariantCollection>> varCollectionQ = new LinkedBlockingQueue<List<VariantCollection>>(); 
		
		SHCCollectionBundleCommons shcColBunCommons = new SHCCollectionBundleCommons(sFileName,sSite);
		
		// Start producer thread to produce nodes
		ChunkProducerThread<VariantCollection> prodColnThread = new ChunkProducerThread<VariantCollection>(sFileName, varCollectionQ, VariantCollection.class,"variant-collection");//, poison);
		prodColnThread.setBucketSize(1);
		Thread tc = new Thread(prodColnThread);
		tc.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<VariantCollection> nodeToTest = varCollectionQ.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodColnThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new Variant_Collection_Verifications(nodeToTest.get(0), shcColBunCommons, sSite, errorPartNumbers));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public 	static List<String> errorPartNumbers = new ArrayList<String>();
	
	@BeforeClass(groups="COT_StaticLoadTest")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			errorPartNumbers = ErrorPartReader.getUVDErrorPartsFromLogFile(errorlogFile);
		}

	}
}
