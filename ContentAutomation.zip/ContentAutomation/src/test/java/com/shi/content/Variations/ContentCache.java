package com.shi.content.Variations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.generated.vos.hierarchy.Hierarchy;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.db.DBException;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.entity.AttrKey;
import com.shc.content.entity.AttrValue;
import com.shc.content.entity.CatentryIds;
import com.shc.content.restutils.RestExecutor;

public class ContentCache {
	private static Map<Long, List<String>> catGroupPath = null;
	private static Map<String, List<String>> keyword = null;
	private static Map<AttrKey, AttrValue> attributes =  new HashMap<AttrKey, AttrValue>();;
	private static Map<Long, List<String>> paths = null;
	private static Map<String, List<Map<String,String>>> resultSetCatDetails = null;
	private static List<String> lstItemClassIds = new ArrayList<>();
	
	private static Map<String, String> mpStoreHierIdToName = new ConcurrentHashMap<String, String>();
	
	public static void refreshCache() {
		catGroupPath = new HashMap<Long, List<String>>();
		keyword = new HashMap<String, List<String>>();
		attributes = new HashMap<AttrKey, AttrValue>();
		paths = new HashMap<Long, List<String>>();
//		resultSetCatDetails = new HashMap<String, ResultSet>();
	}
	
	public synchronized  static AttrValue getAttributeValue(AttrKey key) {

		AttrValue returnValue = new AttrValue();
		loadAttributes(key.getItemClassId());
		if (attributes.containsKey(key)) {
			return attributes.get(key);
		}
		return returnValue;
	}
	
	public static void loadAttributes(String itemClassId) {
		if (null == attributes || attributes.size() <= 0 || !(lstItemClassIds.contains(itemClassId))) {
			lstItemClassIds.add(itemClassId);
			String sQuery = "SELECT att.displaylabel, xcatgrpattrrel.ATTRIBUTESEQUENCE, atval.STRINGVALUE, atval.SEQUENCE, att.field2, atval.NAME "
					+ " FROM wcsadm.xattribute att, wcsadm.xattrvalue atval, wcsadm.xcatgrpattrrel, wcsadm.catgroup "
					+ " WHERE catgroup.CATGROUP_ID = xcatgrpattrrel.CATGROUP_ID AND atval.XATTRIBUTE_ID = att.XATTRIBUTE_ID "
					+ " AND xcatgrpattrrel.XATTRIBUTE_ID = atval.XATTRIBUTE_ID AND catgroup.MEMBER_ID=7000000000000000101 "
					+ " AND atval.NAME NOT LIKE '%SR' "
					+ " AND catgroup.identifier='" 	+ itemClassId + "' WITH ur";
			ResultSet rs = DBUtil.executeQueryReturnAll(sQuery);

			if (rs != null) {
				try {
					while (rs.next()) {
						
						AttrKey attrKey = new AttrKey();
						AttrValue attrValue = new AttrValue();
						attrValue.setDisplaylabel(rs.getString(1));
						attrValue.setAttrSeqence(rs.getString(2));
						attrValue.setStringValue(rs.getString(3));
						attrValue.setSeqence(rs.getString(4));
						try {
							attrKey.setAttrId(rs.getLong(5));
							attrKey.setAttrValueId(rs.getLong(6));
							attrKey.setItemClassId(itemClassId);
							attributes.put(attrKey, attrValue);
						} catch(Exception e) {
							// ignore all filed attributes
//							e.printStackTrace();
						}
					}
				} catch (SQLException e) {
					System.out.println(sQuery);
					throw new DBException("Error in reading result " + e.getMessage());
				}
			}
			
		} 
	}
	
	public synchronized static List<String> getCatGroupPath(Long XMLHierarchyId) {
		
		List<String> returnValue = null;
		if(null == catGroupPath) {
			catGroupPath = new HashMap<Long, List<String>>();
		}
		if(!catGroupPath.containsKey(XMLHierarchyId)) {
			String sQuery = "select CATGROUP_ID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"+
					"= (select CATgroup_id from wcsadm.CATGRPDESC where keyword = '"+XMLHierarchyId+"') with ur";
		
			List<String> lstPaths = DBUtil.executeQueryMultiColumnSingleRow(sQuery);
			if(lstPaths != null &&lstPaths.size() > 0) {
				catGroupPath.put(XMLHierarchyId, lstPaths);
				return lstPaths;
			}
		} else {
			if(catGroupPath.get(XMLHierarchyId).size() > 0)
				return catGroupPath.get(XMLHierarchyId);
		}
		
		return returnValue;
	}
	
	public synchronized static List<String> getKeyword(String lstCatgroupIds) {
		
		List<String> returnValue = null;
		if(null == keyword) {
			keyword = new HashMap<String, List<String>>();
		}
		if(!keyword.containsKey(lstCatgroupIds.trim())) {
			String sQuery = "select keyword from wcsadm.CATGRPDESC where catgroup_id in ("+lstCatgroupIds+") with ur";
			List<String> lstKeywords = DBUtil.executeQuerySingleColMulRow(sQuery);
			
			if(lstKeywords.size() > 0) {
				keyword.put(lstCatgroupIds, lstKeywords);
				return lstKeywords;
			}
		} else {
			if(keyword.get(lstCatgroupIds).size() > 0)
				return keyword.get(lstCatgroupIds);
		}
		
		return returnValue;
	}
	
	public synchronized  static List<String> getPaths(Long lItemClassId) {

		List<String> returnValue = null;
		if(null == paths) {
			paths = new HashMap<Long, List<String>>();
		}
		if(!paths.containsKey(lItemClassId)) {
			String sQuery = "select CATGROUP_ID_PATH, CATGROUP_CID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"+
					" in (select CATGROUP_ID from wcsadm.CATGROUP where identifier = '"+lItemClassId+"') and CATALOG_ID = 21101 with ur";
			List<String> pathsList = DBUtil.executeQueryMultiColumnSingleRow(sQuery);
			
			if(pathsList.size() > 0) {
				paths.put(lItemClassId, pathsList);
				return pathsList;
			}
		} else {
			if(paths.get(lItemClassId).size() > 0)
				return paths.get(lItemClassId);
		}

		return returnValue;
	}

	public synchronized static List<Map<String,String>> getCatGroupDetails(String sQuery,Map<Long, List<String>> sitehiearchyMap,String attrId,String cataId) throws SQLException {

		Map<String,String> pathMap = new HashMap<String,String>();
		List<Map<String,String>> singleResultDetails = new ArrayList<Map<String,String>>();
		if(null == resultSetCatDetails) {
//			resultSetCatDetails =  new HashMap<String, ResultSet>();
			resultSetCatDetails =  new HashMap<String, List<Map<String,String>>>();
		}
		if(!resultSetCatDetails.containsKey(attrId+":"+cataId)) {
			for (Long lSiteId : sitehiearchyMap.keySet()) {
				for (String sHierarchyId : sitehiearchyMap.get(lSiteId)) {
					singleResultDetails =  new ArrayList<Map<String,String>>();
					if(!resultSetCatDetails.containsKey(sHierarchyId+":"+TestUtils.figureOutCatalogId(lSiteId+""))) {
						String sQuery1 = sQuery.replace("ATTR_ID", sHierarchyId).replace("CATA_ID",TestUtils.figureOutCatalogId(lSiteId+""));
						ResultSet rs = DBUtil.executeQueryReturnAll(sQuery1);
						String sCIDpath=null,sNamePath = null;
						if(rs != null){
							while(rs.next()){
								pathMap = new HashMap<String,String>();
								sCIDpath = rs.getString("CATGROUP_ID_PATH");
								sNamePath = rs.getString("CATGROUP_NAME_PATH");
								pathMap.put("CATGROUP_ID_PATH", sCIDpath);
								pathMap.put("CATGROUP_NAME_PATH", sNamePath);
								singleResultDetails.add(pathMap);
							}
						}
						if(singleResultDetails.size() != 0){
							resultSetCatDetails.put(sHierarchyId+":"+TestUtils.figureOutCatalogId(lSiteId+""), singleResultDetails);
						}
						else{
							resultSetCatDetails.put(sHierarchyId+":"+TestUtils.figureOutCatalogId(lSiteId+""), null);
						}
						
						/*if(rs!=null){
							resultSetCatDetails.put(sHierarchyId+":"+TestUtils.figureOutCatalogId(lSiteId+""), rs);
						}
						else{
							resultSetCatDetails.put(sHierarchyId+":"+TestUtils.figureOutCatalogId(lSiteId+""), null);
						}*/
					}
				}
			}
			return resultSetCatDetails.get(attrId+":"+cataId);
		} else {
			return resultSetCatDetails.get(attrId+":"+cataId);
		}
	}
	public static CatentryIds getcatentryIds(HashMap<String, List<String>> partNumbers){
		CatentryIds catentryIds = new CatentryIds();
		List<String> kmartPartnumbers = partNumbers.get("Kmart");
		List<String> searsPartnumbers = partNumbers.get("Sears");
		String partnumbers="";
		if(null != kmartPartnumbers && kmartPartnumbers.size() > 0 ) {
			for(int i=0;i<kmartPartnumbers.size();i++){
				partnumbers = partnumbers+"'"+kmartPartnumbers.get(i)+"'";
				if(i != kmartPartnumbers.size()-1){
					partnumbers = partnumbers+",";
				}
			}
			String sQuery = "select PARTNUMBER,catentry_id from wcsadm.catentry where PARTNUMBER in ("+partnumbers+") with ur";
			catentryIds = DBUtil.executeQueryToGetCatentryIds(catentryIds,sQuery,"kmart");
		}
		if( null != searsPartnumbers && searsPartnumbers.size() > 0) {
			partnumbers="";
			for(int i=0;i<searsPartnumbers.size();i++){
				partnumbers = partnumbers+"'"+searsPartnumbers.get(i)+"'";
				if(i != searsPartnumbers.size()-1){
					partnumbers = partnumbers+",";
				}
			}
			String sQuery="";
			sQuery = "select PARTNUMBER,catentry_id from wcsadm.catentry where PARTNUMBER in ("+partnumbers+") with ur";
			catentryIds = DBUtil.executeQueryToGetCatentryIds(catentryIds,sQuery,"sears");
		}
		return catentryIds;
	}
	
	public static CatentryIds checkFlagsFromAttribsQuery1(CatentryIds catentryIds){
		List<String> kmartCatentryIdsList = catentryIds.getKmartCatentryIdsList();
		List<String> searsCatentryIdsList = catentryIds.getSearsCatentryIdsList();
		Map<String,String> resultMap = new HashMap<String,String>();
		String sCatentryIds="";
		if(null != kmartCatentryIdsList && kmartCatentryIdsList.size() >0) {
			for(int i=0;i<kmartCatentryIdsList.size();i++){
				sCatentryIds = sCatentryIds+kmartCatentryIdsList.get(i);
				if(i != kmartCatentryIdsList.size()-1){
					sCatentryIds = sCatentryIds+",";
				}
			}
			String sQuery = "select CATENTRY_ID,STRINGVALUE from wcsadm.XCATENTATTR where XATTRIBUTE_ID = 161 and " +
					"CATENTRY_ID in ("+sCatentryIds+") and storeid = 10151 with ur";
			resultMap = DBUtil.executeQueryMultiRowMultiColumnSingleMap(sQuery);
			for(int i=0;i<kmartCatentryIdsList.size();i++){
				if(null == kmartCatentryIdsList.get(i)){
					resultMap.put(kmartCatentryIdsList.get(i), null);
				}
			}
			catentryIds.setKmartCheckFlagsFromAttribs1(resultMap);
		}
		if(null != searsCatentryIdsList && searsCatentryIdsList.size() > 0) {
			sCatentryIds="";
			for(int i=0;i<searsCatentryIdsList.size();i++){
				sCatentryIds = sCatentryIds+searsCatentryIdsList.get(i);
				if(i != searsCatentryIdsList.size()-1){
					sCatentryIds = sCatentryIds+",";
				}
			}
			String sQuery = "select CATENTRY_ID,STRINGVALUE from wcsadm.XCATENTATTR where XATTRIBUTE_ID = 161 and " +
					"CATENTRY_ID in ("+sCatentryIds+") and storeid = 10153 with ur";
			resultMap = DBUtil.executeQueryMultiRowMultiColumnSingleMap(sQuery);
			for(int i=0;i<searsCatentryIdsList.size();i++){
				if(null == searsCatentryIdsList.get(i)){
					resultMap.put(searsCatentryIdsList.get(i), null);
				}
			}
			catentryIds.setSearsCheckFlagsFromAttribs1(resultMap);
		}
		return catentryIds;
	}
	
	public static CatentryIds checkFlagsFromAttribsQuery2(CatentryIds catentryIds){
		List<String> kmartCatentryIdsList = catentryIds.getKmartCatentryIdsList();
		List<String> searsCatentryIdsList = catentryIds.getSearsCatentryIdsList();
		Map<String,String> resultMap = new HashMap<String,String>();
		ResultSet set = null;
		String sCatentryIds="";
		if(null != kmartCatentryIdsList && kmartCatentryIdsList.size() > 0 ) {
			for(int i=0;i<kmartCatentryIdsList.size();i++){
				sCatentryIds = sCatentryIds+kmartCatentryIdsList.get(i);
				if(i != kmartCatentryIdsList.size()-1){
					sCatentryIds = sCatentryIds+",";
				}
			}
			String sQuery = "select catentry_id from wcsadm.XCATENTAVREL where XATTRIBUTE_ID=1035223 and catentry_Id in ("+sCatentryIds+") with ur";
			set = DBUtil.executeQueryReturnSingleResultSet(sQuery);
			if(set == null){
				resultMap=null;
			}
			else{
				try {
					while(set.next())
					{
//						resultMap.put(set.getString(1), "Yes");
						resultMap.put(set.getString(1), set.getString(1));
					}
					set.close();
					set.getStatement().close();
				} catch (SQLException e) {
					System.out.println(sQuery);
					throw new DBException("Error in reading result " + e.getMessage());
				}
			}
			if(null != resultMap){
				for(int i=0;i<kmartCatentryIdsList.size();i++){
					if(null == resultMap.get(kmartCatentryIdsList.get(i))){
						resultMap.put(kmartCatentryIdsList.get(i), null);
					}
				}
			}
			catentryIds.setKmartCheckFlagsFromAttribs2(resultMap);
		}
		if(null != searsCatentryIdsList && searsCatentryIdsList.size() > 0 ) {
			sCatentryIds="";
			for(int i=0;i<searsCatentryIdsList.size();i++){
				sCatentryIds = sCatentryIds+searsCatentryIdsList.get(i);
				if(i != searsCatentryIdsList.size()-1){
					sCatentryIds = sCatentryIds+",";
				}
			}
			String sQuery = "select catentry_id from wcsadm.XCATENTAVREL where XATTRIBUTE_ID=1035223 and catentry_Id in ("+sCatentryIds+") with ur";
			set = DBUtil.executeQueryReturnSingleResultSet(sQuery);
			if(set == null){
				resultMap=null;
			}
			else{
				try {
					while(set.next())
					{
//						resultMap.put(set.getString(1), "Yes");
						resultMap.put(set.getString(1), set.getString(1));
					}
					set.close();
					set.getStatement().close();
				} catch (SQLException e) {
					System.out.println(sQuery);
					throw new DBException("Error in reading result " + e.getMessage());
				}
			}
			if(null != resultMap){
				for(int i=0;i<searsCatentryIdsList.size();i++){
					if(null == resultMap.get(searsCatentryIdsList.get(i))){
						resultMap.put(searsCatentryIdsList.get(i), null);
					}
				}
			}
			catentryIds.setSearsCheckFlagsFromAttribs2(resultMap);
		}
		return catentryIds;
	}
	
	

	
	
	

	
	/**
	 * Fetches store hierarchy name for given storeHierId from saved cache.
	 * If not found in cache, hits the storehierarchy collection to fetch relevant data
	 * 
	 * @param storeHierId
	 * @return
	 */
	public static String getNameForStoreHierId(String storeHierId){
		
		if(!mpStoreHierIdToName.containsKey(storeHierId))
			fetchInfoForStoreHierId(storeHierId);
		
		return mpStoreHierIdToName.get(storeHierId);
		
	}
	
	private static void fetchInfoForStoreHierId(String storeHierId){
		Hierarchy storeHierarchy = RestExecutor.getDataById(CollectionValuesVal.STORE_HIERARCHY, storeHierId);
		if(storeHierarchy == null)
			return;
		mpStoreHierIdToName.put(storeHierId, storeHierarchy.getName());
	}
	
}
