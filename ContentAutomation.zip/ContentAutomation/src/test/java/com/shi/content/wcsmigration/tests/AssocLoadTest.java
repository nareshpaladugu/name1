package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.xmls.assocsnew.ParentPartnumber;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;

public class AssocLoadTest 
{
	static List<String> erroredPartNumbers = new ArrayList<String>();
	static Map<String, Boolean> paPriceMap = new HashMap<String, Boolean>();

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="AssocLoadTest")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException
	{
		int counter = 0;
		if(CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Skipping file since threshold exceeded "+ sFileName);
			return;
		}

		String sSite=null;

		System.out.println("Testing file "+ sFileName);

		if(sFileName.toLowerCase().contains("associations2"))
		{
			sSite = "Sears";
		}
		else if(sFileName.toLowerCase().contains("associations1"))
		{
			sSite = "Kmart";
		}
		else
		{
			System.out.println("Unkown site");
			
			LoadProperties.setCustomMsgForEmail("Unkown site, filename : "+sFileName,MSGTYPE.ERROR);
			return;
		}
		
		BlockingQueue<List<ParentPartnumber>> singleProductOfferQueue = new LinkedBlockingQueue<List<ParentPartnumber>>(500); 

		// Start producer thread to produce nodes
		ChunkProducerThread<ParentPartnumber> prodThread = new ChunkProducerThread<ParentPartnumber>
		(sFileName, singleProductOfferQueue, ParentPartnumber.class,"parent-partnumber");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();


		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
					pool.shutdownNow();
					break;
				}
				List<ParentPartnumber> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					//System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){
					counter++;
					pool.execute(new AssocsLoadVerification(nodeToTest.get(0),sSite,paPriceMap));
					
					if(LoadProperties.TESTDATALIMIT!=-1 && counter>LoadProperties.TESTDATALIMIT)
					//if(counter>100)
					{
						break;
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();

			}
		}


		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else
			pool.shutdown();

		while ((CompareValuesUtility.getFinalResult().getFailedCount() < LoadProperties.FAILURE_THRESHOLD) && !pool.isTerminated()){
			Thread.sleep(1000);
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Failure count exceed "+ CompareValuesUtility.getFinalResult().getFailedCount());
			pool.shutdownNow();
			CompareValuesUtility.setRunAborted(true);
		}
	}

	@BeforeClass(groups="AssocLoadTest")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			erroredPartNumbers = ErrorPartReader.getErrorPartsFromLogFile(errorlogFile);
		}
	}
}
