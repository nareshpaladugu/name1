package com.shi.content.storepricing;

import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.content.Content;
import com.generated.vos.offer.Offer;
import com.google.gson.JsonObject;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;
//import resources.properties.properties;
//searsStorePricingInputFile    "src/test/resources/xaa"   SEARSSTOREPROPERTIES


public class StorePricingVerifications implements Runnable {

	static Map<String, Boolean> storeIds = Collections.synchronizedMap(new HashMap<String, Boolean>());
	String finalId=null;
	String partnumId=null;
	ShcPricing storePricingGB;
	Content contentPartGB;
	Offer offerPartGB;
	List<String> singlePricingBlob;
	private boolean check = false;
	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(StorePricingVerifications.class.getName());
	boolean bFound = false;
	boolean xPresent = false;
	boolean pPresent = false;
	boolean rPresent = false;
	boolean ruleFound = false;
	boolean hardlinechk = false;
	
	public StorePricingVerifications(List<String> pricingDataForProduct){
		this.singlePricingBlob = pricingDataForProduct;
	}
	


	public void run() {
		//System.out.println("Thread:" + Thread.currentThread().getId() + " "
		//		+ singlePricingBlob);
        CompareValuesUtility.init();
		// Fill code here
     
        List<PriceDetailVO> lstParentData = new ArrayList<PriceDetailVO>();
        String[] singlePriceData = singlePricingBlob.get(0).split("\\|");
        String mainId = singlePriceData[0] + singlePriceData[2];
        if(LoadProperties.STORE_NATIONAL_ID.contains(singlePriceData[0])){
        	validateForNationalPricing(singlePricingBlob);
        }else{
        	for (String s : singlePricingBlob) {
				System.out.println("the string retrived is= " + s);
				String[] afterSplit = s.split("\\|");
	
				String storeId=afterSplit[0];
				String productId=afterSplit[2];
				String priceType=afterSplit[3];
				String startDate=afterSplit[4].substring(0,10);
				String endDate=afterSplit[5].substring(0,10);
				String price=afterSplit[6];
				
				if (compareDates(startDate, endDate) == true) // first check if  the dates are valid
				{
					if (!validateStore(storeId)) // //check if store exists in store collection
						return; 
					
					else{
					 if (productId.substring(8, 11).equals("000")) {
					       ///After store is checked creating id
							String id = storeId + "-"+ productId.substring(0, 8);
							
							if (id.equals(finalId))
							{    
								 if (storePricingGB==null)
								 { 
									 continue;						 
								 }
							} 
							else{
								storePricingGB = RestExecutor.getDataById(CollectionValuesVal.STOREPRICING, id);
								finalId=id;
								if (storePricingGB==null)
								{
									CompareValuesUtility.logFailed("StorePricingId",finalId,"No result found in gb");
//									CompareValuesUtility.setupResult(mainId, true); 
									continue;    
								 }else{
									 CompareValuesUtility.logPassed("StorePricingId", id, id);
									 CompareValuesUtility.compareValues("StoreId",  storeId.toString(), storePricingGB.getSid());
									 CompareValuesUtility.compareValues("PId", afterSplit[2].substring(0,8),storePricingGB.getPid());
								 }
																					
						      }
								
							//TODO::Check if a and R
						if(priceType.equalsIgnoreCase("r") || priceType.equalsIgnoreCase("a"))
							lstParentData.add(new PriceDetailVO(priceType, startDate, endDate, price));
									
						validatePrices(priceType, startDate, endDate,price, storePricingGB);
					
					} 
					 
				//Start of sku code
				else {
				
					boolean bFound=false;
					String id = storeId + "-" + productId;
					
					if (id.equals(finalId))
					{   
						System.out.println("Same ID");
						if (storePricingGB==null)
						{	 System.out.println("NO data found for "+id+" in GB"); 
						     continue;
						} 
					}
					else{
						storePricingGB = RestExecutor.getDataById(CollectionValuesVal.STOREPRICING, id);
						finalId=id;
						if (storePricingGB==null)
						{	
							CompareValuesUtility.logFailed("StorePricingId",finalId,"No result found in gb for sku");
				             continue;
					    }
						else{
							 CompareValuesUtility.logPassed("StorePricingId", id, id);
							 CompareValuesUtility.compareValues("StoreId",  storeId.toString(), storePricingGB.getSid());
							 CompareValuesUtility.compareValues("PId", afterSplit[2],storePricingGB.getPid() );
							 
							 validateParentDataInSku(storePricingGB, lstParentData);
						}
					}
					
					 
					Float fl = Float.parseFloat(price);
					price = fl.toString();
					switch (priceType) {
						case "X": {
							for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
								if (startDate.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(0,10)))
								{  
									CompareValuesUtility.logPassed("PriceType", "X", "X");
									CompareValuesUtility.compareValues("Price",price,storePricingGB.getP().getX().get(k).getIp().toString());
									CompareValuesUtility.logPassed("StartDate", startDate, storePricingGB.getP().getX().get(k).getSt().toString().substring(0,10));
									CompareValuesUtility.compareValues("EndDate", endDate, storePricingGB.getP().getX().get(k).getEt().toString().substring(0,10));
									
									bFound = true;
								   break;  
								}
							}
							break;
						} // /to end the case for X
	
					}
					if(!bFound){   ///for x price mismatched
						this.logPriceFailed(priceType, startDate, endDate, price);
					}
                
			} // /end of else for sku level clearance price
			} // /end of else for checking values in store_pricing
				
			} 
				continue;
		}
        }
        // end of for for each string
       if(!(check)){
		CompareValuesUtility.setupResult(mainId, true);
		CompareValuesUtility.teardown();
       }
	}

	private void validateParentDataInSku(ShcPricing storePricingGB2, List<PriceDetailVO> lstParentData) {
		
		for(PriceDetailVO parentData : lstParentData){
			validatePrices(parentData.type, parentData.startDate, parentData.endDate, parentData.price, storePricingGB2);
		}
		
	}

	
	private void validatePrices(String priceType, String startDate, String endDate, String price, ShcPricing storePricingGB2) {

		Float fl = Float.parseFloat(price.trim());
		price = fl.toString();
		boolean bFound = false;
		
		switch (priceType) {
		case "R": // connect DB and compare rates for the item
		{
			for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
				if (startDate.equals(storePricingGB.getP().getR().get(k).getSt().toString().substring(0,10)))
					{   
						CompareValuesUtility.logPassed("PriceType", "R", "R");
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getR().get(k).getIp().toString(),price);
						CompareValuesUtility.logPassed("StartDate", startDate, storePricingGB.getP().getR().get(k).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", endDate, storePricingGB.getP().getR().get(k).getEt().toString());
						
					    bFound = true;
						break;    
				     }
				
			}
			
			break;
		} // /to end the case for R
		case "P": {
			for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
				if (startDate.equals(storePricingGB.getP().getS().get(k).getSt().toString().substring(0,10)))	
				{       
						CompareValuesUtility.logPassed("PriceType", "P", "P");
						
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getS().get(k).getIp().toString(),price);
						CompareValuesUtility.logPassed("StartDate", startDate, storePricingGB.getP().getS().get(k).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", endDate, storePricingGB.getP().getS().get(k).getEt().toString());
						
					    bFound = true;
						break;    
				}
			}
			break;
		} // /to end the case for P
		case "A": {
			for (int k = 0; k < storePricingGB.getP().getA().size(); k++) {
				if (startDate.equals(storePricingGB.getP().getA().get(k).getSt().toString().substring(0,10)))
					{   
						CompareValuesUtility.logPassed("PriceType", "A", "A");
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getA().get(k).getIp().toString(),price);
						CompareValuesUtility.logPassed("StartDate", startDate, storePricingGB.getP().getA().get(k).getSt().toString().substring(0,10));
						CompareValuesUtility.compareValues("EndDate", endDate, storePricingGB.getP().getA().get(k).getEt().toString().substring(0,10));
						
					   bFound = true;
					   break;  
					}
			 }
			break;
		}   ///end of 'A'
		case "X": {
			for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
				if (startDate.equals(storePricingGB.getP().getX().get(k).getSt().toString().substring(0,10)))
					{    
						CompareValuesUtility.logPassed("PriceType", "X", "X");
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getX().get(k).getIp().toString(),price);
						CompareValuesUtility.logPassed("StartDate", startDate, storePricingGB.getP().getX().get(k).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", endDate, storePricingGB.getP().getX().get(k).getEt().toString());
						
						bFound = true;
					   break;  
					}
			 }
			break;
		}
		
		
		}   ///end of case
		if(!bFound){
			this.logPriceFailed(priceType, startDate, endDate, price);
		}
		
	}
	
	/**
	 * Reports price type rule as passed when price is not loaded for pricetype if the enddate has passed
	 * @param id
	 * @param priceType
	 */
	private void logEndDateRulePassed(String id, String priceType,String price){
			CompareValuesUtility.logPassed("PriceType", priceType, priceType);
			if(price == null){
				CompareValuesUtility.logPassed("Price","Not loaded","Price not loaded since enddate is past");
				log.info(id+ "Past EndDate not loaded as per the rule");	
			}else{
				CompareValuesUtility.logFailed("Price",price,"Price should not be loaded since input enddate is past.");
				log.error(id+ "EndDate in GB is past");	
			}
	}
	
	
	/**
	 * Checks the rule for National Pricing ie for store ids 0009300,0009313
	 * @param singlePricingBlob
	 * 
	 */
	
	
	private void validateForNationalPricing(List<String> singlePricingBlob) {
		try{
		List<String> divPricingBlob=new ArrayList<String>();
		List<String> skuPricingBlob=new ArrayList<String>();
		for (String s : singlePricingBlob) {
			String[] afterSplit = s.split("\\|");

			String storeId=afterSplit[0];
			String productId=afterSplit[2];
			String priceType=afterSplit[3];
			String startDate=afterSplit[4].substring(0,10);
			String endDate=afterSplit[5].substring(0,10);
			 
			 if (compareDates(startDate, endDate) == true){ //checks whether enddate is past
				if (!validateStore(storeId)) // //check if store exists in store collection
					return; 
				else{
					 if (productId.substring(8, 11).equals("000")) {
						 divPricingBlob.add(s) ;
					 }else{
						 skuPricingBlob.add(s);
					 }
				 }
			 }else{
				 String id1="";
				 if (productId.substring(8, 11).equals("000")) {
					 id1 = storeId + "-" + productId.substring(0,8);
				 }else{
					 id1 = storeId + "-" + productId; 
				 }
				 
				 
				 //NV - Changed to hit pricing gb api instead of greenvips
				 URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, id1);
				 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
				 
				 //Validate end date rule
				 if(storePricingGB!=null){
					 endDateCheck(priceType,endDate,id1);
				 }
			 }
						 
		}
		// For divitems checks the various rules
		if(divPricingBlob!=null && !(divPricingBlob.isEmpty())){
			
			String[] afterSplit = divPricingBlob.get(0).split("\\|");
			String storeId = afterSplit[0];
			String productId = afterSplit[2];
			String priceType = afterSplit[3];
			String startDate = afterSplit[4];
			String endDate = afterSplit[5].substring(0, 10);
			String price = afterSplit[6];
			String partId = productId.substring(0, 8);
			String s = "divitem";
			String id1 = storeId + "-" + partId;
			List<String> divtemList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,s, partId);
			if(divtemList.isEmpty()){
				check = true;
				//log.fatal(id1+" -Not in GB");
				return;
			}else{
				String product = divtemList.get(0); 
				offerPartGB = RestExecutor.getDataById(CollectionValuesVal.OFFER, product);	
				URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, id1);
				URI offerURI = RestAPIs.getByIdURI(LoadProperties.GREENVIP, CollectionValuesVal.OFFER, product); 
				APIResponse<Offer> fullResponse= RestExecutor.getEntireResponseAsObject(offerURI, CollectionValuesVal.OFFER,Offer.class);
				 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
				if(offerPartGB!=null){
					 String parentPartNo = offerPartGB.getIdentity().getParentId();
					 contentPartGB = RestExecutor.getDataById(CollectionValuesVal.CONTENT, parentPartNo);
				}
			 if(offerPartGB==null || contentPartGB==null){
				// log.fatal(id1+" -Not in GB");
				 check = true;
				return;
			 }else{
				 if(fullResponse != null){
						JsonObject obj1 = fullResponse.getFtFields();
						if(obj1 != null && obj1.has("pgrmType") && !obj1.get("pgrmType").toString().equalsIgnoreCase("\"Sears\"") && !obj1.get("pgrmType").toString().equalsIgnoreCase("\"HS\"")) { 
							check = true;
							return;
						}
					}	
				 if(storePricingGB!=null){
					/* boolean xFound = false;
					 for(String div :divPricingBlob ){
						 String[] afterSplit1 = div.split("\\|");
						 String priceType1=afterSplit1[3];
						 String xstartDate = afterSplit1[4].substring(0, 10);
						 String xendDate = afterSplit1[5].substring(0, 10);
						 String xFoundprice = afterSplit1[6];
						 double priceXFound = Double.parseDouble(xFoundprice);
						 if(priceType1.equalsIgnoreCase("x") && priceXFound<=0.02 &&compareActiveDates(xstartDate,xendDate)){
							 xFound=true;
						 }
						 if(xFound){
							 CompareValuesUtility.logFailed("Comments","","Item Should not be loaded since X price is less than or equal to 0.02");	
							 return;
						 }
					 }*/
					 if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null){
						 verifyVDrule(divPricingBlob,id1);
						 verifyGCrule(id1,startDate);
				 }
					 //verifyJennAirRule(id1);
			 }
			 else{
				 //This check is for some partnumber which are present in the feed but still not loaded due the following rules
				 
				 boolean chkPalone = false;
				 boolean xExit = false;
				 double prices = Double.parseDouble(price);
				 for(String div :divPricingBlob ){
					 String[] afterSplit1 = div.split("\\|");
					 String priceType1=afterSplit1[3];
					 String xstartDate = afterSplit1[4].substring(0, 10);
					 String xendDate = afterSplit1[5].substring(0, 10);
					 String xExitprice = afterSplit1[6];
					 double priceXExit = Double.parseDouble(xExitprice);
					 if(priceType1.equalsIgnoreCase("x") || priceType1.equalsIgnoreCase("r")){
						 chkPalone=true;
					 }
					 /*if(priceType1.equalsIgnoreCase("x") && priceXExit<=0.02 &&compareActiveDates(xstartDate,xendDate)){
						 xExit=true; 
					 }*/
				 }
				//If the item is a jenn air item it will not be loaded
				 if(contentPartGB.getBrand()!=null && contentPartGB.getBrand().getName()!=null && (contentPartGB.getBrand().getName().equals("Jenn-Air")) ){
					 CompareValuesUtility.logPassed("Comments","","Item is a Jenn-Air Item");	
					 log.fatal(id1+" -Jenn Item");
					 bFound=true;
					 //if only x price present and the item is a vd item
				 }else if(priceType.equalsIgnoreCase("x") && offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD")&&(prices>0.02)){
					 
						 CompareValuesUtility.logPassed("Comments","","Item is a VD Item value >0.02");	
						 log.fatal(id1+" -VD Item"); 
						 bFound=true;
				 }/*else if(priceType.equalsIgnoreCase("x")&& (prices<=0.02)){
					 CompareValuesUtility.logPassed("Comments","","Item with R price value < 0.02");	
					 log.fatal(id1+" -Item with R price value < 0.02"); 
					 bFound=true;
				 
			    }	*/ 
				//R price less than 0.02	 
				 else if(priceType.equalsIgnoreCase("r")&& (prices<=0.02)){
						 CompareValuesUtility.logPassed("Comments","","Item with R price value < 0.02");	
						 log.fatal(id1+" -Item with R price value < 0.02"); 
						 bFound=true;
						//If price comes as Pprice alone	 
				 }else if(priceType.equalsIgnoreCase("p")&&!(chkPalone)){
						 CompareValuesUtility.logPassed("Comments","","P Alone in the feed < 0.02");	
						 log.fatal(id1+" -Item with R price value < 0.02"); 
						 bFound=true; 
					 
				 }/*else if(xExit){
					 CompareValuesUtility.logPassed("Comments","","Item with X price value < 0.02");	
					 log.fatal(id1+" -Item with X price value < 0.02"); 
					 bFound=true; 
				 }*/
				 else{
				CompareValuesUtility.logFailed("Comments","","No item Found in Store Pricing");		 
				log.fatal(id1+" -Not in SHC_pricing"); 
				return;
				 }
		 }
		if(!(bFound)){	
	    List<NationalPriceDetailVO> lstPriceData = new ArrayList<NationalPriceDetailVO>();
		 for(String div :divPricingBlob ){// Adds all X,P and R price greater than 0.02 to NationalPriceDetailVO 
			 String[] afterSplit1 = div.split("\\|");
	    
			 		String priceType1=afterSplit1[3];
			 		String startDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit1[4]);
			 		//String startTime=afterSplit1[4].substring(11,19);
			 		String endDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit1[5]);
			 		//String endTime=afterSplit1[5].substring(11,19);
			 		String price1=afterSplit1[6]; 
			 		
			 		double prices = Double.parseDouble(price1); 
			 		if(priceType1.equalsIgnoreCase("x")){
			 			if((prices>0.02) && ((offerPartGB.getFfm()==null)||(offerPartGB.getFfm().getChannel()==null)||(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && !(offerPartGB.getFfm().getChannel().equals("VD"))))||(prices<=0.02) && compareActiveDates(startDate1.substring(0, 10), endDate1.substring(0, 10))){
			 			xPresent=true;
			 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
			 		}else{
		 				if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
			 				for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
			 					if (startDate1==(storePricingGB.getP().getX().get(k).getSt().toString())){
			 					CompareValuesUtility.logFailed("Price","","X price should not be loaded in GB");
			 					log.error(id1+ "X price should not be loaded in GB");	
			 					}
			 				}
			 				}	
		 			}
			 		}
			 		if(priceType1.equalsIgnoreCase("p")){
			 			if(prices>0.02){
			 			pPresent=true;
			 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
			 		}else{
			 			if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
			 				for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
			 					if (prices==(storePricingGB.getP().getS().get(k).getIp())){
			 					CompareValuesUtility.logFailed("Price","","P price less than 0.02 loaded in GB");
			 					log.error(id1+ "P price less than 0.02 loaded in GB");	
			 					}
			 				}
			 				}else{
			 					//CompareValuesUtility.logPassed("Price","P","Zero P Price not loaded as per the rule");
			 					log.info(id1+ "Zero Price should not be loaded");	
			 				}
			 					
			 			}
			 		}
		 
			 		if(priceType1.equalsIgnoreCase("r")){
			 			if(prices>0.02){
			 			rPresent=true;
			 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
			 		}else{
			 			if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null && storePricingGB.getP().getR().size()!=0){
			 				for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
			 					if (prices==(storePricingGB.getP().getR().get(k).getIp())){
			 					CompareValuesUtility.logFailed("Price","","R price less than 0.02 loaded in GB");
			 					log.error(id1+ "R price less than 0.02 loaded in GB");	
			 					}
			 				}
			 				}else{
			 					//CompareValuesUtility.logPassed("Price","","Zero R Price not loaded as per the rule");
			 					log.info(id1+ "Zero R Price not loaded as per the rule");	
			 				}
			 					
			 			}
		 }
			 		
		 }
  //checks Hardline rule
		 verifyHardlineRule(divPricingBlob,id1,xPresent);
		 if(storePricingGB!=null){
			 // Checks the P alone should not be loaded rule
		 if(!(xPresent)&&pPresent&&!(rPresent)){
				if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
					for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
					CompareValuesUtility.logFailed("Price","","P price "+storePricingGB.getP().getS().get(k).getIp()+ " should not be loaded alone");
					log.error(id1+ "P price "+storePricingGB.getP().getS().get(k).getIp()+ " should not be loaded alone");
					}
				}else{
					//CompareValuesUtility.logPassed("Price","","P price alone in the feed so not loaded");
					log.info(id1+ "P price alone in the feed so not loaded");
				}
			}
		 //checks the 89% rule
		 if(pPresent && rPresent &&!xPresent && !hardlinechk&&!(bFound)&&storePricingGB!=null){
			if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()!=null &&!(offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()))||(offerPartGB.getPriceDispAttr()==null)||(offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()==null)){
			 String chkRStartDate=null;
				String chkEndDate=null;
				String chkPStartDate=null;
				String Rruleprice =null;
				 String Pruleprice =null;
				 boolean valChk=false;
			 for(String div :divPricingBlob ){
				 String[] afterSplit3 = div.split("\\|");	
//				 String hardstoreId=afterSplit3[0];
					String rulepriceType=afterSplit3[3];
					String rulestartDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[4]);
					//String rulestartTime=afterSplit3[4].substring(11,19);
					String ruleEndDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[5]);
					//String ruleendTime=afterSplit3[5].substring(11,19);
					String ruleprice=afterSplit3[6];
					
						 if(offerPartGB==null || contentPartGB==null){
							 //log.fatal(id1+" -Not in GB");
							 check = true;
							 bFound=true;
						 }else{
							 if(storePricingGB!=null){
								 if(rulepriceType.equalsIgnoreCase("r")){
									 chkRStartDate=rulestartDate;
									 chkEndDate=ruleEndDate;
									  Rruleprice=ruleprice;
								 }
								 if(rulepriceType.equalsIgnoreCase("p")&& !(StringUtils.isBlank(chkRStartDate))&& !(StringUtils.isBlank(chkEndDate)) ){
									 if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal())|| (offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc() !=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc())){
											if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null && storePricingGB.getP().getS().size()!=0){
												CompareValuesUtility.logFailed("Price",ruleprice,"P price should not be present in Gb since it has Everyday or ExptVal as true");		
												valChk=true;
											}else
												valChk=true;
									 }
									 chkPStartDate=rulestartDate;
									 Pruleprice=ruleprice;
									 if(!valChk){
									 if(compareBetween(chkRStartDate.substring(0, 10), chkEndDate.substring(0, 10),chkPStartDate.substring(0, 10)) == true){ 
										 if(!(StringUtils.isBlank(Rruleprice))&& !(StringUtils.isBlank(Pruleprice))){
											 Double rprice=Double.parseDouble(Rruleprice);
											 Double pprice=Double.parseDouble(Pruleprice);
											 Double compareprice= ((rprice-pprice)/rprice)*100;
											 if(compareprice>89){
												 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
												 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
									 				if (pprice.toString().equals(storePricingGB.getP().getS().get(k).getIp().toString())){
									 						CompareValuesUtility.logFailed("Price","","P price "+storePricingGB.getP().getS().get(0).getIp().toString()+ " exceeds 89% rule");
															log.error("P price for "+id1+ "-"+storePricingGB.getP().getS().get(0).getIp().toString()+ " exceeds 89% rule");
															ruleFound=true;
									 				}else
														 ruleFound=true; 
									 				} 
											 }else
												 ruleFound=true; 
											 }else{
												 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
													 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
														if (rulestartDate.equals(storePricingGB.getP().getS().get(k).getSt().toString())){
												    CompareValuesUtility.logPassed("PriceType", "P", "P");
													CompareValuesUtility.compareValues("Price", pprice,storePricingGB.getP().getS().get(k).getIp().toString());
													CompareValuesUtility.compareValues("StartDate", rulestartDate, storePricingGB.getP().getS().get(k).getSt());
													CompareValuesUtility.compareValues("EndDate", ruleEndDate, storePricingGB.getP().getS().get(k).getEt());
												    log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(k).getIp().toString()+ " - " +ruleprice);
												    ruleFound=true;
												    break;
										 				}
													 }
												 }else{
													 
													 CompareValuesUtility.logFailed("Price",ruleprice,"P price not present in the GB");	
														log.error(id1+"P price not present in the GB"); 
														ruleFound=true;
												 
													 
										 				}
											 
										 }
									 }
									 
								 }else{

									 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
										 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
											 Double pprice=Double.parseDouble(ruleprice);
											 if (rulestartDate.equals(storePricingGB.getP().getS().get(k).getSt().toString())){
									    CompareValuesUtility.logPassed("PriceType", "P", "P");
										CompareValuesUtility.compareValues("Price", pprice,storePricingGB.getP().getS().get(k).getIp().toString());
										CompareValuesUtility.compareValues("StartDate", rulestartDate, storePricingGB.getP().getS().get(k).getSt());
										CompareValuesUtility.compareValues("EndDate", ruleEndDate, storePricingGB.getP().getS().get(k).getEt());
									    log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(k).getIp().toString()+ " - " +ruleprice);
									    ruleFound=true;
									    break;
							 				}
										 }
									 }else{
										 
										 CompareValuesUtility.logFailed("Price",ruleprice,"P price not present in the GB");	
											log.error(id1+"P price not present in the GB"); 
											ruleFound=true;
									 
										 
							 				}
								 
							  
								 }
								 }
								 }
								 
							 }
						 }
			 }		 
		 }			 
		 }					 
			 if(pPresent&&(xPresent||rPresent)&&!(bFound)&&storePricingGB!=null){
				 for(NationalPriceDetailVO priceData : lstPriceData){
				//for(int i=0; i<Allprice.size();i++){
					Float fl = Float.parseFloat(priceData.price.trim());
					price = fl.toString();
					Double vdPrice = Double.parseDouble(price);
					Double xChkPrice=0.0;
					if(priceData.type.equalsIgnoreCase("x")){
					if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD") &&(vdPrice>0.02)){
						log.error("X price for "+id1+" should be null for VD");
					}else{
						if(storePricingGB.getP()!=null && storePricingGB.getP().getX() != null && storePricingGB.getP().getX().size()!=0){
								int x =storePricingGB.getP().getX().size();
								
					CompareValuesUtility.logPassed("PriceType", "X", "X");
						for(int m=0;m<x;m++){
							if(priceData.startDate.equals(storePricingGB.getP().getX().get(m).getSt().toString())){
								 xChkPrice=vdPrice;
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getX().get(m).getIp().toString(),price);
						CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getX().get(m).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getX().get(m).getEt().toString());
						log.info("X price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getX().get(m).getIp().toString()+ " - " +price);
					
					bFound=true;
					break;
							}
						}
						}else{
							if(offerPartGB.getFfm()==null || offerPartGB.getFfm().getChannel()==null){
							}else{
							CompareValuesUtility.logFailed("Price",price,"X price not present in the GB");	
							log.error(id1+"X price not present in the GB");
							}
						}
					}
					}
					else if(priceData.type.equalsIgnoreCase("p")){
						if(!ruleFound){
						if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal())|| (offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc() !=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc())){
							if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null && storePricingGB.getP().getS().size()!=0){
								CompareValuesUtility.logFailed("Price",price,"P price should not be present in Gb since it has Everyday or ExptVal as true");		
							}
						}else{
						if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null && storePricingGB.getP().getS().size()!=0){
								int x =storePricingGB.getP().getS().size();
									for(int m=0;m<x;m++){
										if(priceData.startDate.equals(storePricingGB.getP().getS().get(m).getSt().toString())){
						CompareValuesUtility.logPassed("PriceType", "P", "P");
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getS().get(m).getIp().toString(),price);
						CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getS().get(m).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getS().get(m).getEt().toString());
					    log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(m).getIp().toString()+ " - " +price);
					    bFound=true;
					    break;
										}
									
									}
					}else{ 
							CompareValuesUtility.logFailed("Price",price,"P price not present in the GB");	
							log.error(id1+"P price not present in the GB");
						}
					}
					}
					}
					else{
					if(priceData.type.equalsIgnoreCase("r")){
						if(storePricingGB.getP()!=null && storePricingGB.getP().getR() != null && storePricingGB.getP().getR().size()!=0){
							int x =storePricingGB.getP().getR().size();
								for(int m=0;m<x;m++){
									if(priceData.startDate.equals(storePricingGB.getP().getR().get(m).getSt().toString())){	
						CompareValuesUtility.logPassed("PriceType", "R", "R");
						CompareValuesUtility.compareValues("Price", price, storePricingGB.getP().getR().get(m).getIp().toString());
						CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getR().get(m).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getR().get(m).getEt().toString());
						log.info("R price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getR().get(m).getIp().toString()+ " - " +price);
						bFound=true;
						break;
									}
								}if(!bFound){
									CompareValuesUtility.logFailed("Price",price,"R price not present in the GB");		
								}
						}else{
							CompareValuesUtility.logFailed("Price",price,"R price not present in the GB");	
							log.error(id1+"R price not present in the GB");
						}
						}
					}
					 }
			 }	
			 else{
			 if((xPresent||rPresent)&&!(bFound)&&storePricingGB!=null){
				 for(NationalPriceDetailVO priceData : lstPriceData){
						Float fl = Float.parseFloat(priceData.price.trim());
						price = fl.toString();
						Double vdPrice = Double.parseDouble(price);
						if(priceData.type.equalsIgnoreCase("x")){
						if(offerPartGB.getFfm()!=null&& offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD")&&(vdPrice>0.02)){
							log.error("X price for "+id1+" should be null for VD");
						}else{
							if(storePricingGB.getP()!=null && storePricingGB.getP().getX() != null && storePricingGB.getP().getX().size()!=0){	
								int x =storePricingGB.getP().getX().size();
									for(int m=0;m<x;m++){
										if(priceData.startDate.equals(storePricingGB.getP().getX().get(m).getSt().toString())){			
						CompareValuesUtility.logPassed("PriceType", "X", "X");
						CompareValuesUtility.compareValues("Price", storePricingGB.getP().getX().get(m).getIp().toString(),price);
						CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getX().get(m).getSt().toString());
						CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getX().get(m).getEt().toString());
						log.info("X price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getX().get(m).getIp().toString()+ " - " +price);
						bFound=true;
						break;
									}
									}
							}else{
								CompareValuesUtility.logFailed("Price",price,"X price not present in the GB");	
								log.error(id1+"X price not present in the GB");
							}
						}
						}
						else if(priceData.type.equalsIgnoreCase("r")){
							if(storePricingGB.getP()!=null && storePricingGB.getP().getR() != null && storePricingGB.getP().getR().size()!=0){
								int x =storePricingGB.getP().getR().size();
									for(int m=0;m<x;m++){
										if( priceData.startDate.equals(storePricingGB.getP().getR().get(m).getSt().toString())){
							CompareValuesUtility.logPassed("PriceType", "R", "R");
							CompareValuesUtility.compareValues("Price", storePricingGB.getP().getR().get(m).getIp().toString(),price);
							CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getR().get(m).getSt().toString());
							CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getR().get(m).getEt().toString());
							log.info("R price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getR().get(m).getIp().toString()+ " - " +price);
							bFound=true;
							break;
								}
									}
							}else{
								CompareValuesUtility.logFailed("Price",price,"R price not present in the GB");
								log.error(id1+"R price not present in the GB");
							}
							}
						
					 }
			 }	
		 }
		 }
		
		 
		}
		 }
		}
		}
		 if(!(skuPricingBlob.isEmpty())){
			 String[] skuafterSplit = skuPricingBlob.get(0).split("\\|");
					String skustoreId=skuafterSplit[0];
					String skuproductId=skuafterSplit[2];
					String skupriceType=skuafterSplit[3];
					String skustartDate=skuafterSplit[4];
					String skuendDate=skuafterSplit[5];
					String skuprice=skuafterSplit[6];
					String skupartId = skuproductId; 
					String id1 = skustoreId + "-" + skuproductId;
					 offerPartGB = RestExecutor.getDataById(CollectionValuesVal.OFFER, skupartId);
					 URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, id1);
					 URI offerURI = RestAPIs.getByIdURI(LoadProperties.GREENVIP, CollectionValuesVal.OFFER, skupartId); 
					 APIResponse<Offer> fullResponse= RestExecutor.getEntireResponseAsObject(offerURI, CollectionValuesVal.OFFER,Offer.class);
					 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
				 if(offerPartGB!=null){
				 String parentPartNo = offerPartGB.getIdentity().getParentId();
					 contentPartGB = RestExecutor.getDataById(CollectionValuesVal.CONTENT, parentPartNo);
				 }
					 partnumId=skuproductId;
					 if(offerPartGB==null || contentPartGB==null){
						 check=true;
						// log.fatal(id1+" -Not in GB");
						return;
					 }else{
						 if(fullResponse != null){
								JsonObject obj1 = fullResponse.getFtFields();
								if(obj1 != null && obj1.has("pgrmType") && !obj1.get("pgrmType").toString().equalsIgnoreCase("\"Sears\"") && !obj1.get("pgrmType").toString().equalsIgnoreCase("\"HS\"")) { 
									check = true;
									return;
								}
							}	
						if (storePricingGB!=null){
							if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null){
								verifyVDrule(skuPricingBlob, id1);
								verifyGCrule(id1, skustartDate);
							}
							verifyJennAirRule(id1);
						 }
						else{
							 boolean chkPalone = false;
							 double prices = Double.parseDouble(skuprice);
							 for(String div :skuPricingBlob ){
								 String[] afterSplit1 = div.split("\\|");
								 String priceType1=afterSplit1[3];
								 if(priceType1.equalsIgnoreCase("x") || priceType1.equalsIgnoreCase("r")){
									 chkPalone=true;
								 }
							 }
							 if(contentPartGB.getBrand()!=null && contentPartGB.getBrand().getName()!=null && (contentPartGB.getBrand().getName().equals("Jenn-Air")) ){
								 CompareValuesUtility.logPassed("Comments","","Item is a Jenn-Air Item");	
								 log.fatal(id1+" -Jenn Item");
								 bFound=true;
							 }else if(skupriceType.equalsIgnoreCase("x") && (prices>0.02) && offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD")){
								 
									 CompareValuesUtility.logPassed("Comments","","Item is a VD Item value >0.02");	
									 log.fatal(id1+" -VD Item"); 
									 bFound=true;
								 
								 
							 }else if(skupriceType.equalsIgnoreCase("r")&& (prices<=0.02)){
									 CompareValuesUtility.logPassed("Comments","","Item with R price value < 0.02");	
									 log.fatal(id1+" -Item with R price value < 0.02"); 
									 bFound=true;
								 
							 }else if(skupriceType.equalsIgnoreCase("p")&&!(chkPalone)){
									 CompareValuesUtility.logPassed("Comments","","P Alone in the feed < 0.02");	
									 log.fatal(id1+" -Item with R price value < 0.02"); 
									 bFound=true; 
								 
							 }else{
							CompareValuesUtility.logFailed("Comments","","No item Found in Store Pricing");		 
							log.fatal(id1+" -Not in SHC_pricing"); 
							return;
							 }
					 }
			  if(!(bFound)){
				List<String> Allprice=new ArrayList<String>();
				 List<NationalPriceDetailVO> lstPriceData = new ArrayList<NationalPriceDetailVO>();
				 for(String div :skuPricingBlob ){
					 String[] afterSplit1 = div.split("\\|");
					 		String priceType1=afterSplit1[3];
					 		String startDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit1[4]);
					 		String endDate1=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit1[5]);
					 		String price1=afterSplit1[6]; 
					 		double prices = Double.parseDouble(price1); 
					 		if(priceType1.equalsIgnoreCase("x")){
					 			if((prices>0.02) && ((offerPartGB.getFfm()==null)||(offerPartGB.getFfm().getChannel()==null)||(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && !(offerPartGB.getFfm().getChannel().equals("VD"))))||(prices<=0.02) && compareActiveDates(startDate1, endDate1)){
					 			xPresent=true;
					 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
					 			}else{
					 				if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
						 				for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
						 					if (startDate1==(storePricingGB.getP().getX().get(k).getSt().toString())){
						 					CompareValuesUtility.logFailed("Price","","X price should not be loaded in GB");
						 					log.error(id1+ "X price should not be loaded in GB");	
						 					}
						 				}
						 				}	
					 			}
					 		}
					 		if(priceType1.equalsIgnoreCase("p")){
					 			if(prices>0.02){
					 			pPresent=true;
					 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
					 		}else{
					 			if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
					 				for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
					 					if (prices==(storePricingGB.getP().getS().get(k).getIp())){
					 					CompareValuesUtility.logFailed("Price","","P price less than 0.02 loaded in GB");
					 					log.error(id1+ "P price less than 0.02 loaded in GB");	
					 					}
					 				}
					 				}else{
					 					//CompareValuesUtility.logPassed("Price","P","Zero P Price not loaded as per the rule");
					 					log.info(id1+ "Zero Price not loaded as per the rule");	
					 				}
					 					
					 			}
					 		}
				 
					 		if(priceType1.equalsIgnoreCase("r")){
					 			if(prices>0.02){
					 			rPresent=true;
					 			lstPriceData.add(new NationalPriceDetailVO(priceType1, startDate1, endDate1,price1));
					 		}else{
					 			if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null && storePricingGB.getP().getR().size()!=0){
					 				for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
					 					if (prices==(storePricingGB.getP().getR().get(k).getIp())){
					 					CompareValuesUtility.logFailed("Price","","R price less than 0.02 loaded in GB");
					 					log.error(id1+ "R price less than 0.02 loaded in GB");	
					 					}
					 				}
					 				}else{
					 				//	CompareValuesUtility.logPassed("Price","","Zero R Price not loaded as per the rule");
					 					log.info(id1+ "Zero R Price not loaded as per the rule");	
					 				}
					 					
					 			}
				 }
					 		
				 }
				 verifyHardlineRule(skuPricingBlob,id1,xPresent);
			 if(storePricingGB!=null){
					if(!(xPresent)&&pPresent&&!(rPresent)){
						if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
							for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
								CompareValuesUtility.logFailed("Price","","P price "+storePricingGB.getP().getS().get(k).getIp()+ " should not be loaded alone");	
								log.error(id1+ "P price "+storePricingGB.getP().getS().get(k).getIp()+ " should not be loaded alone");
							}
						}else{
							//CompareValuesUtility.logPassed("Price","","P price alone in the feed so not loaded");
							log.info(id1+ "P price alone in the feed so not loaded");
						}
					}
					//checks 89% rule
					 if(pPresent && rPresent &&!xPresent && !hardlinechk&&!(bFound)&&storePricingGB!=null){
						 if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()!=null &&!(offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()))||(offerPartGB.getPriceDispAttr()==null)||(offerPartGB.getPriceDispAttr().getIsPrcAlrtExcln()==null)){
							 String chkRrulestartDate=null;
								String chkRruleEndDate=null;
								String chkPrulestartDate=null;
								String Rruleprice =null;
								 String Pruleprice =null;
								 boolean valChk=false;
							 for(String div :skuPricingBlob ){
								 String[] afterSplit3 = div.split("\\|");	
									String rulepriceType=afterSplit3[3];
									String rulestartDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[4]);
									String ruleEndDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[5]);
									String ruleprice=afterSplit3[6];
									
										 if(offerPartGB==null || contentPartGB==null){
											// log.fatal(id1+" -Not in GB");
											 check = true;
											 bFound=true;
										 }else{
											 if(storePricingGB!=null){
												 if(rulepriceType.equalsIgnoreCase("r")){
													 chkRrulestartDate=rulestartDate;
													 chkRruleEndDate=ruleEndDate;
													  Rruleprice=ruleprice;
												 }
												 if(rulepriceType.equalsIgnoreCase("p")&& !(StringUtils.isBlank(chkRrulestartDate))&& !(StringUtils.isBlank(chkRruleEndDate)) ){
													 if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal())|| (offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc() !=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc())){
															if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null && storePricingGB.getP().getS().size()!=0){
																CompareValuesUtility.logFailed("Price",ruleprice,"P price should not be present in Gb since it has Everyday or ExptVal as true");		
																valChk=true;
															}else
																valChk=true;
													 }
													 chkPrulestartDate=rulestartDate;
													 Pruleprice=ruleprice;
													 if(!valChk){
													 if(compareBetween(chkRrulestartDate.substring(0, 10), chkRruleEndDate.substring(0, 10),chkPrulestartDate.substring(0, 10)) == true){ 
														 if(!(StringUtils.isBlank(Rruleprice))&& !(StringUtils.isBlank(Pruleprice))){
															 Double rprice=Double.parseDouble(Rruleprice);
															 Double pprice=Double.parseDouble(Pruleprice);
															 Double compareprice= ((rprice-pprice)/rprice)*100;
															 if(compareprice>89){
																 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
																 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
													 				if (pprice.toString().equals(storePricingGB.getP().getS().get(k).getIp().toString())){
													 						CompareValuesUtility.logFailed("Price","","P price "+storePricingGB.getP().getS().get(0).getIp().toString()+ " exceeds 89% rule");
																			log.error("P price for "+id1+ "-"+storePricingGB.getP().getS().get(0).getIp().toString()+ " exceeds 89% rule");
																			ruleFound=true;
													 				}else
																		 ruleFound=true; 
													 				} 
															 }else
																 ruleFound=true; 
															 }else{
																 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
																	 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
																		 if (rulestartDate.equals(storePricingGB.getP().getS().get(k).getSt().toString())){
																    CompareValuesUtility.logPassed("PriceType", "P", "P");
																	CompareValuesUtility.compareValues("Price", pprice,storePricingGB.getP().getS().get(k).getIp().toString());
																	CompareValuesUtility.compareValues("StartDate", rulestartDate , storePricingGB.getP().getS().get(k).getSt().toString());
																	CompareValuesUtility.compareValues("EndDate", ruleEndDate, storePricingGB.getP().getS().get(k).getEt().toString());
																    log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(k).getIp().toString()+ " - " +ruleprice);
																    ruleFound=true;
																    break;
														 				}
																	 }
																 }else{
																	 
																	 CompareValuesUtility.logFailed("Price",ruleprice,"P price not present in the GB");	
																		log.error(id1+"P price not present in the GB"); 
																		ruleFound=true;
																 
																	 
														 				}
															 
														 }
													 }
													 
												 }else{

													 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
														 for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
															 Double pprice=Double.parseDouble(ruleprice);
															 if (rulestartDate.equals(storePricingGB.getP().getS().get(k).getSt().toString())){
													    CompareValuesUtility.logPassed("PriceType", "P", "P");
														CompareValuesUtility.compareValues("Price", pprice,storePricingGB.getP().getS().get(k).getIp().toString());
														CompareValuesUtility.compareValues("StartDate", rulestartDate, storePricingGB.getP().getS().get(k).getSt().toString());
														CompareValuesUtility.compareValues("EndDate", ruleEndDate, storePricingGB.getP().getS().get(k).getEt().toString());
													    log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(k).getIp().toString()+ " - " +ruleprice);
													    ruleFound=true;
													    break;
											 				}
														 }
													 }else{
														 
														 CompareValuesUtility.logFailed("Price",ruleprice,"P price not present in the GB");	
															log.error(id1+"P price not present in the GB"); 
															ruleFound=true;
													 
														 
											 				}
												 
											  
												 }
												 }
												 }
												 
											 }
										 }
							 }		 
						 }			 
						 }	
					 if(!(bFound)&&storePricingGB!=null){
						 for(NationalPriceDetailVO priceData : lstPriceData){
						Float fl = Float.parseFloat(priceData.price.trim());
						skuprice = fl.toString();
						Double vdPrice = Double.parseDouble(skuprice);
						Double xChkPrice=0.0;
						if(priceData.type.equalsIgnoreCase("x")){
						if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD")&&(vdPrice>0.02)){
							log.error("X price for "+id1+" should be null for VD");
						}else{
							if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!= null && storePricingGB.getP().getX().size()!=0){
								int x =storePricingGB.getP().getX().size();
									for(int m=0;m<x;m++){
										if(priceData.startDate.equals(storePricingGB.getP().getX().get(m).getSt().toString())){
											xChkPrice=vdPrice;
											CompareValuesUtility.logPassed("PriceType", "X", "X");
						                    CompareValuesUtility.compareValues("Price", storePricingGB.getP().getX().get(m).getIp().toString(),skuprice);
						                    CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getX().get(m).getSt().toString());
				                     		CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getX().get(m).getEt().toString());
						                    log.info("X price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getX().get(m).getIp().toString()+ " - " +skuprice);
						                    bFound=true;
						                    break;
								}
									}
							}else{
								CompareValuesUtility.logFailed("Price",skuprice,"X price not present in the GB");	
								log.error(id1+"X price not present in the GB");
							}
						}
						}
						else if(priceData.type.equalsIgnoreCase("p")){
							if(!ruleFound){
							if((offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal())|| (offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc() !=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc())){
								if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null && storePricingGB.getP().getS().size()!=0){
									CompareValuesUtility.logFailed("Price",skuprice,"P price should not be present in Gb since it has Everyday or ExptVal as true");		
								}
							}else{
							if(storePricingGB.getP()!=null &&  storePricingGB.getP().getS() != null &&storePricingGB.getP().getS().size()!=0){
								int x =storePricingGB.getP().getS().size();
									for(int m=0;m<x;m++){
										if(priceData.startDate.equals(storePricingGB.getP().getS().get(m).getSt().toString())){
							CompareValuesUtility.logPassed("PriceType", "P", "P");
							CompareValuesUtility.compareValues("Price", storePricingGB.getP().getS().get(m).getIp().toString(),skuprice);
							CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getS().get(m).getSt().toString());
							CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getS().get(m).getEt().toString());
							log.info("P price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getS().get(m).getIp().toString()+ " - " +skuprice);
							bFound=true;
							break;
								}
									}
							}else{
								CompareValuesUtility.logFailed("Price",skuprice,"P price not present in the GB");
								log.error(id1+"P price not present in the GB");
							}
						}
						}
							}
						else{
						if(priceData.type.equalsIgnoreCase("r")){
							if(storePricingGB.getP()!=null && storePricingGB.getP().getR() != null && storePricingGB.getP().getR().size()!=0){

	                        int x =storePricingGB.getP().getR().size();
								for(int m=0;m<x;m++){
									if(priceData.startDate.equals(storePricingGB.getP().getR().get(m).getSt().toString())){
							CompareValuesUtility.logPassed("PriceType", "R", "R");
							
							CompareValuesUtility.compareValues("Price", storePricingGB.getP().getR().get(m).getIp().toString(),skuprice);
							CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getR().get(m).getSt().toString());
							CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getR().get(m).getEt().toString());
							
							log.info("R price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getR().get(m).getIp().toString()+ " - " +skuprice);
							bFound=true;
							break;
									}
								}
							}else{
								CompareValuesUtility.logFailed("Price",skuprice,"R price not present in the GB");
								log.error(id1+"R price not present in the GB");
							}
							}
						}
						 }
					}	
					/* else{
					 if((xPresent||rPresent)&&!(bFound)&&storePricingGB!=null){
						 for(NationalPriceDetailVO priceData : lstPriceData){
							Float fl = Float.parseFloat(priceData.price.trim());
							skuprice = fl.toString();
							Double vdPrice = Double.parseDouble(skuprice);
							if(priceData.type.equalsIgnoreCase("x")){
								if(offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && offerPartGB.getFfm().getChannel().equals("VD")&&(vdPrice>0.02)){
								log.error("X price for "+id1+" should be null for VD");
							}else{
								if(storePricingGB.getP()!=null && storePricingGB.getP().getX() != null && storePricingGB.getP().getX().size()!=0){
									int x =storePricingGB.getP().getX().size();
										for(int m=0;m<x;m++){
											if(priceData.startDate.equals(storePricingGB.getP().getX().get(m).getSt().toString().substring(0,10))&&priceData.startTime.equals(storePricingGB.getP().getX().get(m).getSt().toString().substring(11,19))){
							CompareValuesUtility.logPassed("PriceType", "X", "X");
							CompareValuesUtility.compareValues("Price", storePricingGB.getP().getX().get(m).getIp().toString(),skuprice);
							CompareValuesUtility.compareValues("StartDate", priceData.startDate, storePricingGB.getP().getX().get(m).getSt().toString().substring(0,10));
							CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getX().get(m).getEt().toString().substring(0,10));
							
							log.info("X price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getX().get(m).getIp().toString()+ " - " +skuprice);
							bFound=true;
							break;
											}
										}
								}else{
									CompareValuesUtility.logFailed("Price",skuprice,"X price not present in the GB");	
									log.error(id1+"X price not present in the GB");
								}
							}
							}
							else if(priceData.type.equalsIgnoreCase("r")){
								if(storePricingGB.getP()!=null && storePricingGB.getP().getR() != null && storePricingGB.getP().getR().size()!=0){
									int x =storePricingGB.getP().getR().size();
										for(int m=0;m<x;m++){
											if(priceData.startDate.equals(storePricingGB.getP().getR().get(m).getSt().toString().substring(0,10))&& priceData.startTime.equals(storePricingGB.getP().getR().get(m).getSt().toString().substring(11,19))){
								CompareValuesUtility.logPassed("PriceType", "R", "R");
								CompareValuesUtility.compareValues("Price", storePricingGB.getP().getR().get(m).getIp().toString(),skuprice);
								CompareValuesUtility.compareValues("StartDate",priceData.startDate, storePricingGB.getP().getR().get(m).getSt().toString().substring(0,10));
								CompareValuesUtility.compareValues("EndDate", priceData.endDate, storePricingGB.getP().getR().get(m).getEt().toString().substring(0,10));
								
								log.info("R price for "+id1+"- GB price and feed price: " +storePricingGB.getP().getR().get(m).getIp().toString()+ " - " +skuprice);
								bFound=true;
								break;
											}
										}
								}else{
									CompareValuesUtility.logFailed("Price",skuprice,"R price not present in the GB");
									log.error(id1+"R price not present in the GB");
								}
								
								}
							
						 }
				 }	
			 }*/
			 }
			 
			 }
					 }
		 }
		}catch(Exception e){
			log.error("Exception for" +e);
		}
		}
					 
	public void endDateCheck(String priceType, String endDate, String id1 ){

		if(priceType.equalsIgnoreCase("x")){ 
        	 if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
 				for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
 					if (endDate.equals(storePricingGB.getP().getX().get(k).getEt().toString().substring(0,10))){
 						logEndDateRulePassed(id1, "X", storePricingGB.getP().getX().get(k).getIp().toString());
 					}
 				}
	 		 }else{
	 			logEndDateRulePassed(id1,"X",null);	
	 		} 
		 }
         if(priceType.equalsIgnoreCase("p")){ 
        	 if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
 				for (int k = 0; k < storePricingGB.getP().getS().size(); k++) {
 					if (endDate.equals(storePricingGB.getP().getS().get(k).getEt().toString().substring(0,10))){
 						logEndDateRulePassed(id1, "P", storePricingGB.getP().getS().get(k).getIp().toString());
 					}
 				}
				}else{
					logEndDateRulePassed(id1,"P",null);
				} 
		 }
         if(priceType.equalsIgnoreCase("r")){ 
        	 if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null && storePricingGB.getP().getR().size()!=0){
 				for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
 					if (endDate.equals(storePricingGB.getP().getR().get(k).getEt().toString().substring(0,10))){
 						logEndDateRulePassed(id1, "R", storePricingGB.getP().getR().get(k).getIp().toString());
 					}
 				}
	 		}else{
	 			logEndDateRulePassed(id1,"R",null);
	 		} 
		 }
	 	 
	 
	}
	
	/**
	 * Validate the VD rule
	 */
	
	public void verifyVDrule(List<String> pricingBlob,String id1 ){
		
		if(offerPartGB.getFfm().getChannel().equals("VD")){
			 if(storePricingGB.getP()!=null &&storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
				// CompareValuesUtility.logFailed("Price","","X price "+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for VD");
				//	log.error("X price for "+id1+ "-"+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for VD"); 
			 for(String div :pricingBlob ){
					 String[] afterSplit1 = div.split("\\|");
					 String priceType1=afterSplit1[3];
					 String price1=afterSplit1[6]; 
				 double prices = Double.parseDouble(price1); 
				 if(priceType1.equalsIgnoreCase("x") && (prices<=0.02)){
					 for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
		 					if (prices==(storePricingGB.getP().getX().get(k).getIp())){
		 						log.info("X price is valid");
		 					}
		 				} 
				 }else{
					 if(priceType1.equalsIgnoreCase("x") && (prices>0.02)){
					 for (int k = 0; k < storePricingGB.getP().getX().size(); k++) {
		 					if (prices==(storePricingGB.getP().getX().get(k).getIp())){
		 						CompareValuesUtility.logFailed("Price","","X price "+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for VD");
								log.error("X price for "+id1+ "-"+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for VD");
		 					}
		 				} 
					 }
				 }
				 }
			 }
		 }	
	}
	
	/**
	 * Validate the GiftCard item rule
	 */
	
	public void verifyGCrule(String id1, String startDate){
	
		String gcStartDate = JodaDateTimeUtility.getJodaTimeFormatString(startDate);
		if(offerPartGB.getFfm().getChannel().equals("GC") || offerPartGB.getFfm().getChannel().equals("VGC")){
			String price=LoadProperties.GC_PRICE;
			 Float fl = Float.parseFloat(price.trim());
				price = fl.toString();
				String endDate=LoadProperties.GC_DATE;
				String gcEndDate = JodaDateTimeUtility.getJodaTimeFormatString(endDate);	
		    String priceType="R";
		    if(storePricingGB.getP()!=null && storePricingGB.getP().getR()!=null){
			    for (int k = 0; k < storePricingGB.getP().getR().size(); k++) {
			    	CompareValuesUtility.logPassed("PriceType", priceType, "R");
			    	CompareValuesUtility.compareValues("Price",price, storePricingGB.getP().getR().get(k).getIp().toString());
			    	CompareValuesUtility.compareValues("StartDate",gcStartDate, storePricingGB.getP().getR().get(k).getSt().toString());
			    	CompareValuesUtility.compareValues("EndDate",gcEndDate, storePricingGB.getP().getR().get(k).getEt().toString());
			    	log.info(id1+ "- is a GC Item");
			    }
			    bFound=true;
		    }
		    if(storePricingGB.getP()!=null && storePricingGB.getP().getX()!=null && storePricingGB.getP().getX().size()!=0){
		    	CompareValuesUtility.logFailed("Price","","X price "+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for GC/VGC Items");
		    	log.error("X price for "+id1+ "-"+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for GC/VGC Items");
		    	bFound=true;
		    }
		    if(storePricingGB.getP()!=null && storePricingGB.getP().getS()!=null && storePricingGB.getP().getS().size()!=0){
		    	CompareValuesUtility.logFailed("Price","","P price "+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for GC/VGC Items");
		    	log.error("P price for "+id1+ "-"+storePricingGB.getP().getX().get(0).getIp().toString()+ " should be null for GC/VGC Items");
		    	bFound=true;
		    }
		}
	}
	
	/**
	 * Validate the GiftCard item rule
	 */
	public void verifyJennAirRule(String id1){
		if(contentPartGB.getBrand()!=null && contentPartGB.getBrand().getName()!=null){
			 if(contentPartGB.getBrand().getName().equals("Jenn-Air")){
				 CompareValuesUtility.logFailed("Comments","","Jenn-Air items should not be loaded");	
				 log.error("Jenn- Air items "+id1+  "should not be loaded");
				 bFound=true;
				 
			 }
		 }	
		
	}
	
	/**
	 * Validate the Hardline item rule
	 */
	public void verifyHardlineRule(List<String>pricingBlob,String id1, boolean xPresent ){
		 ArrayList<HardListVO> hardlineList = new ArrayList<HardListVO>();
		 ArrayList<String> hardline = new ArrayList<String>();
		 for(String div :pricingBlob ){
			 String[] afterSplit3 = div.split("\\|");	
//			 String hardstoreId=afterSplit3[0];
				String hardproductId=afterSplit3[2];
				String hardpriceType=afterSplit3[3];
				String hardstartDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[4]);
				String hardendDate=JodaDateTimeUtility.getJodaTimeFormatString(afterSplit3[5]);
				String hardprice=afterSplit3[6];
				Double hardlinePrice= Double.parseDouble(hardprice);
					 partnumId=hardproductId;
					 if(offerPartGB==null || contentPartGB==null){
						// log.fatal(id1+" -Not in GB");
						 check = true;
						 bFound=true;
					 }else{
						 if(storePricingGB!=null){
				if(LoadProperties.DIVISION_ID.contains(hardproductId.substring(0, 3)) && ((offerPartGB.getFfm()!=null && offerPartGB.getFfm().getChannel()!=null && !(offerPartGB.getFfm().getChannel().equals("VD")))||offerPartGB.getFfm()==null ||offerPartGB.getFfm().getChannel()==null )){
					if(compareActiveDates(hardstartDate.substring(0, 10), hardendDate.substring(0, 10)) == true){
						if(offerPartGB.getReplenishment()!=null && offerPartGB.getReplenishment().getInternalRimSts()!=null && offerPartGB.getClassifications()!=null && offerPartGB.getClassifications().getOfferType()!=null){
							if(((hardpriceType.equalsIgnoreCase("r")&&hardlinePrice>0.02)||(hardpriceType.equalsIgnoreCase("p")&&hardlinePrice>0.02 && ((offerPartGB.getPriceDispAttr()==null)||((offerPartGB.getPriceDispAttr().getIsExcptVal()==null)&&(offerPartGB.getPriceDispAttr().getIsEvryDayPrc()==null))||(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsEvryDayPrc()!=null &&!(offerPartGB.getPriceDispAttr().getIsEvryDayPrc()))||(offerPartGB.getPriceDispAttr()!=null && offerPartGB.getPriceDispAttr().getIsExcptVal()!=null &&!(offerPartGB.getPriceDispAttr().getIsExcptVal())))))&& !(xPresent)&& LoadProperties.RIM_STATUS.contains(offerPartGB.getReplenishment().getInternalRimSts())&& offerPartGB.getClassifications().getOfferType().toString().equals("NV")){
							hardlineList.add(new HardListVO(hardprice, hardstartDate, hardendDate));
							hardline.add(hardprice);
						}
						}
					}
				
				}
						 }
						 }
		 }
		 
		 if(!(hardlineList.isEmpty())){
		
			
	    Object minValue = Collections.min(hardline);
	   if(minValue!=null){
		   String startdate=null;
		   String enddate=null;
		   String newprice=null;
		   ArrayList<String> startDateList = new ArrayList<String>();
	    for(HardListVO st:hardlineList){
	    if(st.hardprice.equals(minValue)){
	    	startdate = st.hardstartDate;
	    	enddate = st.hardendDate;
	    	newprice = st.hardprice;
	    	
	    	startDateList.add(startdate);	
	    
	    }
	    }
	    startdate=Collections.max(startDateList);
	    for(HardListVO st:hardlineList){
	    	if(st.hardstartDate.equals(startdate)&&st.hardprice.equals(minValue)){	
	    		enddate = st.hardendDate;	
	    	}
	    }
	    validatePrices("X", startdate.substring(0, 10), enddate,newprice, storePricingGB); 
	    hardlinechk=true;
	    log.info(id1+" Item is a hardline item");
	   }
		 }	
	}
	/**
	 * Marks price data as failed
	 * @param priceType
	 * @param startDate
	 * @param endDate
	 * @param price
	 */
	private void logPriceFailed(String priceType, String startDate, String endDate, String price){
		CompareValuesUtility.logFailed("PriceType", priceType, "Not found");
		CompareValuesUtility.logFailed("Price",price,"price not found in GB");
		CompareValuesUtility.logFailed("StartDate", startDate,"Not found");
		CompareValuesUtility.logFailed("EndDate", endDate, "Not found");
		
	}

	public boolean compareDates(String a, String b) { // method to check if date
														// is valid or not
		Date d = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date c1 = sf.parse(sf.format(d)); // /to get current date

//			Date a1 = sf.parse(a);
			Date b1 = sf.parse(b);

			if (b1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
																// dates in the
																// input file
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
	}

	
	public boolean compareActiveDates(String a, String b) { // method to check if date
		// is valid or not
		Date d = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date c1 = sf.parse(sf.format(d)); // /to get current date

			Date a1 = sf.parse(a);
			Date b1 = sf.parse(b);

			if (a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0 ) // to compare a1.compareTo(c1) <= 0 &&
										// b1.compareTo(c1) >= 0
			// dates in the
			// input file
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
	}
	
	public boolean compareBetween(String a, String b,String c) { // method to check if date
		// is valid or not
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {

			Date a1 = sf.parse(a);
			Date b1 = sf.parse(b);
			Date c1 = sf.parse(c);
			
			if (a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0 ) // to compare a1.compareTo(c1) <= 0 &&
										// b1.compareTo(c1) >= 0
			// dates in the
			// input file
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
	}
	/**
	 * validates if store exists in store collection and adds the store to map
	 * if exists with value as true
	 * 
	 * @param stor
	 * @return
	 */
	public boolean validateStore(String stor) {
		if (storeIds.containsKey(stor)) {
			boolean storeStatus = storeIds.get(stor);
			return storeStatus;
		} else {

			String com = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, stor);
			if (com != "[]" || com != null) {
				storeIds.put(stor, true);
				return true;
			} else {
				storeIds.put(stor, false);
				return false;
			}
		}

	}
	
	class HardListVO{
		String hardprice, 
		hardstartDate, 
		hardendDate;
		

		public HardListVO(String hardprice, String hardstartDate, String hardendDate) {
			
			this.hardprice = hardprice;
			this.hardstartDate = hardstartDate;
			this.hardendDate = hardendDate;
			
		}
	}

	class PromoVO{
		String ruleprice,
		rulepriceType,
		rulestartDate, 
		ruleendDate;
		

		public PromoVO(String ruleprice,String rulepriceType, String rulestartDate, String ruleendDate) {
			
			this.ruleprice = ruleprice;
			this.rulepriceType = rulepriceType;
			this.rulestartDate = rulestartDate;
			this.ruleendDate = ruleendDate;
			
		}
	}
	
	/*class DPpriceVO{
		Double ip;
		String startDate, endDate;
		public DPpriceVO(Double ip, String startDate, String endDate) {
			
			this.ip = ip;
			this.startDate = startDate;
			this.endDate = endDate;
			
		}
	}*/
	
	class PriceDetailVO{
		String type, price, startDate, endDate;
		public PriceDetailVO(String type, String startDate, String endDate, String price) {
			
			this.type = type;
			this.price = price;
			this.startDate = startDate;
			this.endDate = endDate;
			
		}
	}
	class NationalPriceDetailVO{
		String type, price, startDate, endDate, endTime, startTime;
		public NationalPriceDetailVO(String type, String startDate, String endDate, String price) {
			
			this.type = type;
			this.price = price;
			this.startDate = startDate;
			this.endDate = endDate;
		}
	}
		
	
	
}
