package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.http.client.utils.URIBuilder;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.content.Assets;
import com.generated.vos.content.Attachment;
import com.generated.vos.hierarchy.Attr;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.offer.AltIds;
import com.generated.vos.offer.AlternateImg;
import com.generated.vos.offer.Condition;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.DeluxOpt;
import com.generated.vos.offer.DispTags;
import com.generated.vos.offer.Fee;
import com.generated.vos.offer.Fee_;
import com.generated.vos.offer.Ffm;
import com.generated.vos.offer.Grocery;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.PriceDispAttr;
import com.generated.vos.offer.Replenishment;
import com.generated.vos.offer.Shipping;
import com.generated.vos.offer.Sites;
import com.generated.vos.offer.Sites_;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.Val;
import com.generated.vos.productoffering.Attribute;
import com.generated.vos.productoffering.FeatureImages;
import com.generated.vos.productoffering.Fees;
import com.generated.vos.productoffering.ImageElementsGroup;
import com.generated.vos.productoffering.ImageUrl;
import com.generated.vos.productoffering.MapPriceRule;
import com.generated.vos.productoffering.MapPriceRulesInfo;
import com.generated.vos.productoffering.OperationalAttribute;
import com.generated.vos.productoffering.OperationalValue;
import com.generated.vos.productoffering.ProductAsset;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.ShipDimension;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.Source;
import com.generated.vos.productoffering.VariantAttribute;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.VendorPack;
import com.generated.vos.productoffering.types.AttributeTypeType;
import com.generated.vos.productoffering.types.ChokingHazardType;
import com.generated.vos.productoffering.types.GlobalAttributeType;
import com.generated.vos.productoffering.types.UpcTypeType;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.tests.SHC_OfferLoadTest_New;

public class SHC_OfferVerifications_New implements Runnable 
{
	SingleProductOffer singleProductOffer;
	VariationProductOffer varProdOffer;

	ProductContent prodContent;
	ProductOffer[] prodOffers;
	SHCContentCommons commonUtils;
	String itemClassId;
	Boolean bSingleProductOffer = true, isSearsOffers = true;
	private String parentId;
	String siteToTest, partNumberToTest;
	List<String> errorPartNumbers;
	String upcToCheck = null;
	private boolean bCrossFormattedItem;
	private boolean validHierarchy;

	public SHC_OfferVerifications_New(SingleProductOffer wNodeListToTest,
			 String itemClassId,
			VariationProductOffer varProdOffer, String sSite,
			List<String> erroredPartNumbers) {

		if (wNodeListToTest == null) {
			bSingleProductOffer = false;
		}
		this.singleProductOffer = wNodeListToTest;
		commonUtils = new SHCContentCommons(sSite);
		
		//Setting offer for difference between content and offer collections on certain parameters
		commonUtils.setOfferTest();
		
		this.itemClassId = itemClassId;
		this.varProdOffer = varProdOffer;
		this.siteToTest = sSite;
		this.errorPartNumbers = erroredPartNumbers;
	}

	public void run() {

		this.getContentToTest();

		APIResponse<Offer> allResponse;
		boolean bTaxonomyCheck = true;
		for (ProductOffer pOffer : prodOffers) {
			if (bSingleProductOffer) {
				if (partNumberToTest == null)
					continue;

				//  if(!partNumberToTest.equals("07711250034")) return;

				if (errorPartNumbers.contains(partNumberToTest)	|| errorPartNumbers.contains(parentId)) {
					System.out.println("Skipping  " + partNumberToTest);
					continue;
				}

				//if(partNumberToTest!=null&&!partNumberToTest.contains("04160719004")) return;
				allResponse = RestExecutor.getAllDataById(
						CollectionValuesVal.OFFER, partNumberToTest);
				if (!checkIfTaxAvailable(allResponse, bTaxonomyCheck))
					return;
				bCrossFormattedItem = commonUtils.isCrossFormattedItem(prodContent, siteToTest, singleProductOffer, null, bSingleProductOffer);

				callVerifs(pOffer, allResponse, partNumberToTest);
			} else {
				String partNumber = (siteToTest.equalsIgnoreCase("sears") ? pOffer
						.getPartNumber().getSearsPartNumber() : pOffer
						.getPartNumber().getKmartPartNumber());

				if (partNumber == null || parentId.equals("nullP"))
					continue;

				if (errorPartNumbers.contains(partNumber)
						|| errorPartNumbers.contains(parentId)) {
					System.out.println("Skipping  " + partNumber + " parent : "
							+ parentId);
					continue;
				}

				partNumberToTest = partNumber;
				//if(partNumberToTest!=null&&!partNumberToTest.contains("04160719004")) return;
				allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, partNumber);
				bTaxonomyCheck = checkIfTaxAvailable(allResponse,bTaxonomyCheck);
				if (!bTaxonomyCheck)
					continue;
				bCrossFormattedItem = commonUtils.isCrossFormattedItem(prodContent, siteToTest, singleProductOffer, pOffer, bSingleProductOffer);
				callVerifs(pOffer, allResponse, partNumber);
			}

		}
	}
	
	private boolean checkIfTaxAvailable(APIResponse<Offer> offer, Boolean bTaxonomyCheck){
		if(siteToTest.equals("sears")){
			if(!bTaxonomyCheck || !commonUtils.isSiteTaxonomyAvailable(prodContent.getSite(),2L )){
				//Check if the only site available in sites section is Kmart, then validate, item is not loaded
				if(!bTaxonomyCheck || prodContent.getSite().length == 1 && commonUtils.isSiteTaxonomyAvailable(prodContent.getSite(),1L )){
					CompareValuesUtility.init();
					CompareValuesUtility.verifyNull("Id", offer.getT(), "Only Kmart hierarchy present");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return false;
				}
			}
		}
		if(siteToTest.equals("kmart")){
			if(!commonUtils.isSiteTaxonomyAvailable(prodContent.getSite(),1L )){
				//Check if the only site available in sites section is Kmart, then validate, item is not loaded
				if(prodContent.getSite().length == 1 && commonUtils.isSiteTaxonomyAvailable(prodContent.getSite(),2L )){
					CompareValuesUtility.init();
					CompareValuesUtility.verifyNull("Id", offer.getT(), "Only Sears hierarchy present");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return false;
				}
			}
		}
		return true;
	}

	private void callVerifs(ProductOffer xmlProductOffer, APIResponse<Offer> allResponse, String offerId) {
		try {
			CompareValuesUtility.init();
			Offer gbOffer = (Offer) allResponse.getT();

			if (gbOffer == null) {
				CompareValuesUtility.logFailed("Id", offerId, " Not found");
				CompareValuesUtility.setupResult(offerId, true);
				return;
			}
			
			verifyOffer(xmlProductOffer, gbOffer, offerId, siteToTest);
			verifySearch(xmlProductOffer, allResponse);
			CompareValuesUtility.setupResult(offerId, true);
			
		} catch (Throwable e) {
			System.out.println("Check this id :" + offerId);
			e.printStackTrace();
		} finally {
			CompareValuesUtility.teardown();
		}
	}

	private void getContentToTest() {

		if (bSingleProductOffer) {

			if (siteToTest.equalsIgnoreCase("sears")) {
				isSearsOffers = true;
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getSearsPartNumber();

			} else {
				isSearsOffers = false;
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getKmartPartNumber();
			}

			parentId = partNumberToTest + "P";
			prodContent = singleProductOffer.getProductContent();
			prodOffers = singleProductOffer.getProductOfferings()
					.getProductOffer();

		} else {

			if (siteToTest.equalsIgnoreCase("sears")) {
				isSearsOffers = true;
				parentId = varProdOffer.getVariationSearsPartNumber() + "P";
			} else {
				isSearsOffers = false;
				parentId = varProdOffer.getVariationKmartPartNumber() + "P";
			}

			prodContent = varProdOffer.getProductContent();
			prodOffers = varProdOffer.getProductOfferings().getProductOffer();
		}
	}

	OfferCommons offerCommon;

	private void verifyOffer(ProductOffer xmlProductOffer, Offer gbOffer,String sOfferId, String site)
	{

		System.out.println("Testing offer id: " + sOfferId); 
		CompareValuesUtility.addDataFieldForReport("itemclassid", itemClassId==null?"null":itemClassId);

		offerCommon = new OfferCommons(gbOffer);

		//Id, name, parentId
		offerCommon.commonVerifications(sOfferId, parentId, prodContent.getName(), false);

		//ssin, uid
		if(SHC_OfferLoadTest_New.checkSSINAndUID)
		{
			offerCommon.verifyIdentity(xmlProductOffer.getSsin(), xmlProductOffer.getGuid());
		}
		
		//brand, modelNo
		offerCommon.verifyBrandModel(prodContent.getBrand() == null ? null : prodContent.getBrand().getName(), prodContent.getManufacturerModelNumber());
		//offerType
		offerCommon.verifyClassifications(bSingleProductOffer);
		
		/* ---------------- assets --------------- */
		verifyAssets(prodContent, gbOffer);

		//sites
		//verifySites(prodContent, gbOffer.getSites());
		
		/*if(bCrossFormattedItem){
			System.out.println("Crossformatted "+ sOfferId);
			verifyOperational(gbOffer);
		}*/
		//altIds
		verifyAltIds(xmlProductOffer, gbOffer.getAltIds());
		//mainImg, swatchImg
		verifyImages(xmlProductOffer, gbOffer.getMainImg(), gbOffer.getSwatchImg());
		
		//alternateImg
		FeatureImages featImgs = xmlProductOffer.getFeatureImages();
		if(featImgs!=null)
			verifyAltImages(featImgs, gbOffer.getAlternateImg());
		else
			CompareValuesUtility.verifyNull("AlternateImg", gbOffer.getAlternateImg().isEmpty()?null:"AltImg found in GB");
		
		//shipping
		verifyShipping(xmlProductOffer.getShipDimension(), gbOffer.getShipping());
		//ffm
		verifyFFM(xmlProductOffer, gbOffer.getFfm(), site);
		verifyItemCondition(xmlProductOffer,gbOffer.getCondition());

		verifyReplenishment(xmlProductOffer, gbOffer.getReplenishment());

		try {
			if (bSingleProductOffer && site.equalsIgnoreCase("sears")) {
				verifyIsRgnEligible(gbOffer);
			}
		} catch (Exception e) {

			//System.out.println("Exception .. for IsRgnEligible .. "+e.getMessage());
		}

		verifyStoreTaxonomy(xmlProductOffer, gbOffer.getTaxonomy().getStore().getHierarchy());

		verifyTaxonomy(gbOffer,xmlProductOffer);

		/* ---------------- legal --------------- */
		Gson gson = new Gson();
		String json = gson.toJson(gbOffer);

		Legal legalTagGb = null;
		if(json.contains("\"legal\":{\"chokingHazards\":[]}"))
		{
			legalTagGb = null;
		}
		else
		{
			legalTagGb = gbOffer.getLegal();
		}

		verifyLegal(xmlProductOffer, legalTagGb);

		CompareValuesUtility.addNewMultiValuedFields();
		
		Grocery grocery = gbOffer.getGrocery();
		CompareValuesUtility.verifyNullOrTrue("Grocery", xmlProductOffer.getImaAttributes().getPerishableCode(), 
				grocery==null?null:grocery.getIsPerishable(), "IsPerishable");

		DispTags dis = gbOffer.getDispTags();

		boolean bDealFlash = false;
		for (Attribute a : xmlProductOffer.getImaAttributes().getAttribute()) {
			if (a.getName().equals("SYW_ITEM_TYPE"))
				CompareValuesUtility.compareValues("DispTags", a.getContent(),
						dis == null ? null : dis.getSywItemType(), "SYWItem");
			if (a.getName().equals("deal flash") && a.getContent().equals("1"))
				bDealFlash = true;
		}
		if (bDealFlash)
			compareValues("DispTags", true,
					dis == null ? null : dis.getIsDealFlash(), "DealFlash");
		else
			CompareValuesUtility.verifyNull("DispTags", dis == null ? null
					: dis.getIsDealFlash(), "DealFlash");
		compareValues("DispTags",
				checkInAttributeGroup("Good Housekeeping - Seal of Approval"),
				dis == null ? null : dis.getIsGhkApproved(), false, true, "GHK");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getViewOnlyCode(), dis == null ? null : dis.getViewOnly(),
						false, true, "ViewOnly");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getSearsExclusive(),
				dis == null ? null : dis.getIsSearsExclusive(), false, true,
				"SearsExcl");
		compareValues("DispTags", prodContent.getSearchSuppressionFlag(),
				dis == null ? null : dis.getIsSearchSupression(), false, true,
				"SearchSupp");
		compareValues("DispTags", prodContent.getTires(),
				dis == null ? null : dis.getIsTire(), false, true,
				"IsTire");

		checkFlagsFromAttribs(gbOffer.getDispTags(),
				gbOffer.getPriceDispAttr());

		CompareValuesUtility.addNewMultiValuedFields();

		if (xmlProductOffer.getVariantAttributes() != null)
			verifyDefiningAttrs(xmlProductOffer.getVariantAttributes()
					.getVariantAttribute(), gbOffer.getDefiningAttrs());
		CompareValuesUtility.addNewMultiValuedFields();

		testNewChanges(xmlProductOffer, gbOffer, sOfferId, site);

		testDeluxOption(xmlProductOffer, gbOffer, sOfferId, site);

		try 
		{
			testNewChanges5_20(xmlProductOffer, gbOffer, sOfferId, site);
		} 
		catch (Exception e) 
		{
			System.out.println("Check this offer ( error in testNewChanges5_20 ) : "+sOfferId);
			e.printStackTrace();
		}
	}
	
	private void verifyAssets(ProductContent pContentAsset, Offer gbOffer){

		if(pContentAsset.getProductAssets() != null){
			verifyAssetAttachments(pContentAsset.getProductAssets().getProductAsset(), gbOffer.getAssets() == null ? null : gbOffer.getAssets().getAttachments());
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifyAssetAttachments(ProductAsset[] productAsset, List<com.generated.vos.offer.Attachment> attachments) {

		for (ProductAsset attachmentAsset : productAsset) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO"))
			{
				continue;
			}

			Boolean bFound = false;
			convertType(attachmentAsset.getType().name());
			if(attachments != null)
			for (com.generated.vos.offer.Attachment gbAttachment : attachments) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(gbAttachment.getLink().getAttrs().getHref())
						&& !assetTypeGB.equals("PRODUCT_VIDEO")
						&& assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref", attachmentAsset.getUrl(), attachmentAsset.getUrl());
					compareValues("AttType", assetTypeGB, gbAttachment.getType());

					if (assetTypeGB.equals("MS"))
						compareValues("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					else
						compareValues("AttchmtName", assetName, gbAttachment.getName());

					if (assetName != null && assetName.contains("Spanish"))
						compareValues("AttchLang", "Spanish", gbAttachment.getLang());
					else
						compareValues("AttchLang", "English", gbAttachment.getLang());
					break;
				}


			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", assetTypeGB, "Not found");

			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	public String assetName, assetTypeGB;

	public void convertType(String assetType) {
		switch (assetType) {
		case "PRODUCT_WARRANTY": {
			assetTypeGB = "PW";
			assetName = "Product Warranty";
			break;
		}
		case "REBATES": {
			assetTypeGB = "RB";
			assetName = "Rebates";
			break;
		}
		case "MISCELLANEOUS": {
			assetTypeGB = "MS";
			assetName = null; // Explicitly setting in case previous loops set
			// it to some other value
			break;
		}
		case "ENGLISH_OWNER_MANUAL": {
			assetTypeGB = "EOM";
			assetName = "Owners manual - English";
			break;
		}
		case "ENERGY_GUIDE": {
			assetTypeGB = "EG";
			assetName = "Energy Guide";
			break;
		}
		case "SPANISH_OWNER_MANUAL": {
			assetTypeGB = "SOM";
			assetName = "Owners manual - Spanish";
			break;
		}
		case "SPANISH_WARRANTY": {
			assetTypeGB = "SW";
			assetName = "Spanish Warranty";
			break;
		}
		case "PRODUCT_VIDEO": {
			assetTypeGB = "PRODUCT_VIDEO";
			assetName = "Product Video";
			break;
		}
		default: {
			break;
		}
		}
	}

	
	private void verifyAltImages(FeatureImages featImgs, List<AlternateImg> alternateImg) {
		for (com.generated.vos.productoffering.FeatureImage fImage : featImgs.getFeatureImage()) {
			boolean bFound = false;
			for (AlternateImg altImg : alternateImg) {
				if (TestUtils.modifyURL(fImage.getImageElementsGroup().getUrl()).equals(altImg.getSrc())) {
					bFound = true;
					compareValues("AlternateImg", TestUtils.modifyURL(fImage.getImageElementsGroup().getUrl()), altImg.getSrc(), "Src");
					CompareValuesUtility.verifyNullOrEqual("AlternateImg", fImage.getImageElementsGroup().getName(), altImg.getTitle(), "Title");
					CompareValuesUtility.verifyNullOrEqual("AlternateImg", fImage.getImageElementsGroup().getWidth(), GenericUtil.convertToString(altImg.getWidth()), "Width");
					CompareValuesUtility.verifyNullOrEqual("AlternateImg", fImage.getImageElementsGroup().getHeight(), GenericUtil.convertToString(altImg.getHeight()), "Height");
				}
			}
			if (!bFound) {
				CompareValuesUtility.compareValues("AlternateImg", TestUtils.modifyURL(fImage.getImageElementsGroup().getUrl()), "Not found", "Src");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void verifySites(ProductOffer xmlProductOffer, List<String> sites) {

		for(com.generated.vos.productoffering.Site s : xmlProductOffer.getSite()){

			if(siteToTest.equalsIgnoreCase("kmart") && (s.getId()==11 || s.getId()==6))
			{
				System.out.println("ignore "+s.getId()+" site for Kmart ..."+partNumberToTest);
				continue;
			}

			if( s.getId() != 13){
			if(s.getId() == 10 || s.getId() == 11)
				continue;
			}
			if((siteToTest.equalsIgnoreCase("sears") && s.getId() == 1) || (siteToTest.equalsIgnoreCase("kmart") && s.getId() == 2))
				continue;
			CompareValuesUtility.verifyItemInList("Site", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void testNewChanges5_20(ProductOffer xmlProductOffer, Offer gbOffer,
			String sOfferId, String site)
	{

		List<String> siteList = new ArrayList<String>();
		for(Site s : prodContent.getSite()){
			siteList.add(TestUtils.getSite(s.getId()));
		}
		
		Boolean isFreqModel = false;
		String isFreqMdTxt = null;
		
		VendorPack[] vendorPack = xmlProductOffer.getImaAttributes()==null?null: xmlProductOffer.getImaAttributes().getVendorPack();


		Object cost = null;
		if(vendorPack!=null)
		{
			for(VendorPack vendorPackk : vendorPack){
				if(vendorPackk.getStoreName().equalsIgnoreCase(siteToTest)){

					cost = vendorPackk.getCost();
				}
			}
		}

		/*It will come under vendor pack tag or can come under operational attributes where source="core system"*/
		if(cost!=null && !siteToTest.equalsIgnoreCase("sears"))
		{
			CompareValuesUtility.compareAsNumbers("Unit Cost-vendorPack", cost.toString(), gbOffer.getReplenishment().getUnitCost());
		}

		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		if(sources!=null)
		{
			String valueXml = null;
			String attrName = null;

			for (Source source : sources) {

				OperationalAttribute[] allAttributes = source.getOperationalAttribute();


				/*============================= SPIN =====================*/
				if(source.getName().equalsIgnoreCase("SPIN"))
				{
					Sites_ gbOperationalSites = gbOffer.getOperational()==null?null:gbOffer.getOperational().getSites();

					for (OperationalAttribute attribute : allAttributes) 
					{
						try {
							valueXml = attribute.getOperationalValue()[0].getValue();
						} catch (Exception e) {
							valueXml = null;
						}
						attrName = attribute.getName();

						Long siteId = attribute.getSiteId();

						switch(attrName.toUpperCase())
						{

						/*"Basically in input file we get tag
						  <operational-attribute name=""SYWR Redemption Ineligible""> which signifies inEligibilty,
						  however the tag in offer collection is SywRdmElig(eligiblity),
						  hence we need to do negation of the incoming value.
						  Below are the four possible scenario which will decide the value of this attribute:
						1. <operational-attribute name=""SYWR Redemption Ineligible"">Y</> then will be set as NULL.
						2.  <operational-attribute name=""SYWR Redemption Ineligible"">N</> then this attribute will be set.
						3. <operational-attribute name=""SYWR Redemption Ineligible"">ANy other value then this attribute will be set.
						4.  <operational-attribute name=""SYWR Redemption Ineligible""> tag is misssing in xml then this attribute will be set."*/

						case "SYWR REDEMPTION INELIGIBLE":

							//Only for Y values its TRUE
							if(valueXml!=null && valueXml.equalsIgnoreCase("Y"))
							{
								CompareValuesUtility.verifyNull("SYWR REDEMPTION INELIGIBLE", gbOffer.getDispTags()==null?null:
									gbOffer.getDispTags().getSywRdmElig());
							}
							else
							{
								// FOR all rest values like N, null, Any other value it should be true

								CompareValuesUtility.compareValues("SYWR REDEMPTION INELIGIBLE", true, gbOffer.getDispTags().getSywRdmElig());
							}


							break;

						case "CLICK_TO_CALL_VALUE":
							CompareValuesUtility.verifyNullOrEqual("CLICK_TO_CALL_VALUE", valueXml, gbOffer.getDispTags().getLpVoiceId());

							break;

						case "CLICK_TO_CHAT_VALUE":
							CompareValuesUtility.verifyNullOrEqual("CLICK_TO_CHAT_VALUE", valueXml, gbOffer.getDispTags().getLpChatId());

							break;

							//Need extra logic : If click to chat or click to call is present then set click to talk .
							/*case "CLICK_TO_TALK":
							compareAsBoolean("CLICK_TO_TALK", valueXml, gbOffer.getDispTags().getIsClickToTalkElig());

							break;*/
						case "PRESELL_DATE":
							CompareValuesUtility.verifyNullOrEqual("PRESELL_DATE", valueXml, gbOffer.getPresell().getStreetDt());

							break;

						case "PRESELL_QTY":
							CompareValuesUtility.verifyNullOrEqual("PRESELL_QTY", valueXml, gbOffer.getPresell().getQty());

							break;

						case "PDP_FULFILLMENT_DEFAULT":
							CompareValuesUtility.verifyNullOrEqual("PDP_FULFILLMENT_DEFAULT", valueXml, gbOffer.getFfm().getDfltFfmDisplay());

							break;

						case "DELAYED_DELIVERY_INELIGIBLE":
							compareAsBoolean("DELAYED_DELIVERY_INELIGIBLE", valueXml, gbOffer.getDispTags()==null?null
									:gbOffer.getDispTags().getIsDlydDlvryInelig());
							break;


						case "CONSUMABLES_TEMPLATE":

							compareAsBoolean("CONSUMABLES_TEMPLATE", valueXml, gbOffer.getDispTags().getIsConsmTemplate());
							break;
						case "SHIP_ALONE":

							compareAsBoolean("SHIP_ALONE", valueXml, gbOffer.getShipping().getIsShipAlone());
							break;

						case "SIMI":

							compareAsBoolean("SIMI", valueXml, gbOffer.getShipping().getIsSimiElig());
							break;

						case "FLAT_RATE_SHIPPING":

							compareAsBoolean("FLAT_RATE_SHIPPING", valueXml, gbOffer.getShipping().getIsFlatRateShip());
							break;

						case "IS_FREQUENCY_MODEL":
							isFreqModel = (valueXml.equals("Y")||valueXml.equals("YES"))?true:false;
							if(isFreqMdTxt!=null){
								compareAsBoolean("IS_FREQUENCY_MODEL", valueXml, gbOffer.getDispTags().getIsPriceFreqModel());
								CompareValuesUtility.verifyNullOrEqual("FREQUENCY_MODEL_TEXT", isFreqMdTxt, gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getPriceFreqMdlTxt());
							}
							break;

						case "FREQUENCY_MODEL_TEXT":
							isFreqMdTxt = valueXml;
							if(isFreqModel){
								compareAsBoolean("IS_FREQUENCY_MODEL", "Y", gbOffer.getDispTags().getIsPriceFreqModel());
								CompareValuesUtility.verifyNullOrEqual("FREQUENCY_MODEL_TEXT", valueXml, gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getPriceFreqMdlTxt());
							}
							break;

						case "GROUND_ONLY":

							compareAsBoolean("GROUND_ONLY", valueXml,
									gbOffer.getShipping()==null?null:gbOffer.getShipping().getIsGroundOnly());
							break;

						case "EXPRESS_CHECKOUT":

							compareAsBoolean("EXPRESS_CHECKOUT", valueXml, gbOffer.getDispTags()==null?null
									:gbOffer.getDispTags().getIsExpressCheckoutElig());
							break;

						case "GIFT WRAP FLAG":

							compareAsBoolean("GIFT WRAP FLAG", valueXml,gbOffer.getDispTags()==null?null:
								gbOffer.getDispTags().getIsGiftWrapElig());
							break;

						case "PREMIUM_SHIPPING":

							compareAsBoolean("PREMIUM_SHIPPING", valueXml, gbOffer.getDispTags()==null?null:
								gbOffer.getDispTags().getIsPremShipElig());
							break;

						case "REQUIRED_ACCESSORIES_DISPLAY_TYPE":

							CompareValuesUtility.compareValues("REQUIRED_ACCESSORIES_DISPLAY_TYPE", valueXml, gbOffer.getDispTags()==null?null:
								gbOffer.getDispTags().getReqAccDispType());
							break;

							//CONTENT
							/*case "SCHEDULE_NOW":

							compareAsBoolean("SCHEDULE_NOW", valueXml, gbOffer.getDispTags().getIsPremShipElig());
							break;*/


						case "MAX_QTY_PURCHASABLE":

							List<String> sitesList = gbOffer.getSites();


							Sites sites;
							try {
								sites = gbOffer.getShipping().getMaxQntyPurchasable().getSites();
							} catch (Exception e) {
								sites =null;
							}

							if(siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) && TestUtils.getSite(siteId).equalsIgnoreCase("sears"))
							{
								if(sitesList!=null && sitesList.contains("sears"))
								{
									CompareValuesUtility.compareAsNumbers("MAX_QTY_PURCHASABLE", valueXml, 
											sites==null||sites.getSears()==null?null:sites.getSears().getVal(),"sears") ;
								}
							}
							else if(siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) && TestUtils.getSite(siteId).equalsIgnoreCase("kmart"))
							{
								if(sitesList!=null && sitesList.contains("kmart"))
								{
									CompareValuesUtility.compareAsNumbers("MAX_QTY_PURCHASABLE", valueXml, 
											sites==null||sites.getKmart()==null?null:sites.getKmart().getVal(),"kmart") ;
								}
							}
							break;

						case "RESERVE_IT_ELIGIBLE":

							if(siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) && TestUtils.getSite(siteId).equalsIgnoreCase("sears")
									&& siteList.contains("sears"))
							{
								compareAsBoolean("RESERVE_IT_ELIGIBLE", valueXml, 
										gbOperationalSites==null?null:gbOperationalSites.getSears().getIsReserveIt()) ;
							}
							else if(siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) && TestUtils.getSite(siteId).equalsIgnoreCase("kmart")
									&& siteList.contains("kmart"))
							{
								compareAsBoolean("RESERVE_IT_ELIGIBLE", valueXml, 
										gbOperationalSites==null?null:gbOperationalSites.getKmart().getIsReserveIt()) ;
							}
							else if(TestUtils.getSite(siteId).equalsIgnoreCase("mygofer")
									&& siteList.contains("mygofer"))
							{
								//TODO confirm with VINIT
								/*	CompareValuesUtility.compareValues("RESERVE_IT_ELIGIBLE", valueXml, 
										sitess.getMygofer().getIsReserveIt()) ;*/
							}
							break;

//						case "DELUXE SCIM CODE":
//							
//							for(OperationalValue deluxOpt : attribute.getOperationalValue()){
//								String dispType = null;
//								String questText = null;
//								if(deluxOpt.getGroupingId()!=null){
//									for(OperationalAttribute operAttr : allAttributes){
//										if(operAttr.getName().equals("DELUXE DISPLAY OPTION TYPE")){
//											for(OperationalValue operVal : operAttr.getOperationalValue()){
//												if(operVal.getGroupingId()!=null && operVal.getGroupingId().equals(deluxOpt.getGroupingId())){
//													dispType = operVal.getValue();
//													break;
//												}
//											}
//											break;
//										}
//									}
//									for(OperationalAttribute operAttr : allAttributes){
//										if(operAttr.getName().equals("DELUXE QUESTION TEXT")){
//											for(OperationalValue operVal : operAttr.getOperationalValue()){
//												if(operVal.getGroupingId()!=null && operVal.getGroupingId().equals(deluxOpt.getGroupingId())){
//													questText = operVal.getValue();
//													break;
//												}
//											}
//											break;
//										}
//									}
//								}
//								//Fetch default "display option" and "question text" if grouping-id is not matching for any one of them
//								if(dispType==null || questText==null){
//									String deluxOptTxt = getDeluxOptAndTxt(deluxOpt.getValue());
//									if(deluxOptTxt!=null){
//										dispType = deluxOptTxt.substring(0, deluxOptTxt.indexOf("@@"));
//										questText = deluxOptTxt.substring(deluxOptTxt.indexOf("@@")+2);
//									}
//								}
//								//skip scim code if not matching with configured values
//								if(dispType==null || questText==null)
//									continue;
//								
//								Boolean dFound = false;
//								if(gbOffer.getDispTags().getDeluxOpt()==null){
//									CompareValuesUtility.logFailed("DELUXE SCIM CODE",deluxOpt.getValue()==null?"null":deluxOpt.getValue(),"null");
//								}else{
//									for(DeluxOpt gbDeluxOpt : gbOffer.getDispTags().getDeluxOpt()){
//										if(deluxOpt.getValue().equals(gbDeluxOpt.getQuestScimCd())){
//											dFound = true;
//											CompareValuesUtility.logPassed("DELUXE SCIM CODE", deluxOpt.getValue(), gbDeluxOpt.getQuestScimCd());
//											CompareValuesUtility.compareValues("DELUXE DISPLAY OPTION TYPE", dispType, gbDeluxOpt.getDispType());
//											CompareValuesUtility.compareValues("DELUXE QUESTION TEXT", questText, gbDeluxOpt.getQuestTxt());									
//											break;
//										}
//									}
//									if(!dFound){
//										CompareValuesUtility.logFailed("DELUXE SCIM CODE",deluxOpt.getValue()==null?"null":deluxOpt.getValue(),"Not found in GB");
//									}
//								}
//								CompareValuesUtility.addNewMultiValuedFields();
//							}
//							break;
												}

					}
				}
				/*============================= Finance System =====================*/
				else if(source.getName().equalsIgnoreCase("Finance System"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{

						}
					}
				}
				/*============================= IMA =====================*/
				else if(source.getName().equals("IMA"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{

						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{
						}
					}
				}
				/*============================= RIM =====================*/
				else if(source.getName().equals("RIM"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{
						}
					}
				}
				else if(source.getName().equalsIgnoreCase("Core System"))
				{
					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("Unit Cost-Core System"))
						{
							CompareValuesUtility.compareAsNumbers("Unit Cost", valueXml, gbOffer.getReplenishment().getUnitCost());
						}
					}
				}
			}
		}

		validateMapPrice(xmlProductOffer, gbOffer, sOfferId, site);
	}



	private void validateMapPrice(ProductOffer xmlProductOffer, Offer gbOffer,String sOfferId, String siteName)
	{
		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		siteName=siteName==null?siteToTest:siteName;

		boolean bMapRule=false,bMapThrValue=false,bMapThrType=false;
		String sMapRule="",sMapThrValue="",sMapThrType="";
		boolean bMapRuleGeneral=true,bMapThrValueGeneral=true,bMapThrTypeGeneral=true;

		if(sources!=null)
		{
			String Val;

			for (Source source : sources) {

				OperationalAttribute[] allAttributes = source.getOperationalAttribute();

				/*============================= SPIN =====================*/
				if(source.getName().equalsIgnoreCase("SPIN"))
				{
					for (OperationalAttribute attribute : allAttributes) 
					{
						OperationalValue[] opValues = attribute.getOperationalValue();

						Long siteId = attribute.getSiteId();

						if(siteId!=null && TestUtils.getSite(siteId)!=null && !siteName.equalsIgnoreCase(TestUtils.getSite(siteId)))
						{
							continue;
						}

						for (OperationalValue operationalValue : opValues) 
						{

							Val  = operationalValue.getValue();

							String startdate = operationalValue.getStartDtm()==null?null:operationalValue.getStartDtm().toString();

							String enddate = operationalValue.getEndDtm()==null?null:operationalValue.getEndDtm().toString();

							if( validateDate(startdate, enddate) )
							{
								switch(attribute.getName().toUpperCase())
								{
								case "MAP_RULE":{
									if(bMapRuleGeneral){
										bMapRule = true;
										sMapRule= Val;
									}
									if(enddate == null && startdate == null){
										bMapRuleGeneral = true;
									}else{
										bMapRuleGeneral=false;
									}
									break;
								}
								case "MAP_THRESHOLD_VALUE":{
										System.out.println("Dates : "+ startdate + " "+ enddate + partNumberToTest);
									if(bMapThrValueGeneral){
										sMapThrValue= Val;
										bMapThrValue =true;
									}
									if(enddate == null && startdate == null){
										bMapThrValueGeneral = true;
									}else{
										bMapThrValueGeneral=false;
									}
										System.out.println("map threshold value now "+ bMapThrValueGeneral + "  "+ sMapThrValue + partNumberToTest);
									
									break;
								}
								case "MAP_THRESHOLD_TYPE":{
									if(bMapThrTypeGeneral){
										sMapThrType=Val;
										bMapThrType=true;
									}
									if(enddate == null && startdate == null){
										bMapThrTypeGeneral = true;
									}else{
										bMapThrTypeGeneral=false;
									}
									break;
								}
								}
							}
						}
					}
				}
			}

			if(bMapRule && bMapThrValue && bMapThrType)
			{
				MapPriceRulesInfo mapPriceRuleInfo = xmlProductOffer.getMapPriceRulesInfo();

				if(mapPriceRuleInfo!=null)
				{
					MapPriceRule[] mapPriceRules = mapPriceRuleInfo.getMapPriceRule();

					String rule;

					if(mapPriceRules.length!=0)
					{
						for (MapPriceRule mapPriceRule : mapPriceRules) 
						{
							rule = String.valueOf(mapPriceRule.getMapRule().intValue());

							if(sMapRule.equals(rule))
							{
								//got valid value we got for the MAP_RULE attrbute, same value should be present in <map-price-rules-info><map-rule> tag

								CompareValuesUtility.compareAsNumbers("MAP_RULE", sMapRule,gbOffer.getPriceDispAttr() == null ? null : gbOffer.getPriceDispAttr().getMapVal());
								CompareValuesUtility.verifyNullOrEqual("MAP_THRESHOLD_VALUE", sMapThrValue,gbOffer.getPriceDispAttr() == null ? null : gbOffer.getPriceDispAttr().getMapThrshld());
								CompareValuesUtility.verifyNullOrEqual("MAP_THRESHOLD_TYPE", sMapThrType,gbOffer.getPriceDispAttr() == null ? null : gbOffer.getPriceDispAttr().getMapValMode());
								CompareValuesUtility.verifyNullOrEqual("MAP_message", mapPriceRule.getMessage(),gbOffer.getPriceDispAttr() == null ? null : gbOffer.getPriceDispAttr().getMapMsg());
								CompareValuesUtility.verifyNullOrEqual("MAP_description", mapPriceRule.getDescription(),gbOffer.getPriceDispAttr() == null ? null : gbOffer.getPriceDispAttr().getMapDesc());
							}
						}
					}
				}
			}
		}
	}
	private boolean validateDate(String startdate,String enddate) {
		try {
			boolean isValid = false;
			Date jobStartTime = CommonSHCConstants.JOB_START_TIME;

			if (startdate == null && enddate == null) {
				return true;
			}

			if (startdate != null && enddate == null) {
				enddate = CommonSHCConstants.ENDDATE;
			}

			// added condition if we get start date as null nut we get a valid end date
			if (startdate == null && enddate != null) {
				startdate = CommonSHCConstants.STARTDATE;
			}
			Date mapPriceStartDate = null;
			Date mapPriceEndDate = null;

			try {
				mapPriceStartDate = CommonSHCConstants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE.parse(startdate
						+ CommonSHCConstants.STARTTIME);
				mapPriceEndDate = CommonSHCConstants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE.parse(enddate
						+ CommonSHCConstants.ENDTIME);
			} catch (Exception e) {
				/*e.printStackTrace();
				System.out.println("error parsing startdate: " + startdate + "  or enddate:" + enddate);*/
				return false;
			}
			Date endOfTodaysTime = CommonSHCConstants.endOfTodayTime.getTime();

			long diff = TimeUnit.MILLISECONDS.toHours(endOfTodaysTime.getTime() - jobStartTime.getTime());

			if (diff >= CommonSHCConstants.MAP_PRICE_ARG_HOURS) {
				if (mapPriceStartDate.compareTo(jobStartTime) < 0 && mapPriceEndDate.compareTo(jobStartTime) >= 0) {
					isValid = true;
				}
			} else {
				if (mapPriceStartDate.compareTo(DateUtils.addHours(jobStartTime, CommonSHCConstants.MAP_PRICE_ARG_HOURS)) < 0
						&& mapPriceEndDate.compareTo(DateUtils.addHours(jobStartTime,
								CommonSHCConstants.MAP_PRICE_ARG_HOURS)) >= 0) {
					isValid = true;
				}
			}
			return isValid;
		} catch (Exception e) {

			System.out.println(e.getMessage()==null?"null":e.getMessage());
			return false;
		}
	}

	private void compareAsBoolean(String field,String sExpectedvalue,Boolean actaul)
	{
		Boolean bExpectedvalue = false;
		if(sExpectedvalue.equals("1") || sExpectedvalue.equals("YES") || sExpectedvalue.equals("Y"))
		{
			bExpectedvalue = true;
		}
		else if (sExpectedvalue.equals("0") || sExpectedvalue.equals("NO")|| sExpectedvalue.equals("N"))
		{
			bExpectedvalue = false;
		}

		//false and null is equal

		if(actaul==null && bExpectedvalue==false)
		{
			CompareValuesUtility.logPassed(field, "false", "null");
		}
		else
		{
			CompareValuesUtility.compareValues(field, bExpectedvalue, actaul);
		}
	}
	/**
	 * Added on 7 April 2015 - by daffy -  for verify additional fields in load job
	 * @param xmlProductOffer
	 * @param gbOffer
	 * @param sOfferId
	 * @param site
	 */
	private void testNewChanges(ProductOffer xmlProductOffer, Offer gbOffer,
			String sOfferId, String site)
	{

		boolean bRimProduct =isRimProduct(xmlProductOffer);
		String ffFromXml="";
		try {
			ffFromXml = xmlProductOffer.getFulfillment().value();
		} catch (Exception e1) {
			ffFromXml="";
		}


		if( siteToTest.equalsIgnoreCase("kmart") && (ffFromXml.equalsIgnoreCase("FBM")))
		{
			String act = gbOffer.getReplenishment()==null?"null":gbOffer.getReplenishment().getRsosIndicator();

			compareValues("rsos ind", "YES", act);
		}

		//-----------------------

		/*String state = xmlProductOffer.getGeoLimiters().getStates();

		String actState = gbOffer.getLegal()==null||gbOffer.getLegal().getLimitedGeos()==null?null:gbOffer.getLegal().getLimitedGeos().toString();

		CompareValuesUtility.verifyNullOrEqual("offer.legal.limitedGeos ",state,actState);*/

		//-----------------------

		if(xmlProductOffer.getImaAttributes()!=null)
		{
			Attribute[] allAttrsIma = xmlProductOffer.getImaAttributes().getAttribute();

			for (Attribute attribute : allAttrsIma) {

				if(attribute.getName().equalsIgnoreCase("sears network distribution"))
				{
					if (!siteToTest.equalsIgnoreCase("kmart")) {
						CompareValuesUtility.verifyNullOrEqual("sears network distribution", attribute.getContent() ,
								gbOffer.getReplenishment()==null?null:gbOffer.getReplenishment().getSrNwDistCode());
					}					

				}

				else if(attribute.getName().equalsIgnoreCase("kmart network distribution"))
				{
					if (siteToTest.equalsIgnoreCase("kmart")) {
						CompareValuesUtility.verifyNullOrEqual("kmart network distribution", attribute.getContent() ,
								gbOffer.getReplenishment()==null?null:gbOffer.getReplenishment().getKmNwDistCode());
					}
				}

				else if(attribute.getName().equalsIgnoreCase("htc code"))
				{
					CompareValuesUtility.verifyNullOrEqual("htc code", attribute.getContent() ,
							gbOffer.getShipping()==null?null:gbOffer.getShipping().getHtcCode());
				}
				else if(attribute.getName().equalsIgnoreCase("exceptional value"))
				{
					if (siteToTest.equalsIgnoreCase("sears")) {
						boolean expVal  = false;

						if(attribute.getContent().equals("1"))
						{
							expVal = true;
						}
						CompareValuesUtility.verifyNullOrEqual("exceptional value", expVal,
								gbOffer.getPriceDispAttr().getIsExcptVal());
					}
				}
				/*recycle fee start*/
				else if(attribute.getName().equalsIgnoreCase("recycle fee"))
				{
					CompareValuesUtility.verifyNullOrEqual("recycleFee", attribute.getContent() ,
							gbOffer.getRclFee());
				}
				/*recycle fee end*/
			}

			if (siteToTest.equalsIgnoreCase("kmart")) {
				CompareValuesUtility.verifyNullOrEqual("calcode", xmlProductOffer.getImaAttributes().getTaxCode(),  gbOffer.getFfm()==null?null:gbOffer.getFfm().getCalCode());
			}
			
			/*state fees start*/
			if(xmlProductOffer.getImaAttributes().getStateFees()!=null && xmlProductOffer.getImaAttributes().getStateFees().getFees()!=null){
				if(gbOffer.getStFees()!=null && gbOffer.getStFees().getFees()!=null){
					Fees[] xmlStateFees = xmlProductOffer.getImaAttributes().getStateFees().getFees();
					for(Fees xsf : xmlStateFees){
						Boolean tFound = false;
						for(Fee gStFee : gbOffer.getStFees().getFees()){
							if(xsf.getType().equals(gStFee.getType())){
								tFound = true;
								CompareValuesUtility.logPassed("stateFee", xsf.getType(), gStFee.getType(), "type");
								for(com.generated.vos.productoffering.Fee xmlFee : xsf.getFee()){
									Boolean fFound = false;
									for(Fee_ gbFee : gStFee.getFee()){
										if((xmlFee.getState().equals(gbFee.getState()) && xmlFee.getTaxCd()==null)
												|| (xmlFee.getState().equals(gbFee.getState()) && xmlFee.getTaxCd().equals(gbFee.getTaxCd()))){
											fFound = true;
											CompareValuesUtility.logPassed("stateFee", xmlFee.getState(), gbFee.getState(), "state");
											CompareValuesUtility.verifyNullOrEqual("stateFee", xmlFee.getTaxCd(), gbFee.getTaxCd(), "taxcd");
											CompareValuesUtility.compareValues("stateFee", xmlFee.getContent().doubleValue(), gbFee.getVal(), "val");
											break;
										}
									}
									if(!fFound){
										CompareValuesUtility.logFailed("stateFee", xmlFee.getState(), "Not found in GB", "state");
									}
								}
								break;
							}
						}
						if(!tFound){
							CompareValuesUtility.logFailed("stateFee", xsf.getType(), "Not found in GB", "type");
						}
					}
				}
				else{
					CompareValuesUtility.logFailed("stateFee", xmlProductOffer.getImaAttributes().getStateFees(), "Not found in GB");
				}
			}else{
				CompareValuesUtility.verifyNull("stateFee", gbOffer.getStFees());
			}
			CompareValuesUtility.addNewMultiValuedFields();
			
			CompareValuesUtility.verifyNullOrEqual("rclFeeCnt", xmlProductOffer.getRecycleFeeItemCount(), gbOffer.getRclFeeCnt()==null?null:gbOffer.getRclFeeCnt().intValue());
			/*state fees end*/

		}
		String sExpVal;
		try {
			sExpVal = xmlProductOffer.getImaAttributes().getSeason().value();
		} catch (Exception e) {
			sExpVal = null;
		}

		CompareValuesUtility.verifyNullOrEqual("season code",sExpVal, gbOffer.getSeasonCode());

		VendorPack[] vendorPack = xmlProductOffer.getImaAttributes()==null?null: xmlProductOffer.getImaAttributes().getVendorPack();

		Object cost = null;
		if(vendorPack!=null)
		{
			for(VendorPack vendorPackk : vendorPack){
				if(vendorPackk.getStoreName().equalsIgnoreCase(siteToTest)){

					cost = vendorPackk.getCost();
				}
			}
		}

		if (siteToTest.equalsIgnoreCase("kmart")) {
			CompareValuesUtility.verifyNullOrEqual("unit-cost", cost , gbOffer.getReplenishment().getUnitCost());
		}

		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		if(sources!=null)
		{
			String valueXml = null;
			String attrName = null;

			for (Source source : sources) {

				OperationalAttribute[] allAttributes = source.getOperationalAttribute();

				if(source.getName().equals("IMA"))
				{

					for (OperationalAttribute attribute : allAttributes) {

						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("instl ind"))
						{
							if(valueXml.equals("N"))
							{
								CompareValuesUtility.verifyNull( "instl ind", gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsInstallable());
							}
							else
							{
								if(valueXml.equals("Y") && gbOffer.getDispTags().getIsInstallable())
								{
									CompareValuesUtility.logPassed("instl ind", valueXml, gbOffer.getDispTags().getIsInstallable());
								}
								else
								{
									CompareValuesUtility.logFailed("instl ind", valueXml, gbOffer.getDispTags().getIsInstallable());
								}
							}
						}
						else if(attrName.equalsIgnoreCase("everyday low price"))
						{
							if(valueXml.equals("1") || valueXml.equals("Y")||valueXml.equals("YES"))
								CompareValuesUtility.verifyNullOrEqual("everyday low price",true,gbOffer.getPriceDispAttr().getIsEvryDayPrc());
							else
								CompareValuesUtility.verifyNullOrFalse("everyday low price",false,gbOffer.getPriceDispAttr().getIsEvryDayPrc());
						}
						else if(attrName.equalsIgnoreCase("rsos ind"))
						{
							if (siteToTest.equalsIgnoreCase("sears"))
							{
								valueXml=valueXml==null?"N":valueXml;

								String act = gbOffer.getReplenishment()==null?null:gbOffer.getReplenishment().getRsosIndicator();

								if(valueXml.equals("N"))
								{
									CompareValuesUtility.verifyNull("rsos ind", act);
								}
								else
								{
									act=act==null?"null":act;

									if(valueXml.equals("Y") && act.equalsIgnoreCase("YES"))
									{
										CompareValuesUtility.logPassed("rsos ind", valueXml, act);
									}
									else
									{
										CompareValuesUtility.logFailed("rsos ind", valueXml, act);
									}
								}
							}
						}
						else if(attrName.equalsIgnoreCase("product item flag"))
						{
							if (!siteToTest.equalsIgnoreCase("kmart")) {
								if(valueXml.equalsIgnoreCase("Y"))
								{
									CompareValuesUtility.verifyNullOrEqual("product item flag", valueXml ,gbOffer.getReplenishment()==null?null:
										gbOffer.getReplenishment().getCoreItemFlag());
								}
							}

						}
						else if(attribute.getName().equalsIgnoreCase("kmart egp"))
						{
							if (siteToTest.equalsIgnoreCase("kmart")) {
								boolean expVal  = false;

								if(valueXml.equals("1"))
								{
									expVal = true;
								}
								CompareValuesUtility.verifyNullOrEqual("exceptional value", expVal,
										gbOffer.getPriceDispAttr()==null?null:	gbOffer.getPriceDispAttr().getIsExcptVal());
							}
						}

					}
				}
				else if(source.getName().equals("RIM"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("rim status"))
						{
							if(bRimProduct && !siteToTest.equalsIgnoreCase("kmart"))
							{
								compareValues("rim status", valueXml, gbOffer.getReplenishment().getInternalRimSts());
							}
						}
						else if(attrName.equalsIgnoreCase("fulfill source"))
						{
							if(bRimProduct && !siteToTest.equalsIgnoreCase("kmart"))
								compareValues("fulfill source", valueXml, gbOffer.getFfm().getVendorDunsNo());
						}
					}
				}
				else if(source.getName().equalsIgnoreCase("SPIN"))
				{
					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("Hot Buy"))
						{
							String startDt = attribute.getOperationalValue()[0].getStartDtm()==null?null:attribute.getOperationalValue()[0].getStartDtm().toString();
							String endDt = attribute.getOperationalValue()[0].getEndDtm()==null?null:attribute.getOperationalValue()[0].getEndDtm().toString();

							if(valueXml.equalsIgnoreCase("y") || valueXml.equalsIgnoreCase("yes"))
							{
								if(endDt==null || JodaDateTimeUtility.validateDate(startDt+"T00:00:00.000Z", endDt+"T23:59:59.999Z")){

									compareValues("Hot Buy", true,  gbOffer.getPriceDispAttr().getIsHotBuy()==null||gbOffer.getPriceDispAttr()==null?false
											:gbOffer.getPriceDispAttr().getIsHotBuy());
								}
							}
							else
							{
								compareValues("Hot Buy", false, gbOffer.getPriceDispAttr().getIsHotBuy()==null|| gbOffer.getPriceDispAttr()==null?false
										:gbOffer.getPriceDispAttr().getIsHotBuy());
							}
						}
					}
				}
				else if(source.getName().equalsIgnoreCase("Finance System"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("sears tax code"))
						{
							if(siteToTest.equalsIgnoreCase("sears"))
							{
								compareValues("sears tax code-calcode", valueXml,  gbOffer.getFfm()==null?null:gbOffer.getFfm().getCalCode());
							}
						}
					}
				}
			}
		}

		if(prodContent.getProductAttributes()!=null)
		{
			ProductAttribute[] prodAttributes= prodContent.getProductAttributes().getProductAttribute();

			for (ProductAttribute productAttribute : prodAttributes) {

				if(productAttribute.getAttributeId().equals("66201"))
				{
					Long val = productAttribute.getProductAttributeTypeChoice().getAttributeValueId();

					if(val!=null)
					{
						if(val==19l)
						{
							CompareValuesUtility.compareValues("isWaterFltrSubscrElig", true, gbOffer.getDispTags().getIsWaterFltrSubscrElig());
						}
						else if(val==92l)
						{
							CompareValuesUtility.compareValues("isWaterFltrSubscrElig", false, gbOffer.getDispTags().getIsWaterFltrSubscrElig());
						}
					}
				}
				else 	if(productAttribute.getAttributeId().equals("848610"))
				{
					CompareValuesUtility.compareValues("isWaterFltrSubscrElig", productAttribute.getProductAttributeTypeChoice().getAttributeValueFlag()
							, gbOffer.getPriceDispAttr()==null?null:gbOffer.getPriceDispAttr().getIsUPP());
				}
			}
		}
	}

	private void verifyIsRgnEligible(Offer gbOffer) {
		try {
			String partnumber=partNumberToTest.substring(0, 8);
			//List<String> divtemList = RestExecutor.getIdsByAltKey(CollectionValuesVal.RGNPRICING, s, partnumber);

			URIBuilder u = new URIBuilder("http://pricegbapi.prod.global.s.com:80/gbox/gb/s/data/get-by-alt-key/rgn_pricing?divitem="+partnumber);

			String singleJSonObject = RestExecutor.getJSonResponse(u.toString());

			List<String> divtemList = JSONParser.parseJSONToArray(singleJSonObject);

			verifyNullOrEqual("isRgnPriceElig", divtemList.isEmpty()?null:true,
					gbOffer.getPriceDispAttr()==null?null: gbOffer.getPriceDispAttr().getIsRgnpriceElig());
		} catch (URISyntaxException e) {
			System.out.println("Exception .. "+e.getMessage());
		}

	}
	
	private String hierName = null;

	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,List<Hierarchy> hierarchy) 
	{

		long XMLHierarchyId;

		if (siteToTest.equalsIgnoreCase("sears")) {
			if (xmlProductOffer.getCoreHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();
		} else {
			if (xmlProductOffer.getShcHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getShcHierarchyId();
		}

		List<String> lstPaths = new LinkedList<String>();
		List<String> lstids = new LinkedList<String>();
		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, XMLHierarchyId+"");

		String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");

		String idpath = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{path{idPath}}}}");

		hierName = name;
		
		name = name.replace("SRWI", "");
		name = name.replace("KWSC", "");

		lstPaths.addAll(Arrays.asList(name.split("-")));

		lstids.addAll(Arrays.asList(idpath.split("\\|")));

		if (lstPaths.isEmpty()) {
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId",
					"null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0,
					"StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (hierarchy.size() == 0) {
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		int iHierarchy = 0;

		for (Hierarchy hrchy_ : hierarchy) 
		{
			compareValues("store-taxo-name", lstPaths.get(iHierarchy),hrchy_ == null ? null : hrchy_.getName());

			compareValues("store-taxo-id", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getId());

			compareValues("store-taxo-spinid", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getSpinId());

			iHierarchy++;
		}

		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void checkFlagsFromAttribs(DispTags dispTags,
			PriceDispAttr priceDispAttr) {

		if (prodContent.getProductAttributes() == null)
			return;
		for (ProductAttribute attrib : prodContent.getProductAttributes()
				.getProductAttribute()) {
			switch (String.valueOf(attrib.getAttributeId())) {
			case "499910": {
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19))
					compareValues("DispTags", true, dispTags == null ? null: dispTags.getIsConfigureTech(), "isConfigureTech:");
				break;

			}
			case "848810": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("PriceDispHotBuy",true,priceDispAttr == null ? null : priceDispAttr.getIsHotBuy());
				}
				break;
			}
			case "848610": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues(
							"PriceDispUpp",
							true,
							priceDispAttr == null ? null : priceDispAttr
									.getIsUPP());
				}
				break;
			}
			case "1774": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEnergyStar(), "isEnergyStar");
				}
				break;
			}
			case "1130610": {
				// CompareValuesUtility.addNewMultiValuedFields();

				String response = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE,"1130610");

				
				//System.out.println("attr : "+response);
				//System.out.println("attr val : "+responseVal);
				if(!TestUtils.isEmptyJsonResponse(response) && OfferTestCache.checkAttrAssoc("1130610", "19"))
				{
					if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
						compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
					}else
						CompareValuesUtility.verifyNull("DispTags", dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
				}
				
				break;

			}
			//Added isDeliverySetupElig validation for Kmart on 12/18/2014
			case "886810": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (siteToTest.equalsIgnoreCase("kmart")) {
					if(attrib.getProductAttributeTypeChoice().getAttributeValueFlag() == true) {
						compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}else {
						CompareValuesUtility.verifyNullOrFalse("DispTags", false, dispTags == null ? null : dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}
				}
				break;
			}

			default: {

			}
			}
		}

	}

	private void verifyLegal(ProductOffer xmlProductOffer, Legal legal) {

		String jewelry_disclosure_52="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care";

		String jewelry_disclosure_53="Diamond weights may not be exact, but are never more than .05 carats below the stated weight";

		String jewelry_disclosure_84="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight";


		boolean bDisclosurePresent = false;

		Integer dicValueId = null;

		if(prodContent.getProductAttributes()!=null && prodContent.getProductAttributes().getProductAttribute()!=null)
		{
			ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();
			for (ProductAttribute productAttribute : attrs) {

				if(productAttribute.getAttributeId().intValue()==30201)
				{
					bDisclosurePresent = true;
					dicValueId = productAttribute.getProductAttributeTypeChoice().getAttributeValueId().intValue();
					break;
				}
			}
		}

		if (  !bDisclosurePresent && prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getHazardMaterialCode() == null
				&& prodContent.getAggrLegalData().getHazardStorageCode() == null
				&& prodContent.getAggrLegalData().getIsCaEmmission() == null
//				&& checkInAttributeGroup("California Emission Compliant") == null
				&& (prodContent.getAggrLegalData().getProp65Flag() == false || prodContent.getAggrLegalData().getProp65Flag() == null)
				//&& xmlProductOffer.getGeoLimiters() == null
				&& (prodContent.getGlobalAttributes() == null || prodContent
				.getGlobalAttributes().getChokingHazard() == null)) {
			CompareValuesUtility.verifyNull("Legal", legal);
		} else {

			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), legal == null ? null : legal.getHazmatMaterialCd(),
					"HazmatMtrCd");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), legal == null ? null : legal.getUsDotType(),
					"usDotType");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardStorageCode(), legal == null ? null : legal.getHazmatStorageCd(),
					"HazmatStrgCd");
			verifyNullOrEqual("Legal",
					 prodContent.getAggrLegalData().getIsCaEmmission() == null || prodContent.getAggrLegalData().getIsCaEmmission() == false ? null : true,
					legal == null ? null : legal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", (prodContent.getAggrLegalData().getProp65Flag() == null ||
					prodContent.getAggrLegalData().getProp65Flag() == false) ? null : true,
							legal == null ? null : legal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			/*if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),
								legal.getLimitedGeos());*/
			
			if(bDisclosurePresent)
			{
				if(dicValueId==52)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_52, legal == null ? null : legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==53)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_53, legal == null ? null : legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==84)
				{
					verifyNullOrEqual("Legal",jewelry_disclosure_84, legal == null ? null : legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else if(dicValueId==2534)
				{
					CompareValuesUtility.verifyNull("Legal", legal == null ? null : legal.getJewelry()==null?null:legal.getJewelry().getDisclosure(), "jwelery.disclosure");
				}
				else
				{
					System.out.println(" ===================== check this dicValueId : "+dicValueId+"===================");
				}
			}
		}
		verifyChokingHazards(legal);
	}

	private Boolean checkInAttributeGroup(String attrToCheck) {
		if (prodContent.getGlobalAttributes() != null) {
			for (GlobalAttributeType attGroup : prodContent
					.getGlobalAttributes().getAttribute()) {
				if (attGroup.value().equals(attrToCheck))
					return true;

			}
			return false;
		} else
			return null;

	}

	private void verifyChokingHazards(Legal legal) {
		Boolean isWarn = false;
		Boolean safetyWarn = false;
		
		if (prodContent.getAggrLegalData() != null && prodContent.getAggrLegalData().getChokingHazards() != null) {
			for (ChokingHazardType cType : prodContent.getAggrLegalData().getChokingHazards()
					.getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
					isWarn = true;
				else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
					safetyWarn = true;
				else
				{
					ArrayList<String> list1 = new ArrayList<String>();
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.value(), legal == null ? list1 : legal.getChokingHazards());
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		if(isWarn)
			compareValues("LegalIsNoWarn", true, legal == null ? null : legal.getIsNoWarning());
		if(safetyWarn)
			compareValues("LegalsafetyWarn", true, legal == null ? null : legal.getSafetyWarnings());
	}

	/*ValueId
	TradeTX
	=> Name => TradeTX/ ValueIdDisplayName
	   FamilyName => ValueIdDisplayName

	ValueFlag
	TradeTX
	=> Name => TradeTX/ ValueFlag
	  FamilyName => ValueFlag

	ValueFree
	TradeTX
	=> Name => TradeTX/ ValueFree
	  FamilyName => ValueFree*/

	private void verifyDefiningAttrs(VariantAttribute[] variantAttributes,List<DefiningAttr> definingAttrs) 
	{
		CompareValuesUtility.addNewMultiValuedFields();

		for (VariantAttribute var : variantAttributes) 
		{
			boolean bFound = false;

			for (DefiningAttr gbDefAttr : definingAttrs) 
			{
				if (String.valueOf(var.getAttributeId()).equals(gbDefAttr.getAttr().getId())) 
				{
					Val attrval = gbDefAttr.getVal();

					AttrValVo attrVal = getAttrVal(String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()), String.valueOf(var.getAttributeId()));
					bFound = true;
					if(attrVal==null && var.getVariantAttributeTypeChoice().getAttributeValueId()!=null)
					{
						CompareValuesUtility.addFailedDataFieldForReport("AttrShouldSkipped(attr-attrval-association-absent)", "ItemClass : "+itemClassId+ " Attribute Id : "+String.valueOf(var.getAttributeId())+" AttrValueId : "+String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()));
						bFound=true;
						continue;
					}



					//--------------attribute -------------
					//id,name,seq,type

					AttrVo attrVo = getAttribute(String.valueOf(var.getAttributeId()));

					compareValues("DefAttrId", String.valueOf(var.getAttributeId()), gbDefAttr.getAttr().getId());

					compareValues("DefAttrType", var.getAttributeType(),gbDefAttr.getAttr().getType());

					if(attrVo==null)
					{
						CompareValuesUtility.addFailedDataFieldForReport("DefAttributeDetailsNotFound", "ItemClass : "+itemClassId+ " Attribute Id : "+String.valueOf(var.getAttributeId()));
					}
					else
					{
						compareValues("DefAttrName", attrVo.getName() , gbDefAttr.getAttr().getName());

						compareValues("DefAttrSeq", attrVo.getSeq(), gbDefAttr.getAttr().getSeq()==null?"null":gbDefAttr.getAttr().getSeq().intValue());
					}

					//--------------attribute value-------------
					//id,name,familyname,seq


					String tradeMarkTextString = var.getTrademarkText();

					if (var.getVariantAttributeTypeChoice()	.getAttributeValueFree() != null) 
					{
						compareValues("DefAttrValueId", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getId());

						if(tradeMarkTextString!=null)
							compareValues("DefAttrValName", tradeMarkTextString,
									attrval == null ? null : gbDefAttr.getVal().getName());
						else
							compareValues("DefAttrValName", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
									attrval == null ? null : gbDefAttr.getVal().getName());

						compareValues("DefAttrValFamily", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getFamilyName());

					} 
					else
					{
						compareValues("DefAttrValueId", String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()),
								attrval == null ? null: gbDefAttr.getVal().getId());

						String sfinalVal  = tradeMarkTextString;

						if (var.getTrademarkText() != null )
							compareValues("DefAttrValName",	sfinalVal,	attrval == null ? null : gbDefAttr.getVal().getName());
						else
						{
							compareValues("DefAttrValName",	attrval.getName() ,
									attrval == null ? null : gbDefAttr.getVal().getName());
						}

						if(attrVal!=null)
						{
							sfinalVal = attrVal.getName();

							compareValues("DefAttrValFamily",	sfinalVal,
									attrval == null ? null : gbDefAttr.getVal()	.getFamilyName());

							compareValues("DefAValSeq",	attrVal.getSeq(), attrval == null ? null
									: gbDefAttr.getVal().getSeq().intValue());
						}
					}

					break;
				}
			}
			if (!bFound) {
				logFailed("DefAttrId", var.getAttributeId(), "Not found");
			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private AttrValVo getAttrVal(String attributeValId,String sAttrId)
	{
		AttrValVo attrValVo  =new AttrValVo();

		AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attributeValId);

		if(attrValsch==null)
		{
			return null;
		}
		attrValVo.setName(attrValsch.getDisplayName());
		List<AttrId> allAttrIds = attrValsch.getAttrIds();

		boolean found = false;

		for (AttrId attrId : allAttrIds) {

			if(attrId.getAttrId().equals(sAttrId))
			{
				attrValVo.setSeq(attrId.getRank());

				found=true;
				break;

			}
		}

		if(!found)
			return null;


		return attrValVo;
	}
	private AttrVo getAttribute(String attributeId)
	{
		AttrVo attrVo = new AttrVo();

		String attrResp = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE, attributeId);

		String name = JsonStringParser.getJsonValue(attrResp, "{_blob{attribute{displayName}}}");

		attrVo.setName(name);

		com.generated.vos.hierarchy.Hierarchy masterHierarchy = RestExecutor.getDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, itemClassId);

		if(masterHierarchy != null && masterHierarchy.getAttrs() != null && masterHierarchy.getAttrs().getLabels() != null)
		{
			List<Label> allLabels =masterHierarchy.getAttrs().getLabels();

			for (Label label : allLabels) {

				List<Attr> attrs = label.getAttrs();

				for (Attr attr : attrs) {

					if(attr.getId().equals(attributeId))
					{
						attrVo.setSeq(String.valueOf(attr.getRank().intValue()));
						return attrVo;
					}
				}
			}

		}
				//

		return null;
	}

	class AttrVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		private String id;
		private String name;
		private String seq;
		private String type;
	}

	class AttrValVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getFamiliyName() {
			return familiyName;
		}
		public void setFamiliyName(String familiyName) {
			this.familiyName = familiyName;
		}
		private String id;
		private String name;
		private String seq;
		private String familiyName;
	}

	private void verifyAltIds(ProductOffer xmlProductOffer, AltIds altIds) {

		verifyNullOrEqual("AltIds", xmlProductOffer.getSpinUniqueId(), altIds.getSpinId(), "SpinId");
		verifyNullOrEqual("AltIds", xmlProductOffer.getImaAttributes().getKsnId(), altIds.getKsn(), "Ksn");
		verifyNullOrEqual("AltIds", xmlProductOffer.getOfferingIndicatorsGroup()==null?null:xmlProductOffer.getOfferingIndicatorsGroup().getLinkedKsn(), 
				altIds.getLinkedKsn(), "LinkedKsn");
		
		upcToCheck = xmlProductOffer.getUpc();
		if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_0.value())){
			upcToCheck = validateUPC(upcToCheck, 12);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_1.value()) 
				|| xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_2.value())){
			upcToCheck = validateUPC(upcToCheck, 8);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_3.value())){
			upcToCheck = validateUPC(upcToCheck, 13);
		}
		else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_7.value())){
			upcToCheck = validateUPC(upcToCheck, 14);
		}
		compareValues("AltIds", upcToCheck, altIds.getUpc(), "Upc");	
		compareValues("AltIds", xmlProductOffer.getUpcType(), GenericUtil.convertToString(altIds.getUpcType()), "UpcType");
		
		for(VendorPack vendorPack : xmlProductOffer.getImaAttributes().getVendorPack()){
			if(vendorPack.getStoreName().equalsIgnoreCase(siteToTest)){
				verifyNullOrEqual("AltIds", vendorPack.getVendorStockNumber(), altIds.getVendorStockNo(), "VendorStockNo");
				break;
			}
		}
		verifyNullOrEqual("AltIds", GenericUtil.convertToString(xmlProductOffer.getImaAttributes().getImaItemId()), 
				GenericUtil.convertToString(altIds.getImaItemId()), "ImaItemId");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private String validateUPC(String upc, int length){

		if(upc==null)
			return null;

		if(upc.length()>length)
		{
			StringBuffer buf = new StringBuffer(upc);
			upc = buf.reverse().toString();

			upc = upc.substring(0, length);

			StringBuffer buf2 = new StringBuffer(upc);

			return buf2.reverse().toString();
		}
		else
		{
			return StringUtils.leftPad(upc, length, "0");
		}
	}

	private void verifyImages(ProductOffer xmlProductOffer,
			List<MainImg> mainImg, List<SwatchImg> lstSwatchImgs) {
		ImageUrl primImageURL = xmlProductOffer.getImageUrl();

		if (primImageURL.getImageElementsGroup() != null) {
			if (mainImg.size() == 0)
				compareValues("PrimaryImage", primImageURL.getImageElementsGroup().getUrl(), "Not found");
			else {
				compareValues("PrimaryImage", TestUtils.modifyURL(primImageURL.getImageElementsGroup().getUrl()), mainImg.get(0)
						.getSrc(), "Src");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getName(), mainImg.get(0).getTitle(), "Title");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getHeight(),GenericUtil.convertToIntFromDouble(mainImg.get(0)
						.getHeight()), "Height");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getWidth(),
						GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()), "Width");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}

		// Only check for swatch image for variant items
		if (bSingleProductOffer)
			return;

		// Verify if any of the variant attributes is of type swatch, if yes,
		// only then continue
		boolean bSwatchAttribFound = false;
		for (VariantAttribute varAttri : xmlProductOffer.getVariantAttributes()
				.getVariantAttribute()) {
			if (varAttri.getAttributeType().equals(AttributeTypeType.SWATCH)) {
				bSwatchAttribFound = true;
				break;
			}
		}

		if (!bSwatchAttribFound)
			return;

		ImageElementsGroup swatchImageURL = xmlProductOffer.getSwatchImage()==null?null:xmlProductOffer.getSwatchImage().getImageElementsGroup();
		if(swatchImageURL!=null)
		{
			if (lstSwatchImgs.size() == 0)
				compareValues("SwatchImg", swatchImageURL.getUrl(), "Not found");
			else {

				compareValues("SwatchImg", TestUtils.modifyURL(swatchImageURL
						.getUrl()), lstSwatchImgs.get(0).getSrc(), "Src");
				CompareValuesUtility.verifyNullOrEqual("SwatchImg",
						swatchImageURL.getName(), lstSwatchImgs.get(0).getTitle(),
						"Title");
				CompareValuesUtility.verifyNullOrEqual("SwatchImg", swatchImageURL
						.getHeight(), GenericUtil
						.convertToIntFromDouble(lstSwatchImgs.get(0).getHeight()),
						"Height");
				CompareValuesUtility.verifyNullOrEqual("SwatchImg", swatchImageURL
						.getWidth(), GenericUtil
						.convertToIntFromDouble(lstSwatchImgs.get(0).getWidth()),
						"Width");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}

	}

	private void verifyReplenishment(ProductOffer xmlProductOffer,
			Replenishment replenishment) {

		VendorPack vendorPToTest = null;
		for (VendorPack vPack : xmlProductOffer.getImaAttributes()
				.getVendorPack()) {
			if (vPack.getStoreName().equalsIgnoreCase(siteToTest)) {
				vendorPToTest = vPack;
				break;
			}
		}
		if (vendorPToTest != null) {
			// Cost will be updated by operational load - 7-30 changes
			// compareValues("Replenishment",
			// vendorPToTest.getCost(),replenishment.getUnitCost(),"Cost");
			compareValues(
					"Replenishment",
					vendorPToTest.getVendorPackId(),
					replenishment == null ? null : replenishment
							.getVendorPackId(), "VendorPackId");
			verifyNullOrEqual("Replenishment", vendorPToTest.getFlowType(),
					replenishment == null ? null : replenishment.getFlowType(),
					"FlowType");
		}
		verifyNullOrEqual("Replenishment",
				GenericUtil.convertToString(xmlProductOffer.getImaAttributes()
						.getCancarryGroup()), replenishment == null ? null
								: replenishment.getCanCarryGrp(), "CanCarryGrp");
		verifyNullOrEqual("Replenishment", xmlProductOffer.getImaAttributes()
				.getCountryOfOrigin(), replenishment == null ? null
						: replenishment.getCntryOfOrig(), "CntryOfOrig");
		// verifyNullOrEqual("RplnishPurchaseSet",
		// xmlProductOffer.getImaAttributes().getVendorPack()[0].getPurchaseStatus(),replenishment.getPurchaseSts());
		//commented by daffy - ECOM-361820
		/*for (VendorPack vp : xmlProductOffer.getImaAttributes().getVendorPack()) {
			if (vp.getStoreName().equalsIgnoreCase(siteToTest))
				verifyNullOrEqual(
						"replenishment.PurchaseStatus",
						vp.getPurchaseStatus(),
						replenishment == null ? null : replenishment
								.getPurchaseSts());
		}*/
		verifyNullOrEqual("Replenishment", xmlProductOffer.getImaAttributes().getRecallFlag(), 
				replenishment==null?null:replenishment.getIsRecalled(), "IsRecalled");
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyItemCondition(ProductOffer xmlProductOffer, Condition condition){
        
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : xmlProductOffer.getOfferCondition().getCondition().value(),
                                   condition == null ? null :condition.getStatus(), "status");
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionComments()==null?null :xmlProductOffer.getOfferCondition().getConditionComments()),
                                   condition == null ? null :condition.getComments(), "comments");
        
        /*verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionComments()==null?null :xmlProductOffer.getOfferCondition().),
                                   condition == null ? null :condition.getDispName(), "DisPlayName");*/
        
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionImageUrl()==null?null :
                            (xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup()==null?null :(
                                          xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getUrl()==null?null :
                                                 xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getUrl())
                                   )),condition == null ? null : (condition.getImg() == null ? null :(condition.getImg().getSrc() == null ? null:condition.getImg().getSrc())), "Conditionurl");
        
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionImageUrl()==null?null :
                            (xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup()==null?null :(
                                          xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getWidth()==null?null :
                                                 xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getWidth().intValue())
                                   )),condition == null ? null : (condition.getImg() == null ? 
                                                  null :(condition.getImg().getWidth() == null ?
                                                               null:condition.getImg().getWidth())), "Conditionwidth");   
        
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionImageUrl()==null?null :
                            (xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup()==null?null :(
                                          xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getHeight()==null?null :
                                                 xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getHeight().intValue())
                                   )),condition == null ? null : (condition.getImg() == null ? null :(condition.getImg().getHeight() == null ? null:condition.getImg().getHeight())), "Conditionheight");  
        
        verifyNullOrEqual("ItemCondition", xmlProductOffer.getOfferCondition()
                     == null ? null : (xmlProductOffer.getOfferCondition().getConditionImageUrl()==null?null :
                            (xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup()==null?null :(
                                          xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getName()==null?null :
                                                 xmlProductOffer.getOfferCondition().getConditionImageUrl().getImageElementsGroup().getName())
                                   )),condition == null ? null : (condition.getImg() == null ? null :(condition.getImg().getTitle() == null ? null:condition.getImg().getTitle())), "ConditionTitile");
        
        
        
 }

	private void verifyFFM(ProductOffer xmlProductOffer, Ffm ffm, String site) {
		if (ffm == null) {
			logFailed("FFM", "sears", "No ffm tag found");
			return;
		}
		compareValues("FFM", site.substring(0, 1).toUpperCase() + site.substring(1), ffm.getSoldBy(), "SoldBy");
		String sFFMBy = site.substring(0, 1).toUpperCase() + site.substring(1);
		/*
		 * if(xmlProductOffer.getFulfillment().equals(FulfillmentType.FBM)){
		 * sFFMBy = "Sears Authorized Supplier"; compareValues("FFM", "VD",
		 * ffm.getChannel(),"Channel"); }else
		 * CompareValuesUtility.verifyNull("FFM",ffm.getChannel(),"Channel");
		 */

		if (ffm.getChannel() != null && ffm.getChannel().equals("VD")) {
			sFFMBy = "Sears Authorized Supplier";
		}
		compareValues("FFM", sFFMBy, ffm.getFulfilledBy(), "FulfilledBy");
		CompareValuesUtility.verifyNullOrEqual("FFM", xmlProductOffer.getOfferingIndicatorsGroup().isWebOnlyFlag() == false ? null : true, 
				ffm.getIsWebExcl(), "isWebExcl");
		
		compareValues("FFM", bSingleProductOffer ? singleProductOffer.getProductContent().getVendorId().toString() : varProdOffer.getProductContent().getVendorId().toString(), 
				ffm.getSpinVendorId(), "SpinVendorId");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyShipping(ShipDimension shipDimension, Shipping shipping) {

		offerCommon.verifyShipping(shipDimension.getLength(),
				shipDimension.getWidth(), shipDimension.getHeight(),
				shipDimension.getWeight());
	}

	private void verifySearch(ProductOffer xmlProductOffer, APIResponse<Offer> allResponse) {
		
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("_ft", bSingleProductOffer?"NV":"V", allResponse.getFtFieldValue("offerType"),"offerType");
		CompareValuesUtility.verifyNullOrEqual("_ft", siteToTest.substring(0, 1).toUpperCase()+siteToTest.substring(1), allResponse.getFtFieldValue("pgrmType"),"pgrmType");
		CompareValuesUtility.addNewMultiValuedFields();
		
		String modelNo = prodContent.getManufacturerModelNumber()==null ? null : prodContent.getManufacturerModelNumber().replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
		
		CompareValuesUtility.verifyNullOrEqual("_search", modelNo, allResponse.getSearchFieldValue("model_no"), "Model_no");
		compareValues("_search", upcToCheck, allResponse.getSearchFieldValue("upc"), "Upc");
		compareValues("_search", parentId, allResponse.getSearchFieldValue("parentId"), "ParentId");
		compareValues("_search", xmlProductOffer.getSpinUniqueId(), allResponse.getSearchFieldValue("spinId"), "SpinId");
		CompareValuesUtility.verifyNullOrEqual("_search", xmlProductOffer.getImaAttributes().getKsnId(), allResponse.getSearchFieldValue("ksn"), "Ksn");
		
		if(siteToTest.equalsIgnoreCase("sears")) {
			compareValues("_search", partNumberToTest.substring(0, 8), allResponse.getSearchFieldValue("divitem"), "DivItem");
		}
		CompareValuesUtility.verifyNullOrEqual("_search", hierName, allResponse.getSearchFieldValue("hierarchy"), "Hierarchy");

		if(SHC_OfferLoadTest_New.checkSSINAndUID)
		{
			CompareValuesUtility.verifyNullOrEqual("_search", xmlProductOffer.getSsin(), xmlProductOffer.getSsin() == null ? null
					: allResponse.getSearchFieldValue("ssin"), "SSIN");
			CompareValuesUtility.verifyNullOrEqual("_search", xmlProductOffer.getGuid(), xmlProductOffer.getGuid() == null ? null
					: allResponse.getSearchFieldValue("uid"), "UID");
		}
		
		commonUtils.verifyDispSiteOffer(xmlProductOffer, allResponse.getSearchFieldList("dispSite"),bCrossFormattedItem,validHierarchy);
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyTaxonomy(Offer gbOffer, ProductOffer xmlProductOffer) {

		if (gbOffer.getTaxonomy() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+ itemClassId, "Taxonomy is null");
			return;
		} else if (gbOffer.getTaxonomy().getMaster() == null) {
			CompareValuesUtility.logFailed("TaxonomyMaster", "Itemclassid:"	+ itemClassId, "Taxonomy-master is null");
			return;
		}

		compareMasterhierarchyGB(Long.parseLong(itemClassId), gbOffer.getTaxonomy().getMaster().getHierarchy());
		
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for (Site site : xmlProductOffer.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId != 13){
			if (lSiteId > 11 || lSiteId == 10)
				continue;
			}
			String siteName = TestUtils.getSite(lSiteId);
			if ((siteToTest.equalsIgnoreCase("sears") && siteName.equalsIgnoreCase("kmart") && !bCrossFormattedItem)
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName.equalsIgnoreCase("sears") && !bCrossFormattedItem)) {
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for (com.generated.vos.productoffering.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()) {
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		for(Map.Entry<Long, List<String>> entry : mpSiteHiearachies.entrySet())
		{
			List<String> lstHieararchyIds = entry.getValue();
			for(String hieararchyId : lstHieararchyIds)
			{
				com.generated.vos.hierarchy.Hierarchy responseHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, hieararchyId);
				
				if(gbOffer.getTaxonomy().getWeb() == null && ( responseHierarchy == null || !responseHierarchy.getIsLeaf()))
				{
					CompareValuesUtility.logPassed("TaxonomyWeb", "Invalid Hierarchy in feed for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy is null in GB");
					CompareValuesUtility.verifyNullOrEqual("Site", "[]", gbOffer.getSites());
					validHierarchy = false;
				}
				else if(gbOffer.getTaxonomy().getWeb() != null &&  responseHierarchy != null && responseHierarchy.getIsLeaf())
				{
					CompareValuesUtility.logPassed("TaxonomyWeb", "Valid Hierarchy in feed for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy present in GB");
					validHierarchy = true;
				}
				else if(gbOffer.getTaxonomy().getWeb() != null &&  responseHierarchy != null && !responseHierarchy.getIsLeaf())
				{
					CompareValuesUtility.logFailed("TaxonomyWeb", "IsLeaf is false for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy present in GB");
					CompareValuesUtility.verifyNullOrEqual("Site", "[]", gbOffer.getSites());
					validHierarchy = false;
				}

			}
		}
//		System.out.println("mpSiteHiearachies"+mpSiteHiearachies);
		
		if (gbOffer.getTaxonomy().getWeb() == null && !(mpSiteHiearachies.size() == 0)) {
			return;
		}

		//Verify Sites
		verifySites(xmlProductOffer, gbOffer.getSites());
		
		if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb(),siteToTest,bCrossFormattedItem);

		CompareValuesUtility.addNewMultiValuedFields();
		
		commonUtils.verifyMeetWExpert(siteToTest, mpSiteHiearachies, gbOffer.getDispTags());

	}

	public void compareMasterhierarchyGB(long l, List<com.generated.vos.content.Hierarchy> list)
	{

		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath =GreenBoxCache.getPathForItemClass(l+"");

		if(masterHierarchyPath == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "No hierarchy exists");
			return;
		}

		if(list == null){
			logFailed("Master", "Hierarchy for "+l+" should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master", hierarchyMap);

		compareValues("Master", masterHierarchyPath.getIdPath(),hierarchyMap.get("no-site-required-for-master").getLstIds().get(0),"IDPath");
		compareValues("Master", masterHierarchyPath.getDisplayPath(),hierarchyMap.get("no-site-required-for-master").getDisplayPaths().get(0),"DisplayPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void setGBHierarchySeparator(){
		this.hierarchySeparator = "|";
	}

	private String hierarchySeparator = "/";

	public void processMasterHierarchy(List<com.generated.vos.content.Hierarchy> list ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();
		List<String> lstCids  = new LinkedList<String>();

		String id=null, name=null,cid=null;

		for (com.generated.vos.content.Hierarchy hierarchy : list) {

			if(id==null)
				id= GenericUtil.convertToString(hierarchy.getSpinId()); //replaced getId
			else
				id = id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

			if(name==null)
				name=hierarchy.getName();
			else
				name = name+this.hierarchySeparator+hierarchy.getName();

			if(cid==null)
				cid=GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ======  For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}


	private class HierarchyPathVo
	{
		public List<String> getLstIds() {
			return lstIds;
		}
		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}
		public List<String> getLstCIds() {
			return lstCIds;
		}
		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}
		public List<String> getDisplayPaths() {
			return displayPaths;
		}
		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}
		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}
	
	private String getDeluxOptAndTxt(String scimCode){
		
		switch(scimCode){
		case "12":
			return "Radio Button@@Left side venting";
		case "15":
			return "Radio Button@@Right side venting";
		case "17":
			return "Radio Button@@Bottom venting";
		case "18":
			return "Radio Button@@Door should open to the left";
		case "19":
			return "Radio Button@@I have purchased a separate ice-maker, it should be installed prior to delivery.";
		case "20":
			return "Radio Button@@The refrigerator door should open to the left (instead of the right) and I have purchased a separate ice-maker, it should be installed prior to delivery.";
		default:
			return null;
		}
	}

	private boolean isRimProduct(ProductOffer xmlProductOffer) {
		Source[] sources = xmlProductOffer.getOperationalAttributes()
				.getSource();

		if (sources != null) {
			String valueXml = null;
			String attrName = null;

			for (Source source : sources) {

				if (source.getName().equals("IMA")) {
					OperationalAttribute[] allAttributes = source
							.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) {

						valueXml = attribute.getOperationalValue()[0]
								.getValue();
						attrName = attribute.getName();

						if (attrName.equals("order system")) {
							if (siteToTest.equalsIgnoreCase("sears")
									&& valueXml.equals("RIM")) {
								return true;
							}
						}
					}
				}
				/*
				 * else if(source.getName().equals("RIM")) {
				 * OperationalAttribute[] allAttributes =
				 * source.getOperationalAttribute();
				 * 
				 * for (OperationalAttribute attribute : allAttributes) {
				 * valueXml = attribute.getOperationalValue()[0].getValue();
				 * attrName = attribute.getName();
				 * 
				 * if(attrName.equalsIgnoreCase("rim status")) {
				 * if(!siteToTest.equalsIgnoreCase("kmart")) {
				 * 
				 * } } } }
				 */
			}
		}

		return false;
	}
	
	public Map<String,String> getDeluxDefaultValues()
	{
		Map<String,String>  defValMap  = new HashMap<>();

		defValMap.put("12","Radio Button|Left side venting");
		defValMap.put("15","Radio Button|Right side venting");
		defValMap.put("16","Radio Button|Right side venting_edited");
		defValMap.put("14","Radio Button|Right side venting_edited");
		defValMap.put("17","Radio Button|Bottom venting");
		defValMap.put("18","Radio Button|Door should open to the left");
		defValMap.put("19","Radio Button|I have purchased a separate ice-maker, it should be installed prior to delivery.");
		defValMap.put("20","Radio Button|The refrigerator door should open to the left (instead of the right) and I have purchased a separate ice-maker, it should be installed prior to delivery.");

		return defValMap;
	}

	class DeluxVo {
		@Override
		public String toString() {
			return "DeluxVo [code=" + code + ", gid="
					+ gid + ", qtext=" + qtext  + ", type=" + type + "]";
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getQtext() {
			qtext=qtext==null?"":qtext;
			return qtext;
		}

		public void setQtext(String qtext) {
			this.qtext = qtext;
		}

		public String getGid() {
			gid=gid==null?"":gid;
			return gid;
		}

		public void setGid(String gid) {
			this.gid = gid;
		}

		public String getType() {
			type=type==null?"":type;
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		private String code;
		private String qtext;
		private String gid;
		private String type;
	}


	private void testDeluxOption(ProductOffer xmlProductOffer,
			Offer gbOffer, String sOfferId, String site) {

		Map<String,String>  deluxDefaultValuesMap   = getDeluxDefaultValues();

		Map<String, ArrayList<SHC_OfferVerifications_New.DeluxVo>> map = new HashMap<>();

		Source[] sources = xmlProductOffer.getOperationalAttributes()
				.getSource();
		
		String sSiteId=null;

		if (sources != null) {

			String attrName = null;

			for (Source source : sources) {

				/* ============================= SPIN ===================== */

				if (source.getName().equalsIgnoreCase("SPIN"))
				{

					OperationalAttribute[] allAttributes = source
							.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) {

						attrName = attribute.getName();

						Long siteId = attribute.getSiteId();

						if(siteId==null){
							sSiteId="0";
						}

						else if(attribute.getGroupName().equalsIgnoreCase("DELUXE OPTION"))

						{
							sSiteId=String.valueOf(siteId);

						}

						ArrayList<DeluxVo> listForSite = map.get(sSiteId);

						if(listForSite==null)
							listForSite=new ArrayList<DeluxVo>();

						switch (attrName.toUpperCase()) {

						case "DELUXE SCIM CODE":

							OperationalValue[] opValues = attribute.getOperationalValue();

							for (OperationalValue operationalValue : opValues) {

								DeluxVo vo = new DeluxVo();
								vo.setGid(operationalValue.getGroupingId());
								vo.setCode(operationalValue.getValue());

								listForSite.add(vo);
							}
							map.put(sSiteId,listForSite);
							break;

						case "DELUXE QUESTION TEXT":

							opValues = attribute.getOperationalValue();

							for (OperationalValue operationalValue : opValues) {

								listForSite = map.get(sSiteId);

								DeluxVo deluxVo = 	getObject( listForSite, operationalValue.getGroupingId());

								if(deluxVo==null)
								{
									deluxVo=new DeluxVo();
								}

								deluxVo.setQtext(operationalValue.getValue());
							}

							map.put(sSiteId,listForSite);

							break;

						case "DELUXE DISPLAY OPTION TYPE":

							opValues = attribute.getOperationalValue();

							for (OperationalValue operationalValue : opValues) {

								listForSite = map.get(sSiteId);


								DeluxVo deluxVo = 	getObject(listForSite, operationalValue.getGroupingId());
								if(deluxVo==null)
								{
									deluxVo=new DeluxVo();
								}
								deluxVo.setType(operationalValue.getValue());
							}

							map.put(sSiteId,listForSite);

							break;
						}
					}
				}
			}

			//set default values if matching grouping id is not available for text or type

			Set<String> keyset = map.keySet();
			
			for (String key : keyset) {

				ArrayList<DeluxVo> listOfObjects = map.get(key);

				if(listOfObjects==null)

				{
					continue;
				}			
				
				for (DeluxVo deluxVo : listOfObjects) {

					String code = deluxVo.getCode();

					if(deluxVo.getQtext().isEmpty()||deluxVo.getType().isEmpty()||deluxVo.getGid().isEmpty())
					{				

						deluxVo.setQtext(deluxDefaultValuesMap.get(code).split("\\|")[1]);

						deluxVo.setType((deluxDefaultValuesMap.get(code).split("\\|")[0]));
												
					}
				}
			}

			List<DeluxOpt> gbDeluxOpt = gbOffer.getDispTags().getDeluxOpt();

			ArrayList<DeluxVo> listOfObjects = null;
			if(!(sSiteId == null)){
				if(sSiteId.equals("0"))
					listOfObjects = map.get("0");
				
				else if(site.equalsIgnoreCase("sears"))
					listOfObjects = map.get("2");
	
				else if(site.equalsIgnoreCase("kmart")) 
					listOfObjects = map.get("1");  
	
				else
					listOfObjects = map.get("0");
			}
			Boolean dFound = false;

			if(listOfObjects!=null){

				for (DeluxVo deluxVo : listOfObjects) {

					dFound = false;

					for (DeluxOpt deluxOpt : gbDeluxOpt) {	

						if((deluxVo.getCode().equals(deluxOpt.getQuestScimCd()))){

							dFound = true;

							CompareValuesUtility.logPassed("DELUXE SCIM CODE",deluxVo.getCode(),deluxOpt.getQuestScimCd());
							CompareValuesUtility.compareValues("DELUXE DISPLAY OPTION TYPE",deluxVo.getType(),deluxOpt.getDispType());
							CompareValuesUtility.compareValues("DELUXE QUESTION TEXT",deluxVo.getQtext(),deluxOpt.getQuestTxt());

							break;
						}

					}

					if (!dFound) {

						CompareValuesUtility.logFailed("DELUXE SCIM CODE",deluxVo.getCode() == null ? "null": deluxVo.getCode(),"null");

						CompareValuesUtility.logFailed("DELUXE DISPLAY OPTION TYPE",deluxVo.getType()== null ? "null": deluxVo.getType(),"null");

						CompareValuesUtility.logFailed("DELUXE QUESTION TEXT",deluxVo.getQtext()== null ? "null": deluxVo.getQtext(),"null");

					}
				}

				for (DeluxOpt gbDeluxOptSingle : gbDeluxOpt) {	

					dFound = false;

					for (DeluxVo deluxVo : listOfObjects) {


						if((deluxVo.getCode().equals(gbDeluxOptSingle.getQuestScimCd()))){

							dFound = true;
							break;
						}

					}
					if (!dFound) {
						CompareValuesUtility.logFailed("DELUXE SCIM CODE","Not Expected",gbDeluxOptSingle.getQuestScimCd() == null ? "null": gbDeluxOptSingle.getQuestScimCd());
						CompareValuesUtility.logFailed("DELUXE DISPLAY OPTION TYPE","Not Expected",gbDeluxOptSingle.getDispType()== null ? "null": gbDeluxOptSingle.getDispType());
						CompareValuesUtility.logFailed("DELUXE QUESTION TEXT","Not Expected",gbDeluxOptSingle.getQuestTxt()== null ? "null": gbDeluxOptSingle.getQuestTxt());
					}
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();


		//inventry threshold

		//		Source[] source1= xmlProductOffer.getOperationalAttributes().getSource();



		for (Source source : sources) {

			String attrName=null;

			if(source.getName().equalsIgnoreCase("SPIN")){

				OperationalAttribute[] allAttributes =source.getOperationalAttribute();

				for(OperationalAttribute attribute:allAttributes){

					if (attribute.getName().equalsIgnoreCase("INVENTORY_THRESHOLD")){

						System.out.println("\n\nthreshold: "+attribute.getName()+"\n gropu name"+attribute.getGroupName()+"\n"+"\nsite id "+attribute.getSiteId());
						OperationalValue[] operationaValue = attribute.getOperationalValue();
						for(OperationalValue s:operationaValue){

							System.out.println("Operational Values"+s.getValue());


						}

					}


				}



			}
		}


	}
	
	private DeluxVo getObject(ArrayList<DeluxVo> lst, String gid)
	{
		if(lst==null||lst.isEmpty())
			return null;

		for (DeluxVo deluxVo : lst) {

			if(deluxVo.getGid().equals(gid))
			{
				return deluxVo;
			}
		}

		return null;
	}
	
	/**
	 * Verifies by default isdispelig is set for all sites
	 * @param pContent
	 * @param content
	 */
	private void verifyOperational( Offer offer) {
		for (com.generated.vos.productoffering.Site s : prodContent.getSite()) {
			if(s.getId() != 13){
			if (s.getId() == 10)
				continue;
			}
			if(offer.getOperational() == null){
				CompareValuesUtility.logFailed("DispElig", "IsDispElig should be set for xformatted items", "null");
				break;
			}
			Boolean isdispelig = SHCContentCommons.getOfferDispEligValue(Long.toString(s.getId()), offer.getOperational());
			/** Changes for Kmart MP project - for common spinid, isdispelig would be set to true for both sites*/
			/*if(!bCrossFormattedItem){
				if(siteToTest.equalsIgnoreCase("sears") && s.getId() == 1)
					CompareValuesUtility.compareValues("DispElig", null, isdispelig, TestUtils.getSite(s.getId()));
				if(siteToTest.equalsIgnoreCase("kmart") && s.getId() == 2)
					CompareValuesUtility.compareValues("DispElig", null, isdispelig, TestUtils.getSite(s.getId()));
			}else*/
				CompareValuesUtility.compareValues("DispElig", true, isdispelig, TestUtils.getSite(s.getId())); 
			
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
	}
}
