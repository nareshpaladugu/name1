package com.shi.content.matching;

import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

/**
 * Very basic producer to read messages set as system property and post to the kafka queue
 * @author nvarsh0
 *
 */

public class KafkaProducer {
	
	static Producer<String, String> producer ;
	
	public static void publish(String[] args) {
		
		String zookeeper = args[0].toString();
		String broker = args[1].toString();
		String topicName = args[2].toString();
		
		initProducer(zookeeper, broker);
		
		System.out.println("Posting to broker "+ broker + " Topic :"+ topicName );
		
		String toPush =  args[3].toString();
				//System.getProperty("Message");
		
		publishMessages(topicName, toPush);
		
		shutdownProducer();
		return;
	}
	
	/**
	 * Publish pipe separated messages as one message each to the queue
	 * @param topicName
	 * @param entireMessage
	 */
	public static void publishMessages(String topicName, String entireMessage){
		String[] allMessages = entireMessage.split("@N@");
		
		for(String message : allMessages){
			publishMessage(topicName, message.trim());
		}
	}
	
	/**
	 * Publish a single message to the specified topicName
	 * @param topicName
	 * @param message
	 */
	public static void publishMessage(String topicName, String message){
		
			KeyedMessage<String, String> kafkaData = new KeyedMessage<String, String>(
					topicName, "Key1",
					message.trim());
			producer.send(kafkaData);
			System.out.println("Posted message : "+ message);
	}
	
	public static void shutdownProducer(){
		producer.close();
	}
	
	/**
	 * Initializes the producer to post to a broker
	 * @param broker
	 */
	public static void initProducer(String zookeeper, String broker){
	
		Properties props = new Properties();
		props.put("zk.connect", zookeeper);
		props.put("metadata.broker.list", broker);
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		ProducerConfig config = new ProducerConfig(props);
		producer = new Producer<String, String>(config);
	}
}
