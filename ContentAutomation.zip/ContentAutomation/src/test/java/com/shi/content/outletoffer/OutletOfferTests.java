package com.shi.content.outletoffer;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.testcommons.FileProviderClass;

public class OutletOfferTests {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider" , groups="OutletOffer")
	public void testOutletOffer(String fileName) {
		
		OutletCommons outletCommons = new OutletCommons();

		BlockingQueue<List<String>> outletOfferQ = new LinkedBlockingQueue<List<String>>();
		TextFileParser<String> myParser = new TextFileParser<String>(fileName, outletOfferQ, new OutletFeedParser());
		Thread t = new Thread(myParser);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		while (true) {
			List<String> newData;
			int i=0;
			try {
				newData = outletOfferQ.poll(20, TimeUnit.SECONDS);

				if (newData == myParser.POISON_PILL) {
					break;
				}
				if(newData != null){
					pool.execute(new OutletOfferVerifications(outletCommons, outletMetaMap, newData, i++));
					//System.out.println("Sent "+ newData);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	Map<String, String> outletMetaMap = new HashMap<String, String>();
	
	@BeforeClass(groups="OutletOffer")
	public void loadOutletMetaMap(){
		try{
			String sQuery = "SELECT division, rtv_itm_cdn_cd, rtv_prd_cdn_cd, rtv_prd_cdn_cd_desc FROM content_batch.outletmeta";
			ResultSet rset = DBUtil.executeQueryReturnAll(sQuery);
			if (rset != null) {
				while(rset.next()) {
					String key = rset.getString(1) + "-" + rset.getString(2) + "-" + rset.getString(3);
					String value = rset.getString(4);
					outletMetaMap.put(key, value);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("OutletMetaMap size: " + outletMetaMap.size());
	}
	
	
	/*@BeforeClass(groups="OutletOffer")
	public void loadOutletMetaMap(){

		String outletEnumFile = System.getProperty("outletEnumFile", "src/test/resources/SEARS_OUTLET_ENUM.txt");

		if(outletEnumFile!=null && !outletEnumFile.isEmpty())
		{
			try
			{
				File f = new File(outletEnumFile);

				if(f.exists())
				{
					FileInputStream fstream = new FileInputStream(outletEnumFile);
					DataInputStream in = new DataInputStream(fstream);
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String strLine;

					while ((strLine = br.readLine()) != null)   
					{
						try {
							String[] line = strLine.split("\\|");
							
							if(line[0].equals("DIVISION") 
									|| line[0].equals("_PRD_CDN_CD_DESC"))
								continue;
							
							String key = line[0] + "-" + line[1] + "-" + line[2];
							String value = line.length==4?"":line[4];
							outletMetaMap.put(key, value);
								
						} catch (Exception e) {
							System.out.println("Error while reading line: " + strLine);
							e.printStackTrace();
						}
					}
					in.close();
				}
			}
			catch (Exception e){
				e.printStackTrace();
				System.err.println("Error: " + e.getMessage());
			}
		}
		System.out.println("OutletMetaMap size: " + outletMetaMap.size());
	}*/
}
