package com.shi.content.acme.ingest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaProducer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

/**
 * @author mbashee
 *
 */
public class AcmeItemBanMassProducer implements Runnable{
	List<String> lstOfIds;
	
	public AcmeItemBanMassProducer(){
		
	}
	
	public AcmeItemBanMassProducer(List<String> ids){
		this.lstOfIds = ids;
	}
	
	@Test(groups="acmeItemBanMassProducer")
	public void fetchAndProduce(){
		List<String> fetchSourceIds = new ArrayList<String>();
		
		if(!LoadProperties.RUN_PARAMS.isEmpty() && (LoadProperties.RUN_PARAMS.contains("vendor") || LoadProperties.RUN_PARAMS.contains("item"))){
			fetchSourceIds = fetch(LoadProperties.TESTDATALIMIT, true);
			System.out.println("Size: " +fetchSourceIds.size());
		}else{
			fetchSourceIds = fetch(LoadProperties.TESTDATALIMIT, false);
		}
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		List<List<String>> listOfSourceIds = Lists.partition(fetchSourceIds, 10);
		
		for(List<String> ids : listOfSourceIds){
			
			pool.execute(new AcmeItemBanMassProducer(ids));

		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		} 
	}	
	
	public List<String> fetch(int iMsgsToPublish, boolean source){
		
		String sURL = null;
		String sParamURL = null;
		int maxPageSize  = System.getProperty("maxPageSize")==null?20:Integer.parseInt(System.getProperty("maxPageSize"));
		
		if(iMsgsToPublish!= -1 && iMsgsToPublish < maxPageSize)
			maxPageSize = iMsgsToPublish;
		
		int pageNumber = System.getProperty("initPageNum") == null?0: Integer.parseInt(System.getProperty("initPageNum"));
		if(!source){
			pageNumber = Integer.parseInt(LoadProperties.RUN_PARAMS);
		}
		else{
			sParamURL = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
			if(sParamURL == null)
				System.out.println("Incorrect params");
		}
		
		
		
		List<String> lstSourceIds = new ArrayList<String>();
		while(true)
		{
			String guids ;
			String ids;
			int itemsFoundSize = 0;
			if(!source){
				sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source?page-size="+maxPageSize+"&page="+pageNumber;
			}else{
				sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source"+sParamURL+"&page-size="+maxPageSize+"&page="+pageNumber;
			}
			System.out.println("sUrl.... "+sURL);
	
			String jsonResponse = RestExecutor.getJSonResponse(sURL);
			
			
			if(source){
				guids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				ids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				if(ids == null || ids.isEmpty())
					break;
				itemsFoundSize = ids.split(",").length;
				
			}else{
				guids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				if(guids==null || guids.isEmpty())
				{
				// Break when there is no more data
					break;
				}
			}
			String[] spGuids = guids.split(",");
			
			//Taking out unique ids only
			Set<String> setOfGUIDs = new HashSet<String>(Arrays.asList(spGuids));
			lstSourceIds.addAll(setOfGUIDs);
			
			//Change last page size to less if required number of messages are less
			if(iMsgsToPublish != -1 && (iMsgsToPublish - lstSourceIds.size()) < maxPageSize)
				maxPageSize = iMsgsToPublish - lstSourceIds.size();
			
			if(source && itemsFoundSize < maxPageSize){
				System.out.println(" ========= No Need to hit page-size url again(res in last request was less than max page size) =========");
				break;
			}
			
			if(!source && spGuids.length<maxPageSize)
			{
				System.out.println(" ========= No Need to hit page-size url again(res in last request was less than max page size) =========");
				break;
			}
			
			if (iMsgsToPublish != -1 &&  iMsgsToPublish <= lstSourceIds.size()){
				System.out.println(" ========= Required ids found  =========");
				break;
			}
			
			pageNumber++;		
			
		}
			Set<String> finalList = new HashSet<String>(lstSourceIds);
			lstSourceIds = new ArrayList<String>(finalList);
			return lstSourceIds;
	}

	@Override
	public void run() {
		
		String format = LoadProperties.KAFKA_MSG_FORMAT;
		KafkaProducer kProd = new KafkaProducer();
		
		for(String id : lstOfIds) {
			System.out.println("Posting for id "+ id);
			String messageToPost = format.replace("@P1@", id);
			long lsentTS = kProd.publishMessage(messageToPost);
		}
		
		kProd.shutdownProducer();
	}
}
