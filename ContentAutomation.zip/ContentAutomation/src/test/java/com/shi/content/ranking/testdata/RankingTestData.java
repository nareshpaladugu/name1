package com.shi.content.ranking.testdata;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class RankingTestData
{
	public static Set<String> setOfProcessedUIDs = new HashSet<String>();
	public static Set<String> setOfProcessedOffers = new HashSet<String>();
	public static int testDataCount = 0;
	
	@Test(dataProvider="partNumberProvider",groups="BuyboxTestData")

	public void rankingTest(List<String> uidList)
	{
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		String site = LoadProperties.STORESITE;

		if(LoadProperties.EXECUTION_MODE.trim().equalsIgnoreCase("bucket"))
		{
			List<String> lstBuckets = getBucketRange();

			for (String sBucketNumber : lstBuckets) 
			{
				if(LoadProperties.TESTDATALIMIT != -1 && LoadProperties.TESTDATALIMIT <= testDataCount )
				{
					System.out.println("Test data limit reached.");
					break;
				}
				List<String> offerIdsByBucket = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER,Integer.parseInt(sBucketNumber));
				
//				List<String> offerIdsByBucket = new ArrayList<String>();		
//				offerIdsByBucket.add("SPM10993235613");
//				offerIdsByBucket.add("SPM7928398817");
//				offerIdsByBucket.add("029V002108567001");
//				offerIdsByBucket.add("SPM7932765917");
//				offerIdsByBucket.add("SPM8016609725");
//				offerIdsByBucket.add("00349443000");
				
				for(String offerId : offerIdsByBucket)
				{
					if(LoadProperties.TESTDATALIMIT != -1 && LoadProperties.TESTDATALIMIT <= testDataCount )
					{
						System.out.println("Test data limit reached.");
						break;
					}
					if(!RankingTestData.setOfProcessedOffers.contains(offerId))
					{
						pool.execute(new RankingTestDataExtractor(offerId,site));
						testDataCount++;
						//System.out.println("Site_OfferId : "+site +  "_" + offerId + "  Count of UIDs = " + RankingTestData.testDataCount);
					}
					
//					System.out.println("Count Of Processed UIDs=" + RankingTestData.setOfProcessedUIDs.size());
				}
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}

	public List<String> getBucketRange()
	{
		List<String> lstValues = new ArrayList<String>();

		if(LoadProperties.RUN_PARAMS.contains("-")){
			String[] range = LoadProperties.RUN_PARAMS.split("-");
			for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
				lstValues.add(i.toString());
			}
			System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

		}
		else
		{
			lstValues.add(LoadProperties.RUN_PARAMS);
		}

		return lstValues;
	}

	@DataProvider(name="partNumberProvider", parallel=true)
	public Object[][] partNumberProvider()
	{

		System.out.println("LoadProperties.EXECUTION_MODE  : "+LoadProperties.EXECUTION_MODE);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("bucket"))
		{
			return new Object[][] { { null } };
		}
		String 	partNumbers=null;
		List<String> uidList = new ArrayList<String>();

		if(LoadProperties.EXECUTION_MODE.trim().equalsIgnoreCase("list"))
		{
			partNumbers=LoadProperties.RUN_PARAMS;
			uidList  =  Arrays.asList(partNumbers.split(","));
		}

		if(LoadProperties.EXECUTION_MODE.contains("file")){
			try{
				FileInputStream fstream = new FileInputStream(LoadProperties.RUN_PARAMS);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty())
					{
						uidList.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}

		return new Object[][] { { uidList } };
	}
}