package com.shi.content.localadd;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.generated.vos.localad.LocalAdOffer;
import com.generated.vos.localad.Localad;
import com.generated.vos.localadgrp.Localadgrp_;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class NewLocalAdVerification implements Runnable {

	static Map<String, Boolean> storeIds = new HashMap<String, Boolean>();
	String finalId = null;
	Localad localGB;
	List<String> localadddata;
	int currentCount;
	 List<LocalOfferVO> listfeed = new ArrayList<LocalOfferVO>();
	public NewLocalAdVerification(List<String> pricingDataForProduct,
			int currentC) {
		this.localadddata = pricingDataForProduct;
		this.currentCount = currentC;
	}

	public void run() {
		long l1 = System.currentTimeMillis();
		CompareValuesUtility.init();
		List<String> localadd = new ArrayList<String>();
		String[] singlePriceData = localadddata.get(0).split("\\|");
		// this Gbid is the main id that we hit with api in the greenbox
		/*String GbId = singlePriceData[1] + "_" + singlePriceData[0] + "_"
				+ singlePriceData[10] + "_" + singlePriceData[11] + "_"
				+ singlePriceData[5].replaceAll("/", "").substring(0, 8) + "_"
				+ singlePriceData[6].replaceAll("/", "").substring(0, 8);*/
		// storing data in each line in the list
		String gbMainid="";
		
		try{
		for (String s : localadddata) {
			localadd.add(s);

		}
		// getting data for each line and each field
		
		for (String id : localadd) {
			String[] afterSplit = id.split("\\|");
			String unitNumber = afterSplit[0];
			String Ksn = afterSplit[1];
			//String ProductRegPrice = afterSplit[2];
			String ProductRegPrice = afterSplit[3];
			String ProductSalePrice = afterSplit[4];
			//String ProductClearancePrice = afterSplit[4];
			String ProductClearancePrice = afterSplit[5];
			String SaleStartDate = afterSplit[6];
			String SaleEndDate = afterSplit[7];
			String AdditionalDealInfo = afterSplit[8];
			String PriceQualifier = afterSplit[10];
			String FinePrint = afterSplit[12];
			String StoreID = afterSplit[11];
			String GroupID = afterSplit[30];
			String PostStartDate = afterSplit[13];
			String PostEndDate = afterSplit[14];
			String ListingStatus = afterSplit[31];
			
			Localadgrp_ localgrp=null;
			int grpStoreId=0;
			if (StoreID.equals("10153") && unitNumber.length()<7 ) {
				unitNumber=String.format("%07d", Integer.parseInt(unitNumber));	
			}
			gbMainid = unitNumber + "-" + Ksn ;
	        
			if(!GroupID.isEmpty()){
			 localgrp=RestExecutor.getDataById(CollectionValuesVal.LOCALADGRP,
						GroupID);
			 if(localgrp!=null)
			 grpStoreId = localgrp.getStoreId().intValue();
			}
			 double Cp=0; 
			 
			double Sp= Double.parseDouble(ProductSalePrice);
			if(!(ProductClearancePrice.equals(""))){
				if(ProductClearancePrice.matches("[0-9]+\\.[0-9]+$")){
			 Cp= Double.parseDouble(ProductClearancePrice);
				}
			}
			double Rp= Double.parseDouble(ProductRegPrice);
		if(SaleStartDate.equals("")||StoreID.equals("")||SaleEndDate.equals("")||!(unitNumber.matches("\\d+")) ||!(Ksn.matches("[a-zA-Z0-9]+$")) 
				||!(LoadProperties.Local_Store.contains(StoreID))||!(ProductRegPrice.matches("[0-9]+\\.[0-9]+$"))
				||!(ProductSalePrice.matches("[0-9]+\\.[0-9]+$"))
				||(Sp>Rp)||(!(ProductClearancePrice.equals("")) && Cp>Rp)){
			
			
			localGB = RestExecutor.getDataById(CollectionValuesVal.LOCALAD, gbMainid);
			if(localGB!=null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer should get loaded");
				CompareValuesUtility.setupResult(gbMainid, true);
			}
			//CompareValuesUtility.logFailed("Id","Not Valid","");
		}else{
			
			if (compareDates(SaleEndDate.substring(0,10)) == false ||(!(PostEndDate.equals("")) && (compareDates(PostEndDate.substring(0,10))== false))) {
				/*if(localGB!=null){
					CompareValuesUtility.logFailed("Id",gbMainid, "local offer should not get loaded");
					CompareValuesUtility.setupResult(gbMainid, true);
				}*/
			}else{
				
			if(PostStartDate.equals(""))
				PostStartDate=SaleStartDate;
			if(PostEndDate.equals(""))
				PostEndDate=SaleEndDate;
		 
          
			System.out.println(gbMainid);
			APIResponse<Localad> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.LOCALAD,gbMainid);
			if(allResponse!=null)
			localGB = allResponse.getT();
			 int stId = Integer.parseInt(StoreID);
			 if(!(GroupID.equals(""))&& (!(grpStoreId==stId) || !(GroupID.matches("[0-9]+")))){
		        	if(localGB!=null){
		        	CompareValuesUtility.logFailed("Id",gbMainid, "Group ID mismatch");
					CompareValuesUtility.setupResult(gbMainid, true);
		        	}
		     }else{	
			if(localGB==null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer not found");
				CompareValuesUtility.setupResult(gbMainid, true);
				return;
			}else{
			System.out.println("*****************************************");
			  
				
				List<LocalOfferVO> offers = new ArrayList<LocalOfferVO>();
				for (LocalAdOffer offer: localGB.getLocalAdOffers()){
					offers.add(new LocalOfferVO(offer.getSaleEndDt(), offer.getPostStDt(), offer.getPostEndDt(),offer.getSp(),offer.getSaleStDt(),offer.getRp(), offer.getPrcQlfr(),offer.getStatus(),offer.getCp(),offer.getAdtnlDeal()));
				}
				DecimalFormat df = new DecimalFormat("#.####");
							    
			    LocalOfferVO feedVO = new LocalOfferVO(JodaDateTimeUtility.getJodaTimeFormatString(SaleEndDate), JodaDateTimeUtility.getJodaTimeFormatString(PostStartDate), JodaDateTimeUtility.getJodaTimeFormatString(PostEndDate), 
			    		df.format(Sp), JodaDateTimeUtility.getJodaTimeFormatString(SaleStartDate), df.format(Rp), PriceQualifier.equals("")?null:PriceQualifier, ListingStatus,Cp==0?null:df.format(Cp),AdditionalDealInfo.equals("")?null:AdditionalDealInfo) ;
			    
			   
			   
			    boolean found =false;
			    if(!(listfeed.contains(feedVO))){
			    for (LocalOfferVO gbOffer: offers){
			    	if(gbOffer.equals(feedVO)){
			    		SimpleDateFormat myFormat  = new SimpleDateFormat("MM/dd/yyyy");
			    		SimpleDateFormat fromUser = new SimpleDateFormat("yyyy-MM-dd");
			    		if(compareDates(myFormat.format(fromUser.parse(feedVO.saleEndDt.substring(0,10)))) == false ||(!(feedVO.postEndDt.equals("")) && (compareDates(myFormat.format(fromUser.parse(feedVO.postEndDt.substring(0,10))))== false))){
			    			if(gbOffer!=null){
								CompareValuesUtility.logFailed("Id",gbMainid, "local offer should not get loaded");
								CompareValuesUtility.setupResult(gbMainid, true);
								found=true;
							}
			    		}
			    	else{
			    		CompareValuesUtility.compareValues("Id", gbMainid, localGB.getId());
						CompareValuesUtility.compareValues("ksn", Ksn
								, localGB.getKsn()==null?null:localGB.getKsn());
						CompareValuesUtility.compareValues("StoreId", StoreID
								, localGB.getStoreId()==null?null:localGB.getStoreId());
						CompareValuesUtility.compareValues("UnitNumber", unitNumber
								, localGB.getUnitnbr()==null?null:localGB.getUnitnbr());
						
						if(localgrp!=null){
						CompareValuesUtility.compareValues("grpid",localgrp.getId(),localGB.getGrpId());	
						CompareValuesUtility.compareValues("grpDesc",localgrp.getDesc(),localGB.getGrpDesc());	
						CompareValuesUtility.compareValues("grpName",localgrp.getName(),localGB.getGrpName());	
						CompareValuesUtility.compareValues("grpSTdt",JodaDateTimeUtility.getJodaTimeFormatString(localgrp.getSttdt()),localGB.getGrpStDt());	
						CompareValuesUtility.compareValues("grpEnddt",JodaDateTimeUtility.getJodaTimeFormatString(localgrp.getEnddt()),localGB.getGrpEndDt());	
						CompareValuesUtility.compareValues("grpType",localgrp.getType(),localGB.getGrpType());
						CompareValuesUtility.compareValues("grpDispOrd",localgrp.getDispOrd().intValue(),localGB.getGrpDispOrd());
						CompareValuesUtility.compareValues("grpStatus",localgrp.getStatus().intValue(),localGB.getGrpStatus());
						CompareValuesUtility.compareValues("grpStoreId",localgrp.getStoreId().intValue(),localGB.getGrpStoreId());
						}
						String storeDoc = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, unitNumber);
						String stgTmzn = JsonStringParser.getJsonValue(storeDoc,"{_blob{unit{stgTmzn}}}");
						CompareValuesUtility.compareValues("tz",stgTmzn==null?localGB.getTz():stgTmzn,localGB.getTz());
			    		compareValues("SaleEndDate",feedVO.saleEndDt.equals("")?null:feedVO.saleEndDt,gbOffer.saleEndDt.equals("")?null:gbOffer.saleEndDt);
						compareValues("postStDt",feedVO.postStDt.equals("")?null:feedVO.postStDt,gbOffer.postStDt.equals("")?null:gbOffer.postStDt);
						compareValues("postEndDt",feedVO.postEndDt.equals("")?null:feedVO.postEndDt,gbOffer.postEndDt.equals("")?null:gbOffer.postEndDt);
						compareValues("sp",feedVO.sp.equals("")?null:feedVO.sp,gbOffer.sp.equals("")?null:gbOffer.sp);
						compareValues("saleStDt",feedVO.saleStDt.equals("")?null:feedVO.saleStDt,gbOffer.saleStDt.equals("")?null:gbOffer.saleStDt);
						compareValues("rp",feedVO.rp.equals("")?null:feedVO.rp,gbOffer.rp.equals("")?null:gbOffer.rp);
						CompareValuesUtility.verifyNullOrEqual("prcQlfr",feedVO.prcQlfr==null?null:feedVO.prcQlfr,gbOffer.prcQlfr==null?null:gbOffer.prcQlfr);
						compareValues("status",feedVO.status.equals("")?null:feedVO.status,gbOffer.status.equals("")?null:gbOffer.status);	
						CompareValuesUtility.verifyNullOrEqual("cp",feedVO.cp==null?null:feedVO.cp,gbOffer.cp==null?null:gbOffer.cp);
						CompareValuesUtility.verifyNullOrEqual("AddionalInfo",feedVO.additionalInfo==null?null:feedVO.additionalInfo,gbOffer.additionalInfo==null?null:gbOffer.additionalInfo);
						CompareValuesUtility.verifyNullOrEqual("Search",unitNumber, allResponse.getSearchFieldValue("unitnbr").toString(),"unitNumber");
						found=true;
						System.out.println("check");
			    	}
			    	}else{
			    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			        DateTime lastWeek = new DateTime().minusDays(15);
			        Date c1 = dateFormat.parse(dateFormat.format(lastWeek.toDate()));
			        String a= gbOffer.saleEndDt.substring(0, 19) +"Z";
			        Date b1 = dateFormat.parse(a);
			        if (!(b1.compareTo(c1) >= 0)){
			        	CompareValuesUtility.logFailed("SaleEndDate",gbMainid, "PastDate offer present in GB");
			        }
			        found=true; 
			    	}
			    	 
			    }
			    listfeed.add(feedVO);
			    
			}else
				found=true;   
			    if(!found){
			    	CompareValuesUtility.logFailed("SaleEndDate",gbMainid, "Mismatch found");	
			    }
		
		}
			
		}
		}
		}
		}
		CompareValuesUtility.setupResult(gbMainid, true);
		}catch(Throwable e){
			System.out.println("Check this id :"+ gbMainid);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	
	public boolean compareDates(String a) { // method to check if date
		// is valid or not
            Date d = new Date();
            SimpleDateFormat sf = new SimpleDateFormat("MM/dd/yyyy");
        try {
            Date c1 = sf.parse(sf.format(d)); // /to get current date

              //Date a1 = sf.parse(a);
            Date b1 = sf.parse(a);

            if (b1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
				// dates in the
				// input file
             {
            return true;
             } else {
            return false;
            }
            } catch (ParseException pr) {
            pr.printStackTrace();
            return false;
       }
}

	
	
	class LocalOfferVO{
		
		String saleEndDt, postStDt, postEndDt, sp, saleStDt, rp, prcQlfr, status , cp, additionalInfo;
		public LocalOfferVO(String saleEndDt, String postStDt, String postEndDt, String sp, String saleStDt, String rp, String prcQlfr,String status, String cp,String additionalInfo) {
			
			this.saleEndDt = saleEndDt;
			this.postStDt = postStDt;
			this.postEndDt = postEndDt;
			this.sp = sp;
			this.saleStDt = saleStDt;
			this.rp = rp;
			this.prcQlfr = prcQlfr;
			this.status = status;
			this.cp = cp;
			this.additionalInfo = additionalInfo;
		}
	
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			LocalOfferVO other = (LocalOfferVO) obj;
			if (saleEndDt == null) {
				if (other.saleEndDt != null)
					return false;
			} else if (!saleEndDt.equals(other.saleEndDt))
				return false;
			if (postStDt == null) {
				if (other.postStDt != null)
					return false;
			} else if (!postStDt.equals(other.postStDt))
				return false;
			if (postEndDt == null) {
				if (other.postEndDt != null)
					return false;
			} else if (!postEndDt.equals(other.postEndDt))
				return false;
			if (sp == null) {
				if (other.sp != null)
					return false;
			} else if (!sp.equals(other.sp))
				return false;
			if (saleStDt == null) {
				if (other.saleStDt != null)
					return false;
			} else if (!saleStDt.equals(other.saleStDt))
				return false;
			if (rp == null) {
				if (other.rp != null)
					return false;
			} else if (!rp.equals(other.rp))
				return false;
			if (prcQlfr == null) {
				if (other.prcQlfr != null)
					return false;
			} else if (!prcQlfr.equals(other.prcQlfr))
				return false;
			if (status == null) {
				if (other.status != null)
					return false;
			} else if (!status.equals(other.status))
				return false;
			if (cp == null) {
				if (other.cp != null)
					return false;
			} else if (!cp.equals(other.cp))
				return false;
			if (additionalInfo == null) {
				if (other.additionalInfo != null)
					return false;
			} else if (!additionalInfo.equals(other.additionalInfo))
				return false;
			return true;
		}
	}
	
	

}