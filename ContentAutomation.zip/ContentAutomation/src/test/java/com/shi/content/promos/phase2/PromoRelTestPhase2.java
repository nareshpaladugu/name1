package com.shi.content.promos.phase2;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 * PromoRel phase 2 validation test
 */
public class PromoRelTestPhase2 
{
	public static Map<String,String> FieldsMap = new HashMap<String, String>();

	int chunkSize = 25;

	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp")
	public void promoRelTest(String sBucketNumber)
	{
		List<String> lstIdsInBucket = new ArrayList<String>();

		/* --------------- get promorel ids from specified bucket -----------------*/
		
		lstIdsInBucket = RestExecutor.getIdsForBucket(CollectionValuesVal.PROMO_REL, Integer.parseInt(sBucketNumber));

		System.out.println("Testing Bucket Number : "+sBucketNumber +" Got PromoRels : "+lstIdsInBucket.size());
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		/* --------------- make chunk wise parition of ids  -----------------*/
		
		List<List<String>> allPartitions = Lists.partition(lstIdsInBucket, chunkSize);

		for (List<String> list : allPartitions)
		{
			pool.execute(new PromoRelLogic(list));
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

	}

	
	/**
	 * This method reads field mapping file and prepares map
	 */
	@BeforeSuite
	public void readFieldMapping()
	{
		try
		{
			FileInputStream fstream = new FileInputStream("src/test/resources/fieldMapping.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			String[] sp;
			while ((strLine = br.readLine()) != null)   {

				sp =strLine.split("=");
				try {
					FieldsMap.put(sp[0],sp[1]);
				} catch (Exception e) {
				}
			}
			in.close();
		}
		catch (Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}

		System.out.println("Done reading field map, got "+FieldsMap.size());
	}
}
