package com.shi.content.vocabularyfeeds;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.VocabularyFeedParser;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.content.vocabularyfeeds.pojos.ProductVO;

/**
 * Test script to verify Vocabulary Feeds Load Job
 * @author vshar10
 *
 */
public class VerifyVocabularyFeedsLoadJob {

	@Test(groups="VocabularyFeedsLoad", dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void verifyVocabularyFeedsLoadJob(String fileName) throws Exception {
		BlockingQueue<List<ProductVO>> productsQueue = new LinkedBlockingQueue<List<ProductVO>>();
		VocabularyFeedParser<ProductVO> vocabuFeedsThread = new VocabularyFeedParser<ProductVO>(fileName,productsQueue);
		Thread t = new Thread(vocabuFeedsThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		List<ProductVO> products = null;

		while(true) {
			try {
				products = productsQueue.poll(30, TimeUnit.SECONDS);
				
				if(products == vocabuFeedsThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				
				if(products != null)
					pool.execute(new VocabularyFeedsLoadVerification(products.get(0)));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}