package com.shi.content.ranking.threepointfive.helper;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.shc.autocontent.LoadProperties;

public class RankingMongoDbUtil {

	public static MongoClient mongoClient=null;

	private static MongoClient getMongoClient()
	{
		try {

			if(mongoClient==null)
			{
				List<ServerAddress> seeds = new ArrayList<ServerAddress>();
				seeds.add( new ServerAddress( 
						LoadProperties.rankingMongoServer, 
						Integer.parseInt(LoadProperties.rankingMongoServerPort) ));

				List<MongoCredential> credentials = new ArrayList<MongoCredential>();

				credentials.add(
						MongoCredential.createScramSha1Credential(
								LoadProperties.rankingMongoUser,
								LoadProperties.rankingMongoDatabasename,
								LoadProperties.rankingMongoPassword.toCharArray()
								)
						);

				mongoClient = new MongoClient( seeds, credentials );
			}
		} catch (Exception e) {

			e.printStackTrace();
			return null;
		}

		return mongoClient;
	}

	public static MongoCollection<Document> getRankingMongoCollection()
	{
		try {

			if(mongoClient==null)
			{
				mongoClient = getMongoClient();
			}


			return mongoClient.getDatabase(LoadProperties.rankingMongoDatabasename).
					getCollection(LoadProperties.rankingMongoCollection);

		} catch (Exception e) {

			e.printStackTrace();
			return null;
		}
	}
}
