package com.shi.content.mptests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class MPPromotionsTest  {

	BlockingQueue<List<String>> mpPromotionsQueue = null;
	KafkaIAConsumer<String> mpPromoKafkaReader = null;
	Thread tConsumerThread = null;

	@Test(description = "Test MP Promotion messages that get inserted in promorel collection", groups = "MPPromorelDataValidation")
	public void MPPromotionsTests() {
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		if (LoadProperties.EXECUTION_MODE.equalsIgnoreCase("MESSAGE")) {
			mpPromotionsQueue = new LinkedBlockingQueue<List<String>>();
			mpPromoKafkaReader = new KafkaIAConsumer<String>(mpPromotionsQueue);
			tConsumerThread = new Thread(mpPromoKafkaReader);
			tConsumerThread.start();

			try {
				while (true) {
					List<String> nodeToTest;
					nodeToTest = mpPromotionsQueue.poll(50, TimeUnit.SECONDS);
					if (nodeToTest == mpPromoKafkaReader.POISON_PILL) {
						System.out.println("Got poison pill ..breaking out");
						break;
					}
					if (nodeToTest != null) {
						pool.execute(new MPPromoRelVerifications(nodeToTest.get(0)));
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			pool.shutdown();

			try {
				pool.awaitTermination(240, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				System.out.println("pool.awaitTermination - Exception");
			}			
		}  else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("LIST")) {
			String envMode = LoadProperties.getProperty("envMode","");
			if (envMode == null || envMode.equals("")) {
				System.out.println("______________________________________________________");
				System.out.println("Error: envMode is incorrect or not specified");
				System.out.println("______________________________________________________");
			}

			String runParams = LoadProperties.getProperty("runParams","");
			if (runParams == null || runParams.equals("")) {
				System.out.println("______________________________________________________");
				System.out.println("Error: runParams is incorrect or not specified");
				System.out.println("______________________________________________________");
			}

			try {
				HashMap<String, HashMap<String, String>> partNoData =  getData(envMode, runParams);
				for (String partNo : partNoData.keySet()) {
					pool.execute(new MPPromoRelVerifications(partNo, partNoData.get(partNo)));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			pool.shutdown();

			try {
				pool.awaitTermination(240, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				System.out.println("pool.awaitTermination - Exception");
			}			
		} else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("BUCKET_ID_LIST")) {
			
			// Get list of bucket ids specified
			String runParams = LoadProperties.getProperty("runParams","");
			if (runParams == null || runParams.equals("")) {
				System.out.println("______________________________________________________");
				System.out.println("Error: runParams is incorrect or not specified");
				System.out.println("______________________________________________________");
			} else {
				String[] bucketList = runParams.split(",");
				List<String> offerList = new ArrayList<>();
				
				// Get all offers specified in buckets
				for (String bucketId : bucketList) {
					List<String> tempOfferList = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER, Integer.parseInt(bucketId.trim()));
					if (tempOfferList != null && tempOfferList.size() > 0) {
						offerList.addAll(tempOfferList);
					}
				}

				try {
					for (String offerId : offerList) {
//						if (offerId.equals("027W951666130003"))
							pool.execute(new MPPromoRelVerifications(offerId,true));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				pool.shutdown();

				try {
					pool.awaitTermination(240, TimeUnit.MINUTES);
				} catch (InterruptedException e) {
					System.out.println("pool.awaitTermination - Exception");
				}			
			}
		} else {
			System.out.println("______________________________________________________");
			System.out.println("Error: Execution Mode is incorrect or not specified");
			System.out.println("______________________________________________________");
		}
	}

	public HashMap<String, HashMap<String, String>> getData(String mode, String runParams) {
		HashMap<String, HashMap<String, String>> map = new HashMap<>();
		runParams = runParams.replaceAll(" ", "");

		String[] arr = runParams.split("],");
		HashMap<String, String> promoInfo = new HashMap<>();

		for (String str : arr) {
			String[] arr2 = str.split("\\[");
			String partNo = arr2[0];
			arr2[1] = arr2[1].replace("]", "");
			String[] promoList = arr2[1].split(",");

			for (String promoId : promoList) {
				promoInfo.put(promoId, mode);
			}
			map.put(partNo, promoInfo);
		}
		return map;
	}
}	