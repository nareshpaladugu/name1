package com.shi.content.wcsmigration.verifications;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class CommonSHCConstants {
	
	public static final String ENDDATE = " 9999-12-31";
	public static final String STARTDATE = " 1999-01-01";
	public static final String ENDTIME = " 23:59:59";
	public static final String STARTTIME = " 00:00:00";
	public static final Date JOB_START_TIME = new Date();
	public static final String YYYY_MM_DD_HH_MM_SS_DATE = "yyyy-MM-dd HH:mm:ss";
	public static final DateFormat DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_DATE = new SimpleDateFormat(CommonSHCConstants.YYYY_MM_DD_HH_MM_SS_DATE);

	public static Calendar endOfTodayTime = setEndOfTodaysTime();

	public static Calendar setEndOfTodaysTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(CommonSHCConstants.JOB_START_TIME);
		calendar.set(Calendar.HOUR_OF_DAY, CommonSHCConstants.DEFAULT_END_HOUR);
		calendar.set(Calendar.MINUTE, CommonSHCConstants.DEFAULT_END_MIN_SEC);
		calendar.set(Calendar.SECOND, CommonSHCConstants.DEFAULT_END_MIN_SEC);
		return calendar;
	}
	
	public static final int DEFAULT_END_HOUR = 23;
	public static final int DEFAULT_END_MIN_SEC = 59;
	public static final int MAP_PRICE_ARG_HOURS = 12;//ItemLoadUtil.getProperty("map.price.arg.hours"));

}