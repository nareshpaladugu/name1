package com.shi.content.ranking.vos.pricing;

public class Shipping {
	private Float minRate;

	public Float getMinRate() {
		return minRate;
	}

	public void setMinRate(Float minRate) {
		this.minRate = minRate;
	}

}
