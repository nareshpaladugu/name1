package com.shi.content.batchrules;

import java.util.List;

import com.generated.vos.Shc_pricing.R;
import com.generated.vos.Shc_pricing.S;
import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.Shc_pricing.X;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.DateUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class PricingCheckHelper {

	public static boolean isValidRegPriceSet(String parentStore, String storeName,String sOfferId)
	{
		String id=sOfferId;
		if(!parentStore.equalsIgnoreCase("kmart") && (sOfferId.length()>=8))
		{
			//only for non kmart items
			id  = sOfferId .substring(0, 8);
		}

		ShcPricing shcPricing = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,OfferEligibilityHelper.getPricingId(parentStore,storeName, id));

		if(shcPricing==null)
		{
			return false;
		}

		if(isValidClearancePriceSet(parentStore, storeName, sOfferId))
		{
			//don't want clearance
			return false;
		}

		if(isValidSalePriceSet(parentStore, storeName, sOfferId))
		{
			//don't want sell price
			return false;
		}

		List<R> allRPrices= shcPricing.getP()==null?null:shcPricing.getP().getR();

		if(allRPrices!=null)
		{
			for (R r : allRPrices) {

				if(storeName.equalsIgnoreCase("kmart") )
				{
					//date is valid
					if(r.getIp()>0.02)
					{
						return true;
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(r.getSt(), r.getEt()))
					{
						//date is valid
						if(r.getIp()>0.02)
						{
							return true;
						}
					}
				}
			}
		}

		return false;
	}

	public static boolean isValidSalePriceSet(String parentStore, String storeName,String sOfferId)
	{
		String id=sOfferId;
		if(!parentStore.equalsIgnoreCase("kmart") && (sOfferId.length()>=8))
		{
			//only for non kmart items
			id  = sOfferId .substring(0, 8);
		}


		ShcPricing shcPricing = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,OfferEligibilityHelper.getPricingId(parentStore,storeName, id));

		if(shcPricing==null)
		{
			return false;
		}

		if(isValidClearancePriceSet(parentStore, storeName, sOfferId))
		{
			//don't want clearance
			return false;
		}

		List<S> allSPrices= shcPricing.getP()==null?null:shcPricing.getP().getS();

		if(allSPrices!=null)
		{
			for (S s : allSPrices) {

				if(storeName.equalsIgnoreCase("kmart") )
				{
					//date is valid
					if(s.getIp()>0.02)
					{
						return true;
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(s.getSt(), s.getEt()))
					{
						//date is valid
						if(s.getIp()>0.02)
						{
							return true;
						}
					}
				}
			}
		}


		return false;
	}

	public static boolean isValidClearancePriceSet(String parentStore, String storeName,String sOfferId)
	{
		sOfferId=sOfferId.trim();

		String sIdToHitTrimmed = sOfferId .substring(0, 8)  ;

		String sIdToHitFull = sOfferId  ;

		ShcPricing shcPricing = null;

		if(storeName.equalsIgnoreCase("kmart"))
		{
			//full offerid
			shcPricing 	= RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, OfferEligibilityHelper.getPricingId(parentStore, storeName, sIdToHitFull));
		}
		else if(storeName.equalsIgnoreCase("sears") && sOfferId.endsWith("000")  )
		{
			//first 8 digits - NV
			shcPricing 	= RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, OfferEligibilityHelper.getPricingId(parentStore, storeName, sIdToHitTrimmed));
		}
		else
		{
			shcPricing 	= RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, OfferEligibilityHelper.getPricingId(parentStore, storeName, sIdToHitFull));

			if((shcPricing==null) || (shcPricing.getP()==null) || (shcPricing.getP().getX()==null))
			{
				//need another try with trimmed
				//System.out.println("need another try with trimmed .... "+sIdToHitFull);

				shcPricing 	= RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, OfferEligibilityHelper.getPricingId(parentStore, storeName, sIdToHitTrimmed));
			}
			/*else
			{
				System.out.println("No need to again pricing for X price .... "+sIdToHitFull);
			}*/
		}


		if(shcPricing==null)
		{
			return false;
		}

		List<X> allX = shcPricing.getP()==null?null:shcPricing.getP().getX();

		if(allX!=null)
		{
			for (X x : allX) {

				if(storeName.equalsIgnoreCase("kmart") )
				{
					//Changed on 14-March-2016
					//if(x.getIp()>0.02)
					//Changed on 11-April-2016
					//if(x.getIp()>0.00)
					if(x.getIp()>0.02)
					{
						return true;
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(x.getSt(), x.getEt()))
					{
						//date is valid
						//	//Changed on 14-March-2016
						//if(x.getIp()>0.02)
						if(x.getIp()>0.02)
						{
							return true;
						}
					}
				}
			}
		}

		return false;
	}

	public static boolean isValidPriceGenericCheck(String parentStore, String storeName,String sOfferId,String sPriceToCheck)
	{

		Double priceToCheck=0d;

		try {
			priceToCheck = Double.parseDouble(sPriceToCheck);
		} catch (NumberFormatException e) {
			System.out.println("Invalid price sent for checking ... offer : "+sOfferId+ " Price : "+sPriceToCheck);
			return false;
		}

		String id=sOfferId;
		if(!parentStore.equalsIgnoreCase("kmart") && (sOfferId.length()>=8))
		{
			//only for non kmart items
			id  = sOfferId .substring(0, 8);
		}

		ShcPricing shcPricing = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,OfferEligibilityHelper.getPricingId(parentStore,storeName, id));

		return priceCheck(shcPricing, storeName, priceToCheck,parentStore);

	}
	public static boolean isInvalidPriceKmartPr(String sOfferId)
	{
		return  !isValidPrice("kmart", "puertorico", sOfferId, false);
	}

	/**
	 * This method checks for valid price for offer is, if r price is not there, it will check for x price
	 * in future more validation may be needed
	 * @param storeName
	 * @param sOfferId
	 * @return
	 */
	public static boolean isValidPrice(String parentStore, String storeName,String sOfferId,boolean sywItmTyp)
	{
		String id=sOfferId;
		if(!parentStore.equalsIgnoreCase("kmart") && (sOfferId.length()>=8))
		{
			//only for non kmart items
			id  = sOfferId .substring(0, 8);
		}

		ShcPricing shcPricing=null;

		if(parentStore.equalsIgnoreCase("sears") && sywItmTyp)
		{
			shcPricing = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,"0009305-"+id);
		} else
		{
			shcPricing = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,OfferEligibilityHelper.getPricingId(parentStore,storeName, id));
		}

		return priceCheck(shcPricing, storeName, 0.02d,parentStore);
	}


	private static boolean priceCheck(ShcPricing shcPricing,String storeName,Double priceToCheck,String parentStore)
	{

		if(shcPricing==null)
		{
			return false;
		}

		List<R> allRPrices =  shcPricing.getP()==null?null:shcPricing.getP().getR();
		List<S> allSPrices =  shcPricing.getP()==null?null:shcPricing.getP().getS();
		List<X> allXPrices =  shcPricing.getP()==null?null:shcPricing.getP().getX();


		if((allXPrices!=null) && !allXPrices.isEmpty())
		{
			//X is there
			for (X x : allXPrices) {

				if(parentStore.equalsIgnoreCase("kmart") || storeName.equalsIgnoreCase("kmart")||storeName.equalsIgnoreCase("mygofer"))
				{
					if(x.getIp()>0.02)
					{
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(x.getSt(), x.getEt()))
					{
						//date is valid
						if(x.getIp()>0.02)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
				}
			}
		}

		if((allSPrices !=null) && !allSPrices.isEmpty() )
		{
			//S is there

			for (S s : allSPrices) {

				if(parentStore.equalsIgnoreCase("kmart") ||storeName.equalsIgnoreCase("kmart")||storeName.equalsIgnoreCase("mygofer"))
				{
					if(JodaDateTimeUtility.validateDate(DateUtil.getCurrentDateAndTimeInRquiredFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"), s.getEt()))
					{
						//date is valid
						if(s.getIp()>0.02)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(s.getSt(), s.getEt()))
					{
						//date is valid
						if(s.getIp()>0.02)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
				}
			}
		}

		if((allRPrices !=null) && !allRPrices.isEmpty() )
		{
			//R is There

			for (R r : allRPrices) {

				if(parentStore.equalsIgnoreCase("kmart") ||storeName.equalsIgnoreCase("kmart")||storeName.equalsIgnoreCase("mygofer"))
				{
					if(r.getIp()>0.02)
					{
						return true;
					}
				}
				else
				{
					if(JodaDateTimeUtility.validateDate(r.getSt(), r.getEt()))
					{
						//date is valid
						if(r.getIp()>0.02)
						{
							return true;
						}
					}
				}
			}
		}
		System.out.println("**********************No Valid Price Avaliable**********************");
		return false;
	}
}
