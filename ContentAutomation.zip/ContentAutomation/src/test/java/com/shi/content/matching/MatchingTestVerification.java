package com.shi.content.matching;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.bson.Document;

import com.generated.vos.offer.DefiningAttr;
import com.google.gson.JsonObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class MatchingTestVerification implements Runnable
{
	private String sSSINUnderTest;

	Set<String> setOfBrandsSSINLevel;

	Set<String> setOfModelsSSINLevel;

	Set<String> setOfUPCsSSINLevel;

	Set<String> setOfParentIdsSSINLevel;

	Set<String> setOfOfferIdsSSINLevel;

	String sOfferTypeSSINLevel="-NA-";

	String sMasterVerticalSSINLevel="-NA-";

	String sPkgQtySSINLevel="-NA-";

	Map<List<DefiningAttr>, Integer> mapDefAttrSSINLevel;

	List<JsonObject> allOffersSchemasInGroupedBySSIN;
	
	Set<String> sExpectedSSINSet = null;
	public MatchingTestVerification(String ssinUnderTest, String singleDocument)
	{
		this.sSSINUnderTest = ssinUnderTest;

		/*============================== Get all offer data for single SSIN ====================*/

		allOffersSchemasInGroupedBySSIN = JSONParser.stringToArray(
				JsonStringParser.getJsonValueNew(singleDocument, "OfferList"), JsonObject[].class);
	}

	public void run() 
	{
		long startTime = System.currentTimeMillis();

		int groupNumberTracker = 1;

		setOfBrandsSSINLevel = new HashSet<String>();
		setOfModelsSSINLevel = new HashSet<String>();
		setOfUPCsSSINLevel = new HashSet<String>();
		setOfOfferIdsSSINLevel=new HashSet<String>();
		setOfParentIdsSSINLevel=new HashSet<String>();
		mapDefAttrSSINLevel=new HashMap<List<DefiningAttr>, Integer>();

		Map<String,SubGroupVo> mapOfSubGroupedByUID = new java.util.LinkedHashMap<String, SubGroupVo>();

		CompareValuesUtility.init();

		boolean siteOnlyOffer=false;

		boolean parentLevelExclusion=false;

		if(allOffersSchemasInGroupedBySSIN.isEmpty())
		{
			//Rare case
			CompareValuesUtility.addFailedDataFieldForReport("Data Error", "No Offers Found under SSIN");
		}	
		else
		{
			sExpectedSSINSet = getExpectedSSIN(allOffersSchemasInGroupedBySSIN);
			
			for (JsonObject jsonObject  : allOffersSchemasInGroupedBySSIN) 
			{
				/* ============= JSON Document to Matching Data VO =============*/
				
				SingleOfferMatchDataVo vo = getMatchingData(jsonObject);

				/*============================== Check for exclusion rules ====================*/

				checkForExclusionRule(vo);

				checkForSearsOrKmartOnlyOffer(vo);

				siteOnlyOffer = siteOnlyOffer || vo.isSiteOnlySpecificOffer;

				SubGroupVo subGroupVo = mapOfSubGroupedByUID.get(vo.getUid());

				if(subGroupVo==null)
					subGroupVo=new SubGroupVo(groupNumberTracker++);

				List<SingleOfferMatchDataVo> offerListBySingleUID = subGroupVo.getListOfOffers();

				if(offerListBySingleUID == null)
					offerListBySingleUID = new ArrayList<SingleOfferMatchDataVo>();

				vo.setOfferNumberInSubGroup(offerListBySingleUID.size()+1);

				offerListBySingleUID.add(vo);
				if(vo.isExcludedAtParentLevel())
					parentLevelExclusion=true;

				subGroupVo.setListOfOffers(offerListBySingleUID);

				mapOfSubGroupedByUID.put(vo.getUid(),subGroupVo);

				setOfBrandsSSINLevel.add(vo.getBrandName());

				setOfModelsSSINLevel.add(vo.getModelNumber());

				if(!vo.getUpc().isEmpty())
					setOfUPCsSSINLevel.add(vo.getUpc());

				setOfOfferIdsSSINLevel.add(vo.getOfferid());

				setOfParentIdsSSINLevel.add(vo.getParentId());

				if(vo.getParentId().equals(sSSINUnderTest))
				{
					/*============================== if ParentId=SSIN, capture expected vertical, offer type and pkgQty ====================*/

					sMasterVerticalSSINLevel = vo.getMasterVerticalId();
					sOfferTypeSSINLevel = vo.getOfferType();
					sPkgQtySSINLevel = vo.getPackageQty();
				}
			}

			Iterator<Entry<String, SubGroupVo>> uidKeyIterator = mapOfSubGroupedByUID.entrySet().iterator();

			Set<String> upcSetByUID = null;

			Map<List<DefiningAttr>, Integer> mapAccordingtoDefAttrsUIDLevel =new LinkedHashMap<List<DefiningAttr>, Integer>();

			int ctrUID = -1;

			boolean excluded=false;
			while (uidKeyIterator.hasNext()) 
			{
				ctrUID ++;

				Entry<String, SubGroupVo> subGroupbyUIDEntry =  uidKeyIterator.next();

				List<SingleOfferMatchDataVo> offerListByUID = subGroupbyUIDEntry.getValue().getListOfOffers();

				upcSetByUID = new HashSet<String>();

				mapAccordingtoDefAttrsUIDLevel.clear();

				mapAccordingtoDefAttrsUIDLevel.put(offerListByUID.get(0).getDefiningAttrs(), 1);

				excluded=false;
				//all offer should have same UPC, for offer having null UPC, it should have matching brand model
				for (int i = 0; i < offerListByUID.size(); i++) 
				{
					SingleOfferMatchDataVo matchingDataVo = offerListByUID.get(i);


					if(!matchingDataVo.getUpc().isEmpty())
						upcSetByUID.add(matchingDataVo.getUpc());

					CompareValuesUtility.addDataFieldForReport("GroupNumber", subGroupbyUIDEntry.getValue().getGroupNumber()+"."+ matchingDataVo.getOfferNumberInSubGroup());

					CompareValuesUtility.addDataFieldForReport("OfferId", matchingDataVo.getOfferid());

					if(MatchingTest.exceptionVerticals.contains(matchingDataVo.getMasterVerticalId())    //if vertical is from exception list
							&& 	matchingDataVo.isSiteOnlySpecificOffer   // and if its site only specific offer
							&&  allOffersSchemasInGroupedBySSIN.size()>1) // and there are other offers also in group
					{
						CompareValuesUtility.addFailedDataFieldForReport("SiteOnly-Specific-Offer-grouped", "should be excluded from group" );
					}
					else
					{
						CompareValuesUtility.addDataFieldForReport("Missing-OfferId", "");
						CompareValuesUtility.addDataFieldForReport("Missing-Offer-Reason", "");

						//For NV items group all offer should same UID, UID subgroup size should be 1 
						if(sOfferTypeSSINLevel.equalsIgnoreCase("NV") && ctrUID>=1)
						{
							CompareValuesUtility.addFailedDataFieldForReport("UID", matchingDataVo.getUid());
						}
						else
						{
							CompareValuesUtility.addDataFieldForReport("UID", matchingDataVo.getUid());
						}

						CompareValuesUtility.addDataFieldForReport("UPC", matchingDataVo.getUpc());

						CompareValuesUtility.addDataFieldForReport("ParentId", matchingDataVo.getParentId());

						if(sMasterVerticalSSINLevel.equals(matchingDataVo.getMasterVerticalId()))
						{
							CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
						}
						else
						{
							CompareValuesUtility.logFailed("MasterVertical", sMasterVerticalSSINLevel,matchingDataVo.getMasterVerticalId());
						}

						CompareValuesUtility.compareValues("OfferType", sOfferTypeSSINLevel,matchingDataVo.getOfferType());

						CompareValuesUtility.addDataFieldForReport("Brand", matchingDataVo.getBrandName());

						CompareValuesUtility.addDataFieldForReport("Model", matchingDataVo.getModelNumber());

						CompareValuesUtility.addDataFieldForReport("ProgramType", matchingDataVo.getProgramType());

						CompareValuesUtility.compareValues("PackageQty", sPkgQtySSINLevel,matchingDataVo.getPackageQty());

						CompareValuesUtility.addDataFieldForReport("DivLine", matchingDataVo.getDivLine());

						if(mapAccordingtoDefAttrsUIDLevel.get(matchingDataVo.getDefiningAttrs())==null)
						{
							CompareValuesUtility.addFailedDataFieldForReport("DefAttrs", matchingDataVo.getDefiningAttrsStr());
						}
						else
						{
							CompareValuesUtility.addDataFieldForReport("DefAttrs", matchingDataVo.getDefiningAttrsStr());
						}

						Integer ys2 = mapDefAttrSSINLevel.get(matchingDataVo.getDefiningAttrs());

						if(ys2==null)
						{
							mapDefAttrSSINLevel.put(matchingDataVo.getDefiningAttrs(),1);
						}
						else
						{
							mapDefAttrSSINLevel.put(matchingDataVo.getDefiningAttrs(),ys2++);
						}

						if(matchingDataVo.isSingleItemGroupNeeded())
						{
							try {
								if(isGroupContainsSingleItemByUID(matchingDataVo.getUid()))
								{
									excluded=true;
									CompareValuesUtility.addDataFieldForReport("Single-Offer-SubGroup-Reason", matchingDataVo.getSingleItemGroupReason());
								}
								else
								{
									CompareValuesUtility.addFailedDataFieldForReport("Single-Offer-SubGroup-offercount", "Found No/Multiple Offers");
								}
							} catch (Exception e) {

								CompareValuesUtility.addFailedDataFieldForReport("Exception", "Single-Offer-SubGroup check : "+e.getMessage());
							}
						}

						if(!excluded && i == offerListByUID.size())
						{
							//OfferCount-By-UID check
							CompareValuesUtility.compareValues("OfferCount-By-UID",offerListByUID.size(),RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"uid="+subGroupbyUIDEntry.getKey().toString()).size());
						}
					}
				}

				//here UPC set should not be more than 1 (it can be 0 or 1)

				if(upcSetByUID.size()>1)
				{
					CompareValuesUtility.addFailedDataFieldForReport("MultipleUPC under same UID", StringUtils.join(upcSetByUID, ","));
				}

			}

			/*================ ensure parent item is not grouped with any other item as its excluded at parent level===========*/
			if( parentLevelExclusion  )
			{
				try {
					if( !isGroupContainsSingleItemBySsinAndParentId(sSSINUnderTest, sSSINUnderTest))
						CompareValuesUtility.addDataFieldForReport("Single-Offer-Group", "Found Multiple Items(ParentIds)");
				} catch (Exception e) {
					CompareValuesUtility.addDataFieldForReport("Exception","Single-Offer-Group check : "+ e.getMessage());
				}
			}
			else
			{
				/*================ check for missing offers if not excluded at parent level===========*/

				if( siteOnlyOffer  &&  allOffersSchemasInGroupedBySSIN.size()==1)
				{
					System.out.println("No need to check for missing offers for single site only offer");
				}
				else
				{
					List<SingleOfferMatchDataVo> listOfMissingOffer;

					try
					{
						listOfMissingOffer = getMissingOffersIfAny();

						if(!listOfMissingOffer.isEmpty())
						{
							//got missing offers
							for (SingleOfferMatchDataVo singleOfferMatchDataVo : listOfMissingOffer) 
							{
								CompareValuesUtility.addDataFieldForReport("GroupNumber", "-");

								CompareValuesUtility.addDataFieldForReport("OfferId", "-");

								if(singleOfferMatchDataVo.isValidDefAttr())
								{
									CompareValuesUtility.addFailedDataFieldForReport("Missing-OfferId", singleOfferMatchDataVo.getOfferid());
									CompareValuesUtility.addDataFieldForReport("Missing-Offer-Reason", singleOfferMatchDataVo.getMissingOfferReason());
								}
								else
								{
									CompareValuesUtility.addDataFieldForReport("Missing-OfferId", singleOfferMatchDataVo.getOfferid());
									CompareValuesUtility.addDataFieldForReport("Missing-Offer-Reason", singleOfferMatchDataVo.getMissingOfferReason());
								}

								CompareValuesUtility.addDataFieldForReport("UID", singleOfferMatchDataVo.getUid());

								CompareValuesUtility.addDataFieldForReport("UPC", singleOfferMatchDataVo.getUpc());

								CompareValuesUtility.addDataFieldForReport("ParentId", singleOfferMatchDataVo.getParentId());

								CompareValuesUtility.logPassed("MasterVertical", sMasterVerticalSSINLevel, sMasterVerticalSSINLevel);

								CompareValuesUtility.compareValues("OfferType", sOfferTypeSSINLevel,singleOfferMatchDataVo.getOfferType());

								CompareValuesUtility.addDataFieldForReport("Brand", singleOfferMatchDataVo.getBrandName());

								CompareValuesUtility.addDataFieldForReport("Model", singleOfferMatchDataVo.getModelNumber());

								CompareValuesUtility.addDataFieldForReport("ProgramType", singleOfferMatchDataVo.getProgramType());

								CompareValuesUtility.addDataFieldForReport("DefAttrs", singleOfferMatchDataVo.getDefiningAttrsStr());

								CompareValuesUtility.addDataFieldForReport("PackageQty-Data", singleOfferMatchDataVo.getPackageQty());

								CompareValuesUtility.addDataFieldForReport("MasterVertical-Data", singleOfferMatchDataVo.getMasterVerticalId());

								if(!singleOfferMatchDataVo.isValidDefAttr())
								{
									CompareValuesUtility.addDataFieldForReport("Invalid Def Attr-Skipped from matching", "Yes");
								}
							}
						}
					} catch (Exception e) {
						CompareValuesUtility.addDataFieldForReport("Exception", e.getMessage());
					}
				}
			}
			
			if(sExpectedSSINSet.contains(sSSINUnderTest))
				CompareValuesUtility.logPassed("SSIN", sSSINUnderTest, sSSINUnderTest);
			else
				CompareValuesUtility.logFailed("SSIN", StringUtils.join(sExpectedSSINSet, ","), sSSINUnderTest);
		}

		long stop = System.currentTimeMillis();

		System.out.println(" SSIN "+this.sSSINUnderTest +" took(s) : " +(stop-startTime)/1000);

		CompareValuesUtility.setupResult(this.sSSINUnderTest, true);

		clean();

	}

	/**
	 * Set all instance variable to null
	 */
	public void clean()
	{
		sSSINUnderTest=null;

		setOfBrandsSSINLevel=null;

		setOfModelsSSINLevel=null;

		setOfUPCsSSINLevel=null;

		setOfParentIdsSSINLevel=null;

		setOfOfferIdsSSINLevel=null;

		sOfferTypeSSINLevel=null;

		sMasterVerticalSSINLevel=null;

		sPkgQtySSINLevel=null;

		mapDefAttrSSINLevel=null;

		allOffersSchemasInGroupedBySSIN=null;
	}

	/**
	 * Check for missing offers
	 * @return
	 * @throws Exception
	 */
	private List<SingleOfferMatchDataVo> getMissingOffersIfAny() throws Exception
	{
		long start = System.currentTimeMillis();

		List<SingleOfferMatchDataVo> missingOfferList = new ArrayList<SingleOfferMatchDataVo>();

		Document matchCriteria = new Document();

		Document projCriteria = new Document("_id",0)

		.append("_blob.offer.id", 1)
		.append("_blob.offer.brandName", 1)
		.append("_blob.offer.modelNo",1)
		.append("_blob.offer.altIds.upc",1)
		.append("_blob.offer.identity.uid",1)
		.append("_blob.offer.identity.ssin",1)
		.append("_blob.offer.identity.parentId",1)
		.append("_blob.offer.definingAttrs",1)
		.append("_blob.offer.packageQty",1)
		.append("_ft.pgrmType",1)
		.append("_search.hierarchy",1)
		.append("_blob.offer.classifications.isUvd",1)
		.append("_blob.offer.classifications.offerType",1);

		//............ Ignore already Grouped offers...........

		matchCriteria.append("_id", new Document("$nin",setOfOfferIdsSSINLevel));

		//............ offer type should match............
		matchCriteria.append("_blob.offer.classifications.offerType",sOfferTypeSSINLevel);


		if(sPkgQtySSINLevel.isEmpty())
			matchCriteria.append("_blob.offer.packageQty",new Document("$exists",false));
		else
			matchCriteria.append("_blob.offer.packageQty",sPkgQtySSINLevel);

		//............ MasterVertical should match............
		try {
			matchCriteria.append("_blob.offer.taxonomy.master.hierarchy.0.id", Integer.parseInt(sMasterVerticalSSINLevel));
		} catch (NumberFormatException e1) {
			throw new Exception("Exception... Master Vertical not available  ");
		}

		//............ UPC or B+M should match............
		if(setOfUPCsSSINLevel.isEmpty())
		{
			matchCriteria.append("_blob.offer.brandName", new Document("$in",setOfBrandsSSINLevel));
			matchCriteria.append("_search.model_no", new Document("$in",setOfModelsSSINLevel));
			matchCriteria.append("_search.upc", new Document("$exists",false));
		}
		else
		{
			//if direct upc OR no upc and brand + model

			Document clause1 = new Document("_search.upc", new Document("$in",setOfUPCsSSINLevel));

			Document clause2 = new Document("_search.model_no", new Document("$in",setOfModelsSSINLevel))
			.append("_blob.offer.brandName", new Document("$in",setOfBrandsSSINLevel));

			List<Document> or = new ArrayList<Document>();
			or.add(clause1);
			or.add(clause2);

			matchCriteria.append("$or", or);
		}

		MongoClient mongoClient=null;
		try {
			mongoClient = MongoDBClient.connectToMongoDB();
		} catch (Exception e) {
			e.printStackTrace();
		}

		MongoDatabase db = mongoClient.getDatabase("offer");

		MongoCollection<Document> dbCollection = db.getCollection("offer");

		FindIterable<Document> result = dbCollection.find(matchCriteria).projection(projCriteria);

		String offerSchm;

		for (Document document : result) 
		{
			offerSchm = document .toJson().toString();

			SingleOfferMatchDataVo vo = new SingleOfferMatchDataVo();

			vo.setBrandName(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.brandName",true));

			vo.setUpc(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.altIds.upc",true));

			vo.setDivLine(JsonStringParser.getJsonValueNew(offerSchm, "_search.hierarchy",true));

			vo.setIsUvd(Boolean.parseBoolean(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.classifications.isUvd",true)));

			vo.setModelNumber(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.modelNo",true));

			vo.setOfferid(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.id",true));

			vo.setOfferType(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.classifications.offerType",true));

			vo.setPackageQty(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.packageQty",true));

			vo.setParentId(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.identity.parentId",true));

			vo.setProgramType(JsonStringParser.getJsonValueNew(offerSchm, "_ft.pgrmType",true));

			vo.setSsin(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.identity.ssin",true));

			/*===========no need to add excluded items in missing list=============*/
			if(Arrays.asList(MatchingExclusionConstants.ExcludedModels.split(",")).contains(vo.getModelNumber()))
				continue;
			
			if(Arrays.asList(MatchingExclusionConstants.ExcludedBrands.split(",")).contains(vo.getBrandName()))
				continue;
			
			try {
				vo.setStrDefiningAttributes(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.definingAttrs",true));
			} catch (Exception e) {
				System.out.println("DefAttr Exception "+e.getMessage());
			}

			vo.setUid(JsonStringParser.getJsonValueNew(offerSchm, "_blob.offer.identity.uid",true));

			//checkForExclusionRule(vo);

			if(setOfParentIdsSSINLevel.contains(vo.getParentId()))
			{
				//if parent is there in existing group this offer has to be there anyhow

				vo.setMissingOfferReason("Parent Id Matching");

				if(sOfferTypeSSINLevel.equals("NV"))
				{
					missingOfferList.add(vo);
					//FOR NV DA - not matters
					vo.setValidDefAttr( true );
				}
				else
				{
					if(!vo.getDefiningAttrs().isEmpty())
					{
						//Here no need to check def attr within group offers as parent is matching
						vo.setValidDefAttr( isValidDefAttr(vo.getDefiningAttrs()));
						missingOfferList.add(vo);
					}
				}
			}

			//if UPC matching
			else 
			{
				if( setOfUPCsSSINLevel.contains(vo.getUpc()))
					vo.setMissingOfferReason("UPC Matching");
				else
					vo.setMissingOfferReason("Need to debug");

				if(sOfferTypeSSINLevel.equals("NV"))
				{
					missingOfferList.add(vo);
					//FOR NV DA - not matters
					vo.setValidDefAttr( true );
				}
				else
				{
					//For "V" offers, Def Attrs should match with any one from group
					if(mapDefAttrSSINLevel.get(vo.getDefiningAttrs())!=null)
					{
						missingOfferList.add(vo);
					}
				}
			}
		}

		long stop = System.currentTimeMillis();

		System.out.print ("Find missing offers took (seconds) :"+(stop-start)/1000);

		return missingOfferList;
	}


	private static boolean isValidDefAttr( List<DefiningAttr> das)
	{
		try {
			for (DefiningAttr definingAttr : das) {

				if(definingAttr.getAttr()==null || definingAttr.getVal() ==null)
				{
					//System.out.println("Invalid def attrs ... ");
					return false;
				}
			}
		} catch (Exception e) {
			System.out.println(" isValidDefAttr() Exception ..."+e.getMessage());
			return false;
		}


		return true;

	}
	/**
	 * Checks for exclusion logic w.r.t Model_no,Model,ProgramType,Division,Division Line
	 * @param offerSchema
	 * @return
	 */
	private void checkForExclusionRule(SingleOfferMatchDataVo vo)
	{
		vo.setSingleItemGroupNeeded(false);
		vo.setExcludedAtParentLevel(false);
		//----------------------------------------------------------------------------------

		/*Change made on 9-March-2016, to include kmart items also in group*/
		/*if(vo.getProgramType().equalsIgnoreCase("kmart"))
		{
			// for kmart item it has be in single separate group
			vo.setSingleItemGroupNeeded(true);
			//vo.setSingleItemGroupReason("Kmart Item");

			vo.setExcludedAtParentLevel(true);
		}*/

		//----------------------------------------------------------------------------------

		if(vo.getOfferType().equalsIgnoreCase("S") || vo.getOfferType().equalsIgnoreCase("HS") || vo.getIsUvd())
		{
			vo.setSingleItemGroupNeeded(true);
			//vo.setSingleItemGroupReason("UVD/HS/S");

			vo.setExcludedAtParentLevel(true);
		}

		//----------------------------------------------------------------------------------

		if(vo.getUpc().equals("000000000000") || vo.getUpc().equals("0000000000000") )
		{
			//for these upcs single group needed
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("UPC exclusion : 00000000000000");
		}
		List<String> brandsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedBrands.split(","));

		List<String> modelsToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedModels.split(","));

		if(vo.getOfferid().startsWith("028") || vo.getOfferid().startsWith("095") || vo.getOfferid().startsWith("090") )
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Division :  028,090,095");	
		}

		if(brandsToExclude.contains(vo.getBrandName()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Brand");
		}

		if(modelsToExclude.contains(vo.getModelNumber()))
		{
			vo.setSingleItemGroupNeeded(true);
			vo.setSingleItemGroupReason("Execluded Models");
		}

		List<String> divLinesToExclude = Arrays.asList(MatchingExclusionConstants.ExcludedDivLines.split(","));

		if(vo.getDivLine()!=null && !vo.getDivLine().isEmpty())
		{
			for (String divline : divLinesToExclude) {

				if(vo.getDivLine().startsWith(divline))
				{
					vo.setSingleItemGroupNeeded(true);
					vo.setSingleItemGroupReason("Execluded DivLines");
				}
			}
		}
	}

	/**
	 * Json Document to Matching Data VO
	 * @param jsonObject
	 * @return
	 */
	private SingleOfferMatchDataVo getMatchingData(JsonObject jsonObject)
	{
		SingleOfferMatchDataVo vo =new SingleOfferMatchDataVo();

		vo.setOfferid(jsonObject.get("offerId")==null?"":jsonObject.get("offerId").getAsString());

		vo.setBrandName(jsonObject.get("brandName")==null?"":jsonObject.get("brandName").getAsString());

		vo.setMasterVerticalId( jsonObject.get("masterVertical")==null?"":jsonObject.get("masterVertical").toString());

		vo.setUpc( jsonObject.get("upc")==null?"": jsonObject.get("upc").getAsString());

		vo.setBrandCodeId( jsonObject.get("brandCodeId")==null?"": jsonObject.get("brandCodeId").getAsString());
		
		vo.setSpinId( jsonObject.get("spinId")==null?"": jsonObject.get("spinId").getAsString());

		vo.setProgramType( jsonObject.get("pgrmType")==null?"": jsonObject.get("pgrmType").getAsString());

		vo.setUid( jsonObject.get("uid")==null?"": jsonObject.get("uid").getAsString());

		vo.setSsin( jsonObject.get("ssin")==null?"": jsonObject.get("ssin").getAsString());

		vo.setWebHierarchy( jsonObject.get("webHie")==null?"": jsonObject.get("webHie").toString());

		vo.setParentId( jsonObject.get("parentId")==null?"": jsonObject.get("parentId").getAsString());

		vo.setModelNumber(jsonObject.get("model")==null?"":jsonObject.get("model").getAsString());

		vo.setDivLine( jsonObject.get("hierarchy")==null?"": jsonObject.get("hierarchy").getAsString());

		vo.setOfferType( jsonObject.get("offerType")==null?"": jsonObject.get("offerType").getAsString());

		vo.setIsUvd( jsonObject.get("isUvd")==null?false: Boolean.parseBoolean(jsonObject.get("isUvd").getAsString()));

		vo.setPackageQty(jsonObject.get("pkgQty")==null?"":jsonObject.get("pkgQty").getAsString());

		vo.setStrDefiningAttributes(jsonObject.get("defattr")==null?"":jsonObject.get("defattr").toString());

		return vo;
	}

	/**
	 * No. of offers returned for SSIN and parentId has to be same	
	 * @param ssin
	 * @param parentId
	 * @return
	 */
	private boolean isGroupContainsSingleItemBySsinAndParentId(String ssin, String parentId)
	{
		List<String> offIdsListBySSIN = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin="+ ssin);

		List<String> offIdsListByParId = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+ parentId);

		offIdsListBySSIN=offIdsListBySSIN==null?new ArrayList<String>():offIdsListBySSIN;

		offIdsListByParId=offIdsListByParId==null?new ArrayList<String>():offIdsListByParId;

		if(offIdsListBySSIN.isEmpty() && offIdsListByParId.isEmpty() )
		{
			return false;
		}

		Set<String> ssinOfferList = new HashSet<>(offIdsListBySSIN);

		Set<String> parentIdOfferList = new HashSet<>(offIdsListByParId);

		parentIdOfferList.removeAll(ssinOfferList);

		if(parentIdOfferList.isEmpty())
		{
			//yes single group
			return true;
		}

		return false;
	}

	private boolean isGroupContainsSingleItemByUID(String uid)
	{
		List<String> offersByUID = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid="+ uid);

		offersByUID=offersByUID==null?new ArrayList<String>():offersByUID;

		if(offersByUID.size()==1 )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	private void checkForSearsOrKmartOnlyOffer(SingleOfferMatchDataVo vo)
	{
		String programType = vo.getProgramType();

		String webHierarchy = vo.getWebHierarchy();

		String sears = JsonStringParser.getJsonValueNew(webHierarchy,"sears");
		String kmart = JsonStringParser.getJsonValueNew(webHierarchy,"kmart");


		if( (programType.equalsIgnoreCase("sears")  && (kmart==null || kmart.equalsIgnoreCase("null"))) ||
				(programType.equalsIgnoreCase("kmart")  && (sears==null || sears.equalsIgnoreCase("null"))) )
		{

			List<String> idsList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"spinId="+vo.getSpinId());

			if(idsList!=null && idsList.size()==1)
			{
				vo.setSiteOnlySpecificOffer(true);
			}
		}

		vo.setSiteOnlySpecificOffer(false);
	}
	
	
	public static Set<String> getExpectedSSIN(List<JsonObject> allOffersSchemasInGroupedBySSIN2)
	{
		/*Picking SSIN(Content of an offer) rules: 			SEARS -->KMART-> FBM --> FBS --> DSS --> CPC*/
		/*		CPC		DSS		FBM		FBS		HS		Kmart		S		Sears		UVD		UVD-DUMMY		 */

		Map<String,Set<String>> searsMap = new TreeMap<String, Set<String>>();

		String sPgrmType = "";
		String sParentId = "";
		
		String currentKey = null;
		for (JsonObject  jsonObject : allOffersSchemasInGroupedBySSIN2) 
		{
			sPgrmType =  jsonObject.get("pgrmType")==null?"": jsonObject.get("pgrmType").getAsString();

			sParentId =  jsonObject.get("parentId")==null?"": jsonObject.get("parentId").getAsString();
			
			switch(sPgrmType.toUpperCase())
			{
			case "SEARS":	currentKey="s1";		break;
			case "KMART":	currentKey="s2";		break;
			case "FBM":	 
			case "FBS":		currentKey="s3";		break;
				
			case "DSS":		currentKey="s4";		break;
			case "CPC":		currentKey="s5";		break;
			default:		
			{
				currentKey="s6";		break;
			}
			}

			Set<String> setOfParentIds = searsMap.get(currentKey);

			if(setOfParentIds==null)
			{
				setOfParentIds=new HashSet<String>();
			}

			setOfParentIds.add(sParentId);

			searsMap.put(currentKey, setOfParentIds);
		}

		Set<Entry<String, Set<String>>> entrySet = searsMap.entrySet();
		Iterator<Entry<String, Set<String>>> iterator = entrySet.iterator();

		while (iterator.hasNext()) {
			Entry<String, Set<String>> entry = iterator.next();

			if(entry.getValue()!=null)
			{
				return entry.getValue();
			}
		}

		return null;
	}

}