package com.shi.content.gbcomparetests;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.listeners.SimpleReporter;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;


/**
 * Utility to compare two greenboxes or two collections.
 * Supports running by buckets and lists. <br>
 * Hits two collections in different gbs and does a document comparison. <br>
 * 
 * <b>Properties being used :</b><br>
 * runParams  - Specify bucket numbers or list of ids<br>
 * collection - collection to test<br>
 * greenvip  - GreenBox 1<br>
 * otherGbBox - Greenbox 2
 * @author nvarsh0
 *
 */
public class MultiCollectionCompare implements Runnable 
{

	String runParam;

	public MultiCollectionCompare(String idToTest){
		this.runParam = idToTest;
	}

	public static String fieldsToConsider = null;

	@BeforeGroups(groups="GBToGBCompare")
	public void setupHeaders()
	{

		fieldsToConsider = System.getProperty("fieldsToConsider","");
		System.out.println("fieldsToConsider............... "+fieldsToConsider);

		List<String> headers = new ArrayList<>();
		headers.add("Id");
		headers.add("Field");
		headers.add("GB1");
		headers.add("GB2");
		try {
			SimpleReporter.resultsQueue.put(headers);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp",groups="GBToGBCompare")
	public void testCompareIds(String sRunParam)
	{

		if(LoadProperties.IS_LISTBASED_RUN)
		{
			Thread runSingleData = new Thread(new MultiCollectionCompare(sRunParam));
			runSingleData.start();
			try {
				runSingleData.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else if(LoadProperties.IS_BUCKETBASED_RUN)
		{

			String collectionToQuery = LoadProperties.collection;

			if(LoadProperties.collection.contains(","))
			{
				String[] collectionsToTest = LoadProperties.collection.trim().split(",");
				collectionToQuery = collectionsToTest[0];
			}

			List<String> lstIdsInBucket = null;
			if(LoadProperties.searchKey.isEmpty()){
				lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.getCollection(collectionToQuery),Integer.parseInt(sRunParam));
			}else{
				try{
					String[] filter = LoadProperties.searchKey.split("=");
					//System.out.println(filter[0] + "=" + filter[1]);
					lstIdsInBucket  = RestExecutor.getFilteredIds(CollectionValuesVal.getCollection(collectionToQuery), Integer.parseInt(sRunParam), filter[0], filter[1]);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			System.out.println("Running for bucket : "+ sRunParam+"  Size "+ lstIdsInBucket.size());
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			int i = 0;
			for(String id : lstIdsInBucket){
				//For promorel store specific 
				if(StringUtils.equalsIgnoreCase(LoadProperties.promorelStoreSpecificCompare, "true") && !StringUtils.startsWith(id, LoadProperties.promorelStore)){
					continue;
				}
				i++;
				pool.execute(new MultiCollectionCompare(id));
				/*if(i>5)
					break;*/
			}

			pool.shutdown();

			try {
				pool.awaitTermination(400, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void run()
	{

		String promoid = runParam;//"212502_p";//"214446_p";
		//System.out.println("Testing for "+ promoid);
		String data1, data2;		
		
		if(LoadProperties.collection.contains(","))
		{
			String[] collectionsToTest = LoadProperties.collection.trim().split(",");
			data1 = RestExecutor.getJSonResponseById(CollectionValuesVal.getCollection(collectionsToTest[0].trim()), promoid);
			data2 = RestExecutor.getJSonResponseById(CollectionValuesVal.getCollection(collectionsToTest[1].trim()), promoid);
			
		}
		else{
			CollectionValues collectionToTest = CollectionValuesVal.getCollection(LoadProperties.collection);

			data1 = RestExecutor.getJSonResponseById(collectionToTest, promoid);
			URI green2URI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, collectionToTest, promoid);
			data2 = RestExecutor.getJSonResponse(green2URI);
		}
		
		try {
			JSONAssert.assertEquals(data1, data2, JSONCompareMode.NON_EXTENSIBLE);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(AssertionError err){
			String msg = err.getMessage();
			List<String> finalResult = new ArrayList<String>();
			//System.out.println(msg);
			String[] allErrs = msg.split(";");
			for(String error : allErrs)
			{
				if(fieldsToConsider==null || fieldsToConsider.isEmpty())
				{
					if(checkInIgnored(error))
						continue;
				}
				else
				{
					if(!checkInRequired(error))
						continue;
				}
				
				error=error.replaceAll("\\[_bucket=.*?\\]", "");
				error=error.replaceAll(",", ";");
				error=formatError(error);
				error=error+"\n";

				//For first error add id
				if(finalResult.size()==0)
					finalResult.add(promoid);
				finalResult.add(error);
			}

			if(finalResult.size()>0){
				SimpleReporter.logFailed(finalResult);
			}
			else{
				logPassed(promoid);

			}

			return;
		}
		logPassed(promoid);
	}

	/**
	 * Method to check if field name contains any of the values in the ignored list
	 * Returns true if it is an ignored error, false otherwise
	 * @param error
	 * @return
	 */
	private boolean checkInIgnored(String error) {
		for(String ignoredError : LoadProperties.IGNORED_FAILURES){
			if(!ignoredError.isEmpty() && error.contains(ignoredError))
				return true;
		}
		return false;

	}
	
	private boolean checkInRequired(String error) 
	{
		for(String requiredFields : fieldsToConsider.split(","))
		{
			if(!requiredFields.isEmpty() && error.contains(requiredFields))
				return true;
		}
		return false;

	}

	/**
	 * Formats the error line.  Splits the lines into csvs
	 * @param error
	 * @return
	 */
	private String formatError(String error){
		String[] splitData = error.split("\n");
		String finalError = "";

		if(splitData.length == 3 && splitData[1].contains("Unexpected")){
			finalError =  splitData[0]+",,"+ splitData[1];
		}else if(splitData[0].matches(".Expected \\d+ values but got \\d+")){
			String[] furtherSplits = splitData[0].split("Expected");
			String[] expActuals = furtherSplits[1].split("but");
			finalError =  furtherSplits[0]+","+expActuals[0]+","+ expActuals[1];
		}
		else{
			for(int i=0; i< splitData.length; i++ ){
				splitData[i] = splitData[i].trim();
				if(splitData[i].startsWith("Expected:"))
					splitData[i] = splitData[i].replaceAll("Expected.*?:", "");
				else if(splitData[i].startsWith("got:"))
					splitData[i] = splitData[i].replaceAll("got.*?:", "");
				finalError = finalError +  splitData[i]+ ",";
			}
		}
		return finalError;
	}

	/**
	 * Add PromoId to passed list
	 * @param promoId
	 */
	private void logPassed(String promoId){
		//System.out.println("Id "+ promoId + " Passed");
		List<String> passedResult = new ArrayList<String>();
		passedResult.add(promoId);
		passedResult.add("Passed");
		SimpleReporter.logPassed(passedResult);
	}

}
