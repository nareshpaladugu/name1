package com.shi.content.seller;

import java.util.List;

import com.generated.vos.seller.LocalMarketPlace;
import com.generated.vos.seller.NonContinentalSurcharge_;
import com.generated.vos.seller.OptInRestrictShipLocs_;
import com.generated.vos.seller.PickUpLocation;
import com.generated.vos.seller.ShcWeightHandlingFee;
import com.generated.vos.seller.ShipMethods_;
import com.generated.vos.seller.StoreFront;
import com.generated.vos.seller.WareHouseLocation;
import com.generated.vos.seller.WareHouseLocation_;
import com.generated.vos.seller.WareHouseLocation__;
import com.generated.xmls.seller.BusinessAddress;
import com.generated.xmls.seller.Cpc;
import com.generated.xmls.seller.Dss;
import com.generated.xmls.seller.Fbm;
import com.generated.xmls.seller.Fbs;
import com.generated.xmls.seller.LocalMarketplace;
import com.generated.xmls.seller.Location;
import com.generated.xmls.seller.NonContinentalSurcharge;
import com.generated.xmls.seller.OptInRestrictShipLocs;
import com.generated.xmls.seller.OrderAmountChargeRange;
import com.generated.xmls.seller.ProgramsTypeItem;
import com.generated.xmls.seller.Seller;
import com.generated.xmls.seller.SellerWarehouse;
import com.generated.xmls.seller.ShcOrderHandlingFee;
import com.generated.xmls.seller.ShcWarehouse;
import com.generated.xmls.seller.ShcWeightRange;
import com.generated.xmls.seller.ShipMethods;
import com.generated.xmls.seller.ShippingChargeModelTypeChoiceItem;
import com.generated.xmls.seller.ShippingCharges;
import com.generated.xmls.seller.Site;
import com.generated.xmls.seller.StoreFrontOffer;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class SellerVerifications implements Runnable {
	
	Seller seller;

	public SellerVerifications(Seller seller) {
		this.seller = seller;
	}

	@Override
	public void run() {

		CompareValuesUtility.init();
		String sellerId = null;
		try {
			
			sellerId = seller.getSellerId().toString();
			
			System.out.println("Testing seller "+ sellerId);
			
			APIResponse<com.generated.vos.seller.Seller> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.MPSELLER, sellerId);
			com.generated.vos.seller.Seller gbSeller = (com.generated.vos.seller.Seller) allResponse.getT();
			
			//com.generated.vos.seller.Seller sellerResp = RestExecutor.getDataById(CollectionValuesVal.MPSELLER, sellerId);
			
			if(gbSeller == null){
				CompareValuesUtility.logFailed("id", sellerId, "Not Found in GB");	
				CompareValuesUtility.setupResult(sellerId+"", true);
				return;
			}else{
				verifySeller(seller, gbSeller, sellerId);
				CompareValuesUtility.compareValues("_search.vanityName", seller.getSellerStoreFrontName(), allResponse.getSearchFieldValue("vanityName"));
			}
			
			CompareValuesUtility.setupResult(sellerId+"", true);
						
		} catch (Throwable e) {
			System.out.println("Check this id :" + sellerId);
			e.printStackTrace();
		} finally {
			CompareValuesUtility.teardown();
		}

	}

	private void verifySeller(Seller xmlSeller, com.generated.vos.seller.Seller gbSeller, String sellerId) {
		CompareValuesUtility.compareValues("id", sellerId, gbSeller.getId());
		CompareValuesUtility.compareValues("name", xmlSeller.getName(), gbSeller.getName());
		CompareValuesUtility.verifyNullOrEqual("email", xmlSeller.getEmail(), gbSeller.getEmail());
		CompareValuesUtility.verifyNullOrEqual("description", TestUtils.plainEncodeHTML(xmlSeller.getDescription()), gbSeller.getDescription());
		CompareValuesUtility.compareValues("sellerTier", xmlSeller.getSellerTier()==null?"REGULAR":xmlSeller.getSellerTier(), gbSeller.getSellerTier());
		CompareValuesUtility.verifyNullOrEqual("phone", xmlSeller.getPhone(), gbSeller.getPhone());
		CompareValuesUtility.verifyNullOrEqual("disableinUI", xmlSeller.getDisableInUi()==null?"false":xmlSeller.getDisableInUi().toString(), gbSeller.getDisableinUI().toString());
		
		/*Business Address*/
		BusinessAddress xmlBusAddr = xmlSeller.getBusinessAddress();
		com.generated.vos.seller.BusinessAddress gbBusAddr = gbSeller.getBusinessAddress();
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getLine1(), gbBusAddr==null?null:gbBusAddr.getLine1(), "line1");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getLine2(), gbBusAddr==null?null:gbBusAddr.getLine2(), "line2");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getCity(), gbBusAddr==null?null:gbBusAddr.getCity(), "city");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getState(), gbBusAddr==null?null:gbBusAddr.getState(), "state");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getZipCode(), gbBusAddr==null?null:gbBusAddr.getZipCode(), "zipCode");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:xmlBusAddr.getCountry(), gbBusAddr==null?null:gbBusAddr.getCountry(), "country");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:(xmlBusAddr.getCoordinates()==null?null:xmlBusAddr.getCoordinates().getLatitudeDegrees()), 
				gbBusAddr==null?null:(gbBusAddr.getCoordinates()==null?null:gbBusAddr.getCoordinates().getLatitudeDegrees()), "latitudeDegrees");
		CompareValuesUtility.verifyNullOrEqual("businessAddress", xmlBusAddr==null?null:(xmlBusAddr.getCoordinates()==null?null:xmlBusAddr.getCoordinates().getLongitudeDegrees()), 
				gbBusAddr==null?null:(gbBusAddr.getCoordinates()==null?null:gbBusAddr.getCoordinates().getLongitudeDegrees()), "longitudeDegrees");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("sellerLogo", xmlSeller.getSellerLogo()==null?null:xmlSeller.getSellerLogo().getUrl(), gbSeller.getSellerLogo());
		CompareValuesUtility.verifyNullOrEqual("acctStoreUnit", xmlSeller.getSalesTaxRestructure()==null?null:xmlSeller.getSalesTaxRestructure().getAccountStoreUnit(), gbSeller.getAcctStoreUnit());
		
		/*Nexus States*/
		String[] nexSts = null;
		if(xmlSeller.getSalesTaxRestructure()!=null 
				&& xmlSeller.getSalesTaxRestructure().getNexusStates()!=null 
				&& !xmlSeller.getSalesTaxRestructure().getNexusStates().isEmpty()){
			
			nexSts = xmlSeller.getSalesTaxRestructure().getNexusStates().split(",");
			
			for(String nxSt : nexSts){
				CompareValuesUtility.verifyItemInList("nexusStates", nxSt, gbSeller.getNexusStates());
			}
		}else{
			CompareValuesUtility.compareValues("nexusStates", "[]", gbSeller.getNexusStates().toString());
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/*Vendor Accounts*/
		for( String vndAcnt : xmlSeller.getVendorAccounts().getVendorAccount()){
			CompareValuesUtility.verifyItemInList("vndrAcnts", vndAcnt, gbSeller.getVndrAcnts());
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/*Sites*/
		for(Site site : xmlSeller.getSites().getSite()){
			if(site.getId().toString().equals("1") || site.getId().toString().equals("2") || site.getId().toString().equals("4")){
				CompareValuesUtility.verifyInListField("sites", site.getId().toString(), gbSeller.getSites(), "id", com.generated.vos.seller.Site.class);
				CompareValuesUtility.verifyInListField("sites", site.getContent(), gbSeller.getSites(), "name", com.generated.vos.seller.Site.class);
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/*Storefront*/
		StoreFront gbStoreFront = gbSeller.getStoreFront();
		CompareValuesUtility.compareValues("storeFront", xmlSeller.getSellerStoreFrontName(), gbStoreFront==null?null:gbStoreFront.getName(), "name");
		CompareValuesUtility.compareValues("storeFront", "/seller/"+xmlSeller.getSellerStoreFrontName(), gbStoreFront==null?null:gbStoreFront.getUrlName(), "url");
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlSeller.getOffersForStoreFront()!=null){
			for(StoreFrontOffer xOffr : xmlSeller.getOffersForStoreFront().getStoreFrontOffer()){
				Boolean oFound = false;
				String offerId = generateOfferId(xOffr.getItemId().toString(), xOffr.getProgramType());
				if(offerId!=null){
					if(gbStoreFront !=null && gbStoreFront.getOffers()!=null && !gbStoreFront.getOffers().isEmpty()){
						for(com.generated.vos.seller.Offer gOffr : gbStoreFront.getOffers()){					
							if(offerId.equals(gOffr.getOfferId())){
								oFound = true;
								CompareValuesUtility.logPassed("storeFrontOfferId", offerId, offerId);
								CompareValuesUtility.compareValues("storeFrontOfferRank", xOffr.getRank().toString(), gOffr.getRank().toString());
							}
						}
						if(!oFound){
							CompareValuesUtility.logFailed("storeFrontOfferId", offerId, "Not Found in GB");
						}
					}else{
						CompareValuesUtility.logFailed("storeFrontOfferId", offerId, "Not Found in GB");
					}
				}
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}else{
			CompareValuesUtility.verifyNull("storeFrontOffers", gbStoreFront.getOffers().isEmpty()?null:"Found in GB");
		}

		/*programs*/
		for(ProgramsTypeItem pgmType : xmlSeller.getPrograms().getProgramsTypeItem()){
			
			if(pgmType.getCpc()!=null){
				verifyCpc(pgmType.getCpc(), gbSeller.getPrograms().getCpc());
			}else if(pgmType.getFbm()!=null){
				verifyFbm(pgmType.getFbm(), gbSeller.getPrograms().getFbm());
			}else if(pgmType.getFbs()!=null){
				verifyFbs(pgmType.getFbs(), gbSeller.getPrograms().getFbs());
			}else{
				verifyDss(pgmType.getDss(), gbSeller.getPrograms().getDss());
			}
		}
		
		
	}

	private String generateOfferId(String itemId, String programType) {
		String offerId = null;
		switch(programType){
		case "FBM":
		case "DSS":
			offerId = "SPM" + itemId;
			break;
		case "FBS":
			List<String> offerIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "spinId", itemId);
			if(!offerIds.isEmpty())
				offerId = offerIds.get(0); 
			break;
		case "CPC":
			offerId = "SPA" + seller.getSellerId().toString() + "S" + itemId;
			break;
		}
		return offerId;
	}

	private void verifyDss(Dss xmlDss, com.generated.vos.seller.Dss gbDss) {
		CompareValuesUtility.verifyNullOrEqual("DSS", xmlDss.getFbmsElementsGroup().getServiceHours(), gbDss.getServiceHours(), "serviceHours");
		CompareValuesUtility.verifyNullOrEqual("DSS", xmlDss.getFbmsElementsGroup().getEdiRouteCode(), gbDss.getEdiRouteCode(), "ediRouteCode");
		CompareValuesUtility.verifyNullOrEqual("DSS", xmlDss.getFbmsElementsGroup().getOpenOrderThreshold(), gbDss.getOpenOrderThreshold()==null?null:gbDss.getOpenOrderThreshold().intValue(), "openOrderThreshold");
		CompareValuesUtility.verifyNullOrEqual("DSS", xmlDss.getFbmsElementsGroup().getSywMaxEligibility(), gbDss.getSywMaxEligibility(), "sywMaxEligibility");
		CompareValuesUtility.verifyNullOrEqual("DSS", xmlDss.getFbmsElementsGroup().getDunsNumber(), gbDss.getDunsNumber(), "dunsNumber");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getLine1(), gbDss.getReturnAddress().getLine1(), "line1");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getLine2(), gbDss.getReturnAddress().getLine2(), "line2");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getCity(), gbDss.getReturnAddress().getCity(), "city");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getState(), gbDss.getReturnAddress().getState(), "state");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getZipCode(), gbDss.getReturnAddress().getZipCode(), "zipCode");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getCountry(), gbDss.getReturnAddress().getCountry(), "country");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getCoordinates()==null?null:xmlDss.getReturnAddress().getCoordinates().getLatitudeDegrees(), 
				gbDss.getReturnAddress().getCoordinates()==null?null:gbDss.getReturnAddress().getCoordinates().getLatitudeDegrees(), "latitudeDegrees");
		CompareValuesUtility.verifyNullOrEqual("DSS-ReturnAddr", xmlDss.getReturnAddress().getCoordinates()==null?null:xmlDss.getReturnAddress().getCoordinates().getLongitudeDegrees(), 
				gbDss.getReturnAddress().getCoordinates()==null?null:gbDss.getReturnAddress().getCoordinates().getLongitudeDegrees(), "longitudeDegrees");
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlDss.getSellerWarehouses()!=null){
			verifyDssSellerWrhs(xmlDss.getSellerWarehouses().getSellerWarehouse(), gbDss.getWareHouseLocations());
		}
		
		/*Ship Methods*/
		CompareValuesUtility.compareValues("DSS-ShipMthd", xmlDss.getShippingRates().getShipMode().getMode(), gbDss.getShippingRates().getShipMode(), "mode");
		
		if(xmlDss.getShippingRates().getShipMode().getShipMethods()!=null){		
			ShipMethods xmlShpMthd = xmlDss.getShippingRates().getShipMode().getShipMethods();
			ShipMethods_ gbShpMthd = gbDss.getShippingRates().getShipMethods();
			CompareValuesUtility.verifyNullOrEqual("DSS-ShipMthd", xmlShpMthd.getGround()==null?false:xmlShpMthd.getGround(), gbShpMthd.getGround(), "ground");
			CompareValuesUtility.verifyNullOrEqual("DSS-ShipMthd", xmlShpMthd.getExpedited()==null?false:xmlShpMthd.getExpedited(), gbShpMthd.getExpedited(), "expedited");
			CompareValuesUtility.verifyNullOrEqual("DSS-ShipMthd", xmlShpMthd.getPremium()==null?false:xmlShpMthd.getPremium(), gbShpMthd.getPremium(), "premium");
		}
		if(xmlDss.getShippingRates().getShipMode().getOptInRestrictShipLocs()!=null){		
			OptInRestrictShipLocs xmlOptIn = xmlDss.getShippingRates().getShipMode().getOptInRestrictShipLocs();
			OptInRestrictShipLocs_ gbOptIn = gbDss.getShippingRates().getOptInRestrictShipLocs();
			CompareValuesUtility.verifyNullOrEqual("DSS-ShipMthd", xmlOptIn.getAlaska()==null?false:xmlOptIn.getAlaska(), gbOptIn.getAlaska(), "alaska");
			CompareValuesUtility.verifyNullOrEqual("DSS-ShipMthd", xmlOptIn.getHawaii()==null?false:xmlOptIn.getHawaii(), gbOptIn.getHawaii(), "hawaii");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyDssSellerWrhs(SellerWarehouse[] sellerWarehouse, List<WareHouseLocation__> wareHouseLocations) {
		for(SellerWarehouse xWrhs : sellerWarehouse){
			Boolean wFound = false;
			for(WareHouseLocation__ gWrhs : wareHouseLocations){
				if(xWrhs.getLocationId().toString().equals(gWrhs.getLocationId())){
					wFound = true;
					CompareValuesUtility.compareValues("DSS-SellerWrhs", xWrhs.getLocationId().toString(), gWrhs.getLocationId(), "locationId");
					CompareValuesUtility.compareValues("DSS-SellerWrhs", xWrhs.getName(), gWrhs.getName(), "name");
					CompareValuesUtility.compareValues("DSS-SellerWrhs", xWrhs.getEmail(), gWrhs.getEmail(), "email");
					CompareValuesUtility.compareValues("DSS-SellerWrhs", xWrhs.getPhone(), gWrhs.getPhone(), "phone");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAlternatePhone(), gWrhs.getAlternatePhone(), "altPhone");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getFax(), gWrhs.getFax(), "fax");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getStandardOrderProcessingTime().getRegular(), gWrhs.getSopt().getRegular(), "soptRegular");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getStandardOrderProcessingTime().getOversize(), gWrhs.getSopt().getOversize(), "soptOversize");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getLine1(), gWrhs.getAddress().getLine1(), "line1");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getLine2(), gWrhs.getAddress().getLine2(), "line2");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getCity(), gWrhs.getAddress().getCity(), "city");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getState(), gWrhs.getAddress().getState(), "state");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getZipCode(), gWrhs.getAddress().getZipCode(), "zipCode");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getCountry(), gWrhs.getAddress().getCountry(), "country");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getCoordinates()==null?null:xWrhs.getAddress().getCoordinates().getLatitudeDegrees(), 
							gWrhs.getAddress().getCoordinates()==null?null:gWrhs.getAddress().getCoordinates().getLatitudeDegrees(), "latitudeDegrees");
					CompareValuesUtility.verifyNullOrEqual("DSS-SellerWrhs", xWrhs.getAddress().getCoordinates()==null?null:xWrhs.getAddress().getCoordinates().getLongitudeDegrees(), 
							gWrhs.getAddress().getCoordinates()==null?null:gWrhs.getAddress().getCoordinates().getLongitudeDegrees(), "longitudeDegrees");
					break;
					
				}
			}
			if(!wFound){
				CompareValuesUtility.compareValues("DSS-SellerWrhs", xWrhs.getLocationId().toString(), "Not found", "locationId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
	}

	private void verifyFbs(Fbs xmlFbs, com.generated.vos.seller.Fbs gbFbs) {
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getFbmsElementsGroup().getServiceHours(), gbFbs.getServiceHours(), "serviceHours");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getFbmsElementsGroup().getEdiRouteCode(), gbFbs.getEdiRouteCode(), "ediRouteCode");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getFbmsElementsGroup().getOpenOrderThreshold(), gbFbs.getOpenOrderThreshold()==null?null:gbFbs.getOpenOrderThreshold().intValue(), "openOrderThreshold");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getFbmsElementsGroup().getSywMaxEligibility(), gbFbs.getSywMaxEligibility(), "sywMaxEligibility");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getFbmsElementsGroup().getDunsNumber(), gbFbs.getDunsNumber(), "dunsNumber");
		CompareValuesUtility.compareValues("FBS", xmlFbs.getTrustedSeller(), gbFbs.getTrustedSeller(), "trustedSeller");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getPickAndPackFee().toString(), gbFbs.getPickAndPackFee(), "pickAndPackFee");
		CompareValuesUtility.verifyNullOrEqual("FBS", xmlFbs.getDiscountShippingRate().toString(), gbFbs.getDiscountShipRate(), "discountShipRate");
		CompareValuesUtility.addNewMultiValuedFields();
		
		ShcOrderHandlingFee xFbsOrd = xmlFbs.getShcOrderHandlingFee();
		CompareValuesUtility.verifyNullOrEqual("FBS-OrdHndlgFee", xFbsOrd==null?null:xFbsOrd.getStandard(), gbFbs.getShcOrderHandlingFee().getStandard(), "standard");
		CompareValuesUtility.verifyNullOrEqual("FBS-OrdHndlgFee", xFbsOrd==null?null:xFbsOrd.getExpedited(), gbFbs.getShcOrderHandlingFee().getExpedited(), "expedited");
		CompareValuesUtility.verifyNullOrEqual("FBS-OrdHndlgFee", xFbsOrd==null?null:xFbsOrd.getPremium(), gbFbs.getShcOrderHandlingFee().getPremium(), "premium");
		CompareValuesUtility.verifyNullOrEqual("FBS-OrdHndlgFee", xFbsOrd==null?null:xFbsOrd.getLtl(), gbFbs.getShcOrderHandlingFee().getLtl(), "ltl");
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlFbs.getShcWeightHandlingFee()!=null){
			for(ShcWeightRange xSwhf : xmlFbs.getShcWeightHandlingFee().getShcWeightRange()){
				Boolean wFound = false;
				for(ShcWeightHandlingFee gSwhf : gbFbs.getShcWeightHandlingFee()){
					if(xSwhf.getMin().toString().equals(gSwhf.getMin()) &&
							xSwhf.getMax().toString().equals(gSwhf.getMax())){
						wFound = true;
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getMin().toString(), gSwhf.getMin(), "min");
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getMax().toString(), gSwhf.getMax(), "max");
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getStandardFeePerPound(), gSwhf.getStandardFeePerPound(), "stdFeePerPound");
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getExpeditedFeePerPound(), gSwhf.getExpeditedFeePerPound(), "expFeePerPound");
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getPremiumFeePerPound(), gSwhf.getPremiumFeePerPound(), "premFeePerPound");
						CompareValuesUtility.verifyNullOrEqual("FBS-WgtHndlgFee", xSwhf.getLtlFeePerPound(), gSwhf.getLtlFeePerPound(), "ltlFeePerPound");
						break;
					}
				}
				if(!wFound){
					CompareValuesUtility.compareValues("FBS-WgtHndlgFee", xSwhf.getMin().toString(), "Not found", "min");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		verifyShcWrhs(xmlFbs.getShcWarehouses().getShcWarehouse(), gbFbs.getWareHouseLocations());
		
	}

	private void verifyShcWrhs(ShcWarehouse[] shcWarehouse, List<WareHouseLocation_> wareHouseLocations) {
		for(ShcWarehouse xWrhs : shcWarehouse){
			Boolean wFound = false;
			for(WareHouseLocation_ gWrhs : wareHouseLocations){
				if(xWrhs.getShcWarehouseId().equals(gWrhs.getLocationId())){
					wFound = true;
					CompareValuesUtility.compareValues("FBS-ShcWrhs", xWrhs.getShcWarehouseId(), gWrhs.getLocationId(), "locationId");
					CompareValuesUtility.compareValues("FBS-ShcWrhs", xWrhs.getName(), gWrhs.getName(), "name");
					break;
				}
			}
			if(!wFound){
				CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getShcWarehouseId(), "Not found", "locationId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFbm(Fbm xmlFbm, com.generated.vos.seller.Fbm gbFbm) {
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getFbmsElementsGroup().getServiceHours(), gbFbm.getServiceHours(), "serviceHours");
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getFbmsElementsGroup().getEdiRouteCode(), gbFbm.getEdiRouteCode(), "ediRouteCode");
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getFbmsElementsGroup().getOpenOrderThreshold(), gbFbm.getOpenOrderThreshold()==null?null:gbFbm.getOpenOrderThreshold().intValue(), "openOrderThreshold");
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getFbmsElementsGroup().getSywMaxEligibility(), gbFbm.getSywMaxEligibility(), "sywMaxEligibility");
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getFbmsElementsGroup().getDunsNumber(), gbFbm.getDunsNumber(), "dunsNumber");
		CompareValuesUtility.compareValues("FBM", xmlFbm.getTrustedSeller(), gbFbm.getTrustedSeller(), "trustedSeller");
		CompareValuesUtility.compareValues("FBM", xmlFbm.getGoferL3Seller(), gbFbm.getGoferL3Seller()==null?false:gbFbm.getGoferL3Seller(), "goferL3Seller");
		CompareValuesUtility.verifyNullOrEqual("FBM", xmlFbm.getReturnPolicy(), gbFbm.getReturnPolicy(), "returnPolicy");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getLine1(), gbFbm.getReturnAddress().getLine1(), "line1");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getLine2(), gbFbm.getReturnAddress().getLine2(), "line2");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getCity(), gbFbm.getReturnAddress().getCity(), "city");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getState(), gbFbm.getReturnAddress().getState(), "state");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getZipCode(), gbFbm.getReturnAddress().getZipCode(), "zipCode");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getCountry(), gbFbm.getReturnAddress().getCountry(), "country");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getCoordinates()==null?null:xmlFbm.getReturnAddress().getCoordinates().getLatitudeDegrees(), 
				gbFbm.getReturnAddress().getCoordinates()==null?null:gbFbm.getReturnAddress().getCoordinates().getLatitudeDegrees(), "latitudeDegrees");
		CompareValuesUtility.verifyNullOrEqual("FBM-ReturnAddr", xmlFbm.getReturnAddress().getCoordinates()==null?null:xmlFbm.getReturnAddress().getCoordinates().getLongitudeDegrees(), 
				gbFbm.getReturnAddress().getCoordinates()==null?null:gbFbm.getReturnAddress().getCoordinates().getLongitudeDegrees(), "longitudeDegrees");
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlFbm.getSellerWarehouses()!=null){
			verifyFbmSellerWrhs(xmlFbm.getSellerWarehouses().getSellerWarehouse(), gbFbm.getWareHouseLocations());
		}
		
		if(xmlFbm.getLocalMarketplace()!=null){
			verifyFbmLmp(xmlFbm.getLocalMarketplace(), gbFbm.getLocalMarketPlace());
		}
		
		/*Ship Methods*/
		CompareValuesUtility.compareValues("FBM-ShipMthd", xmlFbm.getShippingRates().getShipMode().getMode(), gbFbm.getShippingRates().getShipMode(), "mode");
		
		if(xmlFbm.getShippingRates().getShipMode().getShipMethods()!=null){		
			ShipMethods xmlShpMthd = xmlFbm.getShippingRates().getShipMode().getShipMethods();
			com.generated.vos.seller.ShipMethods gbShpMthd = gbFbm.getShippingRates().getShipMethods();
			CompareValuesUtility.verifyNullOrEqual("FBM-ShipMthd", xmlShpMthd.getGround()==null?false:xmlShpMthd.getGround(), gbShpMthd.getGround(), "ground");
			CompareValuesUtility.verifyNullOrEqual("FBM-ShipMthd", xmlShpMthd.getExpedited()==null?false:xmlShpMthd.getExpedited(), gbShpMthd.getExpedited(), "expedited");
			CompareValuesUtility.verifyNullOrEqual("FBM-ShipMthd", xmlShpMthd.getPremium()==null?false:xmlShpMthd.getPremium(), gbShpMthd.getPremium(), "premium");
		}
		if(xmlFbm.getShippingRates().getShipMode().getOptInRestrictShipLocs()!=null){		
			OptInRestrictShipLocs xmlOptIn = xmlFbm.getShippingRates().getShipMode().getOptInRestrictShipLocs();
			com.generated.vos.seller.OptInRestrictShipLocs gbOptIn = gbFbm.getShippingRates().getOptInRestrictShipLocs();
			CompareValuesUtility.verifyNullOrEqual("FBM-ShipMthd", xmlOptIn.getAlaska()==null?false:xmlOptIn.getAlaska(), gbOptIn.getAlaska(), "alaska");
			CompareValuesUtility.verifyNullOrEqual("FBM-ShipMthd", xmlOptIn.getHawaii()==null?false:xmlOptIn.getHawaii(), gbOptIn.getHawaii(), "hawaii");
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlFbm.getShippingRates().getShippingCharges()!=null){
			verifyFbmShipCharge(xmlFbm.getShippingRates().getShippingCharges(), gbFbm.getShippingRates().getShippingCharges());
		}
		
		if(xmlFbm.getShipToStore()!=null){
			/*CompareValuesUtility.verifyNullOrEqual("FBM-STS", xmlFbm.getShipToStore().getSellerEligibility(), gbFbm.(), "sellerEligibility");
			
			
			CompareValuesUtility.verifyNullOrEqual("FBM-STS", xmlFbm.getReturnAddress().getLine1(), gbFbm.getReturnAddress().getLine1(), "sellerEligibility");
		*/}
	}

	private void verifyFbmShipCharge(ShippingCharges xmlShpChrg, com.generated.vos.seller.ShippingCharges gbShpChrg) {
		
		for(ShippingChargeModelTypeChoiceItem xmlShpChrgTyp : xmlShpChrg.getShippingChargeModelTypeChoice().getShippingChargeModelTypeChoiceItem()){
			if(xmlShpChrgTyp.getOrderAmountBasedShippingCharges()!=null){
				for(OrderAmountChargeRange xOrdRng : xmlShpChrgTyp.getOrderAmountBasedShippingCharges().getOrderAmountChargeRange()){
					Boolean oFound = false;
					if(gbShpChrg.getOrderAmountBasedShippingCharges()!=null){
						for(com.generated.vos.seller.OrderAmountChargeRange gOrdRng : gbShpChrg.getOrderAmountBasedShippingCharges().getOrderAmountChargeRange()){
							if(xOrdRng.getMin().toString().equals(gOrdRng.getMin()) &&
									xOrdRng.getMax().toString().equals(gOrdRng.getMax())){
								oFound = true;
								CompareValuesUtility.compareValues("FBM-OrdShpChrg", xOrdRng.getMin(), gOrdRng.getMin(), "min");
								CompareValuesUtility.compareValues("FBM-OrdShpChrg", xOrdRng.getMax().toString(), gOrdRng.getMax(), "max");
								CompareValuesUtility.verifyNullOrEqual("FBM-OrdShpChrg", xOrdRng.getGround(), gOrdRng.getGround(), "ground");
								CompareValuesUtility.verifyNullOrEqual("FBM-OrdShpChrg", xOrdRng.getExpedited(), gOrdRng.getExpedited(), "expedited");
								CompareValuesUtility.verifyNullOrEqual("FBM-OrdShpChrg", xOrdRng.getPremium(), gOrdRng.getPremium(), "premium");
								break;
							}
						}
					}
					if(!oFound){
						CompareValuesUtility.compareValues("FBM-OrdShpChrg", xOrdRng.getMin().toString(), "Not found", "min");
					}
				}
				for(NonContinentalSurcharge xOrdNcs : xmlShpChrgTyp.getOrderAmountBasedShippingCharges().getNonContinentalSurcharge()){
					Boolean oFound = false;
					if(gbShpChrg.getOrderAmountBasedShippingCharges()!=null){
						for(NonContinentalSurcharge_ gOrdNcs : gbShpChrg.getOrderAmountBasedShippingCharges().getNonContinentalSurcharge()){
							if(xOrdNcs.getLocation().equals(gOrdNcs.getLocation())){
								oFound = true;
								CompareValuesUtility.compareValues("FBM-OrdShpChrg", xOrdNcs.getLocation(), gOrdNcs.getLocation(), "ncsLoc");
								CompareValuesUtility.verifyNullOrEqual("FBM-OrdShpChrg", xOrdNcs.getExpedited(), gOrdNcs.getExpedited(), "expedited");
								CompareValuesUtility.verifyNullOrEqual("FBM-OrdShpChrg", xOrdNcs.getPremium(), gOrdNcs.getPremium(), "premium");
								break;
							}
						}
					}
					if(!oFound){
						CompareValuesUtility.compareValues("FBM-OrdShpChrg", xOrdNcs.getLocation(), "Not found", "ncsLoc");
					}
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
	}

	private void verifyFbmLmp(LocalMarketplace xmlLmp, LocalMarketPlace gbLmp) {
		CompareValuesUtility.compareValues("FBM-PickupLoc", xmlLmp.getGoferL4Seller(), gbLmp.getGoferL4Seller(), "goferL4Seller");
		
		if(xmlLmp.getPickUpLocations()!=null){
			for(Location xPuLoc : xmlLmp.getPickUpLocations().getLocation()){
				Boolean pFound = false;
				for(PickUpLocation gPuLoc : gbLmp.getPickUpLocations()){
					if(xPuLoc.getLocationId().toString().equals(gPuLoc.getLocationId())){
						pFound = true;
						CompareValuesUtility.compareValues("FBM-PickupLoc", xPuLoc.getLocationId().toString(), gPuLoc.getLocationId(), "locationId");
						CompareValuesUtility.compareValues("FBM-PickupLoc", xPuLoc.getName(), gPuLoc.getName(), "name");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getEmail(), gPuLoc.getEmail(), "email");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getPhone(), gPuLoc.getPhone(), "phone");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAlternatePhone(), gPuLoc.getAlternatePhone(), "altPhone");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getFax(), gPuLoc.getFax(), "fax");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getSameDayFulfillmentCutoffTime(), gPuLoc.getSameDayFulfillmentCutoffTime(), "sameDayFulfillmentCutoffTime");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getOrderPrepTime(), gPuLoc.getOrderPrepTime(), "orderPrepTime");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getPickUpNowEligible(), gPuLoc.getPickUpNowEligible(), "pickUpNowEligible");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getSpecialInstructions(), gPuLoc.getSpecialInstructions(), "specialInstructions");
						
						/*Address*/
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getLine1(), gPuLoc.getAddress().getLine1(), "line1");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getLine2(), gPuLoc.getAddress().getLine2(), "line2");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getCity(), gPuLoc.getAddress().getCity(), "city");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getState(), gPuLoc.getAddress().getState(), "state");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getZipCode(), gPuLoc.getAddress().getZipCode(), "zipCode");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getCountry(), gPuLoc.getAddress().getCountry(), "country");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getCoordinates()==null?null:xPuLoc.getAddress().getCoordinates().getLatitudeDegrees(), 
								gPuLoc.getAddress().getCoordinates()==null?null:gPuLoc.getAddress().getCoordinates().getLatitudeDegrees(), "latitudeDegrees");
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getAddress().getCoordinates()==null?null:xPuLoc.getAddress().getCoordinates().getLongitudeDegrees(), 
								gPuLoc.getAddress().getCoordinates()==null?null:gPuLoc.getAddress().getCoordinates().getLongitudeDegrees(), "longitudeDegrees");
						
						/*Hours of operation*/
						CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getTimezone(), gPuLoc.getHoursOfOperation().getTimeZone(), "timeZone");
						if(xPuLoc.getHoursOfOperation().getSunday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getSunday().getStart(), gPuLoc.getHoursOfOperation().getSunday().getStart(), "sunStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getSunday().getDuration(), gPuLoc.getHoursOfOperation().getSunday().getDuration(), "sunDuration");
						}
						if(xPuLoc.getHoursOfOperation().getMonday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getMonday().getStart(), gPuLoc.getHoursOfOperation().getMonday().getStart(), "monStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getMonday().getDuration(), gPuLoc.getHoursOfOperation().getMonday().getDuration(), "monDuration");
						}
						if(xPuLoc.getHoursOfOperation().getTuesday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getTuesday().getStart(), gPuLoc.getHoursOfOperation().getTuesday().getStart(), "tuesStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getTuesday().getDuration(), gPuLoc.getHoursOfOperation().getTuesday().getDuration(), "tuesDuration");
						}
						if(xPuLoc.getHoursOfOperation().getWednesday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getWednesday().getStart(), gPuLoc.getHoursOfOperation().getWednesday().getStart(), "wedStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getWednesday().getDuration(), gPuLoc.getHoursOfOperation().getWednesday().getDuration(), "wedDuration");
						}
						if(xPuLoc.getHoursOfOperation().getThursday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getThursday().getStart(), gPuLoc.getHoursOfOperation().getThursday().getStart(), "thuStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getThursday().getDuration(), gPuLoc.getHoursOfOperation().getThursday().getDuration(), "thuDuration");
						}
						if(xPuLoc.getHoursOfOperation().getFriday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getFriday().getStart(), gPuLoc.getHoursOfOperation().getFriday().getStart(), "friStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getFriday().getDuration(), gPuLoc.getHoursOfOperation().getFriday().getDuration(), "friDuration");
						}
						if(xPuLoc.getHoursOfOperation().getSaturday()!=null){
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getSaturday().getStart(), gPuLoc.getHoursOfOperation().getSaturday().getStart(), "satStart");
							CompareValuesUtility.verifyNullOrEqual("FBM-PickupLoc", xPuLoc.getHoursOfOperation().getSaturday().getDuration(), gPuLoc.getHoursOfOperation().getSaturday().getDuration(), "satDuration");
						}
						break;
					}
				}
				if(!pFound){
					CompareValuesUtility.compareValues("FBM-PickupLoc", xPuLoc.getLocationId().toString(), "Not found", "locationId");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
	}

	private void verifyFbmSellerWrhs(SellerWarehouse[] sellerWarehouse, List<WareHouseLocation> wareHouseLocations) {
		for(SellerWarehouse xWrhs : sellerWarehouse){
			Boolean wFound = false;
			for(WareHouseLocation gWrhs : wareHouseLocations){
				if(xWrhs.getLocationId().toString().equals(gWrhs.getLocationId())){
					wFound = true;
					CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getLocationId().toString(), gWrhs.getLocationId(), "locationId");
					CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getName(), gWrhs.getName(), "name");
					CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getEmail(), gWrhs.getEmail(), "email");
					CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getPhone(), gWrhs.getPhone(), "phone");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAlternatePhone(), gWrhs.getAlternatePhone(), "altPhone");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getFax(), gWrhs.getFax(), "fax");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getStandardOrderProcessingTime().getRegular(), gWrhs.getSopt().getRegular(), "soptRegular");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getStandardOrderProcessingTime().getOversize(), gWrhs.getSopt().getOversize(), "soptOversize");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getLine1(), gWrhs.getAddress().getLine1(), "line1");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getLine2(), gWrhs.getAddress().getLine2(), "line2");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getCity(), gWrhs.getAddress().getCity(), "city");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getState(), gWrhs.getAddress().getState(), "state");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getZipCode(), gWrhs.getAddress().getZipCode(), "zipCode");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getCountry(), gWrhs.getAddress().getCountry(), "country");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getCoordinates()==null?null:xWrhs.getAddress().getCoordinates().getLatitudeDegrees(), 
							gWrhs.getAddress().getCoordinates()==null?null:gWrhs.getAddress().getCoordinates().getLatitudeDegrees(), "latitudeDegrees");
					CompareValuesUtility.verifyNullOrEqual("FBM-SellerWrhs", xWrhs.getAddress().getCoordinates()==null?null:xWrhs.getAddress().getCoordinates().getLongitudeDegrees(), 
							gWrhs.getAddress().getCoordinates()==null?null:gWrhs.getAddress().getCoordinates().getLongitudeDegrees(), "longitudeDegrees");
					break;
					
				}
			}
			if(!wFound){
				CompareValuesUtility.compareValues("FBM-SellerWrhs", xWrhs.getLocationId().toString(), "Not found", "locationId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyCpc(Cpc xmlCpc, com.generated.vos.seller.Cpc gbCpc) {
		CompareValuesUtility.verifyNullOrEqual("CPC", xmlCpc.getAggregatorId(), gbCpc.getAggregatorId(), "aggregatorId");
		CompareValuesUtility.verifyNullOrEqual("CPC", xmlCpc.getRating(), gbCpc.getRating()==null?null:gbCpc.getRating().intValue(), "rating");
		CompareValuesUtility.verifyNullOrEqual("CPC", xmlCpc.getNotes(), gbCpc.getNotes(), "notes");
		CompareValuesUtility.verifyNullOrEqual("CPC", xmlCpc.getTaxStates(), gbCpc.getTaxStates(), "taxStates");
		CompareValuesUtility.verifyNullOrEqual("CPC", xmlCpc.getReturnPolicy(), gbCpc.getReturnPolicy(), "returnPolicy");
		
		if(xmlCpc.getCreditCards()!=null){
			for(String cc : xmlCpc.getCreditCards().getCc()){	
				CompareValuesUtility.verifyItemInList("CPC", cc, gbCpc.getCreditCards(), "creditCards");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

}
