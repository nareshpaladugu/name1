package com.shi.content.northstar.pages;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.AbstractBaseElement;
import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.CheckBox;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.TextField;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.common.CommonMethods;

public class SearchStorePage extends BasePage {
	
	//Locators

	TextField txtRegion = new TextField("frm-search:sel-region_input", "Region");
	TextField txtDistrict = new TextField("frm-search:sel-district_input", "District");
	TextField txtStore = new TextField("frm-search:sel-store_input", "Store");
	TextField txtZipCode = new TextField("frm-search:txt-zip", "ZipCode");
	TextField txtRgnDropdown =  new TextField("//div[@id='frm-search:sel-region_panel']//li","Searched regions dropdown");
	TextField txtDistDropdown =  new TextField("//div[@id='frm-search:sel-district_panel']//li","Searched district dropdown");
	TextField txtStoreDropdown =  new TextField("//div[@id='frm-search:sel-store_panel']//li","Searched Store dropdown");
	
	
	//After search
	
	Button btnEdit = new Button("//span[@class='ui-button-text ui-c'][contains(text(),'Edit')]", "Edit");
	Button btnCloseStore = new Button("//span[@class='ui-button-text ui-c'][contains(text(),'Close Store')]", "Close");
	Button btnNext = new Button("//span[@class='ui-paginator-next ui-state-default ui-corner-all']", "Next");
	Button btnNextDisabled = new Button("//span[@class='ui-paginator-next ui-state-default ui-corner-all ui-state-disabled']", "Next END");
	Button btnSearch = new Button("frm-search:btn-search", "Search");
	Button btnClear = new Button("frm-search:btn-reset", "Clear");
	
//	Table tableSearchedStores = new Table("//*[@id='frm-result:tbl-result']/div[3]/table/tbody/tr", "StoreDisplayTable");old
	Table tableSearchedStores = new Table("//tbody[@id='frm-result:tbl-result_data']/tr", "StoreDisplayTable");
	
	Link linkInvalidSearchMsg = new Link("//span[@class='ui-growl-title']", "InvalidSearchMsg");
	Link linkStoreId = new Link("//a[@class='ui-commandlink ui-widget'][contains(text(),'{0}')]","Store Id link");
	Link linkClosedStore= new Link("//button[@aria-disabled='false']/span[contains(text(),'Open Store')]","Closed Store");
	Link lnkStoreId=new Link("link='{0}'", "Store id link :");

	DriverLogger logger = new DriverLogger();
	
	public SearchStorePage() {
		super("Search Store Page");
	}
	
	/**
	 * Get all the data in WebElement Table format displayed on (single/ multiple) search page/s
	 *@return table of webElements
	 *
	 */
	public ArrayList<ArrayList<WebElement>> getSearchResults() {
		boolean flag;
		ArrayList<ArrayList<WebElement>> searchedResults = null;
		
		logger.log("Getting search results....", true);
		
		do {
			flag = false;
		
			searchedResults = tableSearchedStores.getTableElements();
				
			if (searchedResults.isEmpty() || invalidSearch()) {
				logger.log("Search result page is empty", true);
				return null;
			}

			if (btnNext.isElementPresent()) {
				btnNext.click();
				flag = true;
			}

			WaitUtils.waitBySleep();

		} while (flag);
		
		return searchedResults;

	}
	
	/**
	 * Get all the data in WebElement Table format displayed on (single/ multiple) search page/s
	 *@return table of webElements
	 *
	 */
	public ArrayList<ArrayList<WebElement>> getSearchResults_FirstPage() {
		
		ArrayList<ArrayList<WebElement>> searchedResults = null;
		
		logger.log("Getting search results from first page only....", true);
		
		searchedResults = tableSearchedStores.getTableElements();
				
			if (searchedResults.isEmpty() || invalidSearch()) {
				logger.log("Search result page is empty", true);
				return null;
			}

		return searchedResults;

	}

	/**
	 * Get All Sears storesId list where all stores are open and Non ICCE Stores
	 * @return storeId List
	 * 
	 */
	
	public ArrayList<String> getAllSearsOpenNonICEEStores() {
	
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table =getSearchResults();

		
		if(invalidSearch()){
			return null;
		}
		logger.log("Fetching Non ICCE Sears OpenStores... total stores found "+table.size(), false);
		for (int row_num = 0; row_num < table.size(); row_num++) {

			if (table.get(row_num).get(3).getText().equalsIgnoreCase("Sears")&& checkStoreOpen(table.get(row_num).get(8))
					&&(!checkIfICCEStore(table.get(row_num).get(1).getText()))) {
				
				storeList.add(table.get(row_num).get(1).getText());
			}
		}
		
		return storeList;

	}
	
	/**
	 * Get All Kmart storesId list where all stores are open 
	 * @return storeId List
	 * 
	 */
	
	public ArrayList<String> getAllKmartOpenStores() {
	
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table =getSearchResults_FirstPage();

		if(invalidSearch()){
			return null;
		}
		
		logger.log("Fetching Kmart OpenStores... ", false);
		for (int row_num = 0; row_num < table.size(); row_num++) {

			if (table.get(row_num).get(3).getText().equalsIgnoreCase("Kmart")&& checkStoreOpen(table.get(row_num).get(8))
					&&(!checkIfICCEStore(table.get(row_num).get(1).getText()))) {
				
				storeList.add(table.get(row_num).get(1).getText());

			}

		}
		
		return storeList;

	}
	
	/**
	 * Get All Sears storesId list where all stores are open and Non ICCE Stores // verification pending
	 * @return storeId List
	 * 
	 */
	
	public ArrayList<String> getAllPROpenNonICEEStores() {
	
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table =getSearchResults();

		if(invalidSearch()){
			return null;
		}
		
		logger.log("Fetching non ICCE PR OpenStores... ", false);
		for (int row_num = 0; row_num < table.size(); row_num++) {

			if (table.get(row_num).get(5).getText().equalsIgnoreCase("PUERTO RICO")&& checkStoreOpen(table.get(row_num).get(8))
					&&(!checkIfICCEStore(table.get(row_num).get(1).getText()))) {
				
				storeList.add(table.get(row_num).get(1).getText());

			}

		}
		
		return storeList;

	}

	/**
	 * Get All storesId list where all stores are open and Non ICCE Stores // verification pending
	 * @return storeId List
	 * 
	 */
	
	public ArrayList<String> getAllNonICCEOpenStores() {
	
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table =getSearchResults();

		if(invalidSearch()){
			return null;
		}
		
		logger.log("Fetching All ICCE OpenStores... ", false);
		
		for (int row_num = 0; row_num < table.size(); row_num++) {

			if (checkStoreOpen(table.get(row_num).get(8))
					&&(!checkIfICCEStore(table.get(row_num).get(1).getText()))) {
				
				storeList.add(table.get(row_num).get(1).getText());

			}

		}
		
		if(storeList.isEmpty())
		return null;
		else 
		return storeList;

	}
	
	/**
	 * Get All storesId list where all stores are open and ICCE Stores // verification pending
	 * @return storeId List
	 * 
	 */
	
	public ArrayList<String> getAllICCEOpenStores() {
	
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table =getSearchResults();

		if(invalidSearch()){
			return null;
		}
		
		logger.log("Fetching All ICCE OpenStores... ", false);
		
		for (int row_num = 0; row_num < table.size(); row_num++) {

			if (checkStoreOpen(table.get(row_num).get(8))
					&&(checkIfICCEStore(table.get(row_num).get(1).getText()))) {
				
				storeList.add(table.get(row_num).get(1).getText());

			}

		}
		
		return storeList;

	}
	
	/**
	 * Get list of all storesId displayed on the page whether they are open, close, sears, kmart, PR or ICCE
	 * @return storeId list
	 * 
	 */
	
	public ArrayList<String> getAllStoreIds() {
		
		ArrayList<String> storeList = new ArrayList<String>();
		
		ArrayList<ArrayList<WebElement>> table = getSearchResults();
	
		logger.log("Fetching only StoreIds from Search Result page... ", false);
		
			for (int row_num = 0; row_num < table.size(); row_num++) {
			
				storeList.add(table.get(row_num).get(1).getText());

			}

		return storeList;

	}
	
	/**
	 * Selects only all stores from all supplied stores list
	 *@param list of stores to select
	 *
	 */
	public void selectStore(String storeId) {
		
		logger.log("Selecting two stores from the supplied stores....", false);

		ArrayList<ArrayList<WebElement>> table = getSearchResults();
		
			for (int row = 0; row < table.size(); row++) {
				
				if (storeId.contains(table.get(row).get(1).getText())) {
					
					table.get(row).get(0).click();
					logger.log("Selected : "+table.get(row).get(1).getText(), false);
				}
			}
 
	}
	
	/**
	 * Selects only two stores from all supplied stores list
	 *@param list of stores to select
	 *
	 */
	public void selectStore(ArrayList<String> stores, int noOfStores) {
		
		logger.log("Selecting two stores from the supplied stores....", false);

		ArrayList<ArrayList<WebElement>> table = getSearchResults();
		
			for (int row = 0; row < table.size(); row++) {
				
				if (stores.contains(table.get(row).get(1).getText())) {
					if(noOfStores==0) break;
					table.get(row).get(0).click();
					logger.log("Selected : "+table.get(row).get(1).getText(), false);
					noOfStores--;
				}
			}
 
	}
	
	/**
	 * Checks open store button is enabled or not
	 * @param WebElement of which status to be checked
	 * @return true if store is open and returns false if store is closed
	 * 
	 */

	public boolean checkStoreOpen(WebElement tableCell) {
		
		return tableCell.findElement(By.tagName("button")).getAttribute("aria-disabled").equals("true");

	}
	
	/**
	 * Click on storeId
	 *@param storeId
	 *
	 */
	public void clickStore(String storeId){
		
//		logger.log("Selecting store........", false);
		
		WaitUtils.waitUntilElementIsVisible(tableSearchedStores);
		
		Link linkStore = (Link)linkStoreId.formatOption(storeId);

		linkStore.click(); 
		
		logger.log("Clicked : "+storeId, false);

	}
	
	/**
	 * Check if store is ICCE store
	 * @param store
	 * @return true if store is ICCE store
	 * 
	 */

	public boolean checkIfICCEStore(String store) {
		
		if (ICCEStores.allICCEStores.contains(store)) {
			return true;
			
		} else {
			
			return false;
			
		}

	}
	
	/**
	 * Clicks Edit button present on the Search  Store Page
	 *
	 */
	public void searchPageEdit() {

		logger.log("Click edit button on search page: ", false);

		btnEdit.click();
		
	}

	/**
	 * Clicks Close Store button present on the Search  Store Page
	 *
	 */
	public void searchPageCloseStore() {

		logger.log("Click close store button on search page : ", false);

		btnCloseStore.click();
		
	}
	

	/**
	 * Check if error msg 'Invalid Search Criterion' is displayed
	 * @return true if error mgs is displayed and there are no search results else returns true
	 *
	 */
	public boolean invalidSearch(){
		
		if(linkInvalidSearchMsg.isElementPresent()&& linkInvalidSearchMsg.getText().equalsIgnoreCase("Invalid Search Criterion")){
			
				logger.log("Invalid search criteria , error msg displayed",	true);

				return true;
		}else {
		
			return false;
		}
		
		
	}

	/**
	 * Method to search by Store number
	 * @param store number
	 * @return void
	 */

	public void searchByStoreNumber(String storeNumber) {
		
			logger.log("Searching by Store Number : "+ storeNumber, false);
			
			txtStore.sendKeys(storeNumber);
			
			WaitUtils.waitUntilElementIsVisible(txtStoreDropdown);
			if(txtStoreDropdown.isVisible()){
				logger.log("Clicking on searched option", true);
				txtStoreDropdown.click();
			}
//			WaitUtils.waitUntilElementIsVisible(btnSearch);
			WaitUtils.waitUntil(ExpectedConditions.presenceOfElementLocated(btnSearch.getByType()), "Search Button");
			logger.log("Clicking on search button ", true);
			btnSearch.click();
			btnSearch.click();
	}
	

	/**
	 * Method to search by region code
	 * @param region
	 */
	public void searchByRGN(String region) {
		
		logger.log("Searching by Region : "+ region, false);
		
		txtRegion.sendKeys(region);
		
		WaitUtils.waitUntilElementIsVisible(txtRgnDropdown);
		if(txtRgnDropdown.isVisible()){
			logger.log("Clicking on searched option", true);
			txtRgnDropdown.click();
		}
		WaitUtils.waitUntilElementIsVisible(btnSearch);
		logger.log("Clicking on search button ", true);
		btnSearch.click();

	}
	/**
	 * Method to search by region code
	 * @param district
	 */
	public void searchByDistrict(String district) {
		
		logger.log("Searching by District : "+ district, false);
		
		txtDistrict.sendKeys(district);
		WaitUtils.waitUntilElementIsVisible(txtDistDropdown);
		if(txtDistDropdown.isVisible()){
			logger.log("Clicking on searched option", true);
			txtDistDropdown.click();
		}
//		WaitUtils.waitUntilElementIsVisible(btnSearch);
		WaitUtils.waitUntil(ExpectedConditions.presenceOfElementLocated(btnSearch.getByType()), "Search Button");
		logger.log("Clicking on search button ", true);
		btnSearch.click();
		btnSearch.click();

	}


	/**
	 * Method to search by zip code
	 * @param zipcode
	 */
	public void searchByZipCode(String zipCd) {

		logger.log("Searching by zipcode : "+ zipCd, false);
		
		txtZipCode.sendKeys(zipCd);
		
		btnSearch.click();
		
	}
}