package com.shi.content.hierarchy.tests;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNotNull;

import java.util.List;

import com.generated.vos.hierarchy.Hierarchy;
import com.generated.xmls.storehierarchy.Level1;
import com.generated.xmls.storehierarchy.Level2;
import com.generated.xmls.storehierarchy.Level3;
import com.generated.xmls.storehierarchy.Level4;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class StoreHierarchyVerifications implements Runnable{
	
	List<Level1> wLevel1List;
	String sFileName;
	String storeAppender;
	String sSiteId;
	String sSiteName;
	//String sIDPath;
	//String sCurrentName;
	HierarchyCommons hierarchyUtils;
	//static final String SRWI = "SRWI";
	static final String SEPARATOR = "|";
	
	
	public StoreHierarchyVerifications(List<Level1> wLevel1List, HierarchyCommons commonUtils, String storeAppender, String sSiteId){
		this.wLevel1List = wLevel1List;
		this.hierarchyUtils = commonUtils;
		this.storeAppender = storeAppender;
		this.sSiteId = sSiteId;
	}
	
	@Override
	public void run() {
//		hierarchyUtils = new HierarchyCommons(sFileName);
		//For each node fetch from hierarchy collection
		if (sSiteId.equals("1"))
			sSiteName = "kmart";
		else if (sSiteId.equals("2"))
			sSiteName = "sears";
		else
			sSiteName = "null";
		
		for(Level1 n : wLevel1List){
			CompareValuesUtility.init();
			try{
				if(n.getId() == 0)
					continue;
				//HierarchySchema gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.STOREHIERARCHY, String.valueOf(n.getId()));
				APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.STORE_HIERARCHY, String.valueOf(n.getId()));
				Hierarchy gbHierarchy = allResponse.getT();
				
				System.out.println("Validating level 1 id=" + n.getId());
				verifyLevel(n, gbHierarchy, allResponse);
				CompareValuesUtility.setupResult(String.valueOf(n.getId()), true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ n.getId());
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}	
	}
	
	public void verifyLevel(Level1 xmlNode, Hierarchy gbHierarchy, APIResponse<Hierarchy> allResponse){
		//System.out.println("In verifyNode");
		compareValues("Id", xmlNode.getId(), gbHierarchy.getId());
		String sLevel1Name = xmlNode.getImaId()+storeAppender;
		//String sCurrentName = sLevel1Name;
		String sLevel1IdPath = String.valueOf(xmlNode.getId());
		String sCID = hierarchyUtils.fetchCatGroupId(sLevel1Name);
		//compareValues("CId", sCID, gbHierarchy.getCid()); //WCS-Migration
		verifyNotNull("CId", gbHierarchy.getCid());
		compareValues("Site", sSiteName , gbHierarchy.getSite());
		compareValues("Name", sLevel1Name, gbHierarchy.getName());
		compareValues("Type", "store", gbHierarchy.getType());
		compareValues("isLeafNode",false, gbHierarchy.getIsLeaf());
		compareValues("level","1", gbHierarchy.getLevel());
		//CompareValuesUtility.verifyNullOrEqual("ParentId",null, gbHierarchy.getParentIds().get(0).getId());
		CompareValuesUtility.verifyNullOrEqual("ParentId",null, null);
		compareValues("DisplayPath",xmlNode.getDisplayPath(), gbHierarchy.getPath().get(0).getDisplayPath());
		compareValues("IdPath",sLevel1IdPath, gbHierarchy.getPath().get(0).getIdPath());
		//compareValues("CIdPath",sCID, gbHierarchy.getPath().get(0).getCidPath()); //WCS-Migration
		verifyNotNull("CIdPath", gbHierarchy.getPath().get(0).getCidPath());
		verifySearch(allResponse, sCID);
		verifyFt(allResponse, false, "1");
		verifyLevel2Nodes(xmlNode.getLevel2(), xmlNode, sCID, sLevel1Name, sLevel1IdPath);
	}

	private void verifyLevel2Nodes(Level2[] level2List, Level1 xmlNode, String sCID, String sLevel1Name, String sLevel1IdPath) {
		
		for(Level2 xmlLevel2 : level2List){
			//HierarchySchema gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.STOREHIERARCHY, String.valueOf(xmlLevel2.getId()));
			APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.STORE_HIERARCHY, String.valueOf(xmlLevel2.getId()));
			Hierarchy gbHierarchy = allResponse.getT();
			verifyLevel2(xmlLevel2, gbHierarchy, xmlNode, sCID, sLevel1Name, sLevel1IdPath, allResponse);
		}
		
	}
	
	private void verifyLevel2(Level2 level2Node,Hierarchy gbHierarchy, Level1 l1Node, String sParentCIDPath, String sLevel1Name, String sLevel1IdPath, APIResponse<Hierarchy> allResponse){
		compareValues("Id", level2Node.getId(), gbHierarchy.getId());
		String sLevel2Name =  generateName(sLevel1Name, level2Node.getImaId());
		String sCID = hierarchyUtils.fetchCatGroupId(sLevel2Name);
		String sLevel2IdPath = sLevel1IdPath+SEPARATOR+String.valueOf(level2Node.getId());
		String sCIDPath = sParentCIDPath+SEPARATOR+sCID;
		//compareValues("CId", sCID, gbHierarchy.getCid()); //WCS-Migration
		verifyNotNull("CId", gbHierarchy.getCid());
		compareValues("Site", sSiteName , gbHierarchy.getSite());
		compareValues("Name", sLevel2Name, gbHierarchy.getName());
		compareValues("Type", "store", gbHierarchy.getType());
		compareValues("isLeafNode",false, gbHierarchy.getIsLeaf());
		compareValues("level","2", gbHierarchy.getLevel());
		
		//Parent is id of level1
		compareValues("ParentId",l1Node.getId(), gbHierarchy.getParentIds().get(0).getId());
		compareValues("DisplayPath",level2Node.getDisplayPath(), gbHierarchy.getPath().get(0).getDisplayPath());
		compareValues("IdPath",sLevel2IdPath, gbHierarchy.getPath().get(0).getIdPath());
		//compareValues("CIdPath",sCIDPath, gbHierarchy.getPath().get(0).getCidPath()); //WCS-Migration
		verifyNotNull("CIdPath", gbHierarchy.getPath().get(0).getCidPath());
		verifySearch(allResponse, sCID);
		verifyFt(allResponse, false, "2");
		verifyLevel3Nodes(level2Node.getLevel3(), level2Node, sCIDPath, sLevel2Name, sLevel2IdPath);
	}
	
	private void verifyLevel3Nodes(Level3[] level3List, Level2 xmlNode, String sCID, String sLevel2Name, String sLevel2IdPath) {
		
		for(Level3 xmlLevel3 : level3List){
			//HierarchySchema gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.STOREHIERARCHY, String.valueOf(xmlLevel3.getId()));
			APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.STORE_HIERARCHY, String.valueOf(xmlLevel3.getId()));
			Hierarchy gbHierarchy = allResponse.getT();
			verifyLevel3(xmlLevel3, gbHierarchy, xmlNode, sCID, sLevel2Name, sLevel2IdPath, allResponse);
		}
		
	}
	
	private void verifyLevel3(Level3 level3Node,Hierarchy gbHierarchy, Level2 l2Node, String sParentCIDPath, String sLevel2Name, String sLevel2IdPath, APIResponse<Hierarchy> allResponse){
		compareValues("Id", level3Node.getId(), gbHierarchy.getId());
		String sLevel3Name =  generateName(sLevel2Name, level3Node.getImaId());
		String sCID = hierarchyUtils.fetchCatGroupId(sLevel3Name);
		String sCIDPath = sParentCIDPath+SEPARATOR+sCID;
		String sLevel3IdPath = sLevel2IdPath+SEPARATOR+String.valueOf(level3Node.getId());
		
		//compareValues("CId", sCID, gbHierarchy.getCid()); //WCS-Migration
		verifyNotNull("CId", gbHierarchy.getCid());
		compareValues("Site", sSiteName , gbHierarchy.getSite());
		compareValues("Name", sLevel3Name, gbHierarchy.getName());
		compareValues("Type", "store", gbHierarchy.getType());
		compareValues("isLeafNode",false, gbHierarchy.getIsLeaf());
		compareValues("level","3", gbHierarchy.getLevel());
		
		//Parent is id of level2
		compareValues("ParentId",l2Node.getId(), gbHierarchy.getParentIds().get(0).getId());
		
		compareValues("DisplayPath",level3Node.getDisplayPath(), gbHierarchy.getPath().get(0).getDisplayPath());
		compareValues("IdPath",sLevel3IdPath, gbHierarchy.getPath().get(0).getIdPath());
		//compareValues("CIdPath",sCIDPath, gbHierarchy.getPath().get(0).getCidPath()); //WCS-Migration
		verifyNotNull("CIdPath", gbHierarchy.getPath().get(0).getCidPath());
		verifySearch(allResponse, sCID);
		verifyFt(allResponse, false, "3");
		verifyLevel4Nodes(level3Node.getLevel4(), level3Node, sCIDPath, sLevel3Name, sLevel3IdPath);
	}
	
	private void verifyLevel4Nodes(Level4[] level4List, Level3 xmlNode, String sCID, String sLevel3Name, String sLevel3IdPath) {
		
		for(Level4 xmlLevel4 : level4List){
			//HierarchySchema gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.STOREHIERARCHY, String.valueOf(xmlLevel4.getId()));
			APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.STORE_HIERARCHY, String.valueOf(xmlLevel4.getId()));
			Hierarchy gbHierarchy = allResponse.getT();
			verifyLevel4(xmlLevel4, gbHierarchy, xmlNode, sCID, sLevel3Name, sLevel3IdPath, allResponse);
		}
		
	}
	
	private void verifyLevel4(Level4 level4Node,Hierarchy gbHierarchy, Level3 l3Node, String sParentCIDPath, String sLevel3Name, String sLevel3IdPath, APIResponse<Hierarchy> allResponse){
		compareValues("Id", level4Node.getId(), gbHierarchy.getId());
		String sLevel4Name =  generateName(sLevel3Name, level4Node.getImaId());
		String sCID = hierarchyUtils.fetchCatGroupId(sLevel4Name);
		String sCIDPath = sParentCIDPath+SEPARATOR+sCID;
		String sLevel4IdPath = sLevel3IdPath+SEPARATOR+String.valueOf(level4Node.getId());
		//compareValues("CId", sCID, gbHierarchy.getCid()); //WCS-Migration
		verifyNotNull("CId", gbHierarchy.getCid());
		compareValues("Site", sSiteName , gbHierarchy.getSite());
		compareValues("Name", sLevel4Name, gbHierarchy.getName());
		compareValues("Type", "store", gbHierarchy.getType());
		compareValues("isLeafNode",true, gbHierarchy.getIsLeaf());
		compareValues("level","4", gbHierarchy.getLevel());
		
		//Parent is id of level3
		compareValues("ParentId",l3Node.getId(), gbHierarchy.getParentIds().get(0).getId());
		
		compareValues("DisplayPath",level4Node.getDisplayPath(), gbHierarchy.getPath().get(0).getDisplayPath());
		compareValues("IdPath",sLevel4IdPath, gbHierarchy.getPath().get(0).getIdPath());
		//compareValues("CIdPath",sCIDPath, gbHierarchy.getPath().get(0).getCidPath()); //WCS-Migration
		verifyNotNull("CIdPath", gbHierarchy.getPath().get(0).getCidPath());
		verifySearch(allResponse, sCID);
		verifyFt(allResponse, true, "4");
	}
	
	/**
	 * Add current id in between SRWI and parent
	 * @param sName
	 * @return
	 */
	private String generateName(String sParentName, String sCurrentId){
		String sChildName = sParentName.split(storeAppender)[0];
		sChildName =  sChildName+"-"+sCurrentId+storeAppender;
		return sChildName;
	}
	
	private void verifySearch(APIResponse<Hierarchy> allResponse, String sCid) {
		//CompareValuesUtility.addNewMultiValuedFields();
		//compareValues("_search.cid", sCid, allResponse.getSearchFieldValue("cid"));
		verifyNotNull("_search.cid", allResponse.getSearchFieldValue("cid"));
	}
	public void verifyFt(APIResponse<Hierarchy> allResponse, boolean sIsLeaf, String sLevel){
		//CompareValuesUtility.addNewMultiValuedFields();
		compareValues("_ft.leaf", sIsLeaf, allResponse.getFtFieldValue("leaf"));
		compareValues("_ft.level", sLevel, allResponse.getFtFieldValue("level"));
		compareValues("_ft.site", sSiteName, allResponse.getFtFieldValue("site"));
	}
	
}
 
