package com.shi.content.acme.publish;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

/**
 * Temporary utility to read from reconciled db and push to content kafka queue
 * Uses testdatalimit property to push number of records
 * @author Niharika Varshney
 *
 */
public class AcmePublishMessages implements Runnable{
	List<String> lstOfIds;
	
	public AcmePublishMessages(){
		
	}
	
	public AcmePublishMessages(List<String> ids){
		this.lstOfIds = ids;
	}
	
	@Test(groups="publishAcmeMatchData")
	public void publish(){
		
		String ids=System.getProperty("ids", "");
		
		String url;
		
		for(String id : ids.split(",")){
			url = "http://"+LoadProperties.IA_SERVER+"/acme/publisher/idpublish/"+id+"?publish=true";
			
			URI uri;
			try {
				uri = new URI(url);
			
				System.out.println(RestExecutor.getJSonResponse(uri));
				System.out.println("Successfully pushed "+ url);
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
		}
	}
	
	@Test(groups="fetchAndPublishAcmeMatchData")
	public void fetchAndpublish(){
		List<String> fetchedReconciledIds = new ArrayList<String>();
		
		if(!LoadProperties.RUN_PARAMS.isEmpty() && (LoadProperties.RUN_PARAMS.contains("vendor") || LoadProperties.RUN_PARAMS.contains("item"))){
			fetchedReconciledIds = fetch(LoadProperties.TESTDATALIMIT, true);
			System.out.println("Size" +fetchedReconciledIds.size());
		}else{
			fetchedReconciledIds = fetch(LoadProperties.TESTDATALIMIT, false);
		}
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		
		List<List<String>> listofReconciledIds = Lists.partition(fetchedReconciledIds, 10);
		for(List<String> ids : listofReconciledIds){
			
			pool.execute(new AcmePublishMessages(ids));

		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}	
	
	public List<String> fetch(int iMsgsToPublish, boolean source){
		
		String sURL = null;
		String sParamURL = null;
		int maxPageSize  = 100;
		
		if(iMsgsToPublish!= -1 && iMsgsToPublish < maxPageSize)
			maxPageSize = iMsgsToPublish;
		
		int pageNumber = System.getProperty("initPageNum") == null?0: Integer.parseInt(System.getProperty("initPageNum"));
		if(!source){
			pageNumber = Integer.parseInt(LoadProperties.RUN_PARAMS);
		}
		else{
			sParamURL = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
			if(sParamURL == null)
				System.out.println("Incorrect params");
		}
		
		
		
		List<String> lstReconciledIds = new ArrayList<String>();
		while(true)
		{
			String guids ;
			String ids;
			int itemsFoundSize = 0;
			if(!source){
				sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source?page-size="+maxPageSize+"&page="+pageNumber;
			}else{
				sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source"+sParamURL+"&page-size="+maxPageSize+"&page="+pageNumber;
			}
			System.out.println("sUrl.... "+sURL);
	
			String jsonResponse = RestExecutor.getJSonResponse(sURL);
			
			
			if(source){
				guids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				ids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				if(ids == null || ids.isEmpty())
					break;
				itemsFoundSize = ids.split(",").length;
				
			}else{
				guids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
				if(guids==null || guids.isEmpty())
				{
				// Break when there is no more data
					break;
				}
			}
			String[] spGuids = guids.split(",");
			
			//Taking out unique ids only
			Set<String> setOfGUIDs = new HashSet<String>(Arrays.asList(spGuids));
			lstReconciledIds.addAll(setOfGUIDs);
			
			//Change last page size to less if required number of messages are less
			if(iMsgsToPublish != -1 && (iMsgsToPublish - lstReconciledIds.size()) < maxPageSize)
				maxPageSize = iMsgsToPublish - lstReconciledIds.size();
			
			if(source && itemsFoundSize < maxPageSize){
				System.out.println(" ========= No Need to hit page-size url again(res in last request was less than max page size) =========");
				break;
			}
			
			if(!source && spGuids.length<maxPageSize)
			{
				System.out.println(" ========= No Need to hit page-size url again(res in last request was less than max page size) =========");
				break;
			}
			
			if (iMsgsToPublish != -1 &&  iMsgsToPublish <= lstReconciledIds.size()){
				System.out.println(" ========= Required ids found  =========");
				break;
			}
			
			pageNumber++;		
			
		}
			Set<String> finalList = new HashSet<String>(lstReconciledIds);
			lstReconciledIds = new ArrayList<String>(finalList);
			return lstReconciledIds;
	}

	@Override
	public void run() {
		
		for(String id : lstOfIds)
			System.out.println(RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/publisher/idpublish/"+id+"?publish=true"));
		
	}

}
