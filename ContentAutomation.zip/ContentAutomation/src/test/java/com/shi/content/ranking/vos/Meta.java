package com.shi.content.ranking.vos;

public class Meta {
	
	private String metaTypePrice;

	public String getMetaTypePrice() {
		return metaTypePrice;
	}

	public void setMetaTypePrice(String metaTypePrice) {
		this.metaTypePrice = metaTypePrice;
	}






}
