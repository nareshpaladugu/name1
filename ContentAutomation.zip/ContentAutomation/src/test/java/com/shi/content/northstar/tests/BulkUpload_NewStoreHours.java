package com.shi.content.northstar.tests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shi.content.northstar.pages.BulkUploadPage;
import com.shi.content.northstar.pages.BulkUploadPage.BulkUploadType;
import com.shi.content.northstar.pages.LinkPanel;

/**
 * Test to verify Bulk Upload Feature for New Store Hours Option
 * @author vshar10
 */
public class BulkUpload_NewStoreHours extends NorthStarBaseTest {
	DriverLogger logger = new DriverLogger();
	HashMap<String, HashMap<String, Object>> storeDataMap = null;

	@Test(description="Test To Verify Bulk Upload Feature For New Store Hours Option", groups = {"NS-P1"})
	public void testBulkUploadForHolidayHours() {
		LinkPanel menuLinks = new LinkPanel();
		menuLinks.goToBulkUpload();
		BulkUploadPage bulkUploadPage = new BulkUploadPage();
		bulkUploadPage.selectBulkUploadType(BulkUploadType.NEW_STORE_HOURS);
		String filePath = generateInputFile();	// Get input file
		bulkUploadPage.uploadFile(filePath);	// Upload input file
		Asserts.assertTrue(bulkUploadPage.messageLabel.containsText("File upload succesful"), "File upload succesful");
		bulkUploadPage.publishData();
		Asserts.assertTrue(bulkUploadPage.messageLabel.containsText("New store hours are succesfully published to Database"), "New store hours are succesfully published to Database");
		verifyUploadedDataMatchWithDB();	// Verify data is updated in DB
	}

	/**
	 * Method to fetch stores data from DB & generate input file
	 * @return
	 */
	private String generateInputFile() {
		String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\BulkUploadInputFiles\\NewStoreHours_Inputs.xlsx";
		try {
			getStoreData();	// Get stores from DB

			FileOutputStream fos = new FileOutputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook();
			workbook.createSheet();
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Create Header
			XSSFRow row = sheet.createRow(0);
			row.createCell(0).setCellValue("Store");
			row.createCell(1).setCellValue("Store Type");
			row.createCell(2).setCellValue("StdTmZn");
			row.createCell(3).setCellValue("DaySav");
			row.createCell(4).setCellValue("DayFL");
			row.createCell(5).setCellValue("StdOffset");
			row.createCell(6).setCellValue("DstdOffset");
			row.createCell(7).setCellValue("MOpen");
			row.createCell(8).setCellValue("MClose");
			row.createCell(9).setCellValue("TOpen");
			row.createCell(10).setCellValue("TClose");
			row.createCell(11).setCellValue("WOpen");
			row.createCell(12).setCellValue("WClose");
			row.createCell(13).setCellValue("ThOpen");
			row.createCell(14).setCellValue("ThClose");
			row.createCell(15).setCellValue("FOpen");
			row.createCell(16).setCellValue("FClose");
			row.createCell(17).setCellValue("SatOpen");
			row.createCell(18).setCellValue("SatClose");
			row.createCell(19).setCellValue("SunOpen");
			row.createCell(20).setCellValue("SunClose");

			int rowNo=1, cellNo=0;
			XSSFCell cell;

			// Write Store Data
			XSSFCellStyle style = workbook.createCellStyle();
			style.setDataFormat(workbook.createDataFormat().getFormat("0"));
			
			for(String storeId: storeDataMap.keySet()) {
				row = sheet.createRow(rowNo);
				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("Store").toString());

				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("Store Type").toString());

				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("StdTmZn").toString());

				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("DaySav").toString());

				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("DayFL").toString());

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) storeDataMap.get(storeId).get("StdOffset"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) storeDataMap.get(storeId).get("DstdOffset"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("mon")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("mon")).get("closeTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("tue")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("tue")).get("closeTime"));

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("wed")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("wed")).get("closeTime"));

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("thu")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("thu")).get("closeTime"));

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("fri")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("fri")).get("closeTime"));

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("sat")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("sat")).get("closeTime"));

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("sun")).get("openTime"));
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) ((HashMap)storeDataMap.get(storeId).get("sun")).get("closeTime"));

				rowNo++;
				cellNo=0;
			}
			workbook.write(fos);
			fos.flush();
			fos.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return filePath;
	}

	/**
	 * Method to get required Sears & Kmart stores data
	 */
	public void getStoreData() {
		storeDataMap = new HashMap<>();
		HashMap<String, Object> storeInfo = null;
		List<String> searsStoreIds = getRandomStoreIds(StoreType.SEARS, 5);
		List<String> kmartStoreIds = getRandomStoreIds(StoreType.KMART, 5);
		int n;
		String storeId;

		for (int i = 0, flag = 1; i < 5; i++) {
			storeInfo = new HashMap<>();
			if (flag == 1) {
				storeId = searsStoreIds.get(i).trim();
				storeInfo.put("Store", !storeId.startsWith("000")?storeId:storeId.substring(3));
				storeInfo.put("Store Type", "Sears");

				if (i == searsStoreIds.size()-1) {		// Change flag to add Kmart stores
					flag = 0;
					i = -1;
				}
			} else {
				storeId = kmartStoreIds.get(i).trim();
				storeInfo.put("Store", storeId);
				storeInfo.put("Store Type", "Kmart");
			}
			storeInfo.put("StdTmZn", "EST");
			storeInfo.put("DaySav", "EDT");
			storeInfo.put("DayFL", "Y");
			storeInfo.put("StdOffset", -8);
			storeInfo.put("DstdOffset", -4);
			
			HashMap<String, Integer> storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));	
			storeTimings.put("closeTime", n+12);
			storeInfo.put("mon", storeTimings); // Set store open/close time

			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));	
			storeTimings.put("closeTime", n+12);
			storeInfo.put("tue", storeTimings); 

			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));
			storeTimings.put("closeTime", n+12);
			storeInfo.put("wed", storeTimings); 

			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));
			storeTimings.put("closeTime", n+12);
			storeInfo.put("thu", storeTimings); 

			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));
			storeTimings.put("closeTime", n+12);
			storeInfo.put("fri", storeTimings); 
			
			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));
			storeTimings.put("closeTime", n+12);
			storeInfo.put("sat", storeTimings); 
			
			storeTimings = new HashMap<>();
			storeTimings.put("openTime", n=GenericUtil.getRandomNumberInRange(6, 11));
			storeTimings.put("closeTime", n+12);
			storeInfo.put("sun", storeTimings); 
			
			storeDataMap.put(storeId, storeInfo);	
		}
	}

	/**
	 * Method to validate Bulk Uploaded data matches with data in DB
	 */
	public void verifyUploadedDataMatchWithDB() {
		String days = "mon tue wed thu fri sat sun";
		
		for(String storeId: storeDataMap.keySet()) {
			logger.logPassed("Verifying store: "+storeId);
			HashMap<String, Object> storeData = storeDataMap.get(storeId);
			
			String jResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, storeId);
			String storeTimings = "";
			
			// Check timings for each day
			for (String day : storeData.keySet()) {
				if (days.contains(day)) {
					logger.logPassed("Day : "+day);
					storeTimings = JsonStringParser.getJsonValueNew(jResponse, "_blob.unit.strHrs."+day);
					JsonObject jObject = new JsonParser().parse(storeTimings).getAsJsonObject();
					Integer actOpnTime = Integer.parseInt(jObject.get("opn").toString());
					Integer actClsTime = Integer.parseInt(jObject.get("cls").toString());
					Integer expOpnTime = Integer.parseInt(((HashMap) storeData.get(day)).get("openTime").toString()) * 3600;
					Integer epxClsTime = Integer.parseInt(((HashMap) storeData.get(day)).get("closeTime").toString()) * 3600;
					Asserts.verifyTrue(actOpnTime.equals(expOpnTime), "Verified Open Time");
					Asserts.verifyTrue(actClsTime.equals(epxClsTime), "Verified Close Time");
				}
			}
		}
	}
}