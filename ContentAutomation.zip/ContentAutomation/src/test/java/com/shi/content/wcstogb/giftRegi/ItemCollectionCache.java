package com.shi.content.wcstogb.giftRegi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shc.autocontent.db.DBUtil;

public class ItemCollectionCache {

	public static Map<String,List<Map<String, String>>> mapGRGFTITM = new HashMap<String, List<Map<String,String>>>();

	public static Map<String,Map<String,Map<String, String>>> mapXGRGFTITM = new HashMap<String,Map<String,Map<String, String>>>();
	
	
	public static void clearMaps(String id)
	{
		mapGRGFTITM.remove(id);
		
		mapXGRGFTITM.remove(id);

	}
	
	public static void init(String strList)
	{
		initGRGFTITMTbl(strList);
		
		initXGRGFTITMtbl(strList);

	}
	
	public static void initGRGFTITMTbl(String strList)
	{
		String sQuery  = "select * from GRGFTITM where GIFTREGISTRY_ID in("+strList+") with ur";

		mapGRGFTITM.putAll(DBUtil.executeQuery(sQuery,"GIFTREGISTRY_ID"));

	}
	
	public static void initXGRGFTITMtbl(String strList)
	{
		String sQuery  = "select xi.*,i.giftregistry_id from XGRGFTITM xi, GRGFTITM i where i.giftitem_id =xi.giftitem_id and i.giftregistry_id in ("+strList+")  order by  i.giftregistry_id,xi.giftitem_id with ur";
	
		mapXGRGFTITM.putAll(DBUtil.executeQueryMultiPrimaryKey(sQuery,"GIFTREGISTRY_ID","GIFTITEM_ID"));
		
	}
	

}
