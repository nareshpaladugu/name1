package com.shi.content.bundles;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;

/**
 * @author mbashee
 * Created : 18 March 2015
 */

public class BundleTests {
	
	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp", groups="BundleTests")
	public void bundleTests(String sRunParam) {
		if (LoadProperties.IS_BUCKETBASED_RUN) {
			List<String> lstBundleIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "B");
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			for (String bundleId : lstBundleIds) {
				pool.execute(new BundleVerifications(bundleId));
			}

			pool.shutdown();

			try {
				pool.awaitTermination(40, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else if (LoadProperties.IS_LISTBASED_RUN) {
			new BundleVerifications(sRunParam).run();
		} else {
			System.out.println("Please set property executionMode");
		}
	}
}
