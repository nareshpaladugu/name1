package com.shi.content.batchrules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.commons.ConditionParser;
import com.shi.content.wcsmigration.commons.OfferEligibilityUtils;
import com.shi.content.wcsmigration.commons.vos.ConditionVO;
import com.shi.content.wcsmigration.commons.vos.EligibilityVo;
import com.shi.content.wcsmigration.commons.vos.RuleVO;
import com.shi.content.wcsmigration.tests.OfferEligibilityTest_Evaluate;

/**
 * @author ddaphal
 *
 */
public class OfferEligibilityTest_Evaluate_Verifications implements Runnable
{
	private String offerId;
	private String sOfferAttrsSchemaJson;

	public OfferEligibilityTest_Evaluate_Verifications(String offerId)
	{
		this.offerId=offerId;
	}

	public void run() 
	{
		/*if(!offerId.equals("00231812059") )
		{
			return;
		}*/
		String outputFieldPath = null;
		String outputFieldValueExpected = null;
		String outputFieldValueActual = null;
		List<String> conditionsSatisFied = new ArrayList<>();
		boolean bCurrentConditionResult=false;

		String tVal;
		Boolean conditionresult = null;

		CompareValuesUtility.init();

		String splittedSites[];

		// key 1 is field name , key 2 is rule name
		Map<String, Map<String, Boolean>> rulesSatisfiedFieldLevel = new HashMap<String, Map<String,Boolean>>();

		sOfferAttrsSchemaJson = RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER_ATTR_SCHEMA, offerId);

		boolean isBreakNeeded  = false, sywItmTyp=false;

		if(TestUtils.isEmptyJsonResponse(sOfferAttrsSchemaJson))
		{
			CompareValuesUtility.addFailedDataFieldForReport("offerattrs", "NOT FOUND");
		}
		else
		{
			String tmpA[];
			String id;
			String stmpVal;
			if(sOfferAttrsSchemaJson.startsWith("["))
			{
				sOfferAttrsSchemaJson=sOfferAttrsSchemaJson.substring(1,sOfferAttrsSchemaJson.length()-1);
			}

			if(TestUtils.isEmptyJsonResponse(sOfferAttrsSchemaJson))
			{
				CompareValuesUtility.addFailedDataFieldForReport("offerattrs", "NOT FOUND");
			}
			else
			{
				String sOutputField="";
				String collNField;
				System.out.println("Checking :  "+ offerId);

				CompareValuesUtility.addDataFieldForReport("meta.modifiedTs",
						clean(JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson, OfferEligibilityUtils.OfferAttrsPrefix+"meta.modifiedTs")));


				tVal = JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson, OfferEligibilityUtils.OfferAttrsPrefix+"oper.sywItmTyp",true);

				sywItmTyp = tVal!=null&&tVal.equals("SYW EXCLUSIVE")?true:false;

				List<String> sitesList = TestUtils.getSitesList(JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson, OfferEligibilityUtils.OfferAttrsPrefix+"desc.sites"));

				boolean dispEligCheck = false;

				Map<String,Boolean> siteLevelResultSingleField = new HashMap<String, Boolean>();
				/*---------------------------iterate over EACH SHEET-----------------------------------*/

				for (Iterator<EligibilityVo> iterator = OfferEligibilityTest_Evaluate.mappingDetails.iterator(); iterator.hasNext();) 
				{
					EligibilityVo  eligibilityVo = iterator.next();

					if(eligibilityVo.getTabName().equalsIgnoreCase("isDispElig"))
					{
						dispEligCheck = true;
					}
					rulesSatisfiedFieldLevel = new HashMap<String, Map<String, Boolean>>();

					if(!eligibilityVo.getRuleList().isEmpty())
					{
						/*-------------------------iterate over EACH RULE in single sheet(grouped by output field) ---------------------------*/

						Iterator<Entry<String, LinkedList<RuleVO>>> itr1 = eligibilityVo.getRuleList().entrySet().iterator();

						while(itr1.hasNext()) 
						{
							Entry<String, LinkedList<RuleVO>> entry = itr1.next();

							sOutputField = entry.getKey();

							//for each field = new map(site level)
							siteLevelResultSingleField = new HashMap<String, Boolean>();

							Map<String, Boolean> rulesSatisfiedSiteLevel = new HashMap<String, Boolean>();
							rulesSatisfiedFieldLevel.put(sOutputField, rulesSatisfiedSiteLevel);

							LinkedList<RuleVO> allRulesForSingleField = entry.getValue();

							/*-------------------------iterate over EACH RULE for single field ---------------------------*/

							isBreakNeeded  = false;

							for (RuleVO ruleVO : allRulesForSingleField) 
							{
								splittedSites = getSitesToTest(ruleVO.getSite()).split(",");

								//repeating for each site
								for ( String singleSite : splittedSites)
								{
									if(singleSite.isEmpty())
										continue;

									if(siteLevelResultSingleField.get(singleSite)!=null && siteLevelResultSingleField.get(singleSite))
									{
										continue;
									}

									if(rulesSatisfiedFieldLevel.get(sOutputField).get(singleSite)==null)
									{
										rulesSatisfiedFieldLevel.get(sOutputField).put(singleSite,false);
									}

									if(sitesList.contains(singleSite))
									{
										outputFieldPath = ruleVO.getOutputField();
										outputFieldPath = outputFieldPath.replaceAll("\\[SITE\\]",singleSite.toLowerCase());
										outputFieldPath = OfferEligibilityUtils.OfferAttrsPrefix + outputFieldPath;

										try {
											outputFieldValueActual = JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson,outputFieldPath);
										} catch (Exception e) {

											//System.out.println(" =========== Exception while fetching actual output value........");
											e.printStackTrace();
										}

										if(outputFieldValueActual!=null)
										{
											outputFieldValueActual=outputFieldValueActual.replaceAll("\"", "");
										}

										conditionresult = null; 

										/*----------------------------iterate over each condition in single rule----------------------------------*/

										conditionsSatisFied = new ArrayList<>();

										for (Iterator<String> iterator3 = ruleVO.getConditions().iterator(); iterator3.hasNext();) 
										{
											String conditionString =  iterator3.next();

											conditionString=conditionString.replaceAll("\\[SITE\\]",singleSite.toLowerCase());
											ConditionVO conditionVO =  ConditionParser.parseCondition(conditionString);

											if(conditionVO==null)
											{
												System.out.println(" ============> check this condition : "+conditionString);
												continue;
											}

											bCurrentConditionResult = OfferEligibilityHelper.evaluateConditon
													(
															clean(JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson, "_ft.pgrmType"))
															,singleSite,conditionVO,ruleVO.getDefaultValues(), 
															conditionsSatisFied,offerId,sOfferAttrsSchemaJson, sywItmTyp);
											try {
												if(conditionresult==null)
													conditionresult =  bCurrentConditionResult;
												else
													//Logical AND the result of each condition
													conditionresult = conditionresult && bCurrentConditionResult;
											} catch (Exception e) {

												e.printStackTrace();
												System.out.println(" ============> check this condition : "+conditionString);
												continue;

											}

											/*--------------------------- BREAK once we get first FALSE --------------------------*/

											if(!conditionresult)
											{
												// no need to check for another conditions
												break;
											}
										}

										if(ruleVO.getConditions().isEmpty())
										{
											if(OfferEligibilityTest_Evaluate.checkDefaultValues && !rulesSatisfiedFieldLevel.get(sOutputField).get(singleSite))
											{
												// no rule satisfied before for this field + site combo
												//System.out.println("Need to check default value for "+sOutputField +" for site " + singleSite);
												conditionresult=true;
											}
										}

										if(conditionresult!=null && conditionresult)
										{
											siteLevelResultSingleField.put(singleSite, true);

											CompareValuesUtility.addDataFieldForReport("site", singleSite);

											CompareValuesUtility.addDataFieldForReport("Rule-satisfied", "["+eligibilityVo.getTabName()+"] " + ruleVO.getRuleName());

											rulesSatisfiedFieldLevel.get(sOutputField).put(singleSite,true);
											//Condition satisfied

											/*-------- indicated all conditions for single rule satisfied, 
									  means this rule has been check irrespective of its expected and actual values comparison result  ---------*/

											ruleVO.setCheckedThisRule(true);

											outputFieldValueExpected = ruleVO.getOutputValue();

											if(outputFieldValueExpected.startsWith("@"))
											{
												//remove @
												outputFieldValueExpected = outputFieldValueExpected.replaceFirst("@", "");

												//seller.programs.vd.sopt.oversize@collection:seller#desc.ffmsrc

												if(outputFieldValueExpected.contains("@collection:"))
												{

													tmpA = outputFieldValueExpected.split("@collection:"); 
													//seller.programs.vd.sopt.oversize[0]      seller#desc.ffmsrc[1]

													collNField = tmpA[1];
													//seller#desc.ffmsrc[1]

													//desc.ffmsrc -->
													id = clean(JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson,OfferEligibilityUtils.OfferAttrsPrefix+collNField.split("#")[1]));

													// tmpA[0] = field
													outputFieldValueExpected = OfferEligibilityHelper.getValueFromCollection(singleSite, collNField.split("#")[0],id, tmpA[0] );

													outputFieldValueExpected = clean(outputFieldValueExpected);
												}

												else
												{
													/*--------------------If expected output value contains @, first extract expected value -----------------------*/

													try {
														outputFieldValueExpected=OfferEligibilityUtils.OfferAttrsPrefix+outputFieldValueExpected;
														outputFieldValueExpected = JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson,outputFieldValueExpected);
													} catch (Exception e) {
														System.out.println(" =========== Exception while fetching expected output value........");
														e.printStackTrace();
													}
												}

												if(outputFieldValueExpected!=null)
												{
													outputFieldValueExpected=outputFieldValueExpected.replaceAll("\"", "");
												}
											}

											//TODO generalize later
											if(outputFieldValueExpected.equalsIgnoreCase("<ENV>OUTPUT"))
											{
												outputFieldValueExpected = Env.OUTPUT;
											}

											outputFieldValueExpected=outputFieldValueExpected!=null?outputFieldValueExpected.trim():outputFieldValueExpected;

											outputFieldValueActual = outputFieldValueActual!=null?outputFieldValueActual.trim():outputFieldValueActual;

											if((outputFieldValueExpected==null || outputFieldValueExpected.equalsIgnoreCase("null"))  
													&& (outputFieldValueActual==null||outputFieldValueActual.equalsIgnoreCase("null")))
											{

												//both NULL
												CompareValuesUtility.logPassed("Output Field Value","null","null",outputFieldPath );
											}
											else
											{
												if(outputFieldValueExpected!=null && (outputFieldValueExpected.equalsIgnoreCase("false")
														||outputFieldValueExpected.equalsIgnoreCase("true")))
												{
													if(outputFieldValueExpected.equalsIgnoreCase("false"))
													{
														outputFieldValueActual=outputFieldValueActual!=null&&outputFieldValueActual.equals("null")?null:outputFieldValueActual;
														//for false case, null  is also equal to false 
														CompareValuesUtility.verifyNullOrFalse("Output Field Value",outputFieldValueExpected,outputFieldValueActual,outputFieldPath);
													}
													else
													{
														CompareValuesUtility.compareValuesIgnoreCase("Output Field Value",outputFieldValueExpected,outputFieldValueActual,outputFieldPath);
													}

												}
												else
												{
													CompareValuesUtility.compareValues("Output Field Value",outputFieldValueExpected,outputFieldValueActual, outputFieldPath );

												}
											}

											CompareValuesUtility.addDataFieldForReport(" Conditions Satified",getConditionStr(conditionsSatisFied));
											isBreakNeeded  = true;
											//break;


											if(dispEligCheck && outputFieldPath.contains("isDispElig") && (singleSite.equalsIgnoreCase("kmart")||singleSite.equalsIgnoreCase("sears")))
											{
												//for all sites sitesList should have same value

												//expected output value = outputFieldValueExpected

												//sitesList

												for (String sSite  : sitesList) {

													if((sSite.equalsIgnoreCase("kmart")||sSite.equalsIgnoreCase("sears")))
													{
														stmpVal= JsonStringParser.getJsonValueNew(sOfferAttrsSchemaJson,"_blob.offerattrs.oper.sites."+sSite+".isDispElig");

														CompareValuesUtility.compareValuesIgnoreCase("isDispElig-val-check",outputFieldValueExpected,stmpVal,sSite );
													}
												}
											}
										}

										/*if(isBreakNeeded)
											break; */
									} // End of IF offerAttrsSchema.getBlob().getOfferattrs().getDesc().getSites().contains(singleSite)
								}  // end of FOR - site level

								if(isBreakNeeded)
									break;
							}
						}
					}
				}
			}
		}

		CompareValuesUtility.setupResult(offerId,true);
	}


	public static String clean(String s)
	{
		if(s==null )
			return "null";

		s=s.replaceAll("\"","");
		return s;
	}

	private String getConditionStr(List<String> conditionsSatisFied)
	{
		String sCondStr = null;

		for (Iterator<String> iterator3 = conditionsSatisFied.iterator(); iterator3.hasNext();) 
		{
			String string = iterator3.next();
			if(sCondStr==null)
			{
				sCondStr  = string;
			}
			else
			{
				sCondStr = sCondStr+","+string;
			}
		}
		sCondStr=sCondStr==null?"":sCondStr;

		return sCondStr;
	}

	public static String getSitesToTest(String sSiteByUser)
	{
		String sOutput = "";

		if(sSiteByUser==null || sSiteByUser.isEmpty())
		{
			if(LoadProperties.SITE_NAME.equalsIgnoreCase("kmart"))
			{
				sOutput = "kmart,mygofer,puertorico";
			}

			if(LoadProperties.SITE_NAME.equalsIgnoreCase("sears"))
			{
				sOutput = "sears,mygofer,puertorico";
			}
		}
		else
		{
			String sp[] = sSiteByUser.split(",");

			for (String string : sp)
			{
				if(string.equals("mygofer") || string.equals("puertorico"))
				{
					sOutput=sOutput+","+string;
				}

				if(string.equals("kmart") && LoadProperties.SITE_NAME.equalsIgnoreCase("kmart"))
				{
					sOutput=sOutput+","+string;
				}

				if(string.equals("sears") && LoadProperties.SITE_NAME.equalsIgnoreCase("sears"))
				{
					sOutput=sOutput+","+string;
				}
			}
		}

		if(sOutput.startsWith(","))
		{
			sOutput=sOutput.replaceFirst(",","");
		}
		return sOutput.toLowerCase();
	}
}
