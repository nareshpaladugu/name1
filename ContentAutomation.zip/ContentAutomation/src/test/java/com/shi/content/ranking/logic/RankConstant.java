package com.shi.content.ranking.logic;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import com.shi.content.ranking.vos.SellerdtlsVO;

public class RankConstant {
	public static final BlockingQueue bucketQ= new LinkedBlockingQueue();
	public static final BlockingQueue itemQ= new LinkedBlockingQueue();
	public static final Map sellerMap=new ConcurrentHashMap<String, SellerdtlsVO>();
	public static final Map sellerMapNew=new ConcurrentHashMap<String, com.generated.vos.seller.Seller>();

}
