package com.shi.content.ranking.vos;

public class SellerdtlsVO {
	
	int soptDays;
	int regularSopt;
	int oversizeSopt;
	String store;
	String trustedSeller;
	String sellerTier;
	String sellerStoreUrl;

	public int getSoptDays() {
		return soptDays;
	}
	public void setSoptDays(int soptDays) {
		this.soptDays=soptDays;
	}
	public int getRegularSopt() {
		return regularSopt;
	}
	public void setRegularSopt(int regularSopt) {
		this.regularSopt = regularSopt;
	}
	public int getOversizeSopt() {
		return oversizeSopt;
	}
	public void setOversizeSopt(int oversizeSopt) {
		this.oversizeSopt = oversizeSopt;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store=store;
	}
	public String getTrustedSeller() {
		return trustedSeller;
	}
	public void setTrustedSeller(String trustedSeller) {
		this.trustedSeller = trustedSeller;
	}
	public String getSellerTier() {
		return sellerTier;
	}
	public void setSellerTier(String sellerTier) {
		this.sellerTier = sellerTier;
	}
	public String getSellerStoreUrl() {
		return sellerStoreUrl;
	}
	public void setSellerStoreUrl(String sellerStoreUrl) {
		this.sellerStoreUrl = sellerStoreUrl;
	}
}