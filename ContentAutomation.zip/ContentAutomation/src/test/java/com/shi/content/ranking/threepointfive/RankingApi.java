package com.shi.content.ranking.threepointfive;

import com.generated.vos.rankingmongo.offer.Rankingmongo;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.shc.autocontent.LoadProperties;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class RankingApi {

	public static Rankingmongo getSingleDoc(String id)
	{
		try {
			String url = LoadProperties.rankingBonusService+"/get/"+id;
			System.out.println(url);
			String resp = RestExecutor.getJSonResponse(url);

			Gson gson = new Gson();

			Rankingmongo rankingMongo = gson.fromJson(resp, Rankingmongo.class);

			return rankingMongo;
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
			return null;
		}
	}
}
