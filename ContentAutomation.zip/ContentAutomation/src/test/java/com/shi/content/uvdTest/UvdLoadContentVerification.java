package com.shi.content.uvdTest;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Val;
import com.generated.vos.uvd.AutomotiveProductOffer;
import com.generated.vos.uvd.ProductAttribute;
import com.generated.vos.uvd.ProductContent;
import com.generated.vos.uvd.ProductOffer;
import com.google.gson.JsonArray;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.SHCContentCommons;

/**
 * @author ddaphal
 *
 */
public class UvdLoadContentVerification   implements Runnable{

	AutomotiveProductOffer automotiveProductOffer ;

	public UvdLoadContentVerification(AutomotiveProductOffer automotiveProductOffer)
	{
		super();
		this.automotiveProductOffer = automotiveProductOffer;
	}


	public void run()
	{
		CompareValuesUtility.init();

		System.out.println("automotiveProductOffer.getImaClassControlPid()"+automotiveProductOffer.getImaClassControlPid());

		String sRelationType = automotiveProductOffer.getRelationType();

		String sUVDId ="";
		String dummyPID = "";
		String brandCodeId = "";
		String spinId = "";

		ProductContent productContent = automotiveProductOffer.getProductContent();

		String catEntrySubType=null;
		
		if(sRelationType.equalsIgnoreCase("single"))
		{
			ProductOffer productOffer = automotiveProductOffer.getProductOfferings().getProductOffer()[0];

			String sSpinUniqueId = productOffer.getSpinUniqueId();

			sUVDId = "UVD"+sSpinUniqueId+"P";

			catEntrySubType = "NV";
			
			dummyPID = productOffer.getBrandCodeId()+"-"+productOffer.getManufacturerPartNumber();
			brandCodeId = productOffer.getBrandCodeId();
			spinId = sSpinUniqueId;
		}
		else if(sRelationType.equalsIgnoreCase("automotiveGrouping"))
		{
			String sAutomotiveGroupId = automotiveProductOffer.getAutomotiveGroupId();

			sUVDId = "UVD"+sAutomotiveGroupId+"P";
			
			catEntrySubType ="V";
			
			dummyPID = sAutomotiveGroupId;
			brandCodeId = automotiveProductOffer.getProductOfferings().getProductOffer(0).getBrandCodeId();
			spinId = sAutomotiveGroupId;
		}

		APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, sUVDId);
		Content content = (Content)allResponse.getT();
		//Content content = RestExecutor.getDataById(CollectionValuesVal.CONTENT, sUVDId);
		
		if(content==null)
		{
			CompareValuesUtility.logFailed("Product Id", sUVDId, "Not Found in GB");
		}
		else
		{
			try {
				verifyContent(productContent, content, catEntrySubType, dummyPID, brandCodeId);
				verifyFtSearch(allResponse, catEntrySubType, spinId);
			} catch (Exception e) {

				System.out.println(e.getMessage() + " Exception : "+sUVDId);
			}	
		}
		
		CompareValuesUtility.setupResult(sUVDId+"", true);
	}


	private void verifyFtSearch(APIResponse<Content> allResponse, String catEntrySubType, String spinId) {
		JsonArray catSubTyp = allResponse.getFtFields().get("catentrySubType").getAsJsonArray();
		CompareValuesUtility.compareValues("_ft.catentrySubType", "UVD+"+catEntrySubType, catSubTyp.get(0).getAsString()+"+"+catSubTyp.get(1).getAsString());
		CompareValuesUtility.compareValues("_search", "UVD", allResponse.getSearchFieldValue("dispSite"), "dispSite");
		CompareValuesUtility.compareValues("_search", spinId, allResponse.getSearchFieldValue("spinId"), "spinId");
		CompareValuesUtility.addNewMultiValuedFields();
	}


	public void verifyContent(ProductContent xmlContentObject,Content gbContentObject,String catEntrySubType, String dummyPID, String brandCodeId)
	{
		
		SHCContentCommons commons =new SHCContentCommons();

		CompareValuesUtility.compareValues("Name",xmlContentObject.getName(),gbContentObject.getName());

		CompareValuesUtility.compareValues("Brand", xmlContentObject.getBrand().getId(), gbContentObject.getBrand().getId(), "id");
		CompareValuesUtility.compareValues("Brand", xmlContentObject.getBrand().getName(), gbContentObject.getBrand().getName(), "name");
		String xmlBrandUrl = xmlContentObject.getBrand().getLogoImageUrl().replaceAll("http://i.sears.com/s/", "http://c.shld.net/rpx/i/s/").replaceAll("http://s7.sears.com/", "http://s.shld.net/").replaceAll("http://s7.kmart.com/", "http://s.shld.net/");
		CompareValuesUtility.compareValues("Brand", xmlBrandUrl, gbContentObject.getBrand().getImg()==null?null:gbContentObject.getBrand().getImg().getSrc(), "url");
		CompareValuesUtility.addNewMultiValuedFields();
		
		Object modelNum;
		Object mfrName;
		try{
			modelNum = gbContentObject.getMfr().getModelNo();
			mfrName = gbContentObject.getMfr().getName();
		}catch (Exception e){
			modelNum = null;
			mfrName = null;
		}

		CompareValuesUtility.verifyNullOrEqual("Mfr", xmlContentObject.getManufacturerName(), mfrName, "name");
		CompareValuesUtility.verifyNullOrEqual("Mfr", xmlContentObject.getManufacturerModelNumber(), modelNum, "modelNo");
		CompareValuesUtility.addNewMultiValuedFields();

		if(xmlContentObject.getSeo()!=null){
			CompareValuesUtility.compareValues("Seo", xmlContentObject.getSeo().getSeoRobotFollowFlag(), gbContentObject.getSeo().getIsRobotFollow(), "isRobotFollow");
			CompareValuesUtility.compareValues("Seo", xmlContentObject.getSeo().getSeoRobotIndexFlag(), gbContentObject.getSeo().getIsRobotIndex(), "isRobotIndex");
			CompareValuesUtility.verifyNullOrEqual("Seo", xmlContentObject.getSeo().getSeoProductAltTag(), gbContentObject.getSeo().getProductAltTag(), "productAltTag");
			CompareValuesUtility.verifyNullOrEqual("Seo", xmlContentObject.getSeo().getSeoFeatureAltTag(), gbContentObject.getSeo().getFeatureAltTag(), "featureAltTag");
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		CompareValuesUtility.compareValues("Classifications", "P", gbContentObject.getClassifications().getCatentryType(), "catentryType");
		CompareValuesUtility.compareValues("Classifications", catEntrySubType ,gbContentObject.getClassifications().getCatentrySubType(), "catentrySubType");
		CompareValuesUtility.compareValues("Classifications", "true", gbContentObject.getClassifications().getIsUvd(), "isUvd");
		CompareValuesUtility.compareValues("Classifications", "S", gbContentObject.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
		CompareValuesUtility.compareValues("Classifications", "true", gbContentObject.getClassifications().getIsAutomotive(), "isAutomotive");
		CompareValuesUtility.addNewMultiValuedFields();
		
		commons.verifyDesc(xmlContentObject.getFeatureDescription(), xmlContentObject.getMarketingDescription(), gbContentObject.getDesc(), true);
		CompareValuesUtility.addNewMultiValuedFields();

		Boolean xmlIsLongDescSuppress = xmlContentObject.getSuppressLongDescriptionFlag();

		xmlIsLongDescSuppress = xmlIsLongDescSuppress==null?false:xmlIsLongDescSuppress;

		Boolean isLongDescSuppress = gbContentObject.getIsLongDescSuppress(); 

		isLongDescSuppress  = isLongDescSuppress==null?false:isLongDescSuppress;

		compareValues("PrimaryImg", "P", gbContentObject.getAssets().getImgs().get(0).getType(),"Type");
		verifyNullOrEqual("PrimaryImg", xmlContentObject.getPrimaryImage().getHeight(), convertToString(gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getHeight()),"Height");
		verifyNullOrEqual("PrimaryImg", xmlContentObject.getPrimaryImage().getWidth(), convertToString(gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getWidth()),"Width");
		compareValues("PrimaryImg", TestUtils.modifyURL(xmlContentObject.getPrimaryImage().getUrl()), gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getSrc(),"Src");
		CompareValuesUtility.addNewMultiValuedFields();

		if(xmlContentObject.getFeatureImages() != null){
			for(com.generated.vos.uvd.FeatureImage fImage : xmlContentObject.getFeatureImages().getFeatureImage()){
				boolean bFound = false;
				int i = getPositionInList("A", gbContentObject.getAssets().getImgs(), "type", Img_.class);
				for(Val assetImgVal : gbContentObject.getAssets().getImgs().get(i).getVals()){
					if(assetImgVal.getSrc().equals(TestUtils.modifyURL(fImage.getUrl()))){
						bFound = true;
						compareValues("FeaturedImg", "A", gbContentObject.getAssets().getImgs().get(i).getType(),"Type");
						CompareValuesUtility.verifyTrue(true, "FeaturedImg", TestUtils.modifyImgURL(fImage.getUrl()), assetImgVal.getSrc());
						verifyNullOrEqual("FeaturedImg", fImage.getWidth(), convertToString(assetImgVal.getWidth()),"Width");
						verifyNullOrEqual("FeaturedImg", fImage.getHeight(), convertToString(assetImgVal.getHeight()),"Height");
					}
				}
				if(!bFound){
					CompareValuesUtility.verifyTrue(false, "FImgSrc", fImage.getUrl(), "Not found");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}

		verifySpecs(xmlContentObject.getProductAttributes().getProductAttribute(), gbContentObject.getSpecs(),xmlContentObject.getContentItemClassId()+"");

		CompareValuesUtility.compareValues("isLongDescSuppress", xmlIsLongDescSuppress, isLongDescSuppress);
		
		CompareValuesUtility.verifyNullOrEqual("AltIds", automotiveProductOffer.getImaClassControlPid(), gbContentObject.getAltIds().getImaClassControlPid(), "imaClassControlPid");
		CompareValuesUtility.verifyNullOrEqual("AltIds", dummyPID, gbContentObject.getAltIds().getDummyPID(), "dummyPID");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("Automotive", "UVD", gbContentObject.getAutomotive().getAutoType(), "autoType");
		CompareValuesUtility.verifyNullOrEqual("Automotive", brandCodeId, gbContentObject.getAutomotive().getBrandCodeId(), "brandCodeId");
		//TODO CompareValuesUtility.verifyNullOrEqual("Automotive", ??, gbContentObject.getAutomotive().getAutoFitment(), "autoFitment");
		CompareValuesUtility.addNewMultiValuedFields();

		verifyTaxonomy(xmlContentObject, gbContentObject, xmlContentObject.getContentItemClassId()+"");
		
		SHCContentCommons commonUtils = new SHCContentCommons();
		
		ProductAttribute[] prodAttr = xmlContentObject.getProductAttributes().getProductAttribute();
		
		String attId = "",attValId="";
		for (ProductAttribute productAttribute : prodAttr) {
			
			attId=attId+","+productAttribute.getAttributeId();
			attValId=attValId+","+productAttribute.getProductAttributeTypeChoice().getAttributeValueId();
					
		}
		
		attId=attId.replaceFirst(",","");
		attValId=attValId.replaceFirst(",","");
		
		
		String sQuery = commonUtils.getFacetsQuery(xmlContentObject.getContentItemClassId()+"", attId, attValId);
		
		try {
			commonUtils.verifyFacets(sQuery, gbContentObject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		commonUtils.verifySites(xmlContentObject, gbContentObject.getSites());
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlContentObject.getProductAssets() != null){
			commonUtils.verifyAssetAttachments(xmlContentObject.getProductAssets().getProductAsset(), gbContentObject.getAssets().getAttachments());
			
			commonUtils.verifyAssetVideo(xmlContentObject.getProductAssets().getProductAsset(), gbContentObject.getAssets().getVideos());
		}
		if(xmlContentObject.getContentExtensions()!= null)
			commonUtils.verifyContentExtension(xmlContentObject.getContentExtensions().getProvider(0), gbContentObject.getAssets().getContentExtensions().get(0));
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyTaxonomy(ProductContent pContent, Content content,String itemClassId) {
		
		SHCContentCommons commonUtils = new SHCContentCommons();
		
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for ( com.generated.vos.uvd.Site site : pContent.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId > 11 || lSiteId == 10)
				continue;
			
			List<String> lstHieararchyIds = new ArrayList<String>();
			for( com.generated.vos.uvd.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}
			
			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		
		
		commonUtils.compareWebhierarchy(mpSiteHiearachies, content.getTaxonomy().getWeb());
		commonUtils.compareMasterhierarchy(Long.parseLong(itemClassId), content.getTaxonomy().getMaster().getHierarchy());
	}

	public void verifySpecs(com.generated.vos.uvd.ProductAttribute[] prodAttribs, List<Spec> specsJson, String itemClassId){

		List<String> ignoreAttrIds = Arrays.asList(new String[]{"781110","797010","250601","796910","796810","1774"});
		List<String> autoIds = Arrays.asList(new String[]{"1035210","873910"});

		String query ="select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1" +
				" where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ('ATTVALID')"+
				" and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"+
				" and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		String attributeOnlyQuery = "select x.displaylabel as name, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g" +
				" where x.xattribute_id=g.xattribute_id and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"+
				" and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";



		if(prodAttribs!=null)
		{

			String grpNameJson="";
			String grpNameWCS="";

			Long attrId , val_id;
			String val_free = "";
			String attrName=null, attrVal=null;
			for ( com.generated.vos.uvd.ProductAttribute attribute : prodAttribs) {

				//It's a flag field - no need to check
				if(attribute.getProductAttributeTypeChoice().getAttributeValueFlag()!= null)
					continue;

				attrId = attribute.getAttributeId();

				//For content some attribute ids need to be skipped
				if(ignoreAttrIds.contains(attrId.toString())){
					continue;
				}

				//If automotive attributes
				if(autoIds.contains(attrId.toString())){
					//					bIsAuto = true;
					continue;
				}

				val_id = attribute.getProductAttributeTypeChoice().getAttributeValueId();
				val_free = attribute.getProductAttributeTypeChoice().getAttributeValueFree();

				if(val_id != null){
					String finalQuery = query.replace("ATTVALID",  val_id.toString()).replace("ATTID", attrId.toString()).
							replace("IMACLASSID", itemClassId);
					List<String> attrData = DBUtil.executeQueryMultiColumnSingleRow(finalQuery);
					if(attrData == null)
						continue;
					attrName = attrData.get(0);
					attrVal = attrData.get(1);
					grpNameWCS = attrData.get(2);
				}
				else  //Probably free text
				{
					String finalQuery = attributeOnlyQuery.replace("ATTID", attrId.toString()).replace("IMACLASSID", itemClassId);
					List<String> attrData = DBUtil.executeQueryMultiColumnSingleRow(finalQuery);
					if(attrData!=null)
					{
						attrName = attrData.get(0);

						grpNameWCS = attrData.get(1);
					}
					attrVal=val_free;
				}

				if(grpNameWCS==null)
				{
					grpNameWCS="Others:";
				}

				boolean found = false;
				for (Spec spec : specsJson) {

					grpNameJson = spec.getGrpName();
					List<Attr> attrsList = spec.getAttrs();
					for (Attr attr : attrsList) {

						if(attr.getName().equals(attrName) 
								&& attr.getVal().equals(TestUtils.encodeHTML(attrVal))
								&& grpNameWCS.equals(grpNameJson))
						{
							found = true;
							CompareValuesUtility.logPassed("SpecName", attrName, attr.getName());
							CompareValuesUtility.logPassed("SpecVal", attrVal, attr.getVal());
							CompareValuesUtility.logPassed("SpecGrpName", grpNameWCS, grpNameJson);
							break;
						}
					}

					if(found)
					{
						break;
					}
				}

				if(!found)
				{
					attrName = attrName==null?"null":attrName;
					attrVal = attrVal==null?"null":attrVal;

					CompareValuesUtility.logFailed("SpecName", attrName, "");
					CompareValuesUtility.logFailed("SpecVal", attrVal==null?"null":attrVal, "");
					CompareValuesUtility.logFailed("SpecGrpName", grpNameWCS, grpNameJson);
				}

			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}
}
