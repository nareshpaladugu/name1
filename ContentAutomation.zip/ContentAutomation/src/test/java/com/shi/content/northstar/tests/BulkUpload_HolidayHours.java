package com.shi.content.northstar.tests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shi.content.northstar.pages.BulkUploadPage;
import com.shi.content.northstar.pages.BulkUploadPage.BulkUploadType;
import com.shi.content.northstar.pages.LinkPanel;

/**
 * Test to verify Bulk Upload Feature for Holiday Hours Option
 * @author vshar10
 */
public class BulkUpload_HolidayHours extends NorthStarBaseTest {
	DriverLogger logger = new DriverLogger();
	HashMap<String, HashMap<String, Object>> storeDataMap = null;

	@Test(description="Test To Verify Bulk Upload Feature For Holiday Hours Option", groups = {"NS-P1"})
	public void testBulkUploadForHolidayHours() {
		LinkPanel menuLinks = new LinkPanel();
		menuLinks.goToBulkUpload();
		BulkUploadPage bulkUploadPage = new BulkUploadPage();
		bulkUploadPage.selectBulkUploadType(BulkUploadType.HOLIDAY_HOURS);
		String filePath = generateInputFile();	// Get input file
		bulkUploadPage.uploadFile(filePath);	// Upload input file
		Asserts.assertTrue(bulkUploadPage.messageLabel.containsText("File upload succesful"), "File upload succesful");
		bulkUploadPage.publishData();
		Asserts.assertTrue(bulkUploadPage.messageLabel.containsText("Holiday hours are succesfully published to Database"), "Holiday hours are succesfully published to Database");
		verifyUploadedDataMatchWihDB();	// Verify data is updated in DB
	}

	/**
	 * Method to fetch stores data from DB & generate input file
	 * @return
	 */
	private String generateInputFile() {
		String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\BulkUploadInputFiles\\HolidayHours_Inputs.xlsx";
		try {
			getStoreData();	// Get stores from DB

			FileOutputStream fos = new FileOutputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook();
			workbook.createSheet();
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Create Header
			XSSFRow row = sheet.createRow(0);
			row.createCell(0).setCellValue("Store#");
			row.createCell(1).setCellValue("Store Type");
			row.createCell(2).setCellValue("Date");
			row.createCell(3).setCellValue("Open");
			row.createCell(4).setCellValue("Close");
			row.createCell(5).setCellValue("Early Fusion Order Drop");

			int rowNo=1, cellNo=0;
			XSSFCell cell;

			// Write Store Data
			XSSFCellStyle style = workbook.createCellStyle();
			style.setDataFormat(workbook.createDataFormat().getFormat("0"));

			XSSFCellStyle style2 = workbook.createCellStyle();
			style2.setDataFormat(workbook.createDataFormat().getFormat("m/d/yyyy"));

			for(String storeId: storeDataMap.keySet()) {
				row = sheet.createRow(rowNo);
				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("Store#").toString());	// Store Id

				cell = row.createCell(cellNo++);
				cell.setCellValue(storeDataMap.get(storeId).get("Store Type").toString());	// Store Type

				cell = row.createCell(cellNo++);
				cell.setCellValue((Date) storeDataMap.get(storeId).get("Date"));	// Date
				cell.setCellStyle(style2);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) storeDataMap.get(storeId).get("Open"));	// Open
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer)storeDataMap.get(storeId).get("Close"));	// Close
				cell.setCellStyle(style);

				cell = row.createCell(cellNo++);
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				cell.setCellValue((Integer) storeDataMap.get(storeId).get("Early Fusion Order Drop"));	// Early Fusion Order Drop
				cell.setCellStyle(style);

				rowNo++;
				cellNo=0;
			}
			workbook.write(fos);
			fos.flush();
			fos.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return filePath;
	}

	/**
	 * Method to get required Sears & Kmart stores data
	 */
	public void getStoreData() {
		storeDataMap = new HashMap<>();
		List<String> searsStoreIds = getRandomStoreIds(StoreType.SEARS, 5);
		List<String> kmartStoreIds = getRandomStoreIds(StoreType.KMART, 5);

		HashMap<String, Object> storeInfo = null;

		for (int i = 0, flag = 1; i < 5; i++) {
			// Add Sears Store Data to Map
			storeInfo = new HashMap<>();
			String storeId = "";
			if (flag == 1) {	// Will add sears stores
				storeId = searsStoreIds.get(i).trim();
				storeInfo.put("Store#", !storeId.startsWith("000")?storeId:storeId.substring(3));	
				storeInfo.put("Store Type", "Sears");

				if (i == searsStoreIds.size()-1) {		// Change flag to add Kmart stores
					flag = 0;
					i = -1;
				}
			} else {			// Will add kmart stores
				storeId = kmartStoreIds.get(i).trim();
				storeInfo.put("Store#", storeId);	
				storeInfo.put("Store Type", "Kmart");
			}
			storeInfo.put("Date", JodaDateTimeUtility.getRandomFutureDate());
			Integer n = GenericUtil.getRandomNumberInRange(6,11);
			storeInfo.put("Open", n);
			storeInfo.put("Close", n+12);
			storeInfo.put("Early Fusion Order Drop", 0);
			storeDataMap.put(storeId, storeInfo);
		}
	}

	/**
	 * Method to validate Bulk Uploaded data matches with data in DB
	 */
	public void verifyUploadedDataMatchWihDB() {
		for(String storeId: storeDataMap.keySet()) {
			HashMap<String, Object> storeData = storeDataMap.get(storeId);
			String jResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, storeId);
			String hldyObj = JsonStringParser.getJsonValueNew(jResponse, "_blob.unit.hldy");
			JsonArray jArray = new JsonParser().parse(hldyObj).getAsJsonArray();
			for(JsonElement jElement: jArray) {
				String date = new SimpleDateFormat("yyyy-MM-dd").format(storeData.get("Date"));
				JsonObject jsonObject = jElement.getAsJsonObject();
				if (jsonObject.get("dt").toString().replaceAll("\"", "").equals(date)) {
					logger.log("Verifying store "+storeId, false);

					// Validate Date
					Asserts.verifyTrue(jsonObject.get("dt").toString().replaceAll("\"", "").equals(date), "Verified date");

					// Validate Start Time
					String openTime = Integer.toString(((Integer) storeData.get("Open") * 3600));
					Asserts.verifyTrue(jsonObject.get("opn").toString().replaceAll("\"", "").equals(openTime), "Verified store open time ");

					// Validate End Time
					String closeTime = Integer.toString(((Integer) storeData.get("Close") * 3600));
					Asserts.verifyTrue(jsonObject.get("cls").toString().replaceAll("\"", "").equals(closeTime), "Verified store close time");

					break;	// Stop checking further for current store Id
				}
			}
		}
	}
}