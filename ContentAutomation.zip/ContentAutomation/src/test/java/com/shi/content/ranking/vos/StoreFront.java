package com.shi.content.ranking.vos;

public class StoreFront {

	private String urlName;
	
	public String getUrlName() {
		return urlName;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}
}
