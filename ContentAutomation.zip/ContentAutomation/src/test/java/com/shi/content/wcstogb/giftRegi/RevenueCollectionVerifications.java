package com.shi.content.wcstogb.giftRegi;

import java.util.List;
import java.util.Map;

import com.generated.vos.gr.revenue.PurchaseDetail;
import com.generated.vos.gr.revenue.RevenueCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;

public class RevenueCollectionVerifications implements Runnable
{
	private String giftregistry_id;
	private List<Map<String,String>> rowMapsForSingleGr;

	public RevenueCollectionVerifications(String giftregistry_id,List<Map<String,String>> rowMapsForSingleGr)
	{
		this.giftregistry_id=giftregistry_id;
		this.rowMapsForSingleGr = rowMapsForSingleGr;
	}


	public void run() 
	{
		if(giftregistry_id==null || giftregistry_id.isEmpty())
		{
			return;
		}

		CompareValuesUtility.init();

		CommonGiftReg commonGiftReg = new CommonGiftReg();

		BasicDBObject criteria = new BasicDBObject();
		criteria.put("_id", giftregistry_id);

		DBCollection dbCollection =  CommonGiftReg.getDBCollection("registryRevenueCollection"); 

		DBObject singleDocumentRegistryItemColl = dbCollection.findOne(criteria);

		if(singleDocumentRegistryItemColl == null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("registryRevenueCollection", "Not Found");
		}
		else
		{

			if(TestUtils.isEmptyJsonResponse(singleDocumentRegistryItemColl.toString()))
			{
				CompareValuesUtility.addFailedDataFieldForReport("registryRevenueCollection", "Not Found");
			}
			else
			{
				String PURCHASERECORD_ID=null;

			//	System.out.println(singleDocumentRegistryItemColl.toString());
				RevenueCollection revenueCollection = CommonGiftReg.getCollectionObject(singleDocumentRegistryItemColl.toString(),RevenueCollection.class);

				CompareValuesUtility.compareValues("_id", giftregistry_id,revenueCollection.getId()); 

				CompareValuesUtility.compareValues("giftregistry_id", giftregistry_id,revenueCollection.getGiftRegistryId()); 

				List<PurchaseDetail> purchaseDetails = 	revenueCollection.getPurchaseDetails();

				String REGISTRANTMEMO;
				String ISNOTESENT;
				try 
				{
					boolean found = false;
					for (Map<String, String> rs : rowMapsForSingleGr) 
					{
						PURCHASERECORD_ID = rs.get("PURCHASERECORD_ID");

						found = false;

						for (PurchaseDetail purchaseDetail : purchaseDetails) 
						{

							if(PURCHASERECORD_ID.equals(purchaseDetail.getPurchaseRecordId()))
							{
								CompareValuesUtility.compareValues("purchaseRecordId", rs.get("PURCHASERECORD_ID"),purchaseDetail.getPurchaseRecordId()); 
								CompareValuesUtility.compareValues("partNumber", rs.get("PARTNUMBER"),purchaseDetail.getPartNumber()); 
								commonGiftReg.compareAsNumbers("orderItemId", rs.get("ORDERITEMID"),purchaseDetail.getOrderItemId()); 
								CompareValuesUtility.verifyNullOrEqual("purchaseDate", rs.get("PURCHASEDATE"),purchaseDetail.getPurchaseDate()); 

								REGISTRANTMEMO = rs.get("REGISTRANTMEMO");
								if(REGISTRANTMEMO==null)
								{
									REGISTRANTMEMO="";
								}

								if(REGISTRANTMEMO.contains("#"))
								{
									REGISTRANTMEMO=REGISTRANTMEMO.substring(0,REGISTRANTMEMO.indexOf("#"));
								}

								CompareValuesUtility.verifyNullOrEqual("buyerEmailId",REGISTRANTMEMO ,purchaseDetail.getBuyerEmailId()); 

								ISNOTESENT =  rs.get("ISNOTESENT");

								if(ISNOTESENT.equals("1"))
								{
									ISNOTESENT="Y";
								}
								else if(ISNOTESENT.equals("0"))
								{
									ISNOTESENT="N";
								}
								CompareValuesUtility.verifyNullOrEqual("isThankYouNoteSent", ISNOTESENT,purchaseDetail.getIsThankYouNoteSent()); 
								CompareValuesUtility.verifyNullOrEqual("purchaseLocation", rs.get("PURCHASELOCATION"),purchaseDetail.getPurchaseLocation()); 
								CompareValuesUtility.verifyNullOrEqual("salesCheckNumber", rs.get("TRANSACTIONID"),purchaseDetail.getSalesCheckNumber());
								//CompareValuesUtility.verifyNullOrEqual("createTime", rs.get("CREATETIME"),purchaseDetail.getCreateTime());
								//CompareValuesUtility.verifyNullOrEqual("updateTime", rs.get("UPDATETIME"),purchaseDetail.getUpdateTime());
								CompareValuesUtility.verifyNullOrEqual("buyerFirstName", rs.get("BUYER_FIRST_NAME"),purchaseDetail.getBuyerFirstName());
								CompareValuesUtility.verifyNullOrEqual("buyerLastName", rs.get("BUYER_LAST_NAME"),purchaseDetail.getBuyerLastName());
								CompareValuesUtility.verifyNullOrEqual("buyerMiddleName", rs.get("BUYER_MIDDLE_NAME"),purchaseDetail.getBuyerMiddleName());

								CompareValuesUtility.verifyNullOrEqual("productDescription", CommonGiftReg.removeSpecialChar(rs.get("PRODUCT_DESC")),purchaseDetail.getProductDescription());

								commonGiftReg.compareAsNumbers("price", rs.get("PRICE"),purchaseDetail.getPrice());
								commonGiftReg.compareAsNumbers("quantity", rs.get("QUANTITY"),purchaseDetail.getQuantity());
								commonGiftReg.compareAsNumbers("totalProduct", rs.get("TOTAL_PRODUCT"),purchaseDetail.getTotalProduct());
								commonGiftReg.compareAsNumbers("taxAmount", rs.get("TAX_AMOUNT"),purchaseDetail.getTaxAmount());
								commonGiftReg.compareAsNumbers("totalAdjustment", rs.get("TOTAL_ADJUSTMENT"),purchaseDetail.getTotalAdjustment());
								commonGiftReg.compareAsNumbers("shipTaxAmount", rs.get("SHIP_TAX_AMOUNT"),purchaseDetail.getShipTaxAmount());
								commonGiftReg.compareAsNumbers("shipCharge", rs.get("SHIP_CHARGE"),purchaseDetail.getShipCharge());

								CompareValuesUtility.verifyNullOrEqual("purchaseForRegistrant", rs.get("PURCHASE_FOR_REGISTRANT"),purchaseDetail.getPurchaseForRegistrant());
								commonGiftReg.compareAsNumbers("shippingAddressId", rs.get("SHIPPING_ADDRESS_ID"),purchaseDetail.getShippingAddressId());
								commonGiftReg.compareAsNumbers("billingAddressId", rs.get("BILLING_ADDRESS_ID"),purchaseDetail.getBillingAddressId());
								CompareValuesUtility.verifyNullOrEqual("isMsgForRegistrant", rs.get("ISMSG_FOR_REGISTRANT"),purchaseDetail.getIsMsgForRegistrant());
								CompareValuesUtility.verifyNullOrEqual("registrantMessage", CommonGiftReg.removeSpecialChar(rs.get("REGISTRANT_MESSAGE")),purchaseDetail.getRegistrantMessage());
								commonGiftReg.compareAsNumbers("storeUnitNumber", rs.get("STOREUNIT_ID"),purchaseDetail.getStoreUnitNumber());
								CompareValuesUtility.verifyNullOrEqual("nposMessage", rs.get("NPOS_MSG"),purchaseDetail.getNposMessage());

								if(rs.get("STOREID")==null)
								{
									CompareValuesUtility.compareValues("Store", "", purchaseDetail.getStore()); 
								}
								else if(rs.get("STOREID").equals("10153"))
								{
									CompareValuesUtility.compareValues("Store", "sears", purchaseDetail.getStore()); 
								}
								else if(rs.get("STOREID").equals("10151"))
								{
									CompareValuesUtility.compareValues("Store", "kmart", purchaseDetail.getStore()); 
								}
								else
								{
									System.out.println("############ Unhandled store..............");
								}

								commonGiftReg.compareAsNumbers("giftItemId", rs.get("GIFTITEM_ID"),purchaseDetail.getGiftItemId());
								found = true;
								break;
							}
						}
						if(!found)
						{
							CompareValuesUtility.addFailedDataFieldForReport("purchaseDetail-Not Found", PURCHASERECORD_ID);
						}
					}
				} 
				catch (Exception e) 
				{
					System.out.println("Check this is ... "+giftregistry_id);
					e.printStackTrace();
				}
			}
		}
		CompareValuesUtility.setupResult(giftregistry_id,true);
	}
}
