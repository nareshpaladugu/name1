package com.shi.content.mptests;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.generated.vos.pricing.PricingSchema;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class MPPricingVerifications implements Runnable {

	
	
	static Map<String, Long> idToTS = new HashMap<String, Long>();
	static boolean bFileFound = false;
	private List<String> mpPricingMessages;
	private static final String FILENAME =  "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+".txt";

	private static final String PROCESSED_FILENAME = "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+"_Processed.txt";
	
	public MPPricingVerifications(){
	}
	
	
	@Test(description="Test MP Pricing messages for shipping value", groups="MPPricingVerifs")
	public void MPPricingTests(){
		
		readFromFileAndInitTimestamps();
			if(!(idToTS.size() == 0))
				bFileFound = true;
		
		
		BlockingQueue<List<String>> mpPricingDocs = new LinkedBlockingQueue<List<String>>();

		KafkaIAConsumer<String> mpPricingConsumerThread = new KafkaIAConsumer<String>(mpPricingDocs);		
		Thread tConsumerThread = new Thread(mpPricingConsumerThread);
		tConsumerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<String> nodeToTest;

				nodeToTest = mpPricingDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == mpPricingConsumerThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new MPPricingVerifications(nodeToTest));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public MPPricingVerifications(List<String> ids  ) {
		mpPricingMessages = ids;
	}

	@Override
	public void run() {
		
			
			for(String mpPricingMessage : this.mpPricingMessages){
				try{
					
					String type = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.prgm");
					String id =null;
					String sellerId =null;
					if(type.contains("FBS")){
						 id = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dartPartNbr");	
						 id=id.replaceAll("\"", "");
					}else{
						 id = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.itemId");
					}
					
					if(type.contains("FBM") || type.contains("DSS"))
						id = "SPM"+id;
					if(type.contains("CPC")){
						long cpcId=Long.parseLong(id);
						sellerId=JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.accountId");
						String aggregatorId=RestExecutor.getSpecificValueFromJson(CollectionValuesVal.SELLER, sellerId, "[{_blob{seller{programs{cpc{aggregatorId}}}}}]");
						id=TestUtils.generateCPCId(aggregatorId, sellerId, cpcId);
					}
					String competitiveness =null;
					String mapPriceIndicator=null;
					String promotionalText=null;
					String saleEndDate=null;
					String salePrice=null;
					String saleStartDate=null;
					String standardPrice=null;
					String cost=null;
					String clickAmount=null;
					long saleEdDate=0;
					
					if(type.contains("FBM") || type.contains("FBS")){
					competitiveness = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.cmt");
					mapPriceIndicator = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.mapPriceInd");
					promotionalText = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.sale.promoTxt");
					saleEndDate = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.sale.endDtm");
					saleEdDate=Long.parseLong(saleEndDate);
					salePrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.sale.price");
					Double salePriceRate = Double.parseDouble(salePrice);
					standardPrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.fbms.stdPrice");
					Double standardPriceRate = Double.parseDouble(standardPrice);
					}
					if(type.contains("DSS")){
						competitiveness = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.cmt");
						mapPriceIndicator = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.mapPriceInd");
						promotionalText = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.sale.promoTxt");
						saleEndDate = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.sale.endDtm");
						saleEdDate=Long.parseLong(saleEndDate);
						salePrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.sale.price");
						Double salePriceRate = Double.parseDouble(salePrice);
						standardPrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.rsp");
						Double standardPriceRate = Double.parseDouble(standardPrice);
						cost=JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.dss.cost");
						}
					if(type.contains("CPC")){
						competitiveness = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.cmt");
						promotionalText = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.sale.promoTxt");
						saleEndDate = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.sale.endDtm");
						saleEdDate=Long.parseLong(saleEndDate);
						salePrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.sale.price");
						Double salePriceRate = Double.parseDouble(salePrice);
						standardPrice = JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.stdPrice");
						Double standardPriceRate = Double.parseDouble(standardPrice);
						clickAmount=JsonStringParser.getJsonValueNew(mpPricingMessage, "itemPrice.cpc.click.amt");
						
						}
					CompareValuesUtility.init();
					
					PricingSchema priceDoc = RestExecutor.getDataById(CollectionValuesVal.PRICING, id);
					if(priceDoc == null){
						CompareValuesUtility.logFailed("Pricing", id, "Pricing not found");
						CompareValuesUtility.setupResult(id, true);
						continue;
					}
					String cmt=priceDoc.getCmt();
					//String salepromotionalText= priceDoc.getPromotext();
					//String saleEtDate= priceDoc.getSale().getSaleEndDate();
					//String salePrRate= priceDoc.getSale().getSalePrice();
					//String regularPriceRate= priceDoc.getRegPrice();
					
					String modifiedTS = priceDoc.getMeta().getModifiedTs();
					System.out.println("Testing for : "+ id + " Pricing : "  + "  Modified TS : "+ modifiedTS);
					
					CompareValuesUtility.addDataFieldForReport("ProgramType",type);
					CompareValuesUtility.verifyNullOrEqual("Competitiveness", competitiveness.replaceAll("\"", ""), cmt);
					CompareValuesUtility.verifyNullOrFalse("PromotionalText",promotionalText.replaceAll("\"", ""),priceDoc.getPromotext() == null ? null
							: priceDoc.getPromotext());
					String saleEndDt = getDate(saleEdDate, "yyyy-MM-dd HH:mm:ss.SSS");
					CompareValuesUtility.verifyNullOrEqual("Sale",priceDoc.getSale().getSaleEndDate() == null ? null
							: priceDoc.getSale().getSaleEndDate(), saleEndDt.substring(0, 10)+"T"+saleEndDt.substring(11, 23)+"Z", "SaleEndDate");
					CompareValuesUtility.verifyNullOrEqual("Sale", salePrice, priceDoc.getSale().getSalePrice() == null ? null
							: priceDoc.getSale().getSalePrice(), "SalePrice");
					CompareValuesUtility.verifyNullOrEqual("StandardPrice", standardPrice, priceDoc.getRegPrice() == null ? null
							: priceDoc.getRegPrice());
					if(type.contains("FBM") || type.contains("FBS") ||type.contains("DSS")){
					CompareValuesUtility.verifyNullOrFalse("MapPriceIndicator",mapPriceIndicator.replaceAll("\"", ""),priceDoc.getMapVal() == null ? null
							: priceDoc.getMapVal());
					}
					if(type.contains("DSS")){
						CompareValuesUtility.verifyNullOrFalse("Cost",cost,priceDoc.getCost() == null ? null
								: priceDoc.getCost());	
					}
					if(type.contains("CPC")){
						Offer offerDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);
						if(offerDoc == null){
							CompareValuesUtility.logFailed("Pricing", id, "Offer not found");
							CompareValuesUtility.setupResult(id, true);
							continue;
						}
						CompareValuesUtility.verifyNullOrFalse("ClickAmount",clickAmount,offerDoc.getMarketplace().getCpc().getClickPrice() == null ? null
								: offerDoc.getMarketplace().getCpc().getClickPrice());	
					}
					if(bFileFound){
						
						Long insertTS = idToTS.get(id);
						CompareValuesUtility.addDataFieldForReport("GBTime", modifiedTS);
						if(insertTS == null){
							CompareValuesUtility.addDataFieldForReport("Insertime","Insert time not found");
						}
						else{
							String insertDate = getDate(insertTS, "yyyy-MM-dd HH:mm:ss.SSS");
							CompareValuesUtility.addDataFieldForReport("Insertime",insertDate );
							
							DateTime dtGBTime = JodaDateTimeUtility.convertToJodaFormat(modifiedTS);
							DateTime dtInsertTime = JodaDateTimeUtility.convertToJodaFormat(insertDate);
							if(dtGBTime == null)
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", "No modified ts in gb");
							else
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", (dtGBTime.getMillis() - dtInsertTime.getMillis())+"");
						}
					}
					
									
					CompareValuesUtility.setupResult(id, true);
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Check this message "+ mpPricingMessages);
				}
			}
		}

/***
 * Method to read from file if available and create a map of id to timestamp
 */
	public void readFromFileAndInitTimestamps(){
		
		
		BlockingQueue<String> singleStoreProductPrice = new LinkedBlockingQueue<String>();
		TextFileParser<String> myParser = new TextFileParser<String>(FILENAME, singleStoreProductPrice);
		
		
		Thread t = new Thread(myParser);
		String newData;
		t.start();


		while (true) {
				try {
					newData = singleStoreProductPrice.poll(20, TimeUnit.SECONDS);
					if(newData.equals(myParser.POISON_PILL_STRING))
						break;
					if(newData != null){
						String[] idAndTS = newData.split(":");
						idToTS.put(idAndTS[0], Long.parseLong(idAndTS[1]));
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 

		}
	}
	
	/**
	 * Formats unix timestamp in specified {@code dateFormat}
	 * @param unixTS - Timestamp
	 * @param dateFormat - Format to convert to
	 * @return Converted date
	 */
	public static String getDate(long unixTS, String dateFormat)
	{
		
	    // Create a DateFormatter object for displaying date in specified format.
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
	    
	    // Create a calendar object that will convert the date and time value in milliseconds to date. 
	     Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("US/Central"));
	     calendar.setTimeInMillis(unixTS);
	     return formatter.format(calendar.getTime());
	}
	
	@AfterClass(groups="MPShippingVerifs")
	public void markFileAsProcessed(){
		
		//If file was found during execution, mark it as processed.
		if(bFileFound){
			File oldProcessedFile =  new File(PROCESSED_FILENAME);
			if(oldProcessedFile.exists())
				oldProcessedFile.delete();
			
			File f = new File(FILENAME);
			File toCreateProcessedFile = new File(PROCESSED_FILENAME);
			f.renameTo(toCreateProcessedFile);
		}
	}





}
