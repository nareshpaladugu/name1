package com.shi.content.ranking.threepointfive.helper;

import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.generated.vos.rankingmongo.offer.Rankingmongo;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.ranking.threepointfive.RankingApi;

/**
 * @author ddaphal
 *
 */
public class ValidateGetAPI 
{
	@Test(description="ValidateBonusPoints", groups="ValidateGetAPI")

	public void dailyRoutineTest()
	{
		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("full"))
		{
			try {

				int processed=0;
				MongoCollection<org.bson.Document> collection = RankingMongoDbUtil.getRankingMongoCollection();

				BasicDBObject query = new BasicDBObject();

				
				long count = collection.count(query);
				System.out.println("Count : "+count);
				
				FindIterable<org.bson.Document> findResult = collection.find(query)
						.projection(new org.bson.Document("_id",1)).batchSize(5);

				for (org.bson.Document document : findResult) {

					processed++;
					processSingleItem(document.get("_id").toString());

					if(LoadProperties.TESTDATALIMIT!=-1 && processed>=LoadProperties.TESTDATALIMIT)
					{
						System.out.println("Processed required items..");
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else
		{
			String sOfferId=System.getProperty("OfferIds","SPM10343472318");

			String sp[] = sOfferId.split(",");

			for (String sSingleOffer : sp) {

				processSingleItem(sSingleOffer);
			}
		}
	}

	public static void processSingleItem(String sSingleOffer)
	{

		CompareValuesUtility.init();

		try {
			Rankingmongo obj = RankingApi.getSingleDoc(sSingleOffer);

			Offer offer= RestExecutor.getDataById(CollectionValuesVal.OFFER, sSingleOffer);

			try {
				CompareValuesUtility.addDataFieldForReport("Classifier",offer.getClassifications().getOfferType().toString());
			} catch (Exception e) {
				CompareValuesUtility.addFailedDataFieldForReport("GB-Offer","Not Found");
			}

			if(obj==null)
			{
				CompareValuesUtility.addFailedDataFieldForReport("MongoRecord","Not Found");
			}
			else
			{
				if(!obj.getId().equalsIgnoreCase(sSingleOffer))
				{
					CompareValuesUtility.addFailedDataFieldForReport("MongoRecord","Not Found");
				}
			}

			if(obj.getBucket()==null|| obj.getBucket().isEmpty())
			{
				CompareValuesUtility.addFailedDataFieldForReport("BukcetId","Not Found");
			}


			try {
				CompareValuesUtility.addDataFieldForReport("Bonuspoints-Sears",obj.getSywPoints().getSears().get(0).getPoints()+"");
			} catch (Exception e) {
			}
			try {
				CompareValuesUtility.addDataFieldForReport("Bonuspoints-Kmart",obj.getSywPoints().getKmart().get(0).getPoints()+"");
			} catch (Exception e) {
			}

			/*try {
				if(obj.getSywPoints().getSears().size()>1)
				{
					CompareValuesUtility.addFailedDataFieldForReport("Multiple SYWPoints",obj.getSywPoints().getSears().size()+"");
				}
			} catch (Exception e) {
			}*/

		} catch (Exception e) {
			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("MongoRecord","Not Found-Exception");
		}
		finally
		{
			CompareValuesUtility.setupResult(sSingleOffer,true);
		}

	}

}

