package com.shi.content.northstar.tests;


import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.ICCEStores;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
* Test search by Zip code
* @author inaikwa
*/
public class SearchStoresByZipCd extends NorthStarBaseTest {

	private ArrayList<String> listStoreIds;
	
	@Test(description="Test to verify search by ZipCd ", groups = {"NS-P1"})

	public void testSearchByZipCd() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();
			
		searchPage.searchByZipCode("60173");
	
		listStoreIds= searchPage.getAllStoreIds();
		
		System.out.println("\nonline "+listStoreIds.size());
	
		System.out.println(listStoreIds);
		
		ArrayList<String> sStores = (ArrayList<String>) RestExecutor.getIdsByAltKey(CollectionValuesVal.STORE, "zipCd","60173"); 
		ArrayList<String> newStoreList = new ArrayList<String>(); 
		System.out.println(sStores.size());
	
		for (int i=0; i <sStores.size();i++){
			
			String storeType = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, sStores.get(i));
			String type =JsonStringParser.getJsonValueNew(storeType, "_blob.unit.strClsReason");
			String sellerId =JsonStringParser.getJsonValueNew(storeType, "_search.sellerId");

			if ((sellerId.equals("null")?null:sellerId)==null&&!(type.replaceAll("\"", "").equalsIgnoreCase("Closed"))) {

				newStoreList.add(sStores.get(i));

				}
			
		}
		
		Asserts.verifyEquals(listStoreIds.size(), newStoreList.size(), "Stores fecthed are equal to stores displayed");
		
		Asserts.verifyTrue(listStoreIds.containsAll(newStoreList), "All stores fetched are matching with the stores displayed");
	
	}
}