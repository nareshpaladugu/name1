package com.shi.content.acme.publish;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class GeneralMessageReader {

	@Test(description="Tests to read from queue and validate source ids",groups="GeneralMessageReader")

	public void acmePublisherTests() throws Exception 
	{
		BlockingQueue<List<Object>> acmeMatchdataDocs = new LinkedBlockingQueue<List<Object>>();

		KafkaIAConsumer<Object> prodThread = new KafkaIAConsumer<Object>("GeneralMessageReaderQAConsumer", Object.class, acmeMatchdataDocs);		
		Thread t = new Thread(prodThread);
		t.start();

		int iMessageCount=0;

		try 
		{
			while (true) 
			{
				List<Object> nodeToTest;

				nodeToTest = acmeMatchdataDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}
}
