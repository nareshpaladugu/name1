package com.shi.content.ranking.logic;

public class ItemConditionBean {
	
	float lowestPrice = 0;
	float lowestPriceNew = 0;
	float lowestPriceRefurbished = 0;
	float lowestPriceUsed = 0;
	String refurbishedOfferId = null;
	String usedOfferId = null;
	int offers_count_new = 0;
	int offers_count_refurbished = 0;
	int offers_count_used = 0;
	
	float getLowestPrice() {
		return lowestPrice;
	}
	void setLowestPrice(float lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	float getLowestPriceNew() {
		return lowestPriceNew;
	}
	void setLowestPriceNew(float lowestPriceNew) {
		this.lowestPriceNew = lowestPriceNew;
	}
	float getLowestPriceRefurbished() {
		return lowestPriceRefurbished;
	}
	void setLowestPriceRefurbished(float lowestPriceRefurbished) {
		this.lowestPriceRefurbished = lowestPriceRefurbished;
	}
	float getLowestPriceUsed() {
		return lowestPriceUsed;
	}
	void setLowestPriceUsed(float lowestPriceUsed) {
		this.lowestPriceUsed = lowestPriceUsed;
	}
	String getRefurbishedOfferId() {
		return refurbishedOfferId;
	}
	void setRefurbishedOfferId(String refurbishedOfferId) {
		this.refurbishedOfferId = refurbishedOfferId;
	}
	String getUsedOfferId() {
		return usedOfferId;
	}
	void setUsedOfferId(String usedOfferId) {
		this.usedOfferId = usedOfferId;
	}
	int getOffers_count_new() {
		return offers_count_new;
	}
	void setOffers_count_new(int offers_count_new) {
		this.offers_count_new = offers_count_new;
	}
	int getOffers_count_refurbished() {
		return offers_count_refurbished;
	}
	void setOffers_count_refurbished(int offers_count_refurbished) {
		this.offers_count_refurbished = offers_count_refurbished;
	}
	int getOffers_count_used() {
		return offers_count_used;
	}
	void setOffers_count_used(int offers_count_used) {
		this.offers_count_used = offers_count_used;
	}
	
}
