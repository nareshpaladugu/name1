package com.shi.content.mptests;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class MPShippingVerifications implements Runnable{

	
	
	static Map<String, Long> idToTS = new HashMap<String, Long>();
	static boolean bFileFound = false;
	private List<String> mpShippingMessages;
	private static final String FILENAME =  "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+".txt";

	private static final String PROCESSED_FILENAME = "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+"_Processed.txt";
	
	public MPShippingVerifications() {
	}
	
	
	@Test(description="Test MP Shipping messages for shipping value", groups="MPShippingVerifs")
	public void MPShippingTests(){
		
		readFromFileAndInitTimestamps();
			if(!(idToTS.size() == 0))
				bFileFound = true;
		
		
		BlockingQueue<List<String>> mpShippingDocs = new LinkedBlockingQueue<List<String>>();

		KafkaIAConsumer<String> mpSoptConsumerThread = new KafkaIAConsumer<String>(mpShippingDocs);		
		Thread tConsumerThread = new Thread(mpSoptConsumerThread);
		tConsumerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<String> nodeToTest;

				nodeToTest = mpShippingDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == mpSoptConsumerThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new MPShippingVerifications(nodeToTest));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public MPShippingVerifications(List<String> ids  ) {
		mpShippingMessages = ids;
	}

	@Override
	public void run() {
		
			
			for(String mpShippingMessage : this.mpShippingMessages){
				try{
					
					String type = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.prgm");
					String id =null;
					if(type.contains("FBS")){
						 id = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.dartPartNbr");	
					}else{
						 id = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.itemId");
					}
					
					if(type.contains("FBM") || type.contains("DSS"))
						id = "SPM"+id;
					
					String handlingFeeRate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.handlingFee");
					Double handlingFee = Double.parseDouble(handlingFeeRate);
					String gndshippingRate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.ground.shipRate");
					Double gndshipping = Double.parseDouble(gndshippingRate);
					String exclude = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.ground.exclude");
					String freeShippingEndDate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.ground.freeShip.endDtm");
					long freeShipEtDate=Long.parseLong(freeShippingEndDate);
					String freeShippingStartDate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.ground.freeShip.startDtm");
					long freeShipStDate=Long.parseLong(freeShippingStartDate);
					String promotionalText = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.ground.freeShip.promoTxt");
					String Expexclude = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.expedited.exclude");
					String ExpshippingRate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.expedited.shipRate");
					Double expShipRate = Double.parseDouble(ExpshippingRate);
					String Premexclude = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.premium.exclude");
					String PremshippingRate = JsonStringParser.getJsonValueNew(mpShippingMessage, "itemShipPrice.shipPrice.premium.shipRate");
					Double premShipRate = Double.parseDouble(PremshippingRate);
					
					CompareValuesUtility.init();
					
					Offer offerDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);
					if(offerDoc == null){
						CompareValuesUtility.logFailed("Shipping", id, "Offer not found");
						CompareValuesUtility.setupResult(id, true);
						continue;
					}
					Double handlingfee=offerDoc.getShipping().getMode().getHandlingFee();
					//Double gndshipRate = offerDoc.getShipping().getMode().getGnd().getPrice();
					//String freeShipEndDate= offerDoc.getShipping().getMode().getGnd().getFree().getEndDt();
					//String freeShipStartDate= offerDoc.getShipping().getMode().getGnd().getFree().getStartDt();
					//String freePromotext= offerDoc.getShipping().getMode().getGnd().getFree().getPromoTxt();
					//Double PremiumshippingRate=offerDoc.getShipping().getMode().getPrem().getPrice();
					
					String modifiedTS = offerDoc.getMeta().getModifiedTs();
					System.out.println("Testing for : "+ id + " Shipping : "  + "  Modified TS : "+ modifiedTS);
					
					CompareValuesUtility.addDataFieldForReport("ProgramType",type);
					CompareValuesUtility.verifyNullOrEqual("GndShiping", gndshipping, offerDoc.getShipping().getMode().getGnd().getPrice() == null ? null
							: offerDoc.getShipping().getMode().getGnd().getPrice(), "GndShipRate");
					CompareValuesUtility.verifyNullOrFalse("GndShiping", exclude, offerDoc.getShipping().getMode().getGnd().getExcluded() == null ? null
							: offerDoc.getShipping().getMode().getGnd().getExcluded(), "Exclude");
					CompareValuesUtility.compareValues("HandlingFeeRate",handlingFee,handlingfee+"");
					String freeEtDate = getDate(freeShipEtDate, "yyyy-MM-dd HH:mm:ss.SSS");
					String freeStDate = getDate(freeShipStDate, "yyyy-MM-dd HH:mm:ss.SSS");
					CompareValuesUtility.verifyNullOrEqual("FreeShiping",offerDoc.getShipping().getMode().getGnd().getFree().getEndDt() == null ? null
							: offerDoc.getShipping().getMode().getGnd().getFree().getEndDt(), freeEtDate.substring(0, 10)+"T23:59:59.000Z", "EndDate");
					CompareValuesUtility.verifyNullOrEqual("FreeShiping", offerDoc.getShipping().getMode().getGnd().getFree().getStartDt() == null ? null
							: offerDoc.getShipping().getMode().getGnd().getFree().getStartDt(), freeStDate.substring(0, 10)+"T00:00:00.000Z", "StartDate");
					CompareValuesUtility.verifyNullOrEqual("FreeShiping", offerDoc.getShipping().getMode().getGnd().getFree().getPromoTxt() == null ? null
							: offerDoc.getShipping().getMode().getGnd().getFree().getPromoTxt(), promotionalText.replaceAll("\"", ""), "PromoText");
					CompareValuesUtility.verifyNullOrFalse("ExpeditedShipping", Expexclude, offerDoc.getShipping().getMode().getExp().getExcluded() == null ? null
							: offerDoc.getShipping().getMode().getExp().getExcluded(), "Exclude");
					CompareValuesUtility.verifyNullOrFalse("ExpeditedShipping", expShipRate, offerDoc.getShipping().getMode().getExp().getPrice() == null ? null
							: offerDoc.getShipping().getMode().getExp().getPrice(), "ShippingRate");
					CompareValuesUtility.verifyNullOrFalse("PremiumShipping", Premexclude, offerDoc.getShipping().getMode().getPrem().getExcluded() == null ? null
							: offerDoc.getShipping().getMode().getPrem().getExcluded(), "Exclude");
					CompareValuesUtility.verifyNullOrEqual("PremiumShipping", offerDoc.getShipping().getMode().getPrem().getPrice() == null ? null
							: offerDoc.getShipping().getMode().getPrem().getPrice(), premShipRate, "ShippingRate");
					
					
					if(bFileFound){
						
						Long insertTS = idToTS.get(id);
						CompareValuesUtility.addDataFieldForReport("GBTime", modifiedTS);
						if(insertTS == null){
							CompareValuesUtility.addDataFieldForReport("Insertime","Insert time not found");
						}
						else{
							String insertDate = getDate(insertTS, "yyyy-MM-dd HH:mm:ss.SSS");
							CompareValuesUtility.addDataFieldForReport("Insertime",insertDate );
							
							DateTime dtGBTime = JodaDateTimeUtility.convertToJodaFormat(modifiedTS);
							DateTime dtInsertTime = JodaDateTimeUtility.convertToJodaFormat(insertDate);
							if(dtGBTime == null)
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", "No modified ts in gb");
							else
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", (dtGBTime.getMillis() - dtInsertTime.getMillis())+"");
						}
					}
					
									
					CompareValuesUtility.setupResult(id, true);
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Check this message "+ mpShippingMessage);
				}
			}
		}

/***
 * Method to read from file if available and create a map of id to timestamp
 */
	public void readFromFileAndInitTimestamps(){
		
		
		BlockingQueue<String> singleStoreProductPrice = new LinkedBlockingQueue<String>();
		TextFileParser<String> myParser = new TextFileParser<String>(FILENAME, singleStoreProductPrice);
		
		
		Thread t = new Thread(myParser);
		String newData;
		t.start();


		while (true) {
				try {
					newData = singleStoreProductPrice.poll(20, TimeUnit.SECONDS);
					if(newData.equals(myParser.POISON_PILL_STRING))
						break;
					if(newData != null){
						String[] idAndTS = newData.split(":");
						idToTS.put(idAndTS[0], Long.parseLong(idAndTS[1]));
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 

		}
	}
	
	/**
	 * Formats unix timestamp in specified {@code dateFormat}
	 * @param unixTS - Timestamp
	 * @param dateFormat - Format to convert to
	 * @return Converted date
	 */
	public static String getDate(long unixTS, String dateFormat)
	{
		
	    // Create a DateFormatter object for displaying date in specified format.
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
	    
	    // Create a calendar object that will convert the date and time value in milliseconds to date. 
	     Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("US/Central"));
	     calendar.setTimeInMillis(unixTS);
	     return formatter.format(calendar.getTime());
	}
	
	@AfterClass(groups="MPShippingVerifs")
	public void markFileAsProcessed(){
		
		//If file was found during execution, mark it as processed.
		if(bFileFound){
			File oldProcessedFile =  new File(PROCESSED_FILENAME);
			if(oldProcessedFile.exists())
				oldProcessedFile.delete();
			
			File f = new File(FILENAME);
			File toCreateProcessedFile = new File(PROCESSED_FILENAME);
			f.renameTo(toCreateProcessedFile);
		}
	}



}
