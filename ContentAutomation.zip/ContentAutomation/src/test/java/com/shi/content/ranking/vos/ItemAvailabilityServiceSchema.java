package com.shi.content.ranking.vos;

import java.util.ArrayList;
import java.util.List;

public class ItemAvailabilityServiceSchema {
	private List<Item> items = new ArrayList<Item>();;

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
}
