package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.xmls.collections.Bundle;
import com.generated.xmls.collections.Collection;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.BOC_StaticVerifications;
import com.shi.content.wcsmigration.verifications.SHCCollectionBundleCommons;

public class BOC_StaticLoadTest {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="BOC_StaticLoadTest")
	public void testBOC_StaticLoad(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);
		String sSite = sFileName.split("\\.")[0].split("-")[1];

		BlockingQueue<List<Collection>> collectionQ = new LinkedBlockingQueue<List<Collection>>(); 
		BlockingQueue<List<Bundle>> bundleQ = new LinkedBlockingQueue<List<Bundle>>();
		
		SHCCollectionBundleCommons shcColBunCommons = new SHCCollectionBundleCommons(sFileName,sSite);
		
		// Start producer thread to produce nodes
		ChunkProducerThread<Collection> prodColnThread = new ChunkProducerThread<Collection>(sFileName, collectionQ, Collection.class,"collection");//, poison);
		prodColnThread.setBucketSize(1);
		Thread tc = new Thread(prodColnThread);
		tc.start();
		
		ChunkProducerThread<Bundle> prodBndlThread = new ChunkProducerThread<Bundle>(sFileName, bundleQ, Bundle.class,"bundle");//, poison);
		prodBndlThread.setBucketSize(1);
		Thread tb = new Thread(prodBndlThread);
		tb.start();
		int totalCollCount = 0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Collection> nodeToTest = collectionQ.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodColnThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
//					System.out.println("Sending" + nodeToTest.get(0).getCollectionSearsPartNumber());
					pool.execute(new BOC_StaticVerifications(nodeToTest.get(0), null, shcColBunCommons, sSite, errorPartNumbers));
					
				}
				totalCollCount++;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Total collection count:"+ totalCollCount + " Starting bundles");
		while(true){
			try {
				List<Bundle> nodeToTest = bundleQ.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodBndlThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new BOC_StaticVerifications(null, nodeToTest.get(0), shcColBunCommons, sSite, errorPartNumbers));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public 	static List<String> errorPartNumbers = new ArrayList<String>();
	
	@BeforeClass(groups="BOC_StaticLoadTest")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			errorPartNumbers = ErrorPartReader.getUVDErrorPartsFromLogFile(errorlogFile);
		}

	}
}
