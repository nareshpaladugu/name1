package com.shi.content.Variations;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.contentkafka.Content;
import com.generated.vos.contentkafka.ContentKafkaSchema;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class SHCStaticKafkaLoadTests  {

	
	
	@Test(description="Tests to read from iacontent queue and validate data against GB", groups="kafkaToGBContentTests")
	public void kafkaToGBContentTests() throws Exception {


		BlockingQueue<List<ContentKafkaSchema>> iaContentDocs = new LinkedBlockingQueue<List<ContentKafkaSchema>>();

		KafkaIAConsumer<ContentKafkaSchema> prodThread = new KafkaIAConsumer<ContentKafkaSchema>("IAContentCons",ContentKafkaSchema.class,iaContentDocs);		
		Thread t = new Thread(prodThread);
		t.start();
		
		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<ContentKafkaSchema> nodeToTest;

				nodeToTest = iaContentDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					//pool.execute(new SHCStaticKafkaVerifications<Content>(nodeToTest.get(0).getContent()));
					pool.execute(new SHCStaticKafkaVerifications<Content>(nodeToTest.get(0)));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}

	


}