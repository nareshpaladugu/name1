package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.generated.vos.content.Content;
import com.generated.vos.content.Desc;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Offer;
import com.generated.vos.uvd.ProductContent;
import com.generated.vos.uvd.ProductOffer;
import com.generated.vos.uvd.Site;
import com.google.gson.JsonArray;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class UVD_ImaPidVerifications implements Runnable{
	
	String imaClassControlPid;
	String contentId;
	String offerId;
	String hierarchy;
	ProductOffer productOffer;
	ProductContent productContent;

	public UVD_ImaPidVerifications(String imaClassControlPid, com.generated.vos.uvd.ProductOffer productOffer, ProductContent productContent) {
		super();
		this.imaClassControlPid = imaClassControlPid;
		this.productOffer = productOffer;
		this.productContent = productContent;
		contentId = "UVD"+imaClassControlPid+"P";
		offerId = "UVD"+imaClassControlPid;
		hierarchy = "";
	}

	public void run()
	{
		CompareValuesUtility.init();
		
		System.out.println("Testing UVD Ima Pid: "+ offerId);
		
		APIResponse<Content> contentResp = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, contentId);
		Content content = (Content)contentResp.getT();
		
		Boolean hasKmart = false;
		for(Site site : productContent.getSite()){
			if(site.getId().toString().equals("1")){
				hasKmart = true;
			}
		}
		
		if(content==null)
		{
			CompareValuesUtility.logFailed("contId", contentId, "Content not found in GB");
		}
		else
		{
			try {
				CompareValuesUtility.compareValues("contId",contentId,content.getId());
				CompareValuesUtility.compareValues("contName","UVD-CLASS-CONTROL-PID",content.getName());
				int i = getPositionInList("S", content.getDesc(), "type", Desc.class);
				CompareValuesUtility.compareValues("contDesc","UVD-CLASS-CONTROL-PID",content.getDesc().get(i).getVal());
				CompareValuesUtility.compareValues("contModelNo","UVD-CLASS-CONTROL-PID",content.getMfr().getModelNo());
				CompareValuesUtility.compareValues("contMfrName","IMA-CLASS-CONTROL-PID",content.getMfr().getName());
						
				CompareValuesUtility.compareValues("contSrIsDispElig", true, content.getOperational().getSites().getSears().getIsDispElig());
				/*if(hasKmart){
					CompareValuesUtility.compareValues("contKmIsDispElig", true, content.getOperational().getSites().getKmart().getIsDispElig());
				}*/
				
				CompareValuesUtility.compareValues("contClassifications", "P", content.getClassifications().getCatentryType(), "catentryType");
				CompareValuesUtility.compareValues("contClassifications", "NV", content.getClassifications().getCatentrySubType(), "catentrySubType");
				CompareValuesUtility.compareValues("contClassifications", "S", content.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
				CompareValuesUtility.verifyNull("contClassifications", content.getClassifications().getIsUvd(), "isUvd");
				CompareValuesUtility.verifyNull("contClassifications", content.getClassifications().getIsAutomotive(), "isAutomotive");
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.verifyItemInList("contSites", "sears", content.getSites());
				/*if(hasKmart){
					CompareValuesUtility.verifyItemInList("contSites", "kmart", content.getSites());
				}*/
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.verifyNull("contTaxonomy", content.getTaxonomy());
				CompareValuesUtility.verifyNull("contAltIds", content.getAltIds());
				CompareValuesUtility.verifyNull("contIsLongDescSup", content.getIsLongDescSuppress());
				//CompareValuesUtility.verifyNull("contIdentity", content.getIdentity());
				
				JsonArray catSubTyp = contentResp.getFtFields().get("catentrySubType").getAsJsonArray();
				CompareValuesUtility.compareValues("cont_ft.catentrySubType", "UVD-DUMMY+NV", catSubTyp.get(0).getAsString()+"+"+catSubTyp.get(1).getAsString());
				CompareValuesUtility.compareValues("cont_search", "UVD-DUMMY", contentResp.getSearchFieldValue("dispSite"), "dispSite");
				CompareValuesUtility.verifyNull("cont_search", contentResp.getSearchFieldValue("spinId"), "spinId");
				//CompareValuesUtility.verifyNull("cont_search", contentResp.getSearchFieldValue("ssin"), "ssin");
				//CompareValuesUtility.verifyNull("cont_search", contentResp.getSearchFieldValue("uid"), "uid");
				CompareValuesUtility.addNewMultiValuedFields();
				
			} catch (Exception e) {
				System.out.println(e.getMessage() + " Exception : " + contentId);
			}	
		}
		
		APIResponse<Offer> offerResp = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId);
		Offer offer = (Offer)offerResp.getT();
		
		if(offer == null){
			CompareValuesUtility.logFailed("offrId", offerId, "Offer not found in GB");
		}
		else
		{
			try {
				CompareValuesUtility.compareValues("offrId",offerId,offer.getId());
				CompareValuesUtility.compareValues("offrName","UVD-CLASS-CONTROL-PID",offer.getName());
				CompareValuesUtility.compareValues("offrDesc","UVD-CLASS-CONTROL-PID",offer.getDesc());
				CompareValuesUtility.compareValues("offrSrIsDispElig", true, offer.getOperational().getSites().getSears().getIsDispElig());
				/*if(hasKmart){
					CompareValuesUtility.compareValues("offrKmIsDispElig", true, offer.getOperational().getSites().getKmart().getIsDispElig());
				}*/
				
				CompareValuesUtility.verifyItemInList("offrSites", "sears", offer.getSites());
				/*if(hasKmart){
					CompareValuesUtility.verifyItemInList("offrSites", "kmart", offer.getSites());
				}*/
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.compareValues("offrClassifications", "NV", offer.getClassifications().getOfferType(), "offerType");
				CompareValuesUtility.verifyNull("offrClassifications", offer.getClassifications().getIsUvd(), "isUvd");
				CompareValuesUtility.verifyNull("offrClassifications", offer.getClassifications().getIsAutomotive(), "isAutomotive");
				CompareValuesUtility.verifyNull("offrClassifications", offer.getClassifications().getIsFitmentRequired(), "isFitmentRequired");
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.verifyNull("offrTaxMaster", offer.getTaxonomy().getMaster());
				CompareValuesUtility.verifyNull("offrTaxWeb", offer.getTaxonomy().getWeb());
				CompareValuesUtility.verifyNull("offrAltIds", offer.getAltIds());
				
				verifyStoreTaxonomy(productOffer, offer.getTaxonomy().getStore().getHierarchy());
				
				CompareValuesUtility.compareValues("offrIdentity", contentId, offer.getIdentity().getParentId(), "parentId");
				//CompareValuesUtility.verifyNull("offrIdentity", offer.getIdentity().getSsin(), "ssin");
				//CompareValuesUtility.verifyNull("offrIdentity", offer.getIdentity().getUid(), "uid");
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.compareValues("offrFfm", "VD", offer.getFfm().getChannel(), "channel");
				CompareValuesUtility.compareValues("offrFfm", "Sears", offer.getFfm().getSoldBy(), "soldBy");
				CompareValuesUtility.compareValues("offrFfm", "Sears", offer.getFfm().getFulfilledBy(), "fulfilledBy");
				CompareValuesUtility.compareValues("offrFfm", "00000000", offer.getFfm().getWrhsLcns().get(0), "wrhsLcn");
				CompareValuesUtility.verifyNull("offrFfm", offer.getFfm().getIsSTSElig(), "isSTSElig");
				CompareValuesUtility.verifyNull("offrFfm", offer.getFfm().getIsSResElig(), "isSResElig");
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.compareValues("offr_ft", "UVD-DUMMY", offerResp.getFtFieldValue("pgrmType"), "pgrmType");
				CompareValuesUtility.compareValues("offr_ft", "NV", offerResp.getFtFieldValue("offerType"), "offerType");
				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.compareValues("offr_search", "UVD-DUMMY", offerResp.getSearchFieldValue("dispSite"), "dispSite");
				CompareValuesUtility.compareValues("offr_search", contentId, offerResp.getSearchFieldValue("parentId"), "parentId");
				CompareValuesUtility.verifyNullOrEqual("offr_search", this.hierarchy, offerResp.getSearchFieldValue("hierarchy"), "hierarchy");
				//CompareValuesUtility.verifyNull("offr_search", offerResp.getSearchFieldValue("ssin"), "ssin");
				//CompareValuesUtility.verifyNull("offr_search", offerResp.getSearchFieldValue("uid"), "uid");
				CompareValuesUtility.verifyNull("offr_search", offerResp.getSearchFieldValue("spinId"), "spinId");
				CompareValuesUtility.addNewMultiValuedFields();

			} catch (Exception e) {
				System.out.println(e.getMessage() + " Exception : "+ offerId);
			}
		}
		
		CompareValuesUtility.setupResult(imaClassControlPid + "", true);
	}
	
	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,List<Hierarchy> hierarchy){

		long XMLHierarchyId;

		if (xmlProductOffer.getCoreHierarchyId() == null){
			return;
		}
		XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();

		List<String> lstPaths = new LinkedList<String>();
		List<String> lstids = new LinkedList<String>();
		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, XMLHierarchyId+"");

		String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");
		this.hierarchy = name;
		String idpath = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{path{idPath}}}}");

		name = name.replace("SRWI", "");
		name = name.replace("KWSC", "");

		lstPaths.addAll(Arrays.asList(name.split("-")));

		lstids.addAll(Arrays.asList(idpath.split("\\|")));

		if (lstPaths.isEmpty()) {
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId", "null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (hierarchy.size() == 0) {
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		int iHierarchy = 0;

		for (Hierarchy hrchy_ : hierarchy) {
			compareValues("store-taxo-name", lstPaths.get(iHierarchy),hrchy_ == null ? null : hrchy_.getName());
			compareValues("store-taxo-id", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getId());
			//TODO
			//compareValues("store-taxo-spinid", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getSpinId());
			iHierarchy++;
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
}
