package com.shi.content.ziptests;

import com.google.gson.Gson;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class ZipCodeHelper {

	public static com.generated.vos.zipOld.ZipcodeOld  getOldZip(String zipCode)
	{
		String oldZipJson ="";
		try {

			Gson gsn = new Gson();

			oldZipJson =  RestExecutor.getJSonResponseById(CollectionValuesVal.ZIP_OLD, zipCode);

			oldZipJson = oldZipJson.replaceFirst("\\[", "");
			oldZipJson = oldZipJson.substring(0,oldZipJson.length()-1);

			return gsn.fromJson(oldZipJson, com.generated.vos.zipOld.ZipcodeOld.class);
			
		} catch (Exception e) {
			
			System.out.println(oldZipJson);
			System.out.println("Exception for zipcode.... "+zipCode);
			e.printStackTrace();

			return null;
		}
	}

}
