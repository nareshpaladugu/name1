package com.shi.content.storeloadtests;

public class TaxGeoCountyVO {

	String storeID;
	String countyCode;
	String geoCode;

	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}

	public String getStoreID() {
		return storeID;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}

	public String getGeoCode() {
		return geoCode;
	}

}
