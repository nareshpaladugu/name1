package com.shi.content.matching;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.bson.Document;
import org.testng.annotations.Test;

import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;

/**
 * @author ddaphal
 *
 */
public class MatchingTest 
{
	public static List<String> exceptionVerticals = null;
	
	public static Set<String> lstOfSpecificSSINs = null;
	
	public static Set<String> lstOfTestedSSINs = null;
	
	@Test(groups="MatchingTest")
	public void verifyMatching()
	{
		lstOfTestedSSINs = new HashSet<String>();
		
		exceptionVerticals = Arrays.asList(System.getProperty("exceptionVerticals","8").split(","));
		
		System.out.println("-----------------------------------");
		System.out.println("exceptionVerticals.... "+exceptionVerticals);
		System.out.println("-----------------------------------");
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		String SSINunderTest;

		MongoClient mongoClient=null;
		
		try {
			mongoClient = MongoDBClient.connectToMongoDB();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Document match=null;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("list"))
		{
			if(LoadProperties.RUN_PARAMS.isEmpty())
			{
				LoadProperties.setCustomMsgForEmail("RunParams need to be specified in list mode",MSGTYPE.ERROR);
				return;
			}
			
			lstOfSpecificSSINs = new HashSet<String>();
			
			lstOfSpecificSSINs.addAll(Arrays.asList(LoadProperties.RUN_PARAMS.trim().split(",")));
			
			match = new Document("_search.ssin",new Document("$in",lstOfSpecificSSINs));
		}
		else
		{
			match = new Document("_search.ssin",new Document("$exists",true));
		}


		MongoDatabase db = mongoClient.getDatabase("offer");

		MongoCollection<Document> dbCollection = db.getCollection("offer");

		/*================Match criteria===============*/

		Document matchDocument = new Document("$match",match);

		Document limitDocument = null;

		int iLimit = LoadProperties.TESTDATALIMIT;

		if(iLimit!=-1)
		{
			limitDocument = new Document("$limit",iLimit);
		}
		
		/*================group criteria===============*/

		Document groupDocument = Document.parse("{ \"$group\" : { \"_id\" : { \"ssin\" : \"$_search.ssin\" }, " +
				" \"OfferList\" : {   \"$addToSet\" :{  " +
				" \"masterVertical\":\"$_blob.offer.taxonomy.master.hierarchy.id\", " +
				" \"brandName\":\"$_blob.offer.brandName\"," +
				" \"offerType\":\"$_blob.offer.classifications.offerType\"," +
				" \"isUvd\":\"$_blob.offer.classifications.isUvd\"," +
				" \"upc\":\"$_blob.offer.altIds.upc\"," +
				" \"spinId\":\"$_blob.offer.altIds.spinId\"," +
				" \"uid\":\"$_blob.offer.identity.uid\"," +
				" \"webHie\":\"$_blob.offer.taxonomy.web.sites\"," +
				" \"ssin\":\"$_blob.offer.identity.ssin\"," +
				" \"parentId\":\"$_blob.offer.identity.parentId\"," +
				" \"model\":\"$_blob.offer.modelNo\",  " +
				" \"offerId\":\"$_blob.offer.id\", " +
				" \"pgrmType\":\"$_ft.pgrmType\"," +
				" \"hierarchy\":\"$_search.hierarchy\"," +
				" \"pkgQty\":\"$_blob.offer.packageQty\"," +
				" \"defattr\":\"$_blob.offer.definingAttrs\"} } } }");

		/*================Projection Field===============*/
		
		Document projectDocument = Document.parse("" +
				"{\"$project\":{\"_search.ssin\":1," +
				"\"_blob.offer.taxonomy.master.hierarchy.id\":1," +
				"\"_blob.offer.taxonomy.web.sites\":1," +
				"\"_blob.offer.brandName\":1," +
				"\"_blob.offer.classifications.offerType\":1," +
				"\"_blob.offer.classifications.isUvd\":1," +
				"\"_blob.offer.altIds.upc\":1," +
				"\"_blob.offer.altIds.spinId\":1," +
				"\"_blob.offer.identity.uid\":1," +
				"\"_blob.offer.identity.parentId\":1," +
				"\"_blob.offer.modelNo\":1," +
				"\"_blob.offer.id\":1," +
				"\"_ft.pgrmType\":1," +
				"\"_search.hierarchy\":1," +
				"\"_blob.offer.definingAttrs\":1," +
				"\"_blob.offer.packageQty\":1}}");


		List<Document> pipeline;

		if(iLimit!=-1)
		{
			pipeline = Arrays.asList(matchDocument,projectDocument,groupDocument,limitDocument);
		}
		else
		{
			pipeline = Arrays.asList(matchDocument,projectDocument,groupDocument);
		}

		AggregateIterable<Document> aggOutput = dbCollection.aggregate(pipeline).batchSize(25).allowDiskUse(true);

		Document singleDocument;

		MongoCursor<Document> it = aggOutput.iterator();

		while(it.hasNext())
		{

			singleDocument = it.next();

			SSINunderTest =  JsonStringParser.clean(JsonStringParser.getJsonValueNew(singleDocument.toJson().toString(), "_id.ssin"));

			if(SSINunderTest==null || SSINunderTest.trim().isEmpty())
			{
				continue;
			}
			
			if(lstOfSpecificSSINs!=null && !lstOfSpecificSSINs.isEmpty())
				lstOfTestedSSINs.add(SSINunderTest);

			pool.execute(new MatchingTestVerification(SSINunderTest, singleDocument.toJson().toString()));
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

		
		lstOfSpecificSSINs.removeAll(lstOfTestedSSINs);
		
		for (String untestedSSIN : lstOfSpecificSSINs) {
			
			CompareValuesUtility.init();
			
			CompareValuesUtility.logFailed("SSIN",untestedSSIN, "Not Found");
			
			CompareValuesUtility.setupResult(untestedSSIN, true);
			
		}
		
		System.out.println("-------------Reset Mongo Client---------------");
		MongoDBClient.resetmongoGBClient();
		System.out.println("----------------------------------------------");

		System.out.println("END of Test !");
	}
}
