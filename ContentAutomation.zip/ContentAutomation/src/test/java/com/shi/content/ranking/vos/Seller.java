package com.shi.content.ranking.vos;

public class Seller {
	private Programs programs;
	private String sellerTier;
	private StoreFront storeFront;

	public Programs getPrograms() {
		return programs;
	}

	public void setPrograms(Programs programs) {
		this.programs = programs;
	}
	
	public String getSellerTier() {
		return sellerTier;
	}

	public void setSellerTier(String sellerTier) {
		this.sellerTier = sellerTier;
	}
	
	public StoreFront getStoreFront() {
		return storeFront;
	}

	public void setStoreFront(StoreFront storeFront) {
		this.storeFront = storeFront;
	}

}
