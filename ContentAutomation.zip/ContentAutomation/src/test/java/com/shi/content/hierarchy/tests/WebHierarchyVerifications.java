package com.shi.content.hierarchy.tests;


import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logPassed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyInListField;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.DispAttr;
import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.hierarchy.ParentId;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.hierarchy.Tag;
import com.generated.xmls.webhierarchy.Attribute;
import com.generated.xmls.webhierarchy.DisplayableAttributes;
import com.generated.xmls.webhierarchy.Node;
import com.generated.xmls.webhierarchy.RetiredNode;
import com.generated.xmls.webhierarchy.TagSet;
import com.generated.xmls.webhierarchy.types.TypeType;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class WebHierarchyVerifications implements Runnable{
	
	List<Node> wNodeList;
	List<RetiredNode> retiredNodeList;
	HierarchyCommons hierarchyUtils;
	Integer siteId;
	String sCID = null;
	boolean isLeaf;
	int iLevelToverify = 1;
	String sSite = null;
	
	static Map<String, Map<String,String>> redirectNodeData = new HashMap<String, Map<String, String>>();
//	private static String IDPATH = "IDPATH";
//	private static String CIDPATH = "CIDPATH";
//	private static String DISPLAYPATH = "DISPLAYPATH";
	
	public WebHierarchyVerifications(List<Node> wNodeListToTest, HierarchyCommons commonUtils, Integer siteID){
		this.wNodeList = wNodeListToTest;
		this.hierarchyUtils = commonUtils;
		this.siteId = siteID;
	}
	
	public WebHierarchyVerifications(List<RetiredNode> wNodeListToTest, Integer siteID){
		this.retiredNodeList = wNodeListToTest;
		this.siteId = siteID;
	}
	
	
	
	@Override
	public void run() {
	
		if(wNodeList != null){
			for(Node n : wNodeList){
				CompareValuesUtility.init();
				try{
					if(n.getId() == 0 )
						continue;
					long l1 = System.currentTimeMillis();
					//Hierarchy gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEBHIERARCHY, String.valueOf(n.getId()));
					APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.WEB_HIERARCHY, String.valueOf(n.getId()));
					Hierarchy gbHierarchy = allResponse.getT();
					//If null is returned, then the id is missing from hierarchy collection
					if(gbHierarchy == null){
						CompareValuesUtility.logFailed("Id", n.getId(), "Not found");
						CompareValuesUtility.setupResult(String.valueOf(n.getId()), true);
						continue;
					}
					verifyNode(n,gbHierarchy,siteId );
					verifyFt(allResponse);
					if (n.getId()!=0) {
						verifySearch(allResponse);
					}
					
					CompareValuesUtility.setupResult(String.valueOf(n.getId()), true);
					long l2 = System.currentTimeMillis();
					System.out.println("Full for "+ n.getId()+ "  "+ (l2-l1));
				}catch(Throwable e){
					System.out.println("Check this id :"+ n.getId());
					e.printStackTrace();
				}finally{
					CompareValuesUtility.teardown();
				}
			}
		}
		
		if(retiredNodeList != null){
			for(RetiredNode rNode : retiredNodeList){
				CompareValuesUtility.init();
				try{
					Hierarchy gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, String.valueOf(rNode.getId()));
					//If null is returned, then the id is missing from hierarchy collection
					if(gbHierarchy == null){
						CompareValuesUtility.logPassed("Id", rNode.getId(), "Retired node not found in GB");
						CompareValuesUtility.setupResult(String.valueOf(rNode.getId()), true);
						continue;
					}
					verifyRetiredNode(rNode, gbHierarchy);
					CompareValuesUtility.setupResult(String.valueOf(rNode.getId()), true);
				}catch(Throwable e){
					System.out.println("Check this id :"+ rNode.getId());
					e.printStackTrace();
				}finally{
					CompareValuesUtility.teardown();
				}
			}
		}
		
	}
	

	public void verifyNode(Node xmlNode, Hierarchy gbHierarchy, long lSiteId){
		compareValues("Id", xmlNode.getId(), gbHierarchy.getId());
		CompareValuesUtility.verifyNull("Retired",gbHierarchy.getRetired());
		if(xmlNode.getId() == 0){
			verifyNull("CId", gbHierarchy.getCid());
		}else{
			this.sCID = hierarchyUtils.fetchCatGroupId(xmlNode.getId());
			//CompareValuesUtility.verifyNullOrEqual("CId", this.sCID, gbHierarchy.getCid()); //WCS Migration
			CompareValuesUtility.verifyNotNull("CId", gbHierarchy.getCid());
		}
		compareValues("Name", xmlNode.getName(), gbHierarchy.getName());
		compareValues("Rank", xmlNode.getRank() , this.convertToIntFromDouble(gbHierarchy.getRank()));
		sSite = xmlNode.getId()==0?null:getSite(lSiteId);
		//compareValues("Site", xmlNode.getId()==0?null:getSite(lSiteId) ,gbHierarchy.getSite() );
		compareValues("Site", sSite ,gbHierarchy.getSite().toString() );
		compareValues("Type", "web", gbHierarchy.getType().toString());
		isLeaf = hierarchyUtils.isLeafNode(xmlNode.getId(),false);
		//compareValues("isLeafNode",hierarchyUtils.isLeafNode(xmlNode.getId(),false), gbHierarchy.getIsleaf());
		compareValues("isLeafNode",isLeaf, gbHierarchy.getIsLeaf());
//		verifyNullOrEqual("Retired", null, gbHierarchy.getRetired());
		
		//Verify parent id in xml node is part of parent ids array
		if(xmlNode.getId() == 0){
			verifyNull("ParentId", gbHierarchy.getParentIds().get(0).getId());
			compareValues("ParentIdPrimary?",true,gbHierarchy.getParentIds().get(0).getIsPrimary());
		}else{
			int iParentPosition = verifyInListField("ParentId", String.valueOf(xmlNode.getParentNodeId()), gbHierarchy.getParentIds(),"id", ParentId.class);
			compareValues("ParentIdPrimary?",true, (iParentPosition != -1)?gbHierarchy.getParentIds().get(iParentPosition).getIsPrimary():"Not found");
		}
		verifySecondaryParents(xmlNode.getId(), gbHierarchy.getParentIds());
		
		CompareValuesUtility.addNewMultiValuedFields();
		
		String sPrimaryPath = verifyPrimaryPath(xmlNode, gbHierarchy);
		if(xmlNode.getParentNodeId() != 0)
			verifySecondaryPaths(xmlNode.getId(),sPrimaryPath, gbHierarchy.getPath());
		
		CompareValuesUtility.addToHeaders(new String[]{"No. of Tags","TagType","TagName"});
		if(xmlNode.getTags() != null)
			verifyTags(xmlNode.getTags().getTagSet(), gbHierarchy.getAttrs().getTags());
		
		CompareValuesUtility.addToHeaders(new String[]{"DispAttrsCount","DispAttrId","DispAttrRank","DispAttrType"});
		
		verifyDisplayAttributes(xmlNode.getDisplayableAttributes(), gbHierarchy.getAttrs());
		
		CompareValuesUtility.addNewMultiValuedFields();
		for(long lId : xmlNode.getMasterHierachyId()){//String.valueOf(Long.valueOf(lId).intValue()
			CompareValuesUtility.verifyTrue(gbHierarchy.getMasterHierarchyIds().contains(this.convertToString(lId)), "MasterHierarchyId", lId, gbHierarchy.getMasterHierarchyIds());
		}
		if(xmlNode.getMasterHierachyId().length > 1)
			CompareValuesUtility.addNewMultiValuedFields();
		
//		CompareValuesUtility.addNewMultiValuedFields();
		//To check for link nodes
		
	}
	
	/**
	 * Verify secondary parents list
	 * @param id
	 * @param parentIds
	 */
	private void verifySecondaryParents(long id, List<ParentId> parentIds) {
		if(parentIds.size() == 1)
			return;
		List<String> lstLinkedParentIds = hierarchyUtils.fetchParentIdsFromXML(String.valueOf(id), false, false);
		for(String sLinkedParentId: lstLinkedParentIds){
			int i = verifyInListField("ParentId", sLinkedParentId, parentIds,"id", ParentId.class);
			compareValues("ParentIdPrimary?",false,(i != -1)?parentIds.get(i).getIsPrimary():"Parent id Not found");
		}
		
	}

	
	private String verifyPrimaryPath(Node xmlNode, Hierarchy gbHierarchy){
		
		String xmlDisplayPath = "";
		try{
			String[] nameLst = xmlNode.getDisplayPath().split("\\"+HierarchyCommons.SEPARATOR);
			for(String name : nameLst){
				xmlDisplayPath = xmlDisplayPath + name.trim() + "|";
			}
			xmlDisplayPath = xmlDisplayPath.substring(0,xmlDisplayPath.length()-1);
		}catch(Exception e){
			xmlDisplayPath = xmlNode.getDisplayPath();
		}
		
		//int i = verifyInListField("DisplayPath", xmlNode.getDisplayPath(), gbHierarchy.getPath(),"displayPath",Path.class);
		int i = verifyInListField("DisplayPath", xmlDisplayPath, gbHierarchy.getPath(),"displayPath",Path.class);
		//int iLevelToverify = 1;
		String sExpIDPath = null;
		if(i!= -1){
			//Check if first level node
			
			if(xmlNode.getParentNodeId() == 0){
				if(xmlNode.getId() == 0){
					verifyNull("CIDPath", gbHierarchy.getPath().get(i).getCidPath());
				}
				else{
					//CompareValuesUtility.verifyNullOrEqual("CIDPath",this.sCID, gbHierarchy.getPath().get(i).getCidPath()); //WCS Migration
					CompareValuesUtility.verifyNotNull("CIDPath", gbHierarchy.getPath().get(i).getCidPath());
				}
				compareValues("IdPath", xmlNode.getId(), gbHierarchy.getPath().get(i).getIdPath());
				sExpIDPath = String.valueOf(xmlNode.getId());
				
			}else{
				sExpIDPath = hierarchyUtils.formPrimaryIdPath(xmlNode.getId(),false);
				iLevelToverify = sExpIDPath.split("\\"+HierarchyCommons.SEPARATOR).length;
				//CompareValuesUtility.verifyNullOrEqual("CIDPath", hierarchyUtils.fetchPrimaryCIDPath(xmlNode.getId()), gbHierarchy.getPath().get(i).getCidPath()); //WCS Migration
				CompareValuesUtility.verifyNotNull("CIDPath", gbHierarchy.getPath().get(i).getCidPath());
				compareValues("IdPath",sExpIDPath , gbHierarchy.getPath().get(i).getIdPath());
			}
			compareValues("IsPrimaryPath", true, gbHierarchy.getPath().get(i).getIsPrimary());
			compareValues("Level", iLevelToverify, gbHierarchy.getLevel());
		}
//		long l2 = System.currentTimeMillis();
//		System.out.println("verifyPrimPath: "+ (l2-l1));
		return sExpIDPath;
	}
	
	private void verifySecondaryPaths(long id, String sPrimaryPath, List<Path> lstGbPath) {
		List<List<String>> allPaths = hierarchyUtils.fetchAllPaths(String.valueOf(id));
		List<String> idPaths, cidPaths, displayPaths;
		idPaths = allPaths.get(0);
		displayPaths = allPaths.get(1);
		cidPaths = allPaths.get(2);
		for(int iPath=0; iPath< idPaths.size(); iPath++){
			//Do not validate primary path since it's already validated
			if(idPaths.get(iPath).equals(sPrimaryPath) || displayPaths.get(iPath).contains("Retired|"))
				continue;
			int i = CompareValuesUtility.getPositionInList(idPaths.get(iPath), lstGbPath,"idPath" , Path.class);
			compareValues("DisplayPath", displayPaths.get(iPath), (i != -1)?lstGbPath.get(i).getDisplayPath():"Not found");
			//CompareValuesUtility.verifyNullOrEqual("CIDPath", cidPaths.get(iPath), (i != -1)?lstGbPath.get(i).getCidPath():"Not found"); //WCS Migration
			CompareValuesUtility.verifyNotNull("CIDPath", (i != -1)?lstGbPath.get(i).getCidPath():null);
			compareValues("IdPath", idPaths.get(iPath), (i != -1)?lstGbPath.get(i).getIdPath():"Not found");
			compareValues("IsPrimaryPath", false, (i != -1)?lstGbPath.get(i).getIsPrimary():"Not found");
		}
		if(idPaths.size() > 1)
			CompareValuesUtility.addNewMultiValuedFields();
		
		//for each parent fetch all paths
	}
	
	private void verifyDisplayAttributes(
			DisplayableAttributes[] displayableAttributes,
			Attrs gbAttrs) {
		List<DispAttr> gbDispAttrs = null;
		if(displayableAttributes != null && displayableAttributes.length > 0){
			if(gbAttrs == null){
				logFailed("DispAttrId", displayableAttributes.length, "null");
				return;
			}
						
			else{
				CompareValuesUtility.addNewMultiValuedFields();
				gbDispAttrs = gbAttrs.getDispAttrs();
			}
		}
		for(int i= 0; i< displayableAttributes.length; i++){
			for(int j=0; j < displayableAttributes[i].getAttribute().length; j++){
				Attribute displayAttrib = displayableAttributes[i].getAttribute()[j];
				List<TypeType> abc = Arrays.asList(displayAttrib.getType());//String.valueOf(Long.valueOf(displayAttrib.getId()).intValue())
				List<String>  lowerCasedType = new ArrayList<String>();
				for(TypeType t : abc){
					lowerCasedType.add(t.value().toLowerCase());
				}
				int iListPos =verifyInListField("DispAttrId", this.convertToString(displayAttrib.getId())+".0", gbDispAttrs, "id", DispAttr.class );
				compareValues("DispAttrRank",displayAttrib.getRank(), (iListPos != -1)?gbDispAttrs.get(iListPos).getRank().intValue():"DispAttrId not found");
				
				compareValues("DispAttrType",lowerCasedType, (iListPos != -1)?gbDispAttrs.get(iListPos).getType():"DispAttrId not found");
					
			}
		}
		
		
	}
	
	
	
	public void verifyTags(TagSet[] xmlTags, List<Tag> gbTags){
		if(xmlTags.length > 0)
			CompareValuesUtility.addNewMultiValuedFields();
		compareValues("No. of Tags", xmlTags.length, gbTags.size());
		
		for(TagSet xmlTSet: xmlTags){
			int i = verifyInListField("TagType", xmlTSet.getNamespace(), gbTags, "type", Tag.class);
			if(i != -1){
				for(String s : xmlTSet.getTag()){
					if(gbTags.get(i).getName().contains(s))
						logPassed("TagName", s, s);
					else
						logFailed("TagName", s, "Found : "+gbTags.get(i).getName());
				}
			}
		}
	}
	
	private void verifySearch(APIResponse<Hierarchy> allResponse) {
		CompareValuesUtility.addNewMultiValuedFields();
		//CompareValuesUtility.verifyNullOrEqual("_search.cid", sCID, allResponse.getSearchFieldValue("cid")); //WCS Migration
		CompareValuesUtility.verifyNotNull("_search.cid", allResponse.getSearchFieldValue("cid"));
	}
	
	public void verifyFt(APIResponse<Hierarchy> allResponse){
		CompareValuesUtility.addNewMultiValuedFields();
		compareValues("_ft.leaf", isLeaf, allResponse.getFtFieldValue("leaf"));
		compareValues("_ft.level", iLevelToverify, allResponse.getFtFieldValue("level"));
		compareValues("_ft.site", sSite, allResponse.getFtFieldValue("site"));
	}
	
	public String getSite(long siteId){
		//Long.valueOf(siteId).intValue()
		switch(convertToIntFromDouble(siteId)){
		case 1 :
			return "kmart";
		case 2:
			return "sears";
		case 4:
			return "mygofer";
		case 5:
			return "kenmore";
		case 6:
			return "craftsman";
		case 7:
			return "insco";
		case 8:
			return "tgi";
		case 11:
			return "puertorico";
		default:
			return null;
			
		}
	}
		public Integer convertToIntFromDouble(Object d){
			if(d == null)
				return null;
			else{
				if(d instanceof Long )
					return ((Long)d).intValue();
				else if(d instanceof Double)
					return ((Double)d).intValue();
				else 
					return null;
			}
		}
		
		public String convertToString(Object d){
			if(d == null)
				return null;
			else{
				if(d instanceof Long )
					return String.valueOf(((Long)d).intValue());
				else if(d instanceof Double)
					return String.valueOf(((Double)d).intValue());
				else 
					return null;
			}
		}
		
		/**
		 * Verifications for retired node
		 * retired should be set to true
		 * all child nodes of this retired node id should be updated with paths based on redirect node id
		 * @param rNode
		 * @param gbHierarchy
		 */
		private void verifyRetiredNode(RetiredNode rNode, Hierarchy gbHierarchy) {
			compareValues("Id", rNode.getId(), gbHierarchy.getId());
			compareValues("Retired", 1, gbHierarchy.getRetired());
			
			
			//NV - Commenting the below till the time a 
			//Fetch all ids where this was parent - dom parser
			/*List<String> childIds = fetchAllChildNodes(rNode.getId());
			
			
			String redirectNodeId = rNode.getRedirectNode().toString();
			if(redirectNodeId != null){
				
				//Fetch data (primary idpath, cidpath, displaypath of redirect node id
				Map<String, String> paths = fetchPaths(redirectNodeId);
				
				//Fetch all ids in webhierarchy
				List<Hierarchy> childHierarchies =  RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, childIds);
				
				//For each id verify 
				for(Hierarchy childHierarchy : childHierarchies){
					//Verify parentId changed to redirectNode
					compareValues("ChildHierarchyId", childHierarchy.getId(), childHierarchy.getId());
					 CompareValuesUtility.verifyTrue(childHierarchy.getParentIds().contains(redirectNodeId),
							 "ParentIds", "Redirect Node added", "Redirect Node not found");
					 StringBuilder failedIdPath = new StringBuilder();
							 //IdPath
					 for(Path eachPath : childHierarchy.getPath()){
						 
						if(!( eachPath.getIdPath().startsWith(paths.get(IDPATH)) 
						 || !eachPath.getIdPath().contains(gbHierarchy.getPath().get(0).getIdPath()))){
							failedIdPath.append(eachPath.getIdPath());
						}
						
						if(!( eachPath.getDisplayPath().startsWith(paths.get(DISPLAYPATH)) 
								 || !eachPath.getDisplayPath().contains(gbHierarchy.getPath().get(0).getDisplayPath()))){
									failedIdPath.append(eachPath.getDisplayPath());
								}
						
						if(!( eachPath.getCidPath().startsWith(paths.get(CIDPATH)) 
								 || !eachPath.getCidPath().contains(gbHierarchy.getPath().get(0).getCidPath()))){
									failedIdPath.append(eachPath.getCidPath());
								}
							
						 
					 }
					
					
					//For all paths where rNode id appeared, verify it is replaced with idpath, cidpath, displaypath of redirect node
				}
					
				
			}else
				return;
			*/
			
		}
		
		/*private List<String> fetchAllChildNodes(Long id) {
			return null;
		}

		*//**
		 * Fetch primary path of redirect node id
		 *//*
		public Map<String, String> fetchPaths(String id){
			
			if(redirectNodeData.get(id) != null){
				return redirectNodeData.get(id) ;
			}
			Hierarchy retiredNodeId = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, id);
			
			Map<String,String> pathsMap = new HashMap<String,String>();
			pathsMap.put(IDPATH, retiredNodeId.getPath().get(0).getIdPath());
			pathsMap.put(CIDPATH, retiredNodeId.getPath().get(0).getCidPath());
			pathsMap.put(DISPLAYPATH, retiredNodeId.getPath().get(0).getDisplayPath());
			
			redirectNodeData.put(id, pathsMap);
			
			return pathsMap;
			
		}*/
	}
	


	
	
	/*@Test
	public void verifyIdPath(){
		hierarchyUtils = new HierarchyCommons("src/main/resources/web-hierarchy-2.xml");
//		hierarchyUtils.formIdPath(2114);
		List<List<String>> a = hierarchyUtils.fetchPath("19247610");
		for(String sPath: a.get(2))
			System.out.println(sPath);
		
	}
	
	/*if(iListPos != -1){
						boolean bFound = false;
						for(TypeType t :displayAttrib.getType()){
							bFound = false;
							for(Type gbType : gbDispAttrs.get(iListPos).getType()){
								if(t.name().equals(gbType.name())){
										logPassed("DispAttrType", t.name(), gbType.name());
										bFound = true;
										break;
								}
							}
							logFailed("DispAttrType", t.name(), "Not found");
						}
					}else
						logFailed("DispAttrType","sdf" , "Not found");*/
	
	
	
 