package com.shi.content.wcstogb.giftRegi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.db.DBUtil;

public class ItemCollectionTest 
{
	public static int ctr=0;

	@Test(groups="GiftRegistry-registryItemCollectionTest")
	public void registryItemCollectionTest()
	{

		if(CommonGiftReg.database==null)
		{
			LoadProperties.setCustomMsgForEmail("Check MongoDb Connection",MSGTYPE.ERROR);
			return;
		}

		String sQuery = "select  "+ 
				" item.GIFTITEM_ID as GRGFTITM_GIFTITEM_ID,  "+ 
				" item.GIFTREGISTRY_ID as GRGFTITM_GIFTREGISTRY_ID,  "+ 
				" item.QUANTITYREQUESTED as GRGFTITM_QUANTITYREQUESTED,  "+ 
				" item.QUANTITYBOUGHT as GRGFTITM_QUANTITYBOUGHT,  "+ 
				" item.FIELD1 as GRGFTITM_FIELD1,  "+ 
				" item.FIELD2 as GRGFTITM_FIELD2,  "+ 
				" item.OPTCOUNTER as GRGFTITM_OPTCOUNTER,  "+ 
				" item.CREATETIME as GRGFTITM_CREATETIME,  "+ 
				" item.LASTUPDATE as GRGFTITM_LASTUPDATE,  "+ 
				" item.LOCATION as GRGFTITM_LOCATION,  "+ 
				" item.PARTNUMBER as GRGFTITM_PARTNUMBER,  "+ 
				" item.PARTAUXKEY as GRGFTITM_PARTAUXKEY,  "+ 
				" item.FIELD3 as GRGFTITM_FIELD3,  "+ 
				" item.FIELD4 as GRGFTITM_FIELD4,  "+ 
				" item.FIELD5 as GRGFTITM_FIELD5,  "+ 
				" xitem.GIFTITEM_ID as XGRGFTITM_GIFTITEM_ID,  "+ 
				" xitem.STOREITEMCOUNT as XGRGFTITM_STOREITEMCOUNT,  "+ 
				" xitem.FIELD1 as XGRGFTITM_FIELD1,  "+ 
				" xitem.FIELD2 as XGRGFTITM_FIELD2,  "+ 
				" xitem.FIELD3 as XGRGFTITM_FIELD3,  "+ 
				" xitem.FIELD4 as XGRGFTITM_FIELD4,  "+ 
				" xitem.FIELD5 as XGRGFTITM_FIELD5,  "+ 
				" xitem.OPTCOUNTER as XGRGFTITM_OPTCOUNTER,  "+ 
				" xitem.ITMADDEDFROM as XGRGFTITM_ITMADDEDFROM,  "+ 
				" xitem.TEMPITMFLG as XGRGFTITM_TEMPITMFLG,  "+ 
				" xitem.PERSONALTHANKYOU as XGRGFTITM_PERSONALTHANKYOU,  "+ 
				" xitem.INSTOREONLYNOTES as XGRGFTITM_INSTOREONLYNOTES,  "+ 
				" xitem.INSTOREONLYITMFLAG as XGRGFTITM_INSTOREONLYITMFLAG,  "+ 
				" xitem.NPOSGRMSG as XGRGFTITM_NPOSGRMSG,  "+ 
				" xitem.ITEMBOUGHTFROM as XGRGFTITM_ITEMBOUGHTFROM,  "+ 
				" xitem.STOREUNITID as XGRGFTITM_STOREUNITID,  "+ 
				" xitem.INSTOREPURCHASEDATE as XGRGFTITM_INSTOREPURCHASEDATE "+ 
				" from GRGFTITM  item,  XGRGFTITM xitem "+  // LEFT OUTER JOIN
				" where item.GIFTITEM_ID =  xitem.GIFTITEM_ID "+ 
				" HARDCODED_IDS "+
				" order by item.GIFTREGISTRY_ID "+ 
				" PHOLDER with ur";

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("LIST"))
		{
			String sp[] = LoadProperties.RUN_PARAMS.split(",");

			sQuery = sQuery.replaceFirst("PHOLDER", " ");
			sQuery = sQuery.replaceFirst("HARDCODED_IDS",
					"  and  item.GIFTREGISTRY_ID in ("+RegistryCollectionCache.getListToString(Arrays.asList(sp)) +")");
		}
		else
		{
			//AUTO
			sQuery = sQuery.replaceFirst("HARDCODED_IDS"," ");

			if(LoadProperties.TESTDATALIMIT!=-1)
				sQuery = sQuery.replaceFirst("PHOLDER", " fetch first "+LoadProperties.TESTDATALIMIT+" rows only ");
			else
				sQuery = sQuery.replaceFirst("PHOLDER", " ");
		}

		ResultSet resultSet = DBUtil.executeQueryReturnAll(sQuery);

		if(resultSet!=null)
		{
			String giftregistry_idOld = "";

			String giftregistry_idNew = null;

			List<Map<String,String>> mapForSingleGiftRegId = new ArrayList<Map<String,String>>();

			try {
				while(resultSet.next())
				{
					giftregistry_idNew = resultSet.getString("GRGFTITM_GIFTREGISTRY_ID");

					if(!giftregistry_idNew.equals(giftregistry_idOld))
					{
						//got new one and need to process old on
						if(!mapForSingleGiftRegId.isEmpty())
							pool.execute(new ItemCollectionVerifications(giftregistry_idOld,mapForSingleGiftRegId));

						mapForSingleGiftRegId = new ArrayList<Map<String,String>>();
					}

					Map<String, String> SingleRow = CommonGiftReg.getMap(resultSet);

					mapForSingleGiftRegId.add(SingleRow);

					giftregistry_idOld = giftregistry_idNew;
				}

				if(!mapForSingleGiftRegId.isEmpty())
					pool.execute(new ItemCollectionVerifications(giftregistry_idOld,mapForSingleGiftRegId));

			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			finally
			{
				DBUtil.closeCursor(resultSet);
			}
		}
		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}


	@BeforeSuite(groups="GiftRegistry-registryItemCollectionTest")
	public void startUp()
	{
		CommonGiftReg.getGiftRegMongoDB();
	}
}
