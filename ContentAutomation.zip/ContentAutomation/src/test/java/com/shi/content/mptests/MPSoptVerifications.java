package com.shi.content.mptests;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class MPSoptVerifications implements Runnable {
	
	
	static Map<String, Long> idToTS = new HashMap<String, Long>();
	static boolean bFileFound = false;
	private List<String> mpSoptMessages;
	private static final String FILENAME =  "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+".txt";

	private static final String PROCESSED_FILENAME = "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+"_Processed.txt";
	
	public MPSoptVerifications( ) {
	}
	
	
	@Test(description="Test MP SOPT messages for sopt days value", groups="MPSOPTVerifs")
	public void MPSoptTests(){
		
		readFromFileAndInitTimestamps();
			if(!(idToTS.size() == 0))
				bFileFound = true;
		
		
		BlockingQueue<List<String>> mpSoptDocs = new LinkedBlockingQueue<List<String>>();

		KafkaIAConsumer<String> mpSoptConsumerThread = new KafkaIAConsumer<String>(mpSoptDocs);		
		Thread tConsumerThread = new Thread(mpSoptConsumerThread);
		tConsumerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<String> nodeToTest;

				nodeToTest = mpSoptDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == mpSoptConsumerThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new MPSoptVerifications(nodeToTest));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public MPSoptVerifications(List<String> ids  ) {
		mpSoptMessages = ids;
	}

	@Override
	public void run() {
		
			
			for(String mpSoptMessage : this.mpSoptMessages){
				try{
					String id = JsonStringParser.getJsonValueNew(mpSoptMessage, "itemSopt.itemId");
					String type = JsonStringParser.getJsonValueNew(mpSoptMessage, "itemSopt.prgm");
					
					if(type.contains("FBM") || type.contains("DSS"))
						id = "SPM"+id;
					
					String getProcessingTime = JsonStringParser.getJsonValueNew(mpSoptMessage, "itemSopt.sopt");
					Double processingTime = Double.parseDouble(getProcessingTime);
				
					CompareValuesUtility.init();
					
					Offer offerDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);
					if(offerDoc == null){
						CompareValuesUtility.logFailed("Sopt", processingTime, "Offer not found");
						CompareValuesUtility.setupResult(id, true);
						continue;
					}
					Double soptDays = offerDoc.getShipping().getSoptDays();
					String modifiedTS = offerDoc.getMeta().getModifiedTs();
					System.out.println("Testing for : "+ id + " Sopt : " + soptDays  + "  Modified TS : "+ modifiedTS);
					
					CompareValuesUtility.addDataFieldForReport("ProgramType",type);
					CompareValuesUtility.compareValues("Sopt",Math.ceil((processingTime/(24*3600))),soptDays+"");
					if(bFileFound){
						
						Long insertTS = idToTS.get(id);
						CompareValuesUtility.addDataFieldForReport("GBTime", modifiedTS);
						if(insertTS == null){
							CompareValuesUtility.addDataFieldForReport("Insertime","Insert time not found");
						}
						else{
							String insertDate = getDate(insertTS, "yyyy-MM-dd HH:mm:ss.SSS");
							CompareValuesUtility.addDataFieldForReport("Insertime",insertDate );
							
							DateTime dtGBTime = JodaDateTimeUtility.convertToJodaFormat(modifiedTS);
							DateTime dtInsertTime = JodaDateTimeUtility.convertToJodaFormat(insertDate);
							if(dtGBTime == null)
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", "No modified ts in gb");
							else
								CompareValuesUtility.addDataFieldForReport("Difference(ms)", (dtGBTime.getMillis() - dtInsertTime.getMillis())+"");
						}
					}
					
									
					CompareValuesUtility.setupResult(id, true);
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Check this message "+ mpSoptMessage);
				}
			}
		}


/***
 * Method to read from file if available and create a map of id to timestamp
 */
	public void readFromFileAndInitTimestamps(){
		
		
		BlockingQueue<String> singleStoreProductPrice = new LinkedBlockingQueue<String>();
		TextFileParser<String> myParser = new TextFileParser<String>(FILENAME, singleStoreProductPrice);
		
		
		Thread t = new Thread(myParser);
		String newData;
		t.start();


		while (true) {
				try {
					newData = singleStoreProductPrice.poll(20, TimeUnit.SECONDS);
					if(newData.equals(myParser.POISON_PILL_STRING))
						break;
					if(newData != null){
						String[] idAndTS = newData.split(":");
						idToTS.put(idAndTS[0], Long.parseLong(idAndTS[1]));
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 

		}
	}
	
	/**
	 * Formats unix timestamp in specified {@code dateFormat}
	 * @param unixTS - Timestamp
	 * @param dateFormat - Format to convert to
	 * @return Converted date
	 */
	public static String getDate(long unixTS, String dateFormat)
	{
		
	    // Create a DateFormatter object for displaying date in specified format.
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
	    
	    // Create a calendar object that will convert the date and time value in milliseconds to date. 
	     Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("US/Central"));
	     calendar.setTimeInMillis(unixTS);
	     return formatter.format(calendar.getTime());
	}
	
	@AfterClass(groups="MPSOPTVerifs")
	public void markFileAsProcessed(){
		
		//If file was found during execution, mark it as processed.
		if(bFileFound){
			File oldProcessedFile =  new File(PROCESSED_FILENAME);
			if(oldProcessedFile.exists())
				oldProcessedFile.delete();
			
			File f = new File(FILENAME);
			File toCreateProcessedFile = new File(PROCESSED_FILENAME);
			f.renameTo(toCreateProcessedFile);
		}
	}

}
