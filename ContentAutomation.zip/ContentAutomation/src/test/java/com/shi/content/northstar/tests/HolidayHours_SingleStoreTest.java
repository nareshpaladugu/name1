package com.shi.content.northstar.tests;

import java.util.ArrayList;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shi.content.northstar.pages.HolidayHours;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * Test Holiday Hours are updating for Single Store
 * Updates Sunday Open Time for one selected store and verify the response of same store 
 * @author inaikwa
 *
 */
public class HolidayHours_SingleStoreTest extends NorthStarBaseTest {
	private ArrayList<String> listStoreIds;
	private String storeId;
	DriverLogger logger = new DriverLogger();
	
	@Test(description="Test to verify if the Holiday Dates are updating ", groups = {"NS-P1"})
	public void testUpdateHolidayDates() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();

		searchPage.searchByZipCode("03079");
		
		listStoreIds= searchPage.getAllSearsOpenNonICEEStores();

//		Kmart user
//		searchPage.searchByZipCode("95351");
//		listStoreIds = searchPage.getAllKmartOpenStores();
		
		Assert.assertNotNull(listStoreIds,  "Zero stores found, terminating......... ");
		
		storeId =listStoreIds.get(0);
		
		searchPage.clickStore(storeId);
		
		searchPage.searchPageEdit();
		
		HolidayHours eView = new HolidayHours();
		eView.goToHolidayHoursView();
		
		HashMap<String, String> newHoliday =eView.addHolidaySingleView();
		eView.saveDocument();
		
		Asserts.verifyTrue(eView.updateSuccessMsg(), "Verified that the Update success msg is displayed after adding New Holiday" );
		
		String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId);
		
		String hldyObj= JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.hldy");
		
		JsonParser jp = new JsonParser();
		
		JsonElement je = jp.parse(hldyObj);
		
		JsonArray noOfhlydays = je.getAsJsonArray();
		logger.log("Comparing Response for store : "+storeId+"...........", false);
		for (JsonElement jsonElement : noOfhlydays) {
				
			if(newHoliday.get("Date").equalsIgnoreCase(jsonElement.getAsJsonObject().get("dt").toString().replaceAll("\"", ""))
				&&newHoliday.get("OpenTime").substring(0,2).equalsIgnoreCase("0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("opn").toString().replaceAll("\"", ""))))/3600)
				&&newHoliday.get("CloseTime").substring(0,2).equalsIgnoreCase("0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("cls").toString().replaceAll("\"", ""))))/3600)
				&&newHoliday.get("Offset").substring(0,2).equalsIgnoreCase("0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("offstOpn").toString().replaceAll("\"", ""))))/3600)
					){
				
				Asserts.verifyEquals(newHoliday.get("Date"),jsonElement.getAsJsonObject().get("dt").toString().replaceAll("\"", ""),"Verified New Holiday date is updated successfully. "+
						"Entered Date : "+newHoliday.get("Date")+" Updated Date: "+jsonElement.getAsJsonObject().get("dt").toString().replaceAll("\"", ""));
				Asserts.verifyEquals(newHoliday.get("OpenTime").substring(0,2),"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("opn").toString().replaceAll("\"", ""))))/3600,"Verified New Holiday Open time is updated successfully. "+
						"Entered OpenTime : "+newHoliday.get("OpenTime").substring(0,2)+" Updated OpenTime : "+"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("opn").toString().replaceAll("\"", ""))))/3600		);
				Asserts.verifyEquals(newHoliday.get("CloseTime").substring(0,2),"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("cls").toString().replaceAll("\"", ""))))/3600,"Verified New Holiday Close time is updated successfully. "+
						"Entered OpenTime : "+newHoliday.get("CloseTime").substring(0,2)+" Updated OpenTime : "+"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("cls").toString().replaceAll("\"", ""))))/3600		);
				Asserts.verifyEquals(newHoliday.get("Offset").substring(0,2),"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("offstOpn").toString().replaceAll("\"", ""))))/3600,"Verified New Holiday Offset  is updated successfully. "+
						"Entered Offset : "+newHoliday.get("Offset").substring(0,2)+" Updated Offset : "+"0"+(Integer.parseInt((jsonElement.getAsJsonObject().get("offstOpn").toString().replaceAll("\"", ""))))/3600);
			}
			
		}
		
		/**
		 * Delete holiday for Single View only
		 */
		eView.goToHolidayHoursView();
		
		Asserts.verifyTrue(eView.deleteHoliday(newHoliday), "Verified that the Holiday record is deleted successfully. Deleted Holiday record having date : " + newHoliday.get("Date") );
		
		Asserts.verifyTrue(eView.deleteSuccessMsg(), "Verified that the delete success msg is displayed after deleting" );
		
	}
	
}
