package com.shi.content.ranking.vos;

public class Programs {
	private Fbm fbm;
	private Dss dss;

	public Dss getDss() {
		return dss;
	}

	public void setDss(Dss dss) {
		this.dss = dss;
	}

	public Fbm getFbm() {
		return fbm;
	}

	public void setFbm(Fbm fbm) {
		this.fbm = fbm;
	}
	

}
