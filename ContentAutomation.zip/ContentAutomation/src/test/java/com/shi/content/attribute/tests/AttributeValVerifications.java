package com.shi.content.attribute.tests;

import java.util.List;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.xmls.attribute.AllowedValue;
import com.generated.xmls.attribute.Attribute;
import com.google.gson.JsonElement;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
//import com.shc.autocontent.attribute.commons.AttributeDBQueries;

public class AttributeValVerifications implements Runnable{
	
	
	private List<Attribute> lstXmlAttribute;
	//private AttributeDBQueries db = new AttributeDBQueries();
	private AllowedValue allowedValue;
	private String sAttributeIdToTest, wcs_attrid;
	
	public AttributeValVerifications(List<Attribute> xmlAttribute){
		lstXmlAttribute = xmlAttribute;
	}
	
	/*public AttributeValVerifications(AllowedValue xmlAttrValue, String sAttributeIdToTest, String wcs_attrid){
		allowedValue = xmlAttrValue;
		this.sAttributeIdToTest = sAttributeIdToTest;
		this.wcs_attrid = wcs_attrid;
		
	}*/ //WCS Migration

	public AttributeValVerifications(AllowedValue xmlAttrValue, String sAttributeIdToTest){
		allowedValue = xmlAttrValue;
		this.sAttributeIdToTest = sAttributeIdToTest;
	
	}
	
	@Override
	public void run() {
		
			try{
				long l1 = System.currentTimeMillis();
				CompareValuesUtility.init();
				System.out.println("Searching for allowedValue "+ allowedValue.getId());
				APIResponse<AttributeValueSchema> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.ATTRIBUTE_VALUE, allowedValue.getId());
				//AttributeValueSchema attrValue = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, allowedValue.getId());
				AttributeValueSchema attrValue = allResponse.getT();
				if(attrValue == null){
					CompareValuesUtility.logFailed("Id", allowedValue.getId(), "Not found");
					CompareValuesUtility.setupResult(String.valueOf(allowedValue.getId()), true);
					return;
//					continue;
				}
				//this.compareAttributeValues(attrValue, allowedValue, sAttributeIdToTest, wcs_attrid); //WCS Migration
				this.compareAttributeValues(attrValue, allowedValue, sAttributeIdToTest);
				this.verifySearch(allResponse, sAttributeIdToTest);
				CompareValuesUtility.setupResult(allowedValue.getId(), true);
				long l2 = System.currentTimeMillis();
				System.out.println("Time in : "+ (l2-l1));
			}catch(Throwable e){
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
//		}
		
//		}
	}
	
	/*public void compareAttributeValuesForAttribute(AllowedValue[] allowedValue1,
			String id, String wcsXAttributeId) {
		// TODO Auto-generated method stub
		for(AllowedValue allowedValue : allowedValue1){
				System.out.println("Searching for allowedValue "+ allowedValue.getId());
				AttributeValueSchema attrValue = RestExecutor.getDataById(CollectionValues.ATTRVALUE, allowedValue.getId());
				this.compareAttributeValues(attrValue, allowedValue, id, wcsXAttributeId);
		}
	}*/
	
	
	
	private void verifySearch(APIResponse<AttributeValueSchema> allResponse, String attribute_id) {
		Boolean bFound = false;
		for(JsonElement i : allResponse.getSearchFields().getAsJsonArray("attrId")){
			if(i.getAsString().equals(attribute_id)){
				bFound = true;
				CompareValuesUtility.logPassed("_search.attrId", attribute_id, i.getAsString());
				break;
			}
		}
		if(!bFound){
			CompareValuesUtility.logFailed("_search.attrId", attribute_id, "Not found");
		}
		
	}

	//public void compareAttributeValues(AttributeValueSchema attrValue, AllowedValue allowedValue, String attribute_id, String wcs_attrid){ //WCS Migration
	public void compareAttributeValues(AttributeValueSchema attrValue, AllowedValue allowedValue, String attribute_id){
		
		CompareValuesUtility.compareValues("ValueId", allowedValue.getId(),attrValue.getId());
		long l1 = System.currentTimeMillis();
		//String sAttrValue_id = db.fetchXAttributeValId(wcs_attrid, allowedValue.getRank());
		//String sAttrValue_id = db.fetchXAttributeValId(wcs_attrid, allowedValue.getId()); //WCS Migration
		long l2 = System.currentTimeMillis();
		System.out.println("fetch xattr : "+ (l2-l1));
		
		String gbAttrValName = TestUtils.plainEncodeHTML(attrValue.getName()).replaceAll("&#34;", "\"");
		String gbAttrValDispName = TestUtils.plainEncodeHTML(attrValue.getDisplayName()).replaceAll("&#34;", "\"");
		
//		CompareValuesUtility.compareValues("Name", allowedValue.getName(),attrValue.getName());
		CompareValuesUtility.compareValues("Name", allowedValue.getName(),gbAttrValName);
		CompareValuesUtility.verifyNullOrEqual("BrandLogo", allowedValue.getBrandLogoImageUrl(),attrValue.getBrandLogoImgUrl());
//		CompareValuesUtility.compareValues("DisplayName", allowedValue.getName(),attrValue.getDisplayName());
		CompareValuesUtility.compareValues("DisplayName", allowedValue.getName(),gbAttrValDispName);
//		CompareValuesUtility.compareValues("Rank", allowedValue.getRank(),attrValue.getRank().longValue());
		CompareValuesUtility.verifyNullOrEqual("Tooltip", allowedValue.getToolTip(),attrValue.getToolTip());
		
		//Fetch Attribute value id 
		
		int i = CompareValuesUtility.verifyInListField("Attribute Id", attribute_id, attrValue.getAttrIds(), "attrId", AttrId.class);
		if(i!= -1){
			//CompareValuesUtility.compareValues("Attr WCSId", wcs_attrid, attrValue.getAttrIds().get(i).getWcsAttrId()); //WCS Migration
			CompareValuesUtility.compareValues("Attr Rank", allowedValue.getRank(), attrValue.getAttrIds().get(i).getRank());
			//CompareValuesUtility.compareValues("AttrVal WCS Id", sAttrValue_id, attrValue.getAttrIds().get(i).getWcsId()); //WCS Migration
	}
	}

	
	
	
	/*public void compareAttributeValuesForAttribute(AllowedValue[] allowedValues, String attribute_id, String wcs_attrid){
		for(AllowedValue allowedValue : allowedValues){
			System.out.println("Searching for allowedValue "+ allowedValue.getId());
			AttributeValueSchema attrValue = RestExecutor.getDataById(CollectionValues.CE, allowedValue.getId());
			this.compareAttributeValues(attrValue, allowedValue, attribute_id, wcs_attrid);
		}
	}
	
	public void validateMandatoryFields(AttributeType a, AttributeSchema gbAttrib){
		if(a.getId() == null || a.getName() == null || a.getEntryType().getName() == null || a.getDataType() == null){
				CompareValuesUtility.verifyRecordNotInserted();
		}
	}
	*
	*/	
}
 