package com.shi.content.mptests;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class MPItemBanVerificationsTest implements Runnable {
	
	
	static Map<String, Long> idToTS = new HashMap<String, Long>();
	
	private List<String> mpIBanMessages;
	
	public MPItemBanVerificationsTest( ) {
	}
	
	
	@Test(description="Test MP ItemBan messages", groups="MPIBanVerifs")
	public void MPItemBanTests(){
		
		
		BlockingQueue<List<String>> mpIBanDocs = new LinkedBlockingQueue<List<String>>();

		KafkaIAConsumer<String> mpIBanConsumerThread = new KafkaIAConsumer<String>(mpIBanDocs);		
		Thread tConsumerThread = new Thread(mpIBanConsumerThread);
		tConsumerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<String> nodeToTest;

				nodeToTest = mpIBanDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == mpIBanConsumerThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new MPItemBanVerificationsTest(nodeToTest));
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public MPItemBanVerificationsTest(List<String> ids  ) {
		mpIBanMessages = ids;
	}

	@Override
	public void run() {
		
			
			for(String mpIBanMessage : this.mpIBanMessages){
				try{
					String id = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.itemId");
					String type = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.prgm");
					
					if(type.contains("FBM") || type.contains("DSS"))
						id = "SPM"+id;
					
					String getProcessingTime = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.itemId");
					Double processingTime = Double.parseDouble(getProcessingTime);
				
					CompareValuesUtility.init();
					
					Offer offerDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);
					if(offerDoc != null){
						
						CompareValuesUtility.logFailed("ItemId", id, "Offer found");
						//System.out.println(id);
						//offerDoc.getIdentity().getSsin()
					}	
					else{
						CompareValuesUtility.logPassed("ItemId", id, "Offer not found");
					}
									
					CompareValuesUtility.setupResult(id, true);
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Check this message "+ mpIBanMessage);
				}
			}
		}

}
