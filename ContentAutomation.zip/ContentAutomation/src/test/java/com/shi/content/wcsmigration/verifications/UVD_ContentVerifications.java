package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Static;
import com.generated.vos.content.Val;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.offer.Legal;
import com.generated.vos.productoffering.types.ChokingHazardType;
import com.generated.vos.productoffering.types.GlobalAttributeType;
import com.generated.vos.uvd.AutomotiveProductOffer;
import com.generated.vos.uvd.ProductAttribute;
import com.generated.vos.uvd.ProductContent;
import com.generated.vos.uvd.ProductOffer;
import com.generated.vos.uvd.Site;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.SHCContentCommons;

public class UVD_ContentVerifications implements Runnable{

	AutomotiveProductOffer automotiveProductOffer;
	Attrs masterHierarchyAttributes;
	String itemClassId;
	String sSiteToTest;
	SHCContentCommons commonUtils;
	String vendorId;

	public UVD_ContentVerifications(AutomotiveProductOffer automotiveProductOffer, String vendorId){
		super();
		this.automotiveProductOffer = automotiveProductOffer;
		this.itemClassId = automotiveProductOffer.getProductContent().getContentItemClassId().toString();
		this.sSiteToTest = "sears";
		this.commonUtils = new SHCContentCommons();
		this.vendorId = vendorId;
	}


	public void run()
	{
		CompareValuesUtility.init();

		//System.out.println("automotiveProductOffer.getImaClassControlPid()"+automotiveProductOffer.getImaClassControlPid());

		String sRelationType = automotiveProductOffer.getRelationType();

		String sUVDId ="";
		String dummyPID = "";
		String brandCodeId = "";
		String spinId = "";
		ProductOffer xmlOffer = automotiveProductOffer.getProductOfferings().getProductOffer()[0];

		ProductContent productContent = automotiveProductOffer.getProductContent();

		String catEntrySubType=null;
		
		if(sRelationType.equalsIgnoreCase("single"))
		{
			String sSpinUniqueId = xmlOffer.getSpinUniqueId();

			sUVDId = "UVD"+sSpinUniqueId+"P";

			catEntrySubType = "NV";
			
			//TODO Need confirmation on dummyPID logic for NV UVD content
			//dummyPID = productOffer.getBrandCodeId()+"-"+productOffer.getManufacturerPartNumber();
			dummyPID = productContent.getBrand()==null?"":productContent.getBrand().getId()+"-"+xmlOffer.getManufacturerPartNumber();
			brandCodeId = xmlOffer.getBrandCodeId();
			spinId = sSpinUniqueId;
		}
		else if(sRelationType.equalsIgnoreCase("automotiveGrouping"))
		{
			String sAutomotiveGroupId = automotiveProductOffer.getAutomotiveGroupId();

			sUVDId = "UVD"+sAutomotiveGroupId+"P";
			
			catEntrySubType ="V";
			
			dummyPID = sAutomotiveGroupId;
			brandCodeId = automotiveProductOffer.getProductOfferings().getProductOffer(0).getBrandCodeId();
			spinId = sAutomotiveGroupId;
		}
		
		System.out.println("Testing UVD Content: "+ sUVDId);

		APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, sUVDId);
		Content content = (Content)allResponse.getT();
		
		if(content==null)
		{
			CompareValuesUtility.logFailed("Id", sUVDId, "Not Found in GB");
			CompareValuesUtility.addDataFieldForReport("vendorId", vendorId);
		}
		else
		{
			try {
				verifyContent(productContent, xmlOffer, content, catEntrySubType, dummyPID, brandCodeId, sUVDId, sRelationType);
				verifyFtSearch(xmlOffer , allResponse, catEntrySubType, spinId, sRelationType);
			} catch (Exception e) {

				System.out.println(e.getMessage() + " Exception : "+sUVDId);
				e.printStackTrace();
			}	
		}
		
		CompareValuesUtility.setupResult(sUVDId+"", true);
	}


	private void verifyFtSearch(ProductOffer xmlOffer, APIResponse<Content> allResponse, String catEntrySubType, String spinId, String sRelationType) {
		JsonArray catSubTyp = allResponse.getFtFields().get("catentrySubType").getAsJsonArray();
		CompareValuesUtility.compareValues("_ft.catentrySubType", "UVD+"+catEntrySubType, catSubTyp.get(0).getAsString()+"+"+catSubTyp.get(1).getAsString());
		CompareValuesUtility.compareValues("_search", "UVD", allResponse.getSearchFieldValue("dispSite"), "dispSite");
		CompareValuesUtility.compareValues("_search", spinId, allResponse.getSearchFieldValue("spinId"), "spinId");
		CompareValuesUtility.compareValues("_search", xmlOffer.getSsin(), allResponse.getSearchFieldValue("ssin"), "ssin");
		if(sRelationType.equalsIgnoreCase("single"))
		{
			CompareValuesUtility.compareValues("_search", xmlOffer.getGuid(), allResponse.getSearchFieldValue("uid"), "uid");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}


	public void verifyContent(ProductContent xmlContentObject,ProductOffer xmlOffer, Content gbContentObject,String catEntrySubType, String dummyPID, String brandCodeId, String sUVDId, String sRelationType)
	{
		
		SHCContentCommons commons =new SHCContentCommons();

		CompareValuesUtility.compareValues("Id",sUVDId,gbContentObject.getId());
		
/* ---------------- legal --------------- */

		Gson gson = new Gson();
		String json = gson.toJson(gbContentObject);
		com.generated.vos.content.Legal legalTagGb = null;
		if(json.contains("\"legal\":{\"chokingHazards\":[]}"))
		{
			legalTagGb = null;
		}
		else
		{
			legalTagGb = gbContentObject.getLegal();
		}

		verifyLegal(xmlContentObject, legalTagGb);
		
		//Identity.ssin
		
		if(xmlOffer != null && xmlOffer.getSsin() == null)
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", xmlOffer.getSsin(), gbContentObject.getIdentity()== null ? null : gbContentObject.getIdentity().getSsin(),"ssin");
			
			if(gbContentObject.getIdentity().getPrevSsin() == null)
			{
				CompareValuesUtility.logFailed("Identity", "SSIN not in Feed", "PrevSsin is not set");
			}
			else
			{
				CompareValuesUtility.logPassed("Identity", "SSIN not in Feed", "PrevSsin="+gbContentObject.getIdentity().getPrevSsin());
			}
			
		}
		else if(xmlOffer != null && xmlOffer.getSsin() != null)
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", xmlOffer.getSsin(), gbContentObject.getIdentity()== null ? null : gbContentObject.getIdentity().getSsin(),"ssin");
		}
		else 
		{
			CompareValuesUtility.logFailed("Identity", "xmlOffer="+xmlOffer, "offer in xml is not present for ssin="+gbContentObject.getIdentity().getSsin());
		}
		
		/* ---------------- Identity.uid and Identity.offerCnt --------------- */
		if(sRelationType.equalsIgnoreCase("single"))
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", xmlOffer.getGuid(), gbContentObject.getIdentity()== null ? null : gbContentObject.getIdentity().getUid(),"UID");
			if(gbContentObject.getMeta().getModifiedTs() == null)
			{
				CompareValuesUtility.verifyNullOrEqual("Identity", xmlContentObject.getOfferCount() == null ? "99" : xmlContentObject.getOfferCount(), gbContentObject.getIdentity().getOfferCnt() == null ? null : gbContentObject.getIdentity().getOfferCnt().intValue(),"OfferCnt");
			}
			else
			{
				if(xmlContentObject.getOfferCount() == null)
				{
					CompareValuesUtility.logPassed("Identity", "OfferCnt is null in feed", gbContentObject.getIdentity()== null ? "null" : gbContentObject.getIdentity().getOfferCnt() == null ? "null" : gbContentObject.getIdentity().getOfferCnt().intValue(),"OfferCnt");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("Identity", xmlContentObject.getOfferCount(), gbContentObject.getIdentity()== null ? null : gbContentObject.getIdentity().getOfferCnt() == null ? null : gbContentObject.getIdentity().getOfferCnt().intValue(),"OfferCnt");
				}
			}
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", xmlContentObject.getOfferCount(), gbContentObject.getIdentity()== null ? null : gbContentObject.getIdentity().getOfferCnt() == null ? null : gbContentObject.getIdentity().getOfferCnt().intValue(),"OfferCnt");
		}
		
		CompareValuesUtility.addDataFieldForReport("vendorId", vendorId);
		CompareValuesUtility.compareValues("Name",TestUtils.plainEncodeHTML(xmlContentObject.getName()),gbContentObject.getName());
		
		commons.verifyDesc(xmlContentObject.getFeatureDescription(), xmlContentObject.getMarketingDescription(), gbContentObject.getDesc(), true);
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("Brand", xmlContentObject.getBrand()==null?null:xmlContentObject.getBrand().getId(), gbContentObject.getBrand()==null?null:gbContentObject.getBrand().getId(), "id");
		CompareValuesUtility.verifyNullOrEqual("Brand", xmlContentObject.getBrand()==null?null:xmlContentObject.getBrand().getName(), gbContentObject.getBrand()==null?null:gbContentObject.getBrand().getName(), "name");
		String xmlBrandUrl = xmlContentObject.getBrand()==null?null:(xmlContentObject.getBrand().getLogoImageUrl()==null?null:xmlContentObject.getBrand().getLogoImageUrl().
				replaceAll("http://i.sears.com/s/", "http://c.shld.net/rpx/i/s/").
				replaceAll("http://s7.sears.com/", "http://s.shld.net/").
				replaceAll("http://s7.kmart.com/", "http://s.shld.net/"));
		CompareValuesUtility.verifyNullOrEqual("Brand", xmlBrandUrl, (gbContentObject.getBrand()==null || gbContentObject.getBrand().getImg()==null)?null:gbContentObject.getBrand().getImg().getSrc(), "url");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("Mfr", xmlContentObject.getManufacturerName(), gbContentObject.getMfr()==null?null:gbContentObject.getMfr().getName(), "name");
		CompareValuesUtility.verifyNullOrEqual("Mfr", xmlContentObject.getManufacturerModelNumber(), gbContentObject.getMfr()==null?null:gbContentObject.getMfr().getModelNo(), "modelNo");
		CompareValuesUtility.addNewMultiValuedFields();

		if(xmlContentObject.getSeo()!=null){
			CompareValuesUtility.compareValues("Seo", xmlContentObject.getSeo().getSeoRobotFollowFlag(), gbContentObject.getSeo().getIsRobotFollow(), "isRobotFollow");
			CompareValuesUtility.compareValues("Seo", xmlContentObject.getSeo().getSeoRobotIndexFlag(), gbContentObject.getSeo().getIsRobotIndex(), "isRobotIndex");
			CompareValuesUtility.verifyNullOrEqual("Seo", xmlContentObject.getSeo().getSeoProductAltTag(), gbContentObject.getSeo().getProductAltTag(), "productAltTag");
			CompareValuesUtility.verifyNullOrEqual("Seo", xmlContentObject.getSeo().getSeoFeatureAltTag(), gbContentObject.getSeo().getFeatureAltTag(), "featureAltTag");
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		CompareValuesUtility.compareValues("Classifications", "P", gbContentObject.getClassifications().getCatentryType(), "catentryType");
		CompareValuesUtility.compareValues("Classifications", catEntrySubType ,gbContentObject.getClassifications().getCatentrySubType(), "catentrySubType");
		CompareValuesUtility.compareValues("Classifications", "true", gbContentObject.getClassifications().getIsUvd(), "isUvd");
		CompareValuesUtility.compareValues("Classifications", "S", gbContentObject.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
		CompareValuesUtility.compareValues("Classifications", "true", gbContentObject.getClassifications().getIsAutomotive(), "isAutomotive");
		CompareValuesUtility.addNewMultiValuedFields();

		Boolean xmlIsLongDescSuppress = xmlContentObject.getSuppressLongDescriptionFlag();
		xmlIsLongDescSuppress = xmlIsLongDescSuppress==null?false:xmlIsLongDescSuppress;
		Boolean isLongDescSuppress = gbContentObject.getIsLongDescSuppress(); 
		isLongDescSuppress  = isLongDescSuppress==null?false:isLongDescSuppress;

		compareValues("PrimaryImg", "P", gbContentObject.getAssets().getImgs().get(0).getType(),"Type");
		verifyNullOrEqual("PrimaryImg", xmlContentObject.getPrimaryImage().getHeight(), convertToString(gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getHeight()),"Height");
		verifyNullOrEqual("PrimaryImg", xmlContentObject.getPrimaryImage().getWidth(), convertToString(gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getWidth()),"Width");
		compareValues("PrimaryImg", TestUtils.modifyURL(xmlContentObject.getPrimaryImage().getUrl()), gbContentObject.getAssets().getImgs().get(0).getVals().get(0).getSrc(),"Src");
		CompareValuesUtility.addNewMultiValuedFields();

		if(xmlContentObject.getFeatureImages() != null){
			for(com.generated.vos.uvd.FeatureImage fImage : xmlContentObject.getFeatureImages().getFeatureImage()){
				boolean bFound = false;
				int i = getPositionInList("A", gbContentObject.getAssets().getImgs(), "type", Img_.class);
				for(Val assetImgVal : gbContentObject.getAssets().getImgs().get(i).getVals()){
					if(assetImgVal.getSrc().equals(TestUtils.modifyURL(fImage.getUrl()))){
						bFound = true;
						compareValues("FeaturedImg", "A", gbContentObject.getAssets().getImgs().get(i).getType(),"Type");
						CompareValuesUtility.verifyTrue(true, "FeaturedImg", TestUtils.modifyImgURL(fImage.getUrl()), assetImgVal.getSrc());
						verifyNullOrEqual("FeaturedImg", fImage.getWidth(), convertToString(assetImgVal.getWidth()),"Width");
						verifyNullOrEqual("FeaturedImg", fImage.getHeight(), convertToString(assetImgVal.getHeight()),"Height");
					}
				}
				if(!bFound){
					CompareValuesUtility.verifyTrue(false, "FImgSrc", fImage.getUrl(), "Not found");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}

		//verifySpecs(xmlContentObject.getProductAttributes().getProductAttribute(), gbContentObject.getSpecs(),xmlContentObject.getContentItemClassId()+"");

		CompareValuesUtility.compareValues("isLongDescSuppress", xmlIsLongDescSuppress, isLongDescSuppress);
		
		CompareValuesUtility.verifyNullOrEqual("AltIds", automotiveProductOffer.getImaClassControlPid(), gbContentObject.getAltIds().getImaClassControlPid(), "imaClassControlPid");
		CompareValuesUtility.verifyNullOrEqual("AltIds", dummyPID, gbContentObject.getAltIds().getDummyPID(), "dummyPID");
		CompareValuesUtility.addNewMultiValuedFields();

/*
		verifyTaxonomy(xmlContentObject, gbContentObject, xmlContentObject.getContentItemClassId()+"");
		
		SHCContentCommons commonUtils = new SHCContentCommons();
		
		ProductAttribute[] prodAttr = xmlContentObject.getProductAttributes().getProductAttribute();
		
		String attId = "",attValId="";
		for (ProductAttribute productAttribute : prodAttr) {
			
			attId=attId+","+productAttribute.getAttributeId();
			attValId=attValId+","+productAttribute.getProductAttributeTypeChoice().getAttributeValueId();
					
		}
		
		attId=attId.replaceFirst(",","");
		attValId=attValId.replaceFirst(",","");
		
		
		String sQuery = commonUtils.getFacetsQuery(xmlContentObject.getContentItemClassId()+"", attId, attValId);
		
		try {
			commonUtils.verifyFacets(sQuery, gbContentObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
		commonUtils.verifySites(xmlContentObject, gbContentObject.getSites());
		CompareValuesUtility.addNewMultiValuedFields();
		
		if(xmlContentObject.getProductAssets() != null){
			commonUtils.verifyAssetAttachments(xmlContentObject.getProductAssets().getProductAsset(), gbContentObject.getAssets().getAttachments());
			
			commonUtils.verifyAssetVideo(xmlContentObject.getProductAssets().getProductAsset(), gbContentObject.getAssets().getVideos());
		}
		if(xmlContentObject.getContentExtensions()!= null)
			commonUtils.verifyContentExtension(xmlContentObject.getContentExtensions().getProvider(0), gbContentObject.getAssets().getContentExtensions().get(0));
		
		CompareValuesUtility.addNewMultiValuedFields();
		
		
		/***Facets***/
		verifyFacetsGB(xmlContentObject, gbContentObject);
		/***Specs***/
		verifySpecsGB(gbContentObject.getSpecs());
		/***Taxonomy***/
		verifyTaxonomy(xmlOffer.getSite(), gbContentObject);
		
		CompareValuesUtility.verifyNullOrEqual("Automotive", "UVD", gbContentObject.getAutomotive().getAutoType(), "autoType");
		CompareValuesUtility.verifyNullOrEqual("Automotive", brandCodeId, gbContentObject.getAutomotive().getBrandCodeId(), "brandCodeId");
		CompareValuesUtility.verifyNullOrEqual("Automotive", autoFitmentType, gbContentObject.getAutomotive().getAutoFitment(), "autoFitment");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	List<String> lstAttributeVals = new ArrayList<String>();
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	List<String>  lstAttribsNotFound = new ArrayList<>();
	String brandCodeId = null, autoFitmentType = null;
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });
	
	public void verifySpecsGB(List<Spec> specsXML) {

		if(masterHierarchyAttributes == null){
			return;
		}

		if(lstSpecAttributes.isEmpty()){
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecVal", "No specs expected", "Specs found");

			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstSpecAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		verifySpecValues(attributeData, attributeValData, specsXML);

	}

	private void verifyLegal(ProductContent prodContent, com.generated.vos.content.Legal gbLegal) {

		String jewelry_disclosure_52="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care";

		String jewelry_disclosure_53="Diamond weights may not be exact, but are never more than .05 carats below the stated weight";

		String jewelry_disclosure_84="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight";


		boolean bDisclosurePresent = false;

		Integer dicValueId = null;

		if(prodContent.getProductAttributes()!=null && prodContent.getProductAttributes().getProductAttribute()!=null)
		{
			ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();
			for (ProductAttribute productAttribute : attrs) {

				if(productAttribute.getAttributeId().intValue()==30201)
				{
					bDisclosurePresent = true;
					dicValueId = productAttribute.getProductAttributeTypeChoice().getAttributeValueId().intValue();
					break;
				}
			}
		}

		if (  !bDisclosurePresent && prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getHazardMaterialCode() == null
				&& prodContent.getAggrLegalData().getHazardStorageCode() == null
				&& prodContent.getAggrLegalData().getIsCaEmmission() == null
				&& checkInAttributeGroup("California Emission Compliant", prodContent) == null
				&& (prodContent.getAggrLegalData().getProp65Flag() == false || prodContent.getAggrLegalData().getProp65Flag() == null)
				//&& xmlProductOffer.getGeoLimiters() == null
				&& (prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getChokingHazards() == null)) {
			CompareValuesUtility.verifyNull("Legal", gbLegal);
		} else {

			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getHazmatMaterialCd(),
					"HazmatMtrCd");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getUsDotType(),
					"usDotType");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardStorageCode(), gbLegal == null ? null : gbLegal.getHazmatStorageCd(),
					"HazmatStrgCd");
			verifyNullOrEqual("Legal",
					prodContent.getAggrLegalData().getIsCaEmmission() == null || prodContent.getAggrLegalData().getIsCaEmmission() == false ? null : true,
					gbLegal == null ? null : gbLegal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", (prodContent.getAggrLegalData().getProp65Flag() == null ||
					prodContent.getAggrLegalData().getProp65Flag() == false) ? null : true,
							gbLegal == null ? null : gbLegal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			/*if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),
								legal.getLimitedGeos());*/
			
//			if(bDisclosurePresent)
//			{
//				if(dicValueId==52)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_52, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==53)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_53, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==84)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_84, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==2534)
//				{
//					CompareValuesUtility.verifyNull("Legal", gbLegal == null ? null : gbLegal.getJewelry()==null?null:gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else
//				{
//					System.out.println(" ===================== check this dicValueId : "+dicValueId+"===================");
//				}
//			}
		}
		verifyChokingHazards(gbLegal,prodContent);
	}
	
	private Boolean checkInAttributeGroup(String attrToCheck, ProductContent prodContent) {
		if (prodContent.getGlobalAttributes() != null) {
			for (com.generated.vos.uvd.types.GlobalAttributeType attGroup : prodContent
					.getGlobalAttributes().getAttribute()) {
				if (attGroup.value().equals(attrToCheck))
					return true;

			}
			return false;
		} else
			return null;

	}
	
	private void verifyChokingHazards(com.generated.vos.content.Legal gbLegal,ProductContent prodContent) {
		Boolean isWarn = false;
		Boolean safetyWarn = false;
		
		if (prodContent.getAggrLegalData() != null &&  prodContent.getAggrLegalData().getChokingHazards() != null) {
			for (com.generated.vos.uvd.types.ChokingHazardType cType : prodContent.getAggrLegalData().getChokingHazards().getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
					isWarn = true;
				else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
					safetyWarn = true;
				else
				{
					ArrayList<String> list1 = new ArrayList<String>();
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.value(), gbLegal == null ? list1 : gbLegal.getChokingHazards());
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		if(isWarn)
			compareValues("LegalIsNoWarn", true, gbLegal == null ? null : gbLegal.getIsNoWarning());
		if(safetyWarn)
			compareValues("LegalsafetyWarn", true, gbLegal == null ? null : gbLegal.getSafetyWarnings());
	}
	
	private void verifySpecValues(Map<String, String> attribData,  Map<String, String> attribValData,List<Spec> specsXML)
	{
		for(String attributeId : lstSpecAttributes)
		{
			String grpNameIA = attributeToGroup.get(attributeId)==null?"Others:":attributeToGroup.get(attributeId);
			boolean bAttributeFound = false;
			boolean bGroupFound = false;
			boolean bAttrValueFound = false;
			boolean bIsDoNotDisplaySpecFound = false;
			String displayEligibility = GreenBoxCache.isDoNotDisplay(attributeId);
			for (Spec spec : specsXML) {
				String grpNameJson = spec.getGrpName();
				if(grpNameIA.equals(grpNameJson)){
					bGroupFound = true;
					for(Attr attr : spec.getAttrs()){

						if(displayEligibility!= null && attr.getName().equals(displayEligibility)){
							bIsDoNotDisplaySpecFound = true;
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName",displayEligibility+ ": Do not display set("+attributeId+").  Attribute should not be in specs.", attr.getName() + " found in specs");
							break;
						}
						//Checking to prevent it getting printed everytime the same attribute is found 
						if (attr.getName().equals(attribData.get(attributeId))){
							if(!bAttributeFound){
								CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
								bAttributeFound = true;
								CompareValuesUtility.logPassed("SpecName",attribData.get(attributeId), attr.getName());
							}

							boolean bRes;
							try {
								bRes = bAttributeFound && 
										(attributeToVal.get(attributeId).equals(attr.getVal()) 
											||	TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()) || TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()));
							} catch (Exception e) {
								bRes = false;
								e.printStackTrace();
							}

							if(bRes){
								bAttrValueFound = true;

								if(attributeToVal.get(attributeId).equals(attr.getVal())){
									CompareValuesUtility.logPassed("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}else
								{
									if(TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal", TestUtils.encodeHTML(attributeToVal.get(attributeId)) , attr.getVal());
									
									else if (TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal",TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))) , attr.getVal());
								}
								break;
							}
						}
					}

					//If attribute is donotdisplay type and is not displayed, mark as passed
					if(displayEligibility!= null && !bIsDoNotDisplaySpecFound){
						CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
						CompareValuesUtility.logPassed("SpecName", attributeId+":"+displayEligibility, "Do not display set.Not found in specs.");
					}
					//Do the following checks only for displayable attributes
					if(displayEligibility == null){
						if(!bAttributeFound){
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
						}
						if(bAttributeFound && !bAttrValueFound){
							CompareValuesUtility.logFailed("SpecVal", attributeToVal.get(attributeId), "Not found");
						}
					}
					break;
				}
			}

			if(!bAttributeFound && !bGroupFound)
				CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void verifyFacetsGB(ProductContent pContent, Content content) {
			if(pContent.getProductAttributes()==null)
				return;

			masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
			if(masterHierarchyAttributes == null){
				CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
				return;
			}

			segregateAttributes(pContent.getProductAttributes().getProductAttribute());

			if(lstFacetAttributes.isEmpty()){
				CompareValuesUtility.verifyNull("FacetName", content.getFacets());
				CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
				return;
			}

			//Hit all attributes
			Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
			Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

			List<Static> staticFacets=null;

			String val ;

			if(sSiteToTest.equalsIgnoreCase("sears"))
				staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
			else if(sSiteToTest.equalsIgnoreCase("kmart"))
				staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getKmart().getStatic();

			for(String facetAttributeId : lstFacetAttributes){
				boolean bFound = false;
				boolean bAttrValueFound = false;
				if(staticFacets ==  null){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found");
					continue;
				}
				for(Static gbFacet : staticFacets){
					if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
						if(!bFound){
							bFound = true;
							CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId));
						}

						val = attributeValData.get(attributeToVal.get(facetAttributeId));
						val= val==null?"null":val;

						if(bFound &&
								(attributeToVal.get(facetAttributeId).equals(gbFacet.getValue())
										|| val.equals(gbFacet.getValue())))
						{
							bAttrValueFound = true;
							if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
								compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue());
							else //free value
								compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue());
							break;
						}
					}
				}
				if(!bFound){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found");
				}

				if(!bAttrValueFound){
					CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	
	private void segregateAttributes(ProductAttribute[] productAttributes){

		String sAttrId;
		String sValFree;
		String valueFlag;
		String sValId;

		for(ProductAttribute attributeXML : productAttributes ){

			sAttrId = String.valueOf(attributeXML.getAttributeId().intValue());

			sValFree = attributeXML.getProductAttributeTypeChoice().getAttributeValueFree();

			valueFlag = String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueFlag());

			try {
				sValId =String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueId().intValue());
			} catch (Exception e) {
				sValId = null;
			}

			if(autoIds.contains(sAttrId)){
				if(sAttrId.equals("873910")){
					brandCodeId = sValFree;
				}
				if(sAttrId.equals("1035210")){
					switch(sValId){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}

					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(sAttrId) )
				continue;
			boolean bFound = false;

			//label is array
			for(Label label : masterHierarchyAttributes.getLabels())
			{
				//each label has attr array again
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs())
				{
					if(sAttrId.equals(attr.getId()) && (attr.getType().contains("search") 
							|| attr.getType().contains("label")))
					{
						bFound = true;
						if(attr.getType().contains("search"))
							lstFacetAttributes.add(sAttrId);
						if( attr.getType().contains("label")){
							lstSpecAttributes.add(sAttrId);
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());

						}
						attributeToGroup.put(sAttrId, label.getName());

						if(sValId != null)
							lstAttributeVals.add(sValId);

						//Commenting td text - ECOM-361803

						/*if(attributeXML.getTrademarkText() != null){
							attributeToVal.put(sAttrId, attributeXML.getTrademarkText());
						}
						else 
						 */


						if( sValFree != null)
							attributeToVal.put(sAttrId, sValFree);
						else if(valueFlag != null && !valueFlag .equals("null"))
							attributeToVal.put(sAttrId, valueFlag.toString());
						else if(sValId != null){
							lstAttributeVals.add(sValId);
							attributeToVal.put(sAttrId, sValId);
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
							//							throw new IllegalArgumentException("No attribute val data found");

							break;
					}

				}
				if(bFound)
					break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(sAttrId);
			}
		}
	}
	
	boolean isPrimaryAvlbl = false; 
	
	private void verifyTaxonomy(Site[] sites, Content content) {
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();

		for ( Site site : sites) {

			long lSiteId = site.getId();

			if(lSiteId > 11 || lSiteId == 10)
				continue;

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(com.generated.vos.uvd.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				if(hierarchy.getPrimary().equals("true"))
					isPrimaryAvlbl = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, content.getTaxonomy() == null? null : content.getTaxonomy().getWeb(),sSiteToTest,true);

		commonUtils.compareMasterhierarchyGB(Long.parseLong(itemClassId), content.getTaxonomy() == null? null : content.getTaxonomy().getMaster() == null ? null : content.getTaxonomy().getMaster().getHierarchy());
	}


	/*private void verifyTaxonomy(ProductContent pContent, Content content,String itemClassId) {
		
		SHCContentCommons commonUtils = new SHCContentCommons();
		
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for ( com.generated.vos.uvd.Site site : pContent.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId > 11 || lSiteId == 10)
				continue;
			
			List<String> lstHieararchyIds = new ArrayList<String>();
			for( com.generated.vos.uvd.Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}
			
			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		
		
		commonUtils.compareWebhierarchy(mpSiteHiearachies, content.getTaxonomy().getWeb());
		commonUtils.compareMasterhierarchy(Long.parseLong(itemClassId), content.getTaxonomy().getMaster().getHierarchy());
	}*/

	/*public void verifySpecs(com.generated.vos.uvd.ProductAttribute[] prodAttribs, List<Spec> specsJson, String itemClassId){

		List<String> ignoreAttrIds = Arrays.asList(new String[]{"781110","797010","250601","796910","796810","1774"});
		List<String> autoIds = Arrays.asList(new String[]{"1035210","873910"});

		String query ="select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1" +
				" where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ('ATTVALID')"+
				" and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"+
				" and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		String attributeOnlyQuery = "select x.displaylabel as name, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g" +
				" where x.xattribute_id=g.xattribute_id and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"+
				" and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";



		if(prodAttribs!=null)
		{

			String grpNameJson="";
			String grpNameWCS="";

			Long attrId , val_id;
			String val_free = "";
			String attrName=null, attrVal=null;
			for ( com.generated.vos.uvd.ProductAttribute attribute : prodAttribs) {

				//It's a flag field - no need to check
				if(attribute.getProductAttributeTypeChoice().getAttributeValueFlag()!= null)
					continue;

				attrId = attribute.getAttributeId();

				//For content some attribute ids need to be skipped
				if(ignoreAttrIds.contains(attrId.toString())){
					continue;
				}

				//If automotive attributes
				if(autoIds.contains(attrId.toString())){
					//					bIsAuto = true;
					continue;
				}

				val_id = attribute.getProductAttributeTypeChoice().getAttributeValueId();
				val_free = attribute.getProductAttributeTypeChoice().getAttributeValueFree();

				if(val_id != null){
					String finalQuery = query.replace("ATTVALID",  val_id.toString()).replace("ATTID", attrId.toString()).
							replace("IMACLASSID", itemClassId);
					List<String> attrData = DB2Utils.executeQueryMultiColumnSingleRow(finalQuery);
					if(attrData == null)
						continue;
					attrName = attrData.get(0);
					attrVal = attrData.get(1);
					grpNameWCS = attrData.get(2);
				}
				else  //Probably free text
				{
					String finalQuery = attributeOnlyQuery.replace("ATTID", attrId.toString()).replace("IMACLASSID", itemClassId);
					List<String> attrData = DB2Utils.executeQueryMultiColumnSingleRow(finalQuery);
					if(attrData!=null)
					{
						attrName = attrData.get(0);

						grpNameWCS = attrData.get(1);
					}
					attrVal=val_free;
				}

				if(grpNameWCS==null)
				{
					grpNameWCS="Others:";
				}

				boolean found = false;
				for (Spec spec : specsJson) {

					grpNameJson = spec.getGrpName();
					List<Attr> attrsList = spec.getAttrs();
					for (Attr attr : attrsList) {

						if(attr.getName().equals(attrName) 
								&& attr.getVal().equals(TestUtils.encodeHTML(attrVal))
								&& grpNameWCS.equals(grpNameJson))
						{
							found = true;
							CompareValuesUtility.logPassed("SpecName", attrName, attr.getName());
							CompareValuesUtility.logPassed("SpecVal", attrVal, attr.getVal());
							CompareValuesUtility.logPassed("SpecGrpName", grpNameWCS, grpNameJson);
							break;
						}
					}

					if(found)
					{
						break;
					}
				}

				if(!found)
				{
					attrName = attrName==null?"null":attrName;
					attrVal = attrVal==null?"null":attrVal;

					CompareValuesUtility.logFailed("SpecName", attrName, "");
					CompareValuesUtility.logFailed("SpecVal", attrVal==null?"null":attrVal, "");
					CompareValuesUtility.logFailed("SpecGrpName", grpNameWCS, grpNameJson);
				}

			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}*/
}
