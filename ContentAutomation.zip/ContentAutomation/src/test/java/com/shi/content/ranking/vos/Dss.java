package com.shi.content.ranking.vos;

import java.util.ArrayList;
import java.util.List;

public class Dss {
	private List<WareHouseLocation> wareHouseLocations = new ArrayList<WareHouseLocation>();
	private WareHouse wareHouse;

	public WareHouse getWareHouse() {
		return wareHouse;
	}

	public void setWareHouse(WareHouse wareHouse) {
		this.wareHouse = wareHouse;
	}

	public List<WareHouseLocation> getWareHouseLocations() {
		return wareHouseLocations;
	}

	public void setWareHouseLocations(List<WareHouseLocation> wareHouseLocations) {
		this.wareHouseLocations = wareHouseLocations;
	}


}
