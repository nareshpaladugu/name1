package com.shi.content.storepricing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.content.sshutils.SSHExecutor;

public class KmartStorePricingTest {

	static Map<String, Boolean> storeIds = Collections.synchronizedMap(new HashMap<String, Boolean>());

	static BufferedWriter invalidPartNumberWriter;
	
	public static Integer icountOfStoreOnlyItems = 0;
	public static AtomicInteger countOfStoreOnlyItems = new AtomicInteger(0);
	
//	public static List<String> gwPartNumbers;
	
	@AfterTest
	public void closeFile()
	{
		System.out.println("Closing file........");
		try {
			invalidPartNumberWriter.flush();
			invalidPartNumberWriter.close();
		} catch (IOException e) {
		  e.printStackTrace();
		}
		System.out.println("Counts of rows with all prices < 0.02 "+ KmartStorePricingVerifications.countOfNullPricedItems);
	}
	
	@BeforeTest
	public void openFile()
	{
		System.out.println("Opening file........");
		//open file

		try {
			
			File F=new File("Upc_InvalidPartnumbers.txt");   //C:/Users/hthamar/workspace/Variations_8.30_release/test-output/
			invalidPartNumberWriter=new BufferedWriter(new FileWriter(F));

//			gwPartNumbers=getGWPartNumbers();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void kmartPricingTests(String fileName){
		
		try{
			FileReader fr=new FileReader(fileName);
			BufferedReader br=new BufferedReader(fr);      ////get filename one by one and start reading each line

			String processLine;
			
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			
			while((processLine=br.readLine())!=null){
			
				if(!processLine.contains("1.Store Number"))

				pool.execute(new KmartStorePricingVerifications(processLine));
				
				
			}
			br.close();
			pool.shutdown();
			
			pool.awaitTermination(300, TimeUnit.MINUTES);
			
			LoadProperties.setCustomMsgForEmail("Count of store only items "+icountOfStoreOnlyItems,MSGTYPE.SUCCESS);
			
			System.out.println("------------------------------------------------");
			System.out.println("countOfStoreOnlyItems---------------------------: "+countOfStoreOnlyItems.intValue());
			System.out.println("icountOfStoreOnlyItems--------------------------:"+icountOfStoreOnlyItems);
			System.out.println("------------------------------------------------");
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
			
	}
	// Retrieve gw part numbers from kmpricing-config.properties file

	public List<String>  getGWPartNumbers(){
		
		SSHExecutor executor = new SSHExecutor();
		
		List<String> output = executor.executeCommand("cd /appl/batch/kmpricing/07152014/conf;cat kmpricing-config.properties");
		
		List<String> gwPartNoList=null;
		
		if(!output.isEmpty()){
		
			for(String property : output){
				
				if(property.contains("kmpricing.gw.partnos")){
					
					property= property.replace("kmpricing.gw.partnos=", "");
					
					String partNumberList[] = property.split(",");
					
					gwPartNoList=Arrays.asList(partNumberList);
					
					
				}
			}
			System.out.println("\n Kmart GW Part Numbers: ");
			for(String s:gwPartNoList){
				System.out.println(s);
			}
			
		}
			
		executor.disconnect();

		return gwPartNoList;
	}
	
	
	
	
	
	/*@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void priceChecking(String fileName)
	{  try{
		FileReader fr=new FileReader(fileName);
		BufferedReader br=new BufferedReader(fr);      ////get filename one by one and start reading each line

		String processLine;

		String storeID=null;
		while((processLine=br.readLine())!=null)
		{

			try {
				//processLine=br.readLine();

				//			CompareValuesUtility.init();
				///logic to get each line from file
				//String Line="7840| |0028332473842|N|N| |N|1|N|0000000000000| |Y| |048|00|00|00|01|00|00000000|00000000|00000001|0|N|000|022|3|0|25954411|000|        |010|00000001|01|      | |N| |0000|0000|00|00000399|01|        | |";
				String[] AfterLineSplit= processLine.split("\\|");
				storeID=AfterLineSplit[0];
				String upcCode1=AfterLineSplit[2];       //upc no of item. catentry_id.field4
				String upcTypeCode=AfterLineSplit[22];
				String upcPriceTypeCode=AfterLineSplit[26];  /////will determin the type of upc code .....value 1 for regular and value 3 for clearnce
				String UpcPriceAmt=AfterLineSplit[21];    //value for regular and clearance price
				String UpcPriceMul=AfterLineSplit[17];    //multiple value for regular and clearance price
				String AssosDisPrice=AfterLineSplit[32];  //Associated price amount
				String AssoDiscMul=AfterLineSplit[33];     ////associated price multiple
				String wasPrice=AfterLineSplit[41];         ////was price amount
				String wasPriceMul=AfterLineSplit[42];     ///was price multiple
				String eventPrice=AfterLineSplit[20];       //Sale price
				String eventPriceMul=AfterLineSplit[16];     //sale price multiple
				String eventFlag=AfterLineSplit[36];         ///Sale flag
				String eventEndDate=AfterLineSplit[35];      ///sale end date



				String upcCode=getUpc(upcTypeCode, upcCode1); //this method will extract the actual upc code


				if (storeID.equals("7840")||storeID.equals("7800"))
				{
					ArrayList<String> pIds=new ArrayList<String>();   //to get list of products under the upc.
					pIds=(ArrayList<String>)RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"upc",upcCode);  
					if (pIds.isEmpty()==true)    ///check if upc has no records
					{  upcFileWriting(upcCode);
					   continue;
				     }
					else{

						for(int i=0;i<pIds.size();i++)    //after getting list of products under the pid, checking prices for all the products in the list
						{
							CompareValuesUtility.init();
							String productId=pIds.get(i);
							
							
							OfferSchema ofd=RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFERSCHEMA, productId);
						    String pgType=ofd.getFt().getPgrmType().toString();
						   
							
							
							
							if (!pgType.equals("Kmart"))          /// to filter out only kmart partnumbers under below upc  
							{  
								String storeProductId=storeID+"-"+productId;
								if (validateSearsNotPresent(storeProductId))
								{	
									CompareValuesUtility.logFailed("Id", storeProductId, "Found in GB");    /////////
								     CompareValuesUtility.setupResult(storeProductId, true);
								     continue;                       
								}
								else {  productFileWriting(storeProductId);  ///write in log file that invalid store product Id is not written to the GB
										continue;
								     }
							}
							String storeProductId=(storeID+"-"+productId);
							 


							ShcPricing storePricingGB = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING,storeProductId);
							if (storePricingGB==null)
							{
								//System.out.println("No data found for the "+ storeProductId);
								//CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
								CompareValuesUtility.logFailed("Id", storeProductId, "Not found in GB");
								CompareValuesUtility.setupResult(storeProductId, true);
								continue;
							}
							else{

								CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
								//to check if item is giftcard or if it is giftwrap eligible
								
								String channel=ofd.getBlob().getOffer().getFfm().getChannel().toString();
								if (channel!=null && channel.equals("VGC"))
								{ 
									compareVGCPrices(storePricingGB,productId);
									CompareValuesUtility.logPassed("Id", storeProductId, storeProductId);
									CompareValuesUtility.setupResult(storeProductId, true);
									continue;
								}
								
								if (channel!=null && channel.equals("VD"))
								{ 
									compareVDItemPrices(storePricingGB,storeProductId,upcCode,upcPriceTypeCode,UpcPriceAmt,UpcPriceMul,AssosDisPrice,AssoDiscMul,wasPrice,wasPriceMul,eventPrice,eventPriceMul,eventFlag,eventEndDate);
									CompareValuesUtility.setupResult(storeProductId, true);
									continue;
								}
								
								//compareVDItemPrices

								compareAllPrices(storePricingGB,storeProductId,upcCode,upcPriceTypeCode,UpcPriceAmt,UpcPriceMul,AssosDisPrice,AssoDiscMul,wasPrice,wasPriceMul,eventPrice,eventPriceMul,eventFlag,eventEndDate);

								//////DP method to check expire Dp dates or not


								CompareValuesUtility.setupResult(storeProductId, true);

							}  ////end of else for checking storePricingGB==null
						}
					}/////end of else for checking  if list of pids is not empty



				}


				else {          ////for stores other than national store
                
					List<String> pIds;  //to get list of products under the upc.
					System.out.println(upcCode);
					pIds= RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"upc",upcCode);  
					if (pIds.isEmpty()==true)    ///check if upc has no partnumbers associated with upc no are processed
					{  upcFileWriting(upcCode);
						continue;
					}
					for(int i=0;i<pIds.size();i++)    //after getting list of products under the pid, checking prices for all the products in the list
					{
						
						String productId=pIds.get(i);
						if (productId.length()<12)          /// to filter out only kmart partnumbers under below upc  
						{ continue;                       
						}
						String storeProductId=storeID+"-"+productId;
                        
						CompareValuesUtility.init();
						ShcPricing storePricingGB = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, storeProductId);
						if (storePricingGB==null)
							CompareValuesUtility.logPassed("Id", "not expected in DB "+storeProductId, "Not occuring in DB");
						else {  
							
							CompareValuesUtility.logFailed("Id", "Not expected in DB "+storeProductId, "Data occuring in DB");

						     }

						CompareValuesUtility.setupResult(storeProductId, true);

					}


				}
			} catch (Exception e) {

				System.out.println("[Exeception occured]Please check this storeID : "+storeID);
			}



		}   ///end of while loop

		br.close();
		CompareValuesUtility.teardown();
	}
	catch(Exception E){
		E.printStackTrace();
	}


	}

	
	 * will multiply the prices with multiplier and return value. For null prices will return zero
	 * 
	 * 
	public String allPriceMultipiler(String a,String b)   
	{   if ((a.equals("") && b.equals(""))|| a.equals(""))
		return "0.0";
	else if (b==null || b.equals("00") || b.equals("000") || b.equals("0"))
	{  Double a1=Double.parseDouble(a);
	a1=0.0; 
	return a1.toString();
	}
	else  
	{  Double a1=Double.parseDouble(a);
	Double b1=Double.parseDouble(b);
	a1=(a1/100)/ b1;
	Math.round(a1);
	return a1.toString();
	}
	}




	public boolean validateStore(String stor) {
		if (storeIds.containsKey(stor)) {
			boolean storeStatus = storeIds.get(stor);
			return storeStatus;
		} else {

			String com = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, stor);
			if (com != "[]" || com != null) {
				storeIds.put(stor, true);
				return true;
			} else {
				storeIds.put(stor, false);
				return false;
			}
		}

	}

	*//**
	 * Check if sears id is added in the kmart store pricing
	 * @param Searspid
	 * @return
	 *//*
	public boolean validateSearsNotPresent(String otherpid)
	{
		String Sr=RestExecutor.getJSonResponseById(CollectionValuesVal.SHCPRICING,otherpid);
		if (Sr.equals("[]")||Sr==null)
		{
			//System.out.println("Partnumber not added to collection"+ otherpid);
			return false;
		}
		else
			return true;    //sears partnumber present in shc_pricing for kmart national pricing
	}



	public boolean compareSaleEndDate(String d1) { // method to check if date is valid or not
		Date d = new Date();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date c1 = sf.parse(sf.format(d)); // /to get current date

			Date a1 = sf.parse(convertDate(d1));
			if (a1.compareTo(c1) >= 0) // to compare   a1.compareTo(c1) <= 0 && b1.compareTo(c1) >= 0
			{
				return true;
			} else {
				return false;
			}
		} catch (ParseException pr) {
			pr.printStackTrace();
			return false;
		}
	}




	public String convertDate(String d)
	{  String MM=d.substring(0, 2);
	String dd=d.substring(2, 4);
	String yyyy=d.substring(4,8);
	String date1=(yyyy+"-"+MM+"-"+dd);
	return date1;
	}

	public void compareVGCPrices(ShcPricing storePricingGB1,String storeProductId1)
	{if(storePricingGB1.getP().getR().size()== 1)
	{
		CompareValuesUtility.compareValues("Regular Price","10.0", storePricingGB1.getP().getR().get(0).getIp().toString());
	}
	else 
		CompareValuesUtility.logFailed("Regular Price","10.0", "Regular price not loaded for Gift card");

	}

	public void compareAllPrices(ShcPricing storePricingGB1,String storeProductId1,String upcCode1,String upcTypeCode1,String UpcPriceAmt1,String UpcPriceMul1,String AssosDisPrice1,String AssoDiscMul1,String wasPrice1,String wasPriceMul1,String eventPrice1,String eventPriceMul1,String eventFlag1,String eventEndDate1)
	{   

		if (upcTypeCode1.equals("1"))   ///to check regular price
		{   String price=allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1);
		if (Double.parseDouble(price)>0.02){
			if(storePricingGB1.getP().getR().size()>0){
				CompareValuesUtility.compareValues("Regular Price",  price.toString(), storePricingGB1.getP().getR().get(0).getIp().toString());
			}
			else 
				CompareValuesUtility.logFailed("Regular Price",price , "Regular price not loaded");

		}else{
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getR().size()==0,"Regular Price","Regular price not set","Regular price found");

		}

		}

		if (upcTypeCode1.equals("3"))    /// to check clearance price
		{   String price=allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1);
		if (Double.parseDouble(price)>0.02){
			if(storePricingGB1.getP().getX().size()>0){
				CompareValuesUtility.compareValues("Clearance Price",  price.toString(), storePricingGB1.getP().getX().get(0).getIp().toString());
			}
			else 
				CompareValuesUtility.logFailed("Clearance Price",price.toString() , "clearance price not loaded");

		}else{
			CompareValuesUtility.compareValues("Clearance Price",  "0.00", storePricingGB1.getP().getX().get(0).getIp().toString());

		}

		}




		String assoPrice=allPriceMultipiler(AssosDisPrice1,AssoDiscMul1);   //to compare associated price
		if (Double.parseDouble(assoPrice)>0.02){
			if(storePricingGB1.getP().getA().size() == 1){
				CompareValuesUtility.compareValues("Associated Price",  assoPrice.toString(), storePricingGB1.getP().getA().get(0).getIp().toString());
			}
			else 
				CompareValuesUtility.logFailed("Associated Price",assoPrice , "Associated price not loaded");

		}else{
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getA().size()==0,"Associated Price","Associated price not set","Associated price found");

		}




		String WasPrice=allPriceMultipiler(wasPrice1,wasPriceMul1);  //to compare was price
		if (Double.parseDouble(WasPrice)>0.02)
		{ if (storePricingGB1.getP().getW()==null)
		{ CompareValuesUtility.verifyTrue(true,"Was Price",WasPrice,"Was price not found");
		}
		else 			 
			CompareValuesUtility.compareValues("Was Price",  WasPrice.toString(), storePricingGB1.getP().getW().toString());
		} else 
		{ CompareValuesUtility.verifyTrue(storePricingGB1.getP().getW().toString()==null,"Was Price","Was price not set","Was price found");
		}



		if(eventFlag1.equals("Y") && compareSaleEndDate(eventEndDate1))   //to compare sale price
		{ String EventPrice=allPriceMultipiler(eventPrice1, eventPriceMul1);

		String convertedDate=DateConverts(eventEndDate1.toString());

		if (Double.parseDouble(EventPrice)>0.02)
		{ if(storePricingGB1.getP().getS().size()== 1)
		    {   CompareValuesUtility.compareValues("Sale Price",  EventPrice.toString(), storePricingGB1.getP().getS().get(0).getIp().toString());
		        CompareValuesUtility.compareValues("Sale End Date",convertedDate,storePricingGB1.getP().getS().get(0).getEt().toString().substring(0,10));
		     }
		  else 
			  CompareValuesUtility.logFailed("Sale Price",EventPrice.toString() , "Sale price not loaded");
		}  
		else 
		{ 
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
		}  
		}
		////to check if sale price is still not loaded
		else {
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
			
		     }
		

	}

	
	public void compareVDItemPrices(ShcPricing storePricingGB1,String storeProductId1,String upcCode1,String upcTypeCode1,String UpcPriceAmt1,String UpcPriceMul1,String AssosDisPrice1,String AssoDiscMul1,String wasPrice1,String wasPriceMul1,String eventPrice1,String eventPriceMul1,String eventFlag1,String eventEndDate1)
	{   

		if (upcTypeCode1.equals("1"))   ///to check regular price
		{   String price=allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1);
		if (Double.parseDouble(price)>0.02){
			if(storePricingGB1.getP().getR().size()>0){
				CompareValuesUtility.compareValues("Regular Price",  price.toString(), storePricingGB1.getP().getR().get(0).getIp().toString());
			}
			else 
				CompareValuesUtility.logFailed("Regular Price",price , "Regular price not loaded");

		}else{
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getR().size()==0,"Regular Price","Regular price not set","Regular price found");

		}

		}

		if (upcTypeCode1.equals("3"))    /// to check clearance price
		{   String price=allPriceMultipiler(UpcPriceAmt1,UpcPriceMul1);
		if (Double.parseDouble(price)>0.02){
			if(storePricingGB1.getP().getX().size()>0){
				CompareValuesUtility.logFailed("Clearance Price","No clearance for VD items" , "clearance price loaded");
			}
			else 
				CompareValuesUtility.logPassed("Clearance Price","No clearance for VD items", "clearance price not loaded");

		}else{
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getX().size()==0,"Clearance Price","No clearance price for VD items","Clearance price found");

		}

		}




		String assoPrice=allPriceMultipiler(AssosDisPrice1,AssoDiscMul1);   //to compare associated price
		if (Double.parseDouble(assoPrice)>0.02){
			if(storePricingGB1.getP().getA().size() == 1){
				CompareValuesUtility.compareValues("Associated Price",  assoPrice.toString(), storePricingGB1.getP().getA().get(0).getIp().toString());
			}
			else 
				CompareValuesUtility.logFailed("Associated Price",assoPrice , "Associated price not loaded");

		}else{
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getA().size()==0,"Associated Price","Associated price not set","Associated price found");

		}




		String WasPrice=allPriceMultipiler(wasPrice1,wasPriceMul1);  //to compare was price
		if (Double.parseDouble(WasPrice)>0.02)
		{ if (storePricingGB1.getP().getW()==null)
		{ CompareValuesUtility.verifyTrue(true,"Was Price",WasPrice,"Was price not found");
		}
		else 			 
			CompareValuesUtility.compareValues("Was Price",  WasPrice.toString(), storePricingGB1.getP().getW().toString());
		} else 
		{ CompareValuesUtility.verifyTrue(storePricingGB1.getP().getW().toString()==null,"Was Price","Was price not set","Was price found");
		}



		if(eventFlag1.equals("Y") && compareSaleEndDate(eventEndDate1))   //to compare sale price
		{ String EventPrice=allPriceMultipiler(eventPrice1, eventPriceMul1);

		String convertedDate=DateConverts(eventEndDate1.toString());

		if (Double.parseDouble(EventPrice)>0.02)
		{ if(storePricingGB1.getP().getS().size()== 1)
		    {   CompareValuesUtility.compareValues("Sale Price",  EventPrice.toString(), storePricingGB1.getP().getS().get(0).getIp().toString());
		        CompareValuesUtility.compareValues("Sale End Date",convertedDate,storePricingGB1.getP().getS().get(0).getEt().toString().substring(0,10));
		     }
		  else 
			  CompareValuesUtility.logFailed("Sale Price",EventPrice.toString() , "Sale price not loaded");
		}  
		else 
		{ 
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
		}  
		}
		////to check if sale price is still not loaded
		else {
			CompareValuesUtility.verifyTrue(storePricingGB1.getP().getS().size()==0,"Sale Price","Sale price not set","Sale price found");
			
		     }
		

	}
	
	
	
	public boolean nationalValidation(String product_Id)
	{ boolean NationalValidation=false; 
	Offer offer=RestExecutor.getDataById(CollectionValuesVal.OFFER, product_Id);  ///get offer
	if(offer.getDispTags().getIsGiftWrapElig())
		return NationalValidation;
	else 
	{NationalValidation=true;
	return NationalValidation;}

	}

	*//**
	 * 
	 * @param upcTypeCode   will be 0 (12 digit upc)  
	 * 1,2(8 digit upc)  ,3 (13 digit upc) ,7 (14 digit upc) 
	 * @param upc
	 * @return
	 *//*
	public String getUpc(String upcTypeCode, String upc)
	{  String tmp=upc;
	String upcCode;
	if(upcTypeCode.equalsIgnoreCase("0"))
	{
		upcCode=tmp.substring(tmp.length()-12, tmp.length());
		return upcCode;
	}       
	else if(upcTypeCode.equalsIgnoreCase("1") || upcTypeCode.equalsIgnoreCase("2"))
	{
		upcCode=tmp.substring(tmp.length()-8, tmp.length());
		return upcCode;
	}       

	else if(upcTypeCode.equalsIgnoreCase("3"))
	{
		upcCode=tmp.substring(tmp.length()-13, tmp.length());
		return upcCode;
	}       
	else if(upcTypeCode.equalsIgnoreCase("7"))
	{
		upcCode=tmp.substring(tmp.length()-14, tmp.length());
		return upcCode;
	}
	return upc;  ///meaning invalid upc which will get rejected
	}

	*//***
	 * to get the dat in format as in response in GB. however not exactly in iso format
	 * @param s
	 * @return
	 *//*
	public String DateConverts(String s)
	{   String mm=s.substring(0, 2);
	String dd=s.substring(2, 4);
	String yy=s.substring(4,8);
	//Date d=new Date();
	//String a=(yy+"-"+mm+"-"+dd);

	return (yy+"-"+mm+"-"+dd);

	}
	
	public void upcFileWriting(String u)
	{ try {
		b.write("No data returned for the upc "+u);
		b.newLine();
	} catch (IOException e) {
		e.printStackTrace();
	}
		
	}
	
	public void productFileWriting(String p)
	{ try {
		b.write("_ft.prgmtype is not Kmart. Hence not written in shc_pricing collection "+p);
		b.newLine();
	} catch (IOException e) {
		e.printStackTrace();
	}
		
	}*/

}
