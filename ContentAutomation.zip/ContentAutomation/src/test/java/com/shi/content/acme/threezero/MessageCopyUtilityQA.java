package com.shi.content.acme.threezero;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.contentscoreMsg.ContentscoreMsg;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class MessageCopyUtilityQA 
{
	@Test(groups="MessageCopyUtilityQA")
	public void copyDataToQueue()
	{
		String logPrint = System.getProperty("printLog", "true");
		System.out.println("logPrint.. "+logPrint);


		if(LoadProperties.KAFKABROKER2.toUpperCase().contains("PROD") ||
				LoadProperties.KAFKATOPIC2.toUpperCase().contains("PROD") ||
				LoadProperties.ZOOKEEPER2.toUpperCase().contains("PROD")			)
		{
			LoadProperties.setCustomMsgForEmail("Can not post to prod topics", MSGTYPE.ERROR);
		}
		else
		{
			BlockingQueue<List<ContentscoreMsg>> acmeMatchdataDocs = new LinkedBlockingQueue<List<ContentscoreMsg>>();

			//QueueToQueueCopyQA
			KafkaIAConsumer<ContentscoreMsg> prodThread = new KafkaIAConsumer<ContentscoreMsg>("MessageCopyUtilityQA", ContentscoreMsg.class, acmeMatchdataDocs);		
			Thread t = new Thread(prodThread);
			t.start();

			int iMessageCount=0;

			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

			Gson g=new Gson();

			try 
			{
				while (true) 
				{
					List<ContentscoreMsg> nodeToTest;

					nodeToTest = acmeMatchdataDocs.poll(50, TimeUnit.SECONDS);

					if (nodeToTest == prodThread.POISON_PILL) {
						System.out.println("Got poison pill ..breaking out");
						break;
					}

					if (nodeToTest != null)
					{
						iMessageCount++;
						pool.execute(new KafkaPush(g.toJson(nodeToTest.get(0))));

						if(logPrint.equalsIgnoreCase("true"))
							System.out.println("Actual Json to publish......."+g.toJson(nodeToTest.get(0)));
					}

					if(iMessageCount==LoadProperties.TESTDATALIMIT)
					{
						break;
					}

				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			pool.shutdown();

			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(iMessageCount == 0 ){
				LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
			}
		}

	}
}