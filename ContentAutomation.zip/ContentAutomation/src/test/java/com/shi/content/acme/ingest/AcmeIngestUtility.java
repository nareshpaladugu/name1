package com.shi.content.acme.ingest;

import java.net.URI;
import java.net.URISyntaxException;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;

/**
 * Temporary utility to read from reconciled db and push to content kafka queue
 * Uses testdatalimit property to push number of records
 * @author Niharika Varshney
 *
 */
public class AcmeIngestUtility {

	@Test(groups="AcmeIngestUtility")
	public void ingest(){
		
		String feedSource = System.getProperty("feedSource","null");
		String ingestServer = System.getProperty("ingestServer", "iaapp305p.qa.ch3.s.com:8180");
		String filePath = System.getProperty("filePath","/tmp/");
		
		String ids = System.getProperty("ids");
		
		try {
		if(feedSource.equals("sellerPortal")){
			for(String id : ids.split(",")){
				String config = RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeDelta"));
				//System.out.println(configResponse);
				String attributes = JsonStringParser.getJsonValue(config, "{item{attributes}}",",");
				//System.out.println(attributes);
				String inputFile = JsonStringParser.getJsonValue(attributes, "{inputFile}",",");
				//System.out.println(inputFile);
				String newAttributes = attributes.replaceAll(inputFile, filePath + "catalog-delta-" + id + ".xml");
				//System.out.println(newAttributes);
				String newConfig = "[{\"attributes\":" + newAttributes + ",\"path\": \"ingest.acmeDelta\"}]";
				//System.out.println(newConfig);
				
				System.out.println("Putting config for seller: " + id);
				String configUrl ="http://"+LoadProperties.IA_SERVER+"/acme/config/";
				String configResp = RestExecutor.putRequest(configUrl, newConfig);
				//System.out.println(configResp);
				
				//System.out.println(RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeDelta")));
				
				System.out.println("Ingesting seller: " + id);
				System.out.println(RestExecutor.getJSonResponse(new URI("http://"+ingestServer+"/acme/ingest/acmeDelta")));
			}
		}else if(feedSource.equals("spin")){
			for(String id : ids.split(",")){
				String config = RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeSpin"));
				//System.out.println(configResponse);
				String attributes = JsonStringParser.getJsonValue(config, "{item{attributes}}",",");
				//System.out.println(attributes);
				String inputFile = JsonStringParser.getJsonValue(attributes, "{inputFile}",",");
				//System.out.println(inputFile);
				String newAttributes = attributes.replaceAll(inputFile, filePath + "offering-sears-" + id + ".xml");
				//System.out.println(newAttributes);
				String newConfig = "[{\"attributes\":" + newAttributes + ",\"path\": \"ingest.acmeSpin\"}]";
				//System.out.println(newConfig);
				
				System.out.println("Putting config for itemClass: " + id);
				String configUrl ="http://"+LoadProperties.IA_SERVER+"/acme/config/";
				String configResp = RestExecutor.putRequest(configUrl, newConfig);
				//System.out.println(configResp);
				
				//System.out.println(RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeSpin")));
				
				System.out.println("Ingesting itemClass: " + id);
				System.out.println(RestExecutor.getJSonResponse(new URI("http://"+ingestServer+"/acme/ingest/acmeSpin")));
			}
		}else if(feedSource.equals("spinInActive")){
			for(String id : ids.split(",")){
				String config = RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeSpinInActive"));
				//System.out.println(configResponse);
				String attributes = JsonStringParser.getJsonValue(config, "{item{attributes}}",",");
				//System.out.println(attributes);
				String inputFile = JsonStringParser.getJsonValue(attributes, "{inputFile}",",");
				//System.out.println(inputFile);
				String newAttributes = attributes.replaceAll(inputFile, filePath + "sears-delete-" + id + ".xml");
				//System.out.println(newAttributes);
				String newConfig = "[{\"attributes\":" + newAttributes + ",\"path\": \"ingest.acmeSpinInActive\"}]";
				//System.out.println(newConfig);
				
				System.out.println("Putting config for itemClass: " + id);
				String configUrl ="http://"+LoadProperties.IA_SERVER+"/acme/config/";
				String configResp = RestExecutor.putRequest(configUrl, newConfig);
				//System.out.println(configResp);
				
				//System.out.println(RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeSpinInActive")));
				
				System.out.println("Ingesting itemClass: " + id);
				System.out.println(RestExecutor.getJSonResponse(new URI("http://"+ingestServer+"/acme/ingest/acmeSpinInActive")));
			}
		}else if(feedSource.equals("uvd")){
			for(String id : ids.split(",")){
				String config = RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeAuto"));
				//System.out.println(configResponse);
				String attributes = JsonStringParser.getJsonValue(config, "{item{attributes}}",",");
				//System.out.println(attributes);
				String inputFile = JsonStringParser.getJsonValue(attributes, "{inputFile}",",");
				//System.out.println(inputFile);
				String newAttributes = attributes.replaceAll(inputFile, filePath + "spin-automotive-items-" + id + ".xml");
				//System.out.println(newAttributes);
				String newConfig = "[{\"attributes\":" + newAttributes + ",\"path\": \"ingest.acmeAuto\"}]";
				//System.out.println(newConfig);
				
				System.out.println("Putting config for vendorId: " + id);
				String configUrl ="http://"+LoadProperties.IA_SERVER+"/acme/config/";
				String configResp = RestExecutor.putRequest(configUrl, newConfig);
				//System.out.println(configResp);
				
				//System.out.println(RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeAuto")));
				
				System.out.println("Ingesting vendorId: " + id);
				System.out.println(RestExecutor.getJSonResponse(new URI("http://"+ingestServer+"/acme/ingest/acmeAuto")));
			}
		}else if(feedSource.equals("uvdInActive")){
			for(String id : ids.split(",")){
				String config = RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeUvdInActive"));
				//System.out.println(configResponse);
				String attributes = JsonStringParser.getJsonValue(config, "{item{attributes}}",",");
				//System.out.println(attributes);
				String inputFile = JsonStringParser.getJsonValue(attributes, "{inputFile}",",");
				//System.out.println(inputFile);
				String newAttributes = attributes.replaceAll(inputFile, filePath + "spin-automotive-delete-" + id + ".xml");
				//System.out.println(newAttributes);
				String newConfig = "[{\"attributes\":" + newAttributes + ",\"path\": \"ingest.acmeUvdInActive\"}]";
				//System.out.println(newConfig);
				
				System.out.println("Putting config for vendorId: " + id);
				String configUrl ="http://"+LoadProperties.IA_SERVER+"/acme/config/";
				String configResp = RestExecutor.putRequest(configUrl, newConfig);
				//System.out.println(configResp);
				
				//System.out.println(RestExecutor.getJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/config/node/ingest.acmeUvdInActive")));
				
				System.out.println("Ingesting vendorId: " + id);
				System.out.println(RestExecutor.getJSonResponse(new URI("http://"+ingestServer+"/acme/ingest/acmeUvdInActive")));
			}
		}else{
			System.out.println("Please provide valid feedSource value");
		}
		
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	}
}
