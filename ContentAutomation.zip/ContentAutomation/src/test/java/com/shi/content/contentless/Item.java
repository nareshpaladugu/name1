package com.shi.content.contentless;

public class Item {

		private String itemId;
		private String sellerId;
		private String packageQuantity;
		private String asin;
		private String ssin;
		private String upc;
		private String brand;
		private String modelNo;
		public String getItemId() {
			return itemId;
		}
		public void setItemId(String itemId) {
			this.itemId = itemId;
		}
		public String getSellerId() {
			return sellerId;
		}
		public void setSellerId(String sellerId) {
			this.sellerId = sellerId;
		}
		public String getPackageQuantity() {
			return packageQuantity;
		}
		public void setPackageQuantity(String packageQuantity) {
			this.packageQuantity = packageQuantity;
		}
		public String getAsin() {
			return asin;
		}
		public void setAsin(String asin) {
			this.asin = asin;
		}
		public String getSsin() {
			return ssin;
		}
		public void setSsin(String ssin) {
			this.ssin = ssin;
		}
		public String getUpc() {
			return upc;
		}
		public void setUpc(String upc) {
			this.upc = upc;
		}
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}
		public String getModelNo() {
			return modelNo;
		}
		public void setModelNo(String modelNo) {
			this.modelNo = modelNo;
		}
		@Override
		public String toString() {
			return "Item [itemId=" + itemId + ", sellerId=" + sellerId
					+ ", packageQuantity=" + packageQuantity + ", asin=" + asin
					+ ", ssin=" + ssin + ", upc=" + upc + ", brand=" + brand
					+ ", modelNo=" + modelNo + "]";
		}

		

}
