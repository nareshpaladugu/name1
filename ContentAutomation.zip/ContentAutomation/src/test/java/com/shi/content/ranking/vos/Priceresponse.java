package com.shi.content.ranking.vos;

import java.util.ArrayList;
import java.util.List;

public class Priceresponse {
	//private Itemresponse itemresponse;	

	/*public Itemresponse getItemresponse() {
		return itemresponse;
	}

	public void setItemresponse(Itemresponse itemresponse) {
		this.itemresponse = itemresponse;
	}*/
	
	private List<Itemresponse> itemresponse = new ArrayList<Itemresponse>();

	public List<Itemresponse> getItemresponse() {
		return itemresponse;
	}

	public void setItemresponse(List<Itemresponse> itemresponse) {
		this.itemresponse = itemresponse;
	}

}
