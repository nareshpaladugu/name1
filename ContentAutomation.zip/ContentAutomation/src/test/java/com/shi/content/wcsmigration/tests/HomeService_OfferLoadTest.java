package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.xmls.serviceofferings.SingleServiceProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.HomeService_OfferVerifications;

public class HomeService_OfferLoadTest
{
	public static boolean checkSSINAndUID = false;

	static List<String> erroredPartNumbers = new ArrayList<String>();

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="HomeServiceOfferLoadTest")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException
	{
		if(CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Skipping file since threshold exceeded "+ sFileName);
			return;
		}

		System.out.println("Testing file "+ sFileName);

		String sSite = "sears";

		BlockingQueue<List<SingleServiceProductOffer>> singleServiceProductOfferQueue = new LinkedBlockingQueue<List<SingleServiceProductOffer>>(500);

		SHCContentCommons shcOfferCommons = new SHCContentCommons(sFileName,sSite);

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleServiceProductOffer> prodThread = new ChunkProducerThread<SingleServiceProductOffer>(sFileName, singleServiceProductOfferQueue, SingleServiceProductOffer.class,"single-service-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				if(!pool.isTerminated() && (CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD)){
					pool.shutdownNow();
					break;
				}
				List<SingleServiceProductOffer> nodeToTest = singleServiceProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){

					//	System.out.println("item-class-id: "+sItemClassId);

					//					System.out.println("Values passed for verification:" + nodeToTest.get(0) + " " + shcOfferCommons + " " + " " + sSite + " " + erroredPartNumbers);

					pool.execute(new HomeService_OfferVerifications(nodeToTest.get(0),shcOfferCommons, sSite, erroredPartNumbers));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();

			}
		}

		if(!pool.isTerminated() && (CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD)){
			pool.shutdownNow();
		} else
		{
			pool.shutdown();
		}

		while ((CompareValuesUtility.getFinalResult().getFailedCount() < LoadProperties.FAILURE_THRESHOLD) && !pool.isTerminated()){
			Thread.sleep(1000);
		}

		if(!pool.isTerminated() && (CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD)){
			System.out.println("Failure count exceed "+ CompareValuesUtility.getFinalResult().getFailedCount());
			pool.shutdownNow();
			CompareValuesUtility.setRunAborted(true);


		}
		System.out.println("Pool terminated "+ pool.isTerminated());
	}

	@BeforeClass(groups="SHCOfferLoadTestNew")
	public void initErrorParts(){

		checkSSINAndUID = Boolean.parseBoolean(System.getProperty("checkSSINandUID", "false"));

		String errorlogFile = System.getProperty("errorLogFile", "");

		if((errorlogFile!=null) && !errorlogFile.isEmpty())
		{
			erroredPartNumbers = ErrorPartReader.  getErrorPartsFromLogFile(errorlogFile);
		}
	}


}