package com.shi.content.rankingMyTest;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.generated.vos.offer.OfferSchema;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class ChangeItemCondtion {

	public static void main(String[] args) throws InterruptedException {
		
		String offer="SPM7704563110";
	
//		String condition="NEW";
//		String condition="NEW_OTHER";
//		String condition="NEW_BLEMISHED";
//		String condition="REFURBISHED";
//		String condition="REFURBISHED_SELLER";
//		String condition="REFURBISHED_MANUFACTURER_AUTHORIZED";
//		String condition="USED_LIKE_NEW";
//		String condition="USED_GOOD";
		String condition="USED_ACCEPTABLE";
//		String condition="USED_POOR";
		
		updateItemCondtionToOffer(offer,condition);
		
		
	}

	
	
	
	
	private void searchForOffers() {

//		RestExecutor.get

	}
	
	
	
	private static void updateItemCondtionToOffer(String offer,String newCondition) {

//		-------------code to update item condition tag--------START-------------//
		
		String offerResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER, offer);
		System.out.println("\nofferResponse\n"+offerResponse);
		
		Gson gson = new Gson();
		offerResponse=offerResponse.substring(1, offerResponse.length()-1);
		OfferSchema offerObj= gson.fromJson(offerResponse, OfferSchema.class);

		String condition= offerObj.getBlob().getOffer().getCondition().getStatus();
	
		offerResponse=offerResponse.replaceAll(condition, newCondition);
		
		System.out.println(offerResponse+"\nCondition Changed to:\n"+newCondition);

		
		
		
		
		
//		System.out.println("\n\nssin:"+ssin);
//		
//		System.out.println("\n\nuid:"+uid);
		
//		-------------code to update item condition tag-----END----------------//

		
		
//		--------------------not working post /put--------------------------//
//		RestExecutor.postForJSonResponse(offer, s);
//		RestExecutor.putRequest("http://green2vip.qa.ch3.s.com:8080/gbox/gb/s/data/get/offer/", s);
//		RestExecutor.putRequest(offer, s);
//		RestExecutor.postForJSonResponse("http://green2vip.qa.ch3.s.com:8080/gbox/gb/s/data/get/offer/", s);
		
//		--------------------not working post /put--------------------------//
		
	}
	
	
	
	public List<String> getBucketRange()
	{
		List<String> lstValues = new ArrayList<String>();

		if(LoadProperties.RUN_PARAMS.contains("-")){
			String[] range = LoadProperties.RUN_PARAMS.split("-");
			for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
				lstValues.add(i.toString());
			}
			System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

		}
		else
		{
			lstValues.add(LoadProperties.RUN_PARAMS);
		}

		return lstValues;
	}
	
	private void trial() {

		// List<String> noOfoffers= new ArrayList<String>();
		//
		// for(String offer:noOfoffers){
		// String
		// offerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER,
		// offer);
		//
		// }

		String offerResponse = RestExecutor.getJSonResponseById(
				CollectionValuesVal.OFFER, "SPM7371082507");

		System.out.println(offerResponse);

		System.out.println("\n\n\n"
				+ offerResponse.substring(1, offerResponse.length() - 1)
				+ "\n\nend");

		// -------
		// String
		// offerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER,
		// "SPM7371082507");

		System.out.println("\nResponse\n" + offerResponse);

		// System.out.println(offerResponse.);

		System.out.println("\n\n\n"
				+ offerResponse.substring(1, offerResponse.length() - 1)
				+ "\n\nend");

		// RestExecutor.postForJSonResponse(url, body)

		
		
		
		
	}
	
	private void psvm() {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();

		driver.get("http://batch302p.qa.ch3.s.com:8086/RestJsonClient/faces/views/forfeit/login.xhtml");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//*[@id='frm-login:txt-uname']")).sendKeys("inaikwa");
		
		driver.findElement(By.xpath("//*[@id='frm-login:txt-pword']")).sendKeys("@zahid30");
		
		driver.findElement(By.xpath("//*[@id='frm-login:btn-login']")).click();
		
//		driver.wait(6000);
		
		if (driver.findElement(By.xpath("//*[@id='frm-menu:j_idt33']/ul/li[1]")).isDisplayed())
				driver.findElement(By.xpath("//*[@id='frm-menu:j_idt38']/span[2]")).click();
		
		driver.findElement(By.xpath("//*[@id='j_idt63:j_idt66_label']")).click();
		
	}
}
