package com.shi.content.acme.threezero;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.threezero.vos1.Priority;
import com.shi.content.acme.threezero.vos2.ProgramType;
import com.shi.content.matching.SingleOfferMatchDataVo;

public class AcmeThreeHelper {

	public static Priority getPriority()
	{
		String resp=RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/config/node/reconcile.priority");

		Gson gson = new Gson();

		Priority p = gson.fromJson(resp, Priority.class);

		return p;
	}
	public static void prepareConfig(Map<Integer,List<String>> programTypeMap)
	{
		Gson gson = new Gson();

		String resp2=RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/config/node/reconcile.programType");

		ProgramType pt = gson.fromJson(resp2, ProgramType.class);

		updatePtMap(programTypeMap, pt.getItem().getAttributes().getSEARS(), "SEARS");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getKMART(), "KMART");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getUVD(), "UVD");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getPreferredContent(), "PreferredContent");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getSelectedContent(), "SelectedContent");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getDSS(), "DSS");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getFBM(), "FBM");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getFBS(), "FBS");
		updatePtMap(programTypeMap, pt.getItem().getAttributes().getForceSsin(), "forceSsin");
	}

	public static void updatePtMap(Map<Integer,List<String>> programTypeMap,int priorityNumber,String programType)
	{
		List<String> listOfSamePriorityProgTypes = programTypeMap.get(priorityNumber);

		if(listOfSamePriorityProgTypes==null)
		{
			listOfSamePriorityProgTypes=new ArrayList<>();
		}
		listOfSamePriorityProgTypes.add(programType);

		programTypeMap.put(priorityNumber, listOfSamePriorityProgTypes);
	}

	public static List<SingleOfferMatchDataVo > getShortListByProgramType(List<SingleOfferMatchDataVo > list2,List<String> programTypes)
	{
		List<SingleOfferMatchDataVo > sourceIdMap = new ArrayList<SingleOfferMatchDataVo>();

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list2) {

			if(programTypes.contains(singleOfferMatchDataVo.getProgramType()))
			{
				sourceIdMap.add(singleOfferMatchDataVo);
			}
		}

		return sourceIdMap;
	}

	public static List<SingleOfferMatchDataVo > getShortListByMisClassFalse(List<SingleOfferMatchDataVo > list2)
	{
		List<SingleOfferMatchDataVo > sourceIdMap = new ArrayList<SingleOfferMatchDataVo>();

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list2) {

			if(singleOfferMatchDataVo.getMisClass()==false)
			{
				sourceIdMap.add(singleOfferMatchDataVo);
			}
		}

		return sourceIdMap;
	}

	public static SingleOfferMatchDataVo getOldestSpinId(List<SingleOfferMatchDataVo > list2)
	{
		Map<String, SingleOfferMatchDataVo> map= new TreeMap<String, SingleOfferMatchDataVo>();

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list2) {

			map.put(singleOfferMatchDataVo.getSpinId(),singleOfferMatchDataVo);
		}

		SingleOfferMatchDataVo selected = map.get(map.keySet().toArray()[0]);

		return selected;
	}

	public static List<SingleOfferMatchDataVo > getShortListByContentScore(List<SingleOfferMatchDataVo > list2)
	{
		List<SingleOfferMatchDataVo > withoutScore = new ArrayList<SingleOfferMatchDataVo>();

		Map<Double,List<SingleOfferMatchDataVo >> map= new HashMap<Double, List<SingleOfferMatchDataVo>>();

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list2) {


			if(singleOfferMatchDataVo.getContentScore()==null)
			{
				withoutScore.add(singleOfferMatchDataVo);
			}
			else
			{
				List<SingleOfferMatchDataVo> list = map.get(singleOfferMatchDataVo.getContentScore());

				if(list == null)
					list = new ArrayList<SingleOfferMatchDataVo>();

				list.add(singleOfferMatchDataVo);

				map.put(singleOfferMatchDataVo.getContentScore(),list);
			}
		}

		Set<Double> keySet = map.keySet();

		List<SingleOfferMatchDataVo> sourceIdMap = new ArrayList<SingleOfferMatchDataVo>();

		if(keySet.isEmpty())
		{
			System.out.println("Nothing Shortlisted for Content Score");
			return sourceIdMap;
		}

		List<Double> listDb = new ArrayList<Double>();
		listDb.addAll(keySet);

		Collections.sort(listDb, Collections.reverseOrder());

		System.out.println("Highest score : "+listDb.get(0));

		sourceIdMap = map.get(listDb.get(0));

		sourceIdMap.addAll(withoutScore);

		return sourceIdMap;
	}

	public static void updateMisClass(List<SingleOfferMatchDataVo > list)
	{
		String resp;
		String flag;
		boolean bFlag;

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list) {

			resp =RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/misclass/"+singleOfferMatchDataVo.getSpinId());

			flag = JsonStringParser.getJsonValueNew(resp, "item.attributes.misclass");

			bFlag=flag==null||flag.isEmpty()||flag.equalsIgnoreCase("null")?false:Boolean.parseBoolean(flag);

			System.out.println(singleOfferMatchDataVo.getSpinId() +" misclass :  "+bFlag);

			singleOfferMatchDataVo.setMisClass(bFlag);
		}

	}

	public static void updateContentScore(List<SingleOfferMatchDataVo > list)
	{
		String resp;
		String aggregateScore;
		Double aggregateScoreDbl;

		for (SingleOfferMatchDataVo singleOfferMatchDataVo : list) {

			resp =RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/contentscore/"+singleOfferMatchDataVo.getSpinId());

			aggregateScore = JsonStringParser.getJsonValueNew(resp, "item.attributes.aggregateScore");

			aggregateScoreDbl=aggregateScore==null||aggregateScore.isEmpty()||aggregateScore.equalsIgnoreCase("null")?null:Double.parseDouble(aggregateScore);

			System.out.println(singleOfferMatchDataVo.getSpinId() +" Content Score :  "+aggregateScoreDbl);

			singleOfferMatchDataVo.setContentScore(aggregateScoreDbl);
		}
	}


	public static List<SingleOfferMatchDataVo > getSourceItemsByGuid(String guid)
	{

		List<SingleOfferMatchDataVo > sourceIdMap = new ArrayList<SingleOfferMatchDataVo>();
		if(guid==null)
			return sourceIdMap;

		String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/features?guid="+guid+"&count";

		try {

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);

			int totalSourceCount = Integer.parseInt(JsonStringParser.getJsonValue(jsonResponse, "{count}"));

			int totalPages = 0;
			int lastPageSize = 0;
			int pageSize =  150;

			totalPages = totalSourceCount/pageSize;
			lastPageSize = totalSourceCount%pageSize;
			if(totalSourceCount%pageSize == 0)
				totalPages--;

			JsonElement jsonElement;
			JsonArray array =null;

			JsonParser jParser = new JsonParser();

			for(int i = 0 ; i <=totalPages; i++)
			{
				if(i==totalPages)
					pageSize=lastPageSize;

				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source?guid="+guid+"&page-size="+pageSize+"&page="+i;

				jsonResponse = RestExecutor.getJSonResponse(sUrl);

				jsonElement = jParser.parse(jsonResponse);

				if(jsonElement.getAsJsonObject().get("items")!=null)
				{
					array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

					for (int ii = 0; ii < array.size(); ii++) 
					{

						sourceIdMap.add(getMatchingData(array.get(ii).getAsJsonObject(),false));
					}
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}

		return sourceIdMap;
	}

	public static SingleOfferMatchDataVo getMatchingData(JsonObject jsonObject,boolean featuresDb)
	{
		SingleOfferMatchDataVo vo =new SingleOfferMatchDataVo();

		JsonObject attributes =  jsonObject.get("attributes").getAsJsonObject();

		attributes=attributes==null?new JsonObject():attributes;

		vo.setSourceDbId(jsonObject.get("id")==null?"":jsonObject.get("id").getAsString());

		vo.setBrandName(attributes.get("brandName")==null?"":attributes.get("brandName").getAsString());

		vo.setUpc( attributes.get("upcCode")==null?"": attributes.get("upcCode").getAsString());

		vo.setSpinId(jsonObject.get("id")==null?"":jsonObject.get("id").getAsString());

		vo.setProgramType( attributes.get("programType")==null?"": attributes.get("programType").getAsString());


		vo.setContentId( attributes.get("contentId")==null?"": attributes.get("contentId").getAsString());

		if(featuresDb)
		{
			vo.setAcmeSourceStatus( attributes.get("status")==null?"": attributes.get("status").getAsString() );

			vo.setMasterVerticalId( attributes.get("itemClassId")==null?"": attributes.get("itemClassId").getAsString() );

			vo.setVarAttrs( attributes.get("defAttr")==null?"": attributes.get("defAttr").getAsString() );

			vo.setUid( attributes.get("guid")==null?"": attributes.get("guid").getAsString() );
		}
		else
		{
			vo.setAcmeSourceStatus( attributes.get("status")==null?"": 
				(attributes.get("status").getAsJsonObject()==null?"":
					attributes.get("status").getAsJsonObject().get("status")==null?"":attributes.get("status").getAsJsonObject().get("status").getAsString()));

			vo.setUid( jsonObject.get("guid")==null?"": jsonObject.get("guid").getAsString());
		}

		vo.setSsin( jsonObject.get("ssin")==null?"": jsonObject.get("ssin").getAsString());

		vo.setWebHierarchy( attributes.get("sites")==null?"": attributes.get("sites").toString());

		//calcSsin=item id in gb
		vo.setParentId( jsonObject.get("calcSsin")==null?"": jsonObject.get("calcSsin").getAsString());

		vo.setModelNumber(attributes.get("modelNumber")==null?"":attributes.get("modelNumber").getAsString());

		vo.setOfferType( attributes.get("classifier")==null?"": attributes.get("classifier").getAsString());

		vo.setIsUvd( jsonObject.get("isUvd")==null?false: Boolean.parseBoolean(jsonObject.get("isUvd").getAsString()));

		vo.setPackageQty(attributes.get("packageQuantity")==null?"":attributes.get("packageQuantity").getAsString());

		//Master Vertical and defAttr and div lines from features 
		return vo;
	}

	private String encodeField(String field)
	{
		field = field.replaceAll("&","%26").replaceAll("\"", "%22").replaceAll("&", "%26")
				.replaceAll(" ", "%20").replaceAll("!","%21").replaceAll("$", "%24").replaceAll("'", "%27");

		return field;
	}

}
