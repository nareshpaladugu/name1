package com.shi.content.ranking.vos;

import java.util.List;

public class SuccessItem {
	
	String partNumber;
	Boolean free;
	Boolean autoUpgrade;
	List<ShipMode> shipModes;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public Boolean getFree() {
		return free;
	}
	public void setFree(Boolean free) {
		this.free = free;
	}
	public Boolean getAutoUpgrade() {
		return autoUpgrade;
	}
	public void setAutoUpgrade(Boolean autoUpgrade) {
		this.autoUpgrade = autoUpgrade;
	}
	public List<ShipMode> getShipModes() {
		return shipModes;
	}
	public void setShipModes(List<ShipMode> shipModes) {
		this.shipModes = shipModes;
	}
}
