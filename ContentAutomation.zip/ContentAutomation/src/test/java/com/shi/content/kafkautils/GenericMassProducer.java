package com.shi.content.kafkautils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaProducer;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class GenericMassProducer {

	static int count;
	private BufferedWriter dataWriter;
	private static final String FILENAME = "IdToTimeStampOfInsertion_"+LoadProperties.KAFKATOPIC+".txt";
	
	@BeforeClass(groups="KafkaMassProducer")
	public void openFile()
	{

		try {
			
			File F=new File(FILENAME);  
			dataWriter=new BufferedWriter(new FileWriter(F));
			

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	@AfterClass(groups="KafkaMassProducer")
	public void closeFile()
	{
		System.out.println("Closing file........");
		try {
			dataWriter.flush();
			dataWriter.close();
		} catch (IOException e) {
		  e.printStackTrace();
		}
	}
	
	@Test(groups="KafkaMassProducer")
	public void gbBasedProducer(){
		
	String format = LoadProperties.KAFKA_MSG_FORMAT;

		System.out.println("Format is "+ format);
		
		count = Integer.parseInt(LoadProperties.RUN_PARAMS);
		
		Map<String, List<String>> mpItems = new HashMap<>();
		for(String type : LoadProperties.CRITERIA){
			mpItems.put(type, new ArrayList<String>());
		}
		
		
		
		int iBucket = 0;
		int currentSize = 0;
		boolean bSizeReached = false;
		
		while(true){
			int iSizeReturned = 0;
			
			for(String type : LoadProperties.CRITERIA){
				
				iSizeReturned = this.createData(mpItems, type, currentSize, iBucket);
				if(iSizeReturned != -1){
					currentSize +=iSizeReturned;
				}else{
					bSizeReached = true;
					break;
				}
				
			}
			iBucket++;
		
			if(bSizeReached)
				break;
			
			if(iBucket>4095){
				System.out.println("Bucket id greater than 4095 "+ iBucket);
				LoadProperties.setCustomMsgForEmail("Only "+ currentSize + " of type : "+ LoadProperties.CRITERIA+" items found in all 4096 buckets.", MSGTYPE.WARNING);
				break;
			}
		}
		
		if(currentSize == 0 && !bSizeReached ){
			LoadProperties.setCustomMsgForEmail("No data found of type : "+ LoadProperties.CRITERIA+" in all 4096 buckets.", MSGTYPE.ERROR  );
			return;
		}
		
		//Create a new producer
		KafkaProducer kProd = new KafkaProducer();
		
		Map<String, Long> idToTS = new HashMap<String, Long>();
		
		for(String type : mpItems.keySet()){
			List<String> lstIds = mpItems.get(type);
			
			for(String id : lstIds){
				System.out.println("Posting for id "+ id);
				String sellerId=null;
				//For FBM and DSS, remove SPM from id
				String itemId = id;
				sellerId="1245";
				if(!type.equals("FBS")){
					itemId =  id.replace("SPM", "");
					
				}
				if(type.equals("CPC")){
					itemId=id.substring(id.lastIndexOf("S") + 1);
					
					sellerId=id.substring(id.lastIndexOf("A") + 1,id.lastIndexOf("S") + 0);
					System.out.println("Print"+itemId);
				}
					
				//Replace id and programType in standard message
				String messageToPost = formatMessageForMPItems(format, itemId, type,sellerId);
				
				long lsentTS = kProd.publishMessage(messageToPost);
				idToTS.put(id, lsentTS);
				
				try {
					dataWriter.write(id+":"+lsentTS);
					dataWriter.newLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
					
			}
		}
		kProd.shutdownProducer();
		
		if(bSizeReached)
			LoadProperties.setCustomMsgForEmail("Producer successfully pushed "+ count + " messages to queue.", MSGTYPE.SUCCESS  );
		
		
	}
	
	/**
	 * Hits the Greenbox offer collection to fetch offer ids based on the programType specified
	 * 
	 * @param mp  - Map of type to Ids.  Will be populated once data is fetched from greenbox
	 * @param programType - Type of data to fetch - FBM/FBS/DSS
	 * @param currentSize - currentSize to compare against total count
	 * @param iBucket - Bucket to fetch data from
	 * @return
	 */
	public int createData(Map<String, List<String>> mp, String programType, int currentSize, int iBucket){
		
		List<String> fetchedIdsForProgramType = RestExecutor.getFilteredIds(CollectionValuesVal.OFFER, iBucket, "pgrmType", programType);
		
		if(currentSize+ fetchedIdsForProgramType.size() > count ){
			//trim fetched data and add to corresponding list
			int toSizeTo = count - currentSize;
			fetchedIdsForProgramType = fetchedIdsForProgramType.subList(0, toSizeTo);
			mp.get(programType).addAll(fetchedIdsForProgramType);
			return -1;

		}
		
		mp.get(programType).addAll(fetchedIdsForProgramType);
		return fetchedIdsForProgramType.size();
	}
	
	/**
	 * Depending upon programType, replaces item id and dartnumber with data
	 * @param msgFormat
	 * @param itemId
	 * @param programType
	 * @return
	 */
	private String formatMessageForMPItems(String msgFormat, String itemId, String programType, String sellerId){
		
		String msg = null;
		if(programType.equals("FBS")){
			msg = msgFormat.replace("@P1@", "1233");
			msg = msg.replace("@P2@", itemId);
			
		}else{
			msg = msgFormat.replace("@P1@", itemId);
			msg = msg.replace("@P2@", "1245");
		}
		msg = msg.replace("@P4@", sellerId);
		msg = msg.replace("@ProgramType@", programType);
		
		return msg;
		
	}
	
}
