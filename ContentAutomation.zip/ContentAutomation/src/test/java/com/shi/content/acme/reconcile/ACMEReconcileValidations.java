package com.shi.content.acme.reconcile;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import com.generated.vos.itemauthority.reconciled.ReconciledResponse;
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class ACMEReconcileValidations implements Runnable{

	private String ssin = null;
	private String guid = null;
	List<JsonObject> sourceData = null;
	public static List<String> reconRules = null;
	public static List<ArrayList<String>> progTypeRules = null;
	ItemDetails contentWinner = null;
	String ssinRuleValue = "";
	ArrayList<String> appliedRules = null;
	boolean isPgmTypeApplied = false;
	boolean isMisclassApplied = false;
	boolean isContentScoreApplied = false;
	List<ItemDetails> noMisclassList = null;
	HashMap<String, ArrayList<String>> vendorItemMapping = null;

	public ACMEReconcileValidations(String ssinUnderTest)
	{
		this.ssin = ssinUnderTest;
	}

	public void run() 
	{
		CompareValuesUtility.init();
		System.out.println("Verifying SSIN: "+this.ssin);

		try {
			// Get all sources
			sourceData = getSourcesBySSIN(); 

			if (sourceData == null) {
				System.out.println("No Item Present Under SSIN: "+this.ssin);
				CompareValuesUtility.logPassed("Content Winner", "", "No item present under this SSIN");
			} else {
				// Get Item Details
				List<ItemDetails> itemDetails = getItemDetails();

				if (itemDetails == null || itemDetails.size() == 0) {
					System.out.println("No Active item present under SSIN: "+this.ssin);
					CompareValuesUtility.logPassed("Content Winner", "", "No Active item present under this SSIN");
				} else {
					if (itemDetails.size() == 1) {
						// Singleton
						this.contentWinner = itemDetails.get(0);
						this.ssinRuleValue = "Singleton";
					} else {
						// Check reconcile priority
						List<ItemDetails> inputList = itemDetails;
						List<ItemDetails> outputList = null;
						appliedRules = new ArrayList<>();

						for (String rule : reconRules) {
							switch (rule) {
							case "programType":
								outputList = applyProgramTypeRule(inputList);
								appliedRules.add("programType");
								break;
							case "misclass":
								outputList = applyMisclassRule(inputList);
								appliedRules.add("misclass");
								break;
							case "contentScore":
								outputList = applyContentScoreRule(inputList);
								appliedRules.add("contentScore");
							}

							if (outputList.size() == 1) {
								contentWinner = outputList.get(0);
								break;
							} else {
								inputList = outputList;
							}
						}

						if (contentWinner == null) {
							contentWinner = applyExistingSSINRule(outputList);
							if (contentWinner != null) 
								this.ssinRuleValue = "default";
						} else {
							// Prepare ssin rule value
							for (String rule : reconRules) {
								switch (rule) {
								case "programType":
									if (isPgmTypeApplied)
										this.ssinRuleValue += "+"+contentWinner.getPgmType().toUpperCase();
									break;

								case "misclass":
									if (isMisclassApplied) {
										if (noMisclassList.contains(contentWinner)) {
											this.ssinRuleValue += "~misclass";
										} else {
											this.ssinRuleValue += "+misclass";
										}
									}
									break;

								case "contentScore":
									if (isContentScoreApplied) 
										this.ssinRuleValue += "+contentScore";
								}
							}
						}
					}

					if (this.contentWinner != null) {
						// Verify reconciliation fields
						URI uri = null;
						try {
							uri = new URI("http://"+LoadProperties.IA_SERVER+"/acme/reconciled/"+this.guid);
						} catch (URISyntaxException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						ReconciledResponse reconcileDoc = RestExecutor.getDataById(uri, CollectionValuesVal.Reconciled_Response);
						String json = RestExecutor.getJSonResponse(uri);

						// Verify content winner item
						if (reconcileDoc != null) {
							String actualContentWinner = null;
							if (reconcileDoc.getItem().getAttributes().getSsinSourceId() != null) {
								actualContentWinner = reconcileDoc.getItem().getAttributes().getSsinSourceId().getValue();	
							}
							CompareValuesUtility.compareValues("Content Winner",contentWinner.getItemId(),actualContentWinner);
						} else {
							throw new Exception("No Reconcile Document present for SSIN: "+this.ssin);
						}

						System.out.println("SSIN: "+this.ssin+" Content Winner: "+contentWinner.getItemId());

						// Compare other fields in reconciled document
						CompareValuesUtility.compareValues("UID",this.guid,reconcileDoc.getItem().getId());
						CompareValuesUtility.compareValues("SSIN",this.ssin,reconcileDoc.getItem().getSsin());

						if (reconcileDoc.getItem().getAttributes().getSsinRule() != null) {
							CompareValuesUtility.compareValues("ssinRule.value",this.ssinRuleValue,reconcileDoc.getItem().getAttributes().getSsinRule().getValue());

							if (appliedRules != null) {
								List<String> actAppliedRules = reconcileDoc.getItem().getAttributes().getSsinRule().getAppliedRules();
								CompareValuesUtility.compareValues("ssinRule.appliedRules",this.appliedRules,actAppliedRules);
							}
						}

						if (reconcileDoc.getItem().getAttributes().getCCnt() != null) {
							CompareValuesUtility.compareValues("cCnt.value",itemDetails.size()+"", reconcileDoc.getItem().getAttributes().getCCnt().getValue());

							if (reconcileDoc.getItem().getAttributes().getCCnt().getContributors() != null) {

								String vendorQuery = "{item{attributes{cCnt{contributors{subString}}}}}";

								for (String vendor : vendorItemMapping.keySet()) {
									List<String> items = vendorItemMapping.get(vendor);
									String reqJson = JsonStringParser.getJsonValue(json, vendorQuery.replace("subString", vendor));
									boolean flag=true;

									if (reqJson != null && !reqJson.equals("")) {
										CompareValuesUtility.compareValues("Vendors",vendor,vendor);
										for (String item : items) {
											if (!reqJson.contains(item)) {
												CompareValuesUtility.compareValues("Items",items.toString(),reqJson.toString());
												flag = false;
												break;
											}
										}

										if (flag) {
											CompareValuesUtility.compareValues("Items",items.toString(),items.toString());
										}
									} else {
										CompareValuesUtility.compareValues("Vendors",vendor,"");
									}

								}
							} else {
								CompareValuesUtility.addFailedDataFieldForReport("Error", "cCnt.contributors tag not present");
							}
						} else {
							CompareValuesUtility.addFailedDataFieldForReport("Error", "cCnt tag not present");
						}

					} else {
						throw new Exception("Could not finalize content winner for SSIN: "+this.ssin);
					}
				}
			}
		} catch (Exception e) {
			CompareValuesUtility.addFailedDataFieldForReport("Error", e.getMessage());
		}

		CompareValuesUtility.setupResult(this.ssin, true);
		CompareValuesUtility.teardown();
	}

	public static void readConfig() {
		String reconPriorityDoc = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/config/node/reconcile.priority");
		reconRules = new ArrayList<>();
		reconRules.add(JsonStringParser.getJsonValue(reconPriorityDoc, "{item{attributes{1}}}"));
		reconRules.add(JsonStringParser.getJsonValue(reconPriorityDoc, "{item{attributes{2}}}"));
		reconRules.add(JsonStringParser.getJsonValue(reconPriorityDoc, "{item{attributes{3}}}"));

		progTypeRules = new ArrayList<>();

		String progTypePriorityDoc = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/config/node/reconcile.programType");
		String progPriority = JsonStringParser.getJsonValue(progTypePriorityDoc, "{item{attributes}}");

		HashMap<String, ArrayList<String>> progTypePrioMap = new HashMap<>();

		try {
			JSONObject jsonObject = new JSONObject(progPriority);
			Iterator iterator = jsonObject.keys();

			while(iterator.hasNext()) {
				String progType = iterator.next().toString();
				String priority = jsonObject.get(progType).toString();

				if (progTypePrioMap.containsKey(priority)) {
					progTypePrioMap.get(priority).add(progType);
				} else {
					ArrayList<String> list = new ArrayList<>();
					list.add(progType);
					progTypePrioMap.put(priority, list);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < progTypePrioMap.size(); i++) {
			progTypeRules.add(progTypePrioMap.get(""+(i+1)));
		}
	}

	public List<ItemDetails> applyProgramTypeRule(List<ItemDetails> itemDetails) {
		for(int i=0; i < progTypeRules.size(); i++) {
			List<String> progTypes = progTypeRules.get(i);
			ArrayList<ItemDetails> highPriorityItems = new ArrayList<>();

			isPgmTypeApplied = true;

			for(int j=0; j < progTypes.size(); j++) {
				for(int k=0; k < itemDetails.size(); k++) {
					if (itemDetails.get(k).getPgmType().equalsIgnoreCase(progTypes.get(j))) {
						highPriorityItems.add(itemDetails.get(k));
					}
				}
			}

			if (highPriorityItems.size() > 0) 
				return highPriorityItems;
		}
		return null;
	}

	public List<ItemDetails> applyMisclassRule(List<ItemDetails> itemDetails) {
		List<ItemDetails> misClassTrueList = new ArrayList<>();
		List<ItemDetails> misClassFalseList = new ArrayList<>();
		noMisclassList = new ArrayList<>();
		List<ItemDetails> finalList = new ArrayList<>();

		isMisclassApplied = true;

		for (int i = 0; i < itemDetails.size(); i++) {
			String misclassDoc = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/misclass/"+itemDetails.get(i).getItemId());
			String misclass = JsonStringParser.getJsonValue(misclassDoc,"{item{attributes{misclass}}}");

			if (misclass == null) {
				noMisclassList.add(itemDetails.get(i));
			} else if (misclass.equals("true")) {
				misClassTrueList.add(itemDetails.get(i));
			} else if (misclass.equals("false")) {
				misClassFalseList.add(itemDetails.get(i));
			}
		}

		finalList.addAll(misClassFalseList);
		finalList.addAll(noMisclassList);

		if (finalList.size() == 0 && misClassTrueList.size() > 0)
			return misClassTrueList;

		return finalList;
	} 

	public List<ItemDetails> applyContentScoreRule(List<ItemDetails> itemDetails) {
		List<ItemDetails> higestContentScoreItems = new ArrayList<>();

		double highestContentScore = 0;
		List<ItemDetails> finalList = new ArrayList<>();

		isContentScoreApplied = true;

		for (int i = 0; i < itemDetails.size(); i++) {
			Double contentScore = null;
			String aggScore = JsonStringParser.getJsonValue(RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/contentscore/"+itemDetails.get(i).getItemId()),"{item{attributes{aggregateScore}}}");
			if (aggScore != null && !aggScore.equals(""))
				contentScore = Double.parseDouble(aggScore);

			if (contentScore == null) {
				finalList.add(itemDetails.get(i));
			} else if(contentScore > highestContentScore ) {
				higestContentScoreItems.clear();
				higestContentScoreItems.add(itemDetails.get(i));
				highestContentScore = contentScore; 
			} else if(contentScore == highestContentScore ) {
				higestContentScoreItems.add(itemDetails.get(i));
			}
		}

		finalList.addAll(higestContentScoreItems);
		return finalList;
	}

	public ItemDetails applyExistingSSINRule(List<ItemDetails> itemDetails) {
		boolean sameSSIN = true;
		ItemDetails finalItem = null;

		if (itemDetails != null && itemDetails.size() > 0) {
			String expSsin = itemDetails.get(0).getSsin();

			for(int i=0; i<itemDetails.size(); i++) {
				if (!itemDetails.get(i).getSsin().equals(expSsin)) {
					sameSSIN = false;
					break;
				}
			}

			if (sameSSIN) {
				for (ItemDetails item : itemDetails) {
					String calcSsin = item.getCalcSsin();

					if (calcSsin != null && calcSsin.equals(expSsin)) {
						return item;
					}
				}
			}

			finalItem = applyOldestItemRule(itemDetails);
		}
		return finalItem;
	}

	public ItemDetails applyOldestItemRule(List<ItemDetails> itemDetails) {
		Long smallest = null;
		ItemDetails finalItem = null;
		if (itemDetails != null && itemDetails.size() > 0) {
			smallest = Long.parseLong(itemDetails.get(0).getLastUpdatedTime());
			finalItem = itemDetails.get(0);
			for (int i=1; i<itemDetails.size(); i++) {
				Long lastUpdated = Long.parseLong(itemDetails.get(i).getLastUpdatedTime());
				if (smallest > lastUpdated) {
					smallest = lastUpdated;
					finalItem = itemDetails.get(i);
				}
			}
		}
		return finalItem;
	}

	public List<ItemDetails> getItemDetails() {
		if (sourceData == null || sourceData.size() == 0) 
			return null;

		List<ItemDetails> itemDetailsList = new ArrayList<>();
		vendorItemMapping = new HashMap<>();

		for (JsonElement element : sourceData) {
			String status = JsonStringParser.getJsonValue(element.toString(), "{status}");
			if (status.equalsIgnoreCase("ACTIVE")) {
				String itemId = JsonStringParser.getJsonValue(element.toString(), "{id}");
				String pgmType = JsonStringParser.getJsonValue(element.toString(), "{attributes{programType}}");
				String isPreferredContent = JsonStringParser.getJsonValue(element.toString(), "{attributes{isPreferredContent}}");
				String overrideSSIN = JsonStringParser.getJsonValue(element.toString(), "{attributes{overrideSsin}}");
				String itemSsin = JsonStringParser.getJsonValue(element.toString(), "{ssin}");
				String calcSsin = JsonStringParser.getJsonValue(element.toString(), "{calcSsin}");
				String lastUpdatedTime = JsonStringParser.getJsonValue(element.toString(), "{lastUpdated}");
				String vendorId = JsonStringParser.getJsonValue(element.toString(), "{vendorId}");
				String ownerId = JsonStringParser.getJsonValue(element.toString(), "{attributes{ownerId}}");
				itemDetailsList.add(new ItemDetails(itemId, pgmType, isPreferredContent, overrideSSIN,itemSsin,calcSsin,lastUpdatedTime,vendorId,ownerId));

				if (vendorItemMapping.containsKey(vendorId)) {
					ArrayList<String> itemList = vendorItemMapping.get(vendorId);
					itemList.add(itemId);
					vendorItemMapping.put(vendorId, itemList);
				} else {
					ArrayList<String> itemList = new ArrayList<>();
					itemList.add(itemId);
					vendorItemMapping.put(vendorId, itemList);
				}
			}
		}
		return itemDetailsList;
	}

	/**
	 * Gets all sources by ssin in one go
	 * @param sourceData
	 */
	private List<JsonObject> getSourcesBySSIN() {
		List<JsonObject> sourceData = new ArrayList<>();
		JsonParser jParser = new JsonParser();
		JsonElement jsonElement = jParser.parse(RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/source?ssin="+ssin+"&page-size=500"));
		JsonArray array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();

		if (array.size() == 0) 
			return null;

		// Get guid
		this.guid = JsonStringParser.getJsonValue(array.get(0).toString(), "{guid}");

		// Sources by SSIN
		for (int i = 0; i < array.size(); i++) 
			sourceData.add(array.get(i).getAsJsonObject());
		return sourceData;
	}
}