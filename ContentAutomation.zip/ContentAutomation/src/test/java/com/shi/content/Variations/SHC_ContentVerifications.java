package com.shi.content.Variations;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.content.Assets;
import com.generated.vos.content.Content;
import com.generated.vos.productoffering.Hierarchy;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;

public class SHC_ContentVerifications implements Runnable {

	SingleProductOffer singleProductOffer ;
	VariationProductOffer varProdOffer ;
	SHCContentCommons commonUtils;
	String itemClassId;
	Boolean bSingleProductOffer = true;
	String partNumberToTest;
	String sSiteToTest;
	
	public SHC_ContentVerifications(SingleProductOffer wNodeListToTest, SHCContentCommons commonUtils, 
			String itemClassId, VariationProductOffer varProdOffer, String siteToTest){
		if(wNodeListToTest == null){
			bSingleProductOffer = false;
		}
		this.singleProductOffer = wNodeListToTest;
		this.commonUtils = commonUtils;
		this.itemClassId = itemClassId;
		this.varProdOffer = varProdOffer;
		this.sSiteToTest = siteToTest;
	}
	
	public void run() {

		ProductContent pContentToTest = this.getContentToTest();
		
		if(partNumberToTest.equals("nullP")){
			return;
		}
		APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,partNumberToTest);
				
		if(partNumberToTest!= null){
			/*if(!partNumberToTest.contains("00842911000"))
				return;*/
			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return;
				}
				
					Content gbContent = (Content)allResponse.getT();
					if(gbContent == null){
						CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
						CompareValuesUtility.setupResult(partNumberToTest, true);
						return;
					}
					verifyProduct(pContentToTest, gbContent,partNumberToTest ,sSiteToTest );
					
				CompareValuesUtility.setupResult(partNumberToTest, true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ partNumberToTest);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
			
	}

	/**
	 * Gets the data to be tested
	 * If NV item, sets the partnumber to be tested based on the site deduced from file name and returns content
	 * If V item, checks whether site offers are present.  If present sets partnumber else sets partnumber to null
	 * eg. if sears site is being tested and if no sears part number is present in product offerings, return null
	 * @return
	 */
	private ProductContent getContentToTest() {
		boolean bFoundSiteOffers = false;
		if(bSingleProductOffer){
				
			if(sSiteToTest.equals("sears")){
				partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber()+"P";
			}else{
				partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber()+"P";
			}
				
			return singleProductOffer.getProductContent();
		
		}else{
			if(sSiteToTest.equals("sears")){
				for( ProductOffer prodOff : varProdOffer.getProductOfferings().getProductOffer()){
					if(prodOff.getPartNumber().getSearsPartNumber()!=null){
						bFoundSiteOffers = true;
						break;
					}
				}
				if(bFoundSiteOffers)
					partNumberToTest = varProdOffer.getVariationSearsPartNumber()+"P";
				else
					partNumberToTest = "nullP";
			}else{
				for( ProductOffer prodOff : varProdOffer.getProductOfferings().getProductOffer()){
					if(prodOff.getPartNumber().getKmartPartNumber()!=null){
						bFoundSiteOffers = true;
						break;
					}
				}
				if(bFoundSiteOffers)
					partNumberToTest = varProdOffer.getVariationKmartPartNumber()+"P";
				else
					partNumberToTest = "nullP";
			}
			
				return varProdOffer.getProductContent();
			}
	}

	String sCatentryId;
	
	

	private void verifyProduct(ProductContent pContent, Content content, String id, String site) {
//		ProductOfferings pOffers = singleOffer.getProductOfferings();
		compareValues("Id", id,content.getId());
		
		sCatentryId = SHCContentCommons.fetchCatentryId(id);
		
		//Validate sites
		commonUtils.verifySites(pContent, content.getSites(),false);
		compareValues("Name", TestUtils.plainEncodeHTML(OfferCommons.escapeNewline(pContent.getName())), content.getName());
		if(pContent.getSuppressLongDescriptionFlag() == null || pContent.getSuppressLongDescriptionFlag().equals(false))
			CompareValuesUtility.verifyNull("SuppresLongDesc", content.getIsLongDescSuppress());
		else
			compareValues("SuppresLongDesc",pContent.getSuppressLongDescriptionFlag(), content.getIsLongDescSuppress());
		
		//Validate classifications
		compareValues("Classifications", "P", content.getClassifications().getCatentryType(),"Catentrytype");
		compareValues("Classifications", bSingleProductOffer?"NV":"V", content.getClassifications().getCatentrySubType(),"CatentrySubtype");
		compareValues("Classifications", commonUtils.getEnrichmentProvider(pContent.getEnrichmentInfo() == null?"S":
			pContent.getEnrichmentInfo().getEnrichmentProvider().value(),true), content.getClassifications().getEnrichmentProvider(),"EnrichProv");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrFalse("IsAuto", false, content.getClassifications().getIsAutomotive());
		CompareValuesUtility.verifyNull("IsFitmentReq",content.getAutomotive());

		//Verify Brand
		commonUtils.verifyBrand(pContent.getBrand(), content.getBrand());
		
		
		//Verify mfr
		///*Comparing only first 64 chars of string as only first 64 gets stored in Greenbox DB */
		String xmlMfrName = pContent.getManufacturerName();
		if (xmlMfrName != null) {
			int xmlMfrNameLen = pContent.getManufacturerName().length();
			xmlMfrName = xmlMfrName.substring(0,xmlMfrNameLen>64?64:xmlMfrNameLen);
		}
		CompareValuesUtility.verifyNullOrEqual("Mfr",xmlMfrName,content.getMfr()!= null? content.getMfr().getName() : null,"MfrName");
		
		
		CompareValuesUtility.verifyNullOrEqual("Mfr",pContent.getManufacturerModelNumber(), content.getMfr()!= null? content.getMfr().getModelNo(): null,"MfrModel");
		CompareValuesUtility.addNewMultiValuedFields();

		//Verify seo
		commonUtils.verifySeo(pContent.getSeo(), content);
		
		//Verify Desc
		commonUtils.verifyDesc(pContent.getFeatureDescription(), pContent.getMarketingDescription(),content.getDesc(),true);
		
		if(pContent.getFeatureTopDescriptions() != null){
			commonUtils.verifyTopDescriptions(pContent.getFeatureTopDescriptions().getFeatureTopDescription(), content.getDesc());
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		//Verify assets
		verifyAssets(pContent, content.getAssets());
		
		String sQuery = commonUtils.getFacetsQuery(sCatentryId);
		
		commonUtils.verifyFacets(sQuery, content);
		
		CompareValuesUtility.addNewMultiValuedFields();
		if(pContent.getProductAttributes()!= null){
			commonUtils.verifySpecs(pContent.getProductAttributes().getProductAttribute(), content.getSpecs(), itemClassId);
		}
		verifyTaxonomy(pContent, content);
		
		if(pContent.getCuratedContents() != null){
			CompareValuesUtility.addNewMultiValuedFields();
			commonUtils.verifyCuratedContents(pContent.getCuratedContents().getCuratedGroup(), content.getCuratedContents());
		}
	}
	

	private void verifyTaxonomy(ProductContent pContent, Content content) {
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for ( Site site : pContent.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId > 11 || lSiteId == 10)
				continue;
			String siteName = TestUtils.getSite(lSiteId);
			
			if((sSiteToTest.equalsIgnoreCase("sears") && siteName.equalsIgnoreCase("kmart"))
					|| (sSiteToTest.equalsIgnoreCase("kmart") && siteName.equalsIgnoreCase("sears"))){
				continue;
			}
			
			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}
			
			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		
		
		commonUtils.compareWebhierarchy(mpSiteHiearachies, content.getTaxonomy().getWeb());
		commonUtils.compareMasterhierarchy(Long.parseLong(itemClassId), content.getTaxonomy().getMaster().getHierarchy());
	}

	private void verifyAssets(ProductContent pContentAsset, Assets contentAssets){
		
		commonUtils.verifyAssets(pContentAsset.getPrimaryImage(), pContentAsset.getFeatureImages(), contentAssets);
		
		if(pContentAsset.getProductAssets() != null){
			commonUtils.verifyAssetAttachments(pContentAsset.getProductAssets().getProductAsset(), contentAssets.getAttachments());
			
			commonUtils.verifyAssetVideo(pContentAsset.getProductAssets().getProductAsset(), contentAssets.getVideos());
		}
		if(pContentAsset.getContentExtensions()!= null)
			commonUtils.verifyContentExtension(pContentAsset.getContentExtensions().getProvider(0), contentAssets.getContentExtensions().get(0));
		
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	
}
