package com.shi.content.matching.acme;
public class AttributeDataVO{
		public AttributeDataVO(String attrName, String attrValues) {
			this.displayName = attrName;
			this.valueIds = attrValues;
		}
		public String displayName;
		public String valueIds;
		
	}