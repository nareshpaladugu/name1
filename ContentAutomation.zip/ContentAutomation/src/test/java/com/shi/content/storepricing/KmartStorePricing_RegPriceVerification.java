package com.shi.content.storepricing;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.Test;

import com.generated.vos.offer.OfferSchema;
import com.generated.vos.pricing.kmstore.KmartStorePricing;
import com.google.common.base.Splitter;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;

public class KmartStorePricing_RegPriceVerification implements Runnable {

	public String processLine;
	public static String storeID;
	public static String kmartStoreNumber;
	public static String finalID;
	public static String typeOfPrice;
	public static String IPPrice1;
	public static Double IPPrice;
	public static Double modPrice;
	public static String modPrice1;
	public static HashMap<String, HashMap<String, Object>> KmartStoreProductPrice;
	public KmartStorePricing_RegPriceVerification(String lineToProcess) {

		this.processLine = lineToProcess;

	}

	@Override
	public void run() {
		try {
			String[] AfterLineSplit=processLine.split("\\|");
			storeID=AfterLineSplit[0]+"-";
			kmartStoreNumber =AfterLineSplit[1].replaceAll("\\s+","");
			typeOfPrice = AfterLineSplit[2].replaceAll("\\s+","");
			IPPrice1 = AfterLineSplit[3].replaceAll("\\s+","");
			IPPrice = Double.parseDouble(IPPrice1);
			modPrice1 = AfterLineSplit[4].replaceAll("\\s+","");
			modPrice = Double.parseDouble(modPrice1);
			verifyPrices();
		} 
		catch(Exception e){
			System.out.println("Inside catch block: "+e.getMessage());
		}
	}
	public static void verifyPrices() throws Exception{


		if (kmartStoreNumber.startsWith("0")) {
			String kmartStoreNumber1 = kmartStoreNumber.substring(1,kmartStoreNumber.length());
			finalID = storeID.concat(kmartStoreNumber1);
			System.out.println(finalID);

		} else {
			finalID = storeID.concat(kmartStoreNumber);

		}		

		KmartStorePricing kmartStorePricing = RestExecutor.getAllDataById(CollectionValuesVal.KM_STOREPRICING, finalID).getT();	
		com.generated.vos.pricing.kmstore.P pObj = kmartStorePricing.getP();
		//Check what kind of price exists 
		CompareValuesUtility.init();	
		if (pObj.getR() != null) {
			String strings = "";
			System.out.println(pObj.getR().get(0).getIp());
			CompareValuesUtility.compareValues("Ip price for Regular Price", IPPrice, pObj.getR().get(0).getIp(), strings);
			CompareValuesUtility.compareValues("Mod price for Regular Price", modPrice, pObj.getR().get(0).getMod(), strings);


			System.out.println(pObj.getS());
			if((typeOfPrice.equals("X") && pObj.getX()!= null) 
					|| (typeOfPrice.equals("P") && pObj.getS()!= null)){

				//Verify ip amd mod for X
				if(pObj.getX().get(0).getIp()==null || pObj.getX().get(0).getMod()==null) throw new Exception("X is not available");

				CompareValuesUtility.compareValues("Ip price for Clearance Price", IPPrice, pObj.getX().get(0).getIp(), strings);	
				CompareValuesUtility.compareValues("Mod price for Clearance Price", modPrice, pObj.getX().get(0).getMod(), strings);
			}
			//Verify ip amd mod for P	
			else if(pObj.getS().get(0).getIp()==null && pObj.getS().get(0).getMod()==null)throw new Exception("P is not available");
			CompareValuesUtility.compareValues("Ip price for Promotional Price", IPPrice, pObj.getS().get(0).getIp(), strings);
			CompareValuesUtility.compareValues("Mod price for Promotional Price", modPrice, pObj.getS().get(0).getMod(), strings);


		}

		//Check for regular price as it will always be there		
		CompareValuesUtility.setupResult(finalID, true);



	}
}


