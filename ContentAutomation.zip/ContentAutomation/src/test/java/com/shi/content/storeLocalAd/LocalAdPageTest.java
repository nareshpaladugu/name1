package com.shi.content.storeLocalAd;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.storelocalad.Media;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class LocalAdPageTest {



	static List<String> erroredPartNumbers = new ArrayList<String>();

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="LocalAdPage")
	public void testLocalAdPage(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Media>> localAdQueue = new LinkedBlockingQueue<List<Media>>(); 
		//Create producer thread
		ChunkProducerThread<Media> prodThread = new ChunkProducerThread<Media>(sFileName, localAdQueue, Media.class);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		//Create consumer threads
		//Each thread does validation for attribute and attribute val
		
		final ExecutorService pool = Executors.newFixedThreadPool(8);
		while(true){
			try {
				List<Media> nodeToTest = localAdQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
//					System.out.println("Calling with node : "+ nodeToTest.get(0).getId());
					pool.execute(new LocalAdPageVerification(nodeToTest));
				}else
					System.out.println("got null");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		pool.shutdown();
		try {
			pool.awaitTermination(20, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}




}
