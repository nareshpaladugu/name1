package com.shi.content.northstar.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.CheckBox;
import com.shc.content.webdriver.html.DialogBox;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.TextField;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.common.CommonMethods;

/**
 * @author inaikwa
 *
 */
public class EditStoreDetails extends BasePage {

	Link linkDepartmentView = new Link("//a[contains(text(),'Unit Attributes and Department View')]","Department View");
	Link linkUnitRegularHoursView = new Link("//a[contains(text(),'Regular Hours View')]","Unit Regular Hours View");
	Link linkPharmacyView = new Link("//a[contains(text(),'Unit Pharmacy View')]","Pharmacy View");
	Table tblView = new Table("//div[@class='ui-accordion-content ui-helper-reset ui-widget-content ui-helper-hidden'][@aria-hidden='false']", "Department View");
//	Table tblCloseStoreOptionsSingleView = new Table("frm-single-view:closeStoreOptionsingle", "Close Store dlg Options Single View");
	Table tblCloseStoreOptionsSingleView = new Table("//table[@id='frm-single-view:closeStoreOptionsingle']/tbody/tr", "Close Store dlg Options Single View");

//	Table tblCloseStoreOptionsMultiView = new Table("frm-result:closeStoreOptionmulti", "Close Store dlg Options Multi View");
	Table tblCloseStoreOptionsMultiView = new Table("//table[@id='frm-result:closeStoreOptionmulti']/tbody/tr", "Close Store dlg Options Multi View");

	Table tableStores = new Table("//tbody[@id='frm-result:tbl-result_data']/tr", "StoreDisplayTable");
	//Buttons	
	Button btnSave = new Button ("//span[@class='ui-button-text ui-c'][contains(text(),'Save')]","Save Button");
	Button btnDone = new Button ("frm-single-view:j_idt371","Done Button" );
	Button btnCloseStore = new Button("frm-single-view:j_idt353","Close Store Button");
	Button btnCloseStoreSave = new Button("frm-single-view:j_idt360","Close store Save button");
	Button btnCloseStoreSaveMultiView = new Button("frm-result:j_idt158","Close store Save button");
	Button btnCloseUpdateSuccess =new Button("//div[@class='ui-growl-icon-close ui-icon ui-icon-closethick']","Close btn of Update Success msg");
	Button btnTempCloseLessThan14 =new Button("//*[contains(text(),'Close store temporarily for 14 or less days')]","Close store temporarily for 14 days or less");
	Button btnOpenStore = new Button("//button[@id='frm-single-view:j_idt354']","Open Store Button");

	//Dialogs
	DialogBox dlgHierarchyList = new DialogBox("frm-single-view:dlg-hierarchy-sel", "Hierarchy Dialog");
	DialogBox dlgCloseStore = new DialogBox("frm-single-view:dlg-clearsingleview", "Close store dialog");
	DialogBox dlgUpdateSuccess = new DialogBox("//span[@class='ui-growl-title']", "Update Success dialog");
	DialogBox dlgCloseStoreSuccess = new DialogBox("//*[contains(text(),'Close Store Success')]", "Close Store Success dialog");
	DialogBox dlgOpenStoreSuccess = new DialogBox("//*[contains(text(),'Open Store Success')]", "Open Store Success dialog");

	Link linkServiceDepts = new Link("//li[@class='ui-picklist-item ui-corner-all'][contains(text(),'{0}')]", "Service Department :");
	Link linkServicesInStore = new Link("//div[contains(text(),'Service Depts In Store')]/..//li[contains(text(),'{0}')]","Services in Store:");
	Link linkMeetExpertNotInStore = new Link("//li[contains(text(),'MEET WITH AN EXPERT')]","MeetExpert");
	Link btnInsert = new Link("//*[@id='frm-single-view:pnl-single-view:servicePickList']/tbody/tr/td[2]/button[1]","Insert");
	Link btnRemove = new Link("//*[@id='frm-single-view:pnl-single-view:servicePickList']/tbody/tr/td[2]/button[3]","Remove");
	Link lnkSingleView = new Link("frm-single-view","Single View");
	//	Link lnkMultiView = new Link("frm-single-view","Multi View");
//PR
	Link btnRemovePR = new Link("//*[@id='frm-single-view:pnl-single-view:servicePickList']/tbody/tr/td[2]/button[3]","Remove");
	

	CheckBox checkBoxVerticals = new CheckBox("//*[@id='frm-single-view:hierarchySelectionMulti']//label[text()='{0}']","Vertical");

	TextField txtOpenCloseHours= new TextField("//span[@class='pe-timepicker ui-widget ui-corner-all']/input","OpenCloseHours");
	TextField txtOpenHours_Single= new TextField("//input[@id='frm-single-view:pnl-single-view:sunopnhr_input']","OpenCloseHours");
	TextField txtOpenHours_Multi= new TextField("//input[@id='frm-multi-view:pnl-multi-view:multisunopnhr_input']","OpenCloseHours");
	TextField txtOpenHours_Pharma= new TextField("//input[@id='frm-single-view:pnl-single-view:sunphrmopnhr_input']","OpenCloseHours");
	TextField txtTime= new TextField( "//td[@class='ui-timepicker-hour-cell']/a[contains(text(),'{0}')]","OpenCloseHours");
	Link lnkTimePickerHourCell= new Link("//td[@class='ui-timepicker-hour-cell']/a[contains(text(),'{0}')]","Select New Holiday Open Time");

	DriverLogger logger = new DriverLogger();

	public EditStoreDetails() {
		super("Editable View Page");
	}
	
	/**
	 * Clicks on Pharmacy view applicable for kmart stores only
	 */

	public void goToPharmacyView(){

		logger.log("Go to Pharmacy view ", false);

		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkPharmacyView);
			linkPharmacyView.click();
		}

		WaitUtils.waitUntilElementIsVisible(linkPharmacyView);
		linkPharmacyView.click();

	}
	
	/**
	 * Clicks on Departments view
	 */

	public void goToDepartmentsView(){

		logger.log("Go to Departments view ", false);

		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkDepartmentView);
			linkDepartmentView.click();
		}

		WaitUtils.waitUntilElementIsVisible(linkDepartmentView);
		linkDepartmentView.click();

	}

	/**
	 * Clicks on Unit Regular Hours view
	 */
	public void goToRegHoursView(){

		logger.log("Go to Regular Hours view ", false);

		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkUnitRegularHoursView);
			linkUnitRegularHoursView.click();
		}

		WaitUtils.waitUntilElementIsVisible(linkUnitRegularHoursView);
		linkUnitRegularHoursView.click();

	}

	/**
	 * Update success dialog after adding new holiday or updating regular hours
	 */

	public boolean updateSuccessMsg(){

		WaitUtils.waitUntilElementIsVisible(dlgUpdateSuccess);

		if(dlgUpdateSuccess.isVisible()){

			logger.log("Update success dialog displayed successfully ", false);
			return true;

		}else{
			logger.log("Update success dialog display : Failed ", false);
			return false;

		}
	}

	/**
	 * Close Store success dialog after closing store
	 */
	public boolean closeStoreSuccessMsg() {

		WaitUtils.waitUntilElementIsVisible(dlgCloseStoreSuccess);

		if (dlgCloseStoreSuccess.isVisible()) {

			logger.log("Close Store success dialog displayed successfully ", false);
			return true;

		} else {

			logger.log("Close Store success dialog display : Failed ", false);
			return false;

		}
	}

	/**
	 * Open Store success dialog after opening store
	 */

	public boolean openStoreSuccessMsg() {

		WaitUtils.waitUntilElementIsVisible(dlgOpenStoreSuccess);

		if (dlgOpenStoreSuccess.isVisible()) {

			logger.log("Open Store success dialog displayed successfully ", false);
			return true;

		} else {
			logger.log("Open Store success dialog display : Failed ", false);
			return false;

		}
	}

	/**
	 * Update Sunday Open Time for unit regular or holiday for only one day  
	 * @param lstOfOptions
	 */

	public String updateHours_Single(){

		logger.log("Updating Sunday Open Time ", false);

		List<WebElement> storeHours= new ArrayList<WebElement>();

//		storeHours=txtOpenCloseHours.findElements();
//
//		if(storeHours.get(0).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
//			logger.log("Time field is greyed out", false);
//
//		}

//		storeHours.get(0).click();

		txtOpenHours_Single.click();
		String time= "0"+CommonMethods.getRandomNumber();

		Link lnkTimePicker = (Link)lnkTimePickerHourCell.formatOption(time);

		lnkTimePicker.click();
		logger.log("Store Hours Updated", false);
		return time;
	}
	
	public String updateHours_Multi(){

		logger.log("Updating Sunday Open Time ", false);

		List<WebElement> storeHours= new ArrayList<WebElement>();

//		storeHours=txtOpenCloseHours.findElements();
//
//		if(storeHours.get(0).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
//			logger.log("Time field is greyed out", false);
//
//		}

//		storeHours.get(0).click();

		txtOpenHours_Multi.click();
		String time= "0"+CommonMethods.getRandomNumber();

		Link lnkTimePicker = (Link)lnkTimePickerHourCell.formatOption(time);

		lnkTimePicker.click();
		logger.log("Store Hours Updated", false);
		return time;
	}
	
	public String updateHours_Pharma(){

		logger.log("Updating Sunday Open Time for Pharmacy", false);

		txtOpenHours_Pharma.click();
		String time= "0"+CommonMethods.getRandomNumber();

		Link lnkTimePicker = (Link)lnkTimePickerHourCell.formatOption(time);

		lnkTimePicker.click();
		logger.log("Store Hours Updated", false);
		return time;
	}
	

	/**
	 * List of services to add to store
	 * @param lstOfOptions
	 */
	public void addServicesToStore(List<SERVICES> lstOfOptions){
		logger.log("Add services to store "+ lstOfOptions, false);
		for(SERVICES option : lstOfOptions){

			Link currentService = (Link) linkServiceDepts.formatOption(option.getOption());
			if(currentService.isElementPresent()){
				currentService.click();
				btnInsert.click();
			}
		}
	}

	/**
	 * Adds meet with expert option
	 */

	public void addMeetWithExpert(List<VERTICALS> verticals){

		this.goToDepartmentsView();

		this.removeMeetWithExpertOption();

		List<SERVICES> servicesList = new ArrayList<>();

		servicesList.add(SERVICES.MEETWITHEXPERT);

		this.addServicesToStore(servicesList);

		this.addVerticals(verticals);

		logger.log("Meet with expert added", true);
	}

	/**
	 * Adds verticals to meet with expert option
	 * @param lstOfVerticals {@link VERTICALS}
	 */
	public void addVerticals(List<VERTICALS> lstOfVerticals) {
		logger.log("Selecting verticals", true);

		WaitUtils.waitUntilElementIsVisible(dlgHierarchyList);

		for(VERTICALS vertical : lstOfVerticals){
			((CheckBox)checkBoxVerticals.formatOption(vertical.getName())).click();
		}

		btnDone.click();

		WaitUtils.waitUntilElementIsInVisible(dlgHierarchyList);

	}


	/**
	 * Removes meet with expert option
	 * 
	 */

	public void removeMeetWithExpertOption(){

		Link meetWithExpert = (Link)linkServicesInStore.formatOption(SERVICES.MEETWITHEXPERT.getOption());
		if(meetWithExpert.isElementPresent()){
			logger.log("Removing meetwithexpert option", false);
			meetWithExpert.click();

			btnRemove.click();
			WaitUtils.waitUntilElementIsClickable(linkServiceDepts.formatOption(SERVICES.MEETWITHEXPERT.getOption()));
		}
	}


	public void saveDocument(){

		btnSave.click();

	}


	public boolean isOptionAdded(SERVICES service){
		Link meetWithExpert = (Link)linkServicesInStore.formatOption(service.getOption());
		if(meetWithExpert.isElementPresent()){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Clicks on close store in Single View
	 * @return
	 */
	public boolean closeStoreSingleView(){

		logger.log("Closing store", false);

		WaitUtils.waitUntilElementIsVisible(lnkSingleView);
		btnCloseStore.click();

		WaitUtils.waitUntilElementIsVisible(tblCloseStoreOptionsSingleView);
		btnTempCloseLessThan14.click();

		WaitUtils.waitUntilElementIsVisible(tblCloseStoreOptionsSingleView);
		btnCloseStoreSave.click();

		return true;
	}

	/**
	 * Clicks on close store in Multi View
	 * @return
	 */
	
	public boolean closeStoreMultiView(){

		logger.log("Closing in multi store view ", false);

		WaitUtils.waitUntilElementIsVisible(tblCloseStoreOptionsMultiView);
		btnTempCloseLessThan14.click();

		WaitUtils.waitUntilElementIsVisible(tblCloseStoreOptionsMultiView);
		WaitUtils.waitBySleep();
		btnCloseStoreSaveMultiView.click();

		return true;
	}

	/** Opens store in single view
	 * @return true
	 */
	public boolean openStoreSingleView(){

		logger.log("Opening store", false);

		btnOpenStore.click();
		
		return true;
	}

	/**
	 * Opens given stores in multi view 
	 * @author inaikwa
	 * @param list of stores to open
	 *
	 */
	
	public boolean openStoreMultiView(ArrayList<String> listStoreIds){
		int noOfStoresToOpen=0;
		logger.log("Now Opening stores.....", false);

		ArrayList<ArrayList<WebElement>> table =tableStores.getTableElements();
		
		if(table.size()==0){
			
			logger.log("Open Store for multi view failed as Search Page is empty....", true);
			return false;
		}
		
		for (int row_num = 0; row_num < table.size(); row_num++) {
			
			if (listStoreIds.contains(table.get(row_num).get(1).getText())) {

				if(noOfStoresToOpen==2){
					break;
				}
				
				logger.log("Opened store : "+table.get(row_num).get(1).getText() , false);
					
				table.get(row_num).get(8).click();
				WaitUtils.waitBySleep();
				tableStores.findElements();
				table =tableStores.getTableElements();
				noOfStoresToOpen++;
			}

		}

		return true;
	}


	public Link getLinkDepartmentView() {
		return linkDepartmentView;
	}


	public Link getLinkServiceDepts() {
		return linkServiceDepts;
	}


	public Link getLinkServicesInStore() {
		return linkServicesInStore;
	}


	public Link getLinkMeetExpertNotInStore() {
		return linkMeetExpertNotInStore;
	}


	public Link getBtnInsert() {
		return btnInsert;
	}


	public Link getBtnRemove() {
		return btnRemove;
	}


	public CheckBox getCheckBoxVerticals() {
		return checkBoxVerticals;
	}


	public Button getBtnDone() {
		return btnDone;
	}


	public Button getBtnSave() {
		return btnSave;
	}


	public Button getBtnCloseStore() {
		return btnCloseStore;
	}


	public Button getBtnCloseStoreSave() {
		return btnCloseStoreSave;
	}


	public Table getTblDeptView() {
		return tblView;
	}


	public DialogBox getDlgHierarchyList() {
		return dlgHierarchyList;
	}


	public DialogBox getDlgCloseStore() {
		return dlgCloseStore;
	}


	public Button getBtnTempCloseLessThan14() {
		return btnTempCloseLessThan14;
	}

	/**
	 * List of services available for addition in store
	 * To add as and when required
	 * @author Niharika Varshney
	 *
	 */
	public enum SERVICES{
		CITYLMTFLAG("CITY LMT FLAG"),
		MEETWITHEXPERT("MEET WITH AN EXPERT");

		String option;
		SERVICES(String option){
			this.option = option;
		}

		public String getOption(){
			return this.option;
		}
	}

	/**
	 * List of verticals available for meet with expert flag
	 * @author Niharika Varshney
	 *
	 */
	public enum VERTICALS{
		
		CLOTHING("Clothing"),
		APPLIANCES("Appliances");

		String verticalName;
		VERTICALS(String verticalName){
			this.verticalName = verticalName;
		}

		public String getName(){
			return this.verticalName;
		}
	}
}
