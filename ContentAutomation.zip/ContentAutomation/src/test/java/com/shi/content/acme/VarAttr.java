
package com.shi.content.acme;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;

@Generated("org.jsonschema2pojo")
public class VarAttr {

    /**
     * 
     */
    @Expose
    private String id;
    /**
     * 
     */
    @Expose
    private String trademarkText;
    /**
     * 
     */
    @Expose
    private Boolean valueFlag;
    /**
     * 
     */
    @Expose
    private String valueFree;
    /**
     * 
     */
    @Expose
    private String valueId;

    /**
     * 
     * @return
     *     The id
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 
     * @return
     *     The trademarkText
     */
    public String getTrademarkText() {
        return trademarkText;
    }

    /**
     * 
     * @param trademarkText
     *     The trademarkText
     */
    public void setTrademarkText(String trademarkText) {
        this.trademarkText = trademarkText;
    }

    /**
     * 
     * @return
     *     The valueFlag
     */
    public Boolean getValueFlag() {
        return valueFlag;
    }

    /**
     * 
     * @param valueFlag
     *     The valueFlag
     */
    public void setValueFlag(Boolean valueFlag) {
        this.valueFlag = valueFlag;
    }

    /**
     * 
     * @return
     *     The valueFree
     */
    public String getValueFree() {
        return valueFree;
    }

    /**
     * 
     * @param valueFree
     *     The valueFree
     */
    public void setValueFree(String valueFree) {
        this.valueFree = valueFree;
    }

    /**
     * 
     * @return
     *     The valueId
     */
    public String getValueId() {
        return valueId;
    }

    /**
     * 
     * @param valueId
     *     The valueId
     */
    public void setValueId(String valueId) {
        this.valueId = valueId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
