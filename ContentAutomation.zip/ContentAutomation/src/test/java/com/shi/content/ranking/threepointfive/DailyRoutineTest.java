package com.shi.content.ranking.threepointfive;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.generated.vos.proto.itemPromo.SYWPromo;
import com.generated.vos.rankingmongo2.offer.Rankingmongo2;
import com.generated.vos.rankingmongo2.offer.SywOffer;
import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.ranking.threepointfive.helper.RankingMongoDbUtil;

/**
 * @author ddaphal
 *
 */
public class DailyRoutineTest {

	public static Long DR_CURRENT_TIME;

	@Test(description="Daily routine Test", groups="DailyRoutineTest")
	public void dailyRoutineTest()
	{
		CompareValuesUtility.init();

		DRMetadata drMetadata =  DailyRoutineHelper.getMetaData();

		System.out.println("MetaData : "+drMetadata);

		int currentPromos=0;
		int expiredPromos=0;
		int futurePromos=0;
		int expiredItems=0;

		CompareValuesUtility.addDataFieldForReport("Start Bucket ", drMetadata.getStartBucket()+"");
		CompareValuesUtility.addDataFieldForReport("End Bucket ", drMetadata.getEndBucket()+"");
		CompareValuesUtility.addDataFieldForReport("TellurideApi ", drMetadata.getTellurideApi()+"");
		CompareValuesUtility.addDataFieldForReport("isForFuture? ", drMetadata.isForFuture()+"");
		if(drMetadata.isForFuture())
			CompareValuesUtility.addDataFieldForReport("DealStartDate? ", drMetadata.getDealsStartDate()+"");

		MongoCollection<Document> collection = RankingMongoDbUtil.getRankingMongoCollection();

		int bucketNumber=-1;

		BasicDBObject query = new BasicDBObject("_bucket",new BasicDBObject("$gte", drMetadata.getStartBucket()).
				append("$lte",drMetadata.getEndBucket()));

		System.out.println("criteria....... "+query.toString());

		FindIterable<Document> findResult = collection.find(query);

		int totalItems = 0;

		Gson gson = new Gson();

		boolean oneActivePromo;
		Long startDatePromo;
		Long endDatePromo;

		List<String> expiredItemsList = new ArrayList<>();

		for (Document document : findResult) 
		{
			try {
				Rankingmongo2 objMongo =gson.fromJson(document.toJson(),Rankingmongo2.class);

				System.out.println(document.toJson().toString());

				totalItems++;

				bucketNumber = objMongo.getBucket().intValue();

				List<SywOffer> sywOffers = objMongo.getSywOffers();

				oneActivePromo=false;

				for (SywOffer sywOffer : sywOffers) 
				{
					startDatePromo = Long.parseLong(sywOffer.getStartDt().get$numberLong());
					endDatePromo = Long.parseLong(sywOffer.getEndDt().get$numberLong());

					if(drMetadata.isForFuture())
					{
					}
					else
					{
						if(startDatePromo<=DR_CURRENT_TIME  && endDatePromo<= DR_CURRENT_TIME)
						{
							System.out.println("Expired Promo");
							expiredPromos++;
						}

						else if(startDatePromo<=DR_CURRENT_TIME  && endDatePromo>= DR_CURRENT_TIME)
						{
							currentPromos++;
							System.out.println("Current Promo");
							oneActivePromo=true;
						}
						else
						{
							System.out.println("Future promo : "+document.get("_id").toString());
							oneActivePromo=true;
							futurePromos++;
						}
						//daily
					}
				}

				if(!oneActivePromo)
				{

					Offer offer=RestExecutor.getDataById(CollectionValuesVal.OFFER, document.get("_id").toString());

					expiredItemsList.add(document.get("_id").toString()+"#"+offer.getClassifications().getOfferType());
					expiredItems++;
				}
			} catch (Exception e) {
				System.out.println("Check this document "+document.toString());
				e.printStackTrace();
			}
		}

		CompareValuesUtility.addDataFieldForReport("Total-Items", totalItems+"");

		CompareValuesUtility.addDataFieldForReport("Current-Promos ", currentPromos+"");
		CompareValuesUtility.addDataFieldForReport("Expired-Promos ", expiredPromos+"");
		CompareValuesUtility.addDataFieldForReport("Future-Promos ", futurePromos+"");

		CompareValuesUtility.compareAsNumbers("ExpiredItems","0",expiredItems);

		for (String string : expiredItemsList) {
			CompareValuesUtility.addDataFieldForReport("ExpiredItems-OfferId ", string.split("#")[0]);
			CompareValuesUtility.addDataFieldForReport("ExpiredItems-Classifier ", string.split("#")[1]);
		}

		System.out.println("totalItems... "+totalItems);
		System.out.println("currentPromos... "+currentPromos);
		System.out.println("expiredPromos... "+expiredPromos);
		System.out.println("futurePromos... "+futurePromos);
		System.out.println("expiredItems... "+expiredItems);

		CompareValuesUtility.setupResult("DailyRoutine",true);
	}


	private boolean isActivePromo(SYWPromo sywPromoInputMsg)
	{
		long startDate = sywPromoInputMsg.getStartDtm();
		long endDate = sywPromoInputMsg.getEndDtm();

		if(startDate<= RankingPromoRelVerificationTest.CURRENT_TIME && endDate>=RankingPromoRelVerificationTest.CURRENT_TIME)
		{
			return true;
		}

		System.out.println("this is expired promo "+sywPromoInputMsg.getPromoId());

		return false;
	}

	@BeforeTest(description="Daily routine before Test", groups="DailyRoutineTest")
	public void loadData()
	{
		DR_CURRENT_TIME = System.currentTimeMillis();
	}
}
