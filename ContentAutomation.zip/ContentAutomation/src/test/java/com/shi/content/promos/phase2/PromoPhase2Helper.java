package com.shi.content.promos.phase2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.generated.vos.promo.PromoDetails;
import com.generated.vos.promo.Promorel;
import com.generated.vos.promos.Promo;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class PromoPhase2Helper {

	public static Map<String, Promo> PromoMap = Collections.synchronizedMap(new HashMap<String, Promo>());

	/**
	 * This method hits promo collection
	 * @param promoId
	 * @return
	 */
	public static void hitPromos(List<String> promoIds)
	{
		/* ----------------------- Remove already hit promo ids ------------------------- */

		Iterator<String> it = promoIds.iterator();
		while (it.hasNext())
		{
			String promoId = it.next();
			if(PromoMap.containsKey(promoId))
				it.remove();
		}

		if(promoIds.isEmpty())
		{
			//No need to hit promo collection
			return;
		}

		List<APIResponse<Promo>> promos = RestExecutor.getAllDataById(CollectionValuesVal.PROMO, promoIds);

		for (APIResponse<Promo> apiResponse : promos) 
		{
			Promo promo = apiResponse.getT();

			PromoMap.put(promo.getPromoIds().getId(), promo);
		}
	}

	/**
	 * Return Promo object from PromoMap map
	 * @param id
	 * @return
	 */
	public static Promo getPromo(String id)
	{
		return PromoMap.get(id);
	}

	//TODO - try reflection
	/**
	 * This method returns all promos associated with offer
	 * @param promorel
	 * @return map of promodetails with key as domain name like sears, kmart
	 */
	public static Map<String,List<PromoDetails>> getPromosFromPromoRel(Promorel promorel)
	{
		Map<String,List<PromoDetails>> promosMap = new HashMap<String, List<PromoDetails>>();

		if(promorel.getDomain().getSears()!=null)
		{
			List<PromoDetails> promos = new ArrayList<PromoDetails>();

			promos.addAll(promorel.getDomain().getSears().getRegular());

			promos.addAll(promorel.getDomain().getSears().getSywRdmpt());

			promos.addAll(promorel.getDomain().getSears().getBillFreeDelivery());

			promos.addAll(promorel.getDomain().getSears().getCraftClb());

			promos.addAll(promorel.getDomain().getSears().getInstSavings());

			promos.addAll(promorel.getDomain().getSears().getMisc());

			promos.addAll(promorel.getDomain().getSears().getSywMax());

			promos.addAll(promorel.getDomain().getSears().getSywMbr());

			promosMap.put("Sears", promos);
		}

		if(promorel.getDomain().getKmart()!=null)
		{
			List<PromoDetails> promos = new ArrayList<PromoDetails>();

			promos.addAll(promorel.getDomain().getKmart().getRegular());

			promos.addAll(promorel.getDomain().getKmart().getSywRdmpt());

			promos.addAll(promorel.getDomain().getKmart().getBillFreeDelivery());

			promos.addAll(promorel.getDomain().getKmart().getCraftClb());

			promos.addAll(promorel.getDomain().getKmart().getInstSavings());

			promos.addAll(promorel.getDomain().getKmart().getMisc());

			promos.addAll(promorel.getDomain().getKmart().getSywMax());

			promos.addAll(promorel.getDomain().getKmart().getSywMbr());

			promosMap.put("Kmart", promos);
		}

		if(promorel.getDomain().getMygofer()!=null)
		{
			List<PromoDetails> promos = new ArrayList<PromoDetails>();

			promos.addAll(promorel.getDomain().getMygofer().getRegular());

			promos.addAll(promorel.getDomain().getMygofer().getSywRdmpt());

			promos.addAll(promorel.getDomain().getMygofer().getBillFreeDelivery());

			promos.addAll(promorel.getDomain().getMygofer().getCraftClb());

			promos.addAll(promorel.getDomain().getMygofer().getInstSavings());

			promos.addAll(promorel.getDomain().getMygofer().getMisc());

			promos.addAll(promorel.getDomain().getMygofer().getSywMax());

			promos.addAll(promorel.getDomain().getMygofer().getSywMbr());

			promosMap.put("Mygofer", promos);
		}

		if(promorel.getDomain().getSrsPuertoRico()!=null)
		{
			List<PromoDetails> promos = new ArrayList<PromoDetails>();

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getRegular());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getSywRdmpt());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getBillFreeDelivery());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getCraftClb());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getInstSavings());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getMisc());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getSywMax());

			promos.addAll(promorel.getDomain().getSrsPuertoRico().getSywMbr());

			promosMap.put("PuertoRic", promos);
		}

		return promosMap;
	}

	/*public static void removeInactivePromos(List<PromoDetails> promos)
	{
		Iterator<PromoDetails> it = promos.iterator();
		while (it.hasNext())
		{
			PromoDetails promoDetails = it.next();
			//Remove inactive promos

			if(!promoDetails.getStatus().equalsIgnoreCase("a"))
				it.remove();
		}

	}
	 */
	/**
	 * Returns true if empty json
	 * @param sJsonResponse
	 * @return
	 */
	public static boolean isEmptyJsonResponse(String sJsonResponse)
	{
		if(sJsonResponse==null || sJsonResponse.isEmpty() || sJsonResponse.equals("[]") || sJsonResponse.equals("null"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
