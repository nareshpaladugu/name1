package com.shi.content.wcsmigration.mp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.catdelta.Upsert;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.Variations.OfferCommons;

public class MPCatalog_OfferTestsNew 
{
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="MPCatalogOfferTestsNew")
	public void testFbm(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread

		List<List<String>> sellerData = new ArrayList<List<String>>();
		
		System.out.println("Testing sFileName "+ sFileName);
		String sSeller = sFileName.split("\\.")[0].split("-")[2];
		if(sSeller.equalsIgnoreCase("DSS")) {
			sSeller = sFileName.split("\\.")[0].split("-")[3];
		}
		System.out.println("Seller is "+sSeller);
		
		BlockingQueue<List<Upsert>> fbmNodeQueue = new LinkedBlockingQueue<List<Upsert>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Upsert> prodThread = new ChunkProducerThread<Upsert>(sFileName, fbmNodeQueue, Upsert.class);//, poison);
		
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		List<String> sellerDatafbm = OfferCommons.getSellerData(sSeller,"FBM");
		List<String> sellerDatafbs = OfferCommons.getSellerData(sSeller,"FBS");
		List<String> sellerDatadss = OfferCommons.getSellerData(sSeller,"DSS");
		List<String> sellerDatacpc = OfferCommons.getSellerData(sSeller,"CPC");
		
		sellerData.add(sellerDatafbm);
		sellerData.add(sellerDatafbs);
		sellerData.add(sellerDatadss);
		sellerData.add(sellerDatacpc);

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Upsert> nodeToTest = fbmNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new MPCatalog_OfferVerificationsNew(nodeToTest.get(0),sSeller, sellerData));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}