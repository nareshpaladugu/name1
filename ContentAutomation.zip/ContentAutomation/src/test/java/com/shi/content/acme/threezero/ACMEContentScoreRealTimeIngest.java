package com.shi.content.acme.threezero;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.contentscoreMsg.ContentscoreMsg;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class ACMEContentScoreRealTimeIngest {

	@Test(description="Tests to read from contentscore queue and validate ACME contentscore collection", groups="ACMEContentScoreRealTimeIngest")
	public void aCMEContentScoreRealTimeIngest() throws Exception {

		System.out.println("ACMEContentScoreRealTimeIngest.............. started..");

		BlockingQueue<List<ContentscoreMsg>> mpContOffrDocs = new LinkedBlockingQueue<List<ContentscoreMsg>>();

		KafkaIAConsumer<ContentscoreMsg> prodThread = new KafkaIAConsumer<ContentscoreMsg>("ACMEContentScoreRealTimeIngestQA",
				ContentscoreMsg.class, mpContOffrDocs);		

		Thread t = new Thread(prodThread);
		t.start();

		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<ContentscoreMsg> nodeToTest;

				nodeToTest = mpContOffrDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					pool.execute(new ACMEContentScoreRealTimeIngestVerification(nodeToTest.get(0)));

				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}

}
