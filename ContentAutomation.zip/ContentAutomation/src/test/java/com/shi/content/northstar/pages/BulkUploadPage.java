package com.shi.content.northstar.pages;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shc.autocontent.LoadProperties;
import com.shc.content.webdriver.DriverInitializer;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.AbstractBaseElement;
import com.shc.content.webdriver.html.BasePage;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.CheckBox;
import com.shc.content.webdriver.html.Label;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.TextField;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.common.CommonMethods;

/**
 * Page object class to perform all UI actions Bulk Upload Page
 * @author vshar10
 */
public class BulkUploadPage extends BasePage {

	//Locators
	Button holidayHours = new Button("//input[@value='holiday hours']", "Holiday Hours Radio Button");
	Button newStoreHours = new Button("//input[@value='new store hours']", "New Store Hours Radio Button");
	Button updateStoreHours = new Button("//input[@value='update store hours']", "Update Store Hours Radio Button");
	Button reg2HldyHours = new Button("//input[@value='reg to hldy hours']", "New Store Hours Radio Button");
	Button chooseButton = new Button("//span[text()='Choose']", "Choose Button");
	Button uploadButton = new Button("//span[text()='Upload' and contains(@class,'ui-button-text ui-c')]", "Upload Button");
	Button cancelButton = new Button("//span[text()='Cancel' and contains(@class,'ui-button-text ui-c')]", "Cancel Button");
	Button publishDataButton = new Button("//span[text()='Publish Data' and contains(@class,'ui-button-text ui-c')]", "Publish Button");
	public Label messageLabel = new Label("//span[@class='ui-growl-title']", "Bulk Upload Status Message");

	public enum BulkUploadType {HOLIDAY_HOURS, NEW_STORE_HOURS, UPDATE_STORE_HOURS, REG_2_HLDY_HOURS};

	DriverLogger logger = new DriverLogger();

	public BulkUploadPage() {
		super("Bulk Upload Page");
	}

	/**
	 * Method to click required bulk upload option
	 * @param uploadType
	 */
	public void selectBulkUploadType(BulkUploadType uploadType) {
		switch (uploadType) {
		case HOLIDAY_HOURS:
			holidayHours.click();
			break;
		case NEW_STORE_HOURS:
			newStoreHours.click();
			break;
		case UPDATE_STORE_HOURS:
			updateStoreHours.click();
			break;
		case REG_2_HLDY_HOURS:
			reg2HldyHours.click();
			break;
		}
	}
	
	/**
	 * Method to upload file on upload pop up
	 * @param filePath
	 */
	public void uploadFile(String filePath) {
		chooseButton.click();
		
		Process p = null;
		try {
			// Call AutoIt script to upload file
			if (LoadProperties.BROWSER.trim().toLowerCase().contains("firefox")) {
				p = Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\main\\resources\\FileUploadScripts\\FF_FileUpload_Script.exe "+filePath);
			} else if (LoadProperties.BROWSER.trim().toLowerCase().contains("iexplore")) {
				p = Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\main\\resources\\FileUploadScripts\\IE_FileUpload_Script.exe "+filePath);
			} else if (LoadProperties.BROWSER.trim().toLowerCase().contains("chrome")) {
				p = Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\main\\resources\\FileUploadScripts\\Chrome_FileUpload_Script.exe "+filePath);
			}
			
			// Wait till file gets uploaded
			InputStream is = p.getInputStream();
			int retCode = 0;
			while (retCode != -1) {
				retCode = is.read();
			}
		} catch (IOException e) {
			logger.logFailed("Exception while uploading file "+filePath+" "+ExceptionUtils.getMessage(e));
			return;
		}
		uploadButton.click();
	}
	
	/**
	 * Method to click on publish data button
	 */
	public void publishData() {
		publishDataButton.click();
	}
}