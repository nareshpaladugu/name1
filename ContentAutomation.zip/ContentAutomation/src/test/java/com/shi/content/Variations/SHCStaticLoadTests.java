package com.shi.content.Variations;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.parsers.XMLParser;
import com.shc.autocontent.testcommons.FileProviderClass;

public class SHCStaticLoadTests {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		
		String sSite = sFileName.split("\\.")[0].split("-")[1];
		System.out.println(sSite);
		
		BlockingQueue<List<SingleProductOffer>> singleProductOfferQueue = new LinkedBlockingQueue<List<SingleProductOffer>>(); 
		
		BlockingQueue<List<VariationProductOffer>> variationProductOfferQueue = new LinkedBlockingQueue<List<VariationProductOffer>>();
		
		SHCContentCommons shcOfferCommons = new SHCContentCommons(sFileName,sSite);
		
		String sItemClassId = XMLParser.findNodeValue(sFileName, "catalog", "item-class-id");

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleProductOffer> prodThread = new ChunkProducerThread<SingleProductOffer>(sFileName, singleProductOfferQueue, SingleProductOffer.class,"single-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		ChunkProducerThread<VariationProductOffer> prodVariationThread = 
				new ChunkProducerThread<VariationProductOffer>(sFileName, variationProductOfferQueue, VariationProductOffer.class,"variation-product-offer");//, poison);
		prodVariationThread.setBucketSize(1);
		Thread variationProdThread = new Thread(prodVariationThread);
		variationProdThread.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<SingleProductOffer> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
					pool.execute(new SHC_ContentVerifications(nodeToTest.get(0),shcOfferCommons, sItemClassId, null,sSite));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		while(true){
			try {
				List<VariationProductOffer> varProdOfferList = variationProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(varProdOfferList == prodVariationThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + varProdOfferList);
					break;
				}
				if(varProdOfferList != null)
					pool.execute(new SHC_ContentVerifications(null,shcOfferCommons, sItemClassId, varProdOfferList.get(0),sSite));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
}


/*public static void compareSeo(Content content)
{
	com.generated.vos.content.Seo seo = content.getSeo();

	String hieraryChy = "";
	List<Hierarchy_> lstHieararchies = new ArrayList<Hierarchy_>();
	if(content.getTaxonomy().getWeb().getSites().getSears() != null)
		lstHieararchies = content.getTaxonomy().getWeb().getSites().getSears().getHierarchies();
	else if (content.getTaxonomy().getWeb().getSites().getKmart() != null)
		lstHieararchies = content.getTaxonomy().getWeb().getSites().getKmart().getHierarchies();
	else if (content.getTaxonomy().getWeb().getSites().getMygofer() != null)
		lstHieararchies = content.getTaxonomy().getWeb().getSites().getMygofer().getHierarchies();
	
	List<SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
	for (SpecificHierarchy specificHierarchy : spHie) {

		hieraryChy+=  " - "+ specificHierarchy.getName();
	}

	String brandinseotitle = content.getBrand()!= null?content.getBrand().getName():"";
	String brandinSEOURL = TestUtils.processURL(brandinseotitle.equals("")?"":brandinseotitle+"-");
	compareValues("seo-url","/"+ TestUtils.trimURL(brandinSEOURL+TestUtils.processURL(content.getName())) , seo.getUrl());

	
	compareValues("seo-title",brandinseotitle+" "+content.getName()+hieraryChy , seo.getTitle());

	int i = CompareValuesUtility.getPositionInList("L", content.getDesc(), "type", Desc.class);

	if(i==-1)
	{
		i = CompareValuesUtility.getPositionInList("S", content.getDesc(), "type", Desc.class);
	}

	String desc=  brandinSEOURL+content.getName()+"-"+content.getMfr().getModelNo()+"-"+content.getDesc().get(i).getVal();
	desc=desc.replaceAll("\\s+", " ").replaceAll("--", "-");
	compareValues("seo-desc", desc, seo.getDesc());


}
*/