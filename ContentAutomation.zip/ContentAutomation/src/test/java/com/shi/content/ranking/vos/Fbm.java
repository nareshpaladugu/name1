package com.shi.content.ranking.vos;

import java.util.ArrayList;
import java.util.List;

public class Fbm {
	private String trustedSeller;
	private String ediRouteCode;
	private List<WareHouseLocation> wareHouseLocations = new ArrayList<WareHouseLocation>();
	private WareHouse wareHouse;
	
	public WareHouse getWareHouse() {
		return wareHouse;
	}

	public void setWareHouse(WareHouse wareHouse) {
		this.wareHouse = wareHouse;
	}

	public List<WareHouseLocation> getWareHouseLocations() {
		return wareHouseLocations;
	}

	public void setWareHouseLocations(List<WareHouseLocation> wareHouseLocations) {
		this.wareHouseLocations = wareHouseLocations;
	}

	public String getEdiRouteCode() {
		return ediRouteCode;
	}

	public void setEdiRouteCode(String ediRouteCode) {
		this.ediRouteCode = ediRouteCode;
	}

	public String getTrustedSeller() {
		return trustedSeller;
	}

	public void setTrustedSeller(String trustedSeller) {
		this.trustedSeller = trustedSeller;
	}
	

}
