package com.shi.content.acme.publish;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.generated.vos.acmematchdata.AcmeMatchData;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.utils.EmailUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

public class AcmePublisherTests {

	private static boolean goAhead = true;
	private static String goAheadError = null;
	private static int iMessageCount = 0;
	ArrayList<String> publishedIds = new ArrayList<String>();
	ArrayList<String> sourceIds = new ArrayList<String>();
	
	@Test(description="Tests to read from qa-1.0_match queue and validate source ids", dataProvider="sourceIdProvider", groups="AcmePublisherTests")
	public void acmePublisherTests(Set<String> IDs, Integer pageNumber, Integer pageSize) throws Exception {

		if(iMessageCount == 0){
			return;
		}
		//Map<String,String> SourceResponseMap  = new HashMap<String, String>();
		
		long l1= System.currentTimeMillis();
		
		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("AUTO_FETCH") || LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH")){
			IDs = new HashSet<String>();
			
			String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source?page-size="+pageSize+"&page="+pageNumber;
			if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH")){
				String sSubUrl = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
				if(sSubUrl == null)
				{
					goAheadError = "Incorrect runparam";
					goAhead=false;
				}else
					sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source"+sSubUrl+"&page-size="+pageSize+"&page="+pageNumber;
			}else{
			
				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source?page-size="+pageSize+"&page="+pageNumber;
			}
			System.out.println("sUrl.... "+sUrl);
			
			
			if(goAhead){
	
				String jsonResponse = RestExecutor.getJSonResponse(sUrl);
				long l4 = System.currentTimeMillis();
				System.out.println("Thread data ids fetch completed "+ Thread.currentThread().getId()+ " "+ (l4-l1) + " ms");	
				try{
					String ids = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
		
					if(ids==null || ids.isEmpty())
					{
						// Some issue happened
						return;
					}
					String spSourceids[] = ids.split(",");
					
					JsonParser jParser = new JsonParser();
					JsonElement jsonElement = jParser.parse(jsonResponse);
					JsonArray array = jsonElement.getAsJsonObject().get("items").getAsJsonArray();
					jsonResponse = null;
					
					for (int i = 0; i < spSourceids.length; i++) {
		
						IDs.add(spSourceids[i]);
						//SourceResponseMap.put(spSourceids[i], array.get(i).getAsJsonObject().toString());
						sourceIds.add(spSourceids[i]);
		
					}
				}catch(Exception e){
					System.out.println("Response "+ jsonResponse);
					throw e;
				}
			}
		}
	}
	
	@BeforeClass(groups = "AcmePublisherTests")
	public void loadPublishedIds() {
		BlockingQueue<List<AcmeMatchData>> acmeMatchdataDocs = new LinkedBlockingQueue<List<AcmeMatchData>>();

		KafkaIAConsumer<AcmeMatchData> prodThread = new KafkaIAConsumer<AcmeMatchData>("AcmePublisherTestsQAConsumer", AcmeMatchData.class, acmeMatchdataDocs);		
		Thread t = new Thread(prodThread);
		t.start();
		
		try {
			while (true) {
				List<AcmeMatchData> nodeToTest;

				nodeToTest = acmeMatchdataDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					
					if(!publishedIds.contains(nodeToTest.get(0).getItem().getItemId())){
						publishedIds.add(nodeToTest.get(0).getItem().getItemId());
					}
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}
	
	@AfterClass(groups="AcmePublisherTests")
	public void result() {	
		int pubIdSize = publishedIds.size();
		int srcIdSize = sourceIds.size();
		System.out.println("Size of publishedIds=" + publishedIds.size());
		System.out.println("Size of sourceIds=" + sourceIds.size());
		sourceIds.removeAll(publishedIds);
		System.out.println("Difference in source/published ids=" + sourceIds.size());
		System.out.println(sourceIds.toString());
		
		String sCustomeBody="<br><font face='Calibri' color='black' size='2'> "
				+"<br>Size of publishedIds : "+ pubIdSize
				+"<br>Size of sourceIds : "+ srcIdSize
				+"<br>Difference in source/published ids : "+ sourceIds.size()
				+ "<font face='Calibri' color='red' size='2'>" 
				+"<br><br><font face='Calibri' color='black' size='2'>";

		EmailUtils.sendEmail("Acme Publisher Tests ", sCustomeBody, null);
	}
	
	@DataProvider(name="sourceIdProvider", parallel=true)
	public Object[][] sourceIdProvider()
	{
		Set<String> idsList = new java.util.HashSet<String>();
		String sSourceIds = LoadProperties.RUN_PARAMS;
		
		Integer pageSize = null, pageNumber = null;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE")) {
			idsList.addAll(Arrays.asList(sSourceIds.split(",")));
			return new Object[][] { { idsList, pageSize, pageNumber } };
		}
		else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE-FileMode"))
		{
			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");
			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty() )
					{
						idsList.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
			return new Object[][] { { idsList, pageSize, pageNumber } };

		}
		else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("AUTO_FETCH") || LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH"))
		{
			int expectedLimit;

			try {
				expectedLimit = LoadProperties.TESTDATALIMIT;
			} catch (NumberFormatException e1) {
				expectedLimit = -1;
				System.out.println("Setting expected limit to entire source collection");
			}

			String sUrl = null;
			String sSubURL = null;
			if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH"))
			{
				sSubURL = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
				if(sSubURL != null)
					sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source"+sSubURL+"&count";
				else{
					goAheadError = "Incorrect runparam";
					goAhead=false;
					return null;
				}
					
			}else{
				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/source?count";
			}
			
			System.out.println("sUrl.... "+sUrl);

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);
			String totalSourceCountValue = JsonStringParser.getJsonValue(jsonResponse, "{count}");
			Integer totalSourceCount = 0;
			if(totalSourceCount != null){
				totalSourceCount = Integer.parseInt(totalSourceCountValue);
			}
			
			int totalPages = 0;
			int lastPageSize = 0;
			if(expectedLimit == -1){
				pageSize =  100;
				totalPages = totalSourceCount/pageSize;
				lastPageSize = totalSourceCount%pageSize;
				if(totalSourceCount%pageSize == 0)
					totalPages--;
				
			}
			else{
				pageSize = 100;
				
				if(expectedLimit > totalSourceCount){
					expectedLimit = totalSourceCount;
				}
				if(expectedLimit <= pageSize){
					pageSize = expectedLimit;
					totalPages = 0;
				}
				else{
					totalPages = expectedLimit/pageSize;
					lastPageSize = expectedLimit%pageSize;
					if(expectedLimit%pageSize == 0)
						totalPages--;
					
				}
			}
			System.out.println( "--------Total sources : "+ totalSourceCount + " Pages to hit :"+ totalPages + "  PageSize : "+ pageSize);
			Object[][] toSend = new Object[totalPages+1][3];
//			int initPage =  6000;
			for(int i = 0 ; i < totalPages; i++){
				toSend[i] = new Object[]{null, i, pageSize};
			}
			toSend[totalPages] = new Object[]{null,totalPages, (lastPageSize == 0? pageSize:lastPageSize)};
			return toSend;
			
		} else {
			goAhead  = false;
			goAheadError = "Unsupported Execution Mode";
		}
		return null;
	}

}
