package com.shi.content.international;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.MySqlConnectionUtil;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class FixrateVerification implements Runnable {



	private String id;
	private String errResp;

	//List<BndlGrp> bundleGroups = new ArrayList<BndlGrp>();
	public static Map<String, String> groupIdMap = new HashMap<String, String>();
	public FixrateVerification()
	{
		
	}
	
	public void run() {
   com.generated.vos.fixrate.Fxrates fixrate =null;
			try{
				long l1 = System.currentTimeMillis();
				CompareValuesUtility.init();
				String[] groupIdlist = LoadProperties.groupId.split("\\,");	
				for(String id:groupIdlist){
					String[] groupDetail=id.split("\\=");
					groupIdMap.put(groupDetail[0], groupDetail[1]);
				}
				ResultSet resultSet_exchgRate = MySqlConnectionUtil.executeQueryReturnSingleResultSet("SELECT DISTINCT C.CURRENCY_CODE,C.COUNTRY_CODE,R.VALUE,R.QUOTE_ID FROM E4X_COUNTRIES C, E4X_FX_RATES R WHERE C.CURRENCY_CODE = R.SHOPPER_CURRENCY AND C.MERCHANT_ID=1601 AND C.SHIPPING_ENABLED='Y';");
						List<CurrencyVO> exchangeRate=convertToList(resultSet_exchgRate);
				ResultSet resultSet_countryRate = MySqlConnectionUtil.executeQueryReturnSingleResultSet("SELECT DISTINCT CASE WHEN (p.FRONT_LOAD_COEFFICIENT IS NULL OR TRIM(p.front_load_coefficient)='') THEN '1' ELSE p.FRONT_LOAD_COEFFICIENT END as FRONT_LOAD_COEFFICIENT,CASE WHEN (p.PROMOTION_ID IS NULL OR TRIM(p.promotion_id)='') THEN  '' ELSE p.PROMOTION_ID END as PROMOTION_ID ,C.SIMI_APPLICABLE, C.COUNTRY_CODE FROM E4X_COUNTRIES EC JOIN COUNTRY_RESTRICTION C ON EC.COUNTRY_CODE=C.COUNTRY_CODE LEFT OUTER JOIN E4X_PRICING_CUSTOMIZATIONS P ON P.COD=C.COUNTRY_CODE AND P.MERCHANT_ID=EC.MERCHANT_ID WHERE EC.SHIPPING_ENABLED='Y' AND EC.MERCHANT_ID=1601;");
						List<CountryVO> countryRate=convertToValue(resultSet_countryRate);		
						
					for(CurrencyVO currencyRate: exchangeRate){
						for(CountryVO countyRate: countryRate){
							if(currencyRate.getcountrycode().equalsIgnoreCase(countyRate.getcountryCd())){
								id= currencyRate.getcountrycode() + "-" + currencyRate.getcurrency();
								fixrate = RestExecutor.getDataById(CollectionValuesVal.Fixrate,
										id);
								if(fixrate!=null){
									CompareValuesUtility.verifyNullOrEqual("Rate", fixrate.getIntShipLcp().getRate().toString()==null?null:fixrate.getIntShipLcp().getRate().toString(), countyRate.getcoefficient()==null?null:countyRate.getcoefficient());	
									CompareValuesUtility.verifyNullOrEqual("Simi",fixrate.getIntShipLcp().getSimi()==null?null:fixrate.getIntShipLcp().getSimi(),countyRate.getsimi()==null?null:countyRate.getsimi());	
									CompareValuesUtility.verifyNullOrEqual("CountryCode",
											fixrate.getIntShipLcp().getCountryCode()==null?null:fixrate.getIntShipLcp().getCountryCode(), countyRate.getcountryCd()
													==null?null:countyRate.getcountryCd());	
									CompareValuesUtility.verifyNullOrEqual("pmId",
											fixrate.getIntShipLcp().getPmId()==null?null:fixrate.getIntShipLcp().getPmId(), countyRate.getpromoid()
													==null?null:countyRate.getpromoid());	
									CompareValuesUtility.verifyNullOrEqual("gId",
											fixrate.getIntShipLcp().getGId()==null?null:fixrate.getIntShipLcp().getGId(), groupIdMap.get(countyRate.getcountryCd())
													==null?null:groupIdMap.get(countyRate.getcountryCd()));	
									CompareValuesUtility.verifyNullOrEqual("exchangeRate",
											fixrate.getIntShipPrice().getExchangeRate().toString()==null?null:fixrate.getIntShipPrice().getExchangeRate().toString(), currencyRate.getvalue()
													==null?null:currencyRate.getvalue());	
									CompareValuesUtility.verifyNullOrEqual("currencyCode",
											fixrate.getIntShipPrice().getCurrencyCode()==null?null:fixrate.getIntShipPrice().getCurrencyCode(), currencyRate.getcurrency()
													==null?null:currencyRate.getcurrency());
									CompareValuesUtility.verifyNullOrEqual("quoteId",
											fixrate.getIntShipPrice().getQuoteId()==null?null:fixrate.getIntShipPrice().getQuoteId(), currencyRate.getquoteId()
													==null?null:currencyRate.getquoteId());
								CompareValuesUtility.setupResult(id, true);
								System.out.println("ID " +id);
								break;	
								}else{
									CompareValuesUtility.logFailed(id, "No Found in GB","");	
									CompareValuesUtility.setupResult(id, true);
								}
								
							}else{
							continue;
						}
							break;		
					}
					}
			}catch(Throwable e){
				System.out.println("Check this id :"+ id);
				System.out.println(this.errResp);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	

	
	public List<CurrencyVO> convertToList(ResultSet rs){
		List<CurrencyVO> countryExchgRate=new ArrayList<CurrencyVO>();
		CurrencyVO currency=new CurrencyVO();
		try {
			while(rs.next()){
				currency.setcurrency(rs.getString("CURRENCY_CODE"));
				currency.setcountrycode(rs.getString("COUNTRY_CODE"));
				currency.setvalue(rs.getString("VALUE"));
				currency.setquoteId(rs.getString("QUOTE_ID"));
				countryExchgRate.add(currency);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return countryExchgRate;
		
	}
	
public List<CountryVO> convertToValue(ResultSet rs){
		
		List<CountryVO> countryRate=new ArrayList<CountryVO>();
		CountryVO country=new CountryVO() ;
		try {
			while(rs.next()){
				country.setcoefficient(rs.getString("FRONT_LOAD_COEFFICIENT"));
				country.setpromoid(rs.getString("PROMOTION_ID"));
				country.setsimi(rs.getString("SIMI_APPLICABLE"));
				country.setcountryCd(rs.getString("COUNTRY_CODE"));
				countryRate.add(country);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return countryRate;
		
	}

class CurrencyVO{
	String currency,countrycode, value,quoteId;
	public CurrencyVO() {
	}
	public String getcurrency() {
		return currency;
	}
	public void setcurrency(String currency) {
		this.currency = currency;
	}
	public String getvalue() {
		return value;
	}
	public void setvalue(String value) {
		this.value = value;
	}
	public String getquoteId() {
		return quoteId;
	}
	public void setquoteId(String quoteId) {
		this.quoteId = quoteId;
	}
	public String getcountrycode() {
		return countrycode;
	}
	public void setcountrycode(String countrycode) {
		this.countrycode = countrycode;
	}
}
class CountryVO{
	String coefficient,promoid, simi,countryCd;
	public CountryVO() {
	}
	public String getcoefficient() {
		return coefficient;
	}
	public void setcoefficient(String coefficient) {
		this.coefficient = coefficient;
	}
	public String getpromoid() {
		return promoid;
	}
	public void setpromoid(String promoid) {
		this.promoid = promoid;
	}
	public String getsimi() {
		return simi;
	}
	public void setsimi(String simi) {
		this.simi = simi;
	}
	public String getcountryCd() {
		return countryCd;
	}
	public void setcountryCd(String countryCd) {
		this.countryCd = countryCd;
	}
}
	


}
