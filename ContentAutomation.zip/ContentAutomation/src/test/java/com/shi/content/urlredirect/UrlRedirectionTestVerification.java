package com.shi.content.urlredirect;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.shc.autocontent.softasserts.CompareValuesUtility;

/**
 * @author ddaphal
 *
 */
public class UrlRedirectionTestVerification implements Runnable {

	URLVo urlVo;

	public UrlRedirectionTestVerification(URLVo urlVo)
	{
		this.urlVo =  urlVo;
	}

	public void run()
	{
		CompareValuesUtility.init();

		HttpURLConnection httpConnection=null;

		try 
		{
			String urlToHit = null;

			if(this.urlVo.getCatalogId().equals("10104"))
			{
				urlToHit= UrlRedirectionTest.sKmartURL;
			}
			else if(this.urlVo.getCatalogId().equals("12605"))
			{
				urlToHit= UrlRedirectionTest.sSearsURL;
			}
			else
			{
				//CompareValuesUtility.addDataFieldForReport("UnHandled Catalog", this.urlVo.getCatalogId());
				return;
			}

			if(urlToHit==null)
			{
				System.out.println("urlToHit is null");
				return;
			}
			CompareValuesUtility.addDataFieldForReport("CATALOGID", this.urlVo.getCatalogId());

			CompareValuesUtility.addDataFieldForReport("OLDURL", this.urlVo.getOldUrl());

			//CompareValuesUtility.addDataFieldForReport("NEWURL", this.urlVo.getNewUrl());

			CompareValuesUtility.addDataFieldForReport("Calculated-NEWURL", convertNewUrl(this.urlVo.getCalculatedNewUrl()));

			if(this.urlVo.getOldUrl()==null || this.urlVo.getOldUrl().isEmpty() || this.urlVo.getOldUrl().equals("null"))
			{
				return;
			}

			if(this.urlVo.getOldUrl().contains("/shc/s"))
			{
				CompareValuesUtility.setupResult(this.urlVo.getId(),true);
				return;
			}

			urlToHit = urlToHit+this.urlVo.getOldUrl();

			URL url = new URL(urlToHit);

			//------------------------------ Response Text -------------------------

			httpConnection = (HttpURLConnection)url.openConnection();

			httpConnection.setInstanceFollowRedirects( false );
			httpConnection.connect();

			//------------------------------ Response Code -------------------------


			int responseCode = httpConnection.getResponseCode();

			CompareValuesUtility.addDataFieldForReport("ResponseCode", String.valueOf(responseCode));

			//System.out.println("ResponseCode... "+responseCode);

			String jvm = httpConnection.getHeaderField("s-srvr");

			jvm=jvm==null?"":jvm;

			CompareValuesUtility.addDataFieldForReport("JVM", jvm);

			System.out.println("responseCode..."+responseCode);

			if(responseCode==200)
			{
				//normal
			}
			else if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP
					|| responseCode == HttpURLConnection.HTTP_MOVED_PERM
					|| responseCode == HttpURLConnection.HTTP_SEE_OTHER || responseCode == 307)
			{
				//actual redirect

				String newUrl = httpConnection.getHeaderField("Location");

				if(newUrl==null)
					newUrl="";

				newUrl = newUrl.replace(UrlRedirectionTest.sKmartURL, "").replace(UrlRedirectionTest.sSearsURL, "");
				
				CompareValuesUtility.compareValues("NEWURL", convertNewUrl(this.urlVo.getCalculatedNewUrl()), newUrl.replaceFirst("\\?rdwna=y", ""));
			}
			else if(responseCode==404)
			{
				if(checkStreamForYikes(httpConnection))
				{
					CompareValuesUtility.addFailedDataFieldForReport("Yikes!", "Yikes! Page");
				}
				else
				{
					CompareValuesUtility.addFailedDataFieldForReport("Yikes!", "Response code : 404");
				}
			}
			else
			{
				if(checkStreamForYikes(httpConnection))
				{
					CompareValuesUtility.addFailedDataFieldForReport("Yikes!", "Yikes! Page");
				}
				else
				{
					CompareValuesUtility.addFailedDataFieldForReport("Error", "Response code : "+responseCode);
				}
			}

			httpConnection.disconnect();

		} 
		catch(java.net.ConnectException connectExp)
		{
			System.out.println("Page is not available...");
			CompareValuesUtility.addFailedDataFieldForReport("ERR_CONNECTION_REFUSED", "Page is not available");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			if(checkStreamForYikes(httpConnection))
			{
				CompareValuesUtility.addFailedDataFieldForReport("Yikes!", "Yikes! Page");
			}
			else
			{
				CompareValuesUtility.addFailedDataFieldForReport("Error", "Exception: "+e.getMessage()); //Not sure about Yikes!
			}
		} 

		CompareValuesUtility.setupResult(this.urlVo.getId(),true);
	}


	/**
	 * Check "Yikes!" word in html source stream or error stream
	 * @param httpConnection
	 * @return
	 */
	public boolean checkStreamForYikes(HttpURLConnection httpConnection)
	{
		String sCurrentLine;

		try 
		{
			BufferedReader in=new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));

			while ((sCurrentLine = in.readLine()) != null) {

				if(sCurrentLine.contains("Yikes!"))
				{
					//System.out.println("Input Stream ... "+sCurrentLine);

					return true;
				}
			}

		} catch (Exception e1) {
			//return true;
		}

		try
		{
			BufferedReader in=new BufferedReader(new InputStreamReader(httpConnection.getErrorStream()));

			while ((sCurrentLine = in.readLine()) != null) {

				if(sCurrentLine.contains("Yikes!"))
				{
					//System.out.println("Error Stream ... "+sCurrentLine);

					return true;
				}
			}

		} catch (Exception e1) {
			//return true;
		}

		return false;
	}
	
	public String convertNewUrl(String url){
		return url.replaceFirst("/v-", "/b-").replaceFirst("/c-", "/b-").replaceFirst("/s-", "/b-");
	}

	/*	public boolean checkForLoadingContent(HttpURLConnection httpConnection)
	{
		String sCurrentLine;

		try 
		{
			BufferedReader in=new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));

			while ((sCurrentLine = in.readLine()) != null) {

				if(sCurrentLine.contains("Loading content"))
				{
					System.out.println("Input Stream ... "+sCurrentLine);

					return true;
				}
			}

		} catch (Exception e1) {
			//return true;
		}

		return false;
	}*/


}
