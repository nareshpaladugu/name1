package com.shi.content.Variations;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.offer.AltIds;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.DispTags;
import com.generated.vos.offer.Ffm;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.PriceDispAttr;
import com.generated.vos.offer.Replenishment;
import com.generated.vos.offer.Shipping;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.Val;
import com.generated.vos.productoffering.Attribute;
import com.generated.vos.productoffering.ImageElementsGroup;
import com.generated.vos.productoffering.ImageUrl;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.ShipDimension;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.VariantAttribute;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.VendorPack;
import com.generated.vos.productoffering.types.AttributeTypeType;
import com.generated.vos.productoffering.types.ChokingHazardType;
import com.generated.vos.productoffering.types.GlobalAttributeType;
import com.generated.vos.productoffering.types.UpcTypeType;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.entity.AttrKey;
import com.shc.content.entity.AttrValue;
import com.shc.content.entity.CatentryIds;
import com.shc.content.restutils.RestExecutor;

public class SHC_OfferVerifications implements Runnable {

	SingleProductOffer singleProductOffer;
	VariationProductOffer varProdOffer;

	ProductContent prodContent;
	ProductOffer[] prodOffers;
	SHCContentCommons commonUtils;
	String itemClassId, sCatentryId;
	Boolean bSingleProductOffer = true, isSearsOffers = true;
	private String parentId;
	String siteToTest, partNumberToTest;
	CatentryIds catentryIds;
	List<String> errorPartNumbers;
	String upcToCheck = null;

	public SHC_OfferVerifications(SingleProductOffer wNodeListToTest,
			SHCContentCommons commonUtils, String itemClassId,
			VariationProductOffer varProdOffer, String sSite,
			CatentryIds catentryIds, List<String> erroredPartNumbers) {
		if (wNodeListToTest == null) {
			bSingleProductOffer = false;
		}
		this.singleProductOffer = wNodeListToTest;
		this.commonUtils = commonUtils;
		this.itemClassId = itemClassId;
		this.varProdOffer = varProdOffer;
		this.siteToTest = sSite;
		this.catentryIds = catentryIds;
		this.errorPartNumbers = erroredPartNumbers;
	}

	public void run() {

		this.getContentToTest();

		APIResponse<Offer> allResponse;
		for (ProductOffer pOffer : prodOffers) {
			if (bSingleProductOffer) {
				// for(String site : sitePartNumberMap.keySet()){
				if (partNumberToTest == null)
					continue;
				/*
				 * if(!partNumberToTest.equals("07136583000")) return;
				 */
				if (errorPartNumbers.contains(partNumberToTest)
						|| errorPartNumbers.contains(parentId)) {
					System.out.println("Skipping  " + partNumberToTest);
					continue;
				}
				/*
				 * if(!partNumberToTest.contains("02814790001")) return;
				 */
				allResponse = RestExecutor.getAllDataById(
						CollectionValuesVal.OFFER, partNumberToTest);
				callVerifs(pOffer, allResponse, partNumberToTest, catentryIds);
				// }
			} else {
				String partNumber = (siteToTest.equalsIgnoreCase("sears") ? pOffer
						.getPartNumber().getSearsPartNumber() : pOffer
						.getPartNumber().getKmartPartNumber());

				if (partNumber == null || parentId.equals("nullP"))
					continue;

				if (errorPartNumbers.contains(partNumber)
						|| errorPartNumbers.contains(parentId)) {
					System.out.println("Skipping  " + partNumber + " parent : "
							+ parentId);
					continue;
				}
				/*
				 * if(!partNumber.equals("07136583000")) return;
				 */

				partNumberToTest = partNumber;
				allResponse = RestExecutor.getAllDataById(
						CollectionValuesVal.OFFER, partNumber);
				callVerifs(pOffer, allResponse, partNumber, catentryIds);
			}

		}
	}

	private void callVerifs(ProductOffer xmlProductOffer,
			APIResponse<Offer> allResponse, String offerId,
			CatentryIds catentryIds) {
		try {
			CompareValuesUtility.init();
			Offer gbOffer = (Offer) allResponse.getT();

			if (gbOffer == null) {
				CompareValuesUtility.logFailed("Id", offerId, " Not found");
				CompareValuesUtility.setupResult(offerId, true);
				return;
			} else {
				verifyOffer(xmlProductOffer, gbOffer, offerId, siteToTest,
						catentryIds);
			}
			verifySearch(xmlProductOffer, allResponse);
			CompareValuesUtility.setupResult(offerId, true);
		} catch (Throwable e) {
			System.out.println("Check this id :" + offerId);
			e.printStackTrace();
		} finally {
			CompareValuesUtility.teardown();
		}
	}

	private void getContentToTest() {

		if (bSingleProductOffer) {

			if (siteToTest.equalsIgnoreCase("sears")) {
				isSearsOffers = true;
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getSearsPartNumber();

			} else {
				isSearsOffers = false;
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getKmartPartNumber();
			}

			parentId = partNumberToTest + "P";
			prodContent = singleProductOffer.getProductContent();
			prodOffers = singleProductOffer.getProductOfferings()
					.getProductOffer();

		} else {

			if (siteToTest.equalsIgnoreCase("sears")) {
				isSearsOffers = true;
				parentId = varProdOffer.getVariationSearsPartNumber() + "P";
			} else {
				isSearsOffers = false;
				parentId = varProdOffer.getVariationKmartPartNumber() + "P";
			}

			prodContent = varProdOffer.getProductContent();
			prodOffers = varProdOffer.getProductOfferings().getProductOffer();
		}
	}

	OfferCommons offerCommon;

	private void verifyOffer(ProductOffer xmlProductOffer, Offer gbOffer,
			String sOfferId, String site, CatentryIds catentryIds) {

		// sCatentryId = commonUtils.fetchCatentryId(sOfferId);
		if (site.equalsIgnoreCase("sears")) {
			sCatentryId = catentryIds.getSearsCatentryIds().get(sOfferId);
		} else if (site.equalsIgnoreCase("kmart")) {
			sCatentryId = catentryIds.getKmartCatentryIds().get(sOfferId);
		}
		offerCommon = new OfferCommons(gbOffer);

		offerCommon.commonVerifications(sOfferId, parentId,
				prodContent.getName(), false);

		offerCommon.verifyIdentity(xmlProductOffer.getSsin(),
				xmlProductOffer.getGuid());

		offerCommon.verifyBrandModel(prodContent.getBrand() == null ? null
				: prodContent.getBrand().getName(), prodContent
				.getManufacturerModelNumber());

		offerCommon.verifyClassifications(bSingleProductOffer);

		commonUtils.verifySites(prodContent, gbOffer.getSites(), false);

		verifyAltIds(xmlProductOffer, gbOffer.getAltIds());

		verifyImages(xmlProductOffer, gbOffer.getMainImg(),
				gbOffer.getSwatchImg());

		verifyShipping(xmlProductOffer.getShipDimension(),
				gbOffer.getShipping());

		verifyFFM(xmlProductOffer, gbOffer.getFfm(), site);

		verifyReplenishment(xmlProductOffer, gbOffer.getReplenishment());
		if (bSingleProductOffer && site.equalsIgnoreCase("sears")) {
			verifyIsRgnEligible(gbOffer);
		}
		verifyStoreTaxonomy(xmlProductOffer, gbOffer.getTaxonomy().getStore()
				.getHierarchy());

		verifyTaxonomy(gbOffer);

		if (prodContent.getNutrition() != null) {
			CompareValuesUtility.verifyNullOrEqual("Nutrition", prodContent
					.getNutrition().getHtmlLabel(), gbOffer.getGrocery()
					.getNutrition().getHtmlLabel(), "Html");
			CompareValuesUtility.verifyNullOrEqual("Nutrition", prodContent
					.getNutrition().getIngredients(), gbOffer.getGrocery()
					.getNutrition().getIngredients(), "Ing");
			CompareValuesUtility.verifyNullOrEqual("Nutrition", prodContent
					.getNutrition().getWarnings(), gbOffer.getGrocery()
					.getNutrition().getWarnings(), "Warning");
			CompareValuesUtility.addNewMultiValuedFields();
		} 
		//Commented. Not sure why we need this. Causing report issue
		/*else {
			CompareValuesUtility.addToHeaders(new String[] { "Nutrition" });
		}*/
		
		verifyLegal(xmlProductOffer, gbOffer.getLegal());

		CompareValuesUtility.addNewMultiValuedFields();

		DispTags dis = gbOffer.getDispTags();

		boolean bDealFlash = false;
		for (Attribute a : xmlProductOffer.getImaAttributes().getAttribute()) {
			if (a.getName().equals("SYW_ITEM_TYPE"))
				CompareValuesUtility.compareValues("DispTags", a.getContent(),
						dis == null ? null : dis.getSywItemType(), "SYWItem");
			if (a.getName().equals("deal flash") && a.getContent().equals("1"))
				bDealFlash = true;
		}
		if (bDealFlash)
			compareValues("DispTags", true,
					dis == null ? null : dis.getIsDealFlash(), "DealFlash");
		else
			CompareValuesUtility.verifyNull("DispTags", dis == null ? null
					: dis.getIsDealFlash(), "DealFlash");
		compareValues("DispTags",
				checkInAttributeGroup("Good Housekeeping - Seal of Approval"),
				dis == null ? null : dis.getIsGhkApproved(), false, true, "GHK");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getViewOnlyCode(), dis == null ? null : dis.getViewOnly(),
				false, true, "ViewOnly");
		compareValues("DispTags", xmlProductOffer.getOfferingIndicatorsGroup()
				.getSearsExclusive(),
				dis == null ? null : dis.getIsSearsExclusive(), false, true,
				"SearsExcl");
		compareValues("DispTags", prodContent.getSearchSuppressionFlag(),
				dis == null ? null : dis.getIsSearchSupression(), false, true,
				"SearchSupp");

		checkFlagsFromAttribs(gbOffer.getDispTags(),
				gbOffer.getPriceDispAttr(), catentryIds);

		CompareValuesUtility.addNewMultiValuedFields();

		if (xmlProductOffer.getVariantAttributes() != null)
			verifyDefiningAttrs(xmlProductOffer.getVariantAttributes()
					.getVariantAttribute(), gbOffer.getDefiningAttrs());
		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void verifyIsRgnEligible(Offer gbOffer) {
		 String s = "divitem";
	        String partnumber=partNumberToTest.substring(0, 8);
	        List<String> divtemList = RestExecutor.getIdsByAltKey(CollectionValuesVal.RGNPRICING, s, partnumber);
	        
	        verifyNullOrEqual("isRgnPriceElig", divtemList.isEmpty()?null:true,
	                gbOffer.getPriceDispAttr()==null?null: gbOffer.getPriceDispAttr().getIsRgnpriceElig());

	}

	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,
			List<Hierarchy> hierarchy) {

		long XMLHierarchyId;
		/*
		 * if(! (xmlProductOffer.getCoreHierarchyId() == null)) XMLHierarchyId =
		 * xmlProductOffer.getCoreHierarchyId(); else XMLHierarchyId =
		 * xmlProductOffer.getShcHierarchyId();
		 */

		if (siteToTest.equalsIgnoreCase("sears")) {
			if (xmlProductOffer.getCoreHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();
		} else {
			if (xmlProductOffer.getShcHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getShcHierarchyId();
		}
		List<String> lstPaths = ContentCache.getCatGroupPath(XMLHierarchyId);
		/*
		 * String sQuery =
		 * "select CATGROUP_ID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"
		 * + "= (select CATgroup_id from wcsadm.CATGRPDESC where keyword = '"+
		 * XMLHierarchyId+"') with ur";
		 * 
		 * List<String> lstPaths =
		 * DB2Utils.executeQueryMultiColumnSingleRow(sQuery);
		 */
		if (lstPaths == null) {
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "StoreHId",
					"null", "Store Hierarchy should be null");
			CompareValuesUtility.verifyTrue(hierarchy.size() == 0,
					"StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (hierarchy.size() == 0) {
			logFailed("StoreHId", XMLHierarchyId, "StoreHierarchy is null");
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		String lstCatgroupIds = Arrays.asList(lstPaths.get(0).split("/"))
				.subList(1, lstPaths.get(0).split("/").length).toString();

		lstCatgroupIds = lstCatgroupIds.substring(1,
				lstCatgroupIds.length() - 1);
		List<String> lstKeywords = ContentCache.getKeyword(lstCatgroupIds);
		/*
		 * sQuery =
		 * "select keyword from wcsadm.CATGRPDESC where catgroup_id in ("
		 * +lstCatgroupIds+") with ur"; List<String> lstKeywords =
		 * DB2Utils.executeQuerySingleColMulRow(sQuery);
		 */
		List<String> lstNames = Arrays.asList(lstPaths.get(1).split("/"))
				.subList(1, lstPaths.get(0).split("/").length);

		int iHierarchy = 0;
		for (String hierarchyId : lstKeywords) {
			Hierarchy gbHierarchy = hierarchy.get(iHierarchy);
			compareValues("StoreHId", hierarchyId,
					GenericUtil.convertToString(gbHierarchy == null ? null
							: gbHierarchy.getId()));
			compareValues("StoreHName", lstNames.get(iHierarchy++),
					gbHierarchy == null ? null : gbHierarchy.getName());
		}

		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void checkFlagsFromAttribs(DispTags dispTags,
			PriceDispAttr priceDispAttr, CatentryIds catentryIds) {
		/*
		 * String result= ""; try { if(isSearsOffers){ result =
		 * catentryIds.getSearsCheckFlagsFromAttribs1().get(sCatentryId); }else{
		 * result =
		 * catentryIds.getKmartCheckFlagsFromAttribs1().get(sCatentryId); } }
		 * catch (Exception e) { // TODO Auto-generated catch block //
		 * e.printStackTrace(); result = null; }
		 */
		// String sQuery =
		// "select stringvalue from wcsadm.XCATENTATTR where XATTRIBUTE_ID = 161 and "
		// +
		// "CATENTRY_ID = "+sCatentryId+" and storeid = "+(isSearsOffers?"10153":"10151"+" with ur");
		/*
		 * if(result != null) compareValues("DispTags",
		 * true,dispTags.getIsPriceFreqModel(),"IsPriceFreq :");
		 */
		// sQuery =
		// "select catentry_id from wcsadm.XCATENTAVREL where XATTRIBUTE_ID=1035223 and catentry_Id="+sCatentryId+" with ur";
		/*
		 * try { if(isSearsOffers){ result =
		 * catentryIds.getSearsCheckFlagsFromAttribs2().get(sCatentryId); }else{
		 * result =
		 * catentryIds.getKmartCheckFlagsFromAttribs2().get(sCatentryId); } }
		 * catch (Exception e) { // TODO Auto-generated catch block //
		 * e.printStackTrace(); result = null; } if(result != null)
		 * compareValues("DispTags", true,
		 * dispTags.getIsWaterFltrSubscrElig(),"WaterFilter :");
		 */
		if (prodContent.getProductAttributes() == null)
			return;
		for (ProductAttribute attrib : prodContent.getProductAttributes()
				.getProductAttribute()) {
			switch (String.valueOf(attrib.getAttributeId())) {
			case "499910": {
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19))
					compareValues("DispTags", true, dispTags == null ? null: dispTags.getIsConfigureTech(), "isConfigureTech:");
				break;

			}
			case "848810": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("PriceDispHotBuy",true,priceDispAttr == null ? null : priceDispAttr.getIsHotBuy());
				}
				break;
			}
			case "848610": {
				CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues(
							"PriceDispUpp",
							true,
							priceDispAttr == null ? null : priceDispAttr
									.getIsUPP());
				}
				break;
			}
			case "1774": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEnergyStar(), "isEnergyStar");
				}
				break;
			}
			case "1130610": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (attrib.getProductAttributeTypeChoice().getAttributeValueId() == Long.valueOf(19)) {
					compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
				}else
					CompareValuesUtility.verifyNull("DispTags", dispTags == null ? null	: dispTags.getIsEGiftElig(), "isEgiftElig");
				break;
			}
			//Added isDeliverySetupElig validation for Kmart on 12/18/2014
			case "886810": {
				// CompareValuesUtility.addNewMultiValuedFields();
				if (siteToTest.equalsIgnoreCase("kmart")) {
					if(attrib.getProductAttributeTypeChoice().getAttributeValueFlag() == true) {
						compareValues("DispTags", true, dispTags == null ? null	: dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}else {
						CompareValuesUtility.verifyNullOrFalse("DispTags", false, dispTags == null ? null : dispTags.getIsDeliverySetupElig(), "isDeliverySetupElig");
					}
				}
				break;
			}
			
			// CompareValuesUtility.compareValues("DispTags",
			// checkInAttributeGroup("Energy Star Compliant"),
			// dis==null?null:dis.getIsEnergyStar(),false, true,"isEnergyStar");
			default: {

			}
			}
		}

	}

	private void verifyLegal(ProductOffer xmlProductOffer, Legal legal) {

		if (xmlProductOffer.getImaAttributes().getHazardMaterialCode() == null
				&& xmlProductOffer.getImaAttributes().getHazardStorageCode() == null
				&& checkInAttributeGroup("California Emission Compliant") == null
				&& (xmlProductOffer.getImaAttributes().getProp65Flag() == false || xmlProductOffer
						.getImaAttributes().getProp65Flag() == null)
				&& xmlProductOffer.getGeoLimiters() == null
				&& (prodContent.getGlobalAttributes() == null || prodContent
						.getGlobalAttributes().getChokingHazard() == null)) {
			CompareValuesUtility.verifyNull("Legal", legal);
		} else {

			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getHazardMaterialCode(), legal.getHazmatMaterialCd(),
					"HazmatMtrCd:");
			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getHazardStorageCode(), legal.getHazmatStorageCd(),
					"HazmatStrgCd:");
			verifyNullOrEqual("Legal",
					checkInAttributeGroup("California Emission Compliant"),
					legal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", xmlProductOffer.getImaAttributes()
					.getProp65Flag() == false ? null : true,
					legal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),
						legal.getLimitedGeos());
		}
		verifyChokingHazards(legal);
	}

	private Boolean checkInAttributeGroup(String attrToCheck) {
		if (prodContent.getGlobalAttributes() != null) {
			for (GlobalAttributeType attGroup : prodContent
					.getGlobalAttributes().getAttribute()) {
				if (attGroup.value().equals(attrToCheck))
					return true;

			}
			return false;
		} else
			return null;

	}

	private void verifyChokingHazards(Legal legal) {
		if (prodContent.getGlobalAttributes() != null) {
			for (ChokingHazardType cType : prodContent.getGlobalAttributes()
					.getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
					compareValues("isNoWarning", true, legal.getIsNoWarning());
				else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
					compareValues("isNoWarning", true,
							legal.getSafetyWarnings());
				else
					CompareValuesUtility.verifyItemInList("ChokingHazard",
							cType.value(), legal.getChokingHazards());
			}
		}
	}

	private void verifyDefiningAttrs(VariantAttribute[] variantAttributes,
			List<DefiningAttr> definingAttrs) {
		CompareValuesUtility.addNewMultiValuedFields();
		for (VariantAttribute var : variantAttributes) {
			boolean bFound = false;
			// List<String> names =
			// fetchAttributeData(var.getAttributeId(),var.getVariantAttributeTypeChoice().getAttributeValueId());
			AttrKey key = new AttrKey(itemClassId, var.getAttributeId(), var
					.getVariantAttributeTypeChoice().getAttributeValueId());
			AttrValue value = ContentCache.getAttributeValue(key);
			for (DefiningAttr gbDefAttr : definingAttrs) {
				if (String.valueOf(var.getAttributeId()).equals(
						gbDefAttr.getAttr().getId())) {
					Val attrval = gbDefAttr.getVal();
					bFound = true;

					compareValues("DefAttrId", String.valueOf(var
							.getAttributeId()), gbDefAttr.getAttr().getId());
					compareValues(
							"DefAttrName",
							value.getDisplaylabel() == null ? null : value
									.getDisplaylabel(), gbDefAttr.getAttr()
									.getName());
					compareValues(
							"DefAttrSeq",
							value.getAttrSeqence() == null ? null : value
									.getAttrSeqence(), gbDefAttr.getAttr()
									.getSeq());

					if (var.getVariantAttributeTypeChoice()
							.getAttributeValueFree() != null) {
						compareValues("DefAttrValueId", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getId());
						compareValues("DefAttrValName", var.getVariantAttributeTypeChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getName());
						compareValues("DefAttrValFamily", var
								.getVariantAttributeTypeChoice()
								.getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal()
										.getFamilyName());
					} else {
						compareValues("DefAttrValueId", String.valueOf(var.getVariantAttributeTypeChoice().getAttributeValueId()),
								attrval == null ? null: gbDefAttr.getVal().getId());
						if (var.getTrademarkText() != null)
							compareValues("DefAttrValName",	var.getTrademarkText(),	attrval == null ? null : gbDefAttr.getVal().getName());
						else
							compareValues("DefAttrValName",	value.getStringValue() == null ? null: value.getStringValue(),
									attrval == null ? null : gbDefAttr.getVal().getName());

						compareValues("DefAttrValFamily",	value.getStringValue() == null ? null : value.getStringValue(),
								attrval == null ? null : gbDefAttr.getVal()	.getFamilyName());
						compareValues("DefAValSeq",	value.getSeqence() == null ? null : value.getSeqence(), attrval == null ? null
										: gbDefAttr.getVal().getSeq());
					}

					compareValues("DefAttrType", var.getAttributeType(),
							gbDefAttr.getAttr().getType());
					// DefAttrValName
					break;
				}
			}
			if (!bFound) {
				logFailed("DefAttrId", var.getAttributeId(), "Not found");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/*
	 * private List<String> fetchAttributeData(long attributeId, long
	 * attributeValueId) { String sQuery =
	 * "select att.displaylabel, xcatgrpattrrel.ATTRIBUTESEQUENCE,  atval.STRINGVALUE, atval.SEQUENCE from"
	 * +
	 * " wcsadm.xattribute att, wcsadm.xattrvalue atval,wcsadm.xcatgrpattrrel where atval.NAME = '"
	 * +attributeValueId+"'" +
	 * " and atval.XATTRIBUTE_ID in (select XATTRIBUTE_ID from wcsadm.xattribute where field2 = '"
	 * +attributeId+"') and " +
	 * "atval.XATTRIBUTE_ID = att.XATTRIBUTE_ID and xcatgrpattrrel.XATTRIBUTE_ID = atval.XATTRIBUTE_ID and "
	 * +
	 * "xcatgrpattrrel.catgroup_id in (select catgroup_id from wcsadm.catgroup where identifier='"
	 * +itemClassId+"') with ur"; return
	 * DB2Utils.executeQueryMultiColumnSingleRow(sQuery); }
	 */

	private void verifyAltIds(ProductOffer xmlProductOffer, AltIds altIds) {

		// compareValues("AltIds",
		// sCatentryId,GenericUtil.convertToString(altIds.getCatentryId()),"CatentryId");
		verifyNullOrEqual("AltIds", xmlProductOffer.getImaAttributes().getKsnId(), altIds.getKsn(), "Ksn");
		upcToCheck = xmlProductOffer.getUpc();
		
		if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_0.value())){
			upcToCheck = validateUPC(upcToCheck, 12);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_1.value()) || xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_2.value())){
			upcToCheck = validateUPC(upcToCheck, 8);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_3.value())){
			upcToCheck = validateUPC(upcToCheck, 13);
		}
		else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_7.value())){
			upcToCheck = validateUPC(upcToCheck, 14);
		}
		compareValues("AltIds", upcToCheck, altIds.getUpc(),	"Upc");	
			
		compareValues("AltIds", xmlProductOffer.getUpcType(), GenericUtil.convertToString(altIds.getUpcType()), "UpcType");
		/*if (xmlProductOffer.getImaAttributes().getVendorPack().length > 0)
			verifyNullOrEqual("AltIds", xmlProductOffer.getImaAttributes().getVendorPack()[0].getVendorStockNumber(),
					altIds.getVendorStockNo(), "VendorStockNo");*/
		for(VendorPack vendorPack : xmlProductOffer.getImaAttributes().getVendorPack()){
			if(vendorPack.getStoreName().equalsIgnoreCase(siteToTest)){
				verifyNullOrEqual("AltIds", vendorPack.getVendorStockNumber(), altIds.getVendorStockNo(), "VendorStockNo");
				break;
			}
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private String validateUPC(String upc, int length){
		return upc.length()>length? upc.substring(0, length):StringUtils.leftPad(upc, length, "0");
	}

	private void verifyImages(ProductOffer xmlProductOffer,
			List<MainImg> mainImg, List<SwatchImg> lstSwatchImgs) {
		ImageUrl primImageURL = xmlProductOffer.getImageUrl();

		if (primImageURL.getImageElementsGroup() != null) {
			if (mainImg.size() == 0)
				compareValues("PrimaryImage", primImageURL.getImageElementsGroup().getUrl(), "Not found");
			else {
				compareValues("PrimaryImage", TestUtils.modifyURL(primImageURL.getImageElementsGroup().getUrl()), mainImg.get(0)
						.getSrc(), "Src");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getName(), mainImg.get(0).getTitle(), "Title");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getHeight(),GenericUtil.convertToIntFromDouble(mainImg.get(0)
								.getHeight()), "Height");
				CompareValuesUtility.verifyNullOrEqual("PrimaryImage",primImageURL.getImageElementsGroup().getWidth(),
						GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()), "Width");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}

		// Only check for swatch image for variant items
		if (bSingleProductOffer)
			return;

		// Verify if any of the variant attributes is of type swatch, if yes,
		// only then continue
		boolean bSwatchAttribFound = false;
		for (VariantAttribute varAttri : xmlProductOffer.getVariantAttributes()
				.getVariantAttribute()) {
			if (varAttri.getAttributeType().equals(AttributeTypeType.SWATCH)) {
				bSwatchAttribFound = true;
				break;
			}
		}

		if (!bSwatchAttribFound)
			return;

		ImageElementsGroup swatchImageURL = xmlProductOffer.getSwatchImage()
				.getImageElementsGroup();
		if (lstSwatchImgs.size() == 0)
			compareValues("SwatchImg", swatchImageURL.getUrl(), "Not found");
		else {

			compareValues("SwatchImg", TestUtils.modifyURL(swatchImageURL
					.getUrl()), lstSwatchImgs.get(0).getSrc(), "Src");
			CompareValuesUtility.verifyNullOrEqual("SwatchImg",
					swatchImageURL.getName(), lstSwatchImgs.get(0).getTitle(),
					"Title");
			CompareValuesUtility.verifyNullOrEqual("SwatchImg", swatchImageURL
					.getHeight(), GenericUtil
					.convertToIntFromDouble(lstSwatchImgs.get(0).getHeight()),
					"Height");
			CompareValuesUtility.verifyNullOrEqual("SwatchImg", swatchImageURL
					.getWidth(), GenericUtil
					.convertToIntFromDouble(lstSwatchImgs.get(0).getWidth()),
					"Width");
			CompareValuesUtility.addNewMultiValuedFields();
		}

	}

	private void verifyReplenishment(ProductOffer xmlProductOffer,
			Replenishment replenishment) {

		VendorPack vendorPToTest = null;
		for (VendorPack vPack : xmlProductOffer.getImaAttributes()
				.getVendorPack()) {
			if (vPack.getStoreName().equalsIgnoreCase(siteToTest)) {
				vendorPToTest = vPack;
				break;
			}
		}
		if (vendorPToTest != null) {
			// Cost will be updated by operational load - 7-30 changes
			// compareValues("Replenishment",
			// vendorPToTest.getCost(),replenishment.getUnitCost(),"Cost");
			compareValues(
					"Replenishment",
					vendorPToTest.getVendorPackId(),
					replenishment == null ? null : replenishment
							.getVendorPackId(), "Vendor");
			verifyNullOrEqual("Replenishment", vendorPToTest.getFlowType(),
					replenishment == null ? null : replenishment.getFlowType(),
					"FlowType");
			CompareValuesUtility.addNewMultiValuedFields();
		}
		verifyNullOrEqual("RplnishCanCarry",
				GenericUtil.convertToString(xmlProductOffer.getImaAttributes()
						.getCancarryGroup()), replenishment == null ? null
						: replenishment.getCanCarryGrp());
		verifyNullOrEqual("RplnishCountry", xmlProductOffer.getImaAttributes()
				.getCountryOfOrigin(), replenishment == null ? null
				: replenishment.getCntryOfOrig());
		// verifyNullOrEqual("RplnishPurchaseSet",
		// xmlProductOffer.getImaAttributes().getVendorPack()[0].getPurchaseStatus(),replenishment.getPurchaseSts());
		
		//commented by daffy - ECOM-361820
		/*for (VendorPack vp : xmlProductOffer.getImaAttributes().getVendorPack()) {
			if (vp.getStoreName().equalsIgnoreCase(siteToTest))
				verifyNullOrEqual(
						"RplnishPurchaseSet",
						vp.getPurchaseStatus(),
						replenishment == null ? null : replenishment
								.getPurchaseSts());
		}*/

	}

	private void verifyFFM(ProductOffer xmlProductOffer, Ffm ffm, String site) {
		if (ffm == null) {
			logFailed("FFM", "sears", "No ffm tag found");
			return;
		}
		compareValues("FFM",
				site.substring(0, 1).toUpperCase() + site.substring(1),
				ffm.getSoldBy(), "SoldBy");
		String sFFMBy = site.substring(0, 1).toUpperCase() + site.substring(1);
		/*
		 * if(xmlProductOffer.getFulfillment().equals(FulfillmentType.FBM)){
		 * sFFMBy = "Sears Authorized Supplier"; compareValues("FFM", "VD",
		 * ffm.getChannel(),"Channel"); }else
		 * CompareValuesUtility.verifyNull("FFM",ffm.getChannel(),"Channel");
		 */

		if (ffm.getChannel() != null && ffm.getChannel().equals("VD")) {
			sFFMBy = "Sears Authorized Supplier";
		}
		compareValues("FFM", sFFMBy, ffm.getFulfilledBy(), "FulfilledBy");
		CompareValuesUtility.verifyNullOrEqual("FFM", xmlProductOffer
				.getOfferingIndicatorsGroup().isWebOnlyFlag() == false ? null
				: true, ffm.getIsWebExcl(), "isWebExc");
		CompareValuesUtility.addNewMultiValuedFields();
		// ffm.getDfltFfmDisplay()
	}

	private void verifyShipping(ShipDimension shipDimension, Shipping shipping) {

		offerCommon.verifyShipping(shipDimension.getLength(),
				shipDimension.getWidth(), shipDimension.getHeight(),
				shipDimension.getWeight());
	}

	private void verifySearch(ProductOffer xmlProductOffer,
			APIResponse<Offer> allResponse) {
		CompareValuesUtility.addNewMultiValuedFields();
		// CompareValuesUtility.verifyNullOrEqual("_Search",prodContent.getManufacturerModelNumber()
		// == null? null :
		// prodContent.getManufacturerModelNumber().replaceAll("[^\\w]",
		// "").toUpperCase(),allResponse.getSearchFieldValue("model_no"),"Model_no");
		CompareValuesUtility.verifyNullOrEqual("_Search", prodContent.getManufacturerModelNumber() == null ? null : prodContent
				.getManufacturerModelNumber().replaceAll("[^a-zA-Z0-9]", "").toUpperCase(), allResponse.getSearchFieldValue("model_no"),
				"Model_no");
		compareValues("_Search", upcToCheck, allResponse.getSearchFieldValue("upc"), "Upc");
		compareValues("_Search", parentId, allResponse.getSearchFieldValue("parentId"), "ParentId");
		CompareValuesUtility.verifyNullOrEqual("_Search", xmlProductOffer.getImaAttributes().getKsnId(), allResponse.getSearchFieldValue("ksn"), "Ksn");
		if(siteToTest.equalsIgnoreCase("sears")) {
			compareValues("_Search", partNumberToTest.substring(0, 8),
					allResponse.getSearchFieldValue("divitem"), "DivItem");
		}
		CompareValuesUtility.verifyNullOrEqual("_Search", xmlProductOffer.getSsin(), xmlProductOffer.getSsin() == null ? null
				: allResponse.getSearchFieldValue("ssin"), "SSIN");
		CompareValuesUtility.verifyNullOrEqual("_Search", xmlProductOffer.getGuid(), xmlProductOffer.getGuid() == null ? null
				: allResponse.getSearchFieldValue("uid"), "UID");
	}

	private void verifyTaxonomy(Offer gbOffer) {

		SHCContentCommons commonUtils = new SHCContentCommons();

		if (gbOffer.getTaxonomy() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"
					+ itemClassId, "Taxonomy is null");
			return;
		} else if (gbOffer.getTaxonomy().getMaster() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"
					+ itemClassId, "Taxonomy-master is null");
			return;
		}
		commonUtils.compareMasterhierarchy(Long.parseLong(itemClassId), gbOffer
				.getTaxonomy().getMaster().getHierarchy());

		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for (Site site : prodContent.getSite()) {

			long lSiteId = site.getId();
			if (lSiteId > 11 || lSiteId == 10)
				continue;
			String siteName = TestUtils.getSite(lSiteId);
			if ((siteToTest.equalsIgnoreCase("sears") && siteName
					.equalsIgnoreCase("kmart"))
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName
							.equalsIgnoreCase("sears"))) {
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for (com.generated.vos.productoffering.Hierarchy hierarchy : site
					.getTaxonomy().getHierarchy()) {
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy
						.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if (gbOffer.getTaxonomy().getWeb() == null) {
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"
					+ itemClassId, "Taxonomy-web is null");
			return;
		}
		commonUtils.compareWebhierarchy(mpSiteHiearachies, gbOffer
				.getTaxonomy().getWeb());
		CompareValuesUtility.addNewMultiValuedFields();

	}

	/*
	 * private void verifyFt(APIResponse<Offer> allResponse){
	 * 
	 * compareValues("Ft",sellerId,allResponse.getFtFieldValue("sellerId"),
	 * "SellerId");
	 * compareValues("Ft",programType,allResponse.getFtFieldValue("pgrmType"
	 * ),"pgrmType");
	 * 
	 * 
	 * }
	 */

}
