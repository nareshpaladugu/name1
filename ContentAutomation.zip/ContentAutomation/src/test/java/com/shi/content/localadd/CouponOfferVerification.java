package com.shi.content.localadd;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.localadgrp.Localadgrp_;
import com.generated.vos.localoffer.Localoffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class CouponOfferVerification implements Runnable {

	List<String> localadddata;
	int currentCount;
	Map<String, Localadgrp_> localAdGrpMap;

	public CouponOfferVerification(List<String> pricingDataForProduct,
			int currentC, 
			Map<String, Localadgrp_> localAdGrpMap) {
		this.localadddata = pricingDataForProduct;
		this.currentCount = currentC;
		this.localAdGrpMap = localAdGrpMap;
	}

	public void run() {
		long l1 = System.currentTimeMillis();
		CompareValuesUtility.init();
		List<String> localadd = new ArrayList<String>();
		String[] singlePriceData = localadddata.get(0).split("\\|");
		// this Gbid is the main id that we hit with api in the greenbox
		/*String GbId = singlePriceData[1] + "_" + singlePriceData[0] + "_"
				+ singlePriceData[10] + "_" + singlePriceData[11] + "_"
				+ singlePriceData[5].replaceAll("/", "").substring(0, 8) + "_"
				+ singlePriceData[6].replaceAll("/", "").substring(0, 8);*/
		// storing data in each line in the list
		String gbMainid="";
		
		try{
		for (String s : localadddata) {
			localadd.add(s);

		}
		// getting data for each line and each field
		
		for (String id : localadd) {
			String[] afterSplit = id.split("\\|");
			String Title = afterSplit[0];
			String Description = afterSplit[1];
			String OfferStartDate = afterSplit[2];
			String OfferEndDate = afterSplit[3];
			String PostStartDate = afterSplit[4];
			String PostEndDate = afterSplit[5];
			String FinePrint = afterSplit[6];
			String ProductRegPrice = afterSplit[7];
			String ProductSalePrice = afterSplit[8];
			String OfferMessage = afterSplit[9];
			String ImageFileName = afterSplit[10];
			String OfferType = afterSplit[11];
			String CategoryGroupID = afterSplit[12];
			String StoreID = afterSplit[13];
			String AvailableOnlineProductCode = afterSplit[14];
			String Status="";
			if(afterSplit.length>15){
				Status = afterSplit[15];
				
			}else{
				Status="1";	
			}
			Localoffer localGB1 = null;
			Localadgrp_ localgrp=null;
			String GroupID = "X"; //Default group id to X
			
			String strIdType = StoreID+"-"+OfferType; //key to get group details from group Map
			
			if(OfferType.equals("SYWR") || OfferType.equals("FINANCEOFFER")){
				strIdType = "0"+"-"+OfferType; //for SYWR and FINANCEOFFER use storeId as 0
			}
			if(localAdGrpMap.get(strIdType)!=null){
				localgrp = localAdGrpMap.get(strIdType); //get data from map using storeId and offerTye as key
				GroupID = localgrp.getId(); //assign groupId
			}	
			 
		if(OfferStartDate.trim().equals("") ||OfferEndDate.trim().equals("")||Title.trim().equals("")||CategoryGroupID.trim().equals("")||!(LoadProperties.Local_Store.contains(StoreID))) 
			{
			gbMainid= CategoryGroupID + "_" + "X" + "_" + 0000 + "_"
					+ StoreID + "_"+ GroupID + "_"
					+ OfferStartDate.replaceAll("/", "").substring(0, 8) + "_"
					+ OfferStartDate.replaceAll("/", "").substring(0, 8);
			localGB1 = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,
					gbMainid);
			if(localGB1!=null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer should not be loaded");
				CompareValuesUtility.setupResult(gbMainid, true);
			}
			
		}else{
			gbMainid= CategoryGroupID + "_" + "X" + "_" + "0000" + "_"
					+ StoreID + "_"+ GroupID + "_"
					+ OfferStartDate.replaceAll("/", "").substring(0, 8) + "_"
					+ OfferEndDate.replaceAll("/", "").substring(0, 8);
			localGB1 = RestExecutor.getDataById(CollectionValuesVal.LOCALOFFER,
					gbMainid);
		if(localGB1==null){
				CompareValuesUtility.logFailed("Id",gbMainid, "local offer notfound");
				CompareValuesUtility.setupResult(gbMainid, true);
		}else{
				
			if(PostStartDate.equals(""))
				PostStartDate=OfferStartDate;
			if(PostEndDate.equals(""))
				PostEndDate=OfferStartDate;
			if(Status.trim().equals("")||!(LoadProperties.Status.contains(Status)))
				Status="1";

			/*if (StoreID.equals("10153")) {
				VerifySears(gbMainid, AvailableOnlineProductCode,localGB1);	
			}
			 if (StoreID.equals("10151")) {
			VerifyKmart(gbMainid, AvailableOnlineProductCode,localGB1);	
			}*/
			
			verifyTaxonomy(CategoryGroupID, localGB1);
			 
			CompareValuesUtility.compareValues("OfferStartDate",
					OfferStartDate==null?null:OfferStartDate, localGB1.getSaleStDt()
							==null?null:localGB1.getSaleStDt());
			CompareValuesUtility.compareValues("OfferEndDate", OfferEndDate
					.toString(), localGB1.getSaleEndDt().toString());
			CompareValuesUtility.compareValues("PostStartDate",
					PostStartDate.toString(), localGB1.getPostStDt()
							.toString());
			CompareValuesUtility.compareValues("PostEndDate", PostEndDate
					.toString(), localGB1.getPostEndDt().toString());
			CompareValuesUtility.compareValues("Title", Title
					, localGB1.getTitle()==null?null:localGB1.getTitle());
			CompareValuesUtility.verifyNullOrEqual("FinePrint", FinePrint
					, localGB1.getFinePnt()==null?null:localGB1.getFinePnt());
			CompareValuesUtility.compareValues("SalePrice", ProductSalePrice
					, localGB1.getSp()==null?null:localGB1.getSp());
			CompareValuesUtility.compareValues("RegularPrice", ProductRegPrice
					, localGB1.getRp()==null?null:localGB1.getRp());
			CompareValuesUtility.verifyNullOrEqual("ClearancePrice", Description
					, localGB1.getDesc()==null?null:localGB1.getDesc());
			CompareValuesUtility.compareValues("Status", Status
					, localGB1.getStatus()==null?null:localGB1.getStatus());
			CompareValuesUtility.compareValues("StoreId", StoreID
					, localGB1.getStoreId()==null?null:localGB1.getStoreId().intValue());
			CompareValuesUtility.compareValues("OfferMessage", OfferMessage
					, localGB1.getOfferMessage()==null?null:localGB1.getOfferMessage());
			CompareValuesUtility.verifyNullOrEqual("ImageFileName", ImageFileName
					, localGB1.getImgFileName()==null?null:localGB1.getImgFileName());
			CompareValuesUtility.verifyNullOrEqual("OfferType", OfferType
					, localGB1.getGrpType()==null?null:localGB1.getGrpType());
			/*CompareValuesUtility.verifyNullOrEqual("CategoryGroupID", CategoryGroupID
					, localGB1.getcat==null?null:localGB1.getGrpType());*/
			CompareValuesUtility.verifyNullOrEqual("AvailableOnlineProductCode", AvailableOnlineProductCode
					, localGB1.getOfferId()==null?null:localGB1.getOfferId());
			if(localgrp!=null){
			CompareValuesUtility.compareValues("grpid",localgrp.getId(),localGB1.getGrpId());	
			CompareValuesUtility.compareValues("grpDesc",localgrp.getDesc(),localGB1.getGrpDesc());	
			CompareValuesUtility.compareValues("grpName",localgrp.getName(),localGB1.getGrpName());	
			CompareValuesUtility.compareValues("grpStdt",localgrp.getSttdt(),localGB1.getGrpStDt());	
			CompareValuesUtility.compareValues("grpEnddt",localgrp.getEnddt(),localGB1.getGrpEndDt());	
			CompareValuesUtility.compareValues("grpType",localgrp.getType(),localGB1.getGrpType());
			CompareValuesUtility.compareValues("grpDispOrd",localgrp.getDispOrd().intValue(),localGB1.getGrpDispOrd());
			CompareValuesUtility.compareValues("grpStatus",localgrp.getStatus().intValue(),localGB1.getGrpStatus());
			CompareValuesUtility.compareValues("grpStoreId",localgrp.getStoreId().intValue(),localGB1.getGrpStoreId());
			}
			
			
		}
		
		}
		CompareValuesUtility.setupResult(gbMainid, true);
		}
		}catch(Throwable e){
			System.out.println("Check this id :"+ gbMainid);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	
	private void verifyTaxonomy(String categoryGroupID, Localoffer localGB) {
		APIResponse<Hierarchy> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.WEB_HIERARCHY, categoryGroupID);
		Hierarchy gbHierarchy = allResponse.getT();
		
		String displayPath = null;
		if(gbHierarchy!=null){
		for(Path path : gbHierarchy.getPath()){
			if(path.getIsPrimary()){
				displayPath = path.getDisplayPath();
			}
		}
		
		String [] levels = displayPath.split("\\|");
		
		String vertical = levels[0];
		String category = levels[1];
		String subcategory = levels[2];
		String leaf = levels[levels.length-1];
		String path = displayPath.replaceAll("\\|", "/");
		
		CompareValuesUtility.verifyNullOrEqual("Vertical", vertical, localGB.getVertical()==null?null:localGB.getVertical());
		CompareValuesUtility.verifyNullOrEqual("Category", category, localGB.getCategory()==null?null:localGB.getCategory());
		CompareValuesUtility.verifyNullOrEqual("SubCategory", subcategory, localGB.getSubcategory()==null?null:localGB.getSubcategory());
		CompareValuesUtility.verifyNullOrEqual("Leaf", leaf, localGB.getLeaf()==null?null:localGB.getLeaf());
		CompareValuesUtility.verifyNullOrEqual("Catgrppath", path, localGB.getCtgrpPath()==null?null:localGB.getCtgrpPath());
		CompareValuesUtility.verifyNullOrEqual("CategoryGrpId", categoryGroupID, localGB.getCategoryGrpId()==null?null:localGB.getCategoryGrpId());
		}
	}

	/*public void VerifySears(String Mainid,  String AvailableOnlineProductCode, Localoffer localGB) {
		APIResponse<Object> offerAllreponse = null;
		Offer offerGB = null;
		if(!AvailableOnlineProductCode.trim().equals("")){
		offerAllreponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, AvailableOnlineProductCode);
		offerGB = offerAllreponse.getT();
		}
				String vertical=null;
				String category=null;
				String subcategory=null;
				String leaf=null;
				String path=null;
				if(offerGB!=null && offerGB.getTaxonomy()!=null && offerGB.getTaxonomy().getWeb()!=null &&offerGB.getTaxonomy().getWeb().getSites()!=null && offerGB.getTaxonomy().getWeb().getSites()
						.getSears()!=null){
				vertical = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(0).getName();
				category = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getName();
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().size()>2){
				 subcategory = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(2).getName();
				}
				int j = (offerGB.getTaxonomy().getWeb().getSites().getSears()
						.getHierarchies().get(0).getSpecificHierarchy().size()) - 1;
				leaf = offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().get(j).getName();
				path = vertical;
				for (int m = 1; m < offerGB.getTaxonomy().getWeb().getSites()
						.getSears().getHierarchies().get(0)
						.getSpecificHierarchy().size(); m++) {
					path = path
							+ "/"
							+ offerGB.getTaxonomy().getWeb().getSites()
									.getSears().getHierarchies().get(0)
									.getSpecificHierarchy().get(m).getName();

				}
				}
			
				CompareValuesUtility.verifyNullOrEqual("BrandName", localGB
						.getBrandName()==null?null:localGB
								.getBrandName(), offerGB.getBrandName()==null?null:offerGB.getBrandName()
						);
				CompareValuesUtility.verifyNullOrEqual("vertical", localGB
						.getVertical()==null?null:localGB
								.getVertical(), vertical);
				CompareValuesUtility.verifyNullOrEqual("Category", localGB
						.getCategory()==null?null:localGB
								.getCategory(), category);
				CompareValuesUtility.verifyNullOrEqual("SubCategory", localGB
						.getSubcategory()==null?null:localGB
								.getSubcategory(), subcategory);
				CompareValuesUtility.verifyNullOrEqual("Leaf", localGB.getLeaf()==null?null:localGB.getLeaf()
						, leaf);
				CompareValuesUtility.verifyNullOrEqual("Catgrppath", localGB
						.getCtgrpPath()==null?null:localGB
								.getCtgrpPath(), path);
				}*/

	
	
	/*public void VerifyKmart(String Mainid,  String AvailableOnlineProductCode, Localoffer localGB) {
		APIResponse<Object> offerAllreponse = null;
		Offer offerGB = null;
		if(!AvailableOnlineProductCode.trim().equals("")){
		offerAllreponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, AvailableOnlineProductCode);
		offerGB = offerAllreponse.getT();
		}
				String vertical=null;
				String category=null;
				String subcategory=null;
				String leaf=null;
				String path=null;
				if(offerGB!=null && offerGB.getTaxonomy()!=null && offerGB.getTaxonomy().getWeb()!=null &&offerGB.getTaxonomy().getWeb().getSites()!=null && offerGB.getTaxonomy().getWeb().getSites()
						.getKmart()!=null){
				vertical = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(0).getName();
				category = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(1).getName();
				if(offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().size()>2){
				 subcategory = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(2).getName();
				}
				int j = (offerGB.getTaxonomy().getWeb().getSites().getKmart()
						.getHierarchies().get(0).getSpecificHierarchy().size()) - 1;
				leaf = offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().get(j).getName();
				path = vertical;
				for (int m = 1; m < offerGB.getTaxonomy().getWeb().getSites()
						.getKmart().getHierarchies().get(0)
						.getSpecificHierarchy().size(); m++) {
					path = path
							+ "/"
							+ offerGB.getTaxonomy().getWeb().getSites()
									.getKmart().getHierarchies().get(0)
									.getSpecificHierarchy().get(m).getName();

				}
				}
			
				CompareValuesUtility.verifyNullOrEqual("BrandName", localGB
						.getBrandName()==null?null:localGB
								.getBrandName(), offerGB.getBrandName()==null?null:offerGB.getBrandName()
						);
				CompareValuesUtility.verifyNullOrEqual("vertical", localGB
						.getVertical()==null?null:localGB
								.getVertical(), vertical);
				CompareValuesUtility.verifyNullOrEqual("Category", localGB
						.getCategory()==null?null:localGB
								.getCategory(), category);
				CompareValuesUtility.verifyNullOrEqual("SubCategory", localGB
						.getSubcategory()==null?null:localGB
								.getSubcategory(), subcategory);
				CompareValuesUtility.verifyNullOrEqual("Leaf", localGB.getLeaf()==null?null:localGB.getLeaf()
						, leaf);
				CompareValuesUtility.verifyNullOrEqual("Catgrppath", localGB
						.getCtgrpPath()==null?null:localGB
								.getCtgrpPath(), path);
				}*/

}
