package com.shi.content.wcsmigration.commons.vos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RuleVO {

	private String site;
	
	public String getSite() {
		return site;
	}
	public void setSite(String sStore) {
		this.site = sStore;
	}
	private boolean checkedThisRule;
	
	public boolean isCheckedThisRule() {
		return checkedThisRule;
	}
	public void setCheckedThisRule(boolean checkedThisRule) {
		this.checkedThisRule = checkedThisRule;
	}
	private String ruleName;
	private String outputField;
	private String outputValue;
	private List<String> conditions;
	private Map<String,String> defaultValues;
	private String skip;
	private String comments;
	//private String defaultOutputValue;

	/*public String getDefaultOutputValue() {
		if(defaultOutputValue==null)
		{
			defaultOutputValue="";
		}
		return defaultOutputValue;
	}
	public void setDefaultOutputValue(String defaultOutputValue) {
		this.defaultOutputValue = defaultOutputValue;
	}*/
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Map<String, String> getDefaultValues() {
		return defaultValues;
	}
	public void setDefaultValues(Map<String, String> defaultValues) {
		this.defaultValues = defaultValues;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public String getOutputField() {
		if(outputField!=null)
			outputField=outputField.trim();
		return outputField;
	}
	public void setOutputField(String outputField) {
		this.outputField = outputField;
	}
	public String getOutputValue() {
		return outputValue;
	}
	public void setOutputValue(String outputValue) {
		this.outputValue = outputValue;
	}
	public List<String> getConditions() {
		if(conditions==null)
			this.conditions  =  new ArrayList<String>();
		return conditions;
	}
	public void setConditions(List<String> conditions) {

		this.conditions  =  new ArrayList<String>();

		for (Iterator<String> iterator = conditions.iterator(); iterator.hasNext();) {
			String string = iterator.next();

			if(string!=null && !string.isEmpty())
			{
				this.conditions.add(string);
			}
		}
	}
	public String getSkip() {
		skip=skip==null?"":skip;
		return skip;
	}
	public void setSkip(String skip) {
		this.skip = skip;
	}



}
