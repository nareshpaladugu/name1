package com.shi.content.ranking.logic;

import java.util.Comparator;

public class ItemSresComparator implements Comparator<GBRankBean>{
	public static final ItemSresComparator TRUE_LOW = new ItemSresComparator(false);
	public static final ItemSresComparator TRUE_HIGH = new ItemSresComparator(true);
	private final boolean trueLow;
	public ItemSresComparator(boolean trueLow) {
	    this.trueLow = trueLow;
	  }
	  public boolean equals(Object obj) {
		    if (this == obj) {
		      return true;
		    }
		    if (!(obj instanceof ItemSresComparator)) {
		      return false;
		    }
		    return (this.trueLow == ((ItemSresComparator) obj).trueLow);
		  }
	  public int hashCode() {
		    return (this.trueLow ? -1 : 1) * getClass().hashCode();
		  }

		  public String toString() {
		    return "ItemSresComparator: " + (this.trueLow ? "true low" : "true high");
		  }
	  
	  
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
	}
		boolean v1 = e1.getSresEligible();
	    boolean v2 = e2.getSresEligible();
	    return (v1 ^ v2) ? ((v1 ^ this.trueLow) ? 1 : -1) : 0;
	}	

}
