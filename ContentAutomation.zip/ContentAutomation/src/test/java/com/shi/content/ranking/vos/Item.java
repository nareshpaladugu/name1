package com.shi.content.ranking.vos;

public class Item {

	private String itemId;
	private String transitDays;
	private Boolean available;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getTransitDays() {
		return transitDays;
	}

	public void setTransitDays(String transitDays) {
		this.transitDays = transitDays;
	}

	public Boolean getAvailable() {
		return available;
	}

	public void setAvailable(Boolean available) {
		this.available = available;
	}

}
