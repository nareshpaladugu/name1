package com.shi.content.varattrs;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;

public class VarAttributeTests {
	
	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp", groups="VarAttributeTestsNew")
	public void testVarAttrs(String sRunParam){
		
		CompareValuesUtility.addToHeaders(new String[]{"UUID","SSIN","UIDOfferCount","UIDOffer","UIDOfferList","UIDisAvail","UIDAttr","UIDAVal","AttrName","AttrSeq","AttrType",
				"AValName","AValSeq","AValFamilyName","PImgSrc","PImgTitle","PImgWidth","PImgHeight","SwatchImgSrc","SwatchImgTitle",
				"SwatchImgWidth","SwatchImgHeight"});
		if(LoadProperties.IS_BUCKETBASED_RUN){
			List<String> lstIdsInBucket = RestExecutor.getIdsForBucket(CollectionValuesVal.VARATTRIBUTE, Integer.parseInt(sRunParam));
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			
			for(String sSSIN : lstIdsInBucket){
				
				if(!(sSSIN.startsWith("sears_") || sSSIN.startsWith("kmart_")))
					continue;
				else{
					pool.execute(new VarAttributeVerifications(sSSIN));
				}
			}
			pool.shutdown();

			try {
				pool.awaitTermination(40, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else if(LoadProperties.IS_LISTBASED_RUN){
			new VarAttributeVerifications(sRunParam).run();
		}else{
			System.out.println("Please set property executionMode");
		}
		
	}
	
}