package com.shi.content.wcsmigration.commons;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ErrorPartReader 
{
	public static List<String> getErrorPartsFromLogFile(String sLogFile)
	{
		List<String> errorParts = new ArrayList<>();

		try
		{
			File f=new File(sLogFile);

			if(f.exists())
			{
				FileInputStream fstream = new FileInputStream(sLogFile);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				int ind,ind2,ind3;
				String part;

				while ((strLine = br.readLine()) != null)   
				{
					try {
						//System.out.println (strLine);
						if(strLine.contains("LogValidation "))
						{
							ind = strLine.indexOf("LogValidation ");
							ind2 = strLine.indexOf(" - ",ind+1);

							ind3= strLine.indexOf(",",ind2+1);

							part = strLine.substring(ind2,ind3).replaceAll(" - ", "").replace(",","");

							//System.out.println(part);
							errorParts.add(part);
						}
						else
						{
							//Assume direct part
							errorParts.add(strLine.trim());
						}
							
					} catch (Exception e) {
						System.out.println("Ingore... this line...");
					}
				}

				in.close();

			}
		}
		catch (Exception e){

			e.printStackTrace();
			System.err.println("Error: " + e.getMessage());
		}

		System.out.println("Error parts size... "+errorParts.size());
		return errorParts;

	}
	
	public static List<String> getUVDErrorPartsFromLogFile(String sLogFile)
	{
		List<String> errorParts = new ArrayList<>();

		try
		{
			File f=new File(sLogFile);

			if(f.exists())
			{
				FileInputStream fstream = new FileInputStream(sLogFile);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				int ind,ind2,ind3;
				String part;

				while ((strLine = br.readLine()) != null)   
				{
					try {
							part = strLine.substring(0,strLine.indexOf("|"));
							errorParts.add(part);
					} catch (Exception e) {
						System.out.println("Ignore... this line...");
					}
				}

				in.close();

			}
		}
		catch (Exception e){

			e.printStackTrace();
			System.err.println("Error: " + e.getMessage());
		}

		System.out.println("Error parts size... "+errorParts.size());
		return errorParts;

	}

}
