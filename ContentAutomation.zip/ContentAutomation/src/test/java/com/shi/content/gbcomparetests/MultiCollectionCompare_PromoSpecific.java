package com.shi.content.gbcomparetests;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

import com.generated.vos.contentbco.Bundle;
import com.generated.vos.offer.Hierarchy;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.counters.PromoCounters;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.listeners.SimpleReporter;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;


/**
 * Utility to compare two greenboxes or two collections.
 * Supports running by buckets and lists. <br>
 * Hits two collections in different gbs and does a document comparison. <br>
 * 
 * <b>Properties being used :</b><br>
 * runParams  - Specify bucket numbers or list of ids<br>
 * collection - collection to test<br>
 * greenvip  - GreenBox 1<br>
 * otherGbBox - Greenbox 2
 * @author nvarsh0
 *
 */
public class MultiCollectionCompare_PromoSpecific implements Runnable 
{	
	String runParam;

	public MultiCollectionCompare_PromoSpecific(String idToTest){
		this.runParam = idToTest;
	}

	public static String fieldsToConsider = null;

	@BeforeGroups(groups="GBToGBCompare_PromoSpecific")
	public void setupHeaders()
	{
		fieldsToConsider = System.getProperty("fieldsToConsider","");
		System.out.println("fieldsToConsider............... "+fieldsToConsider);

		List<String> headers = new ArrayList<>();
		headers.add("Id");
		headers.add("Field");
		headers.add("GB1");
		headers.add("GB2");
		try {
			SimpleReporter.resultsQueue.put(headers);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp",groups="GBToGBCompare_PromoSpecific")
	public void testCompareIds(String sRunParam)
	{

		if(LoadProperties.IS_LISTBASED_RUN)
		{
			Thread runSingleData = new Thread(new MultiCollectionCompare_PromoSpecific(sRunParam));
			runSingleData.start();
			try {
				runSingleData.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		else if(LoadProperties.IS_BUCKETBASED_RUN)
		{

			String collectionToQuery = LoadProperties.collection;

			if(LoadProperties.collection.contains(","))
			{
				String[] collectionsToTest = LoadProperties.collection.trim().split(",");
				collectionToQuery = collectionsToTest[0];
			}

			List<String> lstIdsInBucket = null;
			if(LoadProperties.searchKey.isEmpty()){
				lstIdsInBucket  = RestExecutor.getIdsForBucket(CollectionValuesVal.getCollection(collectionToQuery),Integer.parseInt(sRunParam));
			}else{
				try{
					String[] filter = LoadProperties.searchKey.split("=");
					lstIdsInBucket  = RestExecutor.getFilteredIds(CollectionValuesVal.getCollection(collectionToQuery), Integer.parseInt(sRunParam), filter[0], filter[1]);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			System.out.println("Running for bucket : "+ sRunParam+"  Size "+ lstIdsInBucket.size());
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			
			for(String id : lstIdsInBucket)
			{
				//For promorel store specific 
				if(StringUtils.equalsIgnoreCase(LoadProperties.promorelStoreSpecificCompare, "true") 
						&& !StringUtils.startsWith(id, LoadProperties.promorelStore)){
					continue;
				}
				pool.execute(new MultiCollectionCompare_PromoSpecific(id));
			}

			//System.out.println("Variation ::"+PromoCounters.uniqueVariationParentCount.keySet());
			//System.out.println("Non-Variation ::"+PromoCounters.nonVariationFailedItem.keySet());
			System.out.println("PromoCounters.priceAlrtExclItemCount"+PromoCounters.priceAlrtExclItemCount.get());
			pool.shutdown();

			try {
				pool.awaitTermination(400, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	private boolean isOnline(String promoid, Map<String, String> offerDetails)
	{
		boolean isOnline = false;
		String sOfferId = null;
		String store = null;
		
		StringTokenizer promorelId = new StringTokenizer(promoid, "_");
		//String sOfferId = promoid.substring(promoid.indexOf("_")+1);
		
		try{
			
			while(promorelId.hasMoreTokens() && promorelId.countTokens() == 2){
				store = promorelId.nextToken();
				sOfferId = promorelId.nextToken();
			}
			
			if(sOfferId != null){
				Offer offer = RestExecutor.getDataById(CollectionValuesVal.OFFER,sOfferId);
				if(offer != null){ //Handling Deleted Items
					if(StringUtils.equalsIgnoreCase(offer.getClassifications().getOfferType().name(), "V")){
						offerDetails.put("offerType", "V");
						offerDetails.put("VParent", offer.getIdentity().getParentId());
						if(offer.getPriceDispAttr() != null && offer.getPriceDispAttr().getIsPrcAlrtExcln() != null)
							offerDetails.put("isPrcAlrtExcln", offer.getPriceDispAttr().getIsPrcAlrtExcln().toString());
					}
					
					String storeHier = null;
					if(offer.getTaxonomy().getStore() != null && CollectionUtils.isNotEmpty(offer.getTaxonomy().getStore().getHierarchy())){
						StringBuilder storeHierBuilder = new StringBuilder();
						for(Hierarchy hier : offer.getTaxonomy().getStore().getHierarchy()){
							storeHierBuilder.append(hier.getName());
							storeHierBuilder.append("|");
						}
						storeHier = storeHierBuilder.toString();
						
						offerDetails.put("storeHierar", StringUtils.chomp(storeHier, "|"));
					}
					if(offer.getClassifications() != null && offer.getClassifications().getIsUvd() !=null && offer.getClassifications().getIsUvd()){
						offerDetails.put("uvdType", "uvd");
					}
					//String soldBy = offer.getFfm().getSoldBy();
					
					switch (store.toUpperCase()) 
					{

					case "SEARS":
						try { 	isOnline = offer.getOperational().getSites().getSears().getIsOnline();	} catch (Exception e) { isOnline = false; }
						break;

					case "KMART":
						try { 	isOnline = offer.getOperational().getSites().getKmart().getIsOnline();	} catch (Exception e) { isOnline = false; }
						break;
						
					case "PR":
						try { 	isOnline = offer.getOperational().getSites().getPuertorico().getIsOnline();	} catch (Exception e) { isOnline = false; }
						break;

					case "MYGOFER":case "MYGOFER3":
						try { 	isOnline = offer.getOperational().getSites().getMygofer().getIsOnline();	} catch (Exception e) { isOnline = false; }
						break;

					default:
						break;

					}
				}else if(StringUtils.endsWithIgnoreCase("B", sOfferId)){
					Bundle bundle = RestExecutor.getDataById(CollectionValuesVal.CONTENTBCO,sOfferId);
					if(bundle != null){
						offerDetails.put("bundle", "bundle");
						switch (store.toUpperCase()) 
						{
						
						case "SEARS": case "PR":
							try { 	isOnline = bundle.getOperational().getSites().getSears().getIsDispElig();	} catch (Exception e) { isOnline = false; }
							break;

						case "KMART":
							try { 	isOnline = bundle.getOperational().getSites().getKmart().getIsDispElig();	} catch (Exception e) { isOnline = false; }
							break;

						case "MYGOFER":case "MYGOFER3":
							try { 	isOnline = bundle.getOperational().getSites().getMygofer().getIsDispElig();	} catch (Exception e) { isOnline = false; }
							break;

						default:
							break;

						}
						
					}
				}				
			}
			
		}catch(Throwable thw){
			thw.printStackTrace();
			System.out.println("Excp ::"+promoid);
		}
		
		
		return isOnline;

	}
	public void run()
	{

		String promoid = runParam;//"212502_p";//"214446_p";
		//System.out.println("Testing for "+ promoid);
		String data1, data2;		

		if(LoadProperties.collection.contains(","))
		{
			String[] collectionsToTest = LoadProperties.collection.trim().split(",");
			data1 = RestExecutor.getJSonResponseById(CollectionValuesVal.getCollection(collectionsToTest[0].trim()), promoid);
			data2 = RestExecutor.getJSonResponseById(CollectionValuesVal.getCollection(collectionsToTest[1].trim()), promoid);

		}
		else{
			CollectionValues collectionToTest = CollectionValuesVal.getCollection(LoadProperties.collection);

			data1 = RestExecutor.getJSonResponseById(collectionToTest, promoid);
			URI green2URI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, collectionToTest, promoid);
			data2 = RestExecutor.getJSonResponse(green2URI);
		}
		Map<String, String> offerDetailMap = new HashMap<>();
		boolean bOnline = isOnline(promoid, offerDetailMap);
		try {
			JSONAssert.assertEquals(data1, data2, JSONCompareMode.NON_EXTENSIBLE);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(AssertionError err){


		//	if(bOnline)
			//{
				String msg = err.getMessage();
				List<String> finalResult = new ArrayList<String>();
				//System.out.println(msg);
				String[] allErrs = msg.split(";");
				for(String error : allErrs)
				{
					if(fieldsToConsider==null || fieldsToConsider.isEmpty())
					{
						if(checkInIgnored(error))
							continue;
					}
					else
					{
						if(!checkInRequired(error))
							continue;
					}

					error=error.replaceAll("\\[_bucket=.*?\\]", "");
					error=error.replaceAll(",", ";");
					error=formatError(error);
					error=error+"\n";

					//For first error add id
					if(finalResult.size()==0)
						finalResult.add(promoid);
					finalResult.add(error);
				}

				if(finalResult.size()>0){
					if(bOnline){
						
						PromoCounters.offerOnlineCount.getAndIncrement();
						
						if(offerDetailMap.get("uvdType") != null)
							PromoCounters.uvdItemCount.getAndIncrement();
						if(offerDetailMap.get("bundle") != null)
							PromoCounters.bundleItemCount.getAndIncrement();
						
						String prcAlrtExc = offerDetailMap.get("isPrcAlrtExcln");
						if(StringUtils.equalsIgnoreCase(prcAlrtExc, "true")){
							PromoCounters.priceAlrtExclItemCount.getAndIncrement();
							logPassed(promoid);
							return;
						}
						if(offerDetailMap.get("uvdType") != null || offerDetailMap.get("bundle") != null){
							logPassed(promoid);
							return;
						}
						
						SimpleReporter.logFailed(finalResult);
						PromoCounters.offerOnlineFailCount.getAndIncrement();
						
						String type = offerDetailMap.get("offerType");
						if(StringUtils.equalsIgnoreCase(type, "V")){
							PromoCounters.mismatchVariationItemCount.getAndIncrement();
							PromoCounters.uniqueVariationParentCount.put(offerDetailMap.get("VParent"), "Parent");
						}else{
							PromoCounters.nonVariationFailedItem.put(promoid, "");
						}
						
						if(offerDetailMap.get("uvdType") == null){
							if(offerDetailMap.get("storeHierar") != null){
								AtomicInteger count = PromoCounters.hieraritemGroupings.get(offerDetailMap.get("storeHierar"));
								if(count != null){
									count.getAndIncrement();
								}else{
									count = new AtomicInteger();
									count.getAndIncrement();
								}
								PromoCounters.hieraritemGroupings.put(offerDetailMap.get("storeHierar"), count);
							}
						}
						
					}else{
						PromoCounters.offerOfflineFailCount.getAndIncrement();
						PromoCounters.offerOfflineCount.getAndIncrement();
						logPassed(promoid);
					}					
				}
				else{
					if(!bOnline){
						PromoCounters.offerOfflinePassCount.getAndIncrement();
						PromoCounters.offerOfflineCount.getAndIncrement();
					}else{
						PromoCounters.offerOnlineCount.getAndIncrement();
						PromoCounters.offerOnlinePassCount.getAndIncrement();
					}
					logPassed(promoid);
				}

				return;
			//}
		}
		if(!bOnline){
			PromoCounters.offerOfflinePassCount.getAndIncrement();
			PromoCounters.offerOfflineCount.getAndIncrement();
		}else{
			PromoCounters.offerOnlineCount.getAndIncrement();
			PromoCounters.offerOnlinePassCount.getAndIncrement();
		}
		logPassed(promoid);
	}

	/**
	 * Method to check if field name contains any of the values in the ignored list
	 * Returns true if it is an ignored error, false otherwise
	 * @param error
	 * @return
	 */
	private boolean checkInIgnored(String error) {
		for(String ignoredError : LoadProperties.IGNORED_FAILURES){
			if(!ignoredError.isEmpty() && error.contains(ignoredError))
				return true;
		}
		return false;

	}

	private boolean checkInRequired(String error) 
	{
		for(String requiredFields : fieldsToConsider.split(","))
		{
			if(!requiredFields.isEmpty() && error.contains(requiredFields))
				return true;
		}
		return false;

	}

	/**
	 * Formats the error line.  Splits the lines into csvs
	 * @param error
	 * @return
	 */
	private String formatError(String error){
		String[] splitData = error.split("\n");
		String finalError = "";

		if(splitData.length == 3 && splitData[1].contains("Unexpected")){
			finalError =  splitData[0]+",,"+ splitData[1];
		}else if(splitData[0].matches(".Expected \\d+ values but got \\d+")){
			String[] furtherSplits = splitData[0].split("Expected");
			String[] expActuals = furtherSplits[1].split("but");
			finalError =  furtherSplits[0]+","+expActuals[0]+","+ expActuals[1];
		}
		else{
			for(int i=0; i< splitData.length; i++ ){
				splitData[i] = splitData[i].trim();
				if(splitData[i].startsWith("Expected:"))
					splitData[i] = splitData[i].replaceAll("Expected.*?:", "");
				else if(splitData[i].startsWith("got:"))
					splitData[i] = splitData[i].replaceAll("got.*?:", "");
				finalError = finalError +  splitData[i]+ ",";
			}
		}
		return finalError;
	}

	/**
	 * Add PromoId to passed list
	 * @param promoId
	 */
	private void logPassed(String promoId){
		//System.out.println("Id "+ promoId + " Passed");
		List<String> passedResult = new ArrayList<String>();
		passedResult.add(promoId);
		passedResult.add("Passed");
		SimpleReporter.logPassed(passedResult);
	}

}
