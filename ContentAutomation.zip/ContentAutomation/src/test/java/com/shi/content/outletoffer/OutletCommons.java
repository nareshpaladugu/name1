package com.shi.content.outletoffer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import com.shc.autocontent.LoadProperties;
import com.shc.content.restutils.RestExecutor;

public class OutletCommons {
	
	public Map<String, String> storeMap = new HashMap<String, String>();
	public String storeUrl = "http://" + LoadProperties.OTHERGBBOX + "/gbox/gb/s/data/get/store/";

	public OutletCommons() {
	}
	
	public String getStrType(String unitNumber) {
		
		if(storeMap.get(unitNumber)!=null){
			//System.out.println("Getting strType from storeMap...");
			return storeMap.get(unitNumber);
		}else{
			//System.out.println("Getting strType from store GB...");
			//String strType = RestExecutor.getSpecificValueFromJson(CollectionValuesVal.STORE, unitNumber, "[{_blob{unit{strType2}}}]");
			String strType;
			try {
				strType = RestExecutor.getSpecificValueFromJson(new URI(storeUrl+unitNumber), "[{_blob{unit{strType2}}}]");
				storeMap.put(unitNumber, strType);
				return strType;
			} catch (URISyntaxException e) {
				e.printStackTrace();
				return null;
			}
		}
	}
}
