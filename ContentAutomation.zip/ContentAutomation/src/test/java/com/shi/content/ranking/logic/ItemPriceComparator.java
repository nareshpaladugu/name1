package com.shi.content.ranking.logic;

import java.util.Comparator;

public class ItemPriceComparator implements Comparator<GBRankBean>{
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
		}
		
		//System.out.println("ItemPriceComparator.............."+ e1.getPrice() +" <-> "+ e2.getPrice());
		Float price1 = e1.getPrice()==0.0?Float.MAX_VALUE:e1.getPrice();
		Float price2 = e2.getPrice()==0.0?Float.MAX_VALUE:e2.getPrice();
		return price1.compareTo(price2);
		
		//return e1.getPrice().compareTo(e2.getPrice());
	}

}
