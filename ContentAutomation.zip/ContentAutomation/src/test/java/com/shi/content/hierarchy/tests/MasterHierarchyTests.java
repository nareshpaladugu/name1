package com.shi.content.hierarchy.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.masterhierarchy.Node;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class MasterHierarchyTests {

	
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="MasterHierarchyTests")
	public void testMasterHierarchyFeed(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Node>> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Node>>(); 
		
		HierarchyCommons hierarchyUtils = new HierarchyCommons(sFileName);

		// Start producer thread to produce nodes
		ChunkProducerThread<Node> prodThread = new ChunkProducerThread<Node>(sFileName, masterHierarchyNodeQueue, Node.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Node> nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null)
					pool.execute(new MasterHierarchyVerifications(nodeToTest,hierarchyUtils));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
