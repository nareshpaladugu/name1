package com.shi.content.kafkautils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaProducer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class GBBasedProducer {
	static int count;

	@Test(groups="MPMassProducer")
	public void gbBasedProducer(){
		
		String format = LoadProperties.KAFKA_MSG_FORMAT;
		
		System.out.println("Format is "+ format);
		/*String format = "{\"header\": {\"schemaVer\": \"Version1\",\"schemaLoc\": " +
				"\"sample schema Loc\",\"modifiedTs\": \"Wed Oct 01 17:02:01 PDT 2014\"},\"storeSopt\": " +
				"[{\"sellerId\": 5253,\"locationId\": 2,\"sopt\": [{\"itemId\": @P1@,\"variationGroupId\": " +
				"\"123445\",\"programType\": \"@ProgramType@\",\"standardOrderProcessingTimeinSeconds\": 100000," +
				"\"orderPrepTimeInSeconds\": 100000}]}]}";*/
		

		
//		String getcall = "filter-ids";
		count = Integer.parseInt(LoadProperties.RUN_PARAMS);
//		String filterType = "pgrmType";
		String FBM = "FBM";
		String FBS = "FBS";
		String DSS = "DSS";
//		String values = "_blob.offer.altIds.spinId";
		
		List<String> lstFBMIds = new ArrayList<String>();
		List<String> lstFBSIds = new ArrayList<String>();
		List<String> lstDSSIds = new ArrayList<String>();
		Map<String, List<String>> mpItems = new HashMap<>();
		mpItems.put(FBM, lstFBMIds);
		mpItems.put(FBS, lstFBSIds);
		mpItems.put(DSS, lstDSSIds);
		
		
		
		int iBucket = 0;
		int currentSize = 0;
		
		while(true){
			
			int i = this.createData(mpItems, DSS, currentSize, iBucket);
			if(i != -1){
				currentSize +=i;
			}else{
				break;
			}
			
			i = this.createData(mpItems, FBS, currentSize, iBucket);
			if(i != -1){
				currentSize +=i;
			}else{
				break;
			}
			
			i = this.createData(mpItems, FBM, currentSize, iBucket++);
			if(i != -1){
				currentSize +=i;
			}else{
				break;
			}
			
		}
		
		
		KafkaProducer kProd = new KafkaProducer();
		
		Map<String, Long> idToTS = new HashMap<String, Long>();
		
		for(String type : mpItems.keySet()){
			List<String> lstIds = mpItems.get(type);
			
			for(String id : lstIds){
				System.out.println("For id "+ id);
				
				//For FBM and DSS, remove SPM from id
				String itemId = id;
				if(!type.equals("FBS"))
					itemId =  id.replace("SPM", "");
				
				//Replace id and programType in standard message
				String msg = format.replace("@P1@", itemId);
				msg = msg.replace("@ProgramType@", type);
				
				long lsentTS = kProd.publishMessage(msg);
				idToTS.put(id, lsentTS);
					
			}
		}
		kProd.shutdownProducer();
		
		
		//TODO :: Remove this hardcoded sleep
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		String getProcessingTime = JsonStringParser.getJsonValueNew(format, "storeSopt.sopt.standardOrderProcessingTimeinSeconds");
		Double processingTime = Double.parseDouble(getProcessingTime);
		System.out.println("Processing time is "+ processingTime);
		
		//Verify timestamp
		for(String type : mpItems.keySet()){
			List<String> lstIds = mpItems.get(type);
			
			for(String id : lstIds){
				CompareValuesUtility.init();
				Offer s = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);
				System.out.println(s.getShipping().getSoptDays());
				System.out.println(s.getMeta().getModifiedTs());
				
				String insertDate = getDate(idToTS.get(id), "yyyy-MM-dd HH:mm:ss.SSS");
				CompareValuesUtility.compareValues("Sopt",Math.ceil((processingTime/(24*3600))),s.getShipping().getSoptDays()+"");
				CompareValuesUtility.addDataFieldForReport("Insertime",insertDate );
				CompareValuesUtility.addDataFieldForReport("GBTime", s.getMeta().getModifiedTs());
				
				DateTime dtGBTime = JodaDateTimeUtility.convertToJodaFormat(s.getMeta().getModifiedTs());
				DateTime dtInsertTime = JodaDateTimeUtility.convertToJodaFormat(insertDate);
				
				if(dtGBTime == null)
					CompareValuesUtility.addDataFieldForReport("Difference(ms)", "No modified ts in gb");
				else
					CompareValuesUtility.addDataFieldForReport("Difference(ms)", (dtGBTime.getMillis() - dtInsertTime.getMillis())+"");
				
	//			System.out.println(s.getMeta().getModifiedTs());
				CompareValuesUtility.setupResult(id, true);
			}
		}
		
	}
	
	public int createData(Map<String, List<String>> mp, String type, int currentSize, int iBucket){
		List<String> lstCommon = RestExecutor.getFilteredIds(CollectionValuesVal.OFFER, iBucket, "pgrmType", type);
		if(currentSize+ lstCommon.size() > count ){
			int toSizeTo = count - currentSize;
			lstCommon = lstCommon.subList(0, toSizeTo);
			mp.get(type).addAll(lstCommon);
			return -1;
			//trim lstCommon and add to corresponding
		}
		mp.get(type).addAll(lstCommon);
		return lstCommon.size();
	}
	
	public static String getDate(long milliSeconds, String dateFormat)
	{
	    // Create a DateFormatter object for displaying date in specified format.
	    SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	    formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
	    
	    // Create a calendar object that will convert the date and time value in milliseconds to date. 
	     Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("US/Central"));
	     calendar.setTimeInMillis(milliSeconds);
	     return formatter.format(calendar.getTime());
	}
	
}
