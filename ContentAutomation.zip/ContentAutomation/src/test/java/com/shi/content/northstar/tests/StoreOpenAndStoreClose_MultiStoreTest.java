package com.shi.content.northstar.tests;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shc.content.webdriver.assertions.DriverLogger;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * To test if user is able to Open and close Multiple Stores
 * @author inaikwa
 *
 */
public class StoreOpenAndStoreClose_MultiStoreTest extends NorthStarBaseTest {
	final static String STORECLOSEREASON = "In Liquidation";
	private int noOfStoresToSelect=2;
	private ArrayList<String> listStoreIds;
	
	DriverLogger logger = new DriverLogger();
	
	@Test(description="Multi view Test store closing and opening", groups="NS-P1")
	public void testStoreStateChange(){
		
		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();


		searchPage.searchByZipCode("01040");
		listStoreIds = searchPage.getAllSearsOpenNonICEEStores();
	
//		Kmart
//		searchPage.searchByDistrict("40761");
//		listStoreIds = searchPage.getAllKmartOpenStores();
		
		Asserts.verifyNotNull(listStoreIds.size(), "Verifed required storeIds found.");
		
		Assert.assertNotNull(listStoreIds.size(), listStoreIds.size()+ " =: Zero stores found, terminating......... ");
		
		Assert.assertNotEquals(1, listStoreIds.size()+ " =: Only one store found but multiple stores needed to test hence terminating......... ");
			
		searchPage.selectStore(listStoreIds,noOfStoresToSelect);
		
		searchPage.searchPageCloseStore();
	
		EditStoreDetails eView = new EditStoreDetails();
		
		eView.closeStoreMultiView();
		
		Asserts.verifyTrue(eView.closeStoreSuccessMsg(), "Verified that the Close Store success msg is displayed after closing store" );
	
		for(int i = 0 ;i <noOfStoresToSelect;i++){
			logger.log("Verifying store status for store : "+listStoreIds.get(i), false);
			String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,listStoreIds.get(i)); 
			String strCloseStatus =  JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strStatus", false);
			String strClsReason = JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strClsReason", false);
			Asserts.verifyEquals("0", strCloseStatus,"Verify store status is closed in strStatus");
			
			strCloseStatus = JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strStatus", false);
			Asserts.verifyEquals("0", strCloseStatus,"Verified strStatus is 0 (closed)");
			Asserts.verifyEquals(STORECLOSEREASON, strClsReason,"Verified strClsReason is "+ strClsReason);
		}
		
		// Opening the store
		
		eView.openStoreMultiView(listStoreIds);
		
	
		for(int i = 0 ;i <noOfStoresToSelect;i++){
			logger.log("Verifying store status for store : "+listStoreIds.get(i), false);
			String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,listStoreIds.get(i)); 
			Asserts.verifyNull( JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strClsReason").equals("null")?null:JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strClsReason"),"Verified strClsReason tag is not displayed ");
			Asserts.verifyEquals("1", JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strStatus").replaceAll("\"", ""),"Verified _search.strStatus is 1 (Open) in _search.strStatus");

		}
		

	}
}
