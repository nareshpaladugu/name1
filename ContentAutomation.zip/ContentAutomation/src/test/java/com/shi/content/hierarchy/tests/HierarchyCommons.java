package com.shi.content.hierarchy.tests;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.NodeList;

import com.generated.vos.hierarchy.Hierarchy;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.DOMParserImpl;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class HierarchyCommons {
	
	
	private DOMParserImpl domParser;
	static final String SEPARATOR = "|";
	private String catalogid = figureOutCatalogId("def");
	
	public HierarchyCommons(String sFileName){
		domParser = new DOMParserImpl(sFileName);
	}
	
	public HierarchyCommons(String sFileName, String sCatalogid){
		domParser = new DOMParserImpl(sFileName);
		this.catalogid = sCatalogid;
	}
		
	public String fetchCatGroupId(long nodeId){
		
		Hierarchy gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, String.valueOf(nodeId))	;
		return gbHierarchy.getCid();
		/*return DB2Utils.executeQuerySingleResult("select CATGROUP_ID_CHILD from XCATGROUPPATH where CATGROUP_ID_child" +
				" IN (select catgroup_id from CATGROUP where identifier like '"+String.valueOf(nodeId)+"') and CATALOG_ID = "+catalogid);*/
	}
	
	public String fetchCatGroupId(String name){
		Hierarchy gbHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, String.valueOf(name))	;
		return gbHierarchy.getCid();
		/*return DB2Utils.executeQuerySingleResult("select CATGROUP_ID_CHILD from XCATGROUPPATH where CATGROUP_ID_child" +
				" IN (select catgroup_id from CATGROUP where identifier like '"+name+"') and CATALOG_ID = "+catalogid);*/
	}
	
	/**
	 * Fetch parent catgroup id from catgrprel table
	 * @param catgroupId
	 * @param isPrimary
	 * @return
	 */
	public List<String> fetchParentCatgroupId(String catgroupId, boolean isPrimary){
		if(isPrimary)
			return DBUtil.executeQuerySingleColMulRow("select CATGROUP_ID_PARENT from CATGRPREL where CATGROUP_ID_CHILD ="+catgroupId+" AND (RULE IS NULL OR RULE='PRIMARY') and CATALOG_ID = "+catalogid);
		else 
			return DBUtil.executeQuerySingleColMulRow("select CATGROUP_ID_PARENT from CATGRPREL where CATGROUP_ID_CHILD ="+catgroupId+" and rule='SECONDARY' and catalog_id = "+ catalogid);
	}
	
	/**
	 * Returns catgroup id of parent
	 * @param sNodeId
	 * @return
	 */
	public String fetchParentFromIdentifier(String sNodeId){
		return DBUtil.executeQuerySingleResult("select CATGROUP_ID_PARENT from CATGRPREL where CATGROUP_ID_CHILD in " +
				"(select catgroup_id from catgroup where IDENTIFIER like '"+sNodeId+"'");
	}
	
	
	

	/**
	 * Returns whether current node is a leaf node by parsing the xml
	 * @param sNodeId - Node id to verify
	 * @param isMaster - Set to true if master hierarchy is being verified
	 * @return 
	 */
	public boolean isLeafNode(long sNodeId, boolean isMaster){
		String sXpath;
		String lXpath;
		
		if(isMaster){
			sXpath = "/taxonomy/node/parent-node-id[text()='"+sNodeId+"']";
			lXpath = "/dummy/parent-node-id[text()='"+sNodeId+"']";
		}
		else{
			sXpath = "/web-hierarchies/primary-nodes/node/parent-node-id[text()='"+sNodeId+"']";
			lXpath = "/web-hierarchies/link-nodes/node/parent-node-id[text()='"+sNodeId+"']";
		}
		
		NodeList primNodesFound = domParser.parseAsDOMCached(sXpath);
		NodeList linkNodesFound = domParser.parseAsDOMCached(lXpath);
		
		if(primNodesFound.getLength() > 0)
			return false;
		else
			if(!isMaster && linkNodesFound.getLength() > 0)
				return false;
			else
				return true;
	}
	
	
	private String fetchParentIdFromXML(String sID, boolean isMasterHierarchy){
		List<String> lstParents = this.fetchParentIdsFromXML(sID, isMasterHierarchy, true);
		return lstParents.get(0);
	}
	
	/**
	 * Returns CID Path - fetching from wcs as of now
	 * @param sNodeId
	 * @return
	 */
	public String fetchPrimaryCIDPath(long lNodeId){
		String sCatgroupId = this.fetchCatGroupId(lNodeId);
//		String sCIDPath = SEPARATOR+sCatgroupId;
		String sCIDPath = sCatgroupId;
		String sParentCatId = sCatgroupId;
		while(true){
			//Fetch parent of the base catgroup id.  If null, then no parents
			List<String> lstParentIds = this.fetchParentCatgroupId(sParentCatId, true);
			if(lstParentIds == null)
				break;
			sParentCatId = lstParentIds.get(0);
			if(sParentCatId == null)
				break;
			
			sCIDPath = sParentCatId+SEPARATOR+sCIDPath;
		}
		return sCIDPath;
	}
	
	/**
	 * Parses dom to find parent-node id of current id recursively in nodes/primary nodes based on whehter it is master or web hierarchy
	 * and forms the IDPath
	 * eg.  
	 * @param lID - id for which parent node id is being searched for
	 * @param isMasterHierarchy - set to true for master hierarchy and false for web hierarchy
	 * @return
	 */

	public String formPrimaryIdPath(long lID,boolean isMasterHierarchy){
		String sID1 = String.valueOf(lID);
		String sIdPath = String.valueOf(lID);
		while(true){
			String sParent = fetchParentIdFromXML(sID1, isMasterHierarchy);
			if(sParent.equals("0"))
				return sIdPath;
			else{
				sID1 = sParent;
				sIdPath = sID1+ SEPARATOR+sIdPath;
			}
		}
	}
	
	/**
	 * Fetch parent ids of given node id from xml
	 * @param sID - id for which parent needs to be fetched
	 * @param isMaster - true if master hierarchy is being tested
	 * @param isAll - true if all parents need to be fetched, else only secondary link nodes will be fetched
	 * @return
	 */
	
	public List<String> fetchParentIdsFromXML(String sID,boolean isMaster, boolean isAll){
//		long l1 = System.currentTimeMillis();
		String sXpath;
		if(isMaster)
			sXpath = "/taxonomy/node[@id='"+sID+"']/parent-node-id";
		else{
			if(isAll) //all parents are returned
				sXpath = "//node[@id='"+sID+"']/parent-node-id";
			else //only secondary
				sXpath = "/web-hierarchies/link-nodes/node[@id='"+sID+"']/parent-node-id";
		}
		
		List<String> lstParentIds = new ArrayList<String>();
		if(isAll && !isMaster){
			NodeList nodesFound = domParser.parseAsDOMCached("/web-hierarchies/primary-nodes/node[@id='"+sID+"']/parent-node-id");
			lstParentIds.addAll(addNodeListToList(nodesFound));
			nodesFound = domParser.parseAsDOMCached("/web-hierarchies/link-nodes/node[@id='"+sID+"']/parent-node-id");
			lstParentIds.addAll(addNodeListToList(nodesFound));
			
		}else{
		
			NodeList nodesFound = domParser.parseAsDOMCached(sXpath);
			lstParentIds = addNodeListToList(nodesFound);
		}
//		long l2 = System.currentTimeMillis();
//		System.out.println("Time fetchParentIdsFromXML "+ (l2-l1)/1000);
		return lstParentIds;
	}
	
	private List<String> addNodeListToList(NodeList nodesFound){
		List<String> lstParentIds = new ArrayList<String>();
		if(nodesFound.getLength() == 0){
//			lstParentIds.add("0");
			return lstParentIds;
		}
		else{
		for(int i = 0; i< nodesFound.getLength(); i++){
			lstParentIds.add(nodesFound.item(i).getTextContent());
		}
		return lstParentIds;
	}
	}

	/**
	 * Fetch the name of a node from the web hierarchy xml
	 * @param sID
	 * @return
	 */
	public String fetchNameFromXML(String sID){
//		long l1 = System.currentTimeMillis();
		String sXpath = "/web-hierarchies/primary-nodes/node[@id='"+sID+"']/name";
		NodeList nodesFound = domParser.parseAsDOMCached(sXpath);
		if(nodesFound.getLength() == 0){
			if(checkRetiredNode(sID))
				return "Retired";
		}
//		long l2 = System.currentTimeMillis();
//		System.out.println("Fetchname : "+ (l2 - l1));
		return nodesFound.item(0).getTextContent();
	}
	
	private boolean checkRetiredNode(String sID){
		System.out.println("Checking retired node");
		String sXpath = "/web-hierarchies/retired-nodes/retired-node[@id='"+sID+"']";
		NodeList nodesFound = domParser.parseAsDOMCached(sXpath);
		if(nodesFound.getLength() == 0)
			return false;
		else
			return true;
	}
	
	/**
	 * Fetches the tree of paths of a hiearchy node
	 * eg.<br>
	 * 
	 * 	P1P &nbsp;&nbsp;  P1P2&nbsp;&nbsp;	   P2P1	&nbsp;&nbsp;	P2P2<br>
	 *	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	P1&nbsp;&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P2 <br>
	 *	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;A <br>
	 *
	 * The above would return 4 paths for node A
	 * @param sID
	 * @return
	 */
	
	public List<List<String>> fetchAllPaths(String sID){
		List<String> paths = new ArrayList<String>();
		List<String> displayPaths = new ArrayList<String>();
		List<String> catIdPaths = new ArrayList<String>();
		List<List<String>> pathDetails = new ArrayList<List<String>>();
		
		for(String sParent : fetchParentIdsFromXML(sID,false,true)){
			String currentname = null, sCatId = null;
			if(!sID.equals("0")){
				currentname = fetchNameFromXML(sID);
				sCatId = fetchCatGroupId(sID);
			}
			if(sParent.equals("0")|| currentname.equals("Retired")){
				paths.add(sID);
				displayPaths.add(currentname);
				catIdPaths.add(sCatId);
				continue;
			}
			List<List<String>> allPaths = fetchAllPaths(sParent);
			List<String> pPaths = allPaths.get(0);
			List<String> pdPaths = allPaths.get(1);
			List<String> cidPaths = allPaths.get(2);
			
			for(int i=0; i< pPaths.size();i++){//String sPath :fetchPath(sParent)){
				paths.add(pPaths.get(i)+SEPARATOR+ sID);
				displayPaths.add(pdPaths.get(i)+ SEPARATOR+currentname );
				catIdPaths.add(cidPaths.get(i)+ SEPARATOR+sCatId );
			}
		}
		
		pathDetails.add(paths);
		pathDetails.add(displayPaths);
		pathDetails.add(catIdPaths);
		return pathDetails;
	}
	
	
	static String figureOutCatalogId(String sSiteId){
		switch(sSiteId){
		case "2":{
			return "12605";
		}
		case "1":{
			return "10104";
		}
		case "4":{
			return "27151";
		}
		case "5":{
			return "12604";
		}
		case "6":{
			return "12602";
		}
		case "7":{
			return "16601";
		}
		case "8":{
			return "23151";
		}
		case "11":{
			return "26151";
		}
		case "2_STORE":{
			return "12609";
		}
		case "1_STORE":{
			return "10105";
		}
		default:{
			return "21101";
		}
		}
	}
	
	/*public class Path{
		String sCIDPath;
		String sIDPath;
		String sDisplayPath;
		Path(String sIDPath, String sCIDPath, String sDisplayPath){
			this.sIDPath = sIDPath;
			this.sCIDPath = sCIDPath;
			this.sDisplayPath = sDisplayPath;
			
		}
	}*/
	
	/**
	 * Returns whether node is leaf node or not
	 * @param sNodeId
	 * @return
	 */
	/*public boolean isLeafNode(long sNodeId){
		//If from gb, do db query to check if it is parent node id to any other node
		
//		BasicDBObject dbObj = new BasicDBObject();
//		dbObj.put("_blob.hierarchy.parentIds", sNodeId);
//		if(GBUtils.getCount(dbObj, CollectionValues.HIERARCHY) == 0)
//			return true;
//		
		//from xml
		//xpath - "//primary-nodes//parent-node-id[@id='"+sNodeId+"']"
		String sXpath = "//primary-nodes//parent-node-id[text()='"+sNodeId+"']";
		NodeList nodesFound = domParser.parseAsDOM(sXpath);
		if(nodesFound.getLength() > 0)
			return false;
		else return true;
		
		
		//If from wcs, 
		String sCount = DB2Utils.executeQuerySingleResult("select count from CATGRPREL where CATGROUP_ID_PARENT in " +
				"(select catgroup_id from catgroup where IDENTIFIER like '"+sNodeId+"'");
		if(Integer.parseInt(sCount) == 0)
			return true;
		else
			return false;
	}*/
	
	/**
	 * Parses dom to find parent-node id of current id recursively in primary nodes and forms the IDPath
	 * eg.  
	 * @param sID
	 * @param sFileName
	 * @return
	 */
	/*public String formWebPrimaryIdPath(long sID){
		String sID1 = String.valueOf(sID);
		String sXpath = "//primary-nodes/node[@id='"+sID1+"']/parent-node-id";
		String sIdPath = String.valueOf(sID);
		while(true){
			NodeList nodesFound = domParser.parseAsDOM(sXpath);
			if(nodesFound.getLength() == 0 || nodesFound.item(0).getTextContent().equals("0"))
				return sIdPath;
			else{
				sID1 = nodesFound.item(0).getTextContent();
				sXpath = "//primary-nodes/node[@id='"+sID1+"']/parent-node-id";
				sIdPath = sID1 +"|"+sIdPath;
			}
		}
	}
	
	/**
	 * Parses dom to find parent-node id of current id recursively and forms the IDPath
	 * eg.  
	 * @param sID
	 * @param sFileName
	 * @return
	public String formIdPath(long sID){
//		long l1 = System.currentTimeMillis();
		String sXpath = "/taxonomy/node[@id='"+sID+"']/parent-node-id";
		
		String sIdPath = "/"+String.valueOf(sID);
		String sID1;
		while(true){
			NodeList nodesFound = domParser.parseAsDOMCached(sXpath);
			if(nodesFound.getLength() == 0 || nodesFound.item(0).getTextContent().equals("0")){
//				long l2 = System.currentTimeMillis();
//				System.out.println("Time formIdPath "+ (l2-l1)/1000);
				return sIdPath;
			}
			else{
				sID1 = nodesFound.item(0).getTextContent();
				sXpath = "/taxonomy/node[@id='"+sID1+"']/parent-node-id";
				sIdPath = "/"+nodesFound.item(0).getTextContent() +sIdPath;
			}
		}
	}
	
	/**
	 * Return primary parent from gb db
	 
	public String fetchPrimaryParentGB(long sNodeId){
		BasicDBObject dbObj = new BasicDBObject();
		dbObj.put("_blob.hierarchy.id", String.valueOf(sNodeId));
		dbObj.put("_blob.hierarchy.type", "master");
		dbObj.put("_blob.hierarchy.parentIds.isPrimary", "true");
		HierarchySchema h =(HierarchySchema)GBUtils.getSpecificValue(dbObj, CollectionValues.HIERARCHY, "_blob.hierarchy.parentIds.id.$");
		return String.valueOf(h.getParentIds().get(0).getId());
		
	}
	*
	*/
}
