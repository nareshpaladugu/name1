package com.shi.content.promos.phase2;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.promokafka.PromoKafka;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;


public class PromoKafkaTestPhase2 {

	@Test
	public void testSHCStaticLoad() throws Exception {

		BlockingQueue<List<PromoKafka>> iaPromoDocs = new LinkedBlockingQueue<List<PromoKafka>>();

		KafkaIAConsumer<PromoKafka> prodThread = new KafkaIAConsumer<PromoKafka>(PromoKafka.class,iaPromoDocs);		
		Thread t = new Thread(prodThread);
		t.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<PromoKafka> nodeToTest;

				nodeToTest = iaPromoDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new PromoKafkaLoadLogic(nodeToTest.get(0).getPromo()));
				//	System.out.println("nodeToTest : "+nodeToTest.get(0).getPromo().getPromoId());
					
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();	}
}
