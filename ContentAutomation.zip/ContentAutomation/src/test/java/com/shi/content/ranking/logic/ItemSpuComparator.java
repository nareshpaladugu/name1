package com.shi.content.ranking.logic;

import java.util.Comparator;

public class ItemSpuComparator implements Comparator<GBRankBean>{
	public static final ItemSpuComparator TRUE_LOW = new ItemSpuComparator(false);
	public static final ItemSpuComparator TRUE_HIGH = new ItemSpuComparator(true);
	private final boolean trueLow;
	public ItemSpuComparator(boolean trueLow) {
	    this.trueLow = trueLow;
	  }
	  public boolean equals(Object obj) {
		    if (this == obj) {
		      return true;
		    }
		    if (!(obj instanceof ItemSpuComparator)) {
		      return false;
		    }
		    return (this.trueLow == ((ItemSpuComparator) obj).trueLow);
		  }
	  public int hashCode() {
		    return (this.trueLow ? -1 : 1) * getClass().hashCode();
		  }

		  public String toString() {
		    return "ItemSpuComparator: " + (this.trueLow ? "true low" : "true high");
		  }
	  
	  
	public int compare(GBRankBean e1, GBRankBean e2) {
		if (e1 == null || e2 == null) {
			throw new NullPointerException("compareTo: Argument passed is null");
	}
		boolean v1 = e1.getSpuEligible();
	    boolean v2 = e2.getSpuEligible();
	    return (v1 ^ v2) ? ((v1 ^ this.trueLow) ? 1 : -1) : 0;
	}	

}
