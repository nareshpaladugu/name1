package com.shi.content.urlredirect;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySqlDatabase 
{
	public static final String MYSQL_PROTOCOL = "mysql";

	public static final String JDBC_PROTOCOL = "jdbc";

	private Connection connection;

	public static final String MYSQL_DRIVER = "com.mysql.jdbc.Driver";

	private String protocol;
	private String subprotocol;
	private String host;
	private int port;
	private String name;
	private String user;
	private String password;

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getSubprotocol() {
		return subprotocol;
	}

	public void setSubprotocol(String subprotocol) {
		this.subprotocol = subprotocol;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Connection getDBConnection() 
	{
		String host = System.getProperty("mysqlhost","dbsadmq.qa.ch3.s.com");
		int port =  Integer.parseInt(System.getProperty("mysqlport","3306"));
		String name =  System.getProperty("mysqldbname","siteadm");
		String user =  System.getProperty("mysqluser","batchqa");
		String password	=  System.getProperty("mysqlpassword","sears123");
		
		return getConnection(host,port,name,user,password);
		
		//return getConnection("dbincubate.dev.ch3.s.com",3306,"content_dev","vmaligi","sears0921");
	}
	public Connection getConnection(String host, int port, String name, String user, String password) 
	{
		this.name = name;
		this.user = user;
		this.password = password;
		this.protocol = JDBC_PROTOCOL;
		this.subprotocol = MYSQL_PROTOCOL;
		this.host = host;
		this.port = port;
		this.connection = createConnection();
		
		return this.connection;
	}
	
	//Connection Methods
	private Connection createConnection() {
		try {
			Class.forName(MYSQL_DRIVER).newInstance();

			return DriverManager.getConnection(getConnectionURL());
		} catch (Exception exp) {
			System.out.println("exp "+exp);
			return null;}
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	private String getConnectionURL() throws Exception {
		return getProtocol() + ":" + getSubprotocol() + "://" + getHost() + ":" + getPort() + "/" + getName() +"?user="+user+"&password="+password;
	}
}
