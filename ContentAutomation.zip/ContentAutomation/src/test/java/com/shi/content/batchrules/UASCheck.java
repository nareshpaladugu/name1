package com.shi.content.batchrules;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class UASCheck 
{
	/**
	 * This method hits UAS service and checks for shipAvail=false and pickupAvail=false condition
	 * @param sOfferId
	 * @return
	 */
	public static boolean checkUASResponse(String sOfferId,String sStore)
	{
		try {

			String sURL = null;

			if(sStore!=null && (sStore.equalsIgnoreCase("pr")||sStore.equalsIgnoreCase("puertorico")))
			{
				sURL = System.getProperty("UAS_URL_PR","http://uasvip.prod.ch4.s.com:80/uasserver/uas/availability/v3/pr");
			}
			else
			{
				sURL = System.getProperty("UAS_URL","http://uasvip.prod.ch4.s.com:80/uasserver/uas/availability/v3");
			}

			String sRequestBody = "{\"items\":[\""+sOfferId+"\"]}";

			String sResponse = RestExecutor.postForJSonResponse(sURL, sRequestBody);
			Gson g = new Gson();

			JsonObject jobj = g.fromJson(sResponse, JsonObject.class).get("itemMap").getAsJsonObject().get(sOfferId).getAsJsonObject();

			String shipAvail = jobj.get("shipAvail").getAsString();

			String pickupAvail =  jobj.get("pickupAvail").getAsString();

			if(shipAvail.equalsIgnoreCase("false") && pickupAvail.equalsIgnoreCase("false") )
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (JsonSyntaxException e) {

			System.out.println("UASCheck check() exception .. "+e.getMessage()+ " Offer"+sOfferId+" Store : "+sOfferId);
			return false;
		}

	}

	/*public static void main(String[] args) {

		BufferedReader br = null;

		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader("C:\\Users\\ddaphal\\Desktop\\a.txt"));

			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
				if(!checkUASResponse(sCurrentLine))
				{
					System.out.println("================>"+sCurrentLine);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}*/
}
