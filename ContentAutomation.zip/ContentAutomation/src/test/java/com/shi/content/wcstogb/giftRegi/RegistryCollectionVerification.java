package com.shi.content.wcstogb.giftRegi;

import java.util.List;
import java.util.Map;

import com.generated.vos.gr.registry.ItemPurchaseMailPartNumberList;
import com.generated.vos.gr.registry.MessageDetail;
import com.generated.vos.gr.registry.OosMailPartNumberList;
import com.generated.vos.gr.registry.RegistryCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;

public class RegistryCollectionVerification implements Runnable
{
	private Map<String,String> mapGRGFTREG;

	private String sGiftRegistryId;

	RegistryCollection regCollection;

	public RegistryCollectionVerification (String giftregistry_id, Map<String,String> tblGRGFTREGMap)
	{
		this.sGiftRegistryId=giftregistry_id;
		this.mapGRGFTREG=tblGRGFTREGMap;
	}

	public void run() 
	{
		if(sGiftRegistryId==null || sGiftRegistryId.isEmpty())
		{
			return;
		}

		CommonGiftReg commonGiftReg = new CommonGiftReg();

		String sp[] ;
		String tmpSp[] ;
		String tmpField = null;
		String tmpField1 = null;
		String tmpField2=null;

		CompareValuesUtility.init();

		BasicDBObject criteria = new BasicDBObject();
		criteria.put("_id", sGiftRegistryId);

		DBCollection dbCollection = CommonGiftReg.getDBCollection("registryCollection");

		DBObject singleDocumentRegistryColl = dbCollection.findOne(criteria);

		if(singleDocumentRegistryColl == null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("registryCollection", "Not Found");
		}
		else
		{
			if(TestUtils.isEmptyJsonResponse(singleDocumentRegistryColl.toString()))
			{
				CompareValuesUtility.addFailedDataFieldForReport("registryCollection", "Not Found");
			}
			else
			{
				//System.out.println(singleDocumentRegistryColl.toString());

				/*------------------------------------------- GRGFTREG Table -------------------------------------------------------------*/

				regCollection = CommonGiftReg.getCollectionObject(singleDocumentRegistryColl.toString(),RegistryCollection.class);

				CompareValuesUtility.compareValues("_id", sGiftRegistryId,regCollection.getId()); 

				CompareValuesUtility.compareValues("giftregistry_id", sGiftRegistryId,regCollection.getGiftRegistryId()); 

				CompareValuesUtility.verifyNullOrEqual("externalId", mapGRGFTREG.get("GRGFTREG_EXTERNALID"),regCollection.getExternalId()); 

				CompareValuesUtility.verifyNullOrEqual("privacyLevel", mapGRGFTREG.get("GRGFTREG_GUESTACCESSOPTION"),regCollection.getPrivacyLevel()); 

				CompareValuesUtility.verifyNullOrEqual("status", mapGRGFTREG.get("GRGFTREG_STATUS"),regCollection.getStatus()); 

				CompareValuesUtility.verifyNullOrEqual("acceptGiftCard", mapGRGFTREG.get("GRGFTREG_ACCEPTGIFTCARD"),regCollection.getAcceptGiftCard());

				commonGiftReg.compareAsNumbers("storeNumber", mapGRGFTREG.get("GRGFTREG_FIELD2"),regCollection.getStoreNumber());

				/*There is no need to compare createTimeStamp and lastUpdateTimeStamp.
			       However rest of the dates (eventBaseDate, eventDate, purchaseDate etc) needs to be compared.
				CompareValuesUtility.verifyNullOrEqual("createdTimeStamp", mapGRGFTREG.get("GRGFTREG_CREATEDTIME"),regCollection.getCreatedTimeStamp());

				CompareValuesUtility.verifyNullOrEqual("lastUpdatedTimeStamp", mapGRGFTREG.get("GRGFTREG_LASTUPDATE"),regCollection.getLastUpdatedTimeStamp());*/

				CompareValuesUtility.verifyNullOrEqual("registryLocation", mapGRGFTREG.get("GRGFTREG_LOCATION"),regCollection.getRegistryLocation());

				String msg   = mapGRGFTREG.get("GRGFTREG_MESSAGEFORGUEST");

				msg = CommonGiftReg.removeSpecialChar(msg);

				CompareValuesUtility.verifyNullOrEqual("messageForGuest", msg ,regCollection.getMessageForGuest());

				CompareValuesUtility.verifyNullOrEqual("eventDetails.eventName", mapGRGFTREG.get("GRGFTREG_DESCRIPTION"),regCollection.getEventDetails().getEventName());

				if(mapGRGFTREG.get("GRGFTREG_STOREID")==null)
				{
					CompareValuesUtility.compareValues("Store", "", regCollection.getStore()); 
				}
				else if(mapGRGFTREG.get("GRGFTREG_STOREID").equals("10153"))
				{
					CompareValuesUtility.compareValues("Store", "sears", regCollection.getStore()); 
				}
				else if(mapGRGFTREG.get("GRGFTREG_STOREID").equals("10151"))
				{
					CompareValuesUtility.compareValues("Store", "kmart", regCollection.getStore()); 
				}
				else
				{
					System.out.println("############ Unhandled store..............");
				}

				CompareValuesUtility.verifyNullOrEqual("eventDetails.eventDate", mapGRGFTREG.get("GRGFTREG_EVENTDATE"),regCollection.getEventDetails().getEventDate());

				tmpField = mapGRGFTREG.get("GRGFTREG_FIELD5");

				if(tmpField!=null)
				{
					tmpField1=tmpField.split("#")[0];
					try {
						tmpField2=tmpField.split("#")[1];
					} catch (Exception e) {
						tmpField2 = null;
					}
				}
				//CompareValuesUtility.verifyNullOrEqual("eventDetails.eventLocation", tmpField1,regCollection.getEventDetails().getEventLocation());

				//CompareValuesUtility.verifyNullOrEqual("eventDetails.eventState", tmpField2,regCollection.getEventDetails().getEventState());

				/*----------------------------------------------- XGRGFTREG table----------------------------------------------------------*/

				try 
				{
					tmpField = mapGRGFTREG.get("XGRGFTREG_EMAILOPTIONS");

					try {

						if(tmpField!=null && tmpField.isEmpty())
						{
							tmpField ="";
						}
						else
						{
							tmpSp = tmpField.split("#");

							if(tmpSp[0].equals("Y")  && tmpSp[2].equals("Y") )
							{
								tmpField ="Y";
							}
							else
							{
								tmpField ="N";
							}
						}
					} catch (Exception e) {
						tmpField ="";
					}

					CompareValuesUtility.verifyNullOrEqual("emailCommunications", tmpField,regCollection.getEmailCommunications()==null?"":regCollection.getEmailCommunications());

					CompareValuesUtility.verifyNullOrEqual("photoUrl", mapGRGFTREG.get("XGRGFTREG_GRPHOTOIMAGEURL"),regCollection.getPhotoUrl());

					tmpField =  mapGRGFTREG.get("XGRGFTREG_CELEBRANTNAME");

					if(tmpField==null)
					{
						verifyCelebrantFirstAndLastName("", "");
					}
					else
					{
						sp = tmpField.split("\\|");

						if(sp.length==1)
						{
							verifyCelebrantFirstAndLastName(sp[0],"");
						}
						else if(sp.length==2)
						{
							verifyCelebrantFirstAndLastName(sp[0],sp[1]);
						}
						else
						{
							verifyCelebrantFirstAndLastName("", "");
						}
					}

					tmpField =mapGRGFTREG.get("XGRGFTREG_GENDER");
					tmpField=tmpField==null?"":tmpField;

					if(tmpField.contains("#"))
					{
						tmpField = tmpField.split("#")[0];
					}

					if(tmpField.equals("0")|| tmpField.equals("3") || tmpField.equals("false"))
						tmpField="";
					else if(tmpField.equals("1"))
						tmpField="Boy";
					else if(tmpField.equals("2"))
						tmpField="Girl";

					commonGiftReg.compareAsNumbers("celebrant.celebrantAge", mapGRGFTREG.get("XGRGFTREG_CELEBRANTAGE"),regCollection.getCelebrant().getCelebrantAge());

					CompareValuesUtility.verifyNullOrEqual("celebrant.gender",tmpField ,regCollection.getCelebrant().getGender());

					CompareValuesUtility.verifyNullOrEqual("celebrant.eventBasedDate", mapGRGFTREG.get("XGRGFTREG_EVENTBASEDDATE"),regCollection.getCelebrant().getEventBaseDate());

					if( mapGRGFTREG.get("XGRGFTREG_NOOFGUESTS")==null && regCollection.getEventDetails().getNoOfGuests()==null)
					{
						CompareValuesUtility.logPassed("eventDetails.noOfGuests","nu8734656687346566873465668734656687346566ll","null");
					}
					else
					{
						CompareValuesUtility.verifyNullOrEqual("eventDetails.noOfGuests", mapGRGFTREG.get("XGRGFTREG_NOOFGUESTS")==null?"0":
							mapGRGFTREG.get("XGRGFTREG_NOOFGUESTS"),regCollection.getEventDetails().getNoOfGuests());
					}

					CompareValuesUtility.verifyNullOrEqual("registryTypeName", mapGRGFTREG.get("XGRGFTREG_REGISTRYTYPENAME"),regCollection.getRegistryTypeName());

					tmpField = commonGiftReg.getEventType(mapGRGFTREG.get("GRGFTREG_EVENTTYPE_ID"));

					CompareValuesUtility.verifyNullOrEqual("eventDetails.eventType", tmpField, regCollection.getEventDetails().getEventType());
				}
				catch (Exception e1)
				{
					e1.printStackTrace();
				}

				/*----------------------------------------------- GRADDR table--------------------------------------------------------*/

				Map<String, String> mapGRADDR  = RegistryCollectionCache.mapGRADDR.get(sGiftRegistryId);

				if(mapGRADDR!=null &&  !mapGRADDR.isEmpty())
				{
					if(mapGRADDR.get("RGSTRNTTYPE").equals("0"))
					{
						//Reg

						CompareValuesUtility.verifyNullOrEqual("registrant.regFirstName",  mapGRADDR.get("FIRSTNAME"),
								regCollection.getRegistrant().getRegFirstName());

						CompareValuesUtility.verifyNullOrEqual("registrant.regLastName", mapGRADDR.get("LASTNAME")
								,regCollection.getRegistrant().getRegLastName());

						CompareValuesUtility.verifyNullOrEqual("registrant.regEmailId", mapGRADDR.get("EMAIL1")
								,regCollection.getRegistrant().getRegEmailId());

						CompareValuesUtility.verifyNullOrEqual("registrant.userId",  mapGRADDR.get("USERID")
								,regCollection.getRegistrant().getUserId());

						CompareValuesUtility.verifyNullOrEqual("registrant.address1",  mapGRADDR.get("ADDRESS1")
								,regCollection.getRegistrant().getAddress1());

						CompareValuesUtility.verifyNullOrEqual("registrant.address2",  mapGRADDR.get("ADDRESS2")
								,regCollection.getRegistrant().getAddress2());

						CompareValuesUtility.verifyNullOrEqual("registrant.city",  mapGRADDR.get("CITY")
								,regCollection.getRegistrant().getCity());

						CompareValuesUtility.verifyNullOrEqual("registrant.state",  mapGRADDR.get("STATE")
								,regCollection.getRegistrant().getState());

						CompareValuesUtility.verifyNullOrEqual("registrant.zipcode",  mapGRADDR.get("ZIPCODE")
								,regCollection.getRegistrant().getZipcode());

						CompareValuesUtility.verifyNullOrEqual("registrant.phone1",  mapGRADDR.get("PHONE1").replaceAll("-","")
								,regCollection.getRegistrant().getPhone1());

						CompareValuesUtility.verifyNullOrEqual("registrant.role",    mapGRADDR.get("RELATION")
								,regCollection.getRegistrant().getRole());

					}
					else if(mapGRADDR.get("RGSTRNTTYPE").equals("1"))
					{
						//CoReg

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.coregFirstName",  mapGRADDR.get("FIRSTNAME"),
								regCollection.getCoRegistrant().getCoregFirstName());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.coregLastName", mapGRADDR.get("LASTNAME")
								,regCollection.getCoRegistrant().getCoregLastName());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.coregEmailId", mapGRADDR.get("EMAIL1")
								,regCollection.getCoRegistrant().getCoregEmailId());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.userId ",   mapGRADDR.get("USERID")
								,regCollection.getCoRegistrant().getUserId());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.address1",  mapGRADDR.get("ADDRESS1")
								,regCollection.getCoRegistrant().getAddress1());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.address2",  mapGRADDR.get("ADDRESS2")
								,regCollection.getCoRegistrant().getAddress2());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.city",  mapGRADDR.get("CITY")
								,regCollection.getCoRegistrant().getCity());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.state",  mapGRADDR.get("STATE")
								,regCollection.getCoRegistrant().getState());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.zipcode",  mapGRADDR.get("ZIPCODE")
								,regCollection.getCoRegistrant().getZipcode());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.phone1",  mapGRADDR.get("PHONE1")==null?null:
							mapGRADDR.get("PHONE1").replaceAll("-","")
							,regCollection.getCoRegistrant()==null?null:
								regCollection.getCoRegistrant().getPhone1());

						CompareValuesUtility.verifyNullOrEqual("coRegistrant.role",  mapGRADDR.get("RELATION")
								,regCollection.getCoRegistrant().getRole());

					}
				}

				String shipPref  = null;

				List<Map<String, String>> lstResult2 = RegistryCollectionCache.mapGRRGSTRNT.get(sGiftRegistryId);
				if(lstResult2==null || lstResult2.isEmpty())
				{
					shipPref = "Alternate";
				}
				else
				{
					if(lstResult2.get(0).get("RGSTRNTTYPE").equals("1"))
					{
						shipPref="Coreg";
					}
					else if(lstResult2.get(0).get("RGSTRNTTYPE").equals("0"))
					{
						shipPref="Reg";
					}
				}

				CompareValuesUtility.verifyNullOrEqual("shippingDetails.shippingPreference",  shipPref
						,regCollection.getShippingDetails().getShippingPreference());

				List<Map<String, String>> lstResult = RegistryCollectionCache.mapGRADDR2.get(sGiftRegistryId);

				if(lstResult!=null && !lstResult.isEmpty())
				{
					mapGRADDR =  lstResult.get(0);

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.firstName", mapGRADDR.get("FIRSTNAME"),
							regCollection.getShippingDetails().getFirstName());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.lastName", mapGRADDR.get("LASTNAME"),
							regCollection.getShippingDetails().getLastName());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventAddress1",  mapGRADDR.get("ADDRESS1")
							,regCollection.getShippingDetails().getEventAddress1());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventAddress2",  mapGRADDR.get("ADDRESS2")
							,regCollection.getShippingDetails().getEventAddress2());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventCity",  mapGRADDR.get("CITY")
							,regCollection.getShippingDetails().getEventCity());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventState",  mapGRADDR.get("STATE")
							,regCollection.getShippingDetails().getEventState());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventZipcode",  mapGRADDR.get("ZIPCODE")
							,regCollection.getShippingDetails().getEventZipcode());

					CompareValuesUtility.verifyNullOrEqual("shippingDetails.eventPhone",  mapGRADDR.get("PHONE1")==null?null: mapGRADDR.get("PHONE1").replaceAll("-","")
							,regCollection.getShippingDetails().getEventPhone());

				}

				/*----------------------------------------XGRATTRVAL table---------------------------------------------------------------*/

				boolean coRegAccess = false;
				boolean collaboratorAccess = false;
				boolean commentRegAccess =false;
				boolean postRegAccess=false;

				List<Map<String, String>> mapXGRATTRVAL = RegistryCollectionCache.mapXGRATTRVAL.get(sGiftRegistryId);

				if(mapXGRATTRVAL!=null)
				{
					for (Map<String, String> map : mapXGRATTRVAL) {

						switch(map.get("ATTRIBUTENAME"))
						{

						case "SAMEASREGADDRESS":
							CompareValuesUtility.verifyNullOrEqual("CoRegistrant.sameAsRegAddr",  "Y"
									,regCollection.getCoRegistrant().getSameAsRegAddr());
							break;

						case "COREGACCESS":
							coRegAccess=true;
							CompareValuesUtility.verifyNullOrEqual("socialSettings.coRegAccess",  "Y"
									,regCollection.getSocialSettings().getCoRegAccess());
							break;
						case "COLLABORATORACCESS":
							collaboratorAccess=true;
							CompareValuesUtility.verifyNullOrEqual("socialSettings.collaboratorAccess", "Y"
									,regCollection.getSocialSettings().getCollaboratorAccess());
							break;
						case "COMMENTREGACCESS":
							commentRegAccess=true;
							CompareValuesUtility.verifyNullOrEqual("socialSettings.commentRegAccess",  "Y"
									,regCollection.getSocialSettings().getCommentRegAccess());
							break;
						case "POSTREGACCESS":
							postRegAccess=true;
							CompareValuesUtility.verifyNullOrEqual("socialSettings.postRegAccess",  "Y"
									,regCollection.getSocialSettings().getPostRegAccess());
							break;
						case "SYWGRREWARDDETAILS":

							tmpField =  map.get("ATTRIBUTEVALUE");
							sp = tmpField.split("#");

							CompareValuesUtility.verifyNullOrEqual("sywRewardDetails.emailId", sp[0],regCollection.getSywRewardDetails().getEmailId());
							CompareValuesUtility.verifyNullOrEqual("sywRewardDetails.sywOfferNumber", sp[1],regCollection.getSywRewardDetails().getSywOfferNumber());
							CompareValuesUtility.verifyNullOrEqual("sywRewardDetails.sywMemberNumber", sp[2],regCollection.getSywRewardDetails().getSywMemberNumber());
							commonGiftReg.compareAsNumbers("sywRewardDetails.sywPoints", sp[3],regCollection.getSywRewardDetails().getSywPoints());
							CompareValuesUtility.verifyNullOrEqual("sywRewardDetails.firstPurchaseDate", sp[4],regCollection.getSywRewardDetails().getFirstPurchaseDate());
							break;

						case "SYWGRREWARD_TOOLS":

							CompareValuesUtility.verifyNullOrEqual("sywGRRewardTools", "Y", regCollection.getSywGRRewardTools());
							break;

						case "COREGSENDALLIND":

							CompareValuesUtility.verifyNullOrEqual("coRegistrant.coRegSendAllCommunications","Y", 
									regCollection.getCoRegistrant().getCoRegSendAllCommunications());
							break;


						case "COREGCONFIRMMAILACCESS":

							CompareValuesUtility.verifyNullOrEqual("coRegistrant. invitestatus","Y", 
									regCollection.getCoRegistrant().getInvitestatus());
							break;

						case "CELEBRELATIONSHIP":

							CompareValuesUtility.verifyNullOrEqual("celebrant.celebrantRole",map.get("ATTRIBUTEVALUE"), 
									regCollection.getCelebrant().getCelebrantRole());
							break;
						}
					}
				}

				//TODO -  Confirm
				/*if(! coRegAccess)
					CompareValuesUtility.verifyNullOrEqual("socialSettings.coRegAccess",  "N"
							,regCollection.getSocialSettings().getCoRegAccess());

				if(! collaboratorAccess)
					CompareValuesUtility.verifyNullOrEqual("socialSettings.collaboratorAccess",  "N"
							,regCollection.getSocialSettings().getCollaboratorAccess());

				if(! commentRegAccess)
					CompareValuesUtility.verifyNullOrEqual("socialSettings.commentRegAccess",  "N"
							,regCollection.getSocialSettings().getCommentRegAccess());

				if(! postRegAccess)
					CompareValuesUtility.verifyNullOrEqual("socialSettings.postRegAccess",  "N"
							,regCollection.getSocialSettings().getPostRegAccess());
				 */

				/*--------------------------------------------------------------------------------------------------------------------*/

				List<Map<String, String>> lstResultGRANNHIST = RegistryCollectionCache.mapGRANNHIST.get(sGiftRegistryId);

				boolean found;

				List<MessageDetail> guestShareMessages = regCollection.getSentEmails().getGuestShare().getMessageDetails();

				List<OosMailPartNumberList> oosEmails = regCollection.getSentEmails().getOosMailPartNumberList();

				List<ItemPurchaseMailPartNumberList> itemPurchasedEmails = regCollection.getSentEmails().getItemPurchaseMailPartNumberList();

				if(lstResultGRANNHIST!=null)
				{
					for (Map<String, String> map2 : lstResultGRANNHIST) 
					{
						if(map2.get("FIELD1")==null)
						{
							System.out.println("FIELD1 is null/empty expecting(P/O/E)");
						}
						else if(map2.get("FIELD1").equals("E"))
						{
							CompareValuesUtility.logPassed("sentEmails.guestShare.senderName",
									map2.get("SENDERNAME"),regCollection.getSentEmails()==null||regCollection.getSentEmails().getGuestShare()==null?null
											:regCollection.getSentEmails().getGuestShare().getSenderName());

							CompareValuesUtility.logPassed("sentEmails.guestShare.senderEmail",
									map2.get("SENDEREMAIL"),regCollection.getSentEmails()==null||regCollection.getSentEmails().getGuestShare()==null?null:
										regCollection.getSentEmails().getGuestShare().getSenderEmail());

							found  = false;

							for (MessageDetail messageDetail : guestShareMessages) 
							{

								if(messageDetail.getMessage().equals(map2.get("MESSAGE")) &&messageDetail.getSentDate().equals(map2.get("SENTDATE")) )
								{
									CompareValuesUtility.logPassed("sentEmails.guestShare.message",	map2.get("MESSAGE"),messageDetail.getMessage());

									CompareValuesUtility.logPassed("sentEmails.guestShare.sentDate", map2.get("SENTDATE"),messageDetail.getSentDate());

									found = true;
									break;
								}

							}

							if(!found)
							{
								CompareValuesUtility.logFailed("sentEmails.guestShare.message",	map2.get("MESSAGE"),"Not Found");

								CompareValuesUtility.logFailed("sentEmails.guestShare.sentDate",map2.get("SENTDATE"),"Not Found");
							}

						}

						else if(map2.get("FIELD1").equals("O"))
						{

							found  = false;

							for (OosMailPartNumberList oosMailPartNumberList : oosEmails) 
							{

								if(map2.get("FIELD2").equals(oosMailPartNumberList.getPartNumber())
										&& map2.get("SENTDATE").equals(oosMailPartNumberList.getSentDate()))
								{
									CompareValuesUtility.logPassed("sentEmails.oosMailPartNumberList.partNumber", oosMailPartNumberList.getPartNumber(),oosMailPartNumberList.getPartNumber());

									CompareValuesUtility.logPassed("sentEmails.oosMailPartNumberList.SentDate", oosMailPartNumberList.getSentDate(),oosMailPartNumberList.getSentDate());

									found = true;
									break;
								}
							}

							if(!found)
							{
								CompareValuesUtility.logPassed("sentEmails.oosMailPartNumberList.partNumber", map2.get("FIELD2"),"Not Found");
								CompareValuesUtility.logPassed("sentEmails.oosMailPartNumberList.SentDate", map2.get("SENTDATE"),"Not Found");
							}
						}
						else if(map2.get("FIELD1").equals("P"))
						{
							found  = false;

							for (ItemPurchaseMailPartNumberList itemPurchased : itemPurchasedEmails) 
							{

								if(map2.get("FIELD2").equals(itemPurchased.getPartNumber())
										&& map2.get("SENTDATE").equals(itemPurchased.getSentDate()))
								{
									CompareValuesUtility.logPassed("sentEmails.itemPurchaseMailPartNumberList.partNumber", itemPurchased.getPartNumber(),itemPurchased.getPartNumber());

									CompareValuesUtility.logPassed("sentEmails.itemPurchaseMailPartNumberList.SentDate", itemPurchased.getSentDate(),itemPurchased.getSentDate());

									found = true;
									break;
								}
							}

							if(!found)
							{
								CompareValuesUtility.logPassed("sentEmails.itemPurchaseMailPartNumberList.partNumber", map2.get("FIELD2"),"Not Found");
								CompareValuesUtility.logPassed("sentEmails.itemPurchaseMailPartNumberList.SentDate", map2.get("SENTDATE"),"Not Found");
							}
						}
					}
				}

				/*-------------------------------------------- GREMLLIST table ------------------------------------------------------------*/

				List<Map<String, String>> lstResultGREMLLIST =  RegistryCollectionCache.mapGREMLLIST.get(sGiftRegistryId);

				if(lstResultGREMLLIST!=null)
				{
					for (Map<String, String> map : lstResultGREMLLIST) 
					{
						found = false;

						for (MessageDetail messageDetail : guestShareMessages) 
						{

							if(messageDetail.getReceipientName().equals(map.get("NAME"))
									&& messageDetail.getReceipientEmail().equals(map.get("EMAIL")))
							{
								CompareValuesUtility.logPassed("sentEmails.guestShare.ReceipientName",map.get("NAME"),messageDetail.getReceipientName());
								CompareValuesUtility.logPassed("sentEmails.guestShare.getReceipientEmail",map.get("EMAIL"),messageDetail.getReceipientEmail());

								found = true;
								break;
							}
						}

						if(!found)
						{
							//CompareValuesUtility.logFailed("sentEmails.guestShare.ReceipientName",map.get("NAME")==null?"":map.get("NAME"),"Not Found");
							CompareValuesUtility.logFailed("sentEmails.guestShare.getReceipientEmail",map.get("EMAIL")==null?"":map.get("EMAIL"),"Not Found");
						}
					}
				}

				String ADDSHOWERDATE = mapGRGFTREG.get("XGRGFTREG_ADDSHOWERDATE");

				if(ADDSHOWERDATE!=null)
				{
					String spadd[] = ADDSHOWERDATE.split("#");

					if(mapGRGFTREG.get("GRGFTREG_EVENTTYPE_ID").equals("10001"))
					{
						//Webdding
						for (String str : spadd) 
						{
							if(CommonGiftReg.WShowerMap.get(str)!=null)
							{
								checkCWR(str,CommonGiftReg.WShowerMap);
							}
						}
					}
					else if(mapGRGFTREG.get("GRGFTREG_EVENTTYPE_ID").equals("10002"))
					{
						//baby
						for (String str : spadd) 
						{
							if(CommonGiftReg.BShowerMap.get(str)!=null)
							{
								checkCWR(str,CommonGiftReg.BShowerMap);
							}
						}
					}
					else
					{
						//shower
						//Webdding
						for (String str : spadd) 
						{
							if(CommonGiftReg.EShowerMap.get(str)!=null)
							{
								checkCWR(str,CommonGiftReg.EShowerMap);
							}
						}
					}
				}
				/*--------------------------------------------  END  ------------------------------------------------------------*/
			}
		}

		RegistryCollectionCache.clearMap(sGiftRegistryId);

		CompareValuesUtility.setupResult(sGiftRegistryId,true);
	}


	private void checkCWR(String str,Map<String,String> map)
	{
		if(str.endsWith("_W"))
		{
			//welcomeEmails
			if(regCollection.getSentEmails().getWelcomeEmails().contains(map.get(str)))
			{
				CompareValuesUtility.logPassed("sentEmails.welcomeEmails", map.get(str),map.get(str));
			}
			else
			{
				CompareValuesUtility.logPassed("sentEmails.welcomeEmails", map.get(str),"Not Found");
			}
		}
		else if(str.endsWith("_C"))
		{
			//CongratsEmails
			if(regCollection.getSentEmails().getCongratsEmails().contains(map.get(str)))
			{
				CompareValuesUtility.logPassed("sentEmails.CongratsEmails", map.get(str),map.get(str));
			}
			else
			{
				CompareValuesUtility.logPassed("sentEmails.CongratsEmails", map.get(str),"Not Found");
			}
		}
		else if(str.endsWith("_R"))
		{
			//ReminderEmails
			if(regCollection.getSentEmails().getReminderEmails().contains(map.get(str)))
			{
				CompareValuesUtility.logPassed("sentEmails.ReminderEmails", map.get(str),map.get(str));
			}
			else
			{
				CompareValuesUtility.logPassed("sentEmails.ReminderEmails", map.get(str),"Not Found");
			}

		}

	}

	private void verifyCelebrantFirstAndLastName(String f,String l)
	{
		CompareValuesUtility.verifyNullOrEqual("celebrant.celebrantFirstName",f,regCollection.getCelebrant().getCelebrantFirstName());
		CompareValuesUtility.verifyNullOrEqual("celebrant.celebrantLastName",l,regCollection.getCelebrant().getCelebrantLastName());
	}
}
