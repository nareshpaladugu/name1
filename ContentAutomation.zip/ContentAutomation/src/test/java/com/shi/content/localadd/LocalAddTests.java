package com.shi.content.localadd;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.testcommons.FileProviderClass;
public class LocalAddTests {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider" , groups="LocalAdd")
	public void testlocaladd(String fileName) {

		BlockingQueue<List<String>> singlelocalid = new LinkedBlockingQueue<List<String>>();
		TextFileParser<String> myParser = new TextFileParser<String>(fileName, singlelocalid,new LocaladdParser());
		Thread t = new Thread(myParser);
		t.start();


		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while (true) {
			List<String> newData;
			int i=0;
			try {
				newData = singlelocalid.poll(20, TimeUnit.SECONDS);
				
			//if(newData.contains("UnitNumber|KSN|ProductRegPrice|ProductSalePrice|ProductClearancePrice|SaleStartDate|SaleEndDate|AdditionalDealInfo|PriceQualifier|FinePrint|StoreID|GroupID|PostStartDate|PostEndDate|ListingStatus|")){
			if(newData.contains("UnitNumber|KSN|KSNDesc|ProductRegPrice|ProductSalePrice|ProductClearancePrice|SaleStartDate|SaleEndDate7|AddDealInfo|ItemId|PriceQualifier10|Store|FinePrint|PostStartDate|PostEndDate|OnHandQty|KSNExclFlag|DivNbr|ProductOrgPrice|Source19|Cost20|Rank|RetailerTagId|StoreItemSource|VerticalName|VerticalId|CategoryName|CategoryId|SubCategoryName|SubCategoryId|GroupId30|ListingStatus|OfferType|ProcessPhase")){	
				continue;
			}
				if (newData == myParser.POISON_PILL) {
					break;
				}
				if(newData != null){
					pool.execute(new LocalAddVerifications(newData,i++));
					System.out.println("Sent "+ newData);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		
	}
	
	

}