
package com.shi.content.storepricing;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * store level price of an item,details of all price types
 * 
 * 
 */
@Generated("org.jsonschema2pojo")
public class P {

    /**
     * list of regular prices.
     * (Required)
     * 
     */
    @Expose
    private List<R> r = new ArrayList<R>();
    /**
     * List of associate prices.
     * (Required)
     * 
     */
    @Expose
    private List<A> a = new ArrayList<A>();
    /**
     * list of sale prices.
     * (Required)
     * 
     */
    @Expose
    private List<S> s = new ArrayList<S>();
    /**
     * clearance price object of an item
     * 
     * (Required)
     * 
     */
    @Expose
    private List<X> x = new ArrayList<X>();
    /**
     * was price of an item 
     * (Required)
     * 
     */
    @Expose
    private Double w;

    /**
     * list of regular prices.
     * (Required)
     * 
     */
    public List<R> getR() {
        return r;
    }

    /**
     * list of regular prices.
     * (Required)
     * 
     */
    public void setR(List<R> r) {
        this.r = r;
    }

    /**
     * List of associate prices.
     * (Required)
     * 
     */
    public List<A> getA() {
        return a;
    }

    /**
     * List of associate prices.
     * (Required)
     * 
     */
    public void setA(List<A> a) {
        this.a = a;
    }

    /**
     * list of sale prices.
     * (Required)
     * 
     */
    public List<S> getS() {
        return s;
    }

    /**
     * list of sale prices.
     * (Required)
     * 
     */
    public void setS(List<S> s) {
        this.s = s;
    }

    /**
     * clearance price object of an item
     * 
     * (Required)
     * 
     */
    public List<X> getX() {
        return x;
    }

    /**
     * clearance price object of an item
     * 
     * (Required)
     * 
     */
    public void setX(List<X> x) {
        this.x = x;
    }

    /**
     * was price of an item 
     * (Required)
     * 
     */
    public Double getW() {
        return w;
    }

    /**
     * was price of an item 
     * (Required)
     * 
     */
    public void setW(Double w) {
        this.w = w;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
