package com.shi.content.matching;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.google.common.collect.Lists;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class Tester {


	@Test(groups="TesterTest")
	public void test()
	{

		LoadProperties.gbServer ="greenvip.prod.ch4.s.com:80";

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		for (int i = 0; i < 1000; i++) {

			pool.execute(new Thread(i));
		}


		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

		System.out.println("END of Test !");
	}

	class Thread implements Runnable
	{

		int bucket;

		public Thread(int bucket)
		{
			this.bucket = bucket;
		}

		public void run() {

			try {
				System.out.println("Checking bucket ..."+bucket);
				List<String> ids = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER, bucket);

				List<List<String>> sublists = Lists.partition(ids, 25);

				for (List<String> list : sublists) {

					List<Offer> allOffersGB = RestExecutor.getDataById(CollectionValuesVal.OFFER, list);

					for (Offer offer : allOffersGB) {

						if(offer.getIdentity().getSsin()==null || offer.getIdentity().getSsin().isEmpty())
						{
							try {
								System.out.println( offer.getId() + " -- "+(offer.getFfm()==null?"":offer.getFfm().getChannel())+" --- Meta Created ---> "+offer.getMeta().getCreatedTs() +" --- Meta Modified ---> "+offer.getMeta().getModifiedTs());
							} catch (Exception e) {
							}
						}
					}
				}
			} catch (Exception e) {
				System.out.println("Bucket Exception ... "+bucket);
				e.printStackTrace();
			}
		}

	}
}
