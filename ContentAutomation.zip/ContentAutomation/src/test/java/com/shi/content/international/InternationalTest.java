package com.shi.content.international;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;


public class InternationalTest {

	
	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp", groups="InternationalTests")
	public void internationalTests(String sRunParam) {
		if (LoadProperties.IS_BUCKETBASED_RUN) {
			List<String> lstBundleIds = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER_ATTR_SCHEMA, Integer.parseInt(sRunParam));
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			for (String offerId : lstBundleIds) {
				pool.execute(new InternationalVerifications(offerId));
			}

			pool.shutdown();

			try {
				pool.awaitTermination(40, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else if (LoadProperties.IS_LISTBASED_RUN) {
			new InternationalVerifications(sRunParam).run();
		} else {
			System.out.println("Please set property executionMode");
		}
	}

}
