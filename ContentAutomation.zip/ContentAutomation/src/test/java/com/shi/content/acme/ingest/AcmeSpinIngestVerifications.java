package com.shi.content.acme.ingest;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNull;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.productoffering.Hierarchy;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.types.UpcTypeType;
import com.google.gson.JsonSyntaxException;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.acme.ItemAuthorityTestCommon;

public class AcmeSpinIngestVerifications implements Runnable {

	SingleProductOffer singleProductOffer ;
	VariationProductOffer varProdOffer ;
	SHCContentCommons commonUtils;
	String itemClassId;
	Boolean bSingleProductOffer = true;
	Boolean isVarChild = true;
	String partNumberToTest;
	ProductOffer varChild;
	private boolean bContentEligExp = false;

	public AcmeSpinIngestVerifications(	SingleProductOffer nonVarNodeToTest, String itemClassId, 
			VariationProductOffer varParentNodeToTest, 	ProductOffer varChildNodeToTest) {

		if(nonVarNodeToTest == null){
			bSingleProductOffer = false;
		}
		if(varChildNodeToTest == null){
			isVarChild = false;
		}
		this.singleProductOffer = nonVarNodeToTest;
		this.commonUtils = new SHCContentCommons();
		this.itemClassId = itemClassId;
		this.varProdOffer = varParentNodeToTest;
		this.varChild = varChildNodeToTest;
	}
	String response=null;

	public void run() {


		ProductContent pContentToTest = this.getContentToTest();
		ProductOffer pOfferToTest = this.getOfferToTest();

		try {

			response = RestExecutor.getJSonResponse(RestAPIs.getAcmeURI(CollectionValuesVal.IA_SOURCE_BY_ID, partNumberToTest));
			if(partNumberToTest!= null) 
			{
				CompareValuesUtility.init();

				AcmeSourceById acmeSourceById = JSONParser.parseJSON(response, AcmeSourceById.class);


				if(acmeSourceById == null || acmeSourceById.getItem()==null){
					CompareValuesUtility.logFailed("id", partNumberToTest, " Not found");
					CompareValuesUtility.logFailed("itemClassId", itemClassId, " Not found");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return;
				}
				//System.out.println("Testing id=" + acmeSourceById.getItem().getId());


				verifyProduct(pContentToTest, acmeSourceById, partNumberToTest ,isVarChild, pOfferToTest, response);

				CompareValuesUtility.setupResult(partNumberToTest, true);
			}
		}
		catch(JsonSyntaxException js)
		{
			System.out.println( partNumberToTest + " response..."+response);
			js.printStackTrace();
		}
		catch(Throwable e){
			System.out.println("Check this id :"+ partNumberToTest);
			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());

		}finally{
			CompareValuesUtility.teardown();
		}
	}


	private void verifyProduct(ProductContent prodContent, AcmeSourceById iaSource, String id, Boolean isVarChild, ProductOffer prodOffer,String response) {
		/*fields under Item*/
		compareValues("id", id, iaSource.getItem().getId());

		try 
		{
			compareValues("vendorId", "sears", iaSource.getItem().getVendorId());


			CompareValuesUtility.compareValues("contentElig", bContentEligExp, iaSource.getItem().getAttributes().getContentEligible());
			String sActualTitle = iaSource.getItem().getAttributes().getTitle();

			CompareValuesUtility.compareValues("ContentId", prodContent.getContentId(), iaSource.getItem().getAttributes().getContentId());
			/*fields under Attributes*/
			verifyNullOrEqual("title", prodContent.getName()==null?null:
				OfferCommons.replaceNewline(prodContent.getName()),
				sActualTitle);

			String sExpectedShortDesc = prodContent.getMarketingDescription()==null?null:
				TestUtils.plainEncodeHTML(
						OfferCommons.replaceNewline(prodContent.getMarketingDescription()));


			verifyNullOrEqual("shortDesc", sExpectedShortDesc,	iaSource.getItem().getAttributes().getShortDesc());

			String sActualLongDesc = JsonStringParser.getJsonValue(response,"{item{attributes{longDesc}}}");

			verifyNullOrEqual("longDesc", prodContent.getFeatureDescription()==null?null:
				TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(TestUtils.plainEncodeHTML(OfferCommons.replaceNewline(prodContent.getFeatureDescription())))
				, sActualLongDesc);

			compareValues("itemClassId", itemClassId, iaSource.getItem().getAttributes().getItemClassId());

			if(AcmeSpinIngestTests.bVerifyNotNullSsinGuid){
				CompareValuesUtility.verifyNotNull("ssin", iaSource.getItem().getSsin());
				CompareValuesUtility.verifyNotNull("guid", iaSource.getItem().getGuid());
			}

			verifyNullOrEqual("brandId", prodContent.getBrand()==null?null:prodContent.getBrand().getId(), iaSource.getItem().getAttributes().getBrandId());
			verifyNullOrEqual("brandName", prodContent.getBrand()==null?null:TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(prodContent.getBrand().getName()), iaSource.getItem().getAttributes().getBrandName());
			/*BrandImage brandImage = iaSource.getItem().getAttributes().getBrandImage();
			verifyNullOrEqual("brandImage", (prodContent.getBrand()==null?null:IngestCommons.convertImageUrl(prodContent.getBrand().getLogoImageUrl())), 
					brandImage==null?null:brandImage.getUrl());*/

			verifyNullOrEqual("modelNumber", prodContent.getManufacturerModelNumber(), iaSource.getItem().getAttributes().getModelNumber());
			//verifyNullOrEqual("manufacturerName", prodContent.getManufacturerName(), iaSource.getItem().getAttributes().getManufacturerName());
			//verifyNullOrFalse("isLongDescSupp", prodContent.getSuppressLongDescriptionFlag(), iaSource.getItem().getAttributes().getIsLongDescSupp());

			if(!isVarChild){
				compareValues("svid", prodContent.getVendorId(), iaSource.getItem().getAttributes().getSvid());
			}

			/*String[] xmltopDesc =prodContent.getFeatureTopDescriptions()==null?null
					:prodContent.getFeatureTopDescriptions().getFeatureTopDescription();

			List<String> rectopDesc = iaSource.getItem().getAttributes().getTopDesc()==null?null:
				iaSource.getItem().getAttributes().getTopDesc();

			ItemAuthorityTestCommon.compareTwoLists(xmltopDesc, rectopDesc, "topDesc");*/

			/* --TODO--
			 * brandCodeId
			 * prevSsin ??
			 * sywItemType
			 * imaClassControlPid
			 * */

			/* ------------  Added by Daffy -----------------*/

			verifyNullOrEqual("Status", "ACTIVE", iaSource.getItem().getStatus());


			if(isVarChild)
			{
				verifyNullOrEqual("pid", varProdOffer.getVariationGroupId(), iaSource.getItem().getAttributes().getPid());
				//Map<String, List<VarAttr>> actaulMapVarAttr = ItemAuthorityTestCommon.getVarAttrMapListFromJson(JsonStringParser.getJsonValue(response, "{item{attributes{varAttr}}}"));
				Map<String, List<com.shi.content.acme.VarAttr>> actaulMapVarAttr = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(response, "{item{attributes{varAttr}}}"));
				Map<String, List<com.shi.content.acme.VarAttr>> expectedMapVarAttr = ItemAuthorityTestCommon.getVarAttrMapXml( prodOffer.getVariantAttributes());
				new ItemAuthorityTestCommon().compareAttributesMaps(expectedMapVarAttr, actaulMapVarAttr,true,"varAttr");
				CompareValuesUtility.addNewMultiValuedFields();
			}
			else
			{
				if(prodContent.getProductAttributes()!=null){
					Map<String, List<com.shi.content.acme.VarAttr>> attributesFromXml = ItemAuthorityTestCommon.getattributesMapXml(prodContent.getProductAttributes());
					Map<String, List<com.shi.content.acme.VarAttr>> attriutesFromJson = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(response, "{item{attributes{attributes}}}"));
					new ItemAuthorityTestCommon().compareAttributesMaps(attributesFromXml, attriutesFromJson,true,"attributes");
					CompareValuesUtility.addNewMultiValuedFields();
				}

				/*verifyAutoFitment(prodContent, iaSource);*/
			}

			String brandCodeId = null;
			String pkgQty = null;

			if(prodContent.getProductAttributes()!=null)
			{
				ProductAttribute[] prodAttributes = prodContent.getProductAttributes().getProductAttribute();
				for (ProductAttribute pa : prodAttributes) {
					if(pa.getAttributeId()!=null && 
							(pa.getAttributeId().toString().equals("28101") ||
									pa.getAttributeId().toString().equals("11720") ||
									pa.getAttributeId().toString().equals("242"))){

						pkgQty = pa.getProductAttributeTypeChoice().getAttributeValueFree();

					}else if(pa.getAttributeId()!=null && pa.getAttributeId().toString().equals("873910")){
						brandCodeId = pa.getProductAttributeTypeChoice().getAttributeValueFree();
					}
				}
			}

			verifyNullOrEqual("packageQuantity", isVarChild?null:pkgQty ,iaSource.getItem().getAttributes().getPackageQuantity());
			verifyNullOrEqual("brandCodeId", brandCodeId, iaSource.getItem().getAttributes().getBrandCodeId());
			verifyNullOrEqual("isTires", prodContent.getTires(), iaSource.getItem().getAttributes().getIsTires());


			/*Moved sywItemType outside as it is applicable for NV, V and P*/
			/*Changed attribute name to "shop your way exclusives"*/
			/*Fixed variation issue - take attribute from first variation child offer*/
			/*String iaSywItemType=null;

			try {
				iaSywItemType = iaSource.getItem().getAttributes().getSywItemType();
			} catch (Exception e) {
				iaSywItemType="null";
			}

			Attribute[] imaAttr = null;
			if(bSingleProductOffer)
				imaAttr = singleProductOffer.getProductOfferings().getProductOffer(0).getImaAttributes().getAttribute();
			else
				imaAttr = varProdOffer.getProductOfferings().getProductOffer(0).getImaAttributes().getAttribute();

			for (Attribute a : imaAttr) {
				if (a.getName().equals("shop your way exclusives"))
					CompareValuesUtility.compareValues("SywItemType", a.getContent(), iaSywItemType);
			}*/

			//verifyTaxonomy(prodContent.getSite(), iaSource.getItem().getAttributes().getSites());

			if(bSingleProductOffer||!isVarChild) {
				//Validate below fields only of NV and P
				//verifySeo(prodContent.getSeo(), iaSource.getItem().getAttributes().getSeo());
				//verifyProdAssets(prodContent.getProductAssets(), iaSource.getItem().getAttributes().getProductAssets());
				//verifyContentExtns(prodContent.getContentExtensions(), iaSource.getItem().getAttributes().getContentExt());
				//verifyCuratedConts(prodContent.getCuratedContents(), iaSource.getItem().getAttributes().getCuratedGroups());
				//verifyPrimaryImage(prodContent.getPrimaryImage(), iaSource.getItem().getAttributes().getPrimaryImage());
				//verifyFeatureImage(prodContent.getFeatureImages(), iaSource.getItem().getAttributes().getFeatureImages());


			}else {
				//Validate primaryImage for V
				//verifyPrimaryImage(prodOffer.getImageUrl(), iaSource.getItem().getAttributes().getPrimaryImage());
			}


			/*String xmlEnrichment = prodContent.getEnrichmentInfo()==null?"S":prodContent.getEnrichmentInfo().getEnrichmentProvider().value();
			//System.out.println("xmlEnrichment... "+xmlEnrichment);

			String sSourceEnrichmentExp = commonUtils.getEnrichmentProvider(xmlEnrichment, true);

			compareValues("enrichmentProvider", sSourceEnrichmentExp, iaSource.getItem().getAttributes().getEnrichmentProvider());*/


			/*fields at product offer level*/
			verifyNullOrEqual("upcCode", (bSingleProductOffer||isVarChild)?prodOffer.getUpc():null, iaSource.getItem().getAttributes().getUpcCode());
			verifyNullOrEqual("upcType", (bSingleProductOffer||isVarChild)?prodOffer.getUpcType():null, iaSource.getItem().getAttributes().getUpcType());
			//verifyNullOrEqual("spinId", id, iaSource.getItem().getAttributes().getSpinId());

			String sourceSearsPart=null;
			try {
				sourceSearsPart = iaSource.getItem().getAttributes().getPartNumber().getSearsPartNumber();
			} catch (Exception e) {
				sourceSearsPart=null;
			}

			String xmlSearsPart=null;
			try {
				xmlSearsPart = prodOffer.getPartNumber().getSearsPartNumber();
			} catch (Exception e) {
				xmlSearsPart=null;
			}
			
			String sourceKmartPart=null;

			try {
				sourceKmartPart = iaSource.getItem().getAttributes().getPartNumber().getKmartPartNumber();
			} catch (Exception e) {
				sourceKmartPart=null;
			}
			
			String xmlKmartPart=null;
			
			try {
				xmlKmartPart = prodOffer.getPartNumber().getKmartPartNumber();
			} catch (Exception e) {
				xmlKmartPart=null;
			}
			
			if(sourceSearsPart==null && sourceKmartPart==null)
			{
				//both null
				CompareValuesUtility.addFailedDataFieldForReport("SearsKmartNullParts", "Both null");
			}
			
			if(xmlSearsPart!=null && xmlSearsPart.equals("-1"))
			{
				//both null
				CompareValuesUtility.addFailedDataFieldForReport("Sears-1Parts", "Sears -1 part");
			}
			
			if(xmlKmartPart!=null && xmlKmartPart.equals("-1"))
			{
				//both null
				CompareValuesUtility.addFailedDataFieldForReport("Kmart-1Parts", "Kmart -1 part");
			}

			String log = "sears : "+(xmlSearsPart==null?"":xmlSearsPart) + " and kmart : "+(xmlKmartPart==null?"":xmlKmartPart);
			CompareValuesUtility.addDataFieldForReport("JustForLogPartNumbers",log);
			

			//if(!(bSingleProductOffer?"NV":(isVarChild?"V":"P")).equalsIgnoreCase("P") )
			{
				List<String> sitesToTest = getSitesToTestPartNumber();

				if(sitesToTest.contains("sears"))
					verifyNullOrEqual("searsPartNumber", (bSingleProductOffer||isVarChild)
							?(prodOffer.getPartNumber()==null?null:prodOffer.getPartNumber().getSearsPartNumber())
									:varProdOffer.getVariationSearsPartNumber(), 
									iaSource.getItem().getAttributes().getPartNumber()==null?null
											:iaSource.getItem().getAttributes().getPartNumber().getSearsPartNumber());
				else
					verifyNull("searsPartNumber", iaSource.getItem().getAttributes().getPartNumber().getSearsPartNumber());

				if(sitesToTest.contains("kmart"))
					verifyNullOrEqual("kmartPartNumber", (bSingleProductOffer||isVarChild)
							?prodOffer.getPartNumber()==null?null:prodOffer.getPartNumber().getKmartPartNumber()
									:varProdOffer.getVariationKmartPartNumber(),
									iaSource.getItem().getAttributes().getPartNumber()==null?null
											:iaSource.getItem().getAttributes().getPartNumber().getKmartPartNumber());
				else
					verifyNull("kmartPartNumber", iaSource.getItem().getAttributes().getPartNumber().getKmartPartNumber());
			}
			/*else
			{
				//old flow
				verifyNullOrEqual("searsPartNumber", (bSingleProductOffer||isVarChild)
						?(prodOffer.getPartNumber()==null?null:prodOffer.getPartNumber().getSearsPartNumber())
								:varProdOffer.getVariationSearsPartNumber(), 
								iaSource.getItem().getAttributes().getPartNumber()==null?null
										:iaSource.getItem().getAttributes().getPartNumber().getSearsPartNumber());

				verifyNullOrEqual("kmartPartNumber", (bSingleProductOffer||isVarChild)
						?prodOffer.getPartNumber()==null?null:prodOffer.getPartNumber().getKmartPartNumber()
								:varProdOffer.getVariationKmartPartNumber(),
								iaSource.getItem().getAttributes().getPartNumber()==null?null
										:iaSource.getItem().getAttributes().getPartNumber().getKmartPartNumber());
			}*/



			verifyNull("dartPartNumber", null, iaSource.getItem().getAttributes().getDartPartNumber());

			/*default fields*/
			compareValues("classifier", bSingleProductOffer?"NV":(isVarChild?"V":"P"), iaSource.getItem().getAttributes().getClassifier());
			verifyNullOrEqual("feedSource", "spin", iaSource.getItem().getAttributes().getFeedSource());

			if(prodOffer.getPartNumber()!=null)
			{
				//if(bSingleProductOffer||isVarChild){
				if(prodOffer.getPartNumber().getSearsPartNumber()!=null){
					verifyNullOrEqual("programType", "SEARS", iaSource.getItem().getAttributes().getProgramType());
				}else{
					verifyNullOrEqual("programType", "KMART", iaSource.getItem().getAttributes().getProgramType());
				}
			}
			//			}else{
			//				verifyNullOrEqual("programType", "SEARS", iaSource.getItem().getAttributes().getProgramType());
			//			}


			/*fields not applicable for spin*/
			//verifyNullOrEqual("isBanned", null, iaSource.getItem().getAttributes().getIsBanned());
			//verifyNullOrEqual("isMature", null, iaSource.getItem().getAttributes().getIsMature());		

			/*newly added*/
			verifyNullOrEqual("storeHierId", (bSingleProductOffer||isVarChild)?prodOffer.getCoreHierarchyId():null, iaSource.getItem().getAttributes().getStoreHierId());
			verifyNullOrEqual("attributes.Status", "ACTIVE", iaSource.getItem().getAttributes().getStatus().getStatus());
			verifyNullOrEqual("varGrpId", (bSingleProductOffer||isVarChild)?null:id, iaSource.getItem().getAttributes().getVarGroupId());
			//verifyNullOrEqual("inactiveReason", "[]",iaSource.getItem().getAttributes().getInactiveReason());

			//verifyGroceryTag(prodContent, iaSource, id, isVarChild, prodOffer, response);

			if(prodOffer.getPartNumber()!=null)
			{
				if(bSingleProductOffer||isVarChild)
				{
					verifyNullOrEqual("calcSsin", 
							(prodOffer.getPartNumber().getSearsPartNumber()==null?prodOffer.getPartNumber().getKmartPartNumber()+"P"
									:prodOffer.getPartNumber().getSearsPartNumber()+"P"), iaSource.getItem().getCalcSsin());
				}
				else
				{
					if(getSitesToTestPartNumber().contains("sears"))
						verifyNullOrEqual("calcSsin", varProdOffer.getVariationSearsPartNumber()+"P", iaSource.getItem().getCalcSsin());
					else
						verifyNullOrEqual("calcSsin", varProdOffer.getVariationKmartPartNumber()+"P", iaSource.getItem().getCalcSsin());
				}
			}

			if((bSingleProductOffer?"NV":(isVarChild?"V":"P")).equalsIgnoreCase("P"))
			{
				//sites  content to content
				verifySites1(prodContent.getSite(),iaSource.getItem().getAttributes().getSites());
			}
			else
			{
				//sites offer to offer
				verifySites1(prodOffer.getSite(),iaSource.getItem().getAttributes().getSites());
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
		}
	}

	private List<String> getSitesToTestPartNumber()
	{
		List<String> list = new ArrayList<String>();
		list.add("sears");
		list.add("kmart");

		String searsPartNumberContent ;
		String kmartPartNumberContent ;

		Set<String> searsPartNumbers=new HashSet<>(); ;
		Set<String> kmartPartNumbers=new HashSet<>(); ;

		ProductOffer[] prodOffers ;

		if(!bSingleProductOffer){

			searsPartNumberContent = varProdOffer.getVariationSearsPartNumber();
			kmartPartNumberContent = varProdOffer.getVariationKmartPartNumber();

			if(!TestUtils.isEmptyString(searsPartNumberContent) && !TestUtils.isEmptyString(kmartPartNumberContent))
			{
				//both parts are present

				prodOffers = varProdOffer.getProductOfferings().getProductOffer();

				for (ProductOffer productOffer : prodOffers) 
				{
					if(!TestUtils.isEmptyString(productOffer.getPartNumber().getSearsPartNumber()))
						searsPartNumbers.add(productOffer.getPartNumber().getSearsPartNumber());

					if(!TestUtils.isEmptyString(productOffer.getPartNumber().getKmartPartNumber()))
						kmartPartNumbers.add(productOffer.getPartNumber().getKmartPartNumber());
				}

				if(searsPartNumbers.isEmpty())
				{
					//need to remove sears
					//System.out.println("Need to remove sears part numbers - hcase");
					list.remove("sears");
				}
			}
		}

		return list;
	}

	/*private void verifyAutoFitment(ProductContent prodContent,IaSourceById iaSource)
	{
		SHCContentCommons commonUtils = new SHCContentCommons("","sears");

		boolean isBrandCodeFound=false;

		String sBrandCodeId =null ;

		if(prodContent.getProductAttributes()!=null)
		{
			ProductAttribute[] prodAttributes = prodContent.getProductAttributes().getProductAttribute();
			for (ProductAttribute pa : prodAttributes) {
				if(pa.getAttributeId().toString().equals("873910"))
				{
					sBrandCodeId = pa.getProductAttributeTypeChoice().getAttributeValueFree();
					isBrandCodeFound=true;
					break;
				}
			}

			boolean checkForNull = true;
			for (ProductAttribute pa : prodAttributes) 
			{
				if(pa.getAttributeId().toString().equals("1035210"))
				{
					if(pa.getProductAttributeTypeChoice().getAttributeValueId().toString().equals("2509310"))
					{
						if(isBrandCodeFound)
						{
							boolean isFit = commonUtils.fitmentValidation(sBrandCodeId, prodContent.getManufacturerModelNumber());

							checkForNull = false;
							CompareValuesUtility.verifyNullOrEqual("autoFitment", isFit?isFit:null, iaSource.getItem().getAttributes().getAutoFitment());
						}
					}
				}
			}

			if(checkForNull)
			{
				CompareValuesUtility.verifyNull("autoFitment", iaSource.getItem().getAttributes().getAutoFitment());
			}
		}
	}*/
	/**
	 * Verifies grocery tag
	 * @param prodContent
	 * @param iaSource
	 * @param id
	 * @param isVarChild
	 * @param prodOffer
	 * @param response
	 */
	/*private void verifyGroceryTag(ProductContent prodContent, IaSourceById iaSource, String id, Boolean isVarChild, ProductOffer prodOffer,String response)
	{
		com.generated.vos.iasourcebyid.Nutrition iaGrocery=null;
		try {
			iaGrocery = iaSource.getItem().getAttributes().getGrocery().getNutrition();
		} catch (Exception e) {
			iaGrocery=null;
		}

		Nutrition nutritionXML  = prodContent.getNutrition();

		if(nutritionXML==null && iaGrocery==null)
		{
			CompareValuesUtility.logPassed("Grocery", "null","null");
		}
		else if(nutritionXML==null && iaGrocery!=null)
		{
			CompareValuesUtility.logFailed("Grocery", "null","Found in source");
		}
		else if(nutritionXML!=null && iaGrocery==null)
		{
			CompareValuesUtility.logFailed("Grocery", nutritionXML ,"Not Found in source");
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getAllergen()==null?null:nutritionXML.getAllergen().getContent()
					, iaGrocery.getAllergen()==null?null:iaGrocery.getAllergen().getFreeText(),"Allergen");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getGreenInformation()==null?null:nutritionXML.getGreenInformation().getContent(),
					iaGrocery.getGreenInformation()==null?null: iaGrocery.getGreenInformation().getFreeText(),"GreenInformation");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getGuaranteeAnalysis()==null?null:nutritionXML.getGuaranteeAnalysis().getContent()
					, iaGrocery.getGuaranteeAnalysis()==null?null:iaGrocery.getGuaranteeAnalysis().getFreeText(),"GuaranteeAnalysis");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getGuarantees()==null?null:nutritionXML.getGuarantees().getContent()
					,  iaGrocery.getGuarantees()==null?null:iaGrocery.getGuarantees().getFreeText(),"Guarantees");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getHtmlLabel()==null?null:nutritionXML.getHtmlLabel().getContent()
					, iaGrocery.getHtmlLabel()==null?null:iaGrocery.getHtmlLabel().getFreeText(),"HtmlLabel");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getIndications() ==null?null:nutritionXML.getIndications().getContent()
					, iaGrocery.getIndications()==null?null:iaGrocery.getIndications().getFreeText(),"Indications");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getInstructions() ==null?null:nutritionXML.getInstructions().getContent()
					, iaGrocery.getInstructions()==null?null:iaGrocery.getInstructions().getFreeText(),"Instructions");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getInteractions()==null?null:nutritionXML.getInteractions().getContent()
					, iaGrocery.getInteractions()==null?null:iaGrocery.getInteractions().getFreeText(),"Interactions");

			String expIng = nutritionXML.getIngredients()==null?null:nutritionXML.getIngredients().getContent();

			String actIng = iaGrocery.getIngredients()==null?null:iaGrocery.getIngredients().getFreeText();

			CompareValuesUtility.verifyNullOrEqual("Grocery", expIng
					, actIng,"Ingredients");

			String expectedWar = nutritionXML.getWarnings()==null?null:nutritionXML.getWarnings().getContent();

			String actualWar = iaGrocery.getWarnings()==null?null:iaGrocery.getWarnings().getFreeText();

			CompareValuesUtility.verifyNullOrEqual("Grocery", 
					expectedWar , actualWar ,"Warnings");


			//---------------------

			CompareValuesUtility.addNewMultiValuedFields();

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getAllergen()==null?null:nutritionXML.getAllergen().getDisplayLabel()
							, iaGrocery.getAllergen()==null?null:iaGrocery.getAllergen().getDispLabel(),"Allergen");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getGreenInformation() ==null?null:nutritionXML.getGreenInformation().getDisplayLabel(),
							iaGrocery.getGreenInformation()==null?null: iaGrocery.getGreenInformation().getDispLabel(),"GreenInformation");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getGuaranteeAnalysis()==null?null:nutritionXML.getGuaranteeAnalysis().getDisplayLabel()
							, iaGrocery.getGuaranteeAnalysis()==null?null:iaGrocery.getGuaranteeAnalysis().getDispLabel(),"GuaranteeAnalysis");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getGuarantees() ==null?null:nutritionXML.getGuarantees().getDisplayLabel()
							,  iaGrocery.getGuarantees()==null?null:iaGrocery.getGuarantees().getDispLabel(),"Guarantees");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getHtmlLabel()==null?null:nutritionXML.getHtmlLabel().getDisplayLabel()
							, iaGrocery.getHtmlLabel()==null?null:iaGrocery.getHtmlLabel().getDispLabel(),"HtmlLabel");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getIndications() ==null?null:nutritionXML.getIndications().getDisplayLabel()
							, iaGrocery.getIndications()==null?null:iaGrocery.getIndications().getDispLabel(),"Indications");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getInstructions() ==null?null:nutritionXML.getInstructions().getDisplayLabel()
							, iaGrocery.getInstructions()==null?null:iaGrocery.getInstructions().getDispLabel(),"Instructions");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getInteractions()==null?null:nutritionXML.getInteractions().getDisplayLabel()
							, iaGrocery.getInteractions()==null?null:iaGrocery.getInteractions().getDispLabel(),"Interactions");


			if(!(expIng==null || expIng.isEmpty()) && (actIng==null || actIng.isEmpty()))
			{
				CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
						, nutritionXML.getIngredients()==null?null:nutritionXML.getIngredients().getDisplayLabel()
								, iaGrocery.getIngredients()==null?null:iaGrocery.getIngredients().getDispLabel(),"Ingredients");
			}

			if(!(expectedWar==null || expectedWar.isEmpty())  && (actualWar==null || actualWar.isEmpty()))
			{
				CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
						, nutritionXML.getWarnings()==null?null:nutritionXML.getWarnings().getDisplayLabel()
								, iaGrocery.getWarnings()==null?null:iaGrocery.getWarnings().getDispLabel(),"Warnings");
			}

			CompareValuesUtility.addNewMultiValuedFields();
		}
	}*/

	private String convertUpc(String upc, UpcTypeType upcType) {
		int length = 0;
		if(upcType.value().equals(UpcTypeType.VALUE_0.value())){
			length = 12;
		}else if(upcType.value().equals(UpcTypeType.VALUE_1.value()) || ( upcType!=null && upcType.toString().equals(UpcTypeType.VALUE_2.value()))){
			length = 8;
		}else if(upcType.value().equals(UpcTypeType.VALUE_3.value())){
			length = 13;
		}else if(upcType.value().equals(UpcTypeType.VALUE_7.value())){
			length = 14;
		}		
		return upc.length()>length?upc.substring(upc.length()-length):StringUtils.leftPad(upc, length, "0");
	}

	/*private void verifySites(com.generated.vos.productoffering.Site[] xmlSites, List<com.generated.vos.acmesourcebyid.Site> acmeSites ){
		for(Site xmlSite : xmlSites) {
			if(!(acmeSites.size()==0)) {
				Boolean bSiteFound=false;
				for each site in IA source
				for(com.generated.vos.acmesourcebyid.Site acmeSite : acmeSites) {
					if(xmlSite.getId().toString().equals(acmeSite.getId())) {
						compareValues("SiteId", xmlSite.getId().toString(), acmeSite.getId(), "SiteId");
						for each hierarchy id under xml site
						for(Hierarchy xmlHier : xmlSite.getTaxonomy().getHierarchy()) {
							if(!(acmeSite.getTaxonomy().size()==0)) {
								Boolean hierFoundInIA=false;
								for each hierarchy id under IA source site
								for(com.generated.vos.acmesourcebyid.Taxonomy acmeSrcTxn : acmeSite.getTaxonomy()) {
									if(xmlHier.getId().toString().equals(acmeSrcTxn.getHierarchy().getId())) {
										compareValues("Hierarchy", xmlHier.getId(), acmeSrcTxn.getHierarchy().getId(), "HierarchyId");
										compareValues("Hierarchy", xmlHier.getPrimary(), acmeSrcTxn.getHierarchy().getPrimary(), "Primary");
										hierFoundInIA=true;
										break;
									}
								}
								if(!hierFoundInIA) {
									compareValues("Hierarchy", xmlHier.getId(), null, "HierarchyId");
								}
							}else{
								compareValues("Hierarchy", xmlHier.getId(), null, "HierarchyId");
							}
						}
						bSiteFound=true;
						break;
					}
				}
				if(!bSiteFound) {
					compareValues("SiteId", xmlSite.getId().toString(), null, "SiteId");
				}
			}else{
				compareValues("Sites", xmlSite.getId().toString(), null, "SiteId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}*/

	private void verifySites1(com.generated.vos.productoffering.Site[] xmlSites, List<com.generated.vos.acmesourcebyid.Site> acmeSites ){
		String siteIds =  JsonStringParser.getJsonValueNew(response, "item.attributes.sites.id",true);
		String[] siteIdsSplit = siteIds.split(";");

		for(Site xmlSite : xmlSites){
			if(!(siteIdsSplit.length ==0)) {

				Boolean bSiteFound=false;
				/*for each site in IA source*/
				for(int i=0; i< siteIdsSplit.length; i++) {
					siteIdsSplit[i] = siteIdsSplit[i].replaceAll("\"", "");
					if(xmlSite.getId().toString().equals(siteIdsSplit[i])) {
						bSiteFound = true;

						compareValues("SiteId", xmlSite.getId().toString(), siteIdsSplit[i], "SiteId");

						//Verify hierarchies
						String hierarchies = JsonStringParser.getJsonValueNew(response, "item.attributes.sites["+i+"].taxonomy.hierarchy");
						//System.out.println("IA hierarchies for" + partNumberToTest+ " : "+ xmlSite.getId()+"  "+hierarchies);
						String[] ids = JsonStringParser.getJsonValueNew(hierarchies,"id").split(";");

						String[] primaryVals = JsonStringParser.getJsonValueNew(hierarchies,"primary").split(";");
						for(Hierarchy xmlhierarchy : xmlSite.getTaxonomy().getHierarchy()){
							boolean bHierarchyFound = false;
							if(!(ids == null || ids.length == 0)){
								for(int iHierarchy = 0; iHierarchy < ids.length; iHierarchy++){
									String iaHierarchyId = ids[iHierarchy].replaceAll("\"", "");
									if(xmlhierarchy.getId().toString().equals(iaHierarchyId)){
										bHierarchyFound = true;
										compareValues("Hierarchy", xmlhierarchy.getId().toString(),iaHierarchyId, "Id");
										compareValues("Hierarchy", xmlhierarchy.getPrimary().toString(), primaryVals[iHierarchy].replaceAll("\"", ""), "Primary");
										break;
									}
								}
								if(!bHierarchyFound){
									compareValues("Hierarchy", xmlhierarchy.getId(), null, "HierarchyId");
								}
							}else{
								compareValues("Hierarchy", xmlhierarchy.getId(), null, "HierarchyId");		
							}

						}
						break;
					}

				}
				if(!bSiteFound) {
					compareValues("SiteId", xmlSite.getId().toString(), null, "SiteId");
				}

			}else{
				compareValues("Sites", xmlSite.getId().toString(), null, "SiteId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();


	}





	private ProductContent getContentToTest() {
		if(bSingleProductOffer){			
			partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getSpinUniqueId();	
			return singleProductOffer.getProductContent();
		}else if(isVarChild){
			partNumberToTest = varChild.getSpinUniqueId();
			return varProdOffer.getProductContent();
		}else {
			partNumberToTest = varProdOffer.getVariationGroupId();
			return varProdOffer.getProductContent();
		}
	}



	private ProductOffer getOfferToTest() {
		if(bSingleProductOffer){			
			partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getSpinUniqueId();
			ProductOffer productOffer = singleProductOffer.getProductOfferings().getProductOffer(0);
			setContentEligibility(productOffer, singleProductOffer.getProductContent(),isVarChild);
			return productOffer;
		}else {

			setContentEligibility(varChild, varProdOffer.getProductContent(),isVarChild);
			if(isVarChild){
				partNumberToTest = varChild.getSpinUniqueId();
				return varChild;
			}
			else {
				partNumberToTest = varProdOffer.getVariationGroupId();
				return getVariationPrimaryOffer(varProdOffer);
			}
		}
	}

	/**
	 * Content eligibilty is true if there item has both sears and kmart partnummber under a single spin id
	 * or it is a cross formatted item
	 * @param productOffer
	 * @param prodContent
	 */
	private void setContentEligibility(ProductOffer productOffer, ProductContent prodContent,Boolean isVarChild){
		if(productOffer != null && productOffer.getPartNumber()!=null && productOffer.getPartNumber().getSearsPartNumber() != null 
				&& productOffer.getPartNumber().getKmartPartNumber() !=null ){
			bContentEligExp = true;
			return;
		}
		//Variation item P item
		if(productOffer == null && bSingleProductOffer == false){
			for(ProductOffer xmlOffer : varProdOffer.getProductOfferings().getProductOffer()){
				if(xmlOffer.getPartNumber().getSearsPartNumber() != null  && xmlOffer.getPartNumber().getKmartPartNumber() != null){
					bContentEligExp = true;
					return;
				}
			}

			Set<Long> sites = new HashSet<>();
			for(Site site : prodContent.getSite()){
				sites.add(site.getId());
				if(sites.contains(1L) && sites.contains(2L)){
					bContentEligExp  = true;
					return;
				}
			}
		}

		if(productOffer!=null && productOffer.getSite()!=null )
		{
			Set<Long> sites = new HashSet<>();
			for(Site site : productOffer.getSite()){
				sites.add(site.getId());
				if(sites.contains(1L) && sites.contains(2L)){
					bContentEligExp  = true;
					return;
				}
			}
		}

		//Daffy - sites needs to checked at offer level
		/*Set<Long> sites = new HashSet<>();
		for(Site site : prodContent.getSite()){
			sites.add(site.getId());
				if(sites.contains(1L) && sites.contains(2L)){
					bContentEligExp  = true;
					return;
			}
		}*/
	}

	private ProductOffer getVariationPrimaryOffer(VariationProductOffer variationProdOffer) {
		ProductOffer primaryOffering = null;
		if (!(variationProdOffer.getProductOfferings() == null)
				&& null == variationProdOffer.getProductOfferings().getProductOffer(0).getRank()) {
			primaryOffering = variationProdOffer.getProductOfferings().getProductOffer(0);
		} else if (!(variationProdOffer.getProductOfferings() == null)) {
			Long rank = variationProdOffer.getProductOfferings().getProductOffer(0).getRank();
			primaryOffering = variationProdOffer.getProductOfferings().getProductOffer(0);
			for (ProductOffer offering : variationProdOffer.getProductOfferings().getProductOffer()) {
				if (offering.getRank() <= rank) {
					primaryOffering = offering;
					rank = offering.getRank();
				}
			}
		} else {
			primaryOffering = variationProdOffer.getProductOfferings()
					.getProductOffer(0);
		}
		return primaryOffering;
	}


}


/*private void verifyCuratedConts(CuratedContents xmlCurGrps, List<CuratedGroup> iaSrcCurGrps) 
{
	if(xmlCurGrps!=null) {
		for each cur grp in xml
		for(com.generated.vos.productoffering.CuratedGroup xmlCurGrp : xmlCurGrps.getCuratedGroup()) {
			if(!(iaSrcCurGrps.size()==0)) {
				Boolean curGrpFoundInIA=false;
				for each cur grp in IA source
				for(CuratedGroup iaSrcCurGrp : iaSrcCurGrps) {
					if((xmlCurGrp.getRank()==null?"":xmlCurGrp.getRank().toString()).equals((iaSrcCurGrp.getRank()==null?"":iaSrcCurGrp.getRank())) && 
							xmlCurGrp.getCuratedType().equals(iaSrcCurGrp.getCuratedType())) {
						verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedType(), iaSrcCurGrp.getCuratedType(), "CuratedType");
						verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedGroupName(), iaSrcCurGrp.getName(), "CuratedGrpName");
						verifyNullOrEqual("CuratedGroups", xmlCurGrp.getRank().toString(), iaSrcCurGrp.getRank(), "Rank");
						if(xmlCurGrp.getCuratedContentCount()>0) {
							for each cur content under cur grp in xml
							for(CuratedContent xmlCurCon : xmlCurGrp.getCuratedContent()) {
								if(!(iaSrcCurGrp.getCuratedContents().size()==0)) {
									Boolean curContFoundInIA=false;
									for each cur cont under cur grp in IA source
									for(com.generated.vos.iasourcebyid.CuratedContent iaSrcCurCon : iaSrcCurGrp.getCuratedContents()) {
										if(xmlCurCon.getContentType()!=null && xmlCurCon.getContentType().equals(iaSrcCurCon.getType())) {
											if(((xmlCurCon.getContentType().equals("asset")||xmlCurCon.getContentType().equals("article")||xmlCurCon.getContentType().equals("url")) 
													&& xmlCurCon.getAsset().getUrl().equals(iaSrcCurCon.getAsset().getUrl())) ||
													(xmlCurCon.getContentType().equals("copy")||xmlCurCon.getContentType().equals("text")) 
													&& xmlCurCon.getData().equals(iaSrcCurCon.getData())) {
												verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentName(), iaSrcCurCon.getName(), "ContentName");
												verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentType(), iaSrcCurCon.getType(), "ContentType");
												verifyNullOrEqual("CuratedGroups", xmlCurCon.getColumn(), iaSrcCurCon.getColumn(), "Column");
												verifyNullOrEqual("CuratedGroups", xmlCurCon.getRow(), iaSrcCurCon.getRow(), "Row");
												verifyNullOrEqual("CuratedGroups", xmlCurCon.getData(), iaSrcCurCon.getData(), "Data");
												Asset xmlAsset = xmlCurCon.getAsset();
												com.generated.vos.iasourcebyid.Asset iaSrcAsset = iaSrcCurCon.getAsset();
												verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getCuratedAssetTypeType(), iaSrcAsset==null?null:iaSrcAsset.getType(), "AssetType");
												verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getName(), iaSrcAsset==null?null:iaSrcAsset.getName(), "AssetName");
												verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getHeight(), iaSrcAsset==null?null:iaSrcAsset.getHeight(), "Height");
												verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getWidth(), iaSrcAsset==null?null:iaSrcAsset.getWidth(), "Width");
												verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getUrl(), iaSrcAsset==null?null:iaSrcAsset.getUrl(), "Url");
												curContFoundInIA=true;
												break;
											}
										}
									}
									if(!curContFoundInIA) {
										verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentName(), null, "ContentName");
										verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentType(), null, "ContentType");
										verifyNullOrEqual("CuratedGroups", xmlCurCon.getColumn(), null, "Column");
										verifyNullOrEqual("CuratedGroups", xmlCurCon.getRow(), null, "Row");
										verifyNullOrEqual("CuratedGroups", xmlCurCon.getData(), null, "Data");
										Asset xmlAsset = xmlCurCon.getAsset();
										verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getCuratedAssetTypeType(), null, "AssetType");
										verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getName(), null, "AssetName");
										verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getHeight(), null, "Height");
										verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getWidth(), null, "Width");
										verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getUrl(), null, "Url");
									}
								}else {
									verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentName(), null, "ContentName");
									verifyNullOrEqual("CuratedGroups", xmlCurCon.getContentType(), null, "ContentType");
									verifyNullOrEqual("CuratedGroups", xmlCurCon.getColumn(), null, "Column");
									verifyNullOrEqual("CuratedGroups", xmlCurCon.getRow(), null, "Row");
									verifyNullOrEqual("CuratedGroups", xmlCurCon.getData(), null, "Data");
									Asset xmlAsset = xmlCurCon.getAsset();
									verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getCuratedAssetTypeType(), null, "AssetType");
									verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getName(), null, "AssetName");
									verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getHeight(), null, "Height");
									verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getWidth(), null, "Width");
									verifyNullOrEqual("CuratedGroups", xmlAsset==null?null:xmlAsset.getUrl(), null, "Url");
								}
							}
						}
						curGrpFoundInIA=true;
						break;
					}
				}if(!curGrpFoundInIA) {
					verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedType(), null, "CuratedType");
					verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedGroupName(), null, "CuratedGrpName");
					verifyNullOrEqual("CuratedGroups", xmlCurGrp.getRank(), null, "Rank");
				}
			}else{
				verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedType(), null, "CuratedType");
				verifyNullOrEqual("CuratedGroups", xmlCurGrp.getCuratedGroupName(), null, "CuratedGrpName");
				verifyNullOrEqual("CuratedGroups", xmlCurGrp.getRank(), null, "Rank");
			}
		}
	}else{
		verifyNullOrEqual("CuratedGroups", null, iaSrcCurGrps.size()==0?null:"CuratedGrp found in IA", "CuratedType");
		verifyNullOrEqual("CuratedGroups", null, iaSrcCurGrps.size()==0?null:"CuratedGrp found in IA", "CuratedGrpName");
		verifyNullOrEqual("CuratedGroups", null, iaSrcCurGrps.size()==0?null:"CuratedGrp found in IA", "Rank");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/

/*private void verifyFeatureImage(FeatureImages xmlFeatImgs, List<FeatureImage> iaSrcFeatImgs) {
	if(xmlFeatImgs!=null) {
		for each feat img in xml
		for(com.generated.vos.productoffering.FeatureImage xmlFeatImg : xmlFeatImgs.getFeatureImage()) {
			if(!(iaSrcFeatImgs.size()==0)) {
				Boolean featImgFoundInIA=false;
				for each feat img in IA source
				for(FeatureImage iaSrcFeatImg : iaSrcFeatImgs) {
					if(IngestCommons.convertImageUrl(xmlFeatImg.getImageElementsGroup().getUrl()).equals(iaSrcFeatImg.getUrl())) {
						compareValues("FeatureImg", IngestCommons.convertImageUrl(xmlFeatImg.getImageElementsGroup().getUrl()), iaSrcFeatImg.getUrl(), "Url");
						verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getHeight(), iaSrcFeatImg.getHeight(), "Height");
						verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getWidth(), iaSrcFeatImg.getWidth(), "Width");
						verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getName(), iaSrcFeatImg.getName(), "Name");
						verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank()==0?null:xmlFeatImg.getRank(), iaSrcFeatImg.getRank(), "Rank");
						featImgFoundInIA=true;
						break;
					}
				}if(!featImgFoundInIA) {
					compareValues("FeatureImg", IngestCommons.convertImageUrl(xmlFeatImg.getImageElementsGroup().getUrl()), null, "Url");
					verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getHeight(), null, "Height");
					verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getWidth(), null, "Width");
					verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getName(), null, "Name");
					verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank()==0?null:xmlFeatImg.getRank(), null, "Rank");
				}
			}else{
				compareValues("FeatureImg", IngestCommons.convertImageUrl(xmlFeatImg.getImageElementsGroup().getUrl()), null, "Url");
				verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getHeight(), null, "Height");
				verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getWidth(), null, "Width");
				verifyNullOrEqual("FeatureImg", xmlFeatImg.getImageElementsGroup().getName(), null, "Name");
				verifyNullOrEqual("FeatureImg", xmlFeatImg.getRank()==0?null:xmlFeatImg.getRank(), null, "Rank");
			}
		}
	}else{
		verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Url");
		verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Height");
		verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Width");
		verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Name");
		verifyNullOrEqual("FeatureImg", null, iaSrcFeatImgs.size()==0?null:"Feat Img found in IA source", "Rank");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/



/*private void verifyContentExtns(ContentExtensions xmlContExts, List<ContentExt> iaSrcContExts) {
	if(xmlContExts!=null) {
		for each content extension in xml
		for(Provider xmlContExt : xmlContExts.getProvider()) {
			if(!(iaSrcContExts.size()==0)) {
				Boolean contExtFoundInIA=false;
				for each content extension in IA source
				for(ContentExt iaSrcContExt : iaSrcContExts) {
					if(xmlContExt.getName().equals(iaSrcContExt.getName()) && xmlContExt.getType().equals(iaSrcContExt.getType())) {
						compareValues("ContentExt", xmlContExt.getName(), iaSrcContExt.getName(), "Name");
						compareValues("ContentExt", xmlContExt.getType(), iaSrcContExt.getType(), "Type");
						if(xmlContExt.getDataCount()>0) {
							for each data under xml content ext provider
							for(Data xmlData : xmlContExt.getData()) {
								if(!(iaSrcContExt.getData().size()==0)) {
									Boolean provDataFoundInIA=false;
									for each data under IA source content ext provider
									for(Datum iaSrcData : iaSrcContExt.getData()){
										if(xmlData.getKey().equals(iaSrcData.getKey()) && xmlData.getValue().equals(iaSrcData.getValue())) {
											compareValues("ContentExt", xmlData.getKey(), iaSrcData.getKey(), "Key");
											compareValues("ContentExt", xmlData.getValue(), iaSrcData.getValue(), "Value");
											provDataFoundInIA=true;
											break;
										}
									}
									if(!provDataFoundInIA) {
										compareValues("ContentExt", xmlData.getKey(), null, "Key");
										compareValues("ContentExt", xmlData.getValue(), null, "Value");
									}
								}else{
									compareValues("ContentExt", xmlData.getKey(), null, "Key");
									compareValues("ContentExt", xmlData.getValue(), null, "Value");
								}
							}
						}else{
							CompareValuesUtility.verifyNull("ContentExt", iaSrcContExt.getData()==null||iaSrcContExt.getData().isEmpty()?null:"Data found in IA", "Key");
							CompareValuesUtility.verifyNull("ContentExt", iaSrcContExt.getData()==null||iaSrcContExt.getData().isEmpty()?null:"Data found in IA", "Value");
						}
						contExtFoundInIA=true;
						break;
					}
				}
				if(!contExtFoundInIA) {
					compareValues("ContentExt", xmlContExt.getName(), null, "Name");
					compareValues("ContentExt", xmlContExt.getType(), null, "Type");
				}
			}else{
				compareValues("ContentExt", xmlContExt.getName(), null, "Name");
				compareValues("ContentExt", xmlContExt.getType(), null, "Type");
			}
		}
	}else{
		verifyNullOrEqual("ContentExt", null, iaSrcContExts.size()==0?null:"Content Ext found in IA", "Name");
		verifyNullOrEqual("ContentExt", null, iaSrcContExts.size()==0?null:"Content Ext found in IA", "Type");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/

/*private void verifyProdAssets(ProductAssets xmlPrdAssets, List<ProductAsset> iaSrcPrdAssets) {
	if(xmlPrdAssets!=null) {
		for each asset in xml
		for(com.generated.vos.productoffering.ProductAsset xmlPrdAsset : xmlPrdAssets.getProductAsset()) {
			if(!(iaSrcPrdAssets.size()==0)) {
				Boolean assetFoundInIA=false;
				for each asset in IA source
				for(ProductAsset iaSrcPrdAsset : iaSrcPrdAssets) {
					if(xmlPrdAsset.getType().name().equals(iaSrcPrdAsset.getType()) && IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()).equals(iaSrcPrdAsset.getUrl())) {
						compareValues("ProductAsset", xmlPrdAsset.getType().name(), iaSrcPrdAsset.getType(), "Type");
						compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), iaSrcPrdAsset.getUrl(), "Url");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), iaSrcPrdAsset.getName(), "Name");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), iaSrcPrdAsset.getHeight(), "Height");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), iaSrcPrdAsset.getWidth(), "Width");
						verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank()==null?"null":xmlPrdAsset.getRank(),
								iaSrcPrdAsset.getRank()==null?"null":iaSrcPrdAsset.getRank(), "Rank");
						assetFoundInIA=true;
						break;
					}
				}
				if(!assetFoundInIA) {

					compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), "Name+URL combination not found");

					//compareValues("ProductAsset", xmlPrdAsset.getType().name(), "Name+URL combination not found", "Type");
					compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), "Name+URL combination not found", "Url");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), "Name+URL combination not found", "Name");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), "Name+URL combination not found", "Height");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), "Name+URL combination not found", "Width");
					verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank(), "Name+URL combination not found", "Rank");
				}
			}else{
				compareValues("ProductAsset", xmlPrdAsset.getType().name(), null, "Type");
				compareValues("ProductAsset", IngestCommons.convertAssetUrl(xmlPrdAsset.getUrl()), null, "Url");
				verifyNullOrEqual("ProductAsset", xmlPrdAsset.getName(), null, "Name");
				verifyNullOrEqual("ProductAsset", xmlPrdAsset.getHeight(), null, "Height");
				verifyNullOrEqual("ProductAsset", xmlPrdAsset.getWidth(), null, "Width");
				verifyNullOrEqual("ProductAsset", xmlPrdAsset.getRank(), null, "Rank");
			}
		}
	}else{
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Type");
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Url");
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Name");
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Height");
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Width");
		verifyNullOrEqual("ProductAsset", null, iaSrcPrdAssets.size()==0?null:"Asset Found in IA Source", "Rank");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/

/*private void verifyPrimaryImage(PrimaryImage xmlPriImg, List<com.generated.vos.iasourcebyid.PrimaryImage> iaSrcPriImg) {
	if(xmlPriImg!=null) {
		if(iaSrcPriImg!=null){
			compareValues("PrimaryImg", IngestCommons.convertImageUrl(xmlPriImg.getImageElementsGroup().getUrl()), iaSrcPriImg.get(0).getUrl(), "Url");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getHeight(), iaSrcPriImg.get(0).getHeight(), "Height");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getWidth(), iaSrcPriImg.get(0).getWidth(), "Width");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getName(), iaSrcPriImg.get(0).getName(), "Name");
		}else{
			compareValues("PrimaryImg", IngestCommons.convertImageUrl(xmlPriImg.getImageElementsGroup().getUrl()), "Not found", "Url");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getHeight(), "Not found", "Height");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getWidth(), "Not found", "Width");
			verifyNullOrEqual("PrimaryImg", xmlPriImg.getImageElementsGroup().getName(), "Not found", "Name");
		}	
	}else{
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getUrl(), "Url");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getHeight(), "Height");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getWidth(), "Width");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getName(), "Name");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/

/*private void verifyPrimaryImage(ImageUrl imageUrl, List<com.generated.vos.iasourcebyid.PrimaryImage> iaSrcPriImg) {
	if(imageUrl!=null) {
		if(iaSrcPriImg!=null){
			compareValues("PrimaryImg", IngestCommons.convertImageUrl(imageUrl.getImageElementsGroup().getUrl()), iaSrcPriImg.get(0).getUrl(), "Url");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getHeight(), iaSrcPriImg.get(0).getHeight(), "Height");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getWidth(), iaSrcPriImg.get(0).getWidth(), "Width");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getName(), iaSrcPriImg.get(0).getName(), "Name");
		}else{
			compareValues("PrimaryImg", IngestCommons.convertImageUrl(imageUrl.getImageElementsGroup().getUrl()), "Not found", "Url");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getHeight(), "Not found", "Height");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getWidth(), "Not found", "Width");
			verifyNullOrEqual("PrimaryImg", imageUrl.getImageElementsGroup().getName(), "Not found", "Name");
		}	
	}else{
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getUrl(), "Url");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getHeight(), "Height");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getWidth(), "Width");
		verifyNullOrEqual("PrimaryImg", null, iaSrcPriImg==null?null:iaSrcPriImg.get(0).getName(), "Name");
	}
	CompareValuesUtility.addNewMultiValuedFields();
}*/

/*private void verifySeo(Seo xmlSeo, com.generated.vos.iasourcebyid.Seo iaSourceSeo) {
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoRobotFollowFlag(), iaSourceSeo==null?null:iaSourceSeo.getRobotFollowFlag(), "RobotFollow");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoRobotIndexFlag(), iaSourceSeo==null?null:iaSourceSeo.getRobotIndexFlag(), "RobotIndex");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoFeatureAltTag(), iaSourceSeo==null?null:iaSourceSeo.getFeatureAltTag(), "FeatureAlt");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoProductAltTag(), iaSourceSeo==null?null:iaSourceSeo.getProductAltTag(), "ProdAlt");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoTitle(), iaSourceSeo==null?null:iaSourceSeo.getTitle(), "Title");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoMetaDescription(), iaSourceSeo==null?null:iaSourceSeo.getMetaDescription(), "MetaDesc");
	verifyNullOrEqual("SEO", xmlSeo==null?null:xmlSeo.getSeoUrl(), iaSourceSeo==null?null:iaSourceSeo.getUrl(), "Url");	
	CompareValuesUtility.addNewMultiValuedFields();
}*/
