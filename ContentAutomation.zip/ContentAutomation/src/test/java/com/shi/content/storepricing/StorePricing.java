
package com.shi.content.storepricing;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * Price details of the item, id will be storeID-div-item , for clearance items price will be stored at storeID-div-itemsku level , else all other will be stored on div-item level only
 * 
 */
@Generated("org.jsonschema2pojo")
public class StorePricing {

    /**
     * storeId value, for national price store id will be 0009300 else it will be regional storeId
     * 
     */
    @Expose
    private String sid;
    
    @Expose
    private String pid;
    
    /**
     * DIV-ITEM/ DIV-ITEM-SKU value, DIM-ITEM will be of 8 digit while DIV-ITEM-SKU will be of 11 digit
     * 
     */
    @Expose
    private Double pricingKey;
    /**
     * store level price of an item,details of all price types
     * 
     * (Required)
     * 
     */
    @Expose
    private P p;
    /**
     * details of all price types
     * 
     * (Required)
     * 
     */
    @Expose
    private Dp dp;
    /**
     * competitor price for an item
     * (Required)
     * 
     */
    @Expose
    private List<Cp> cp =   new ArrayList<Cp>();;
    /**
     * lists the schema details
     * (Required)
     * 
     */
    @Expose
    private Meta meta;

    /**
     * storeId value, for national price store id will be 0009300 else it will be regional storeId
     * 
     */
    public String getSid() {
        return sid;
    }
    
    
    public String getPid() {
        return pid;
    }

    /**
     * storeId value, for national price store id will be 0009300 else it will be regional storeId
     * 
     */
    public void setSid(String sid) {
        this.sid = sid;
    }
    
    public void setPid(String pid) {
        this.pid = pid;
    }

    /**
     * DIV-ITEM/ DIV-ITEM-SKU value, DIM-ITEM will be of 8 digit while DIV-ITEM-SKU will be of 11 digit
     * 
     */
    public Double getPricingKey() {
        return pricingKey;
    }

    /**
     * DIV-ITEM/ DIV-ITEM-SKU value, DIM-ITEM will be of 8 digit while DIV-ITEM-SKU will be of 11 digit
     * 
     */
    public void setPricingKey(Double pricingKey) {
        this.pricingKey = pricingKey;
    }

    /**
     * store level price of an item,details of all price types
     * 
     * (Required)
     * 
     */
    public P getP() {
        return p;
    }

    /**
     * store level price of an item,details of all price types
     * 
     * (Required)
     * 
     */
    public void setP(P p) {
        this.p = p;
    }

    /**
     * details of all price types
     * 
     * (Required)
     * 
     */
    public Dp getDp() {
        return dp;
    }

    /**
     * details of all price types
     * 
     * (Required)
     * 
     */
    public void setDp(Dp dp) {
        this.dp = dp;
    }

    /**
     * competitor price for an item
     * (Required)
     * 
     */
    public List<Cp> getCp() {
        return cp;
    }

    /**
     * competitor price for an item
     * (Required)
     * 
     */
    public void setCp(List<Cp> cp) {
        this.cp = cp;
    }

    /**
     * lists the schema details
     * (Required)
     * 
     */
    public Meta getMeta() {
        return meta;
    }

    /**
     * lists the schema details
     * (Required)
     * 
     */
    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
