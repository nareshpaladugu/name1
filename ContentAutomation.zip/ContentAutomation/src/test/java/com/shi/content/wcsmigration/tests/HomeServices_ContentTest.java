package com.shi.content.wcsmigration.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.serviceofferings.SingleServiceProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.verifications.HomeServices_ContentVerifications;

public class HomeServices_ContentTest {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="HomeServicesContent"
			,description="Tests to test the homeservices load job.  Verify content collection data.")
	public void testHomeServicesLoad(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
	System.out.println("Testing file : "+ sFileName);
		
		BlockingQueue<List<SingleServiceProductOffer>> serviceOffer = new LinkedBlockingQueue<List<SingleServiceProductOffer>>(); 
		

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleServiceProductOffer> prodThread = new ChunkProducerThread<SingleServiceProductOffer>(sFileName, serviceOffer, SingleServiceProductOffer.class,"single-service-product-offer");
		prodThread.setBucketSize(1);
		Thread producerThread = new Thread(prodThread);
		producerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				
				List<SingleServiceProductOffer> nodeToTest = serviceOffer.poll(20, TimeUnit.SECONDS);
				
				if(nodeToTest == prodThread.POISON_PILL){
					//System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
					pool.execute(new HomeServices_ContentVerifications(nodeToTest.get(0)));
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		

		
		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
}
