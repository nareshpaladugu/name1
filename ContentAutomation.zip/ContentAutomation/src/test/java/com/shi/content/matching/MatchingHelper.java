package com.shi.content.matching;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import org.bson.Document;
import org.codehaus.jackson.map.ObjectMapper;

import com.generated.vos.offer.Offer;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.UpdateResult;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class MatchingHelper extends JFrame 
{
	private JPanel contentPane;
	private JTextField txtOffers;
	private JTextField txtSource;
	private JTextField txtTarget;
	private JTextField txtSourceSpinId;
	private JTextField txtTargetSpinId_1;
	private JTextField txtItemClass;
	private JTextField txtUPC;
	private JTextField txtOffersList;
	private JTextField txtGreen;
	JButton btnMatchIt = null;
	JLabel status = new JLabel("");
	JTextArea textArea_1 = new JTextArea();
	/**
	 * Launch the application.
	 */
	JTextArea textArea = new JTextArea();
	private JTextField txtOfferProd;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MatchingHelper frame = new MatchingHelper();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MatchingHelper() {

		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		btnMatchIt = new JButton("Match It");
		setTitle("Matching Helper");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 935, 661);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		txtOffers = new JTextField();
		txtOffers.setText("05735392000,012V006926794000,SPM6777450513");
		txtOffers.setBounds(93, 39, 523, 20);
		txtOffers.setColumns(10);


		/*JButton btnChangeUpcFor = new JButton("Change UPC for MP");
		btnChangeUpcFor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				LoadProperties.GREENVIP = txtGreen.getText().trim();

				textArea.setText("");

				String offers[] = txtOffers.getText().split(",");

				List<String> os = new ArrayList<String>();

				for (String string : offers) {

					os.add(string);
				}

				Set<String> spinIds = new HashSet<String>();

				List<Offer> offerss = RestExecutor.getDataById(CollectionValuesVal.OFFER, os);

				textArea.append("-----------------------BEFORE-------------------------------\n");

				String sOrKUpc="";

				String sellerId="";
				String mpSpin="";
				String url,resp;

				for (Offer offer : offerss) {

					textArea.append("Offer : "+offer.getId() +" Spin Id : "+offer.getAltIds().getSpinId() + " upc : "+offer.getAltIds().getUpc()+"\n");

					if(offer.getFfm().getSoldBy().equalsIgnoreCase("Sears")||offer.getFfm().getSoldBy().equalsIgnoreCase("Kmart"))
					{
						sOrKUpc = offer.getAltIds().getUpc();
					}
					else
					{
						System.out.println("its MP...");

						sellerId = offer.getMarketplace().getSeller().getId().intValue()+"";
						mpSpin = offer.getAltIds().getSpinId();

						url = "http://sellpovip.prod.ch4.s.com:8080/BatchService/d/api/pull/specific-item/catalog?seller-id="+sellerId+"&item-ids="+mpSpin+"&client=GB";

						resp = RestExecutor.getJSonResponse(url);

						textArea.append(resp);
					}


					spinIds.add(offer.getAltIds().getSpinId());
				}


			}
		});
		btnChangeUpcFor.setBounds(122, 67, 163, 23);
		panel.add(btnChangeUpcFor);*/

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 899, 601);

		JPanel panel1 = new JPanel();
		panel1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel1.setBounds(10, 49, 835, 518);
		//contentPane.add(panel);
		panel1.setLayout(null);


		JPanel panel11 = new JPanel();
		panel11.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel11.setBounds(10, 49, 835, 518);

		tabbedPane.add("Change Fields",panel11);
		panel11.setLayout(null);

		JLabel lblOfferId = new JLabel("MP Offer  Id");
		lblOfferId.setFont(new Font("Calibri", Font.PLAIN, 15));
		lblOfferId.setBounds(10, 50, 85, 14);
		panel11.add(lblOfferId);

		txtOfferProd = new JTextField();
		txtOfferProd.setText("SPM10001605720");
		txtOfferProd.setBounds(92, 47, 315, 20);
		panel11.add(txtOfferProd);
		txtOfferProd.setColumns(10);

		JButton btnLoad = new JButton("Publish");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(!txtOfferProd.getText().trim().isEmpty())
				{

					//fetch();

					if(!textArea_1.getText().isEmpty())
					{
						status.setText("");
						LoadProperties.KAFKABROKER="rtckafka305p.qa.ch3.s.com:9092";
						LoadProperties.ZOOKEEPER="rtckafka305p.qa.ch3.s.com:2181";

						String param[]={LoadProperties.ZOOKEEPER,LoadProperties.KAFKABROKER,"qa-2.0_mpcatalog.RT",textArea_1.getText()};

						com.shi.content.matching.KafkaProducer.publish(param);

						status.setText("PUBLISHED");
						//textArea_1.append("------------------------------- PUBLISHED ------------------ ");

					}
				}

			}

		});
		btnLoad.setBounds(120, 75, 89, 23);
		panel11.add(btnLoad);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(21, 109, 863, 453);
		panel11.add(scrollPane_1);
		textArea_1.setLineWrap(true);


		scrollPane_1.setViewportView(textArea_1);

		JButton btnFetch = new JButton("Fetch");
		btnFetch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				fetch();
			}
		});
		btnFetch.setBounds(21, 75, 89, 23);
		panel11.add(btnFetch);


		status.setForeground(new Color(154, 205, 50));
		status.setFont(new Font("Calibri", Font.PLAIN, 15));
		status.setBounds(223, 78, 184, 14);
		panel11.add(status);
		
		JButton btnMakeItXformat = new JButton("Make it X-Format");
		btnMakeItXformat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String txt = textArea_1.getText();
				
				int ind = txt.indexOf("\"site\"");
				
				txt = txt.replace(txt.substring(ind,txt.indexOf("],",ind+1)+2)
						,"\"site\" : [ {        \"taxo\" : {          \"hier\" : [ {            \"id\" : \"18444610\",            \"primary\" : true          } ]        },        \"id\" : \"2\"      },	  {        \"taxo\" : {          \"hier\" : [ {            \"id\" : \"18403810\",            \"primary\" : true          } ]        },        \"id\" : \"1\"      } ],");
				
				textArea_1.setText("");
				textArea_1.setText(txt);
			}
		});
		btnMakeItXformat.setBounds(427, 46, 123, 23);
		panel11.add(btnMakeItXformat);

		JLabel lblNewLabel = new JLabel("Source Offer Id");
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 59, 84, 14);
		panel1.add(lblNewLabel);

		txtSource = new JTextField();

		txtSource.setText("05772624000");
		txtSource.setBounds(118, 56, 181, 20);
		panel1.add(txtSource);
		txtSource.setColumns(10);

		JLabel lblItemclass = new JLabel("Target Offer Id");
		lblItemclass.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblItemclass.setBounds(10, 98, 84, 14);
		panel1.add(lblItemclass);

		txtTarget = new JTextField();
		txtTarget.setText("SPM10001605720");
		txtTarget.setColumns(10);
		txtTarget.setBounds(118, 95, 181, 20);
		panel1.add(txtTarget);

		JButton btnChangeSource = new JButton("Make ItemClass and UPC Same");
		btnChangeSource.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				txtOffersList.setText(txtSource.getText()+","+txtTarget.getText());
				String source = txtSource.getText().trim();
				String  upc="",itemClassId="";
				if(!source.isEmpty()){

					try {
						Offer srcOffer = RestExecutor.getDataById(CollectionValuesVal.OFFER, source);

						Offer trgOffer = RestExecutor.getDataById(CollectionValuesVal.OFFER, txtTarget.getText().trim());

						String spinId = srcOffer.getAltIds().getSpinId();

						String targetSpinId = trgOffer.getAltIds().getSpinId();

						LoadProperties.gbServer="iaapp3103p.qa.ch3.s.com";
						LoadProperties.gbServerPort="20000";
						LoadProperties.gbUser="iaappuser";
						LoadProperties.gbPassword="1aAppUs3r";

						MongoClient mongo = MongoDBClient.connectToMongoDB("source");

						MongoDatabase db = mongo.getDatabase("source");

						MongoCollection<Document> dbc = db.getCollection("source");

						FindIterable<Document> cursor = dbc.find(new Document("_id",spinId));

						txtSourceSpinId.setText(spinId);
						txtTargetSpinId_1.setText(targetSpinId);

						boolean found=false;
						for (Document document : cursor) 
						{
							found = true;
							upc = ((Document)document.get("attr")).get("upcCode").toString();
							upc = upc.substring(upc.lastIndexOf("=")+1,upc.indexOf("}",upc.lastIndexOf("=")+1));

							itemClassId = ((Document)document.get("attr")).get("itemClassId").toString();
							itemClassId = itemClassId.substring(itemClassId.lastIndexOf("=")+1,itemClassId.indexOf("}",itemClassId.lastIndexOf("=")+1));

							txtUPC.setText(upc);
							txtItemClass.setText(itemClassId);
						}

						if(!found)
						{
							JOptionPane.showMessageDialog(null, "source offer not found in Source DB");
							btnMatchIt.setEnabled(true);
							return;
						}

						long epoch=System.currentTimeMillis();

						UpdateResult res = dbc.updateOne(new Document("_id",targetSpinId), 
								new Document("$set",
										new Document("attr.itemClassId."+epoch,itemClassId)));

						System.out.println("Modified : "+res.getModifiedCount());

						res = dbc.updateOne(new Document("_id",targetSpinId), 
								new Document("$set",
										new Document("attr.upcCode."+epoch,upc)));

						System.out.println("Modified : "+res.getModifiedCount());

						res = dbc.updateOne(new Document("_id",targetSpinId), 
								new Document("$set",
										new Document("clazz",itemClassId)));

						System.out.println("Modified : "+res.getModifiedCount());


						textArea.append("------------DONE-------------------");

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		btnChangeSource.setBounds(10, 136, 289, 23);
		panel1.add(btnChangeSource);

		JLabel lblSpinid = new JLabel("SpinId");
		lblSpinid.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblSpinid.setBounds(319, 56, 84, 14);
		panel1.add(lblSpinid);

		txtSourceSpinId = new JTextField();
		txtSourceSpinId.setEnabled(false);
		txtSourceSpinId.setColumns(10);
		txtSourceSpinId.setBounds(364, 53, 118, 20);
		panel1.add(txtSourceSpinId);

		JLabel txtTargetSpinId = new JLabel("SpinId");
		txtTargetSpinId.setFont(new Font("Calibri", Font.PLAIN, 14));
		txtTargetSpinId.setBounds(319, 95, 84, 14);
		panel1.add(txtTargetSpinId);

		txtTargetSpinId_1 = new JTextField();
		txtTargetSpinId_1.setEnabled(false);
		txtTargetSpinId_1.setColumns(10);
		txtTargetSpinId_1.setBounds(364, 92, 118, 20);
		panel1.add(txtTargetSpinId_1);

		JLabel lblItemclassud = new JLabel("ItemClassId");
		lblItemclassud.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblItemclassud.setBounds(487, 56, 84, 14);
		panel1.add(lblItemclassud);

		txtItemClass = new JTextField();
		txtItemClass.setEnabled(false);
		txtItemClass.setColumns(10);
		txtItemClass.setBounds(556, 53, 128, 20);
		panel1.add(txtItemClass);

		txtUPC = new JTextField();
		txtUPC.setEnabled(false);
		txtUPC.setColumns(10);
		txtUPC.setBounds(748, 53, 118, 20);
		panel1.add(txtUPC);

		JLabel lblUpc = new JLabel("UPC");
		lblUpc.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblUpc.setBounds(708, 56, 84, 14);
		panel1.add(lblUpc);

		JLabel lblCopyItemclassidAnd = new JLabel("Copy itemclassid and upc from source offer to target offer in Source DB");
		lblCopyItemclassidAnd.setForeground(Color.BLUE);
		lblCopyItemclassidAnd.setHorizontalAlignment(SwingConstants.CENTER);
		lblCopyItemclassidAnd.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblCopyItemclassidAnd.setBounds(30, 34, 705, 14);
		panel1.add(lblCopyItemclassidAnd);


		btnMatchIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Thr t = new Thr();
				t.start();
				//processMatch(txtOffersList.getText().trim());
			}
		});
		btnMatchIt.setBounds(10, 226, 289, 23);
		panel1.add(btnMatchIt);

		JLabel lblListOfOffers = new JLabel("List Of Offers to Match");
		lblListOfOffers.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblListOfOffers.setBounds(10, 201, 157, 14);
		panel1.add(lblListOfOffers);

		txtOffersList = new JTextField();
		txtOffersList.setText("SPM10001605720");
		txtOffersList.setColumns(10);
		txtOffersList.setBounds(164, 198, 571, 20);
		panel1.add(txtOffersList);

		JLabel label = new JLabel("GreenVip");
		label.setFont(new Font("Calibri", Font.PLAIN, 16));
		label.setBounds(30, 14, 67, 14);
		panel1.add(label);

		txtGreen = new JTextField();
		txtGreen.setText("green2vip.qa.ch3.s.com:8080");
		txtGreen.setColumns(10);
		txtGreen.setBounds(100, 11, 523, 20);
		panel1.add(txtGreen);

		JLabel lblMatchIt = new JLabel("Match It");
		lblMatchIt.setHorizontalAlignment(SwingConstants.CENTER);
		lblMatchIt.setForeground(Color.BLUE);
		lblMatchIt.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblMatchIt.setBounds(30, 170, 705, 14);
		panel1.add(lblMatchIt);

		Icon icon = new ImageIcon("src/test/resources/match.png");


		tabbedPane.addTab("Match", icon, panel1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 260, 856, 302);
		panel1.add(scrollPane);


		scrollPane.setViewportView(textArea);

		this.setLocationRelativeTo(null);


		contentPane.add(tabbedPane);
	}

	private String  fetch()
	{
		//LoadProperties.GREENVIP="greenvip.prod.ch4.s.com:80";
		
		String jsonAsString = RestExecutor.getJSonResponse("http://greenvip.prod.ch4.s.com:80/gbox/gb/s/data/get/offer/"+txtOfferProd.getText().trim());
		
		Offer o = JSONParser.parseJSONWithBlob(jsonAsString, CollectionValuesVal.OFFER, Offer.class);

		LoadProperties.GREENVIP = txtGreen.getText().trim();
				
		String sellerId = o.getMarketplace().getSeller().getId().intValue()+"";
		String spinId = o.getAltIds().getSpinId();
		String url = "http://sellpovip.prod.ch4.s.com:8080/BatchService/d/api/pull/specific-item/catalog?seller-id="+sellerId
				+"&item-ids="+spinId+"&client=GB";

		String resp = RestExecutor.getJSonResponse(url);

		textArea_1.setText("");
		textArea_1.append(resp);

		try {
			ObjectMapper mapper = new ObjectMapper();
			Object json = mapper.readValue(textArea_1.getText(), Object.class);
			String indented = mapper.defaultPrettyPrintingWriter().writeValueAsString(json);

			textArea_1.setText("");
			textArea_1.append(indented);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return resp;

	}

	private void processMatch(String offersCList)
	{
		btnMatchIt.setEnabled(false);
		System.out.println("Process Match For ..."+offersCList);
		LoadProperties.GREENVIP = txtGreen.getText().trim();

		textArea.setText("");

		String offers[] = offersCList.split(",");

		List<String> os = new ArrayList<String>();

		for (String string : offers) {

			os.add(string);
		}

		Set<String> spinIds = new HashSet<String>();

		List<Offer> offerss = RestExecutor.getDataById(CollectionValuesVal.OFFER, os);
		
		if(offerss==null || offerss.isEmpty())
		{
			JOptionPane.showMessageDialog(null, "Offers Not found in GB");
			return;
		}

		textArea.append("\nOffers Given : "+os.size() + " Found in GB : "+offerss.size());

		for (Offer offer : offerss) {

			textArea.append("Offer : "+offer.getId() +" Spin Id : "+offer.getAltIds().getSpinId() +"\n");
			spinIds.add(offer.getAltIds().getSpinId());
		}

		String url ="";
		String resp = "";

		String guid ="";
		for (String string : spinIds) {

			textArea.append("---------------------------------------------------------\n");

			url="http://iaapp3103p.qa.ch3.s.com:8180/acme/features/"+string+"?refresh=true";

			RestExecutor.getJSonResponse(url);

			textArea.append("Hitting : "+url+"\n");

			url="http://iaapp3103p.qa.ch3.s.com:8180/acme/match/"+string+"?refresh=true";

			resp =  RestExecutor.getJSonResponse(url);

			guid = JsonStringParser.getJsonValueNew(resp, "item.attributes.guid",true);

			textArea.append("Hitting : "+url+"\n");

			url="http://iaapp3103p.qa.ch3.s.com:8180/acme/reconciled/"+guid+"?refresh=true";

			RestExecutor.getJSonResponse(url);

			textArea.append("Hitting : "+url+"\n");

			url= "http://iaapp3103p.qa.ch3.s.com:8180/acme/publisher/idpublish/"+string+"?publish=true";

			textArea.append("Hitting : "+url+"\n");

			RestExecutor.getJSonResponse(url);
		}

		textArea.append("---------------------------------------------------------\n");

		offerss = RestExecutor.getDataById(CollectionValuesVal.OFFER, os);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

		}

		String ssin="";
		for (Offer offer : offerss) {

			ssin= offer.getIdentity().getSsin() ;
			textArea.append("Offer : "+offer.getId() +" ssin : "+offer.getIdentity().getSsin() +"\n");
			spinIds.add(offer.getAltIds().getSpinId());
		}

		textArea.append("---------------------------------------------------------\n");

		List<String> offersForSameSsin = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin", ssin);

		textArea.append("All Offers for ssin : "+ssin+ " are "+offersForSameSsin+"\n");

		textArea.append("-----------------------END------------------------\n");

		btnMatchIt.setEnabled(true);
	}



	class Thr extends Thread
	{
		public void run()
		{

			processMatch(txtOffersList.getText());
		}
	}
}
