package com.shi.content.seotest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.content.Content;
import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class GetSeoUrlsUtil implements Runnable {
	
	String offerId;
	
	public GetSeoUrlsUtil(String offerId) {
		this.offerId = offerId;
	}

	@Test(groups="GetSeoUrlsUtil")
	public void testSearsStorePricing() {

		ArrayList<String> offerIds = null;
		String execMode = LoadProperties.EXECUTION_MODE;
		
		if (execMode.equalsIgnoreCase("FILE")) {
			String files = LoadProperties.LST_FILES;
			String folderPath = LoadProperties.LST_FILES_FOLDER;
			
			if (files == null || files.equals("") || folderPath == null || folderPath.equals("")) {
				System.out.println("Error: Either file names or folder path are empty. Please specify it correctly.");
				return;
			}
			
			String[] lstFiles= files.split(",");
			offerIds = new ArrayList<>();
			
			for(String sFileName : lstFiles){
				sFileName = sFileName.trim();
				offerIds.addAll(getOfferIdsFromFile(folderPath+sFileName));
			}
		} else {
			String runParams = LoadProperties.getProperty("runParams","");
			if (runParams == null || runParams.equals("")) {
				System.out.println("______________________________________________________");
				System.out.println("Error: runParams is not specified");
				System.out.println("______________________________________________________");
				return;
			}
			
			if (execMode.equalsIgnoreCase("LIST")) {
				String[] arr = runParams.split(",");
				offerIds = new ArrayList<>(Arrays.asList(arr));
			} else if (execMode.equalsIgnoreCase("BUCKET")) {
				String[] bucketIds = runParams.split(",");
				offerIds = new ArrayList<>();
				for (String bucketId : bucketIds) {
					List<String> tempOfferList = RestExecutor.getIdsForBucket(CollectionValuesVal.OFFER, Integer.parseInt(bucketId.trim()));
					if (tempOfferList != null && tempOfferList.size() > 0) {
						offerIds.addAll(tempOfferList);
					}
				}
			}	
		}	
			
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		for (String offer : offerIds) {
			try {
				pool.execute(new GetSeoUrlsUtil(offer));
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		CompareValuesUtility.init();
		try {
			if (offerId != null && !offerId.equals("")) {
				APIResponse<Object> allDataById = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerId);
				if (allDataById == null || allDataById.getT() == null) {
					CompareValuesUtility.addDataFieldForReport("Error", "Offer document not present in GB", INFOTYPE.DATA);
				} else {
					System.out.println("Fetching data for offer: "+offerId);
					Offer offerDoc = allDataById.getT();
					String ssin = "";
					String parentId = "";
					
					if (offerDoc.getIdentity() != null) {
						ssin = offerDoc.getIdentity().getSsin();
						parentId = offerDoc.getIdentity().getParentId();
					} else {
						throw new Exception("Identity tag not present in Offer document");
					}
					
					String itemId = "";
					if (offerDoc.getAltIds() != null) {
						itemId = offerDoc.getAltIds().getSpinId();	
					}
					
					CompareValuesUtility.addDataFieldForReport("Offer Id", offerId, INFOTYPE.DATA);
					CompareValuesUtility.addDataFieldForReport("Spin Id", itemId, INFOTYPE.DATA);
					CompareValuesUtility.addDataFieldForReport("Parent Id", parentId, INFOTYPE.DATA);
					CompareValuesUtility.addDataFieldForReport("SSIN", ssin, INFOTYPE.DATA);

					List<String> sites = offerDoc.getSites(); 
					
					List<String> seoUrlBasedOnParentId = null;
					if (parentId != null && !parentId.equals("")) {
						seoUrlBasedOnParentId = getFinalSeoURLs(parentId,sites);
						if (seoUrlBasedOnParentId != null && seoUrlBasedOnParentId.size() > 0) {
							CompareValuesUtility.addDataFieldForReport("Seo URL Based On Parent Id", seoUrlBasedOnParentId.get(0), INFOTYPE.DATA);
						}	
					} else {
						CompareValuesUtility.addDataFieldForReport("Seo URL Based On Parent Id", "Parent Id field not present in Offer document", INFOTYPE.DATA);
					}
					
					List<String> seoUrlBasedOnSSIN = null;
					
					if (ssin != null && !ssin.equals("")) {
						seoUrlBasedOnSSIN = getFinalSeoURLs(ssin,sites);
						if (seoUrlBasedOnSSIN != null && seoUrlBasedOnSSIN.size() > 0) {
							CompareValuesUtility.addDataFieldForReport("Seo URL Based On SSIN", seoUrlBasedOnSSIN.get(0), INFOTYPE.DATA);
						}	
						
						List<String> list = getGroupedItems(ssin);
						if (list == null || list.size() == 0) {
							CompareValuesUtility.addDataFieldForReport("Offer Count", "0", INFOTYPE.DATA);
						} else {
							CompareValuesUtility.addDataFieldForReport("Offer Count", ""+list.size(), INFOTYPE.DATA);
						}
					} else {
						CompareValuesUtility.addDataFieldForReport("Seo URL Based On SSIN", "SSIN field not present in Offer document", INFOTYPE.DATA);
					}
					
					if (seoUrlBasedOnParentId != null && seoUrlBasedOnParentId.size() > 1) {
						CompareValuesUtility.addDataFieldForReport("Seo URL Based On Parent Id", seoUrlBasedOnParentId.get(1), INFOTYPE.DATA);
					}
					
					if (seoUrlBasedOnSSIN != null && seoUrlBasedOnSSIN.size() > 1) {
						CompareValuesUtility.addDataFieldForReport("Seo URL Based On SSIN", seoUrlBasedOnSSIN.get(1), INFOTYPE.DATA);
					}
				}
			} 
		} catch (Exception e) {
			CompareValuesUtility.addDataFieldForReport("Error", e.getMessage(), INFOTYPE.DATA);
		}
		
		CompareValuesUtility.setupResult(offerId, true);
		CompareValuesUtility.teardown();
	}

	public List<String> getGroupedItems(String ssin) {
		List<String> list = new ArrayList<>();
		list = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin", ssin);
		return list;
	}
	
	public List<String> getFinalSeoURLs(String contentId, List<String> sites) {
		List<String> list = new ArrayList<>();
		String finalURL = "";
		APIResponse<Object> allDataById2 = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, contentId);
		if (allDataById2 == null || allDataById2.getT() == null) {
			finalURL = "Content "+contentId+" is not present in GB";
			list.add(finalURL);
		} else {
			Content contentDoc = allDataById2.getT();
			if (contentDoc.getSeo() == null) {
				finalURL = "Seo tag is missing in content doc "+contentId;
				list.add(finalURL);
			} else {
				String seoUrl = contentDoc.getSeo().getUrl();
				String baseUrl = "";
				
				String uiEnv = LoadProperties.getProperty("UI_ENV","");
				
				for (String site : sites) {
					if (site.equalsIgnoreCase("sears") || site.equalsIgnoreCase("kmart")) {
						if (uiEnv.equalsIgnoreCase("PROD")) {
							baseUrl = "http://www."+site.toLowerCase()+".com";
						} else {
							baseUrl = "http://"+uiEnv.toLowerCase()+".ecom."+site.toLowerCase()+".com";
						}
						
						finalURL = baseUrl+seoUrl+"/p-"+contentId;
						list.add(finalURL);
					}
				}
			}
		}
		return list;
	}
	
	public List<String> getOfferIdsFromFile(String filePath) {
		List<String> list = new ArrayList<>();
		String scannedLine;
		BufferedReader br = null;
		try {
			FileReader file = new FileReader(filePath);
			br = new BufferedReader(file);
			while (!((scannedLine = br.readLine()) == null)) {
				list.add(scannedLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try { br.close(); } catch (IOException e) {e.printStackTrace();}
		}
		return list;
	}
}