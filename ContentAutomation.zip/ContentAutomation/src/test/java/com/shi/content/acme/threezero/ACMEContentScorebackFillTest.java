package com.shi.content.acme.threezero;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.contentscoreMsg.ContentscoreMsg;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;

public class ACMEContentScorebackFillTest {

	@Test(description="Tests to read from contentscore queue and validate ACME contentscore collection",
			groups="ACMEContentScorebackFillTest")
	public void aCMEContentScoreRealTimeIngest() throws Exception {

		System.out.println("aCMEContentScoreRealTimeIngest.............. started..");

		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		String csvFile = LoadProperties.LST_FILES_FOLDER+"/"+LoadProperties.LST_FILES;

		System.out.println("csvFile... "+csvFile);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";


		int account_id=0;
		int content_item_class_id=1;
		int  item_id=2;
		int attribute_Completeness=3;
		int short_desc=4;
		int long_desc=5;
		int title_consistency=6;
		int primary_image=7;
		int alt_1=8;
		int alt_2=9;
		int alt_3=10;
		int alt_4=11;
		int alt_5=12;
		int alt_6=13;
		int tec_timestamp=14;

		try {

			String sp[];
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				//account_id,content_item_class_id,item_id,attribute_Completeness,short_desc,long_desc,title_consistency,primary_image,alt_1,alt_2,alt_3,alt_4,alt_5,alt_6,tec_timestamp

				sp = line.split(cvsSplitBy);
				
				//10000101,1103,798542412,0.53,0.8,0.0,1.0,0.67,\N,\N,\N,\N,\N,\N,2016-10-17 12:07:51


				ContentscoreMsg contentscoreMsg = new ContentscoreMsg();

				if("account_id".equals(sp[account_id]))
				{
					System.out.println("Skipping header part...");
					continue;
				}
				System.out.println("item id : "+contentscoreMsg);

				contentscoreMsg.setAccountID(getStrValue(sp[account_id]));
				contentscoreMsg.setItemClassID(getStrValue(sp[content_item_class_id]));
				contentscoreMsg.setItemID(getStrValue(sp[item_id]));
				contentscoreMsg.setATBRCOMPLETENESS(getStrValue(sp[attribute_Completeness]));
				contentscoreMsg.setSHORTDESC(getStrValue(sp[short_desc]));
				contentscoreMsg.setLONGDESC(getStrValue(sp[long_desc]));
				contentscoreMsg.setTITLECONSISTENCY(getStrValue(sp[title_consistency]));
				contentscoreMsg.setPrimary(getStrValue(sp[primary_image]));
				contentscoreMsg.setAlt1(getStrValue(sp[alt_1]));
				contentscoreMsg.setAlt2(getStrValue(sp[alt_2]));
				contentscoreMsg.setAlt3(getStrValue(sp[alt_3]));
				contentscoreMsg.setAlt4(getStrValue(sp[alt_4]));
				contentscoreMsg.setAlt5(getStrValue(sp[alt_5]));
				contentscoreMsg.setAlt6(getStrValue(sp[alt_6]));


				pool.execute(new ACMEContentScoreRealTimeIngestVerification(contentscoreMsg));


			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}
	
	public String getStrValue(String str)
	{
		return str==null||str.equals("\\N")?null:str;
	}
	

}
