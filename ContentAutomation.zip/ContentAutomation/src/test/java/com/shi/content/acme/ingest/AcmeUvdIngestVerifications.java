package com.shi.content.acme.ingest;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNull;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.uvd.ProductContent;
import com.generated.vos.uvd.ProductOffer;
import com.google.gson.JsonSyntaxException;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.acme.ItemAuthorityTestCommon;

public class AcmeUvdIngestVerifications implements Runnable {

	ProductContent productContent;
	ProductOffer productOffer;
	String vendorId;
	String idToTest;
	Boolean bSingleProductOffer;
	String pid;
	Boolean isVarChild;

	public AcmeUvdIngestVerifications(
			ProductContent productContent,
			ProductOffer productOffer, 
			String vendorId, 
			String idToTest,
			Boolean bSingleProductOffer,
			String pid,
			Boolean isVarChild) {
		this.productContent = productContent;
		this.productOffer = productOffer;
		this.vendorId = vendorId;
		this.idToTest = idToTest;
		this.bSingleProductOffer = bSingleProductOffer;
		this.pid = pid;
		this.isVarChild = isVarChild;
	}

	String jresponse;

	@Override
	public void run() {

		String response = null;
		URI uri=null;

		String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+idToTest;
		System.out.println(sURL);

		try {

			uri = new URI(sURL);
			response = RestExecutor.getJSonResponse(uri);
			jresponse=response;
			if(idToTest!=null){

				CompareValuesUtility.init();

				AcmeSourceById acmeSourceById = JSONParser.parseJSON(response, AcmeSourceById.class);

				if(acmeSourceById == null || acmeSourceById.getItem() == null){
					CompareValuesUtility.logFailed("id", idToTest, " Not found");
					CompareValuesUtility.logFailed("vendorId", vendorId, " Not found");
					CompareValuesUtility.setupResult(idToTest, true);
					return;
				}

				verifySource(idToTest, productContent, productOffer, vendorId, acmeSourceById, response);

				CompareValuesUtility.setupResult(idToTest, true);
			}
		}
		catch(JsonSyntaxException js)
		{
			System.out.println("response..."+response);
			js.printStackTrace();
		}
		catch (URISyntaxException e) {

			e.printStackTrace();
		}catch(Throwable e){
			System.out.println("Check this id :"+ idToTest);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	private void verifySource(
			String id,
			ProductContent prodContent, 
			ProductOffer prodOffer,
			String vendorId, 
			AcmeSourceById iaSource,
			String response) {

		compareValues("id", id, iaSource.getItem().getId());
		compareValues("vendorId", "sears", iaSource.getItem().getVendorId());

		/*default fields*/
		compareValues("classifier", bSingleProductOffer?"NV":(isVarChild?"V":"P"), iaSource.getItem().getAttributes().getClassifier());
		verifyNullOrEqual("feedSource", "UVD", iaSource.getItem().getAttributes().getFeedSource());
		verifyNullOrEqual("programType", "UVD", iaSource.getItem().getAttributes().getProgramType());	

		String sActualTitle = JsonStringParser.getJsonValue(response,"{item{attributes{title}}}");

		/*fields under Attributes*/
		verifyNullOrEqual("title", prodContent.getName()==null?null:
			TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(OfferCommons.replaceNewline(prodContent.getName())),
			sActualTitle);

		String sExpectedShortDesc = prodContent.getMarketingDescription()==null?null:
			TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(TestUtils.plainEncodeHTML(
					OfferCommons.replaceNewline(prodContent.getMarketingDescription())));

		String sActualShortDesc = JsonStringParser.getJsonValue(response,"{item{attributes{shortDesc}}}");

		verifyNullOrEqual("shortDesc", sExpectedShortDesc,	sActualShortDesc);

		String sActualLongDesc = JsonStringParser.getJsonValue(response,"{item{attributes{longDesc}}}");

		verifyNullOrEqual("longDesc", prodContent.getFeatureDescription()==null?null:
			TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(TestUtils.plainEncodeHTML(OfferCommons.replaceNewline(prodContent.getFeatureDescription())))
			, sActualLongDesc);

		compareValues("itemClassId", prodContent.getContentItemClassId(), iaSource.getItem().getAttributes().getItemClassId());

		if(AcmeUvdIngestTests.bVerifyNotNullSsinGuid){
			CompareValuesUtility.verifyNotNull("ssin", iaSource.getItem().getSsin());
			CompareValuesUtility.verifyNotNull("guid", iaSource.getItem().getGuid());
		}

		verifyNullOrEqual("brandId", prodContent.getBrand()==null?null:prodContent.getBrand().getId(), iaSource.getItem().getAttributes().getBrandId());
		verifyNullOrEqual("brandName", prodContent.getBrand()==null?null:TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(prodContent.getBrand().getName()), iaSource.getItem().getAttributes().getBrandName());
		verifyNullOrEqual("modelNumber", (bSingleProductOffer||isVarChild)?prodOffer.getManufacturerPartNumber():prodContent.getManufacturerModelNumber(), iaSource.getItem().getAttributes().getModelNumber());

		compareValues("contentId", prodContent.getContentId().toString(), iaSource.getItem().getAttributes().getContentId());
		compareValues("svid", vendorId, iaSource.getItem().getAttributes().getSvid());
		compareValues("ownerId", vendorId, iaSource.getItem().getAttributes().getOwnerId());

		verifyNullOrEqual("Status", "ACTIVE", iaSource.getItem().getStatus());

		try {
			if((bSingleProductOffer?"NV":(isVarChild?"V":"P")).equalsIgnoreCase("P"))
				verifySites1(prodContent.getSite(), iaSource.getItem().getAttributes().getSites());
			else
				verifySites1(prodOffer.getSite(), iaSource.getItem().getAttributes().getSites());
		} catch (Exception e) {
		}

		if(isVarChild)
		{
			verifyNullOrEqual("pid", pid, iaSource.getItem().getAttributes().getPid());

			if(prodOffer.getVariantAttributes()!=null){
				Map<String, List<com.shi.content.acme.VarAttr>> actaulMapVarAttr = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(response, "{item{attributes{varAttr}}}"));
				Map<String, List<com.shi.content.acme.VarAttr>> expectedMapVarAttr = ItemAuthorityTestCommon.getVarAttrMapXml(prodOffer.getVariantAttributes());
				new ItemAuthorityTestCommon().compareAttributesMaps(expectedMapVarAttr, actaulMapVarAttr, true, "varAttr");
				CompareValuesUtility.addNewMultiValuedFields();
			}else{
				verifyNullOrEqual("varAttr", null, iaSource.getItem().getAttributes().getVarAttr().isEmpty()?null:iaSource.getItem().getAttributes().getVarAttr());
			}
		}
		else
		{
			Map<String, List<com.shi.content.acme.VarAttr>> attributesFromXml = ItemAuthorityTestCommon.getattributesMapXml(prodContent.getProductAttributes());
			Map<String, List<com.shi.content.acme.VarAttr>> attriutesFromJson = ItemAuthorityTestCommon.getAttributesMapListFromJsonNew(JsonStringParser.getJsonValue(response, "{item{attributes{attributes}}}"));
			new ItemAuthorityTestCommon().compareAttributesMaps(attributesFromXml, attriutesFromJson,true,"attributes");
			CompareValuesUtility.addNewMultiValuedFields();

			if(prodContent.getProductAttributes()!=null)
			{
				com.generated.vos.uvd.ProductAttribute[] prodAttributes = prodContent.getProductAttributes().getProductAttribute();
				for (com.generated.vos.uvd.ProductAttribute pa : prodAttributes) {
					if(pa.getAttributeId()!=null && (pa.getAttributeId().toString().equals("28101") ||
							pa.getAttributeId().toString().equals("11720") ||
							pa.getAttributeId().toString().equals("242")))
					{						
						String pkgQty = pa.getProductAttributeTypeChoice().getAttributeValueFree();
						verifyNullOrEqual("packageQuantity", pkgQty ,iaSource.getItem().getAttributes().getPackageQuantity());
						break;
					}
				}
			}
		}

		SHCContentCommons commonUtils = new SHCContentCommons();

		/*fields at product offer level*/
		verifyNullOrEqual("upcCode", (bSingleProductOffer||isVarChild)?prodOffer.getUpc():null, iaSource.getItem().getAttributes().getUpcCode());
		verifyNullOrEqual("brandCodeId", (bSingleProductOffer||isVarChild)?prodOffer.getBrandCodeId():null, iaSource.getItem().getAttributes().getBrandCodeId());

		verifyNull("dartPartNumber", iaSource.getItem().getAttributes().getDartPartNumber());
		verifyNull("searsPartNumber", iaSource.getItem().getAttributes().getPartNumber()==null?null:iaSource.getItem().getAttributes().getPartNumber().getSearsPartNumber());
		verifyNull("kmartPartNumber", iaSource.getItem().getAttributes().getPartNumber()==null?null:iaSource.getItem().getAttributes().getPartNumber().getKmartPartNumber());

		/*newly added*/
		verifyNullOrEqual("storeHierId", (bSingleProductOffer||isVarChild)?prodOffer.getCoreHierarchyId():null, iaSource.getItem().getAttributes().getStoreHierId());
		verifyNullOrEqual("attributes.Status", "ACTIVE", iaSource.getItem().getAttributes().getStatus().getStatus());
		verifyNullOrEqual("varGrpId", (bSingleProductOffer||isVarChild)?null:id, iaSource.getItem().getAttributes().getVarGroupId());

		verifyNullOrEqual("calcSsin", "UVD"+idToTest+"P", iaSource.getItem().getCalcSsin());
	}

	private void verifySites1(com.generated.vos.uvd.Site[] sites, List<com.generated.vos.acmesourcebyid.Site> acmeSites ){
		String siteIds =  JsonStringParser.getJsonValueNew(jresponse, "item.attributes.sites.id",true);
		String[] siteIdsSplit = siteIds.split(";");

		for(com.generated.vos.uvd.Site xmlSite : sites){
			if(!(siteIdsSplit.length ==0)) {

				Boolean bSiteFound=false;
				/*for each site in IA source*/
				for(int i=0; i< siteIdsSplit.length; i++) {
					siteIdsSplit[i] = siteIdsSplit[i].replaceAll("\"", "");
					if(xmlSite.getId().toString().equals(siteIdsSplit[i])) {
						bSiteFound = true;

						compareValues("SiteId", xmlSite.getId().toString(), siteIdsSplit[i], "SiteId");

						//Verify hierarchies
						String hierarchies = JsonStringParser.getJsonValueNew(jresponse, "item.attributes.sites["+i+"].taxonomy.hierarchy");
						//System.out.println("IA hierarchies for" + partNumberToTest+ " : "+ xmlSite.getId()+"  "+hierarchies);
						String[] ids = JsonStringParser.getJsonValueNew(hierarchies,"id").split(";");

						String[] primaryVals = JsonStringParser.getJsonValueNew(hierarchies,"primary").split(";");
						for(com.generated.vos.uvd.Hierarchy xmlhierarchy : xmlSite.getTaxonomy().getHierarchy()){
							boolean bHierarchyFound = false;
							if(!(ids == null || ids.length == 0)){
								for(int iHierarchy = 0; iHierarchy < ids.length; iHierarchy++){
									String iaHierarchyId = ids[iHierarchy].replaceAll("\"", "");
									if(xmlhierarchy.getId().toString().equals(iaHierarchyId)){
										bHierarchyFound = true;
										compareValues("Hierarchy", xmlhierarchy.getId().toString(),iaHierarchyId, "Id");
										compareValues("Hierarchy", xmlhierarchy.getPrimary().toString(), primaryVals[iHierarchy].replaceAll("\"", ""), "Primary");
										break;
									}
								}
								if(!bHierarchyFound){
									compareValues("Hierarchy", xmlhierarchy.getId(), null, "HierarchyId");
								}
							}else{
								compareValues("Hierarchy", xmlhierarchy.getId(), null, "HierarchyId");		
							}

						}
						break;
					}

				}
				if(!bSiteFound) {
					compareValues("SiteId", xmlSite.getId().toString(), null, "SiteId");
				}

			}else{
				compareValues("Sites", xmlSite.getId().toString(), null, "SiteId");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();


	}
}
