package com.shi.content.promos.phase2;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import com.generated.vos.promokafka.Promo;
import com.generated.vos.promos.PromoIds;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class PromoKafkaLoadLogic<T> implements Runnable {
	com.generated.vos.promokafka.Promo iaPromo;
	String promoIdToTest;

	public PromoKafkaLoadLogic(Promo promo) {
		this.iaPromo = promo;
		this.promoIdToTest = promo.getPromoId();

	}

	public void run() {

		System.out.println(promoIdToTest);

		/*
		 * System.out.println("String Return :"+RestExecutor.getDataById(
		 * CollectionValuesVal.PROMO, promoIdToTest));
		 * 
		 * System.out.println("Promo return :"+RestExecutor.getDataByIdFullSchema
		 * (CollectionValuesVal.PROMO, promoIdToTest));
		 * 
		 * com.generated.vos.promos.Promo gbData =
		 * RestExecutor.getDataByIdFullSchema(CollectionValuesVal.PROMO,
		 * promoIdToTest); System.out.println("gbData : "+gbData);
		 */

		com.generated.vos.promos.Promo gbData = RestExecutor.getDataById(
				CollectionValuesVal.PROMO, promoIdToTest);
		// System.out.println("Data : " + gbData);

		if (promoIdToTest != null) {
			/*
			 * if(!promoIdToTest.contains("32122_p")) return;
			 */
			try {
				CompareValuesUtility.init();
				if (gbData == null) {
					CompareValuesUtility.logFailed("Id", promoIdToTest,
							" Not found");
					CompareValuesUtility.setupResult(promoIdToTest, true);
					return;
				}

				// CompareValuesUtility.compareValues("promoIds.id",promoIdToTest,
				// gbData.getPromoIds().getId());

				verifyProduct(iaPromo, gbData, promoIdToTest);

				CompareValuesUtility.setupResult(promoIdToTest, true);
			} catch (Throwable e) {
				System.out.println("Check this id :" + promoIdToTest);
				e.printStackTrace();
			} finally {
				CompareValuesUtility.teardown();
			}
		}
	}

	private void verifyProduct(Promo iaPromo2,
			com.generated.vos.promos.Promo gbData, String promoId) {

		// PromoID
		if (gbData.getPromoIds() != null)
			compareValues("promoIds.id", promoId, gbData.getPromoIds().getId());
		else if (promoId != null)
			CompareValuesUtility.verifyTrue(false, "promoIds.id", promoId,
					"Not found");
		// Classification
		if (gbData.getClassification() != null) {
			compareValues("classification.AprDeal", iaPromo2.getAprDeal(),
					gbData.getClassification().getIsAprDeal());
			compareValues("classification.CsoDeal", iaPromo2.getCsoDeal(),
					gbData.getClassification().getIsCsoDeal());
			compareValues("classification.ExclusiveDeal",
					iaPromo2.getIsExclusiveDeal(), gbData.getClassification()
							.getIsExclusiveDeal());
			compareValues("classification.MemberGrp",
					iaPromo2.getCustomerSegment(), gbData.getClassification()
							.getMemberGrp());
			if (iaPromo2.getParentStoreField().equalsIgnoreCase("SEARS"))
				compareValues("classification.ParentStore",
						iaPromo2.getParentStoreField(), gbData
								.getClassification().getParentStore().SEARS);
			else
				compareValues("classification.ParentStore",
						iaPromo2.getParentStoreField(), gbData
								.getClassification().getParentStore().KMART);

			compareValues("classification.PromoGrpName",
					iaPromo2.getPromoGroup(), gbData.getClassification()
							.getPromoGrpName());
			compareValues("classification.ProrationType",
					iaPromo2.getAffectedItem(), gbData.getClassification()
							.getProrationType());
			compareValues("classification.StoretohomeDeal()",
					iaPromo2.getIsStoreToHomeDeal(), gbData.getClassification()
							.getIsStoretohomeDeal());
		} else {
			if (iaPromo2.getAprDeal() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.AprDeal", iaPromo2.getAprDeal(),
						"Not found");

			if (iaPromo2.getCsoDeal() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.CsoDeal", iaPromo2.getCsoDeal(),
						"Not found");

			if (iaPromo2.getIsExclusiveDeal() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.ExclusiveDeal",
						iaPromo2.getIsExclusiveDeal(), "Not found");

			if (iaPromo2.getCustomerSegment() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.MemberGrp",
						iaPromo2.getCustomerSegment(), "Not found");

			if (iaPromo2.getParentStoreField() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.ParentStore",
						iaPromo2.getParentStoreField(), "Not found");

			if (iaPromo2.getPromoGroup() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.PromoGrpName",
						iaPromo2.getPromoGroup(), "Not found");

			if (iaPromo2.getAffectedItem() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.ProrationType",
						iaPromo2.getAffectedItem(), "Not found");

			if (iaPromo2.getIsStoreToHomeDeal() != null)
				CompareValuesUtility.verifyTrue(false,
						"classification.StoretohomeDeal",
						iaPromo2.getIsStoreToHomeDeal(), "Not found");
		}

		// hard code as 'DEFAULT' until this data point comes from Deal UI
		compareValues("classification.PromoClass", "DEFAULT", gbData
				.getClassification().getPromoClass());
		compareValues("classification.PromoSubClass", "DEFAULT", gbData
				.getClassification().getPromoSubClass());

		// ExclusionText
		if (gbData.getExclusionText() != null)
			compareValues("ExclusionText", iaPromo2.getExclusionText(),
					gbData.getExclusionText());
		else if (iaPromo2.getExclusionText() != null)
			CompareValuesUtility.verifyTrue(false, "ExclusionText",
					iaPromo2.getExclusionText(), "Not found");

		// freePromoFlag
		if (gbData.getFreePromoFlag() != null)
			compareValues("FreePromoFlag", iaPromo2.getFreePromoFlag(),
					gbData.getFreePromoFlag());
		else if (iaPromo2.getFreePromoFlag() != null)
			CompareValuesUtility.verifyTrue(false, "FreePromoFlag",
					iaPromo2.getFreePromoFlag(), "Not found");

		// meta
		if (gbData.getMeta() != null) {
			compareValues("Priority",
					Double.parseDouble(iaPromo2.getPriority()), gbData
							.getMeta().getPriority());
			compareValues("dealstatus", iaPromo2.getDealStatus(), gbData
					.getMeta().getStatus());
			//Waiting for clarification
			/*compareValues("lastUpdateDate", iaPromo2.getUpdatedDate(), gbData
					.getMeta().getLastUpdate());
			compareValues("CreatedDate", iaPromo2.getCreatedDate(), gbData
					.getMeta().getCreate());*/
		} else {
			if (iaPromo2.getPriority() != null)
				CompareValuesUtility.verifyTrue(false, "Priority",
						iaPromo2.getPriority(), "Not found");
			if (iaPromo2.getDealStatus() != null)
				CompareValuesUtility.verifyTrue(false, "dealstatus",
						iaPromo2.getDealStatus(), "Not found");
			if (iaPromo2.getUpdatedDate() != null)
				CompareValuesUtility.verifyTrue(false, "lastUpdateDate",
						iaPromo2.getUpdatedDate(), "Not found");
			if (iaPromo2.getCreatedDate() != null)
				CompareValuesUtility.verifyTrue(false, "CreatedDate",
						iaPromo2.getCreatedDate(), "Not found");
		}
		// iaPromo2.getRules().get(0).getThresholdName()
		// iaPromo2.getRules().get(0).getThresholdCondition().get(0);

		// PromoDetails
		if (gbData.getPromoDetails() != null) {
			compareValues("Promo.Code", iaPromo2.getCouponCode(), gbData
					.getPromoDetails().getCode());
			// Desc
			if (gbData.getPromoDetails().getDesc() != null) {
				int size = gbData.getPromoDetails().getDesc().size();
				for (int i = 0; i < size; i++) {
					if (gbData.getPromoDetails().getDesc().get(i).getType()
							.equals("S")){
						compareValues("ShortDescription", iaPromo2.getShortDescription(), gbData
								.getPromoDetails().getDesc().get(i).getValue());
					}
					if (gbData.getPromoDetails().getDesc().get(i).getType()
							.equals("L")){
						compareValues("LongDescription", iaPromo2.getLongDescription(), gbData
								.getPromoDetails().getDesc().get(i).getValue());
					}
				}
			} else {
				if (iaPromo2.getLongDescription() != null)
					CompareValuesUtility.verifyTrue(false, "LongDescription",
							iaPromo2.getLongDescription(), "Not found");
				if (iaPromo2.getShortDescription() != null)
					CompareValuesUtility.verifyTrue(false, "ShortDescription",
							iaPromo2.getShortDescription(), "Not found");
			}
			
			//DiscountType
			if (gbData.getPromoDetails().getDiscType() != null)
				compareValues("DiscountType", iaPromo2.getDiscountType(), gbData.getPromoDetails().getDiscType());
			else if (iaPromo2.getDiscountType()!=null)
				CompareValuesUtility.verifyTrue(false, "DiscountType",
						iaPromo2.getDiscountType(), "Not found");
			
			//DisplayEndDate
			if(gbData.getPromoDetails().getDispEndDt()!=null)
				compareValues("DisplayEndDate", iaPromo2.getDisplayEndDate(), gbData.getPromoDetails().getDispEndDt());
			else if(iaPromo2.getDisplayEndDate()!=null)
				CompareValuesUtility.verifyTrue(false, "DisplayEndDate",
						iaPromo2.getDisplayEndDate(), "Not found");
			
			//endDt
			if(gbData.getPromoDetails().getEndDt()!=null)
				compareValues("EndDate", iaPromo2.getEndDate(), gbData.getPromoDetails().getEndDt());
			else if(iaPromo2.getEndDate()!=null)
				CompareValuesUtility.verifyTrue(false, "EndDate",
						iaPromo2.getEndDate(), "Not found");
			
			//dispRank
			if(gbData.getPromoDetails().getDispRank()!=null)
				compareValues("DispRank", iaPromo2.getDisplayRank(), gbData.getPromoDetails().getDispRank());
			else if(iaPromo2.getDisplayRank()!=null)
				CompareValuesUtility.verifyTrue(false, "DispRank",
						iaPromo2.getDisplayRank(), "Not found");
			
			//Image
			if(gbData.getPromoDetails().getImage()!=null)
				compareValues("Image", iaPromo2.getPromotionImage(), gbData.getPromoDetails().getImage());
			else if(iaPromo2.getPromotionImage()!=null)
				CompareValuesUtility.verifyTrue(false, "Image",
						iaPromo2.getPromotionImage(), "Not found");
			
			//Name
			if(gbData.getPromoDetails().getName()!=null)
				compareValues("Name", iaPromo2.getPromoName(), gbData.getPromoDetails().getName());
			else if(iaPromo2.getPromoName()!=null)
				CompareValuesUtility.verifyTrue(false, "Name",
						iaPromo2.getPromoName(), "Not found");
			
			//nfxCode
			if(gbData.getPromoDetails().getNfxCode()!=null)
				compareValues("NfxCode", iaPromo2.getFlsCouponNumber(), gbData.getPromoDetails().getNfxCode());
			else if(iaPromo2.getFlsCouponNumber()!=null)
				CompareValuesUtility.verifyTrue(false, "NfxCode",
						iaPromo2.getFlsCouponNumber(), "Not found");
			
			//ptsThldCond
			if(gbData.getPromoDetails().getPtsThldCond()!=null)
				compareValues("ptsThldCond", iaPromo2.getPtsThresholdCond(), gbData.getPromoDetails().getPtsThldCond());
			else if(iaPromo2.getPtsThresholdCond()!=null)
				CompareValuesUtility.verifyTrue(false, "ptsThldCond",
						iaPromo2.getPtsThresholdCond(), "Not found");
			
			//startDate
			if(gbData.getPromoDetails().getStartDt()!=null)
				compareValues("startDate", iaPromo2.getStartDate(), gbData.getPromoDetails().getStartDt());
			else if(iaPromo2.getStartDate()!=null)
				CompareValuesUtility.verifyTrue(false, "startDate",
						iaPromo2.getStartDate(), "Not found");
			
			//Promotype
			if(gbData.getPromoDetails().getType()!=null)
				compareValues("Promotype", iaPromo2.getPromoType(), gbData.getPromoDetails().getType());
			else if(iaPromo2.getPromoType()!=null)
				CompareValuesUtility.verifyTrue(false, "Promotype",
						iaPromo2.getPromoType(), "Not found");
		}
		
		if(gbData.getPromoIds()!=null)
		verifyPromoIds(iaPromo2,gbData.getPromoIds());
		
	}

	private void verifyPromoIds(Promo iaPromo2, PromoIds promoIds) {
			
			if(promoIds.getCouponNum()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getCouponCode(), promoIds.getCouponNum(),"CouponNum:");
			else if(iaPromo2.getCouponCode()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getCouponCode(), "Not found","CouponNum:");
			
			if(promoIds.getId()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getPromoId(), promoIds.getId(),"Id:");
			else if(iaPromo2.getPromoId()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getPromoId(), "Not found","Id:");
			
			if(promoIds.getMarkdownCode()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getMarkdownCode(), promoIds.getMarkdownCode(),"MarkdownCode:");
			else if(iaPromo2.getMarkdownCode()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getMarkdownCode(), "Not found","MarkdownCode:");
			
			if(promoIds.getMarkdownCodeName()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getMarkdownCodeName(), promoIds.getMarkdownCodeName(),"MarkdownCodeName:");
			else if(iaPromo2.getMarkdownCodeName()!=null)
				verifyNullOrEqual("Promo", iaPromo2.getMarkdownCodeName(), "Not found","MarkdownCodeName:");
			CompareValuesUtility.addNewMultiValuedFields();		
	}

}