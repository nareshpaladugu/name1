package com.shi.content.storepricing;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;

public class MemberPriceTests {
	
		HashMap<String, Boolean> storeIds = new HashMap<String, Boolean>();
		String finalId=null;
		StorePricing storePricingGB;

		
		

			
			@Test
			public void testMemberPrice() {
				final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
					List<String> newData;
					try {
							pool.execute(new MemberPriceVerification());
							System.out.println("Sent ");
					} catch (Exception e) {
						e.printStackTrace();
					}
					pool.shutdown();

					try {
						pool.awaitTermination(1000, TimeUnit.MINUTES);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
}
