package com.shi.content.Variations;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class GB_Assert_Node_Verifications implements Runnable{
	
	String idToTest;
	CollectionValues gbSearchcollection;

	public GB_Assert_Node_Verifications(String idToTest){
		this.idToTest = idToTest;
		
		switch(LoadProperties.collection){
			case "offer":{
				gbSearchcollection = CollectionValuesVal.OFFER;
				break;
			}
			case "content":{
				gbSearchcollection = CollectionValuesVal.CONTENT;
				break;
			}	
		}
	}

	public void run() {
		CompareValuesUtility.init();
		//Offer offer =  RestExecutor.getDataById(CollectionValuesVal.OFFER,idToTest);

		String offerToTest = RestExecutor.getJSonResponseById(gbSearchcollection,idToTest);
		boolean validateAbsence = Boolean.parseBoolean(System.getProperty("validateAbsent"));
		//System.out.println(offerToTest);
		if(offerToTest.contains(LoadProperties.gbSearchString)) {
			System.out.println(LoadProperties.gbSearchString+" is present for: "+ idToTest);
			if(validateAbsence)
				CompareValuesUtility.logFailed("Id", idToTest, LoadProperties.gbSearchString+" is present");
			else
				CompareValuesUtility.logPassed("Id", idToTest, LoadProperties.gbSearchString+" is present");
		} else if(offerToTest.equals("[]")) {
			System.out.println("Offer response null for: "+ idToTest);
			CompareValuesUtility.logFailed("Id", idToTest, " Offer response NULL");
		} else {
			System.out.println(LoadProperties.gbSearchString+" is not present for: "+ idToTest);
			if(validateAbsence)
				CompareValuesUtility.logPassed("Id", idToTest, LoadProperties.gbSearchString+" is NOT present");
			else
				CompareValuesUtility.logFailed("Id", idToTest, LoadProperties.gbSearchString+" is present");
			
		}
		CompareValuesUtility.setupResult(idToTest+"", true);
		/*if(offer == null){
			System.out.println("Offer response null for: "+ idToTest);
		} else if (offer.getDispTags() != null 
				&& offer.getDispTags().getIsSearchSupression() != null 
				&& offer.getDispTags().getIsSearchSupression() == true) {
			System.out.println("IsSearchSupression is true for: "+ idToTest);
		} else {
			System.out.println("IsSearchSupression is null/false for: "+ idToTest);
		}*/
	}
}

