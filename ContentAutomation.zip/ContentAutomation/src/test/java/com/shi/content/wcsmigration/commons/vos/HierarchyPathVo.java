package com.shi.content.wcsmigration.commons.vos;

import java.util.List;

public class HierarchyPathVo
	{
		public List<String> getLstIds() {
			return lstIds;
		}
		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}
		public List<String> getLstCIds() {
			return lstCIds;
		}
		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}
		public List<String> getDisplayPaths() {
			return displayPaths;
		}
		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}
		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}
