package com.shi.content.storepricing;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.TextFileParser;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;


public class StorePricingTouchUpTests implements Runnable  {

	
	
	String offerData;
	public StorePricingTouchUpTests(String data) {
		offerData = data;
	}

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="PricingTouchupTests")
	public void testSearsStorePricing(String fileName) {

		BlockingQueue<String> offerMpfDetails = new LinkedBlockingQueue<String>();
		TextFileParser<String> myParser = new TextFileParser<String>(fileName, offerMpfDetails);
		Thread readerThread = new Thread(myParser);
		readerThread.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while (true) {
			String mpfData;
			try {
				mpfData = offerMpfDetails.poll(20, TimeUnit.SECONDS);
			
				if (mpfData == myParser.POISON_PILL_STRING) {
					break;
				}
				if(mpfData != null){
					pool.execute(new StorePricingTouchUpTests(mpfData));
					System.out.println("Sent "+ mpfData);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		
		MPFVo mpfData = this.parseReadData(offerData);
		CompareValuesUtility.init();
		 
		ShcPricing pricingDoc = RestExecutor.getDataById(CollectionValuesVal.SHCPRICING, mpfData.offerId);
		
		if (pricingDoc==null)
		{
			CompareValuesUtility.logPassed("OfferId",mpfData.offerId,"No result found in gb");
			
		}
		else{
			CompareValuesUtility.logPassed("OfferId",mpfData.offerId,pricingDoc.getPid());
			if(JodaDateTimeUtility.isFirstDateBeforeSecond( mpfData.endDate, mpfData.startDate) || 
					!JodaDateTimeUtility.isCurrentDateBeforeEndDate(mpfData.endDate)){
				CompareValuesUtility.addDataFieldForReport("ErroredOut -Date", "SDt:"+mpfData.startDate + " EDt:"+mpfData.endDate, INFOTYPE.DATA);
				CompareValuesUtility.setupResult(mpfData.offerId, true);
				CompareValuesUtility.teardown();
				return;
			}
			if(mpfData.mpf){
				
				CompareValuesUtility.compareValues("MpfFlag", mpfData.mpf, pricingDoc.getMpf().getMp());
				CompareValuesUtility.compareValues("MpfStDate", mpfData.startDate, pricingDoc.getMpf().getSt());
				CompareValuesUtility.compareValues("MpfEtDate", mpfData.endDate, pricingDoc.getMpf().getEt());
			}else{
				CompareValuesUtility.compareValues("MpfFlag", mpfData.mpf, pricingDoc.getMpf().getMp());
				CompareValuesUtility.verifyNull("MpfStDate",pricingDoc.getMpf().getSt() );
				CompareValuesUtility.verifyNull("MpfEtDate", pricingDoc.getMpf().getEt());
			}
		}
		CompareValuesUtility.setupResult(mpfData.offerId, true);
		CompareValuesUtility.teardown();
		
		
	}
	
	/**
	 * File format
	 * PartNumber|MPF|Start Date| End Date|
		01301686|1|2015-05-31 00:00:00|2015-10-20 23:59:59|
	 * @param offerDataLine
	 */

	private MPFVo parseReadData(String offerDataLine) {
		
		String[] mpfData = offerDataLine.split("\\|");
		String offerId = mpfData[0].trim();
		boolean mpf = mpfData[1].trim().equals("1")? true : false;
		String startDate = JodaDateTimeUtility.getJodaTimeFormatString(mpfData[2].trim());
		System.out.println("Date now : "+ startDate);
		String endDate = JodaDateTimeUtility.getJodaTimeFormatString(mpfData[3].trim());
		System.out.println("Date now : "+ startDate);
		MPFVo  mpfDetails = new MPFVo(offerId, mpf, startDate, endDate);
		return mpfDetails;
	}
	
	private class MPFVo{
		String offerId;
		boolean mpf ;
		String startDate;
		String endDate;
		
		public MPFVo(String offerId, boolean mpf, String startDate,	String endDate) {
			if(offerId.endsWith("000"))
				offerId = offerId.substring(0, 8);
			this.offerId = "0009300-"+offerId;
			this.mpf = mpf;
			this.startDate = startDate;
			this.endDate = endDate;
		}
		
		
	}
	
	
	
}


