package com.shi.content.ranking.threepointfive.helper;

import org.bson.Document;

import com.generated.vos.rankingmongo.offer.Rankingmongo;
import com.google.gson.Gson;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

public class RankingMongoDataByDb {

	public static Rankingmongo getSingleDoc(String id)
	{
		try {

			String resp=""; 

			MongoCollection<Document> collection = RankingMongoDbUtil.getRankingMongoCollection();

			FindIterable<Document> rs = collection.find(new Document("_id",id));
			
			for (Document document : rs) {
				resp = document.toJson().toString();
			}
			Gson gson = new Gson();

			if(!resp.isEmpty())
				return gson.fromJson(resp, Rankingmongo.class);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
}
