package com.shi.content.hierarchy.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.webhierarchy.Node;
import com.generated.xmls.webhierarchy.RetiredNode;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class WebHierarchyTests {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="WebHierarchyTests")
	public void testWebHierarchy(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		String sSiteId = sFileName.split("\\.")[0].split("-")[2];
		System.out.println("Site id "+ sSiteId);
		BlockingQueue<List<Node>> webHierarchyNodeQueue = new LinkedBlockingQueue<List<Node>>(); 
		
		HierarchyCommons hierarchyUtils = new HierarchyCommons(sFileName, HierarchyCommons.figureOutCatalogId(sSiteId));
		ChunkProducerThread<Node> prodThread = new ChunkProducerThread<Node>(sFileName, webHierarchyNodeQueue, Node.class);
		prodThread.setCutOffNode("link-nodes");
//		XMLChunker fileParser = prodThread.getParser();
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Node> nodeToTest = webHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null)
					pool.execute(new WebHierarchyVerifications(nodeToTest,hierarchyUtils, Integer.parseInt(sSiteId)));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		//Commenting out retired nodes verification since it is not going to be deployed currently
		BlockingQueue<List<RetiredNode>> retiredNodeQueue = new LinkedBlockingQueue<List<RetiredNode>>();
		ChunkProducerThread<RetiredNode> retiredNodeThread = new ChunkProducerThread<RetiredNode>(sFileName, retiredNodeQueue, RetiredNode.class,"retired-node");
		
		retiredNodeThread.setBucketSize(1);
		Thread retThread = new Thread(retiredNodeThread);
		retThread.start();
		int i = 0;
		while(true){
			try {
				i++;
				List<RetiredNode> nodeToTest = retiredNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == retiredNodeThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null)
					pool.execute(new WebHierarchyVerifications(nodeToTest, Integer.parseInt(sSiteId)));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Retired nodes count "+i);
		pool.shutdown();
		try {
			pool.awaitTermination(30, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

	
}
