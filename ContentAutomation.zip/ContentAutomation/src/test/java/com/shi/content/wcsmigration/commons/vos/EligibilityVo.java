package com.shi.content.wcsmigration.commons.vos;

import java.util.LinkedList;
import java.util.Map;

public class EligibilityVo 
{

	private String tabName;
	
	private Map<String,LinkedList<RuleVO>> ruleList;

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	public Map<String, LinkedList<RuleVO>> getRuleList() {
		return ruleList;
	}

	public void setRuleList(Map<String, LinkedList<RuleVO>> ruleList) {
		this.ruleList = ruleList;
	}
	
}
