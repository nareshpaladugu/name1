package com.shi.content.wcsmigration.commons.vos;

public class SyncVo {

	private String fieldName;
	private String offerPath;
	private String offerAttrsPath;
	private String skip;
	private String jobName;
	private String sr;
	private String booleanField;
	
	public String getBooleanField() {
		return booleanField;
	}
	public void setBooleanField(String booleanField) {
		this.booleanField = booleanField;
	}
	public String getSr() {
		return sr;
	}
	public void setSr(String sr) {
		this.sr = sr;
	}
	public SyncVo(String sr,String fieldName, String offerAttrsPath,String offerPath,
			String jobName ,String skip,String bool) {
		super();
		this.fieldName = fieldName;
		this.offerPath = offerPath;
		this.offerAttrsPath = offerAttrsPath;
		this.skip = skip;
		this.jobName = jobName;
		this.sr = sr;
		booleanField=bool;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getOfferPath() {
		return offerPath;
	}
	public void setOfferPath(String offerPath) {
		this.offerPath = offerPath;
	}
	public String getOfferAttrsPath() {
		return offerAttrsPath;
	}
	public void setOfferAttrsPath(String offerAttrsPath) {
		this.offerAttrsPath = offerAttrsPath;
	}
	public String getSkip() {
		skip=skip==null?"":skip;
		return skip;
	}
	public void setSkip(String skip) {
		this.skip = skip;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
