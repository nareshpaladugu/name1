package com.shi.content.ranking.threepointfive.helper;

import java.util.List;

import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class RankingMongoHelper {

	public static String getOfferIdbySpinId(String spinId)
	{
		List<String> listOfOfferIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "spinId="+spinId);

		if(listOfOfferIds.size()>1)
		{
			System.out.println("================ >>>> More than one offer for this spinId "+spinId);
		}

		if(listOfOfferIds!=null && !listOfOfferIds.isEmpty())
			return listOfOfferIds.get(0);

		return null;
	}

}
