package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.generated.vos.content.Content;
import com.generated.vos.content.Desc;
import com.generated.vos.content.Img_;
import com.generated.vos.contentbco.BundleGroup;
import com.generated.vos.contentbco.CollProduct;
import com.generated.vos.contentbco.Image;
import com.generated.vos.contentbco.Product;
import com.generated.vos.contentbco.Sites;
import com.generated.vos.contentbco.Sites__;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.offer.Offer;
import com.generated.xmls.collections.Bundle;
import com.generated.xmls.collections.BundleTypeChoiceItem;
import com.generated.xmls.collections.Collection;
import com.generated.xmls.collections.CollectionTypeChoiceItem;
import com.generated.xmls.collections.CommonElementsGroup;
import com.generated.xmls.collections.FeatureTopDescriptions;
import com.generated.xmls.collections.GroupType;
import com.generated.xmls.collections.GroupsTypeChoiceItem;
import com.generated.xmls.collections.Hierarchy;
import com.generated.xmls.collections.ItemList;
import com.generated.xmls.collections.ItemPartNumber;
import com.generated.xmls.collections.ProductAttribute;
import com.generated.xmls.collections.ProductAttributes;
import com.generated.xmls.collections.Site;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;

public class BOC_StaticVerifications implements Runnable {
	
	Collection collection;
	Bundle bundle;
	Boolean isBundle = false;
	Boolean isCrossFormatted = false;
	String itemClassId;
	Attrs masterHierarchyAttributes;
	String sSiteToTest;
	SHCCollectionBundleCommons commonUtils;
	String spinId;
	String catentrySubType;
	List<String> errorPartNumbers;
	Offer offerToTakeDataFrom = null;
	int rankProductSize = 2;
	
	

	public BOC_StaticVerifications(Collection collection, 
			Bundle bundle, 
			SHCCollectionBundleCommons commonUtils, 
			String siteToTest, 
			List<String> errorPartNumbers) {
		if(collection == null){
			isBundle = true;
		}
		this.collection = collection;
		this.bundle = bundle;
		this.itemClassId = isBundle?bundle.getCommonElementsGroup().getMasterHierarchyId().toString():collection.getCommonElementsGroup().getMasterHierarchyId().toString();
		this.commonUtils = commonUtils;
		this.sSiteToTest = siteToTest;
		this.errorPartNumbers = errorPartNumbers;
	}

	/*public BOC_StaticVerifications(Bundle bundle, SHCCollectionBundleCommons commonUtils, String siteToTest) {
		this.bundle = bundle;
		this.itemClassId = bundle.getCommonElementsGroup().getMasterHierarchyId().toString();
		this.commonUtils = commonUtils;
		this.sSiteToTest = siteToTest;
		isBundle = true;
	}*/

	@Override
	public void run() {
try{
		CompareValuesUtility.init();
		
		String id = null;
		CommonElementsGroup commElementsGrp = null;
		FeatureTopDescriptions topDesc = null;
		//String parentStore = null;
		String soldBy = null;
		//List<String> ids = new ArrayList<String>();
		
		if(isBundle){
			Boolean pNotFound = false;
			if(sSiteToTest.equals("sears")){
				/*Check if collection has Kmart site*/
				Boolean parentSiteFound = false;
				for(com.generated.xmls.collections.Site site : bundle.getCommonElementsGroup().getSite()){
					long lSiteId = site.getId();
					if(lSiteId==1){
						isCrossFormatted = true;
					}
					if(lSiteId==2){
						parentSiteFound = true;
					}
				}
				/*Check if first required group has sears or kmart partnumber*/
				for(GroupsTypeChoiceItem group : bundle.getBundleTypeChoice().getBundleTypeChoiceItem(0).getBundleGroups().getGroupsTypeChoice().getGroupsTypeChoiceItem()){
					if(group.getRequiredGroup()!=null){					
						for(ItemPartNumber item : group.getRequiredGroup().getItemPartNumber()){
							if(item.getItemSearsPartNumber()==null){
								System.out.println("Non-"+sSiteToTest+" bundle: "+bundle.getBundleSearsPartNumber()+"B");
								pNotFound = true;
								return;
							}
							if(item.getItemKmartPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}else{
						for(ItemPartNumber item : group.getOptionalGroup().getItemPartNumber()){
							if(item.getItemKmartPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}
				}
				/*Check if parent Site exists in feed*/
				if(!parentSiteFound){
					System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " bundle: "+bundle.getBundleSearsPartNumber()+"B");
					return;
				}
				if(!pNotFound){
					id = bundle.getBundleSearsPartNumber()+"B";
					soldBy = "Sears";
				}
			}else{
				/*Check if collection has Sears site*/
				Boolean parentSiteFound = false;
				for(com.generated.xmls.collections.Site site : bundle.getCommonElementsGroup().getSite()){
					long lSiteId = site.getId();
					if(lSiteId==2){
						isCrossFormatted = true;
					}
					if(lSiteId==1){
						parentSiteFound = true;
					}
				}
				/*Check if first required group has sears or kmart partnumber*/
				for(GroupsTypeChoiceItem group : bundle.getBundleTypeChoice().getBundleTypeChoiceItem(0).getBundleGroups().getGroupsTypeChoice().getGroupsTypeChoiceItem()){
					if(group.getRequiredGroup()!=null){
						for(ItemPartNumber item : group.getRequiredGroup().getItemPartNumber()){
							if(item.getItemKmartPartNumber()==null){
								System.out.println("Non-"+sSiteToTest+" bundle: "+bundle.getBundleKmartPartNumber()+"B");
								pNotFound = true;
								return;
							}
							if(item.getItemSearsPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}else{
						for(ItemPartNumber item : group.getOptionalGroup().getItemPartNumber()){
							if(item.getItemSearsPartNumber()!=null){
								isCrossFormatted = false;
							}
						}
					}
				}
				/*Check if parent Site exists in feed*/
				if(!parentSiteFound){
					System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " bundle: "+bundle.getBundleKmartPartNumber()+"B");
					return;
				}
				if(!pNotFound){
					id = bundle.getBundleKmartPartNumber()+"B";
					soldBy = "Kmart";
				}
			}
			
			commElementsGrp = bundle.getCommonElementsGroup();
			topDesc = bundle.getFeatureTopDescriptions();
			spinId = bundle.getSpinBundleId();

		}
		else{
			
			Boolean pNotFound = false;
			
			//Collection should have minimum 2- products
			if(collection.getCollectionTypeChoice().getCollectionTypeChoiceItem(0).getItemList().getItemPartNumber().length <rankProductSize )
				return;			
			
			/*Check if collection has Sears site*/
			if(sSiteToTest.equals("sears")){
				/*Check if collection has Kmart site*/
				Boolean parentSiteFound = false;
				for(com.generated.xmls.collections.Site site : collection.getCommonElementsGroup().getSite()){
					long lSiteId = site.getId();
					if(lSiteId==1){
						isCrossFormatted = true;
					}
					if(lSiteId==2){
						parentSiteFound = true;
					}
				}
				/*Check if each item partnumber has sears or kmart partnumber*/
				for(ItemPartNumber item : collection.getCollectionTypeChoice().getCollectionTypeChoiceItem(0).getItemList().getItemPartNumber()){
					if(item.getItemSearsPartNumber()==null){
						System.out.println("Non-"+sSiteToTest+" collection: "+collection.getCollectionSearsPartNumber()+"B");
						pNotFound = true;
						return;
					}
					if(item.getItemKmartPartNumber()!=null){
						isCrossFormatted = false;
					}
				}
				/*Check if parent Site exists in feed*/
				if(!parentSiteFound){
					System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " collection: "+collection.getCollectionSearsPartNumber()+"B");
					return;
				}
				
				id = collection.getCollectionSearsPartNumber()+"B";
				soldBy = "Sears";
			}else{
				
				//Collection should have minimum 2- products
				if(collection.getCollectionTypeChoice().getCollectionTypeChoiceItem(0).getItemList().getItemPartNumber().length < rankProductSize )
					return;
				
				/*Check if collection has Sears site*/
				Boolean parentSiteFound = false;
				for(com.generated.xmls.collections.Site site : collection.getCommonElementsGroup().getSite()){
					long lSiteId = site.getId();
					if(lSiteId==2){
						isCrossFormatted = true;
					}
					if(lSiteId==1){
						parentSiteFound = true;
					}
				}
				/*Check if each item partnumber has sears or kmart partnumber*/
				for(ItemPartNumber item : collection.getCollectionTypeChoice().getCollectionTypeChoiceItem(0).getItemList().getItemPartNumber()){
					if(item.getItemKmartPartNumber()==null){
						System.out.println("Non-"+sSiteToTest+" collection: "+collection.getCollectionKmartPartNumber()+"B");
						pNotFound = true;
						return;
					}
					if(item.getItemSearsPartNumber()!=null){
						isCrossFormatted = false;
					}
				}
				/*Check if parent Site exists in feed*/
				if(!parentSiteFound){
					System.out.println("Site id="+sSiteToTest+" not present for "+ sSiteToTest + " collection: "+collection.getCollectionSearsPartNumber()+"B");
					return;
				}
				
				id = collection.getCollectionKmartPartNumber()+"B";
				soldBy = "Kmart";
			}
			
			commElementsGrp = collection.getCommonElementsGroup();
			topDesc = collection.getFeatureTopDescriptions();
			spinId = collection.getSpinCollectionId();
		}
		
		System.out.println("Testing id : " + id + " "+(isBundle?"Bundle":"Collection"));
		
		if(errorPartNumbers.contains(id)){
			System.out.println("Item not found in GB; found in error file: " + id);
			CompareValuesUtility.logPassed("Id", id, "Error Item, Not found in GB");
			CompareValuesUtility.setupResult(id, true);
			return;
		}
		if(!verifyCollectionPartNumber(id))
			return;

		APIResponse<com.generated.vos.contentbco.Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENTBCO,id);
		com.generated.vos.contentbco.Bundle gbBundleContent = (com.generated.vos.contentbco.Bundle)allResponse.getT();
				
		if(gbBundleContent==null ){
			if(errorPartNumbers.contains(id)){
				System.out.println("Item not found in GB; found in error file: " + id);
				CompareValuesUtility.logPassed("Id", id, "Error Item, Not found in GB");
			}else{
				CompareValuesUtility.logFailed("Id", id, "Not Found in GB");
			}
		}
		else{
			
			try{
				verifyCommonElements(commElementsGrp, topDesc, gbBundleContent, id, soldBy);
				if(isBundle){
					verifyBundle(bundle.getFixedPriceBundleFlag(), bundle.getBundleTypeChoice().getBundleTypeChoiceItem(), commElementsGrp.getProductAttributes(), gbBundleContent);
				}else
					verifyCollection(collection.getCollectionTypeChoice().getCollectionTypeChoiceItem(), gbBundleContent,collection);
				verifyFtSearch(allResponse);
				
			}catch (Exception e){
				System.out.println(e.getMessage() + " Exception : " + id);
				CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
			}	
		}
		
		CompareValuesUtility.setupResult(id, true);
		}catch (Exception e){
			System.out.println(e.getMessage() + " Exception for spinId: " + (isBundle?bundle.getSpinBundleId():collection.getSpinCollectionId()).toString());
		}	
	}
	
	
	private boolean verifyCollectionPartNumber(String id)
	{
		boolean IsValidCollectionPartNumber = true;
		
		char[] specialCharacter = {'!','@','#','$','%','^','&','*','(',')','?','+','-','_','{','}','/','\\','|',':',';','='};
		
		if(id.equals(null) || id.equals("")|| id.isEmpty())
			IsValidCollectionPartNumber = false;
		else
			IsValidCollectionPartNumber = true;
		
		if(IsValidCollectionPartNumber)
		{
			for(int i=0; i<id.length(); i++)
			{
				for(int j=0; j<specialCharacter.length; j++)
				{				
					if(id.charAt(i)==specialCharacter[j])
					{
						IsValidCollectionPartNumber = false;
						break;
						
					}				
				}
			}
		}
		else
		{
			IsValidCollectionPartNumber = false;
		}
		
		
		
		
		return IsValidCollectionPartNumber;
	}
	
	

	private void verifyCollection(
			CollectionTypeChoiceItem[] collectionTypeChoiceItem,
			com.generated.vos.contentbco.Bundle gbBundleContent,Collection xmlCollection) {
		
		boolean IsDispCollection = true;
		
		ItemList li = collectionTypeChoiceItem[0].getItemList();
		ArrayList<Long> rankList = new ArrayList<Long>();
		
		
		/*Rule # 1 	If rank is not available for any product within a collection, then load the collection with isDispElig as false 
		  at collection level and set products tag as empty */
		for (ItemPartNumber itemPartNumber : li.getItemPartNumber()) 
		{
			if(itemPartNumber == null || itemPartNumber.getRank()==0 || itemPartNumber.getRank()==0.0d )
			{
				System.out.println(itemPartNumber.getRank());
				IsDispCollection = false;				
				break;		
			}
		}
		
		/* Rule #2 - 2.	If multiple products with the same rank exist in the input, then load the collection with isDispElig as false 
		   at collection level and set products tag as empty */
		
		Set<Long> rank = new HashSet<Long>();
		ItemPartNumber[] im = li.getItemPartNumber();
		for(int i = 0; i < im.length; i++)
		{
			if((sSiteToTest.equalsIgnoreCase("sears")&& im[i].getItemSearsPartNumber() != null)
					|| (sSiteToTest.equalsIgnoreCase("kmart")&& im[i].getItemKmartPartNumber() != null))
			{
				if(rank.add(im[i].getRank()) == false)
				{
					IsDispCollection = false;
					//IsProductTagEmpty = true;
					break;
				}
			}			
			
		}		
		
		rankList.addAll(rank);
		if(rankList.size() < rankProductSize)
			return;
										
		if(IsDispCollection == false ||  verifyMasterHierarchy() == false	|| verifyWebHierarchy() == false ){
			verifyDispEligForCollection(false, gbBundleContent);
			CompareValuesUtility.compareValues("Products", 0, gbBundleContent.getProducts().size(), "ProductTag");
			return;
		}
		
		if(verifyTopRankedProductSKU(rankList) == false)
			verifyDispEligForCollection(false, gbBundleContent);
		
		/*if(verifySKUAndShippable();
		
		verifyMasterHierarchy();
		
		verifyWebHierarchy();
		
		verifyOtherSitesInCollection();
		*/

		
		for(CollectionTypeChoiceItem colType : collectionTypeChoiceItem){
			for(ItemPartNumber item : colType.getItemList().getItemPartNumber()){
				String id = null;
				if(sSiteToTest.equals("sears")){
					id = item.getItemSearsPartNumber()+"P";
				}else{
					id = item.getItemKmartPartNumber()+"P";
				}
				com.generated.vos.content.Content gbContent = RestExecutor.getDataById(CollectionValuesVal.CONTENT,id);
				if(gbContent==null){
					System.out.println("Product not present in GB content: " + id);
					continue;
				}
				Boolean pFound = false;
				for(CollProduct gbBundleProduct : gbBundleContent.getProducts()){
					if(gbBundleProduct.getId().equals(id)){
						pFound = true;
						verifyCollProduct(id, item, gbContent, gbBundleProduct);
						break; //when product found
					}
				}
				if(!pFound){
					CompareValuesUtility.compareValues("Products", id, " Not found under collection");
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		
	}
	
	
		
		

	/**
	 * Verify operational dispElig is false/true and products tag is empty
	 * @param gbBundleContent 
	 * @param b 
	 * @param gbBundleContent 
	 * @param bCollectionDispElig
	 */
	
	//TODO :: NV - add check for other sites
	
	private void verifyDispEligForCollection(boolean bDispElig, com.generated.vos.contentbco.Bundle gbBundleContent)
	{
		if(sSiteToTest.equalsIgnoreCase("sears"))
		{
			CompareValuesUtility.compareValues("Collection", bDispElig, gbBundleContent.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
		}
		else
		{
			CompareValuesUtility.compareValues("Collection", bDispElig, gbBundleContent.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
		}
		if(sSiteToTest.equalsIgnoreCase("kmart"))
		{
			CompareValuesUtility.compareValues("Collection", bDispElig, gbBundleContent.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
		}
		else
		{
			CompareValuesUtility.compareValues("Collection", bDispElig, gbBundleContent.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
		}

	}

	
	

	/**
	 * Validation-3.	If top tanked products doesn't contains any sku that is online and shippable or 
	 * top ranked product type is storeonly in GB,
	 *  we set display Eligible as false @ product level as well as collection level
	 * @param rank2 
	 */
	private boolean verifyTopRankedProductSKU(ArrayList<Long> rank)
	{
		boolean IsDispCollection = true;
		
		//Read either sears or kmart type item to check its rank
		//CollectionTypeChoiceItem[] collectionTypeChoiceItem= collection.getCollectionTypeChoice().getCollectionTypeChoiceItem();
		
		List<String>validitemNumberList = new ArrayList<String>();
				
		//Read either sears or kmart type item to check its rank
		CollectionTypeChoiceItem[] collectionTypeChoiceItem = collection.getCollectionTypeChoice().getCollectionTypeChoiceItem();
		ItemList xmlListOfItems =collectionTypeChoiceItem[0].getItemList();
		
		ItemPartNumber[] im = xmlListOfItems.getItemPartNumber();
		
		
		//Sort Rank and
		//Arrange Top Rank product by Rank value and respective ItemPartNumber as well also check ItemPartNumber should not be null. 
		java.util.Collections.sort(rank);
		for (Long lRank : rank)
		{
			for(int i=0; i<im.length ; i++)
			{
				if(im[i].getRank() == lRank)
				{
					if(sSiteToTest.equals("sears"))
					{
						if(im[i].getItemSearsPartNumber().equals(null))
						{
							IsDispCollection = false;							
							
						}
						else
						{
							validitemNumberList.add(im[i].getItemSearsPartNumber()+"P");
						}						
					}
					else
					{
						if(im[i].getItemKmartPartNumber().equals(null))
						{
							IsDispCollection = false;
						}
						else
						{
							validitemNumberList.add(im[i].getItemKmartPartNumber()+"P");
						}						
					}					
				}
			}
									
		}				
		
		
		for(int i=0; i< rankProductSize ; i++)
		{
			 Content contentCollByAllData =   RestExecutor.getDataById(CollectionValuesVal.CONTENT, validitemNumberList.get(i));
			 if(contentCollByAllData != null)
				{
				 if(verifyProductDispEligibility(contentCollByAllData,validitemNumberList.get(i)) == false)
				 {
						IsDispCollection = false;
						break;
				 }
				}
				else
				 {
					IsDispCollection = false;
					break;
				 }
			
		}
		return IsDispCollection;

	}
	
	
	
	
	/***
	 * Added on 21_06_2016
	 * @param itemPartNumber
	 * @return
	 */
	public boolean verifyProductDispEligibility(Content contentCollByAllData,String itemPartNumber)
	{
		boolean IsDispProduct = false;
		
		
		APIResponse<com.generated.vos.offer.Offer> offerCollByAllData = null;
		com.generated.vos.offer.Offer offerCollection = null;
		com.generated.vos.offer.Operational operational = null;
		
		List<String>listOfVarientOffer = new ArrayList<String>();
		
		String id = itemPartNumber;
		/*contentCollByAllData =   RestExecutor.getAllDataById(CollectionValuesVal.CONTENT, id);
		
		//Validation-5.	If top Ranked product is not mapped to GB, then we set dispElig as false at collection level and product tag as empty 
		if(contentCollByAllData!= null &&  contentCollByAllData.getSearchFields()!=null && contentCollByAllData.getT()!=null)
		{*/
			//contentCollection =  contentCollByAllData.getT(); //commented on 23_06_2016_07_35PM
			
			String catSubType = contentCollByAllData.getClassifications().getCatentrySubType();
			
			if(catSubType.equals("NV"))
				{
				
					offerCollByAllData =  RestExecutor.getAllDataById(CollectionValuesVal.OFFER,id.substring(0, id.length()-1));//Original
					
					if(offerCollByAllData != null)
					{
						offerCollection = offerCollByAllData.getT();									
						if(offerCollection.getFfm().getIsShipElig())
						{
							operational = offerCollection.getOperational();		
							
							if(sSiteToTest.equals("sears") && operational.getSites().getSears().getIsDispElig())
							{
									IsDispProduct = true;
							}
							else if(sSiteToTest.equals("kmart") && operational.getSites().getKmart().getIsDispElig() )
							{
								IsDispProduct = true;
							}
							else
							{								
								IsDispProduct = false;						
							}
							//if(IsDispProduct == true) // commented on 06_07_2016
								offerToTakeDataFrom = offerCollection;
						}
						else
						{
							IsDispProduct = false;
							offerCollection = offerCollByAllData.getT(); //Added on 06_07_2016
							offerToTakeDataFrom = offerCollection; //Added on 06_07_2016
						}
						
					}
				}
				else if(catSubType.equals("V"))
				{
					listOfVarientOffer = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+id);
					for (String offerId : listOfVarientOffer) 
					{
						//offerCollAPIesponse = RestExecutor.getDataById(CollectionValuesVal.OFFER,id.substring(0, id.length()-1));
						offerCollection = RestExecutor.getDataById(CollectionValuesVal.OFFER,offerId);
						if(sSiteToTest.equals("sears") && offerCollection.getFfm().getIsShipElig() && offerCollection.getOperational().getSites().getSears().getIsDispElig())
						{
							IsDispProduct = true;
							offerToTakeDataFrom = offerCollection;
							break;
						}
						else if(sSiteToTest.equals("kmart") && offerCollection.getOperational() .getSites().getKmart().getIsDispElig() && offerCollection.getFfm().getIsShipElig() )
						{
							IsDispProduct = true;
							offerToTakeDataFrom = offerCollection;
							break;
						}
						else
						{							
							IsDispProduct = false;	
							offerToTakeDataFrom = offerCollection;
						}
						
					}
				}
				else if(catSubType.equals("S"))
				{
					IsDispProduct = false;					
				}
		//}
		//else
		//{	// ask to Niharika
			//If content collection is null/empty
			//IsProductTagEmpty  = true;			
		//}
		return IsDispProduct;
	
	}
	
	
	
		
	/**
	 * Validation-10.	If master hierarchy is invalid, blank or empty, then load the collection with isDispElig as false at collection level and set products tag as empty
	 */
	private boolean verifyMasterHierarchy()
	{		
		boolean IsValid = true;;
		
		long masterHierarchyId = collection.getCommonElementsGroup().getMasterHierarchyId();
		String masterHierarchyIdStg = Long.toString(masterHierarchyId);
				
		if(!(masterHierarchyId==0 || masterHierarchyIdStg.equals("")||masterHierarchyIdStg==null))
		{
			com.generated.vos.hierarchy.Hierarchy masterHierarchyColl = RestExecutor.getDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, masterHierarchyIdStg);
			if(! (masterHierarchyColl != null && masterHierarchyColl.getId().trim().equals(masterHierarchyIdStg.trim() ) && masterHierarchyColl.getIsLeaf() ))
			{
				IsValid = false;
			}			
					
		}
		return IsValid;
	}
	
	
	
	
	/***
	 * Verify Web Hierarchy from collection
	 * @param collection xmlCollection
	 */
	private boolean verifyWebHierarchy()
	{
		boolean IsValidWebHierarchy = false;
		boolean IsDispCollection = false;
		int siteId= 0;
		
		com.generated.xmls.collections.Site sites[] = null;
		sites =  collection.getCommonElementsGroup().getSite();
		
		//Check for 1-Kmart and 2-Sears site only
		for(Site site: sites)
		{
			if(sSiteToTest.equals("sears") && site.getId() ==2L)
			{
				IsValidWebHierarchy = true;
				siteId = 2;
				break;
			}
			else if(sSiteToTest.equals("kmart") && site.getId()==1L)
			{
				IsValidWebHierarchy = true;
				siteId = 1;
				break;
			}
		}
		
		if(IsValidWebHierarchy)
		{
			for (Site site : sites) 
			{
				if(site.getId()==siteId)
				{					
					com.generated.xmls.collections.Taxonomy taxonomy =  site.getTaxonomy();
					com.generated.xmls.collections.Hierarchy hierarchy[] = taxonomy.getHierarchy();
					for (Hierarchy hierarchy2 : hierarchy) 
					{
						long hierarchyId = hierarchy2.getId();
						
						com.generated.vos.hierarchy.Hierarchy webHierarchyColl = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY,Long.toString(hierarchyId));
						if(webHierarchyColl != null)
						{
							if(webHierarchyColl.getId().equals(Long.toString(hierarchyId))) 
							{
								IsValidWebHierarchy = true;
								break;
							}
						}
						else
						{
							IsValidWebHierarchy = false;
						}
					}
				}
				
			}
		}
		
		if(!IsValidWebHierarchy)
		{
			IsDispCollection = false;			
		}
		else
		{
			IsDispCollection = true;
		}		
		return IsDispCollection;
	}
	
	
	/**
	 * validation-12.	If any sites other than sears and kmart present in the input, then remove the site and do not populate web hierarchy/operational tag for that site
	 * @return
	 */
	public boolean verifyOtherSitesInCollection()
	{
		boolean IsValid = false;		
		String  partnumber = null;
		com.generated.xmls.collections.Site sites[] = null;
		sites =  collection.getCommonElementsGroup().getSite();
		
		if(sSiteToTest.equals("sears"))
		{
			partnumber = collection.getCollectionSearsPartNumber()+"B";
		}
		else
		{
			partnumber = collection.getCollectionKmartPartNumber()+"B";
		}
		
		
		//Check for other site other than 1-Kmart and 2-Sears 
		for(Site site: sites)
		{
			if(site.getId() !=1 || site.getId() != 2)
			{
				APIResponse<com.generated.vos.contentbco.Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENTBCO,partnumber.trim());
				com.generated.vos.contentbco.Bundle gbBundleContent = (com.generated.vos.contentbco.Bundle)allResponse.getT();
				Sites siteList = gbBundleContent.getTaxonomy().getWeb().getSites();
					
				if(siteList.getCraftsman()==null && siteList.getInsco()==null && siteList.getKenmore()==null && siteList.getMygofer()==null && siteList.getPuertorico() ==null && siteList.getTgi() == null)
				{
					
					Sites__ operationalSites = gbBundleContent.getOperational().getSites();
					if(operationalSites.getMygofer() == null && operationalSites.getPuertorico()==null )
					{
						IsValid= true;
						break;
					}
					else
					{
						IsValid = false;
						break;
					}
				}
				else
				{
					IsValid = false;
					break;
				}
				
			}
			break;
		}
		
		/*if(IsValid)
		{
			IsDispCollection = true;
			IsProductTagEmpty = false;
			IsDispProduct = true;
		}*/
		return IsValid;		
	}
	
	
	
	

	private void verifyProduct(
			String id, 
			ItemPartNumber item, 
			Content gbContent, 
			Product gbBundleProduct) {
		
		CompareValuesUtility.compareValues("Products", id, gbBundleProduct.getId(), "Id");
		CompareValuesUtility.compareValues("Products", item.getRank().intValue(), gbBundleProduct.getRank(), "Rank");
		CompareValuesUtility.verifyNullOrEqual("Products", item.getQuantity()==null?null:item.getQuantity().intValue(), gbBundleProduct.getQuantity(), "Qty");
		CompareValuesUtility.compareValues("Products", gbContent.getName(), gbBundleProduct.getName(), "Name");
		CompareValuesUtility.verifyNullOrEqual("Products", gbContent.getBrand()==null?null:gbContent.getBrand().getName(), gbBundleProduct.getBrand(), "Brand");
		CompareValuesUtility.verifyNullOrEqual("Products", gbContent.getMfr()==null?null:gbContent.getMfr().getModelNo(), gbBundleProduct.getModelNo(), "ModelNo");
		
		List<com.generated.vos.content.Desc> desc = gbContent.getDesc();
		int i = getPositionInList("S", desc, "type", Desc.class);
		
		CompareValuesUtility.compareValues("Products", "S", gbBundleProduct.getDesc().getType(), "DescType");
		CompareValuesUtility.compareValues("Products", desc.get(i).getVal()==null?null:desc.get(i).getVal(), gbBundleProduct.getDesc()==null?null:gbBundleProduct.getDesc().getVal()==null?null:gbBundleProduct.getDesc().getVal(), "DescVal");
		
		List<Img_> imgs = gbContent.getAssets().getImgs();
		int j = getPositionInList("P", imgs, "type", Img_.class);
				
		if(j!=-1){
			CompareValuesUtility.compareValues("Products", "P", gbBundleProduct.getImgs().getType(), "ImgType");
			CompareValuesUtility.compareValues("Products", imgs.get(j).getVals().get(0).getSrc(), gbBundleProduct.getImgs().getVals().get(0).getSrc(), "ImgSrc");
			CompareValuesUtility.verifyNullOrEqual("Products", imgs.get(j).getVals().get(0).getHeight(), gbBundleProduct.getImgs().getVals().get(0).getHeight(), "ImgHeight");
			CompareValuesUtility.verifyNullOrEqual("Products", imgs.get(j).getVals().get(0).getWidth(), gbBundleProduct.getImgs().getVals().get(0).getWidth(), "ImgWidth");
			CompareValuesUtility.verifyNullOrEqual("Products", imgs.get(j).getVals().get(0).getTitle(), gbBundleProduct.getImgs().getVals().get(0).getTitle(), "ImgTitle");
		}
		
		CompareValuesUtility.verifyNullOrEqual("Products", gbContent.getOperational()==null?null:(gbContent.getOperational().getSites()==null?null:(gbContent.getOperational().getSites().getSears()==null?null:(gbContent.getOperational().getSites().getSears().getIsDispElig()))), 
				gbBundleProduct.getOperational()==null?null:(gbBundleProduct.getOperational().getSites()==null?null:(gbBundleProduct.getOperational().getSites().getSears()==null?null:(gbBundleProduct.getOperational().getSites().getSears().getIsDispElig()))),
						"SrIsDispElig");
		CompareValuesUtility.verifyNullOrEqual("Products", gbContent.getOperational()==null?null:(gbContent.getOperational().getSites()==null?null:(gbContent.getOperational().getSites().getKmart()==null?null:(gbContent.getOperational().getSites().getKmart().getIsDispElig()))), 
				gbBundleProduct.getOperational()==null?null:(gbBundleProduct.getOperational().getSites()==null?null:(gbBundleProduct.getOperational().getSites().getKmart()==null?null:(gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig()))),
						"KmIsDispElig");
		
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void verifyCollProduct(
			String id, 
			ItemPartNumber item, 
			Content gbContent, 
			CollProduct gbBundleProduct) {
		
		boolean IsProdDispElig = true;
		
		
		
		if(gbContent!=null)
		{
			CompareValuesUtility.compareValues("CollProduct.Id", id, gbBundleProduct.getId(), "Id");
			CompareValuesUtility.compareValues("CollProduct.Rank", item.getRank().intValue(), gbBundleProduct.getRank(), "Rank");
			if(item.getQuantity().intValue()==0 || item.getQuantity() == null)
				item.setQuantity(1L);
			CompareValuesUtility.verifyNullOrEqual("CollProduct.Quantity", item.getQuantity()==null?null:item.getQuantity().intValue(), gbBundleProduct.getQuantity(), "Qty");
			CompareValuesUtility.compareValues("CollProduct.Name", gbContent.getName(), gbBundleProduct.getName(), "Name");
			CompareValuesUtility.verifyNullOrEqual("CollProduct.Brand", gbContent.getBrand()==null?null:gbContent.getBrand().getName(), gbBundleProduct.getBrand(), "Brand");
			CompareValuesUtility.verifyNullOrEqual("CollProduct.Model", gbContent.getMfr()==null?null:gbContent.getMfr().getModelNo(), gbBundleProduct.getModelNo(), "ModelNo");
			CompareValuesUtility.compareValues("CollProduct.CatentrySubType", gbContent.getClassifications().getCatentrySubType(), gbBundleProduct.getCatentrySubType().name(), "catentrySubType");
			
			int i = -1;
			int iBundleIndex = -1;
				
			List<com.generated.vos.content.Desc> desc = gbContent.getDesc();		
			List<com.generated.vos.contentbco.Description> productDesc = gbBundleProduct.getDescription();		
			
			i = getPositionInList("S", desc, "type", Desc.class);
			
			if(i != -1 && i < 3 && productDesc != null)
			{
				iBundleIndex = getPositionInList("S", desc, "type", Desc.class);			
				CompareValuesUtility.compareValues("CollProduct.DescType", "S", gbBundleProduct.getDescription().get(iBundleIndex).getType(), "DescType");			
				CompareValuesUtility.compareValues("CollProduct.Descritpion", desc.get(i).getVal()==null?null:desc.get(i).getVal().trim(), productDesc.get(iBundleIndex).getVal().trim(),"DescVal");
			}
				
			
			i = getPositionInList("L", desc, "type", Desc.class);
			if(i != -1 && i < 3)	
			{
				iBundleIndex = getPositionInList("L", desc, "type", Desc.class);
				CompareValuesUtility.compareValues("CollProduct.DescType", "L", gbBundleProduct.getDescription().get(iBundleIndex).getType(), "DescType");
				CompareValuesUtility.compareValues("CollProduct.Descritpion", desc.get(i).getVal()==null?null:desc.get(i).getVal().trim(),productDesc.get(iBundleIndex).getVal().trim(),"DescVal");
			}
			i = getPositionInList("T", desc, "type", Desc.class);
			if(i != -1 && i < 3)
			{
				iBundleIndex = getPositionInList("T", desc, "type", Desc.class );
				CompareValuesUtility.compareValues("CollProduct.Descritpion", "T", productDesc.get(iBundleIndex).getType(), "DescType");
				compareValues("CollProduct.Descritpion", desc.get(i).getVal()==null?null:desc.get(i).getVal().trim(), productDesc.get(iBundleIndex).getVal().trim(), "DescVal");
				
			}
			
			
			List<Img_> imgs = gbContent.getAssets().getImgs();		
			List<Image> productImages = gbBundleProduct.getImages(); 
			
			//Primary Images
			i = getPositionInList("P", imgs, "type", Img_.class);		
				
				if(i !=-1 )
				{		
					CompareValuesUtility.compareValues("CollProduct.ImageType", "P", productImages.get(i).getType(), "ImgType");
					CompareValuesUtility.verifyNullOrEqual("CollProduct.Height", imgs.get(i).getVals().get(0).getHeight(), productImages.get(i).getVals().get(0).getHeight(), "ImgHeight");			
					CompareValuesUtility.compareValues("CollProduct.src", imgs.get(i).getVals().get(0).getSrc(), productImages.get(i).getVals().get(0).getSrc(), "ImgSrc");
					CompareValuesUtility.verifyNullOrEqual("CollProduct.Title", imgs.get(i).getVals().get(0).getTitle(), productImages.get(i).getVals().get(0).getTitle(), "ImgTitle");			
					CompareValuesUtility.verifyNullOrEqual("CollProduct.width", imgs.get(i).getVals().get(0).getWidth(), productImages.get(i).getVals().get(0).getWidth(), "ImgWidth");
					
				}
				
			
			//Alternate Images (Multiples)
			int val = 0;
			i = getPositionInList("A", imgs, "type", Img_.class);
			if(i != -1)
			 val = gbBundleProduct.getImages().get(i).getVals().size();
			
			
			
			if(i != -1 && val > 0)
			{
				for(int k= 0 ; k < val ; k++)
				{
					CompareValuesUtility.compareValues("CollProduct.ImageType", "A", productImages.get(i).getType(), "ImgType");
					CompareValuesUtility.verifyNullOrEqual("CollProduct.Height", imgs.get(i).getVals().get(k).getHeight(), productImages.get(i).getVals().get(k).getHeight(), "ImgHeight");
					CompareValuesUtility.compareValues("CollProduct.src", imgs.get(i).getVals().get(k).getSrc(), productImages.get(i).getVals().get(k).getSrc(), "ImgSrc");
					CompareValuesUtility.verifyNullOrEqual("CollProduct.Title", imgs.get(i).getVals().get(k).getTitle(), productImages.get(i).getVals().get(k).getTitle(), "ImgTitle");			
					CompareValuesUtility.verifyNullOrEqual("CollProduct.Width", imgs.get(i).getVals().get(k).getWidth(), productImages.get(i).getVals().get(k).getWidth(), "ImgWidth");				
				}
				
			}
			
			
			/** Check ssin's content exists*/
			if(!gbContent.getIdentity().getSsin().equals(id))
			{
				Content ssinContent = RestExecutor.getDataById(CollectionValuesVal.CONTENT,gbContent.getIdentity().getSsin());
				if(ssinContent == null || (ssinContent.getOperational().getIsMarkForDelete() != null && ssinContent.getOperational().equals(true)))
					IsProdDispElig = false;
			}else{
				if(gbContent.getOperational().getIsMarkForDelete() != null && gbContent.getOperational().getIsMarkForDelete().equals(true))
					IsProdDispElig = false;
			}
			
			
			
							
			CompareValuesUtility.verifyNullOrEqual("CollProduct.SSIN", gbContent.getIdentity().getSsin()==null?null:gbContent.getIdentity().getSsin(), gbBundleProduct.getSsin(),"Ssin");
			CompareValuesUtility.verifyNullOrEqual("CollProduct.url", gbContent.getSeo().getUrl()==null?null:gbContent.getSeo().getUrl(), gbBundleProduct.getUrl(), "url");
			
			//Check display Eligibility
			// Validation #2, #3
			if(!IsProdDispElig ||verifyProductDispEligibility(gbContent,id) == false )
			{
				if(sSiteToTest.equalsIgnoreCase("sears")){
					CompareValuesUtility.compareValues("CollProduct.IsProdDispElig", false, gbBundleProduct.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
					//original commented on 06_07_2016 avinash if(gbContent.getOperational().getSites().getKmart() != null)
					if(offerToTakeDataFrom != null && offerToTakeDataFrom.getOperational().getSites().getKmart() != null )
						CompareValuesUtility.compareValues("CollProduct.IsProdDispElig", offerToTakeDataFrom.getOperational().getSites().getKmart().getIsDispElig(), gbBundleProduct.getOperational().getSites().getKmart() == null? false : gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
						
				}
				if(sSiteToTest.equalsIgnoreCase("kmart")){
					CompareValuesUtility.compareValues("CollProduct.IsProdDispElig", false, gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
					//original commented on 06_07_2016 avinash if(gbContent.getOperational().getSites().getSears() != null)
					if(offerToTakeDataFrom != null && offerToTakeDataFrom.getOperational().getSites().getSears() != null)
						CompareValuesUtility.compareValues("CollProduct.IsProdDispElig",  offerToTakeDataFrom.getOperational().getSites().getSears().getIsDispElig(),gbBundleProduct.getOperational().getSites().getSears() == null? false:gbBundleProduct.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
				}

				
				//Validation #6.	If there is no online and shippable offer available for any product, then offerId, uid, isSearchSupression , ffm.fulfilledBy, ffm.channel will be populated as null.
				
				CompareValuesUtility.verifyNull("CollProduct.OfferId",  gbBundleProduct.getOfferId(),"OfferId");
				CompareValuesUtility.verifyNull("CollProduct.Uid",  gbBundleProduct.getUid(),"Uid");
				CompareValuesUtility.verifyNull("CollProduct.IsSearchSupression",  gbBundleProduct.getIsSearchSupression(),"IsSearchSupression");
				CompareValuesUtility.verifyNull("CollProduct.ffm.FulfilledBy",  gbBundleProduct.getFfm() == null? null:gbBundleProduct.getFfm().getFulfilledBy(), "ffm.fulfilledBy");
				CompareValuesUtility.verifyNull("CollProduct.ffm.Channel",  gbBundleProduct.getFfm()==null?null:gbBundleProduct.getFfm().getChannel(), "ffm.channel");
			}
			else
			{
				if(sSiteToTest.equalsIgnoreCase("sears"))
				{
					CompareValuesUtility.compareValues("CollProduct.IsProdDispElig", true,gbBundleProduct.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
					
					//original commented on 06_07_2016 Avinash if(gbContent.getOperational().getSites().getKmart()!=null)
					if(offerToTakeDataFrom.getOperational().getSites().getKmart()!=null)
						// original code commented on 06_07_2016 Avinash CompareValuesUtility.compareValues("CollProduct", gbContent.getOperational().getSites().getKmart().getIsDispElig(),gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");	
						CompareValuesUtility.compareValues("CollProduct", offerToTakeDataFrom.getOperational().getSites().getKmart().getIsDispElig(),gbBundleProduct.getOperational().getSites().getKmart() == null ? false:gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
				}
				else
				{
					CompareValuesUtility.compareValues("CollProduct.IsProdDispEligForKmart", true, gbBundleProduct.getOperational().getSites().getKmart().getIsDispElig(), "IsDispElig");
					//Added on 06_07_2016 Avinash
					if(offerToTakeDataFrom.getOperational().getSites().getSears() != null)
						// commented on 06_07_2016 avinash CompareValuesUtility.compareValues("CollProduct.IsProdDispEligForSears", gbContent.getOperational().getSites().getSears().getIsDispElig(), gbBundleProduct.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
						CompareValuesUtility.compareValues("CollProduct.IsProdDispEligForSears", offerToTakeDataFrom.getOperational().getSites().getSears().getIsDispElig(), gbBundleProduct.getOperational().getSites().getSears() == null?false:gbBundleProduct.getOperational().getSites().getSears().getIsDispElig(), "IsDispElig");
				}				
					
				CompareValuesUtility.compareValues("CollProduct.offerId",offerToTakeDataFrom.getId(),gbBundleProduct.getOfferId(),"OfferId");
				
				CompareValuesUtility.verifyNullOrEqual("CollProduct.IsSearchSupression", offerToTakeDataFrom.getDispTags().getIsSearchSupression(), gbBundleProduct.getIsSearchSupression(),"IsSearchSupression");
				
				//ffm
				CompareValuesUtility.compareValues("CollProduct.ffm.FulfilledBy", offerToTakeDataFrom.getFfm().getFulfilledBy(), gbBundleProduct.getFfm().getFulfilledBy(), "fulfilledBy");
				CompareValuesUtility.compareValues("CollProduct.ffm.Channel", offerToTakeDataFrom.getFfm().getChannel(),gbBundleProduct.getFfm().getChannel(),"Channel");			
				
				CompareValuesUtility.verifyNullOrEqual("CollProduct.SizechartUrl", gbContent.getBrand().getBrandSizechartUrl()==null?null:gbContent.getBrand().getBrandSizechartUrl(), gbBundleProduct.getSizeChartUrl(), "sizeChartUrl");			
			
				CompareValuesUtility.compareValues("CollProduct.Uid", offerToTakeDataFrom.getIdentity().getUid(), gbBundleProduct.getUid(), "Uid");
			}				
			
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyBundle(
			Boolean fixedPriceBundleFlag,
			BundleTypeChoiceItem[] bundleTypeChoiceItems, 
			ProductAttributes productAttributes, 
			com.generated.vos.contentbco.Bundle gbBundleContent) {
		
		Boolean isBndlPromoReqd = false;
		if(productAttributes!=null){
			for(ProductAttribute prodAttr : productAttributes.getProductAttribute()){
				if(prodAttr.getAttributeId().toString().equals("798110") 
						&& prodAttr.getProductAttributeTypeChoice().getAttributeValueFlag()){
					isBndlPromoReqd = true;
				}
			}
		}
		
		CompareValuesUtility.verifyNullOrEqual("DispTags", fixedPriceBundleFlag?fixedPriceBundleFlag:null, gbBundleContent.getDispTags()==null?null:gbBundleContent.getDispTags().getIsFxdPriceBndl(), "isFxdPriceBndl");
		CompareValuesUtility.verifyNullOrEqual("DispTags", isBndlPromoReqd?isBndlPromoReqd:null, gbBundleContent.getDispTags()==null?null:gbBundleContent.getDispTags().getIsBndlPromoReqd(), "isBndlPromoReqd");
		
		for(BundleTypeChoiceItem bndlChoice : bundleTypeChoiceItems){
			for(GroupsTypeChoiceItem group : bndlChoice.getBundleGroups().getGroupsTypeChoice().getGroupsTypeChoiceItem()){
				Boolean gFound = false;
				GroupType xmlGrp = group.getRequiredGroup()==null?group.getOptionalGroup():group.getRequiredGroup();
				String type = group.getRequiredGroup()==null?"optional":"required";
				//System.out.println(type+"-"+xmlGrp.getName()+"-"+xmlGrp.getRank());
				
				for(BundleGroup gbBndlGrp : gbBundleContent.getBundleGroup()){
					
					if(xmlGrp.getName().equals(gbBndlGrp.getName()) 
							&& xmlGrp.getRank().toString().equals(gbBndlGrp.getRank())
							&& type.equals(gbBndlGrp.getType())){
						gFound = true;
						CompareValuesUtility.compareValues("BundleGroup", xmlGrp.getName(), gbBndlGrp.getName(), "Name");
						CompareValuesUtility.compareValues("BundleGroup", xmlGrp.getRank(), gbBndlGrp.getRank(), "Rank");
						CompareValuesUtility.compareValues("BundleGroup", type, gbBndlGrp.getType(), "Type");
						
						for(ItemPartNumber xmlItem : xmlGrp.getItemPartNumber()){

							String id;
							if(sSiteToTest.equals("sears")){
								id = xmlItem.getItemSearsPartNumber()+"P";
							}else{
								id = xmlItem.getItemKmartPartNumber()+"P";
							}
							
							com.generated.vos.content.Content gbContent = RestExecutor.getDataById(CollectionValuesVal.CONTENT,id);
							
							if(gbContent==null){
								System.out.println("Product not present in GB content: " + id);
								continue;
							}
							//Check if bundle has been last updated by operational) - skip the failure - ideally should be caught by operational job run
							if(gbBndlGrp.getProducts().isEmpty() && (gbBundleContent.getMeta().getLastModifiedBy().contains("operational") ||
									gbBundleContent.getMeta().getLastModifiedBy().contains("oper_load")))
								continue;
							
							Boolean pFound = false;
							for(Product gbBdPrd : gbBndlGrp.getProducts()){
								if(id.equals(gbBdPrd.getId())){
									pFound = true;
									verifyProduct(id, xmlItem, gbContent, gbBdPrd);
									break; //when product found
								}
							}
							if(!pFound){
								//If product not found, checking operational and dispelig in offer
								if(gbBundleContent.getMeta().getLastModifiedBy().contains("operational") || gbBundleContent.getMeta().getLastModifiedBy().contains("oper_load") ){
									Offer offer =RestExecutor.getDataById(CollectionValuesVal.OFFER, id.substring(0, id.length()-1));
									if (offer == null || (sSiteToTest.equalsIgnoreCase("sears")&& offer.getOperational().getSites().getSears().getIsDispElig().equals(false))
									|| (sSiteToTest.equalsIgnoreCase("kmart") && offer.getOperational().getSites().getKmart().getIsDispElig().equals(false)))
										
										continue;
								}
								CompareValuesUtility.compareValues("Products", id, " Product not found under bundleGroup: "+type+"-"+xmlGrp.getName());
							}
						}
						break; //when group found
					}
				}
				if(!gFound){
					Boolean pFound = false;
					for(ItemPartNumber xmlItem : xmlGrp.getItemPartNumber()){
						if(sSiteToTest.equals("sears")){
							if(xmlItem.getItemSearsPartNumber()!=null){
								pFound = true;
								break;
							}
						}else{
							if(xmlItem.getItemKmartPartNumber()!=null){
								pFound = true;
								break;
							}
						}
					}
					if(pFound){
						CompareValuesUtility.compareValues("BundleGroup", type+"-"+xmlGrp.getName(), " Group not found under bundle");
					}else{
						System.out.println("Ignoring..." + sSiteToTest + " bundle group with no " + sSiteToTest + " product under it.");
					}
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFtSearch(APIResponse<com.generated.vos.contentbco.Bundle> allResponse) {
		CompareValuesUtility.compareValues("_ft.catentrySubType", catentrySubType, allResponse.getFtFieldValue("catentrySubType"));
		CompareValuesUtility.compareValues("_search.spinId", spinId, allResponse.getSearchFieldValue("spinId"));
		
	}

	private void verifyCommonElements(CommonElementsGroup commonElementsGroup,
			FeatureTopDescriptions topDesc, com.generated.vos.contentbco.Bundle gbBundleContent, String id, String soldBy) {
		
		//Print the double value in without exponential form
		DecimalFormat df = new DecimalFormat("#");
		df.setMaximumFractionDigits(0);
		
		CompareValuesUtility.compareValues("Id", id, gbBundleContent.getId());
		CompareValuesUtility.compareValues("Name", TestUtils.plainEncodeHTML(OfferCommons.escapeNewline(commonElementsGroup.getName())), gbBundleContent.getName());
		
		/* ---------------- desc --------------- */
		commonUtils.verifyDesc(commonElementsGroup.getFeatureDescription(), commonElementsGroup.getMarketingDescription(), gbBundleContent.getDesc(), true);

		if(topDesc != null){
			commonUtils.verifyTopDescriptions(topDesc.getFeatureTopDescription(), gbBundleContent.getDesc());
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/* ---------------- brand --------------- */
		commonUtils.verifyBrand(commonElementsGroup.getBrand(), gbBundleContent.getBrand());
		
		/*CompareValuesUtility.verifyNullOrEqual("Brand",commonElementsGroup.getBrand()==null?null:commonElementsGroup.getBrand().getId(),gbBundleContent.getBrand()==null?null:gbBundleContent.getBrand().getId().intValue(), "id");
		CompareValuesUtility.verifyNullOrEqual("Brand",commonElementsGroup.getBrand()==null?null:commonElementsGroup.getBrand().getName(),gbBundleContent.getBrand()==null?null:gbBundleContent.getBrand().getName(), "name");
		String xmlBrandUrl = (commonElementsGroup.getBrand()==null||commonElementsGroup.getBrand().getLogoImageUrl()==null)?null:commonElementsGroup.getBrand().getLogoImageUrl().replaceAll("http://i.sears.com/s/", "http://c.shld.net/rpx/i/s/").replaceAll("http://s7.sears.com/", "http://s.shld.net/").replaceAll("http://s7.kmart.com/", "http://s.shld.net/");
		CompareValuesUtility.verifyNullOrEqual("Brand",xmlBrandUrl,(gbBundleContent.getBrand()==null||gbBundleContent.getBrand().getImg()==null)?null:gbBundleContent.getBrand().getImg().getAttrs().getSrc(), "logoImageUrl");
		CompareValuesUtility.addNewMultiValuedFields();*/
		
		//Existing Code commented by Avinash
		/*CompareValuesUtility.verifyNullOrEqual("Mfr", commonElementsGroup.getManufacturerName(), gbBundleContent.getMfr()==null?null:gbBundleContent.getMfr().getName(), "name");
		CompareValuesUtility.verifyNullOrEqual("Mfr", commonElementsGroup.getManufacturerModelNumber(), gbBundleContent.getMfr()==null?null:gbBundleContent.getMfr().getModelNo(), "modelNo");
		*/
		
		//Check if collection only
		if(!isBundle)
		{
			CompareValuesUtility.verifyNullOrEqual("Mfr", commonElementsGroup.getManufacturerName(), gbBundleContent.getMfr()==null?null:gbBundleContent.getMfr().getName(), "name");
			CompareValuesUtility.verifyNullOrEqual("Mfr", commonElementsGroup.getManufacturerModelNumber(), gbBundleContent.getMfr()==null?null:gbBundleContent.getMfr().getModelNo(), "modelNo");
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/* ---------------- seo --------------- */
		commonUtils.verifySeo(commonElementsGroup.getSeo(), gbBundleContent);
		
		/*if(commonElementsGroup.getSeo()!=null){
			CompareValuesUtility.compareValues("Seo", commonElementsGroup.getSeo().getSeoRobotFollowFlag(), gbBundleContent.getSeo().getIsRobotFollow(), "isRobotFollow");
			CompareValuesUtility.compareValues("Seo", commonElementsGroup.getSeo().getSeoRobotIndexFlag(), gbBundleContent.getSeo().getIsRobotIndex(), "isRobotIndex");
			CompareValuesUtility.verifyNullOrEqual("Seo", commonElementsGroup.getSeo().getSeoProductAltTag(), gbBundleContent.getSeo().getProductAltTag(), "productAltTag");
			CompareValuesUtility.verifyNullOrEqual("Seo", commonElementsGroup.getSeo().getSeoFeatureAltTag(), gbBundleContent.getSeo().getFeatureAltTag(), "featureAltTag");
			CompareValuesUtility.addNewMultiValuedFields();
		}*/
			
		catentrySubType = "C";
		
		if(isBundle)
			catentrySubType = "B";
		else if(commonElementsGroup.getProductAttributes()!=null){
			for(ProductAttribute prodAttr : commonElementsGroup.getProductAttributes().getProductAttribute()){
				if(prodAttr.getAttributeId().toString().equals("777310") 
						&& prodAttr.getProductAttributeTypeChoice().getAttributeValueId().toString().equals("19")){
					catentrySubType = "O";
				}
			}
		}
		
		CompareValuesUtility.compareValues("Classifications", "C", gbBundleContent.getClassifications().getCatentryType(), "catentryType");
		CompareValuesUtility.compareValues("Classifications", catentrySubType, gbBundleContent.getClassifications().getCatentrySubType(), "catentrySubType");
		CompareValuesUtility.compareValues("Classifications", "S", gbBundleContent.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
		CompareValuesUtility.compareValues("Classifications", "false", gbBundleContent.getClassifications().getIsMarketplace(), "isMarketplace");
		CompareValuesUtility.addNewMultiValuedFields();
		
		//Existing Code commented
		if(catentrySubType.equalsIgnoreCase("B")){
			CompareValuesUtility.compareValues("Ffm", soldBy, gbBundleContent.getFfm().getFulfilledBy(), "fulfilledBy");
			CompareValuesUtility.verifyNullOrEqual("Ffm", !(commonElementsGroup.getWebOnlyFlag())?null:commonElementsGroup.getWebOnlyFlag(), gbBundleContent.getFfm().getIsWebExcl(), "isWebExcl");
		}
		
		CompareValuesUtility.compareValues("Ffm", soldBy, gbBundleContent.getFfm().getSoldBy(), "soldBy");
		
		
		CompareValuesUtility.addNewMultiValuedFields();
		
		//Get Double value without exponential form

		if(gbBundleContent.getAltIds().getSpinId()!=null)
		{
			Double d = Double.valueOf(gbBundleContent.getAltIds().getSpinId());
			CompareValuesUtility.compareValues("AltIds", spinId, df.format(d), "spinId");
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
		
		/***Validate sites***/
		commonUtils.verifySites(commonElementsGroup, gbBundleContent.getSites(), isCrossFormatted);
		/***assets***/
		verifyAssets(commonElementsGroup, gbBundleContent.getAssets());
		/***Facets***/
		verifyFacetsGB(commonElementsGroup, gbBundleContent);
		/***Specs***/
		verifySpecsGB(gbBundleContent.getSpecs());
		/***Taxonomy***/
		verifyTaxonomy(commonElementsGroup.getSite(), gbBundleContent);
	}
	
	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	List<String> lstAttributeVals = new ArrayList<String>();
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	List<String>  lstAttribsNotFound = new ArrayList<>();
	String brandCodeId = null, autoFitmentType = null;
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "1109310","12206","798110","1025310","777310","781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });

	private void verifyAssets(CommonElementsGroup commonElementsGroup, com.generated.vos.contentbco.Assets assets){

		commonUtils.verifyAssets(commonElementsGroup.getPrimaryImage(), commonElementsGroup.getFeatureImages(), assets);

		if(commonElementsGroup.getProductAssets() != null){
			commonUtils.verifyAssetAttachments(commonElementsGroup.getProductAssets().getProductAsset(), assets.getAttachments());

			commonUtils.verifyAssetVideo(commonElementsGroup.getProductAssets().getProductAsset(), assets.getVideos());
		}
		/*if(commonElementsGroup.getContentExtensions()!= null)
			commonUtils.verifyContentExtension(commonElementsGroup.getContentExtensions().getProvider(0), assets.getContentExtensions().get(0));*/
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	public void verifySpecsGB(List<com.generated.vos.contentbco.Spec> list) {

		if(masterHierarchyAttributes == null){
			return;
		}

		if(lstSpecAttributes.isEmpty()){
			CompareValuesUtility.verifyTrue(list.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(list.isEmpty(),"SpecName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(list.isEmpty(),"SpecVal", "No specs expected", "Specs found");

			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstSpecAttributes);
		//Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValDataNew(lstAttributeVals, lstSpecAttributes, attributeToVal);
		
		verifySpecValues(attributeData, attributeValData, list);

	}
	
	private void verifySpecValues(Map<String, String> attribData,  Map<String, String> attribValData,List<com.generated.vos.contentbco.Spec> list)
	{
		for(String attributeId : lstSpecAttributes)
		{
			String grpNameIA = attributeToGroup.get(attributeId)==null?"Others:":attributeToGroup.get(attributeId);
			boolean bAttributeFound = false;
			boolean bGroupFound = false;
			boolean bAttrValueFound = false;
//			boolean bIsDoNotDisplaySpecFound = false;
			String val;
//			String displayEligibility = GreenBoxCache.isDoNotDisplay(attributeId);
			for (com.generated.vos.contentbco.Spec spec : list) {
				String grpNameJson = spec.getGrpName();
				if(grpNameIA.equals(grpNameJson)){
					bGroupFound = true;
					for(com.generated.vos.contentbco.Attr attr : spec.getAttrs()){

						/*if(displayEligibility!= null && attr.getName().equals(displayEligibility)){
							bIsDoNotDisplaySpecFound = true;
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName",displayEligibility+ ": Do not display set("+attributeId+").  Attribute should not be in specs.", attr.getName() + " found in specs");
							break;
						}*/
						//Checking to prevent it getting printed everytime the same attribute is found 
						if (attr.getName().equals(attribData.get(attributeId))){
							if(!bAttributeFound){
								CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
								bAttributeFound = true;
								CompareValuesUtility.logPassed("SpecName",attribData.get(attributeId), attr.getName());
							}

							boolean bRes;
							try {
								bRes = bAttributeFound && 
										(attributeToVal.get(attributeId).equals(attr.getVal()) 
											|| TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attributeToVal.get(attributeId))).equals(attr.getVal()) 
											|| TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attribValData.get(attributeToVal.get(attributeId)))).equals(attr.getVal()));
							} catch (Exception e) {
								bRes = false;
							}

							if(bRes){
								bAttrValueFound = true;

								if(attributeToVal.get(attributeId).equals(attr.getVal())){
									CompareValuesUtility.logPassed("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}else
								{
									if(TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attributeToVal.get(attributeId))).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal", TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attributeToVal.get(attributeId))) , attr.getVal());
									
									else if (TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attribValData.get(attributeToVal.get(attributeId)))).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal",TestUtils.replaceDoubleQuotesWithHTML(TestUtils.plainEncodeHTML(attribValData.get(attributeToVal.get(attributeId)))) , attr.getVal());
								}
								break;
							}
						}
					}

					//If attribute is donotdisplay type and is not displayed, mark as passed
				/*	if(displayEligibility!= null && !bIsDoNotDisplaySpecFound){
						CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
						CompareValuesUtility.logPassed("SpecName", attributeId+":"+displayEligibility, "Do not display set.Not found in specs.");
					}*/
					//Do the following checks only for displayable attributes
//					if(displayEligibility == null){
						if(!bAttributeFound){
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
						}
						if(bAttributeFound && !bAttrValueFound){
							CompareValuesUtility.logFailed("SpecVal", attributeToVal.get(attributeId), "Not found");
						}
//					}
					break;
				}
			}

			if(!bAttributeFound && !bGroupFound){
				val = attribValData.get(attributeToVal.get(attributeId));
				if(val!=null){
					CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private void verifyFacetsGB(CommonElementsGroup commonElementsGroup,
			com.generated.vos.contentbco.Bundle gbBundleContent) {
		if(commonElementsGroup.getProductAttributes()==null)
			return;

		masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
		if(masterHierarchyAttributes == null){
			CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
			return;
		}

		segregateAttributes(commonElementsGroup.getProductAttributes().getProductAttribute());

		if(lstFacetAttributes.isEmpty()){
			CompareValuesUtility.verifyNull("FacetName", gbBundleContent.getFacets());
			CompareValuesUtility.verifyNull("FacetVal", gbBundleContent.getFacets());
			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
		//Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValDataNew(lstAttributeVals, lstFacetAttributes, attributeToVal);

		List<com.generated.vos.contentbco.Static_> staticFacets=null;

		String val = null ;

		if(sSiteToTest.equalsIgnoreCase("sears"))
			staticFacets = gbBundleContent.getFacets() == null? null: gbBundleContent.getFacets().getSites().getSears().getStatic();
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
			staticFacets = gbBundleContent.getFacets() == null? null: gbBundleContent.getFacets().getSites().getKmart().getStatic();

		for(String facetAttributeId : lstFacetAttributes){
			boolean bFound = false;
			boolean bAttrValueFound = false;
			if(staticFacets ==  null){
				val = attributeValData.get(attributeToVal.get(facetAttributeId));
				//Original Avinah commented on 04_07_206 at 4:00 pm 
				//if(val != null){
				if(val == null){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found");
					continue;
				}
			}
			for(com.generated.vos.contentbco.Static_ gbFacet : staticFacets){
				if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
					if(!bFound){
						bFound = true;
						CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId));
					}

					val = attributeValData.get(attributeToVal.get(facetAttributeId));
					val= val==null?"null":val;

					if(bFound &&
							(attributeToVal.get(facetAttributeId).equals(gbFacet.getValue())
									|| val.equals(gbFacet.getValue())))
					{
						bAttrValueFound = true;
						if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
							compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue());
						else //free value
							compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue());
						break;
					}
				}
			}
			if(!bFound){
				
				val = attributeValData.get(attributeToVal.get(facetAttributeId));
				if(val!=null){
					CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found");
				}
			}

			if(!bAttrValueFound){
				if(val!=null){
					CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found");
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
	}
	
	private void segregateAttributes(ProductAttribute[] productAttributes){

		String sAttrId;
		String sValFree;
		String valueFlag;
		String sValId;

		for(ProductAttribute attributeXML : productAttributes ){

			sAttrId = String.valueOf(attributeXML.getAttributeId().intValue());

			sValFree = attributeXML.getProductAttributeTypeChoice().getAttributeValueFree();

			valueFlag = String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueFlag());

			try {
				sValId =String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueId().intValue());
			} catch (Exception e) {
				sValId = null;
			}

			if(autoIds.contains(sAttrId)){
				if(sAttrId.equals("873910")){
					brandCodeId = sValFree;
				}
				if(sAttrId.equals("1035210")){
					switch(sValId){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}

					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(sAttrId) )
				continue;
			boolean bFound = false;

			//label is array
			for(Label label : masterHierarchyAttributes.getLabels())
			{
				//each label has attr array again
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs())
				{
					if(sAttrId.equals(attr.getId()) && (attr.getType().contains("search") 
							|| attr.getType().contains("label")))
					{
						bFound = true;
						if(attr.getType().contains("search"))
							lstFacetAttributes.add(sAttrId);
						if( attr.getType().contains("label")){
							lstSpecAttributes.add(sAttrId);
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());

						}
						attributeToGroup.put(sAttrId, label.getName());

						if(sValId != null)
							lstAttributeVals.add(sValId);

						//Commenting td text - ECOM-361803

						/*if(attributeXML.getTrademarkText() != null){
							attributeToVal.put(sAttrId, attributeXML.getTrademarkText());
						}
						else 
						 */


						if( sValFree != null)
							attributeToVal.put(sAttrId, sValFree);
						else if(valueFlag != null && !valueFlag .equals("null"))
							attributeToVal.put(sAttrId, valueFlag.toString());
						else if(sValId != null){
							lstAttributeVals.add(sValId);
							attributeToVal.put(sAttrId, sValId);
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
							//							throw new IllegalArgumentException("No attribute val data found");

							break;
					}

				}
				if(bFound)
					break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(sAttrId);
			}
		}
	}
	
	boolean isPrimaryAvlbl = false; 
	
	private void verifyTaxonomy(com.generated.xmls.collections.Site[] sites, com.generated.vos.contentbco.Bundle gbBundleContent) {
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();

		for ( com.generated.xmls.collections.Site site : sites) {

			long lSiteId = site.getId();

			//Added check to ignore mygofer and pr for collections
			if(lSiteId > 11 || lSiteId == 10 ||(!isBundle && (lSiteId == 4 || lSiteId == 11 )))
				continue;
			/*if(!isCrossFormatted && ((sSiteToTest.equals("sears") && lSiteId == 1) || (sSiteToTest.equals("kmart") && lSiteId == 2)))
				continue;*/

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				if(hierarchy.getPrimary().toString().equals("true"))
					isPrimaryAvlbl = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, 
							gbBundleContent.getTaxonomy() == null? null : gbBundleContent.getTaxonomy().getWeb(),
							sSiteToTest,
							isCrossFormatted);

		commonUtils.compareMasterhierarchyGB(Long.parseLong(itemClassId), 
				gbBundleContent.getTaxonomy() == null? null : gbBundleContent.getTaxonomy().getMaster().getHierarchy());
	}

}
