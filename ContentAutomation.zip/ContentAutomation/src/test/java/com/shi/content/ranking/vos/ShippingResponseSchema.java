package com.shi.content.ranking.vos;

public class ShippingResponseSchema {
	
	private Shippingdetailsresponse shippingdetailsresponse;

	public Shippingdetailsresponse getShippingdetailsresponse() {
		return shippingdetailsresponse;
	}

	public void setShippingdetailsresponse(
			Shippingdetailsresponse shippingdetailsresponse) {
		this.shippingdetailsresponse = shippingdetailsresponse;
	}

}
