package com.shi.content.northstar.pages;

import com.shc.content.webdriver.html.Label;


public class Header {

	private Label statusMessage = new Label("//*[contains(text(),'Close Store Success')]","Status message");

	public Label getStatusMessage() {
		return statusMessage;
	}
	
	public String getStatus() {
		return statusMessage.getText();
	}

	
	
}
