package com.shi.content.acme.threezero;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.itemauthority.reconciled.Attributes;
import com.generated.vos.itemauthority.reconciled.Contributors;
import com.generated.vos.itemauthority.reconciled.ReconciledResponse;
import com.google.gson.Gson;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.threezero.vos1.Priority;
import com.shi.content.matching.SingleOfferMatchDataVo;

public class ACMEConfigBasedReconciliationTest 
{
	public static Map<Integer,List<String>> programTypeMap = new HashMap<Integer, List<String>>();
	
	public static String firstPriority;
	public static String secondPriority;
	public static String thirdPriority;

	@Test
	public void acmeThreeZeroTest()
	{
		String guid="372f14ee-4780-4222-ace5-37a58f9530f6";

		String sp[] =guid.split(",");
		
		for (String string : sp) {
			processSingleGuid(string);
		}
		
	}

	public static void processSingleGuid(String guid)
	{
		CompareValuesUtility.init();
		
		SingleOfferMatchDataVo winnerDocument = null;

		String resp =RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/reconciled/"+guid+"?refresh=true");

		System.out.println("reconciled.refresh : "+resp);

		/* ---------------------------------Get all sources---------------------------- */

		List<SingleOfferMatchDataVo > list = AcmeThreeHelper.getSourceItemsByGuid(guid);

		AcmeThreeHelper.updateMisClass(list);
		AcmeThreeHelper.updateContentScore(list);

		/* ----------------------------------------------------------------------------- */

		List<SingleOfferMatchDataVo> shortListed= processPriority(firstPriority, list);

		if(shortListed.size()==1)
		{
			System.out.println(" <<<<=========>>> Got winner @ level 1 : "+firstPriority);
			winnerDocument = shortListed.get(0);
		}
		else
		{
			System.out.println(" ===> No winner @ level 1 ");

			shortListed= processPriority(secondPriority, shortListed);

			if(shortListed.size()==1)
			{
				System.out.println(" <<<<=========>>>  Got winner @ level 2 : "+secondPriority);
				winnerDocument = shortListed.get(0);
			}
			else
			{
				System.out.println(" ===> No winner @ level 2 ");

				shortListed= processPriority(thirdPriority, shortListed);

				if(shortListed.size()==1)
				{
					System.out.println("  <<<<=========>>>  Got winner @ level 3 : "+thirdPriority);
					winnerDocument = shortListed.get(0);
				}
				else
				{
					System.out.println("===>  No winner @ level 3, Going by oldest spin Id ");
					winnerDocument = AcmeThreeHelper.getOldestSpinId(shortListed);
				}
			}
		}

		System.out.println("Winner document :  spinid : "+	winnerDocument.getSpinId() + " content id :"+winnerDocument.getContentId() );
		
		String winnerSourceResp =RestExecutor.getJSonResponse("http://iaapp3201p.qa.ch3.s.com:8180/acme/source/"+winnerDocument.getSpinId());
		
		Gson g= new Gson();
		AcmeSourceById iaSource = g.fromJson(winnerSourceResp, AcmeSourceById.class);
		
		String ownerid=iaSource.getItem().getAttributes().getOwnerId();
		String contentId=iaSource.getItem().getAttributes().getContentId();
		String finalSSIN=iaSource.getItem().getCalcSsin();
		
		System.out.println("finalSSIN... "+finalSSIN);
		ReconciledResponse recResp = g.fromJson(resp, ReconciledResponse.class);
		
		Attributes recoAttr = recResp.getItem().getAttributes();
		
		CompareValuesUtility.compareValues("ownerid", ownerid, recoAttr.getOwnerId().getValue());
		CompareValuesUtility.compareValues("contentId", contentId, recoAttr.getContentId().getValue());
		CompareValuesUtility.compareValues("SsinSourceId", winnerDocument.getSpinId(), recoAttr.getSsinSourceId().getValue());
		
		for (SingleOfferMatchDataVo singleSourceFromGUID : list) {
		
			System.out.println(singleSourceFromGUID.getSpinId()+"  : "+"contri ssin ... : "+singleSourceFromGUID.getSsin());
			CompareValuesUtility.addDataFieldForReport("contributor-spinId", singleSourceFromGUID.getSpinId());
			CompareValuesUtility.compareValues("contributor-ssin", finalSSIN,  singleSourceFromGUID.getSsin());
		}
		
		CompareValuesUtility.setupResult(guid,true);
	}


	@BeforeTest
	public void beforeWork()
	{
		/* --------------------------------Prepare Config--------------------------------- */

		AcmeThreeHelper.prepareConfig(programTypeMap);
		
		Priority p = AcmeThreeHelper.getPriority();

		firstPriority = p.getItem().getAttributes().get1();
		secondPriority = p.getItem().getAttributes().get2();
		thirdPriority = p.getItem().getAttributes().get3();
		
	}
	public static List<SingleOfferMatchDataVo>  processPriority(String nThPriority,List<SingleOfferMatchDataVo > list)	
			
			{
		List<SingleOfferMatchDataVo> shortListed=new ArrayList<SingleOfferMatchDataVo>();

		switch (nThPriority.toLowerCase()) {
		case "programtype":
			for (int i =1; i <=programTypeMap.size(); i++) {

				shortListed = AcmeThreeHelper.getShortListByProgramType(list, programTypeMap.get(i));

				if(shortListed.size()==0)
				{
					System.out.println("No item present in group with ProgramType @ Priority "+i+" : "+ programTypeMap.get(i) +", continue to next");
					continue;
				}
				System.out.println(" ===> ProgramType @ Priority "+i+ "-- > "+programTypeMap.get(i) + " --> shortList.size() : "+shortListed.size());

				return shortListed;
			}

			break;

		case "misclass":

			shortListed  = AcmeThreeHelper.getShortListByMisClassFalse(list);

			break;

		case "contentscore":

				shortListed  = AcmeThreeHelper.getShortListByContentScore(list);

			break;

		default:
			break;
		}

		return shortListed;
			}
}
