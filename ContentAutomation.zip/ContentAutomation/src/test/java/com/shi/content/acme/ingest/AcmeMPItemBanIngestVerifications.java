package com.shi.content.acme.ingest;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.net.URI;
import java.util.List;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;

public class AcmeMPItemBanIngestVerifications implements Runnable {

	private List<String> mpIBanMessages;

	public AcmeMPItemBanIngestVerifications(List<String> ids) {
		mpIBanMessages = ids;
	}

	public void run() {

		String idToTest = "";
		String statusToTest = "";
		
		try{
			
			for(String mpIBanMessage : this.mpIBanMessages){
				try{
					String ids = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.itemId");
					String statuses = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.itemStatus");
					
					String[] idLst = ids.split(";");
					String[] statusLst = statuses.split(";");
					
					for(int i=0; i < idLst.length; i++){
					
						idToTest = idLst[i];
						statusToTest = statusLst[i];
						
						CompareValuesUtility.init();
						
						System.out.println("Acme Id: " + idToTest);

						String sSrcURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+idToTest;
						String srcResponse = RestExecutor.getJSonResponse(new URI(sSrcURL));
						
						if (!srcResponse.contains("item")) {
							CompareValuesUtility.logPassed("id", idToTest, idToTest);
							CompareValuesUtility.setupResult(idToTest, true);
							continue;
						}
						
						AcmeSourceById acmeSource = JSONParser.parseJSON(srcResponse, AcmeSourceById.class);
						
						compareValues("id", idToTest, acmeSource.getItem().getId());
						compareValues("Status", statusToTest.contains("Banned")?"BANNED":"INACTIVE", acmeSource.getItem().getStatus());
						compareValues("AttrStatus", statusToTest.contains("Banned")?"BANNED":"INACTIVE", acmeSource.getItem().getAttributes().getStatus().getStatus());
						
						
						String receivedTime = JsonStringParser.getJsonValueNew(mpIBanMessage, "itemBan.transDtm");
						receivedTime=receivedTime==null?"":receivedTime;
						
						CompareValuesUtility.addDataFieldForReport("itemBan-transDtm",receivedTime);
						CompareValuesUtility.addDataFieldForReport("source-lastupdated",acmeSource.getItem().getLastUpdated());
						
						
						try {
							if((Long.parseLong(acmeSource.getItem().getLastUpdated()) - Long.parseLong(receivedTime))>0l)
							{
								CompareValuesUtility.addDataFieldForReport("source-updated-after-itemban",String.valueOf
										(Long.parseLong(acmeSource.getItem().getLastUpdated()) - Long.parseLong(receivedTime)));
							}
						} catch (Exception e) {
						}
						
						CompareValuesUtility.setupResult(idToTest, true);
					}
					
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Check this message "+ mpIBanMessage);
				}
			}
		
		}catch(Exception e){
			System.out.println("Exception for id:" + idToTest);
			e.printStackTrace();
			CompareValuesUtility.addDataFieldForReport("Exception", e.getStackTrace().toString(), INFOTYPE.FAILED);
		}
	}
}
