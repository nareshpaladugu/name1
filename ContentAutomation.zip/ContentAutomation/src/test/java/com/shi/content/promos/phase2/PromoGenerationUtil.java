package com.shi.content.promos.phase2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.Test;

import com.generated.vos.promokafka.Promo;
import com.generated.vos.promokafka.PromoKafka;
import com.generated.vos.promokafka.Rule;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.DBUtil;

/**
 * Quick utility to generate promo messages in kafka format
 * @author Niharika Varshney
 *
 */
public class PromoGenerationUtil {

	@Test(groups="PromoMessageGeneration")
	public void generateJson(){

		String promoId = LoadProperties.RUN_PARAMS;
		ResultSet rs = DBUtil.executeQueryReturnAll("select * from PROMO_DATA pd inner join promo_rule pr on pd.PROMO_ID = pr.PROMO_ID "+  
				"inner join promo_rule_details prd on  pr.PROMO_RULE_ID = prd.PROMO_RULE_ID "+ 
				"left outer join promo_attributes pa on prd.PROMO_RULEDT_ID = pa.PROMO_RULEDT_ID "+ 
				"left outer join promo_categories pc on prd.PROMO_RULEDT_ID = pc.PROMO_RULEDT_ID where pd.PROMO_ID = "+ promoId);

		Properties prop = new Properties();

		
		Promo promo = new Promo();
		promo.setPromoId(promoId);
		try {
			File propFile = new File("src/test/resources/PromoTestData/DealsDBToKafkaMapping");
			prop.load(new FileInputStream(propFile));
		} catch (IOException e) {
			e.printStackTrace();
		}

		try{
			rs.next();

			for(Object key : prop.keySet()){
				String fieldToVerify = (String)key;
				String fieldValue = rs.getString(prop.getProperty(fieldToVerify));
				System.out.println("Got value "+ fieldValue + "  "+ fieldToVerify );
				Field field = Promo.class.getDeclaredField(fieldToVerify);
				field.setAccessible(true);
				if( field.get(promo) instanceof List){
					
					System.out.println("list field "+ fieldToVerify);
					if(fieldValue.isEmpty())
						field.set(promo, null);
					else{
						String[] values = fieldValue.split(",");
						field.set(promo, Arrays.asList(values));
					}
				}
				else
					field.set(promo, PromoCommons.convertDefaults(fieldValue));


			}
			
			Map<String, Rule> returnedRules = PromoCommons.buildRuleObjects(rs);
			List<Rule> rules = new ArrayList<Rule>(returnedRules.values());
			promo.setRules(rules);
		}catch(Exception e){
			e.printStackTrace();
		}finally
		{
			DBUtil.closeCursor(rs);
		}

		PromoKafka prmKfk = new PromoKafka();
		prmKfk.setPromo(promo);
		
		Gson gson = new Gson();
		String jsonStringToPost = gson.toJson(prmKfk);
		
		Object data = removeEmptyProperties(jsonStringToPost);

		String json = new GsonBuilder().setPrettyPrinting().create().toJson(data);
		System.out.println(json);
		
		LoadProperties.setCustomMsgForEmail(json);
		

	}


	/**
	 * Removes empty arrays from coming in the resultant json string
	 * @param jsonString
	 * @return
	 */
	private Object removeEmptyProperties(String jsonString){
		Type type = new TypeToken<Map<String, Object>>() {}.getType();
		Map<String, Object> data = new Gson().fromJson(jsonString, type);

		for (Iterator<Map.Entry<String, Object>> it = data.entrySet().iterator(); it.hasNext();) {
		    Map.Entry<String, Object> entry = it.next();
		    System.out.println(entry.getKey());
		    if (entry.getValue() == null || (entry.getValue().getClass().equals(String.class) && ((String)entry.getValue()).isEmpty())) {
		        it.remove();
		    } else if (entry.getValue().getClass().equals(ArrayList.class)) {
		        if (((ArrayList<?>) entry.getValue()).size() == 0) {
		            it.remove();
		        }
		    }
		}
		return data;
	}
}
