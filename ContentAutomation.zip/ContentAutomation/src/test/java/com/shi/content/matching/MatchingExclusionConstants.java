package com.shi.content.matching;

public class MatchingExclusionConstants {

	public static final String ExcludedBrands = "NA,NOTAVAILABLE,INC,INC.,LLC,&NBSP;";

	public static final String ExcludedModels = "NA,809908510426,N,-F-39,True,CleverEve,1,Freeshippingonallordersover99,806593000000,883929000000,0,HPDV4L10612CTR1000,HPDV4L1066CTR1000";
	
	public static final String ExcludedDivLines = "022-09,022-15,022-20,022-21,022-22,022-25,022-41,026-01,026-02,042-03,042-15,046-01,046-02,046-04,046-51";
}
