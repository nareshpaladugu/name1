package com.shi.content.seller;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.seller.Seller;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class SellerLoadTests {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="SellerLoadTest")
	public void testSeller(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);

		BlockingQueue<List<Seller>> sellerQueue = new LinkedBlockingQueue<List<Seller>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Seller> prodThread = new ChunkProducerThread<Seller>(sFileName, sellerQueue, Seller.class,"seller");
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Seller> nodeToTest = sellerQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new SellerVerifications(nodeToTest.get(0)));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
