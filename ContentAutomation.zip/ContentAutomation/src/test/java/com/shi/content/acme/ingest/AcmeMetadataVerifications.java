package com.shi.content.acme.ingest;

import com.generated.xmls.attribute.AllowedValue;
import com.generated.xmls.attribute.Attribute;
import com.generated.xmls.masterhierarchy.Node;
import com.generated.xmls.seller.Seller;
import com.generated.xmls.storehierarchy.Level1;
import com.generated.xmls.storehierarchy.Level2;
import com.generated.xmls.storehierarchy.Level3;
import com.generated.xmls.storehierarchy.Level4;
import com.generated.xmls.vendor.Vendor;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class AcmeMetadataVerifications implements Runnable {

	Seller seller;
	Vendor vendor;
	Node node;
	Attribute attribute;
	Level1 level1;
	String feed;
	
	public AcmeMetadataVerifications(Seller seller) {
		this.seller = seller;
		this.feed = "mpSeller";
	}

	public AcmeMetadataVerifications(Vendor vendor) {
		this.vendor = vendor;
		this.feed = "spinVendor";
	}

	public AcmeMetadataVerifications(Node node) {
		this.node = node;
		this.feed = "masterTaxo";
	}

	public AcmeMetadataVerifications(Attribute attribute) {
		this.attribute = attribute;
		this.feed = "attributeType";
	}

	public AcmeMetadataVerifications(Level1 level1) {
		this.level1 = level1;
		this.feed = "storeTaxo";
	}

	@Override
	public void run() {
		
		String id = "";
		String url = "";
		String resp = null;
		try{
			CompareValuesUtility.init();
			
			switch(feed){
			case "mpSeller":
				id = seller.getSellerId().toString();
				url = "http://"+LoadProperties.IA_SERVER+"/acme/vendor/" + id;
				resp = RestExecutor.getJSonResponse(url);
				
				if(resp==null || !resp.contains("item")){
					CompareValuesUtility.logFailed("id", id, "Not found in vendor db");
				}else{
					CompareValuesUtility.compareValues("id", id, JsonStringParser.getJsonValue(resp, "{item{id}}"));
					CompareValuesUtility.compareValues("name", TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(seller.getName()), JsonStringParser.getJsonValue(resp, "{item{name}}"));
				}
				break;
				
			case "spinVendor":
				id = vendor.getId().toString();
				url = "http://"+LoadProperties.IA_SERVER+"/acme/vendor/" + id;
				resp = RestExecutor.getJSonResponse(url);
				
				if(resp==null || !resp.contains("item")){
					CompareValuesUtility.logFailed("id", id, "Not found in vendor db");
				}else{
					CompareValuesUtility.compareValues("id", id, JsonStringParser.getJsonValue(resp, "{item{id}}"));
					CompareValuesUtility.compareValues("name", TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(vendor.getName()), JsonStringParser.getJsonValue(resp, "{item{name}}"));
				}
				break;
							
			case "masterTaxo":
				id = node.getId().toString();
				url = "http://"+LoadProperties.IA_SERVER+"/acme/taxonomy/" + id;
				resp = RestExecutor.getJSonResponse(url);
				
				if(resp==null || !resp.contains("item")){
					CompareValuesUtility.logFailed("id", id, "Not found in taxonomy db");
				}else{
					CompareValuesUtility.compareValues("id", id, JsonStringParser.getJsonValue(resp, "{item{id}}"));
					CompareValuesUtility.compareValues("taxonomyId", id, JsonStringParser.getJsonValue(resp, "{item{taxonomyId}}"));
					CompareValuesUtility.compareValues("taxonomyName", node.getName(), JsonStringParser.getJsonValue(resp, "{item{taxonomyName}}"));
					CompareValuesUtility.verifyNullOrEqual("parentTaxonomyId", node.getParentNodeId()==null?null:node.getParentNodeId().toString(), JsonStringParser.getJsonValue(resp, "{item{parentTaxonomyId}}"));
				}
				break;
				
			case "attributeType":
				id = attribute.getId().toString();
				url = "http://"+LoadProperties.IA_SERVER+"/acme/attribute-type/" + id;
				resp = RestExecutor.getJSonResponse(url);
				
				if(resp==null || !resp.contains("item")){
					CompareValuesUtility.logFailed("id", id, "Not found in attributeType db");
				}else{
					CompareValuesUtility.compareValues("id", id, JsonStringParser.getJsonValue(resp, "{item{id}}"));
					CompareValuesUtility.compareValues("spinName", TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(attribute.getName()), JsonStringParser.getJsonValue(resp, "{item{spinName}}"));
					CompareValuesUtility.compareValues("displayName", TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(attribute.getDisplayName()), JsonStringParser.getJsonValue(resp, "{item{displayName}}"));
					CompareValuesUtility.verifyNullOrEqual("type", attribute.getDataType()==null?"STRING":(attribute.getDataType().equals("NUMERIC")?"NUMBER":attribute.getDataType()), JsonStringParser.getJsonValue(resp, "{item{type}}"));
					
					if(attribute.getAllowedValues()!=null){
						for(AllowedValue attval : attribute.getAllowedValues().getAllowedValue()){
							if(JsonStringParser.getJsonValue(resp, "{item{values{"+attval.getId()+"}}}")==null){
								CompareValuesUtility.logFailed("valueId", attval.getId(), "Not found for attribute: " + id);
							}else{
								CompareValuesUtility.compareValues("valueId", attval.getId(), attval.getId());
								CompareValuesUtility.compareValues("valueName", TestUtils.replaceDoubleQuotesWithSlashDoubleQuotes(attval.getName()), JsonStringParser.getJsonValue(resp, "{item{values{"+attval.getId()+"}}}"));
							}
						}
						CompareValuesUtility.addNewMultiValuedFields();
					}
				}
				break;
				
			case "storeTaxo":
				id = level1.getId().toString();
				url = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/" + id;
				resp = RestExecutor.getJSonResponse(url);
				
				if(resp==null || !resp.contains("item")){
					CompareValuesUtility.logFailed("id", id, "Not found in storetaxonomy db");
				}else{
					CompareValuesUtility.compareValues("id", id, JsonStringParser.getJsonValue(resp, "{item{id}}"));
					CompareValuesUtility.compareValues("taxonomyId", id, JsonStringParser.getJsonValue(resp, "{item{taxonomyId}}"));
					CompareValuesUtility.compareValues("divId", level1.getImaId(), JsonStringParser.getJsonValue(resp, "{item{divId}}"));
					
					for(Level2 level2 : level1.getLevel2()){
						String l2Id = level2.getId().toString();
						String l2Url = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/" + l2Id;
						String l2Resp = RestExecutor.getJSonResponse(l2Url);
						
						if(l2Resp==null || !l2Resp.contains("item")){
							CompareValuesUtility.logFailed("l2id", l2Id, "Not found in storetaxonomy db");
						}else{
							CompareValuesUtility.compareValues("l2id", l2Id, JsonStringParser.getJsonValue(l2Resp, "{item{id}}"));
							CompareValuesUtility.compareValues("l2taxonomyId", l2Id, JsonStringParser.getJsonValue(l2Resp, "{item{taxonomyId}}"));
							CompareValuesUtility.compareValues("l2divId", level2.getImaId(), JsonStringParser.getJsonValue(l2Resp, "{item{divId}}"));
							CompareValuesUtility.compareValues("l2parentTaxonomyId", id, JsonStringParser.getJsonValue(l2Resp, "{item{parentTaxonomyId}}"));
						}
						
						for(Level3 level3 : level2.getLevel3()){
							String l3Id = level3.getId().toString();
							String l3Url = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/" + l3Id;
							String l3Resp = RestExecutor.getJSonResponse(l3Url);
							
							if(l3Resp==null || !l3Resp.contains("item")){
								CompareValuesUtility.logFailed("l3id", l3Id, "Not found in storetaxonomy db");
							}else{
								CompareValuesUtility.compareValues("l3id", l3Id, JsonStringParser.getJsonValue(l3Resp, "{item{id}}"));
								CompareValuesUtility.compareValues("l3taxonomyId", l3Id, JsonStringParser.getJsonValue(l3Resp, "{item{taxonomyId}}"));
								CompareValuesUtility.compareValues("l3divId", level3.getImaId(), JsonStringParser.getJsonValue(l3Resp, "{item{divId}}"));
								CompareValuesUtility.compareValues("l3parentTaxonomyId", l2Id, JsonStringParser.getJsonValue(l3Resp, "{item{parentTaxonomyId}}"));
							}
							
							for(Level4 level4 : level3.getLevel4()){
								String l4Id = level4.getId().toString();
								String l4Url = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/" + l4Id;
								String l4Resp = RestExecutor.getJSonResponse(l4Url);
								
								if(l4Resp==null || !l4Resp.contains("item")){
									CompareValuesUtility.logFailed("l4id", l4Id, "Not found in storetaxonomy db");
								}else{
									CompareValuesUtility.compareValues("l4id", l4Id, JsonStringParser.getJsonValue(l4Resp, "{item{id}}"));
									CompareValuesUtility.compareValues("l4taxonomyId", l4Id, JsonStringParser.getJsonValue(l4Resp, "{item{taxonomyId}}"));
									CompareValuesUtility.compareValues("l4divId", level4.getImaId(), JsonStringParser.getJsonValue(l4Resp, "{item{divId}}"));
									CompareValuesUtility.compareValues("l4parentTaxonomyId", l3Id, JsonStringParser.getJsonValue(l4Resp, "{item{parentTaxonomyId}}"));
								}
							}
							CompareValuesUtility.addNewMultiValuedFields();
						}
						CompareValuesUtility.addNewMultiValuedFields();
					}
					CompareValuesUtility.addNewMultiValuedFields();
				}
				break;
			
			default:
				System.out.println("Invalid feed to test");
				break;
			}
			
			CompareValuesUtility.setupResult(id+"", true);
			
		}catch(Exception e){
			System.out.println("Check this id :"+ id);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}
}
