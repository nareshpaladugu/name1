package com.shi.content.storeLocalAd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.generated.vos.localadpage.Localadpage;
import com.generated.vos.localadpage.Product;
import com.generated.vos.offer.Offer;
import com.generated.xmls.storelocalad.Element;
import com.generated.xmls.storelocalad.Article;
import com.generated.xmls.storelocalad.Coord;
import com.generated.xmls.storelocalad.Media;
import com.generated.xmls.storelocalad.Page;
import com.generated.xmls.storelocalad.Property;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

import org.apache.log4j.Logger;

public class PageVerification implements Runnable
{
	Media media;
	Page page;
	Localadpage localadpage;
	private static final Logger log = Logger.getLogger(PageVerification.class.getName());

	public PageVerification(Media media, Page page)
	{
		this.media = media;
		this.page = page;
	}

	@Override
	public void run()
	{
		try
		{
			CompareValuesUtility.init();

			String pageId = page.getId();

			System.out.println("Testing pageId: " + page.getId() + " : Thread Name: " + Thread.currentThread().getName());

			localadpage=RestExecutor.getDataById(CollectionValuesVal.LOCALADPAGE, pageId);

			if(localadpage == null)
			{
				CompareValuesUtility.logFailed("Id", pageId, "Not found"); //Setup the result for this id
			}
			else
			{
				String dudeHostUrl = "http://env37.ca.s.com/s/i/la/image/";

				CompareValuesUtility.compareValues("Id", pageId, localadpage.getId());
				CompareValuesUtility.compareValues("ImageId", page.getAsset(0).getUrl(), localadpage.getImageId());
				CompareValuesUtility.compareValues("ImageUrl", page.getAsset(0).getUrl()==null?null:dudeHostUrl +page.getAsset(0).getUrl().replaceAll(".jpg",""), localadpage.getImageUrl()==null?null:localadpage.getImageUrl());

				for(Coord coord : Arrays.asList(page.getCoord()))
				{
					List<String> lstDivItemOrKsn = getDivItemOrKsn(coord);

					if(lstDivItemOrKsn.isEmpty())
					{
						continue;
					}
					for(String divItemOrKsn : lstDivItemOrKsn)
					{
						List<String> lstPartNumber = getListOfPartNumbers(divItemOrKsn);

						if((lstPartNumber != null) && !(lstPartNumber.isEmpty()))
						{
							for(String partNumber : lstPartNumber)
							{
								Offer offer = RestExecutor.getDataById(CollectionValuesVal.OFFER, partNumber);

								if(offer != null)
								{
									String soldBy = RestExecutor.getSpecificValueFromJson(CollectionValuesVal.OFFER, partNumber, "[{_blob{offer{ffm{soldBy}}}}]");

									if(!soldBy.equalsIgnoreCase(media.getMedia_type()))
									{
										continue;
									}
									String parentId = offer.getIdentity().getParentId();

									boolean cFound = false;
									for(com.generated.vos.localadpage.Element gbElement : localadpage.getElements())
									{
										if(coord.getPoints().equalsIgnoreCase(gbElement.getCoords())) // Why to check
										{
											CompareValuesUtility.compareValues("Coords", coord.getPoints(), gbElement.getCoords());

											boolean pFound =false;

											for(Product prodId: gbElement.getProducts())
											{
												if(parentId.equalsIgnoreCase(prodId.getProductId()))
												{
													CompareValuesUtility.compareValues("ProductID", parentId, prodId.getProductId());
													pFound = true;
													break;
												}
											}
											if(!pFound)
											{
												CompareValuesUtility.logFailed("ProductID", parentId, "ProductId not loaded in GB");
												break;
											}
											cFound = true;
											break;
										}
									}
									if(!cFound)
									{
										CompareValuesUtility.logFailed("Coords", coord.getPoints(), "Coords not loaded in GB");
										break;
									}
								}
							}

						}
					}
				}
			}
			CompareValuesUtility.setupResult(pageId, true);
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
		finally
		{
			CompareValuesUtility.teardown();
		}
	}

	private  List<String> getDivItemOrKsn(Coord coord)
	{
		List<String> lstDivItemOrKsn = new ArrayList<String>();

		for(Element element : Arrays.asList(media.getElement_list().getElement()))
		{
			if(element.getId().equalsIgnoreCase(coord.getElement_id()))
			{
				for(Article article : element.getArticle())
				{
					for(Property property: article.getProperty())
					{
						if(property.getName().equalsIgnoreCase("Product Id"))
						{
							lstDivItemOrKsn.add(property.getValue());
						}
					}
				}
			}
		}
		//		System.out.println("lstDivItemOrKsn=" + lstDivItemOrKsn);
		return lstDivItemOrKsn;
	}

	private List<String> getListOfPartNumbers(String divItemOrKsn)
	{
		List<String> lstPartNumber = null;

		if(media.getMedia_type().equalsIgnoreCase("sears"))
		{
			lstPartNumber = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "divitem" , divItemOrKsn);
		}
		else if(media.getMedia_type().equalsIgnoreCase("kmart"))
		{
			lstPartNumber = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ksn" , divItemOrKsn);
		}
		else
		{
			log.info("Ksn/Divitem=" + divItemOrKsn + " doesn't have any partnumber in offer collection. mediaType=" + media.getMedia_type());
		}
		System.out.println("lstPartNumber="+lstPartNumber);
		return lstPartNumber;
	}
}