package com.shi.content.utilitytests;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import org.exolab.castor.xml.Unmarshaller;

import com.generated.vos.productoffering.Catalog;
class FileOperations 
{

	public static void main(String[] s)
	{
		readXml();
	}
	
	public static void readXml()
	{
		try 
		{
			Catalog catalog = (Catalog)Unmarshaller.unmarshal(Catalog.class,
					new FileReader("src/test/resources/spin-storeonly-offering_sears_2148201.xml"));
					
			System.out.println(catalog.getShcHierarchyId());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String readTextFile(String sFile)
	{
		StringBuffer output = new StringBuffer("");

		try{
			FileInputStream fstream = new FileInputStream(sFile);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)   {
				output.append("\n"+strLine);
			}
			in.close();
		}catch(Exception e){
			System.err.println("Error: " + e.getMessage());
		}

		return output.toString();
	}

	public static BufferedWriter openFileToWrite(String sFile)
	{
		BufferedWriter bw = null;

		try {
			File file = new File(sFile);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			bw = new BufferedWriter(fw);
		} catch (IOException e) {

			e.printStackTrace();
		}

		return bw;
	}

	public static void closeFileToWrite(BufferedWriter bw)
	{

		try {
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}


	public static void writeToFile(BufferedWriter bw,String sContent)
	{
		try 
		{
			bw.write(sContent);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}