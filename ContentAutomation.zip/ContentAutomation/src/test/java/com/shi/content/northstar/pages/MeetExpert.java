package com.shi.content.northstar.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.CheckBox;
import com.shc.content.webdriver.html.DialogBox;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.TextField;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.common.CommonMethods;
import com.shi.content.northstar.pages.EditStoreDetails.SERVICES;
import com.shi.content.northstar.pages.EditStoreDetails.VERTICALS;


/**
 * @author inaikwa
 *
 */
public class MeetExpert extends EditStoreDetails {
	
	Link btnRemoveSears = new Link("//*[@id='frm-single-view:pnl-single-view:prsearsservicePickList']/tbody/tr/td[2]/button[3]","Remove button Sears Section");
	Link btnInsertSears = new Link("//*[@id='frm-single-view:pnl-single-view:prsearsservicePickList']/tbody/tr/td[2]/button[1]","Insert button Sears Section");

	Link btnRemovePR = new Link("//*[@id='frm-single-view:pnl-single-view:prservicePickList']/tbody/tr/td[2]/button[3]","Remove button PR section");
	Link btnInsertPR = new Link("//*[@id='frm-single-view:pnl-single-view:prservicePickList']/tbody/tr/td[2]/button[1]","Insert button PR section");
	CheckBox checkBoxVerticals = new CheckBox("//*[@id='frm-single-view:hierarchySelectionMultiPr']//label[text()='{0}']","Vertical");
	
	public void addMeetWithExpert_Sears(List<VERTICALS> verticals){

		this.goToDepartmentsView();

		this.removeMeetWithExpertOption_Sears();

		List<SERVICES> servicesList = new ArrayList<>();

		servicesList.add(SERVICES.MEETWITHEXPERT);

		this.addServicesToStore_Sears(servicesList);

		this.addVerticals(verticals);

		logger.log("Meet with expert added", true);
	}
	
	public void addMeetWithExpert_PR(List<VERTICALS> verticals){

		this.goToDepartmentsView();

		this.removeMeetWithExpertOption_PR();

		List<SERVICES> servicesList = new ArrayList<>();

		servicesList.add(SERVICES.MEETWITHEXPERT);

		this.addServicesToStore_PR(servicesList);

		this.addVerticals(verticals);

		logger.log("Meet with expert added", true);
	}

	/**
	 * Removes meet with expert option
	 * 
	 */

	public void removeMeetWithExpertOption_Sears(){

		Link meetWithExpert = (Link)linkServicesInStore.formatOption(SERVICES.MEETWITHEXPERT.getOption());
		if(meetWithExpert.isElementPresent()){
			logger.log("Removing meetwithexpert option", false);
			meetWithExpert.click();

			btnRemoveSears.click();
			WaitUtils.waitUntilElementIsClickable(linkServiceDepts.formatOption(SERVICES.MEETWITHEXPERT.getOption()));
		}
	
	}
	
	public void removeMeetWithExpertOption_PR(){

		Link meetWithExpert = (Link)linkServicesInStore.formatOption(SERVICES.MEETWITHEXPERT.getOption());
		if(meetWithExpert.isElementPresent()){
			logger.log("Removing meetwithexpert option", false);
			meetWithExpert.click();

			btnRemovePR.click();
			WaitUtils.waitUntilElementIsClickable(linkServiceDepts.formatOption(SERVICES.MEETWITHEXPERT.getOption()));
		}
	
	}
	
	public void addServicesToStore_Sears(List<SERVICES> lstOfOptions){
		logger.log("Add services to store "+ lstOfOptions, false);
		for(SERVICES option : lstOfOptions){

			Link currentService = (Link) linkServiceDepts.formatOption(option.getOption());
			if(currentService.isElementPresent()){
				currentService.click();
				if(currentService.isEnabled())
				btnInsertSears.click();
				else { currentService.click(); btnInsertSears.click();}
			}
		}
	}
	
	public void addServicesToStore_PR(List<SERVICES> lstOfOptions){
		logger.log("Add services to store "+ lstOfOptions, false);
		for(SERVICES option : lstOfOptions){

			Link currentService = (Link) linkServiceDepts.formatOption(option.getOption());
			if(currentService.isElementPresent()){
				currentService.click();
				btnInsertPR.click();
			}
		}
	}
	
	
	/**
	 * Adds verticals to meet with expert option
	 * @param lstOfVerticals {@link VERTICALS}
	 */
	public void addVerticals(List<VERTICALS> lstOfVerticals) {
		logger.log("Selecting verticals", true);

		WaitUtils.waitUntilElementIsVisible(dlgHierarchyList);

		for(VERTICALS vertical : lstOfVerticals){
			((CheckBox)checkBoxVerticals.formatOption(vertical.getName())).click();
		}

		btnDone.isVisible();
		btnDone.click();

		WaitUtils.waitUntilElementIsInVisible(dlgHierarchyList);

	}
	
}
