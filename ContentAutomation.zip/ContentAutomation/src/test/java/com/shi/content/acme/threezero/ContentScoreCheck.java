package com.shi.content.acme.threezero;

import com.generated.vos.contentscore.Attributes;
import com.generated.vos.contentscore.Contentscore;
import com.generated.vos.contentscore.Image;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class ContentScoreCheck 
{
	public static void main(String[] args)
	{
		calculateAttrigateScript("531884002");
		calculateAttrigateScript("122233455601");
	}

	public static void calculateAttrigateScript(String id)
	{
		/*1. Image Quality (50%)

		Primary Image (40%) : (40/100*0.8) = 0.32
		Alt Image 1 (20%) : (20/100*0.8) = 0.16
		Alt Image 2 (20%) : (20/100*0.8) = 0.16
		Alt Image 3 (20%) : (20/100*0.8) = 0.16
		Sum of above score: 0.8
		Final Image Quality Score: (50/100)*0.8 = 0.4
		2. Title Consistency (20%) : (20/100*1) = 0.2 
		3. Attribute Completeness (10%) : (10/100*0.8) = 0.08
		4. Product Description Quality (10%) : (10/100*0.7) = 0.07
		5. Product Features Quality (10%) : (10/100*0.7) = 0.07*/

		Double expectedAggrScrore= 0d;

		String resp = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/contentscore/"+id);

		Gson g=new Gson();

		Contentscore contentscore  = g.fromJson(resp, Contentscore.class);

		Attributes attr = contentscore.getItem().getAttributes();

		String title = attr.getTitleConsistency();

		String attrComp = attr.getAttrCompleteness();

		String features = attr.getDescription()==null?null:attr.getDescription().getLongDesc();

		String prodDescription = attr.getDescription()==null?null:attr.getDescription().getShortDesc();

		Image image = attr.getImage();

		if(image!=null)
		{

			String primary  = image.getPrimary();

			if(!TestUtils.isEmptyString(primary))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(primary) * .40d);
			}

			String alt1= image.getAlt1();

			if(!TestUtils.isEmptyString(alt1))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt1) * .20d);
			}


			String alt2= image.getAlt2();

			if(!TestUtils.isEmptyString(alt2))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt2) * .20d);
			}

			String alt3= image.getAlt3();

			if(!TestUtils.isEmptyString(alt3))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt3) * .20d);
			}

			expectedAggrScrore = expectedAggrScrore/2;
		}

		if(!TestUtils.isEmptyString(title))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(title) * .20d);
		}

		if(!TestUtils.isEmptyString(attrComp))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(attrComp) * .10d);
		}

		if(!TestUtils.isEmptyString(features))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(features) * .10d);
		}

		if(!TestUtils.isEmptyString(prodDescription))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(prodDescription) * .10d);
		}

		expectedAggrScrore = Double.parseDouble(TestUtils.roundToNDigits(expectedAggrScrore, 2));

		System.out.println("expectedAggrScrore... "+expectedAggrScrore);

		Double aggregateActual = contentscore.getItem().getAttributes().getAggregateScore();

		System.out.println("aggregateActual... "+aggregateActual);

	}
}
