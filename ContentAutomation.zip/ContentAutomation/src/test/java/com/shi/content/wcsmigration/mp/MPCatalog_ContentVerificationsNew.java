package com.shi.content.wcsmigration.mp;


import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.Attributes;
import com.generated.vos.catdelta.Brand;
import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.Cpc;
import com.generated.vos.catdelta.Fbm;
import com.generated.vos.catdelta.FeatureImageUrls;
import com.generated.vos.catdelta.Hierarchy;
import com.generated.vos.catdelta.Image;
import com.generated.vos.catdelta.ImageUrl;
import com.generated.vos.catdelta.ProductAsset;
import com.generated.vos.catdelta.ProductAssets;
import com.generated.vos.catdelta.Site;
import com.generated.vos.catdelta.SpecificFbmsFieldsGroup;
import com.generated.vos.content.Attachment;
import com.generated.vos.content.Content;
import com.generated.vos.content.Img_;
import com.generated.vos.content.Val;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.SHCContentCommons;

public class MPCatalog_ContentVerificationsNew implements Runnable{

	SHCContentCommons commonUtils = new SHCContentCommons("","sears");
	List<Fbm> wNodeList;
	List<Cpc> wNodeListCpc;
	String sFileName;
	boolean cpcExecution = false;
	String sSellerId=null;
	String sVariationGroupId=null;
	String sVariationPgrmType=null;
	String sModelNumber;
	Boolean isFit = true;
	private Boolean isBrandCodeFound = null;
	//ECOM-362062
	static List<String> ignoreAttrIds = Arrays.asList(new String[]{ "797010", "250601", "796910", "796810"});//"781110","797010","250601","796910","796810","1774"});
	static List<String> autoIds = Arrays.asList(new String[]{"1035210","873910"});

	CommonFbmsFieldsGroup commonFields;
	SpecificFbmsFieldsGroup specificFields;

	public MPCatalog_ContentVerificationsNew(List<Fbm> wNodeListToTest,String...sSeller){
		this.wNodeList = wNodeListToTest;
		if(sSeller.length!=0)
		{
			sSellerId=sSeller[0];
			sVariationGroupId=sSeller[1];
			sVariationPgrmType=sSeller[2];
			System.out.println("sSellerId..... "+sSellerId);
			System.out.println("sVariationGroupId..... "+sVariationGroupId);
			System.out.println("sVariationPgrmType..... "+sVariationPgrmType);
		}
	}

	public MPCatalog_ContentVerificationsNew(List<Cpc> wNodeListToTest,boolean cpc,String...sSeller){

		cpcExecution = true;
		//System.out.println("CPC node...");
		this.wNodeListCpc = wNodeListToTest;
		if(sSeller.length!=0)
		{
			sSellerId=sSeller[0];
			//sVariationGroupId=sSeller[1];
			//sVariationPgrmType=sSeller[2];
			//System.out.println("sSellerId..... "+sSellerId);
			//System.out.println("sVariationGroupId..... "+sVariationGroupId);
			//System.out.println("sVariationPgrmType..... "+sVariationPgrmType);
		}
	}

	public MPCatalog_ContentVerificationsNew(List<Fbm> processNodeList,
			CommonFbmsFieldsGroup commonFields2, SpecificFbmsFieldsGroup specificFields, String sSeller,
			String variationGroupId, String string) {
		this(processNodeList, sSeller, variationGroupId,string );
		commonFields = commonFields2;
		this.specificFields = specificFields;
	}

	private void cpcValidation()
	{

		//System.out.println("CPC execution ");

		String sellerDocument = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, sSellerId);
		String aggregatorId = JsonStringParser.getJsonValue(sellerDocument,"{_blob{seller{programs{cpc{aggregatorId}}}}}");

		String id="";

		for(Cpc cpcitem: wNodeListCpc)
		{
			try {
				CompareValuesUtility.init();

				id = String.valueOf(cpcitem.getItemId());

				String cpcId=TestUtils.generateCPCId(aggregatorId,sSellerId,cpcitem.getItemId());

				//System.out.println("cpcId.."+cpcId);

				Content content =  RestExecutor.getDataById(CollectionValuesVal.CONTENT,cpcId);

				/* ==========  Id ============== */

				if(content == null){
					CompareValuesUtility.logFailed("Id", id, " Not found");
					CompareValuesUtility.setupResult(id+"", true);
					continue;
				}

				compareValues("content.id", cpcId, content.getId());

				compareValues("Name", cpcitem.getCommonItemFieldsGroup().getTitle(), content.getName());

				compareValues("Catentrytype", "P", content.getClassifications().getCatentryType());

				/* ========== Brand ============== */

				verifyBrand(cpcitem.getBrand(),content.getBrand());

				/* ==========  Is Auto? ============== */

				CompareValuesUtility.verifyNullOrFalse("IsAuto", false, content.getClassifications().getIsAutomotive());

				//desc
				commonUtils.verifyDesc(null,cpcitem.getCommonItemFieldsGroup().getShortDesc(),content.getDesc(),false);

				/* ========== SEO ============== */

				commonUtils.compareSeo(content,false);

				/* ========== Assets ============== */

				verifyAssetsCpc(cpcitem, content );

				String modelNum = cpcitem.getModelNumber();

				CompareValuesUtility.verifyNullOrEqual("modelNum", modelNum, content.getMfr().getModelNo());

				/* ========== Taxonomy - Web ============== */

				Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
				for ( Site site : cpcitem.getCommonItemFieldsGroup().getSite()) {

					long lSiteId = site.getId();
					List<String> lstHieararchyIds = new ArrayList<String>();
					for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
						lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
					}

					mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
				}


				commonUtils.compareWebhierarchyGB(mpSiteHiearachies, content.getTaxonomy() == null? null : 
					content.getTaxonomy().getWeb(),"Sears",false);

				//commonUtils.compareWebhierarchy(mpSiteHiearachies, content.getTaxonomy().getWeb());

				CompareValuesUtility.addNewMultiValuedFields();

				/* ========== Taxonomy - Master ============== */

				//TODO
				commonUtils.compareMasterhierarchyGB(cpcitem.getCommonItemFieldsGroup().getItemClassId(), 
						content.getTaxonomy() == null? null : content.getTaxonomy().getMaster().getHierarchy());

				CompareValuesUtility.setupResult(id, true);

			}catch(Throwable e){
				System.out.println("Check this id :"+ id);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}

	}
	public void run() 
	{
		String id="";
		if(cpcExecution)
		{
			cpcValidation();
		}
		else
		{
			//System.out.println("Non CPC execution ");
			for(Fbm fbmItem : wNodeList)
			{
				CompareValuesUtility.init();
				try{

					if(commonFields == null){
						commonFields =  fbmItem.getCommonFbmsFieldsGroup();
					}
					boolean fbsFlag = false;
					boolean variationFlag=false;
					String sWhatToAppend = null;

					String sDartPart = fbmItem.getDartPartNumber();

					if(sSellerId!=null)
					{
						variationFlag=true;

						sWhatToAppend  = TestUtils.generateVariationId(sSellerId,sVariationGroupId,sVariationPgrmType);

						System.out.println("Its a variation item ..."+sWhatToAppend);

						id=sWhatToAppend;
					}
					else if(sDartPart==null)
					{
						sWhatToAppend =  "SPM" + String.valueOf(fbmItem.getItemId());
						id=fbmItem.getItemId()+"";
					}
					else
					{
						fbsFlag = true;
						sWhatToAppend = sDartPart;
						id=sWhatToAppend;
					}

					Content content =  RestExecutor.getDataById(CollectionValuesVal.CONTENT,sWhatToAppend);

					/* ==========  Id ============== */

					if(content == null){
						CompareValuesUtility.logFailed("Id", id, " Not found");
						CompareValuesUtility.setupResult(id+"", true);
						continue;
					}

					if(fbsFlag)
					{
						compareValues("Id", sDartPart, content.getId());
					}
					else if(variationFlag)
					{
						CompareValuesUtility.logPassed("Id", sWhatToAppend,sWhatToAppend);
					}
					else
					{
						compareValues("Id", "SPM"+fbmItem.getItemId(), content.getId());
					}
					/* ==========  Catentry type ============== */

					compareValues("Catentrytype", "P", content.getClassifications().getCatentryType());

					/* ==========  Is Auto? ============== */

					CompareValuesUtility.verifyNullOrFalse("IsAuto", false, content.getClassifications().getIsAutomotive());

					/* ==========  CatentrySubtype ============== */

					if(variationFlag)
					{
						compareValues("CatentrySubtype", "V", content.getClassifications().getCatentrySubType());
					}
					else
					{
						compareValues("CatentrySubtype", "NV", content.getClassifications().getCatentrySubType());
					}
					/* ==========  Long/Short Description ============== */



					commonUtils.verifyDesc(commonFields.getLongDesc(),commonFields.getCommonItemFieldsGroup().getShortDesc(),content.getDesc(),false);

					CompareValuesUtility.addNewMultiValuedFields();

					/* ==========  EnrichProv ============== */

					compareValues("EnrichProv", getEnrProvAbbr(fbmItem)
							, content.getClassifications().getEnrichmentProvider());

					/* ==========  Name/Title ============== */

					compareValues("Name", commonFields.getCommonItemFieldsGroup().getTitle(), content.getName());

					/* ========== Brand ============== */

					verifyBrand(commonFields.getBrand(),content.getBrand());

					compareValues("isDispElg", true, content.getOperational().getSites().getSears().getIsDispElig());

					/* ========== Mature Content ============== */

					if(commonFields.getCommonItemFieldsGroup().getMatureContent())
					{
						compareValues("Mature Content", commonFields.getCommonItemFieldsGroup().getMatureContent(), content.getLegal()==null?null:content.getLegal().getIsMatureContent());
					}

					/* ==========  Model No. ============== */
					if(commonFields.getModelNumber()!=null || commonFields.getModelNumber().length()==0){
						sModelNumber = commonFields.getModelNumber();
						compareValues("Model Number", sModelNumber, content.getMfr().getModelNo());

					}
					else {
						isFit=false;
						System.out.println("Model number set isFit to false");
					}
					/* ========== Mfr Name ============== */

					/*Comparing only first 25 chars of string as only first 25 gets stored in GreenBox DB */
					String xmlMfrName = commonFields.getManufacturerName();
					if (xmlMfrName != null) {
						int xmlMfrNameLen = commonFields.getManufacturerName().length();
						xmlMfrName = xmlMfrName.substring(0,xmlMfrNameLen>64?64:xmlMfrNameLen);
					}
					CompareValuesUtility.verifyNullOrEqual("MfrName", xmlMfrName, content.getMfr().getName());

					/* ========== Taxonomy - Web ============== */

					Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
					for ( Site site : commonFields.getCommonItemFieldsGroup().getSite()) {

						long lSiteId = site.getId();
						List<String> lstHieararchyIds = new ArrayList<String>();
						for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
							lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
						}

						mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
					}


					commonUtils.compareWebhierarchyGB(mpSiteHiearachies, content.getTaxonomy() == null? null : 
						content.getTaxonomy().getWeb(),"Sears",false);

					//commonUtils.compareWebhierarchy(mpSiteHiearachies, content.getTaxonomy().getWeb());

					CompareValuesUtility.addNewMultiValuedFields();

					/* ========== Taxonomy - Master ============== */

					commonUtils.compareMasterhierarchyGB(commonFields.getCommonItemFieldsGroup().getItemClassId(), 
							content.getTaxonomy() == null? null : content.getTaxonomy().getMaster().getHierarchy());

					//commonUtils.compareMasterhierarchy(commonFields.getCommonItemFieldsGroup().getItemClassId(), content.getTaxonomy().getMaster().getHierarchy());

					/* ========== SEO ============== */

					commonUtils.compareSeo(content,false);

					/* ========== Specs ============== */

					MpCommon common = new MpCommon();

					common.verifySpecsGB(content.getSpecs());

					//verifySpecs(fbmItem, content);

					CompareValuesUtility.addNewMultiValuedFields();

					/* ========== Facets ============== */

					if(commonFields.getAttributes()!=null)
					{
						common.verifyFacetsGB(commonFields.getAttributes(),content, commonFields.getCommonItemFieldsGroup().getItemClassId().toString());
					}
					/* ========== Assets ============== */

					verifyAssets(fbmItem,content );

					if(variationFlag)
					{
						CompareValuesUtility.setupResult(sWhatToAppend, true);
					}
					else
					{
						CompareValuesUtility.setupResult(String.valueOf(fbmItem.getItemId()), true);
					}

				}catch(Throwable e){
					System.out.println("Check this id :"+ id);
					e.printStackTrace();
				}finally{
					CompareValuesUtility.teardown();
				}
			}	
		}
	}

	public  String getEnrProvAbbr(Fbm fbmItem)
	{
		if(commonFields.getCommonItemFieldsGroup().getEnrichmentInfo()==null)
		{
			return "SP";
		}
		else
		{
			String enrProv = commonFields.getCommonItemFieldsGroup().getEnrichmentInfo().getEnrichmentProvider().value();
			if(enrProv.equals("CNET"))
			{
				return "CN";
			}
			else
			{
				return enrProv;
			}

		}

	}


	public  String getEnrProvAbbr(Cpc cpcNode)
	{
		if(cpcNode.getCommonItemFieldsGroup().getEnrichmentInfo()==null || cpcNode.getCommonItemFieldsGroup().getEnrichmentInfo().getEnrichmentProvider()==null)
		{
			return "SP";
		}
		else
		{
			String enrProv = cpcNode.getCommonItemFieldsGroup().getEnrichmentInfo().getEnrichmentProvider().value();
			if(enrProv.equals("CNET"))
			{
				return "CN";
			}
			else
			{
				return enrProv;
			}

		}

	}


	/**
	 * Verifies brand
	 * @param xmlBrand
	 * @param contentBrand
	 */
	public void verifyBrand(Brand xmlBrand, com.generated.vos.content.Brand contentBrand) {

		String imgSrc=null;
		try {
			imgSrc = contentBrand.getImg().getSrc();
		} catch (Exception e) {
		}

		CompareValuesUtility.verifyNullOrEqual("BrandId", xmlBrand==null?null:xmlBrand.getId(),
				contentBrand==null||contentBrand.getId()==null?null:GenericUtil.convertToString(contentBrand.getId()));

		if((xmlBrand==null||xmlBrand.getLogoImageUrl()==null) && imgSrc == null)
		{
			CompareValuesUtility.logPassed("BrImage","","" );
		}
		else if(xmlBrand.getLogoImageUrl().equals(imgSrc))
		{
			CompareValuesUtility.logPassed("BrImage",xmlBrand.getLogoImageUrl(),imgSrc );
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("BrImage", TestUtils.modifyBrandImgURL(xmlBrand.getLogoImageUrl()),imgSrc );
		}

		CompareValuesUtility.verifyNullOrEqual("BrName", xmlBrand==null?null:xmlBrand.getName(), contentBrand==null?null:contentBrand.getName());

	}

	/**
	 * Verifies Assets
	 * 
	 * @param fbmItem
	 * @param productAssets
	 * @param content
	 */
	private void verifyAssets(Fbm fbmItem , Content content ){

		ProductAssets productAssets  = commonFields.getCommonItemFieldsGroup().getProductAssets();

		if(productAssets !=null )
		{
			try {
				verifyAssetAttachments(productAssets.getProductAsset(), content.getAssets().getAttachments());
			} catch (Exception e2) {
				System.out.println("Exception in verifyAssetAttachments : ");
				e2.printStackTrace();
			}


			try {
				FeatureImageUrls[] fimgs = commonFields.getFeatureImageUrls();

				validateFeaturedImages(fimgs,content);
			} catch (Exception e1) {

				e1.printStackTrace();
				System.out.println("Exception in validateFeaturedImages : "+e1.getMessage());
			}

			try {
				ImageUrl image;
				if(specificFields != null)
					image =  specificFields.getImageUrl();
				else
					image = fbmItem.getSpecificFbmsFieldsGroup().getImageUrl();

				validatePrimaryImages( image, content);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in validatePrimaryImages : "+e.getMessage());
			}

		}

	}
	private void verifyAssetsCpc(Cpc cpcItem, Content content ){

		ProductAssets productAssets  =	cpcItem.getCommonItemFieldsGroup().getProductAssets();

		if(productAssets !=null )
		{
			try {
				verifyAssetAttachments(productAssets.getProductAsset(), content.getAssets().getAttachments());
			} catch (Exception e2) {
				System.out.println("Exception in verifyAssetAttachments : ");
				e2.printStackTrace();
			}

		}

		try {
			ImageUrl image = cpcItem.getImageUrl();

			List<Val> valsList = getImagesOfType(content,"P");

			Val requiredVal = valsList.get(0);

			compareValues("Prim-Image-URL", TestUtils.modifyImgURL(image.getUrl()), requiredVal.getSrc());

			//		validatePrimaryImages( image, content);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in validatePrimaryImages : "+e.getMessage());
		}

		/*try {
			FeatureImageUrls[] fimgs = commonFields.getFeatureImageUrls();

			validateFeaturedImages(fimgs,content);
		} catch (Exception e1) {

			e1.printStackTrace();
			System.out.println("Exception in validateFeaturedImages : "+e1.getMessage());
		}*/
	}


	/**
	 * Return required type of images
	 * @param content
	 * @param type
	 * @return
	 */
	public static  List<Val> getImagesOfType(Content content,String type )
	{
		List<Val> toReturn = new LinkedList<Val>();

		List<Img_> imgs = content.getAssets().getImgs();
		for (Img_ img_ : imgs) {

			if(img_.getType().toString().trim().equals(type))
			{
				toReturn.addAll(img_.getVals());
			}

		}
		return toReturn;
	}


	/**
	 * Verifies featured images
	 * @param fbmItem
	 * @param content
	 */
	public void validateFeaturedImages(FeatureImageUrls[] fimgs,Content content )
	{
		List<Val> valsList = getImagesOfType(content,"A");

		if(fimgs!=null && fimgs.length!=0)
		{
			for (FeatureImageUrls featureImageUrls : fimgs) {

				Image[] imgs = featureImageUrls.getImage();

				if(imgs!=null && imgs.length!=0 )
				{
					boolean found = false;

					found = false;

					for (Image image : imgs) {
						for (Val val : valsList) {

							if(val!=null && String.valueOf(image.getHeight()).equals(GenericUtil.convertToString(val.getHeight()))
									&&
									String.valueOf(image.getWidth()).equalsIgnoreCase(GenericUtil.convertToString(val.getWidth()))
									&&
									TestUtils.modifyImgURL(image.getUrl()).equals(val.getSrc()))
							{
								found = true;
								CompareValuesUtility.logPassed("Feature-Image-Height", image.getHeight(), GenericUtil.convertToString(val.getHeight()));
								CompareValuesUtility.logPassed("Feature-Image-Width", image.getWidth(), GenericUtil.convertToString(val.getWidth()));
								CompareValuesUtility.logPassed("Feature-Image-URL",TestUtils.modifyImgURL(image.getUrl()), val.getSrc());
								break;
							}
						}

						if(!found)
						{
							CompareValuesUtility.logFailed("Feature-Image-Height", image.getHeight(), "");
							CompareValuesUtility.logFailed("Feature-Image-Width", image.getWidth(), "");
							CompareValuesUtility.logFailed("Feature-Image-URL",TestUtils.modifyImgURL(image.getUrl()),"");
						}
					}

				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	/**
	 * Verify primary image
	 * @param fbmItem
	 * @param content
	 */
	public void validatePrimaryImages( ImageUrl image,Content content )
	{


		List<Val> valsList = getImagesOfType(content,"P");

		if(valsList.isEmpty()){
			CompareValuesUtility.logFailed("Prim-Image-URL", image.getUrl(), "Not found in GB");
			return;
		}
		Val requiredVal = valsList.get(0);

		Long height = null ,width = null;

		if(image!=null)
		{
			height = image.getHeight();
			if( height == null)
			{
				height = 1000l;
			}

			width = image.getWidth();
			if( width == null)
			{
				width = 1000l;
			}

			compareValues("Prim-Image-Hieght", height, GenericUtil.convertToString(requiredVal.getHeight()));
			compareValues("Prim-Image-Width", width, GenericUtil.convertToString(requiredVal.getWidth()));
			compareValues("Prim-Image-URL", TestUtils.modifyImgURL(image.getUrl()), requiredVal.getSrc());
		}
	}

	/**
	 * Verifies asset attachments
	 * @param productAsset
	 * @param attachments
	 */
	public void verifyAssetAttachments(ProductAsset[] productAsset,
			List<Attachment> attachments) { 

		SHCContentCommons commons = new SHCContentCommons();
		for(ProductAsset attachmentAsset: productAsset){
			Boolean bFound = false;
			commons.convertType(attachmentAsset.getType().name());
			for(Attachment gbAttachment: attachments){

				if(attachmentAsset.getUrl().equals(gbAttachment.getLink().getAttrs().getHref()) && !commons.assetTypeGB.equals("PRODUCT_VIDEO") 
						&& commons.assetTypeGB.equals(gbAttachment.getType().toString())){
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref", attachmentAsset.getUrl(), attachmentAsset.getUrl());
					compareValues("AttType", commons.assetTypeGB, gbAttachment.getType());

					if(commons.assetTypeGB.equals("MS"))
						compareValues("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					else
						compareValues("AttchmtName", commons.assetName, gbAttachment.getName());

					if(commons.assetName!= null){
						if( commons.assetName.contains("Spanish"))
							compareValues("AttchLang", "Spanish", gbAttachment.getLang());
						else if(commons.assetName.contains("English"))
							compareValues("AttchLang", "English", gbAttachment.getLang());
					}
					break;
				}

			}
			if(!bFound){
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", commons.assetTypeGB, "Not found");

			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	/**
	 * Verifies the automotive section in content if automotive attributes are present
	 * @param content
	 * @param attrs
	 */
	public void verifyAutomotive(Content content, Attributes attrs){
		if(attrs!=null)
		{
			String brandCodeId = null;
			if(content.getAutomotive() != null){
				Attribute[] actAttrs = attrs.getAttribute();
				for (Attribute attribute : actAttrs) {
					String attributeId = attribute.getItemAttributeGroup().getAttributeId().toString();
					if(attributeId.equals("873910")){
						brandCodeId = attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree();
						compareValues("Auto",brandCodeId,
								content.getAutomotive().getBrandCodeId(),"Brand");
						isBrandCodeFound=true;
					}
					if(attributeId.equals("1035210")){
						switch(attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId().toString()){
						case "2509410":{
							content.getAutomotive().getAutoFitment();
							compareValues("Auto","AU Cross Fit",content.getAutomotive().getAutoFitment().toString(),"AutoFitment");
							CompareValuesUtility.verifyNullOrEqual("Auto",null,content.getAutomotive().getIsFitmentRequired(),"IsFitmentReq");
							break;
						}
						case "92":{
							//compareValues("Auto",AutoFitment.NO, content.getAutomotive().getAutoFitment(),"AutoFitment");
							compareValues("Auto","No", content.getAutomotive().getAutoFitment(),"AutoFitment");
							CompareValuesUtility.verifyNullOrEqual("Auto",null,content.getAutomotive().getIsFitmentRequired(),"IsFitmentReq");
							break;
						}
						case "2509310":{
							compareValues("Auto","Requires Fitment",	content.getAutomotive().getAutoFitment(),"AutoFitment");
							if(isBrandCodeFound == null){
								isBrandCodeFound = commonUtils.isBrandCodeIdFound(attrs);
								isFit = commonUtils.fitmentValidation(brandCodeId,sModelNumber );
							}
							//If model number and brand both are present 
							if(isFit  && isBrandCodeFound){
								isFit = commonUtils.fitmentValidation(brandCodeId,sModelNumber );
							}
							if(!isFit)
								isFit = null;

							CompareValuesUtility.verifyNullOrEqual("Auto",isFit,content.getAutomotive().getIsFitmentRequired(),"IsFitmentReq");
							break;
						}
						}
						break;
					}
					/*else
					compareValues("Auto",false,content.getAutomotive().getIsFitmentRequired(),"IsFitmentReq");*/
				}//End of checking all attributes	
				CompareValuesUtility.addNewMultiValuedFields();
			}else{
				CompareValuesUtility.logFailed("Auto","Auto attributes exist","content.automative not found" );
			}
		}
	}
}
