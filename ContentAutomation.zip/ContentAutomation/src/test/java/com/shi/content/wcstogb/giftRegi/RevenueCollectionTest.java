package com.shi.content.wcstogb.giftRegi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.db.DBUtil;

public class RevenueCollectionTest 
{

	@Test(groups="GiftRegistry-registryRevenueCollection")
	public void registryRevenueCollectionTest()
	{
		if(CommonGiftReg.database==null)
		{
			LoadProperties.setCustomMsgForEmail("Check MongoDb Connection",MSGTYPE.ERROR);
			return;
		}

		String sQuery = null;

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		int dataLimit = LoadProperties.TESTDATALIMIT;

		String giftregistry_ids=null;
		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("LIST"))
		{
			String sp[] = LoadProperties.RUN_PARAMS.split(",");

			for (String string : sp) {

				if(giftregistry_ids==null)
					giftregistry_ids="'"+string+"'";
				else
					giftregistry_ids=giftregistry_ids+",'"+string+"'";
			}

			/*sQuery = "select * from GRPURREC a,X_GR_PUR_REC b where a.purchaserecord_id=b.purchase_record_id " 
					+"and giftregistry_id in ("+giftregistry_ids+") order by giftregistry_id with ur"; */

			/*sQuery ="select * from GRPURREC a,X_GR_PUR_REC b,GRGFTREG c "+
					" where a.purchaserecord_id=b.purchase_record_id  "+
					" and a.GIFTREGISTRY_ID=c.GIFTREGISTRY_ID "+
					" and a.giftregistry_id in ("+giftregistry_ids+")  "+
					" order by a.giftregistry_id with ur";*/

			sQuery ="select  grp.GIFTREGISTRY_ID,GRP.PARTNUMBER,GRP.ORDERITEMID,GRP.PURCHASEDATE,GRP.REGISTRANTMEMO,GRP.ISNOTESENT,GRP.PURCHASELOCATION,GRP.TRANSACTIONID,GRP.CREATETIME,GRP.UPDATETIME,XGRP.BUYER_FIRST_NAME,XGRP.BUYER_LAST_NAME,XGRP.BUYER_MIDDLE_NAME,XGRP.PRODUCT_DESC,XGRP.PRICE,XGRP.QUANTITY,XGRP.TOTAL_PRODUCT,XGRP.TAX_AMOUNT,XGRP.TOTAL_ADJUSTMENT,XGRP.SHIP_TAX_AMOUNT,XGRP.SHIP_CHARGE,XGRP.PURCHASE_FOR_REGISTRANT,XGRP.SHIPPING_ADDRESS_ID,XGRP.BILLING_ADDRESS_ID,XGRP.ISMSG_FOR_REGISTRANT,XGRP.REGISTRANT_MESSAGE,XGRP.STOREUNIT_ID,XGRP.NPOS_MSG,XGRP.IS_REGISTRY_ITEM,GRP.PURCHASERECORD_ID,GRP.GIFTITEM_ID,GRG.STOREID "+ 
					" from  "+
					" X_GR_PUR_REC XGRP, GRPURREC GRP, GRGFTREG GRG "+ 
					" where "+
					" XGRP.PURCHASE_RECORD_ID=GRP.PURCHASERECORD_ID  "+
					" and GRG.GIFTREGISTRY_ID = GRP.GIFTREGISTRY_ID" +
					" and GRP.GIFTREGISTRY_ID in ("+giftregistry_ids+")"+
					"	order by GRP.giftregistry_id  with ur ";

			/*for (String string : sp) {
				pool.execute(new RevenueCollectionVerifications(string));
			}*/	

		}
		else
		{
			/*sQuery ="select * from GRPURREC a,X_GR_PUR_REC b where a.purchaserecord_id=b.purchase_record_id order by giftregistry_id";*/

			sQuery ="select * from GRPURREC a,X_GR_PUR_REC b,GRGFTREG c "+
					" where a.purchaserecord_id=b.purchase_record_id  "+
					" and a.GIFTREGISTRY_ID=c.GIFTREGISTRY_ID "+
					" order by a.giftregistry_id with ur";


			sQuery ="select  grp.GIFTREGISTRY_ID,GRP.PARTNUMBER,GRP.ORDERITEMID,GRP.PURCHASEDATE,GRP.REGISTRANTMEMO,GRP.ISNOTESENT,GRP.PURCHASELOCATION,GRP.TRANSACTIONID,GRP.CREATETIME,GRP.UPDATETIME,XGRP.BUYER_FIRST_NAME,XGRP.BUYER_LAST_NAME,XGRP.BUYER_MIDDLE_NAME,XGRP.PRODUCT_DESC,XGRP.PRICE,XGRP.QUANTITY,XGRP.TOTAL_PRODUCT,XGRP.TAX_AMOUNT,XGRP.TOTAL_ADJUSTMENT,XGRP.SHIP_TAX_AMOUNT,XGRP.SHIP_CHARGE,XGRP.PURCHASE_FOR_REGISTRANT,XGRP.SHIPPING_ADDRESS_ID,XGRP.BILLING_ADDRESS_ID,XGRP.ISMSG_FOR_REGISTRANT,XGRP.REGISTRANT_MESSAGE,XGRP.STOREUNIT_ID,XGRP.NPOS_MSG,XGRP.IS_REGISTRY_ITEM,GRP.PURCHASERECORD_ID,GRP.GIFTITEM_ID,GRG.STOREID "+ 
					" from  "+
					" X_GR_PUR_REC XGRP, GRPURREC GRP, GRGFTREG GRG "+ 
					" where "+
					" XGRP.PURCHASE_RECORD_ID=GRP.PURCHASERECORD_ID  "+
					" and GRG.GIFTREGISTRY_ID = GRP.GIFTREGISTRY_ID " +
					" order by GRP.giftregistry_id  with ur ";
		}

		System.out.println(sQuery);

		ResultSet rs =  DBUtil.executeQueryReturnAll(sQuery);

		String giftregistry_id = null;
		String giftregistry_id_last = "-1";

		List<Map<String,String>> rowMapsForSingleGr = new ArrayList<Map<String,String>>();

		boolean flagForAtLeastOneTest = false;

		int testDataCounter = 0;

		try 
		{
			if(rs==null)
			{
				LoadProperties.setCustomMsgForEmail("ResultSet is Empty, No data found to test",MSGTYPE.ERROR);
			}
			else
			{
				while(rs.next())
				{
					giftregistry_id = rs.getString("GIFTREGISTRY_ID");

					if(!giftregistry_id_last.equals(giftregistry_id))
					{
						if(!rowMapsForSingleGr.isEmpty())
						{
							flagForAtLeastOneTest = true;
							pool.execute(new RevenueCollectionVerifications(giftregistry_id_last,rowMapsForSingleGr));
							testDataCounter++;
							if(dataLimit!=-1 && dataLimit==testDataCounter)
							{
								break;
							}
						}

						giftregistry_id_last=giftregistry_id;
						rowMapsForSingleGr = new ArrayList<Map<String,String>>();
					}

					rowMapsForSingleGr.add(CommonGiftReg.getMap(rs));
				}

				if(!flagForAtLeastOneTest)
				{
					pool.execute(new RevenueCollectionVerifications(giftregistry_id_last,rowMapsForSingleGr));
					testDataCounter++;
				}
			}
		}
		catch (SQLException e1) {
			e1.printStackTrace();
			LoadProperties.setCustomMsgForEmail("Exception : "+e1.getMessage(),MSGTYPE.ERROR);
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
	}

	@BeforeSuite(groups="GiftRegistry-registryRevenueCollection")
	public void startUp()
	{
		CommonGiftReg.getGiftRegMongoDB();
	}
}
