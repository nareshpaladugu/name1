package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;
import static com.shc.autocontent.utils.ReflectionUtils.getFieldFromObject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.Attributes;
import com.generated.vos.content.Attachment;
import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.ContentExtension;
import com.generated.vos.content.Content_;
import com.generated.vos.content.CuratedContents;
import com.generated.vos.content.CuratedGrp;
import com.generated.vos.content.Desc;
import com.generated.vos.content.Operational;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Static;
import com.generated.vos.content.Video;
import com.generated.vos.contentbco.Bundle;
import com.generated.vos.contentbco.Val_;
import com.generated.vos.hierarchy.Path;
import com.generated.vos.productoffering.CuratedGroup;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.Provider;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.xmls.collections.CommonElementsGroup;
import com.generated.xmls.collections.VariantCollectionElementsGroup;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.ReflectionUtils;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.ContentCache;
import com.shi.content.Variations.GreenBoxCache;

public class SHCCollectionBundleCommons {

	String sFileName;
	String sSite;

	// Defaults to slash, changed to pipe in GB comparison method
	private String hierarchySeparator = "/";

	public SHCCollectionBundleCommons(String sFileName, String sSite) {
		this.sFileName = sFileName;
		this.sSite = sSite;
	}

	public SHCCollectionBundleCommons() {
	}

	/**
	 * Returns isDispElig field inside operational tag. Returns null if site or
	 * field not found
	 * 
	 * @param sSiteId
	 *            - Site for which operational -> isDispElig field needs to be
	 *            checked
	 * @return
	 */
	public static Boolean getDispEligValue(String sSiteId,
			Operational operational) {
		// Long.valueOf(siteId).intValue()

		Object isDispEligValue = ReflectionUtils.getFieldFromObject(
				operational.getSites(),
				TestUtils.getSite(Long.parseLong(sSiteId)) + ">isDispElig");
		return isDispEligValue == null ? null : (Boolean) isDispEligValue;

	}

	public void verifyDesc(String sLongDescription, String sShortDescription,
			List<com.generated.vos.contentbco.Desc> desc, boolean cleanDesc) {
		int i = getPositionInList("L", desc, "type", com.generated.vos.contentbco.Desc.class);
		if (sLongDescription != null) {
			CompareValuesUtility.verifyTrue(i != -1, "DescType", "L", "L");
			if (cleanDesc)
				compareValues("DescVal", TestUtils.cleanDesc(sLongDescription),
						desc.get(i).getVal());
			else
				compareValues("DescVal", sLongDescription, desc.get(i).getVal());
		}/*
		 * else CompareValuesUtility.verifyTrue(i == -1, "DescType",
		 * "null","null");
		 */

		i = getPositionInList("S", desc, "type", com.generated.vos.contentbco.Desc.class);
		if (sShortDescription != null) {
			CompareValuesUtility.verifyTrue(i != -1, "DescType", "S", "S");
			if (cleanDesc)
				compareValues("DescVal",
						TestUtils.cleanDesc(sShortDescription), desc.get(i)
						.getVal());
			else
				compareValues("DescVal", sShortDescription, desc.get(i)
						.getVal());
		}/*
		 * else CompareValuesUtility.verifyTrue(i == -1, "DescType",
		 * "null","null" );
		 */

	}

	/**
	 * Verifies feature-top-descriptions from xml feed
	 * 
	 * @param lstTopDescriptions
	 * @param list
	 */
	public void verifyTopDescriptions(String[] lstTopDescriptions,
			List<com.generated.vos.contentbco.Desc> list) {

		int i = getPositionInList("T", list, "type", com.generated.vos.contentbco.Desc.class);
		CompareValuesUtility.verifyTrue(i != -1, "DescType", "T", "Not found");
		if (i != -1) {
			String gbTopDesc = "";
			for (String topDesc : lstTopDescriptions) {
				gbTopDesc += "|" + topDesc;
			}
			compareValues("DescVal", gbTopDesc.substring(1), list.get(i)
					.getVal());
		}

	}

	public void verifyBrand(com.generated.xmls.collections.Brand brand,
			com.generated.vos.contentbco.Brand contentBrand) {

		if (brand == null)
			return;
		String imgSrc = null;
		try {
			imgSrc = contentBrand.getImg().getAttrs().getSrc();
		} catch (Exception e) {
		}

		CompareValuesUtility.verifyNullOrEqual("Brand", brand.getId(), convertToString(contentBrand.getId()), "id");
		CompareValuesUtility.verifyNullOrEqual("Brand", TestUtils.modifyURL(brand.getLogoImageUrl()), imgSrc, "logoImageUrl");
		compareValues("Brand", TestUtils.plainEncodeHTML(brand.getName()), contentBrand.getName(), "name");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void verifyAssets(com.generated.xmls.collections.PrimaryImage primaryImage,
			com.generated.xmls.collections.FeatureImages featureImages, com.generated.vos.contentbco.Assets assets) {

		if(primaryImage != null){
			compareValues("PrimaryImg", "P", assets.getImgs().get(0).getType(),
					"Type");
			verifyNullOrEqual("PrimaryImg", primaryImage.getImageElementsGroup()
					.getHeight(), convertToString(assets.getImgs().get(0).getVals()
							.get(0).getImg().getAttrs().getHeight()), "Height");
			verifyNullOrEqual("PrimaryImg", primaryImage.getImageElementsGroup()
					.getWidth(), convertToString(assets.getImgs().get(0).getVals()
							.get(0).getImg().getAttrs().getWidth()), "Width");
			compareValues("PrimaryImg", TestUtils.modifyURL(primaryImage
					.getImageElementsGroup().getUrl()), assets.getImgs().get(0)
					.getVals().get(0).getImg().getAttrs().getSrc(), "Src");
			CompareValuesUtility.addNewMultiValuedFields();
		}

		if (featureImages != null) {
			for (com.generated.xmls.collections.FeatureImage fImage : featureImages.getFeatureImage()) {
				boolean bFound = false;
				int i = getPositionInList("A", assets.getImgs(), "type",
						com.generated.vos.contentbco.Img_.class);
				for (Val_ assetImgVal : assets.getImgs().get(i).getVals()) {
					if (assetImgVal.getImg().getAttrs().getSrc().equals(
							TestUtils.modifyURL(fImage.getImageElementsGroup()
									.getUrl()))) {
						bFound = true;
						compareValues("FeaturedImg", "A",
								assets.getImgs().get(i).getType(), "Type");
						CompareValuesUtility.verifyTrue(true, "FeaturedImg",
								TestUtils.modifyImgURL(fImage
										.getImageElementsGroup().getUrl()),
										assetImgVal.getImg().getAttrs().getSrc());
						verifyNullOrEqual("FeaturedImg", fImage
								.getImageElementsGroup().getWidth(),
								convertToString(assetImgVal.getImg().getAttrs().getWidth()),
								"Width");
						verifyNullOrEqual("FeaturedImg", fImage
								.getImageElementsGroup().getHeight(),
								convertToString(assetImgVal.getImg().getAttrs().getHeight()),
								"Height");
					}
				}
				if (!bFound) {
					CompareValuesUtility.verifyTrue(false, "FImgSrc", fImage
							.getImageElementsGroup().getUrl(), "Not found");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	public void verifyContentExtension(Provider provider,
			ContentExtension contentExtension) {
		compareValues("ContentExt", provider.getName(),
				contentExtension.getName(), "Name");
		compareValues("ContentExt", provider.getType(),
				contentExtension.getType(), "Type");
		if (provider.getDataCount() > 0) {
			compareValues("ContentExt", provider.getData()[0].getKey(),
					contentExtension.getData().get(0).getKey(), "Key");
			compareValues("ContentExt", provider.getData()[0].getValue(),
					contentExtension.getData().get(0).getVal(), "Val");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	public void verifyContentExtension(com.generated.vos.uvd.Provider provider,
			ContentExtension contentExtension) {
		compareValues("ContentExt", provider.getName(), contentExtension.getName(), "Name");
		compareValues("ContentExt", provider.getType(), contentExtension.getType(), "Type");
		if (provider.getDataCount() > 0) {
			compareValues("ContentExt", provider.getData()[0].getKey(), contentExtension.getData().get(0).getKey(), "Key");
			compareValues("ContentExt", provider.getData()[0].getValue(), contentExtension.getData().get(0).getVal(), "Val");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/**
	 * Verifies seo from xml to gb in case seo tag is present in xml. If not,
	 * then verifies seo data against content document brand name, desc etc
	 * 
	 * @param seo
	 * @param gbBundleContent
	 */
	public void verifySeo(com.generated.xmls.collections.Seo seo, Bundle gbBundleContent) {
		if (seo != null) {
			com.generated.vos.contentbco.Seo seo2 = gbBundleContent.getSeo();
			compareValues("SEO", seo.getSeoRobotFollowFlag() == null ? true
					: seo.getSeoRobotFollowFlag(), seo2.getIsRobotFollow(),
					"RobotFollow");
			compareValues("SEO", seo.getSeoRobotIndexFlag() == null ? true
					: seo.getSeoRobotIndexFlag(), seo2.getIsRobotIndex(),
					"RobotIndex");
			verifyNullOrEqual("SEO", seo.getSeoFeatureAltTag(),
					seo2.getFeatureAltTag(), "FeatureAlt");
			verifyNullOrEqual("SEO", seo.getSeoProductAltTag(),
					seo2.getProductAltTag(), "ProdAlt");
			if (seo.getSeoTitle() == null || seo.getSeoTitle().isEmpty()) {
				verifySeoTitle(gbBundleContent);
			} else {
				compareValues("SEO", seo.getSeoTitle(), seo2.getTitle(),
						"Title");
			}

			if (seo.getSeoMetaDescription() == null)
				;
			// verifySeoDescSHC(gbContent);
			else
				compareValues("SEO", seo.getSeoMetaDescription(),
						seo2.getDesc(), "Desc");

			CompareValuesUtility.addNewMultiValuedFields();
			// if(seo.getSeoUrl() == null)
			// checkSHCSEOURL(gbContent);
			/*
			 * else verifyNullOrEqual("SEO", seo.getSeoUrl(),
			 * seo2.getUrl(),"Url");
			 */
		} else {
			verifySeoTitle(gbBundleContent);
			// verifySeoDescSHC(gbContent);
			// checkSHCSEOURL(gbContent);
		}

	}

	/**
	 * Given a partnumber, returns its catentry id from db2
	 * 
	 * @param partNumber
	 * @return
	 */
	public static String fetchCatentryId(String partNumber) {
		return DBUtil
				.executeQuerySingleResult("select catentry_id from wcsadm.catentry where PARTNUMBER = '"
						+ partNumber + "' with ur");

	}

	public String getFacetsQuery(String sCatentryId) {
		return "Select  att.DISPLAYLABEL as name, atval.STRINGVALUE as value from "
				+ "wcsadm.xcatentavrel as avrel, wcsadm.XATTRIBUTE as att, wcsadm.XATTRVALUE as atval"
				+ " where catentry_id in ("
				+ sCatentryId
				+ ") and  avrel.xattribute_id in (select xattribute_id from wcsadm.xcatgrpattrrel where  XCATGRPATTRRELTYPE_ID='SEARCH' "
				+ "and catgroup_id in (select catgroup_id from wcsadm.catgpenrel where catentry_id="
				+ sCatentryId
				+ "  and catalog_id=21101))"
				+ " and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID  with ur";
	}

	public String getFacetsQuery(String identifier, String attributeIds,
			String attributeValIds) {
		return "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1 "
				+ " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ("
				+ attributeValIds
				+ ")"
				+ " and g.catgroup_id in (select catgroup_id from catgroup where identifier = '"
				+ identifier
				+ "')"
				+ " and g.XCATGRPATTRRELTYPE_ID='SEARCH' and x.field2 in ("
				+ attributeIds + ")";
	}

	/**
	 * Verify static facets
	 * 
	 * @param sCatentryId
	 * @param content
	 */
	public void verifyFacets(String sQuery, Content content) {

		/*
		 * String sQuery =
		 * "Select  att.DISPLAYLABEL as name, atval.STRINGVALUE as value from "
		 * +
		 * "wcsadm.xcatentavrel as avrel, wcsadm.XATTRIBUTE as att, wcsadm.XATTRVALUE as atval"
		 * + " where catentry_id in ("+sCatentryId+
		 * ") and  avrel.xattribute_id in (select xattribute_id from wcsadm.xcatgrpattrrel where  XCATGRPATTRRELTYPE_ID='SEARCH' "
		 * +
		 * "and catgroup_id in (select catgroup_id from wcsadm.catgpenrel where catentry_id="
		 * +sCatentryId+"  and catalog_id=21101))" +
		 * " and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID  with ur"
		 * ;
		 */

		/*
		 * String sUVDQuery =
		 * "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1 "
		 * +
		 * " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in (182,1578110,346,23985,2509410)"
		 * +
		 * " and g.catgroup_id in (select catgroup_id from catgroup where identifier = '313310')"
		 * +
		 * " and g.XCATGRPATTRRELTYPE_ID='SEARCH' and x.field2 in (517810,518110,518310,518510,848810,1035210)"
		 * ;
		 */

		ResultSet result = DBUtil.executeQueryReturnAll(sQuery);

		if (result == null) {
			CompareValuesUtility.verifyNull("FacetName", content.getFacets());
			CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
			return;
		}

		sSite = sSite == null ? "sears" : sSite;

		List<Static> staticFacets;
		if (sSite.equalsIgnoreCase("sears"))
			staticFacets = content.getFacets().getSites().getSears()
			.getStatic();
		else
			staticFacets = content.getFacets().getSites().getKmart()
			.getStatic();

		try {
			while (result.next()) {
				String sName = result.getString("name");
				String sVal = result.getString("value");
				Boolean bFound = false;
				for (Static staticFacet : staticFacets) {
					if (sName.equals(staticFacet.getName())
							&& sVal.equals(staticFacet.getValue())) {
						bFound = true;
						CompareValuesUtility.verifyTrue(true, "FacetName",
								sName, staticFacet.getName());
						CompareValuesUtility.verifyTrue(true, "FacetVal", sVal,
								staticFacet.getValue());
					}
				}
				if (!bFound) {
					CompareValuesUtility.logFailed("FacetName", sName,
							"Not Found");
					CompareValuesUtility.logFailed("FacetVal", sVal,
							"Not Found");
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			DBUtil.closeCursor(result);
			e.printStackTrace();
		}
		DBUtil.closeCursor(result);

	}

	public void verifySpecs(ProductAttribute[] prodAttribs,
			List<Spec> specsJson, String itemClassId) {

		List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110",
				"797010", "250601", "796910", "796810", "1774" });
		List<String> autoIds = Arrays
				.asList(new String[] { "1035210", "873910" });

		String query = "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g, xattrvalue x1"
				+ " where x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ('ATTVALID')"
				+ " and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"
				+ " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		String attributeOnlyQuery = "select x.displaylabel as name, g.LABELNAME as grpName from xattribute x, xcatgrpattrrel g"
				+ " where x.xattribute_id=g.xattribute_id and g.catgroup_id in (select catgroup_id from catgroup where identifier = 'IMACLASSID')"
				+ " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ('ATTID')";

		if (prodAttribs != null) {

			String grpNameJson = "";
			String grpNameWCS = "";

			Long attrId, val_id;
			String val_free = "";
			String attrName = null, attrVal = null;
			for (ProductAttribute attribute : prodAttribs) {

				// It's a flag field - no need to check
				if (attribute.getProductAttributeTypeChoice()
						.getAttributeValueFlag() != null)
					continue;

				attrId = attribute.getAttributeId();

				// For content some attribute ids need to be skipped
				if (ignoreAttrIds.contains(attrId.toString())) {
					continue;
				}

				// If automotive attributes
				if (autoIds.contains(attrId.toString())) {
					// bIsAuto = true;
					continue;
				}

				val_id = attribute.getProductAttributeTypeChoice()
						.getAttributeValueId();
				val_free = attribute.getProductAttributeTypeChoice()
						.getAttributeValueFree();

				if (val_id != null) {
					String finalQuery = query
							.replace("ATTVALID", val_id.toString())
							.replace("ATTID", attrId.toString())
							.replace("IMACLASSID", itemClassId);
					List<String> attrData = DBUtil
							.executeQueryMultiColumnSingleRow(finalQuery);
					if (attrData == null)
						continue;
					attrName = attrData.get(0);
					attrVal = attrData.get(1);
					grpNameWCS = attrData.get(2);
				} else // Probably free text
				{
					String finalQuery = attributeOnlyQuery.replace("ATTID",
							attrId.toString()).replace("IMACLASSID",
									itemClassId);
					List<String> attrData = DBUtil
							.executeQueryMultiColumnSingleRow(finalQuery);
					attrName = attrData.get(0);
					grpNameWCS = attrData.get(1);
					attrVal = val_free;
				}

				if (grpNameWCS == null) {
					grpNameWCS = "Others:";
				}

				boolean found = false;
				for (Spec spec : specsJson) {

					grpNameJson = spec.getGrpName();
					List<Attr> attrsList = spec.getAttrs();
					for (Attr attr : attrsList) {

						if (attr.getName().equals(attrName)
								&& attr.getVal().equals(
										TestUtils.encodeHTML(attrVal))
										&& grpNameWCS.equals(grpNameJson)) {
							found = true;
							CompareValuesUtility.logPassed("SpecName",
									attrName, attr.getName());
							CompareValuesUtility.logPassed("SpecVal", attrVal,
									attr.getVal());
							CompareValuesUtility.logPassed("SpecGrpName",
									grpNameWCS, grpNameJson);
							break;
						}
					}

					if (found) {
						break;
					}
				}

				if (!found) {
					CompareValuesUtility.logFailed("SpecName", attrName, "");
					CompareValuesUtility.logFailed("SpecVal",
							attrVal == null ? "null" : attrVal, "");
					CompareValuesUtility.logFailed("SpecGrpName", grpNameWCS,
							grpNameJson);
				}

			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

		// If automotive attributes exist, go ahead and verify attributes in
		// content.automotive

		/*
		 * if(bIsAuto){ verifyAutomotive(content, attrs); }
		 */
	}

	/*
	 * public void verifySpecs(String lstOfAttIds, String lstOfAttValIds,
	 * List<Spec> specs, String itemClassId) {
	 * 
	 * String sQuery =
	 * "Select ATT.XATTRIBUTE_ID as attrid,aTT.DISPLAYLABEL as name, atval.STRINGVALUE as value, rel.LABELNAME as grpName"
	 * + " from xcatentavrel as avrel, XATTRIBUTE as att,xcatgrpattrrel REL," +
	 * " XATTRVALUE as atval where catentry_id in ("+sCatentryId+
	 * ") and  avrel.xattribute_id in (select xattribute_id from xcatgrpattrrel rel "
	 * +
	 * "where	XCATGRPATTRRELTYPE_ID='LABEL' and catgroup_id in (select catgroup_id from catgpenrel where catentry_id="
	 * + sCatentryId+
	 * "  and catalog_id=21101)) and avrel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and avrel.XATTRVALUE_ID = atval.XATTRVALUE_ID"
	 * +
	 * " and rel.XATTRIBUTE_ID = avrel.XATTRIBUTE_ID and rel.XCATGRPATTRRELTYPE_ID = 'LABEL' "
	 * +
	 * "and rel.catgroup_id in (select catgroup_id from catgpenrel where catentry_id="
	 * +sCatentryId+" and catalog_id=21101) with ur";
	 * 
	 * String sQuery =
	 * "select x.displaylabel as name,x1.stringvalue as value, g.LABELNAME as grpName from "
	 * +
	 * "wcsadm.xattribute x, wcsadm.xcatgrpattrrel g, wcsadm.xattrvalue x1 where"
	 * +
	 * " x.xattribute_id=g.xattribute_id and x1.xattribute_id=x.xattribute_id and x1.name in ("
	 * +lstOfAttValIds+")" +
	 * " and g.catgroup_id in (select catgroup_id from wcsadm.catgroup where identifier = '"
	 * +itemClassId+"')" +
	 * " and g.XCATGRPATTRRELTYPE_ID='LABEL' and x.field2 in ("
	 * +lstOfAttIds+") with ur";
	 * 
	 * 
	 * ResultSet result = DB2Utils.executeQueryReturnAll(sQuery); if(result ==
	 * null){ CompareValuesUtility.verifyNull("SpecName",
	 * specs.size()==0?null:specs.get(0).getGrpName());
	 * CompareValuesUtility.addToHeaders(new
	 * String[]{"SpecValue","SpecGrpName"}); DB2Utils.closeCursor(result);
	 * return; } try { while (result.next()){ // String attrId =
	 * result.getString("attrid"); String sGrpName =
	 * result.getString("grpName"); if(sGrpName == null) sGrpName = "Others:";
	 * String sName = result.getString("name"); String sVal =
	 * result.getString("value"); Boolean bFound = false; for(Spec spec :
	 * specs){ for(Attr specAttr : spec.getAttrs()){
	 * if(spec.getGrpName().equals(sGrpName) &&
	 * sName.equals(specAttr.getName())){ bFound = true;
	 * CompareValuesUtility.verifyTrue(true, "SpecName", sName,
	 * specAttr.getName()); CompareValuesUtility.compareValues("SpecValue",
	 * sVal, specAttr.getVal()); CompareValuesUtility.verifyTrue(true,
	 * "SpecGrpName", sGrpName, spec.getGrpName()); } } } if(!bFound){
	 * CompareValuesUtility.logFailed("SpecName", sName, "Not Found");
	 * CompareValuesUtility.logFailed("SpecValue", sVal, "Not Found");
	 * CompareValuesUtility.logFailed("SpecGrpName", sVal, "Not Found");
	 * 
	 * }
	 * 
	 * } } catch (SQLException e) { // TODO Auto-generated catch block
	 * DB2Utils.closeCursor(result); e.printStackTrace(); }
	 * DB2Utils.closeCursor(result); }
	 */

	/**
	 * Needs item class id and Master object
	 * 
	 * @param lItemClassId
	 * @param master
	 */
	public void compareMasterhierarchy(long lItemClassId,
			List<com.generated.vos.contentbco.Hierarchy> hierarchy) {

		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		// URI uri =
		// RestAPIs.getByIdURI(CollectionValuesVal.ITEM_CLASS_HIERARCHY,
		// lItemClassId+"");

		// String sQuery =
		// "select CATGROUP_ID_PATH, CATGROUP_CID_PATH, CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD"+
		// " in(select CATGROUP_ID from wcsadm.CATGROUP where identifier = '"+lItemClassId+"') and CATALOG_ID = 21101 with ur";
		//
		// List<String> pathsList =
		// DB2Utils.executeQueryMultiColumnSingleRow(sQuery);

		List<String> pathsList = ContentCache.getPaths(lItemClassId);

		processMasterHierarchy(hierarchy, "no-site-required-for-master",
				hierarchyMap);

		compareValues("Master", pathsList.get(0),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getLstIds().get(0), "IDPath");
		compareValues("Master", pathsList.get(2),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getDisplayPaths().get(0), "DisplayPath");
		compareValues("Master", pathsList.get(1),
				"/"
						+ hierarchyMap.get("no-site-required-for-master")
						.getLstCIds().get(0), "CIDPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public void compareMasterhierarchyGB(long lItemClassId,
			List<com.generated.vos.contentbco.Hierarchy> list) {

		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath = GreenBoxCache
				.getPathForItemClass(lItemClassId + "");

		if (masterHierarchyPath == null) {
			logFailed("Master", "Hierarchy for " + lItemClassId
					+ " should exist", "No hierarchy exists");
			return;
		}

		if (list == null) {
			logFailed("Master", "Hierarchy for " + lItemClassId
					+ " should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master",
				hierarchyMap);

		String act = hierarchyMap
				.get("no-site-required-for-master").getLstIds().get(0);

		act=act==null?"null":act;

		String exp = masterHierarchyPath.getCidPath();

		exp=exp==null?"null":exp;

		CompareValuesUtility.verifyNullOrEqual("Master", exp , act ,	"IDPath");

		compareValues("Master", masterHierarchyPath.getDisplayPath(),
				hierarchyMap.get("no-site-required-for-master")
				.getDisplayPaths().get(0), "DisplayPath");

		compareValues("Master", masterHierarchyPath.getIdPath(), hierarchyMap
				.get("no-site-required-for-master").getLstCIds().get(0),
				"CIDPath");

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void setGBHierarchySeparator() {
		this.hierarchySeparator = "|";
	}

	/**
	 * 
	 * @param contentWebTaxonomy
	 * @param xmlSites
	 */
	public void compareWebhierarchy(Map<Long, List<String>> sitehiearchyMap,
			com.generated.vos.contentbco.Web contentWebTaxonomy) {
		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();
		com.generated.vos.contentbco.Sites contentSites = contentWebTaxonomy.getSites();
		String sQuery = "select CATGROUP_ID_PATH, CATGROUP_CID_PATH,"
				+ " CATGROUP_NAME_PATH from wcsadm.XCATGROUPPATH where CATGROUP_ID_CHILD "
				+ " in (select CATGROUP_ID from wcsadm.CATGROUP where identifier = 'ATTR_ID') and CATALOG_ID = CATA_ID with ur ";

		for (Long lSiteId : sitehiearchyMap.keySet()) {
			String sSiteName = TestUtils.getSite(lSiteId);
			if (!processSiteForWebHierarchy(sSiteName, contentSites,
					hierarchyMap)) {
				logFailed("web-idPath", sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteName + " not found in gb");
				continue;
			}
			String sCIDpath = null, sNamePath = null;
			for (String sHierarchyId : sitehiearchyMap.get(lSiteId)) {
				// String pathFromWebHierarchyCollection =
				// Helper.getJsonValue(resp,"[{_blob{hierarchy{path[cidPath]}}}]");
				try {
					// ResultSet resultSet =
					// ContentCache.getCatGroupDetails(sQuery,sitehiearchyMap,
					// sHierarchyId, TestUtils.figureOutCatalogId(lSiteId+""));
					List<Map<String, String>> resultSetCatDetails = ContentCache
							.getCatGroupDetails(sQuery, sitehiearchyMap,
									sHierarchyId,
									TestUtils.figureOutCatalogId(lSiteId + ""));
					Map<String, String> pathMap = new HashMap<String, String>();
					// while(null != resultSet && resultSet.next())
					if (null != resultSetCatDetails) {
						for (int i = 0; i < resultSetCatDetails.size(); i++) {

							pathMap = resultSetCatDetails.get(i);
							sCIDpath = pathMap.get("CATGROUP_ID_PATH");
							sNamePath = pathMap.get("CATGROUP_NAME_PATH");
							// sCIDpath =
							// resultSet.getString("CATGROUP_ID_PATH");
							// sNamePath =
							// resultSet.getString("CATGROUP_NAME_PATH");
							// System.out.println("sCIDpath..... "+sCIDpath +
							// " and sNamePath ..... "+sNamePath);
							compareValues(
									"web-idPath",
									sCIDpath,
									checkInList(hierarchyMap.get(sSiteName)
											.getLstIds(), sCIDpath));
							compareValues(
									"web-displayPath",
									sNamePath,
									checkInList(hierarchyMap.get(sSiteName)
											.getDisplayPaths(), sNamePath));
						}
					} else {
						// DB2Utils.closeCursor(resultSet);
						// if(null == resultSet){
						String sQuery1 = sQuery
								.replace("ATTR_ID", sHierarchyId).replace(
										"CATA_ID",
										TestUtils.figureOutCatalogId(lSiteId
												+ ""));
						System.out.println("REsult set null for : " + lSiteId
								+ " " + sQuery1);
					}

				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception of sHierarchyId : "
							+ sHierarchyId);
					// e.printStackTrace();
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	/**
	 * Hits the web-hierarchy collection to fetch paths and compares against gb
	 * paths for each site
	 * 
	 * @param sitehiearchyMap
	 * @param web
	 */
	public void compareWebhierarchyGB(Map<Long, List<String>> sitehiearchyMap,
									com.generated.vos.contentbco.Web web, 
									String sSiteToTest, 
									boolean bCrossFormattedItem) {
		Map<String, HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		this.setGBHierarchySeparator();
		for (Long lSiteId : sitehiearchyMap.keySet()) {
			String sSiteFromWebHierarchy = TestUtils.getSite(lSiteId);


			if(!bCrossFormattedItem)
			{
				if(sSiteToTest.equalsIgnoreCase("sears") && (sSiteFromWebHierarchy.equalsIgnoreCase("kmart")))
				{
					continue;
				}
				if(sSiteToTest.equalsIgnoreCase("kmart") && (sSiteFromWebHierarchy.equalsIgnoreCase("sears")))
				{
					continue;
				}
			}
			if (sSiteToTest.equalsIgnoreCase("kmart")
					&& (sSiteFromWebHierarchy.equalsIgnoreCase("kenmore") 
							|| sSiteFromWebHierarchy.equalsIgnoreCase("insco")
							|| sSiteFromWebHierarchy.equalsIgnoreCase("tgi")
							//|| sSiteFromWebHierarchy.equalsIgnoreCase("puertorico")
							|| sSiteFromWebHierarchy.equalsIgnoreCase("craftsman"))) {
				continue;
			}

			CompareValuesUtility.addDataFieldForReport("TaxonomySite", sSiteFromWebHierarchy);
			List<com.generated.vos.hierarchy.Hierarchy> hierarchyInfoList = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, sitehiearchyMap.get(lSiteId));

			if (hierarchyInfoList == null || hierarchyInfoList.size() == 0) {
				continue;
			} else {
				if (web == null) {
					/*logFailed(TestUtils.getSite(lSiteId)+".web-idPath", "Web Taxonomy expected for site :"
							+ lSiteId + " " + sitehiearchyMap.get(lSiteId),
							"No taxonomy found");*/
					logFailed("web-idPath", "Web Taxonomy expected for site :"
							+ lSiteId + " " + sitehiearchyMap.get(lSiteId),
							"No taxonomy found");
					break;
				}
			}
			com.generated.vos.contentbco.Sites contentSites = web.getSites();

			if (!processSiteForWebHierarchy(sSiteFromWebHierarchy, contentSites,
					hierarchyMap)) {

				/*logFailed(TestUtils.getSite(lSiteId)+".web-idPath", sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteFromWebHierarchy + " not found in gb");*/
				logFailed("web-idPath", sitehiearchyMap.get(lSiteId), "Site "
						+ sSiteFromWebHierarchy + " not found in gb");
				continue;
			}
			
			int gbWebHierPathCount = 0;
			
			for (com.generated.vos.hierarchy.Hierarchy specificHierarchy : hierarchyInfoList) {
				for (Path path : specificHierarchy.getPath()) {
					if(path.getIdPath()!=null){

						compareValues(
								"web-idPath",
								path.getIdPath(),
								checkInList(hierarchyMap.get(sSiteFromWebHierarchy).getLstIds(), 
										path.getIdPath()));
						
						compareValues(
								"web-displayPath",
								path.getDisplayPath(),
								checkInList(hierarchyMap.get(sSiteFromWebHierarchy).getDisplayPaths(), 
										path.getDisplayPath()));
						
						if(path.getCidPath()!=null){
							compareValues(
									"web-cidPath",
									path.getCidPath(),
									checkInList(hierarchyMap.get(sSiteFromWebHierarchy).getLstCIds(), 
											path.getCidPath()));
						}
						
						gbWebHierPathCount++;
					}
				}
			}			
			compareValues("webHierCountPerSite", gbWebHierPathCount, hierarchyMap.get(sSiteFromWebHierarchy).getLstIds().size());
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	public static String checkInList(List<String> lst, String exp) {
		for (String string : lst) {

			if (string.equals(exp)) {
				return string;
			}
		}
		return "Not in list : " + lst.toString();
	}

	/**
	 * Process site for web hierarchy
	 * 
	 * @param siteName
	 * @param contentSites
	 * @param hierarchyMap
	 */
	public boolean processSiteForWebHierarchy(String siteName,
			com.generated.vos.contentbco.Sites contentSites,
			Map<String, HierarchyPathVo> hierarchyMap) {
		List<com.generated.vos.contentbco.Hierarchy_> lstHierarchies = null;

		try {

			switch (siteName) {

			case "kmart":
				lstHierarchies = contentSites.getKmart().getHierarchies();
				break;

			case "sears":
				lstHierarchies = contentSites.getSears().getHierarchies();
				break;

			case "mygofer":
				lstHierarchies = contentSites.getMygofer().getHierarchies();
				break;

			case "kenmore":
				lstHierarchies = contentSites.getKenmore().getHierarchies();
				break;

			case "craftsman":
				lstHierarchies = contentSites.getCraftsman().getHierarchies();
				break;

			case "insco":
				lstHierarchies = contentSites.getInsco().getHierarchies();
				break;

			case "tgi":
				lstHierarchies = contentSites.getTgi().getHierarchies();
				break;

			case "puertorico":
				lstHierarchies = contentSites.getPuertorico().getHierarchies();
				break;
				
			default:
				break;
			}

			processWebHierarchy(lstHierarchies, siteName, hierarchyMap);
			return true;
		} catch (Exception e) {

			// System.out.println("Site not found in json");
			return false;
		}

	}

	/**
	 * Clubs the id and names under specificHierarchy separted by pipes
	 * 
	 * @param lstHierarchies
	 * @param siteName
	 * @param hierarchyMap
	 *            - Map to be updated with hierarchies. eg. <Sears, [{Kids|Kids'
	 *            Clothing|Boys' Clothing|Boys' Outerwear|All Boys'
	 *            Outerwear,Clothing, Shoes & Jewelry|Clothing|Kids'
	 *            Clothing|Boys' Clothing}]>
	 */
	public void processWebHierarchy(List<com.generated.vos.contentbco.Hierarchy_> lstHierarchies,
			String siteName, Map<String, HierarchyPathVo> hierarchyMap) {
		List<String> lstIds = new LinkedList<String>();
		List<String> lstName = new LinkedList<String>();
		List<String> lstCid = new LinkedList<String>();

		String id = "", name = "", cid = "";

		String tempid ="";

		for (com.generated.vos.contentbco.Hierarchy_ hierarchy : lstHierarchies) {

			List<com.generated.vos.contentbco.SpecificHierarchy> spHie = hierarchy.getSpecificHierarchy();

			id = "";
			name = "";
			cid = "";
			for (com.generated.vos.contentbco.SpecificHierarchy specificHierarchy : spHie) {

				if (id.isEmpty() && hierarchySeparator.equals("|")) {
					tempid=  GenericUtil.convertToString(specificHierarchy.getSpinId());
					if(tempid!=null && !tempid.isEmpty() && !tempid.equals("null"))
					{
						id = tempid;
					}
				} else
				{
					tempid=  GenericUtil.convertToString(specificHierarchy.getSpinId());

					if(tempid!=null && !tempid.isEmpty() && !tempid.equals("null"))
					{
						id = id
								+ this.hierarchySeparator
								+ tempid;
					}


				}
				if (name.isEmpty() && hierarchySeparator.equals("|")) {
					name = specificHierarchy.getName();
				} else
					name = name + this.hierarchySeparator
					+ specificHierarchy.getName();
				
				if (cid.isEmpty() && hierarchySeparator.equals("|")) {
					cid = GenericUtil.convertToString(specificHierarchy.getId());
				} else
					cid = cid + this.hierarchySeparator
					+ GenericUtil.convertToString(specificHierarchy.getId());

			}

			lstIds.add(id);
			lstName.add(name);
			lstCid.add(cid);

		}

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCid);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	/**
	 * Process Master hierarchy
	 * 
	 * @param list
	 * @param siteName
	 * @param hierarchyMap
	 */
	public void processMasterHierarchy(List<com.generated.vos.contentbco.Hierarchy> list,
			String siteName, Map<String, HierarchyPathVo> hierarchyMap) {
		List<String> lstIds = new LinkedList<String>();
		List<String> lstName = new LinkedList<String>();
		List<String> lstCids = new LinkedList<String>();

		String id = null, name = null, cid = null;

		for (com.generated.vos.contentbco.Hierarchy hierarchy : list) {

			if (id == null)
				id = GenericUtil.convertToString(hierarchy.getId());
			else
				id = id + this.hierarchySeparator
				+ GenericUtil.convertToString(hierarchy.getId());

			if (name == null)
				name = hierarchy.getName();
			else
				name = name + this.hierarchySeparator + hierarchy.getName();

			if (cid == null)
				cid = GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid + this.hierarchySeparator
				+ GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ====== For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}

	/**
	 * Common for web and Master
	 * 
	 * @author ddaphal
	 * 
	 */
	private class HierarchyPathVo {
		public List<String> getLstIds() {
			return lstIds;
		}

		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}

		public List<String> getLstCIds() {
			return lstCIds;
		}

		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}

		public List<String> getDisplayPaths() {
			return displayPaths;
		}

		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}

		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}

	/**
	 * Verifies curated contents from feeds
	 * 
	 * @param xmlCuratedGroups
	 * @param curatedContents
	 */
	public void verifyCuratedContents(CuratedGroup[] xmlCuratedGroups,
			CuratedContents curatedContents) {

		List<CuratedGrp> gbCuratedGrps = curatedContents.getCuratedGrp();// curatedContents.get(0).getCuratedGrp();

		for (CuratedGroup xmlCurGroup : xmlCuratedGroups) {
			int i = CompareValuesUtility.getPositionInList(String.valueOf((Long
					.valueOf(xmlCurGroup.getRank()).doubleValue())),
					gbCuratedGrps, "rank", CuratedGrp.class);
			if (i != -1) {
				compareValues("CuratedGrpType", xmlCurGroup.getCuratedType(),
						gbCuratedGrps.get(i).getType());
				compareValues("CuratedGrpRank", xmlCurGroup.getRank(),
						GenericUtil.convertToString(gbCuratedGrps.get(i)
								.getRank()));
				verifyNullOrEqual("CuratedGrpName",
						xmlCurGroup.getCuratedGroupName(), gbCuratedGrps.get(i)
						.getName());
				for (com.generated.vos.productoffering.CuratedContent xmlCurContent : xmlCurGroup
						.getCuratedContent()) {
					int j = CompareValuesUtility.getPositionInList(
							xmlCurContent.getContentType(), gbCuratedGrps
							.get(i).getContent(), "type",
							Content_.class);
					if (j != -1) {
						Content_ currentGbContent = gbCuratedGrps.get(i)
								.getContent().get(j);
						compareValues("ContentType",
								xmlCurContent.getContentType(),
								currentGbContent.getType());
						verifyNullOrEqual("ContentName",
								xmlCurContent.getContentName(),
								currentGbContent.getName());
						compareValues("ContentColumn",
								xmlCurContent.getColumn(),
								GenericUtil.convertToString(currentGbContent
										.getColumn()));
						compareValues("ContentRow", xmlCurContent.getRow(),
								GenericUtil.convertToString(currentGbContent
										.getRow()));

						if (xmlCurContent.getContentType().equalsIgnoreCase(
								"asset")) {
							// compareValues("AssetType",
							// xmlCurContent.getAsset().getCuratedAssetTypeType(),currentGbContent.getAsset().get);
							verifyNullOrEqual("AssetName", xmlCurContent
									.getAsset().getName(), currentGbContent
									.getAsset().getName());
							compareValues("AssetURL", xmlCurContent.getAsset()
									.getUrl(), currentGbContent.getAsset()
									.getUrl());
							verifyNullOrEqual("AssetWidth", xmlCurContent
									.getAsset().getHeight(),
									GenericUtil
									.convertToString(currentGbContent
											.getAsset().getHeight()));
							verifyNullOrEqual("AssetHeight", xmlCurContent
									.getAsset().getWidth(),
									GenericUtil
									.convertToString(currentGbContent
											.getAsset().getWidth()));
						}

						verifyNullOrEqual("ContentData",
								xmlCurContent.getData(),
								currentGbContent.getData());
					} else {
						logFailed("ContentType",
								xmlCurContent.getContentType(),
								"Not found in GB");
					}
				}
			} else {
				compareValues("CuratedGrpName",
						xmlCurGroup.getCuratedGroupName(), "Not found in gb");
			}
		}

	}

	private List<com.generated.vos.contentbco.SpecificHierarchy> getSpecificHieararchy(com.generated.vos.contentbco.Bundle bundle) {
		try {
			List<com.generated.vos.contentbco.Hierarchy_> lstHieararchies = new ArrayList<com.generated.vos.contentbco.Hierarchy_>();
			if (sSite.equalsIgnoreCase("sears")) {
				if (bundle.getTaxonomy().getWeb().getSites().getSears() != null)
					lstHieararchies = bundle.getTaxonomy().getWeb().getSites()
					.getSears().getHierarchies();
				else if (bundle.getTaxonomy().getWeb().getSites().getKmart() != null)
					lstHieararchies = bundle.getTaxonomy().getWeb().getSites()
					.getKmart().getHierarchies();
				else
					lstHieararchies = getOtherHierarchies(bundle);

			} else {
				if (bundle.getTaxonomy().getWeb().getSites().getKmart() != null)
					lstHieararchies = bundle.getTaxonomy().getWeb().getSites()
					.getKmart().getHierarchies();
				else
					lstHieararchies = getOtherHierarchies(bundle);
			}

			return lstHieararchies.get(0).getSpecificHierarchy();
		} catch (Exception e) {
			return null;
		}
	}

	private List<com.generated.vos.contentbco.Hierarchy_> getOtherHierarchies(com.generated.vos.contentbco.Bundle bundle) {
		if (bundle.getTaxonomy().getWeb().getSites().getMygofer() != null)
			return bundle.getTaxonomy().getWeb().getSites().getMygofer()
					.getHierarchies();
		else if (bundle.getTaxonomy().getWeb().getSites().getCraftsman() != null)
			return bundle.getTaxonomy().getWeb().getSites().getCraftsman()
					.getHierarchies();
		else if (bundle.getTaxonomy().getWeb().getSites().getInsco() != null)
			return bundle.getTaxonomy().getWeb().getSites().getInsco()
					.getHierarchies();
		else if (bundle.getTaxonomy().getWeb().getSites().getKenmore() != null)
			return bundle.getTaxonomy().getWeb().getSites().getKenmore()
					.getHierarchies();
		else if (bundle.getTaxonomy().getWeb().getSites().getPuertorico() != null)
			return bundle.getTaxonomy().getWeb().getSites().getPuertorico()
					.getHierarchies();
		else if (bundle.getTaxonomy().getWeb().getSites().getTgi() != null)
			return bundle.getTaxonomy().getWeb().getSites().getTgi()
					.getHierarchies();
		return null;
	}

	public static void checkSHCSEOURL(com.generated.vos.contentbco.Bundle bundle) {
		String url = "";

		// 1. Combine brand + name i.e. Ex-Cell Combination Sand Urn/Waste
		// Receptacle Round Steel Black/Chrome
		if (bundle
				.getName()
				.toLowerCase()
				.startsWith(
						bundle.getBrand() == null ? "" : bundle.getBrand()
								.getName().toLowerCase()))
			url = bundle.getName();
		else
			url = bundle.getBrand() == null ? "" : bundle.getBrand()
					.getName() + "-" + bundle.getName();

		// url=url.replaceAll("&nbsp;", "unknown");

		url = TestUtils.trimURLBySpace(url);
		url = TestUtils.replacesSPecialCharsFromURL(url);
		// 4. Convert all to lower case i.e.
		// ex-cell-combination-sand-urn-waste-receptacle-round
		url = url.toLowerCase();

		// 5. Remove adjacent duplicate words
		url = TestUtils.removeAdjacentDuplicateWords(url, "-");

		// 6. Add a slash / at the start i.e.
		// /ex-cell-combination-sand-urn-waste-receptacle-round*/
		url = "/" + url;

		// 7. Remove hyphen from end
		if (url.endsWith("-"))
			url = url.substring(0, url.length() - 1);

		//System.out.println("Exp url : " + url);
		if (bundle.getSeo() == null) {
			CompareValuesUtility.addFailedDataFieldForReport(
					"Seo-tag-not-found", "Exp : " + url);
		} else {
			compareValues("SEO", url, bundle.getSeo().getUrl(), "URL");
		}
	}

	private static void verifySeoURL(Content content) {

		String url = "";

		// 1. Combine brand + name i.e. Ex-Cell Combination Sand Urn/Waste
		// Receptacle Round Steel Black/Chrome
		if (content.getName().startsWith(content.getBrand().getName()))
			url = content.getName();
		else
			url = content.getBrand().getName() + "-" + content.getName();

		// 2. Replace all spaces and other special characters with hyphen i.e.
		// Ex-Cell-Combination-Sand-Urn-Waste-Receptacle-Round-Steel-Black-Chrome
		url = TestUtils.replacesSPecialCharsFromURL(url);

		// 3. Take first 8 words only i.e.
		// Ex-Cell-Combination-Sand-Urn-Waste-Receptacle-Round
		url = TestUtils.trimURL(url);

		// 4. Convert all to lower case i.e.
		// ex-cell-combination-sand-urn-waste-receptacle-round
		url = url.toLowerCase();

		// 5. Add a slash / at the start i.e.
		// /ex-cell-combination-sand-urn-waste-receptacle-round*/
		url = "/" + url;

		compareValues("SEO", url, content.getSeo().getUrl(), "URL");
		/*
		 * String brandinseotitle = content.getBrand()!=
		 * null?content.getBrand().getName():""; String fullURL =
		 * brandinseotitle+" "+content.getName(); fullURL = fullURL.replace("&",
		 * "").replace("-", " ").replaceAll("\\s+"," ");
		 * System.out.println("Before trimming : "+ fullURL);
		 * System.out.println("On trimming : "+ TestUtils.trimURL(fullURL));
		 * compareValues
		 * ("seo-url","/"+TestUtils.processURL(TestUtils.trimURL(fullURL
		 * )),content.getSeo().getUrl());
		 */

	}

	public void verifySeoTitle(com.generated.vos.contentbco.Bundle bundle, Boolean... bPrimaryAvlbl) {

		boolean bToAppendHierarchy = true;
		String hierarchy = null;
		if (bPrimaryAvlbl != null && bPrimaryAvlbl.length > 0
				&& !bPrimaryAvlbl[0])
			bToAppendHierarchy = false;
		if (bToAppendHierarchy) {
			List<com.generated.vos.contentbco.SpecificHierarchy> spHie = getSpecificHieararchy(bundle);
			if (spHie != null) {
				for (com.generated.vos.contentbco.SpecificHierarchy specificHierarchy : spHie) {

					if(hierarchy==null)
						hierarchy= specificHierarchy.getName();
					else
						hierarchy += " - " + specificHierarchy.getName();
				}
			}
		}

		hierarchy=hierarchy==null?"":hierarchy;
		if(!hierarchy.isEmpty())
		{
			hierarchy=" - "+hierarchy;
		}

		String seoTitle = (bundle.getBrand() == null
				|| bundle.getBrand().getName() == null ? "" : bundle
						.getBrand().getName() + " ")
						+ bundle.getName() + hierarchy;

		if (seoTitle.length() > 254)
			seoTitle = seoTitle.substring(0, 254);
		compareValues("SEO", seoTitle, bundle.getSeo().getTitle(), "Title");
	}


	private static void verifySeoDescSHC(Content content) {

		int i = CompareValuesUtility.getPositionInList("L", content.getDesc(),
				"type", Desc.class);
		if (i == -1) {
			i = CompareValuesUtility.getPositionInList("S", content.getDesc(),
					"type", Desc.class);
		}

		String formattedName = TestUtils.replacesSPecialCharsFromURL(
				content.getName()).toLowerCase();

		String sModelNumber = content.getMfr() == null ? "" : content.getMfr()
				.getModelNo();
		String desc = (content.getBrand() == null ? "" : content.getBrand()
				.getName() + "-")
				+ formattedName
				+ "-"
				+ (sModelNumber == null ? "" : sModelNumber)
				+ "-"
				+ content.getDesc().get(i).getVal();
		desc = desc.replaceAll("\\s+", " ").replaceAll("--", "-");
		compareValues("SEO", desc, content.getSeo().getDesc(), "Desc");
	}

	private static void verifySeoDesc(Bundle bundle) {

		int i = CompareValuesUtility.getPositionInList("L", bundle.getDesc(),
				"type", com.generated.vos.contentbco.Desc.class);

		if (i == -1) {
			i = CompareValuesUtility.getPositionInList("S", bundle.getDesc(),
					"type",  com.generated.vos.contentbco.Desc.class);
		}

		String sModelNumber = bundle.getMfr() == null ? "" : bundle.getMfr()
				.getModelNo();
		String desc = bundle.getBrand().getName() + "-" + bundle.getName()
				+ "-" + sModelNumber + "-" + bundle.getDesc().get(i).getVal();
		desc = desc.replaceAll("\\s+", " ").replaceAll("--", "-");
		compareValues("SEO", desc, bundle.getSeo().getDesc(), "Desc");
	}

	public void compareSeo(com.generated.vos.contentbco.Bundle bundle) {
		verifySeoTitle(bundle);
		verifySeoDesc(bundle);
		// verifySeoURL(content);
		checkSHCSEOURL(bundle);
		CompareValuesUtility.addNewMultiValuedFields();

	}


	/**
	 * Verify sites list
	 * 
	 * @param commonElementsGroup
	 * @param sites
	 * @param isCrossFormatted 
	 */
	public void verifySites(CommonElementsGroup commonElementsGroup, List<String> sites, Boolean isCrossFormatted) {

		for (com.generated.xmls.collections.Site s : commonElementsGroup.getSite()) {
			if (s.getId() == 10 || s.getId() == 13 || s.getId() == 4 ||  s.getId() == 11)
				continue;
			if (!isCrossFormatted && 
					((sSite.equalsIgnoreCase("sears") && s.getId() == 1) 
							|| (sSite.equalsIgnoreCase("kmart") && s.getId() == 2)))
				continue;
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	public void verifySites(
			VariantCollectionElementsGroup commonElementsGroup, List<String> sites, Boolean isCrossFormatted) {
		
		for (com.generated.xmls.collections.Site s : commonElementsGroup.getSite()) {
			if (s.getId() == 10 || s.getId() == 13)
				continue;
			if (!isCrossFormatted && 
					((sSite.equalsIgnoreCase("sears") && s.getId() == 1) 
							|| (sSite.equalsIgnoreCase("kmart") && s.getId() == 2)))
				continue;
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
	}
	
	public void verifySites(com.generated.vos.uvd.ProductContent pContent, List<String> sites) {

		for (com.generated.vos.uvd.Site s : pContent.getSite()) {
			if (s.getId() == 10 || s.getId() == 13)
				continue;
			CompareValuesUtility.verifyItemInList("Sites", TestUtils.getSite(s.getId()), sites);
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
	}

	public void verifyAssetVideo(com.generated.xmls.collections.ProductAsset[] productAssets, List<com.generated.vos.contentbco.Video> list) {

		for (com.generated.xmls.collections.ProductAsset videoAsset : productAssets) {
			
			convertType(videoAsset.getType().name());
			
			if (videoAsset.getType().value().equals("PRODUCT_VIDEO")) {
				Boolean bFound = false;
				for (com.generated.vos.contentbco.Video video : list) {
					if (videoAsset.getUrl().equals(
							video.getLink().getAttrs().getHref())) {
						CompareValuesUtility.verifyTrue(true, "VideoURL",
								videoAsset.getUrl(), videoAsset.getUrl());
						bFound = true;
						compareValues("VideoType", videoAsset.getType().name(), video.getType());
						compareValues("VideoName", assetName, video.getName());
						break;
					}
				}
				if (!bFound)
					CompareValuesUtility.logFailed("Video",
							videoAsset.getUrl(), "Not found");
			}
		}
	}
	
	public void verifyAssetVideo(com.generated.vos.uvd.ProductAsset[] productAsset, List<Video> videos) {

		for (com.generated.vos.uvd.ProductAsset videoAsset : productAsset) {
			
			convertType(videoAsset.getType().name());
			
			if (videoAsset.getType().value().equals("PRODUCT_VIDEO")) {
				Boolean bFound = false;
				for (Video video : videos) {
					if (videoAsset.getUrl().equals(video.getLink().getAttrs().getHref())) {
						compareValues("Video", videoAsset.getUrl(), videoAsset.getUrl(), "Url");
						bFound = true;
						compareValues("Video", videoAsset.getType().name(), video.getType(), "Type");
						compareValues("Video", assetName, video.getName(), "Name");
						CompareValuesUtility.addNewMultiValuedFields();
						break;
					}
				}
				if (!bFound)
					CompareValuesUtility.logFailed("Video", videoAsset.getUrl(), "Not found");
			}
		}
	}

	public void verifyAssetAttachments(com.generated.xmls.collections.ProductAsset[] productAssets,
			List<com.generated.vos.contentbco.Attachment> list) {

		for (com.generated.xmls.collections.ProductAsset attachmentAsset : productAssets) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO"))
			{
				continue;
			}

			Boolean bFound = false;
			convertType(attachmentAsset.getType().name());
			for (com.generated.vos.contentbco.Attachment gbAttachment : list) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(
						gbAttachment.getLink().getAttrs().getHref())
						&& !assetTypeGB.equals("PRODUCT_VIDEO")
						&& assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref",
							attachmentAsset.getUrl(), attachmentAsset.getUrl());
					compareValues("AttType", assetTypeGB,
							gbAttachment.getType());

					if (assetTypeGB.equals("MS"))
						compareValues("AttchmtName", attachmentAsset.getName(),
								gbAttachment.getName());
					else
						compareValues("AttchmtName", assetName,
								gbAttachment.getName());

					if (assetName != null && assetName.contains("Spanish"))
						compareValues("AttchLang", "Spanish",
								gbAttachment.getLang());
					else
						compareValues("AttchLang", "English",
								gbAttachment.getLang());
					break;
				}


			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref",
						attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", assetTypeGB,
						"Not found");

			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	public void verifyAssetAttachments(com.generated.vos.uvd.ProductAsset[] productAsset,
			List<Attachment> attachments) {

		for (com.generated.vos.uvd.ProductAsset attachmentAsset : productAsset) {

			if(attachmentAsset.getType().name().equalsIgnoreCase("PRODUCT_VIDEO")){
				continue;
			}

			Boolean bFound = false;
			convertType(attachmentAsset.getType().name());
			for (Attachment gbAttachment : attachments) {

				if (attachmentAsset.getUrl().replace("download.sears.com", "c.shld.net/assets").equals(
						gbAttachment.getLink().getAttrs().getHref())
						&& !assetTypeGB.equals("PRODUCT_VIDEO")
						&& assetTypeGB.equals(gbAttachment.getType().toString())) {
					bFound = true;
					compareValues("Attachments", attachmentAsset.getUrl(), attachmentAsset.getUrl(), "Url");
					compareValues("Attachments", assetTypeGB, gbAttachment.getType(), "Type");

					if (assetTypeGB.equals("MS"))
						compareValues("Attachments", attachmentAsset.getName(), gbAttachment.getName(), "Name");
					else
						compareValues("Attachments", assetName, gbAttachment.getName(), "Name");

					if (assetName != null && assetName.contains("Spanish"))
						compareValues("Attachments", "Spanish", gbAttachment.getLang(), "Language");
					else
						compareValues("Attachments", "English", gbAttachment.getLang(), "Language");
					
					CompareValuesUtility.addNewMultiValuedFields();
					break;
				}
			}
			if (!bFound) {
				CompareValuesUtility.logFailed("AttchmtLinkHref",
						attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", assetTypeGB,
						"Not found");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	

	public String assetName, assetTypeGB;

	public void convertType(String assetType) {
		switch (assetType) {
		case "PRODUCT_WARRANTY": {
			assetTypeGB = "PW";
			assetName = "Product Warranty";
			break;
		}
		case "REBATES": {
			assetTypeGB = "RB";
			assetName = "Rebates";
			break;
		}
		case "MISCELLANEOUS": {
			assetTypeGB = "MS";
			assetName = null; // Explicitly setting in case previous loops set
			// it to some other value
			break;
		}
		case "ENGLISH_OWNER_MANUAL": {
			assetTypeGB = "EOM";
			assetName = "Owners manual - English";
			break;
		}
		case "ENERGY_GUIDE": {
			assetTypeGB = "EG";
			assetName = "Energy Guide";
			break;
		}
		case "SPANISH_OWNER_MANUAL": {
			assetTypeGB = "SOM";
			assetName = "Owners manual - Spanish";
			break;
		}
		case "SPANISH_WARRANTY": {
			assetTypeGB = "SW";
			assetName = "Spanish Warranty";
			break;
		}
		case "PRODUCT_VIDEO": {
			assetTypeGB = "PRODUCT_VIDEO";
			assetName = "Product Video";
			break;
		}
		default: {
			break;
		}
		}
	}

	/**
	 * Given a attribute id, returns displayname from gb attribute collection
	 * 
	 * @param id
	 * @return
	 */
	public String getAttributeFromGB(String id) {

		return RestExecutor.getSpecificValueFromJson(
				CollectionValuesVal.ATTRIBUTE, id,
				"[{_blob{attribute{displayName}}}]");
	}

	/**
	 * Given a attributeval id, returns displayname from gb attrvalue collection
	 * 
	 * @param id
	 * @return
	 */
	public String getAttributeValFromGB(String id) {

		return RestExecutor.getSpecificValueFromJson(
				CollectionValuesVal.ATTRIBUTE_VALUE, id,
				"[{_blob{attrvalue{displayName}}}]");
	}

	public String getEnrichmentProvider(String enrichmentProvider,
			boolean isSHCLoad) {
		switch (enrichmentProvider) {
		case "GLADSON": {
			return "G";
		}
		case "CNET": {
			return "CN";
		}
		case "EDGENET": {
			return "EN";
		}
		case "1WORLDSYNC": {
			return "1WS";
		}
		case "KWIKEE": {
			return "K";
		}
		default: {
			if (isSHCLoad)
				return "S";
			else
				return "SP";
		}
		}
	}

	/**
	 * Hits the uri for fitment validation and returns fitment value
	 * 
	 * @param brand
	 * @param modelNumber
	 * @return
	 */
	public boolean fitmentValidation(String brand, String modelNumber) {

		String fitmentPostResponse = RestExecutor.postForJSonResponse(
				RestAPIs.formFitmentURI(), "[{\"brand\":\"" + brand
				+ "\",\"part\":\"" + modelNumber + "\"}]");

		if (fitmentPostResponse == null) {
			return false;
		}
		String fitmentValidation = JsonStringParser.getJsonValueNew(
				fitmentPostResponse, "data.fitment");
		System.out.println("Fitment response " + fitmentValidation);
		return fitmentValidation == null ? false : Boolean
				.parseBoolean(fitmentValidation);
		// Json
	}

	/**
	 * Checks whether brandcodeid attribute is present
	 * 
	 * @param attrs
	 * @return
	 */
	public boolean isBrandCodeIdFound(Attributes attrs) {
		Attribute[] actAttrs = attrs.getAttribute();
		for (Attribute attribute : actAttrs) {
			String attributeId = attribute.getItemAttributeGroup()
					.getAttributeId().toString();
			if (attributeId.equals("873910")) {
				return true;
			}
		}
		return false;
	}

	public void grocerySpecificChecks(String fieldName, Object allergen,
			Object allergen2) {

		compareOnlyIfNotNull(fieldName,
				getFieldFromObject(allergen, "dispLabel"),
				getFieldFromObject(allergen2, "dispLabel"), "DispLabel");
		compareOnlyIfNotNull(fieldName,
				getFieldFromObject(allergen, "freeText"),
				getFieldFromObject(allergen2, "freeText"), "FreeText");
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void compareOnlyIfNotNull(String fieldName, Object toVerify,
			Object actual, String... subFieldName) {
		if (toVerify != null) {
			compareValues(fieldName, toVerify, actual, subFieldName);
		}
	}

	public boolean isCrossFormattedItem(ProductContent pContent,String  sSiteToTest
			,	SingleProductOffer singleProductOffer,	VariationProductOffer varProdOffer,boolean bSingleProductOffer )
	{
		Site[] sites = pContent.getSite();

		boolean bSearsSitePresent = false;
		boolean bKmartSitePresent = false;

		for (Site site : sites) 
		{
			int siteId = site.getId().intValue() ; 

			if(siteId==1)
				bKmartSitePresent = true;
			else 
				if(siteId==2)
					bSearsSitePresent = true;

		}

		String kmartPart = null;
		String searsPart = null;

		if(bSingleProductOffer)
		{
			kmartPart = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber();
			searsPart = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber();
		}
		else
		{
			kmartPart = varProdOffer.getProductOfferings().getProductOffer()[0].getPartNumber().getKmartPartNumber();
			searsPart = varProdOffer.getProductOfferings().getProductOffer()[0].getPartNumber().getSearsPartNumber();
		}

		if(sSiteToTest.equalsIgnoreCase("sears"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && (kmartPart==null||kmartPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
		{
			if((bSearsSitePresent && bKmartSitePresent ) && (searsPart==null||searsPart.isEmpty()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		return false;

	}

}
