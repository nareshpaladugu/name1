package com.shi.content.contentless;

public class ResponseItem {

	@Override
	public String toString() {
		return "ResponseItem [itemId=" + itemId + ", sellerId=" + sellerId
				+ ", isMatched=" + isMatched + ", matchedContentId="
				+ matchedContentId + ", matchedContentOwnerId="
				+ matchedContentOwnerId + ", ssin=" + ssin + ", guid=" + guid
				+ ", matchedTs=" + matchedTs + ", matchConfidence="
				+ matchedConfidence + ", matchReason=" + matchedReason + "]";
	}
	private String itemId;
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public Boolean getIsMatched() {
		return isMatched;
	}
	public void setIsMatched(Boolean isMatched) {
		this.isMatched = isMatched;
	}
	public String getMatchedContentId() {
		return matchedContentId;
	}
	public void setMatchedContentId(String matchedContentId) {
		this.matchedContentId = matchedContentId;
	}
	public String getMatchedContentOwnerId() {
		return matchedContentOwnerId;
	}
	public void setMatchedContentOwnerId(String matchedContentOwnerId) {
		this.matchedContentOwnerId = matchedContentOwnerId;
	}
	public String getSsin() {
		return ssin;
	}
	public void setSsin(String ssin) {
		this.ssin = ssin;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getMatchedTs() {
		return matchedTs;
	}
	public void setMatchedTs(String matchedTs) {
		this.matchedTs = matchedTs;
	}
	public String getMatchedConfidence() {
		return matchedConfidence;
	}
	public void setMatchedConfidence(String matchConfidence) {
		this.matchedConfidence = matchConfidence;
	}
	public String getMatchedReason() {
		return matchedReason;
	}
	public void setMatchedReason(String matchReason) {
		this.matchedReason = matchReason;
	}
	private String sellerId;
	private Boolean isMatched;
	private String matchedContentId;
	private String matchedContentOwnerId;
	private String ssin;
	private String guid;
	private String matchedTs;
	private String matchedConfidence;
	private String matchedReason;
}
