package com.shi.content.ranking.vos.pricing;

public class Price {
	private float regPrice;
	private Sale sale;
	private Shipping shipping;
	
	public Shipping getShipping() {
		return shipping;
	}
	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}
	public float getRegPrice() {
		return regPrice;
	}
	public void setRegPrice(float regPrice) {
		this.regPrice = regPrice;
	}
	public Sale getSale() {
		return sale;
	}
	public void setSale(Sale sale) {
		this.sale = sale;
	}

}
