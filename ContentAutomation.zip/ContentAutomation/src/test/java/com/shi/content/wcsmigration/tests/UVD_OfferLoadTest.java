package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.uvd.AutomotiveProductOffer;
import com.generated.vos.uvd.ProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.UVD_OfferVerifications;

public class UVD_OfferLoadTest {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="UVDOfferLoadTest")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		String vendorId = sFileName.split("\\.")[0].split("-")[3];
		
		BlockingQueue<List<AutomotiveProductOffer>> uvdProductQueue = new LinkedBlockingQueue<List<AutomotiveProductOffer>>();
		
		ChunkProducerThread<AutomotiveProductOffer> prodThread = new ChunkProducerThread<AutomotiveProductOffer>(sFileName, uvdProductQueue, AutomotiveProductOffer.class,"automotive-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<AutomotiveProductOffer> nodeToTest = uvdProductQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					for(ProductOffer productOffer : nodeToTest.get(0).getProductOfferings().getProductOffer()){
						pool.execute(new UVD_OfferVerifications(
								errorPartNumbers, 
								vendorMap, 
								vendorId, 
								productOffer, 
								nodeToTest.get(0).getProductContent(),
								nodeToTest.get(0).getRelationType(),
								nodeToTest.get(0).getAutomotiveGroupId(),
								nodeToTest.get(0).getImaClassControlPid(),
								nodeToTest.get(0).getKsnId()));
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		pool.shutdown();

		try {
			pool.awaitTermination(300, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
    public static List<String> errorPartNumbers = new ArrayList<String>();
	
	@BeforeClass(groups="UVDOfferLoadTest")
	public void initErrorParts(){

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			errorPartNumbers = ErrorPartReader.getUVDErrorPartsFromLogFile(errorlogFile);
		}/*else
		{
			String query = "SELECT partnumber FROM x_uvd_item_err WHERE lastupdate>=CURRENT TIMESTAMP-1 DAY AND VALID_DT IS NULL WITH UR";
			errorPartNumbers = DB2Utils.executeQuerySingleColMulRow(query);
		}
		System.out.println("Error Partnumbers List Size: " + errorPartNumbers.size());*/
	}
	
	public static Map<String, Map<String, String>> vendorMap = new HashMap<String, Map<String, String>>();
	
	@BeforeClass(groups = "UVDOfferLoadTest")
	public void populateVendorMap() {

		List<String> sellerIds = new ArrayList<String>();

		long start = System.currentTimeMillis();
		for (int bucket = 0; bucket < 4096; bucket++) {
			sellerIds = RestExecutor.getIdsForBucket(CollectionValuesVal.SELLER, bucket);

			for (String sellerId : sellerIds) {
				if (sellerId.startsWith("shc_")) {
					//String sellerResp = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, sellerId);
					com.generated.vos.vendor.Seller gbVendor = RestExecutor.getDataById(CollectionValuesVal.SELLER, sellerId);
					//String vendorID = JsonStringParser.getJsonValue(sellerResp, "{_blob{seller{programs{vd{vendorID}}}}}");
					String vendorID = gbVendor.getPrograms().getVd().getVendorID();
					if (vendorID != null) {
						Map<String, String> vd = new HashMap<String, String>();
						//String ediRouteCode = JsonStringParser.getJsonValue(sellerResp, "{_blob{seller{programs{vd{ediRouteCode}}}}}");
						String ediRouteCode = gbVendor.getPrograms().getVd().getEdiRouteCode();
						//String name = JsonStringParser.getJsonValue(sellerResp, "{_blob{seller{programs{vd{name}}}}}");
						String name = gbVendor.getPrograms().getVd().getName();
						String vendorDunsNo = sellerId.substring(4);
						Boolean v2sCertified = (gbVendor.getPrograms().getVd().getVendorAttr() == null 
								|| gbVendor.getPrograms().getVd().getVendorAttr().getSears() == null
								|| gbVendor.getPrograms().getVd().getVendorAttr().getSears().getVndToStoreCertified() == null)?false:gbVendor.getPrograms().getVd().getVendorAttr().getSears().getVndToStoreCertified();
						Boolean v2sElig = (gbVendor.getPrograms().getVd().getVendorAttr() == null 
								|| gbVendor.getPrograms().getVd().getVendorAttr().getSears() == null
								|| gbVendor.getPrograms().getVd().getVendorAttr().getSears().getVndToStoreElig() == null)?false:gbVendor.getPrograms().getVd().getVendorAttr().getSears().getVndToStoreElig();
						vd.put("ediRouteCode", ediRouteCode);
						vd.put("name", name);
						vd.put("vendorDunsNo", vendorDunsNo);
						vd.put("v2sCertified", v2sCertified.toString());
						vd.put("v2sElig", v2sElig.toString());
						vendorMap.put(vendorID, vd);
					}
				}
			}
		}
		System.out.println("Time taken to populate vendorMap: " + ((System.currentTimeMillis()-start)/1000) + "sec");
		System.out.println("vendorMap size: " + vendorMap.size());
	}
	
}
