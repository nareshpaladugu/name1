package com.shi.content.contentless;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.ReflectionUtils;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.contentless.MatchLookupTests.MatchData;



public class MatchLookupVerifications implements Runnable {
	
	private static final String BASE_MMNDECR = "MMN:";
	private static final String BASE_SSINDECR = "SSIN:";
	private static final String BASE_UPCDECR = "UPC:";
	Gson gson = new Gson();
	String postBody;
	String ssinDecrReason, upcDecrReason, mmnDecrReason;
	Item lookupitem;
	Boolean pkgQtyMatch = null;
	int currentConfidencScore;
	String currentMatchReason;
	Set<String> setOfGuids;
	Map<String, MatchReason> finalGuids = new HashMap<String, MatchReason>();
	Map<String,String> guidSSINDecrementReasons= new HashMap<String, String>();
	Map<String,String> guidBrandDecrementReasons = new HashMap<String, String>();
	Map<String,String> guidUPCDecrementReasons = new HashMap<String, String>();
	com.generated.vos.acmesourcebyid.Item iaSourceToTest;
	
	
	public MatchLookupVerifications(com.generated.vos.acmesourcebyid.Item iaSource){
		/*this.postBody = postBody;
		JsonObject items = gson.fromJson(postBody, JsonObject.class);
		 lookupitem = gson.fromJson(items.get("items").getAsJsonArray().get(0), Item.class);*/
		iaSourceToTest = iaSource; 
		lookupitem = new Item();
		lookupitem.setItemId("Test"+(10000+ThreadLocalRandom.current().nextInt(0, 90000)));
		lookupitem.setSellerId("66668888");
		lookupitem.setSsin(iaSource.getSsin());
		lookupitem.setPackageQuantity(iaSource.getAttributes().getPackageQuantity() == null? "1": iaSource.getAttributes().getPackageQuantity());
		lookupitem.setUpc(iaSource.getAttributes().getUpcCode());
		lookupitem.setBrand(iaSource.getAttributes().getBrandName());
		lookupitem.setModelNo(iaSource.getAttributes().getModelNumber());
		
		
	}
	@Override
	public void run() {
		
		String postResponse =  null;
		
		String postBody = this.generateContentLessLookupMsg();
		CompareValuesUtility.init();
		CompareValuesUtility.addDataFieldForReport("LookupMsg", postBody);
		try{
		try {
			
			postResponse = RestExecutor.postForJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/contentless/lookup"), postBody);
			if(postResponse.contains("TIME OUT ERROR")){
				postResponse = RestExecutor.postForJSonResponse(new URI("http://"+LoadProperties.IA_SERVER+"/acme/contentless/lookup"), postBody);
				if(postResponse.contains("TIME OUT ERROR")){
					CompareValuesUtility.addFailedDataFieldForReport("TimeOut","Time out for lookup "+ lookupitem.getSsin());
					CompareValuesUtility.setupResult(iaSourceToTest.getId(), true);
					return;
				}
			}
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		JsonObject items = null;
		
		try{
		 items = gson.fromJson(postResponse, JsonObject.class);
		}
		catch(Exception e){
			System.out.println("Caught parsing exception "+e.getCause()+" ---  "+ postResponse );
			return;
			
		}
		 ResponseItem responseitem = gson.fromJson(items.get("items").getAsJsonArray().get(0), ResponseItem.class);
		 
		if(lookupitem.getSsin()!= null){
			this.checkSSIN(lookupitem.getSsin());
		}
		
		if(lookupitem.getUpc() != null){
			this.checkUPC(lookupitem.getUpc());
			
		}
		if(lookupitem.getModelNo() != null){
			this.checkMMNBrand(lookupitem.getModelNo(), lookupitem.getBrand());
			
		}
		
		//Check decrement logic
		for(String guid : finalGuids.keySet()){
			MatchReason currentMatchReason = finalGuids.get(guid);
			checkSSINdecr(currentMatchReason, guid);
			checkUPCDecr(currentMatchReason, guid);
			checkMMNDecr(currentMatchReason, guid);
		}
		
		
		String winningguid = null;
		int highestConfScore = -30;
		boolean noMatchDueToMultipleConfScore = false;
		for(String guid : finalGuids.keySet()){
			CompareValuesUtility.addDataFieldForReport("GUIDToConsider", guid+": "+finalGuids.get(guid));
			if(finalGuids.get(guid).matchConfidence == highestConfScore){
				noMatchDueToMultipleConfScore = true;
				CompareValuesUtility.addDataFieldForReport("MultiConf", "something");
			}
			if(finalGuids.get(guid).matchConfidence() > highestConfScore){
				highestConfScore = finalGuids.get(guid).matchConfidence();
				noMatchDueToMultipleConfScore = false;
				winningguid = guid;
			}
		}
		
		for(String guid : guidUPCDecrementReasons.keySet()){
			
			MatchReason currentMatchReason = new MatchReason(MatchData.UPC_DECR, guidUPCDecrementReasons.get(guid));
			checkSSINdecr(currentMatchReason, guid);
			checkMMNDecr(currentMatchReason, guid);
			CompareValuesUtility.addDataFieldForReport("GUIDToConsider", guid+": "+currentMatchReason);

		}

		for(String guid : guidBrandDecrementReasons.keySet()){
			
			MatchReason currentMatchReason = new MatchReason(MatchData.MMN_DECR,guidBrandDecrementReasons.get(guid));
			checkSSINdecr(currentMatchReason, guid);
			checkUPCDecr(currentMatchReason, guid);
			CompareValuesUtility.addDataFieldForReport("GUIDToConsider", guid+": "+currentMatchReason);
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		//No guids found 
		if(winningguid == null || highestConfScore == 0 ){
			
			compareValues("isMatched", false, responseitem.getIsMatched());
			CompareValuesUtility.verifyNull("itemId", responseitem.getItemId());
			CompareValuesUtility.verifyNull("sellerId", responseitem.getSellerId());
			CompareValuesUtility.verifyNull("Winningguid",  responseitem.getGuid());
			CompareValuesUtility.verifyNull("ssin", responseitem.getSsin());
			if(highestConfScore == 0){
				compareValues("MatchConf", "0", responseitem.getMatchedConfidence());
				compareValues("MatchReason", finalGuids.get(winningguid).matchedReason+"", responseitem.getMatchedReason());
			}
			else
				compareValues("MatchReason", "Missing lookup item list.", responseitem.getMatchedReason());
			
			
		}else{
			String[] reconciledData = hitReconciledToGetData(winningguid);
			if(reconciledData == null )
				compareValues("isMatched", false, responseitem.getIsMatched());
			else{
				compareValues("isMatched", true, responseitem.getIsMatched());
				compareValues("Winningguid", winningguid, responseitem.getGuid());
				compareValues("ssin", reconciledData == null? null :reconciledData[0], responseitem.getSsin());
				CompareValuesUtility.verifyNullOrEqual("contentId", reconciledData[2], responseitem.getMatchedContentId());
				CompareValuesUtility.verifyNullOrEqual("ownerId", reconciledData[3], responseitem.getMatchedContentOwnerId());
				compareValues("MatchConf", finalGuids.get(winningguid).matchConfidence+"", responseitem.getMatchedConfidence());
				compareValues("MatchReason", finalGuids.get(winningguid).matchedReason+"", responseitem.getMatchedReason());
			}
			compareValues("itemId", lookupitem.getItemId(), responseitem.getItemId());
			compareValues("sellerId", lookupitem.getSellerId(), responseitem.getSellerId());
			
		}
			
		
		
		//Hit reconciled for getting winning ssin
		}catch(Exception e){
			e.printStackTrace();
			CompareValuesUtility.addDataFieldForReport("Exception", e.getMessage());
		}
		CompareValuesUtility.setupResult(iaSourceToTest.getId(), true);
	}
	
	private String[] hitReconciledToGetData(String winningguid) {
		String reconciledData = hitURLWithRetry(RestAPIs.getAcmeURI(CollectionValuesVal.ACME_RECONCILED, winningguid));
		String contentId = null, ownerId = null;
		if(!reconciledData.contains("id")){
			return null;
		}else{
			String contributorDetails = JsonStringParser.getJsonValueNew(reconciledData, "item.attributes.ssinSourceId.value").replace("\"", "");
			
			if(contributorDetails.equals(iaSourceToTest.getId())){
					contentId = iaSourceToTest.getAttributes().getContentId();
					ownerId = iaSourceToTest.getAttributes().getOwnerId();
			}else{
				String contribSourceId = hitURLWithRetry(RestAPIs.getAcmeURI(CollectionValuesVal.IA_SOURCE_BY_ID, contributorDetails));
				com.generated.vos.acmesourcebyid.Item contribSource =  gson.fromJson(contribSourceId,com.generated.vos.acmesourcebyid.Item.class);
				contentId = contribSource.getAttributes().getContentId();
				ownerId = contribSource.getAttributes().getOwnerId();
			}
			String ssin =  JsonStringParser.getJsonValueNew(reconciledData, "item.ssin").replace("\"", "");
			
			/*JsonObject  sellerDetails = gson.fromJson(contributorDetails, JsonObject.class);
			Iterator<Entry<String, JsonElement>> sellerIterator = sellerDetails.entrySet().iterator();
			String finalSellerId = "";
			while(sellerIterator.hasNext()){
				Entry<String, JsonElement> currentEntry = sellerIterator.next();
				String sellerId = currentEntry.getKey();
				String itemId = currentEntry.getValue().toString();
				if(itemId.contains(iaSourceToTest.getId()))
					finalSellerId = sellerId;
			}*/
			
			String finalSellerId =  lookupitem.getSellerId();
			
			return new String[]{ssin, finalSellerId,contentId, ownerId};
		}
		
		
	}
	public ErrorStatuses commonVerifications(String allResponses){
		
		//Check status only active
		String status = null;
		status = JsonStringParser.getJsonValueNew(allResponses, "items.status");
		if(status == null)
			status = JsonStringParser.getJsonValueNew(allResponses, "attributes.status");
		if(status == null)
			status = JsonStringParser.getJsonValueNew(allResponses, "items.attributes.status");
		Set<String> uniqueStatuses = MatchLookupTests.getUniqueData(status);
		if(!(uniqueStatuses.contains("ACTIVE") || !(uniqueStatuses.contains("status:ACTIVE"))))
			return ErrorStatuses.NO_ACTIVE_STATUS_FOUND;

		//Check programtype not only cpc
		String programType = JsonStringParser.getJsonValueNew(allResponses, "items.attributes.programType");
		if(programType == null)
			programType = JsonStringParser.getJsonValueNew(allResponses, "attributes.programType");
		Set<String> uniquePTypes = MatchLookupTests.getUniqueData(programType);
		if(uniquePTypes.size() ==1 && uniquePTypes.contains("CPC"))
			return ErrorStatuses.PROGRAM_TYPE_ALL_CPC;
		
		//Check classifier not just V
		String classifier = JsonStringParser.getJsonValueNew(allResponses, "items.attributes.classifier");
		if(classifier == null)
			classifier = JsonStringParser.getJsonValueNew(allResponses, "attributes.classifier");
		Set<String> uniqueClassifiers = MatchLookupTests.getUniqueData(classifier);
		if((uniqueClassifiers.size() ==1 && (uniqueClassifiers.contains("V") || uniqueClassifiers.contains("P")) )
				||(uniqueClassifiers.size() ==2 && (uniqueClassifiers.contains("V") && uniqueClassifiers.contains("P"))))
			return ErrorStatuses.ALL_VARIATIONS;
		
		String packageQuantity = JsonStringParser.getJsonValueNew(allResponses, "items.attributes.packageQuantity");
		if(packageQuantity == null)
			packageQuantity = JsonStringParser.getJsonValueNew(allResponses, "attributes.packageQuantity");
		Set<String> uniquePackageQuantity = MatchLookupTests.getUniqueData(packageQuantity);
		if(uniquePackageQuantity.contains(lookupitem.getPackageQuantity()))
			pkgQtyMatch = true;
		else 
			if(lookupitem.getPackageQuantity().equals("1") && uniquePackageQuantity.contains("null"))
				pkgQtyMatch = null;
			else if( uniquePackageQuantity != null && !uniquePackageQuantity.contains("\""+lookupitem.getPackageQuantity()+"\"")){
				pkgQtyMatch=false;
				return ErrorStatuses.PACKAGE_QTY_MISMATCH;
			}
		
		
		return ErrorStatuses.NO_ERROR;
		
	}

	public enum ErrorStatuses{
		NO_ACTIVE_STATUS_FOUND,
		PROGRAM_TYPE_ALL_CPC,
		ALL_VARIATIONS,
		PACKAGE_QTY_MISMATCH,
		NO_ERROR;
	}
	
	public  String generateContentLessLookupMsg(){
		JsonObject meta = new JsonObject();
		meta.addProperty("batchNumber", "123");
		meta.addProperty("itemCount", 1);
		
		JsonArray items = new JsonArray();
		
		String[] itemProperties = new String[]{
				"itemId",
				"sellerId",
				"packageQuantity",
				"ssin",
				"upc",
				"brand",
				"modelNo"};
		
		items.add(buildLookupItemProperties(itemProperties));
		
		
		
		JsonObject lookupMsg = new JsonObject();
		lookupMsg.add("meta", meta);
		lookupMsg.add("items", items);
		
		
		return lookupMsg.toString();
		
		
	}
	
	/**
	 * Build lookup item message by adding the propertiesToAdd
	 * @param propertiesToAdd
	 * @return
	 */
	private JsonObject buildLookupItemProperties(String[] propertiesToAdd){
		JsonObject item = new JsonObject();
		for(String property : propertiesToAdd){
			Object val = ReflectionUtils.getFieldFromObject(this.lookupitem, property) ;
			if(val != null ){
					item.addProperty(property, val.toString());
				
			}
			if(property.equals("packageQuantity")&&val == null ){
				item.addProperty(property, "1");
			}
		}
		
		
		return item;
	}
	
	private void checkUPC(String upc){
		
		upc = StringUtils.leftPad(upc, 14, "0");
		//Hit feature with upc
		String upcFeatures = hitURLWithRetry(RestAPIs.getAltAcmeURI(CollectionValuesVal.ACME_FEATURE, "upcCode",upc));
		if(!upcFeatures.contains("id"))
			return;
		Iterator<JsonElement> iterator = this.fetchElements(upcFeatures);

		Map<String, MatchData> guidData = new HashMap<String, MatchData>();
		
		while(iterator.hasNext()){
			
			
			MatchLookupTests.MatchData matched_data = null;
			JsonElement featureData = iterator.next();
			com.generated.vos.iafeaturesbyid.Item iaFeature =  gson.fromJson(featureData,com.generated.vos.iafeaturesbyid.Item.class);
			String guid = iaFeature.getAttributes().getGuid();
			
			//Skip guid if current matchdata is already highest
			if(guidData.containsKey(guid) && (guidData.get(guid).equals(MatchData.UPCQTY_INCR) || 
					guidData.get(guid).equals(MatchData.UPCQTY_BASIC)))
					continue;
			
			ErrorStatuses validationResult = this.commonVerifications(featureData.toString());
			if(!validationResult.equals(ErrorStatuses.NO_ERROR) && !validationResult.equals(ErrorStatuses.PACKAGE_QTY_MISMATCH) && !guidData.containsKey(guid) ){

				if(guidUPCDecrementReasons.get(guid) == null){
					guidUPCDecrementReasons.put(guid, BASE_UPCDECR+validationResult.toString());
				}else{
					String upcDecrReason = guidUPCDecrementReasons.get(guid);
					upcDecrReason += (","+validationResult.toString());
					guidUPCDecrementReasons.put(guid, upcDecrReason);
				}
				continue;
				
			}
			
			guidUPCDecrementReasons.remove(guid);
			if(finalGuids.containsKey(guid)){
				matched_data = (pkgQtyMatch == null?MatchData.UPCQTYNULL_INCR: MatchData.UPCQTY_INCR);
			}else{
				
				matched_data = (pkgQtyMatch== null?MatchData.UPCQTYNULL_BASIC : (pkgQtyMatch==true?MatchData.UPCQTY_BASIC:MatchData.UPC_QTYMISMATCH));
			}
			guidData.put(guid, matched_data);
		}
		for(String guid : guidData.keySet()){
			if(finalGuids.containsKey(guid))
				finalGuids.get(guid).add(guidData.get(guid).matchReason(),guidData.get(guid).matchScore());
			else
				finalGuids.put(guid, new MatchReason(guidData.get(guid).matchReason(), guidData.get(guid).matchScore()));
		}
		
	}
	
	private void checkSSIN(String ssin){

		String ssinSources = hitURLWithRetry(RestAPIs.getAltAcmeURI(CollectionValuesVal.IA_SOURCE_BY_ID, "ssin",lookupitem.getSsin()));
		Map<String, MatchData> guidData = new HashMap<String, MatchData>();

		if(!ssinSources.contains("id")){
			finalGuids.put("Noguid", new MatchReason(MatchData.SSIN_DECR));
			return;
		}

		setOfGuids = MatchLookupTests.getUniqueData(JsonStringParser.getJsonValueNew(ssinSources, "items.guid"));

		if(setOfGuids.size() > 1){
			Iterator<JsonElement> iterator = this.fetchElements(ssinSources);
			while(iterator.hasNext()){

				JsonElement sourceData = iterator.next();
				com.generated.vos.acmesourcebyid.Item iaSource =  gson.fromJson(sourceData,com.generated.vos.acmesourcebyid.Item.class);
				String docType = JsonStringParser.getJsonValueNew(sourceData.toString(), "documentType");
				if( docType != null && docType.contains("CONTENTLESS"))
					continue;
				String guid = iaSource.getGuid();
				//Skip guid if current matchdata is already highest
				if(guidData.containsKey(guid) && (guidData.get(guid).equals(MatchData.SSINQTY_BASIC)))
					continue;

				MatchLookupTests.MatchData matched_data = null;

				ErrorStatuses validationResult = this.commonVerifications(sourceData.toString());
				if(!validationResult.equals(ErrorStatuses.NO_ERROR) && !validationResult.equals(ErrorStatuses.PACKAGE_QTY_MISMATCH) && !guidData.containsKey(guid)){
					if(guidSSINDecrementReasons.get(guid) == null){
						guidSSINDecrementReasons.put(guid, BASE_SSINDECR+validationResult.toString());
					}else{
						String ssinReasons = guidSSINDecrementReasons.get(guid);
						ssinReasons +=(","+validationResult.toString());
						guidSSINDecrementReasons.put(guid, ssinReasons);
					}
					continue;
				}

				guidSSINDecrementReasons.remove(guid);
				matched_data = (pkgQtyMatch== null?MatchData.SSINQTYNULL_BASIC : (pkgQtyMatch== true?MatchData.SSINQTY_BASIC: MatchData.SSIN_QTYMISMATCH));
				guidData.put(guid, matched_data);

			}
			for(String guid : guidData.keySet()){

				if(finalGuids.containsKey(guid))
					finalGuids.get(guid).add(guidData.get(guid));
				else
					finalGuids.put(guid, new MatchReason(guidData.get(guid).matchReason(), guidData.get(guid).matchScore()));

			}

		}
		else{
			ErrorStatuses validationResult = this.commonVerifications(ssinSources);
			if(validationResult.equals(ErrorStatuses.NO_ERROR)){

				if(pkgQtyMatch!= null && pkgQtyMatch == true){
					finalGuids.put(setOfGuids.iterator().next(), new MatchReason(MatchData.SSINQTY_BASIC));
				}else{
					if(pkgQtyMatch == null) finalGuids.put(setOfGuids.iterator().next(), new MatchReason(MatchData.SSINQTYNULL_BASIC));
				}

			}else{

				if(validationResult.equals(ErrorStatuses.PACKAGE_QTY_MISMATCH))
					finalGuids.put(setOfGuids.iterator().next(), new MatchReason( MatchLookupTests.MatchData.SSIN_QTYMISMATCH));
				else
					guidSSINDecrementReasons.put(setOfGuids.iterator().next(), BASE_SSINDECR+validationResult.toString());
			}

		}

	}
		
		
	
	private void checkMMNBrand(String mmn, String brand){
		
		NameValuePair brandName = new BasicNameValuePair("brandName", brand.toUpperCase());
		NameValuePair mmnData = new BasicNameValuePair("modelNumber", mmn.replace("-", "").replace("_", "").toUpperCase());
		List<NameValuePair> keyValues = new ArrayList<>();
		keyValues.add(brandName);
		keyValues.add(mmnData);
		
		//Hit feature with mmn and brand
		String mmnBrandFeatures = hitURLWithRetry(RestAPIs.getAcmeParametrizedURL(CollectionValuesVal.ACME_FEATURE, keyValues)) ;
		if(!mmnBrandFeatures.contains("id"))
			return;
		Map<String, MatchData> guidData = new HashMap<String, MatchData>();
		Iterator<JsonElement> iterator;
		try{
		iterator = this.fetchElements(mmnBrandFeatures);
		}catch(NullPointerException e){
			System.out.println("NPE "+ mmnBrandFeatures);
			throw e;
		}
		while(iterator.hasNext()){
			
			MatchLookupTests.MatchData matched_data = null;
			JsonElement featureData = iterator.next();
			ErrorStatuses validationResult = this.commonVerifications(featureData.toString());
			com.generated.vos.iafeaturesbyid.Item iaFeature =  gson.fromJson(featureData,com.generated.vos.iafeaturesbyid.Item.class);
			String guid = iaFeature.getAttributes().getGuid();

//			Skip guid if current matchdata is already highest
			if(guidData.containsKey(guid) &&  (guidData.get(guid).equals(MatchData.MMNQTY_INCR) ||	guidData.get(guid).equals(MatchData.MMNQTY_BASIC)))
					continue;
			
			if(!validationResult.equals(ErrorStatuses.NO_ERROR) && !validationResult.equals(ErrorStatuses.PACKAGE_QTY_MISMATCH) && !guidData.containsKey(guid)){

				if(guidBrandDecrementReasons.get(guid) == null){
					guidBrandDecrementReasons.put(guid, BASE_MMNDECR+validationResult.toString());
				}else{
					String mmnReasons = guidBrandDecrementReasons.get(guid);
					mmnReasons += (","+validationResult.toString());
					guidBrandDecrementReasons.put(guid, mmnReasons);
				}
				continue;
			}
			
			guidBrandDecrementReasons.remove(guid);
			if(finalGuids.containsKey(guid)){
					matched_data = (pkgQtyMatch == null?MatchData.MMNQTYNULL_INCR: MatchData.MMNQTY_INCR);
			}else{
					matched_data = (pkgQtyMatch== null?MatchData.MMNQTYNULL_BASIC : (pkgQtyMatch==true? MatchData.MMNQTY_BASIC : MatchData.MMN_QTYMISMATCH));
			}
			guidData.put(guid, matched_data);
		}
		for(String guid : guidData.keySet()){
			MatchReason currentguid = finalGuids.get(guid);
			MatchData currentMatchData = guidData.get(guid);
			
			
			if(finalGuids.containsKey(guid)){
				
				currentguid.add(currentMatchData);
			}
			else{
				finalGuids.put(guid, new MatchReason(currentMatchData));
			}
		}
		
	}
	
	private void checkSSINdecr(MatchReason currentguidData, String guid){
		if(!currentguidData.matchedReason.contains("SSIN") && lookupitem.getSsin() != null){
			currentguidData.add(MatchData.SSIN_DECR);
			if(guidSSINDecrementReasons.get(guid) != null)
				currentguidData.setDecrementReason(guidSSINDecrementReasons.get(guid));
		}
	}
	
	private void checkUPCDecr(MatchReason currentguidData, String guid){
		if(!currentguidData.matchedReason.contains("UPC") && lookupitem.getUpc() != null)
			currentguidData.add(MatchData.UPC_DECR);
//			currentguidData.setDecrementReason(guidUPCDecrementReasons.get(guid));
	}
	
	private void checkMMNDecr(MatchReason currentguidData, String guid){
		if(!currentguidData.matchedReason.contains("MODELNO") && lookupitem.getModelNo() != null)
			currentguidData.add(MatchData.MMN_DECR);
		if(guidBrandDecrementReasons.get(guid) != null)
			currentguidData.setDecrementReason(guidBrandDecrementReasons.get(guid));
	}
	
	
	private String hitURLWithRetry(URI url){
		String response = RestExecutor.getJSonResponse(url);
		if(response.contains("TIME OUT ERROR")){
			response = RestExecutor.getJSonResponse(url);
			if(response.contains("TIME OUT ERROR")){
				CompareValuesUtility.addFailedDataFieldForReport("TimeOut","Timeout occurred @ "+ url);
				CompareValuesUtility.setupResult(iaSourceToTest.getId(), true);
				throw new RuntimeException("Time out error occurred for "+ url);
			}
			
		}
		return response;
	}
	
	/**
	 * Parses list of items as array and returns an iterator over the item
	 * @param responses
	 * @return
	 */
	private Iterator<JsonElement> fetchElements(String responses){
		JsonObject allItemsObject;
		try{
			allItemsObject = gson.fromJson(responses, JsonObject.class);
		}
		catch(Exception e){
			System.out.println("Caught parsing exception "+e.getCause()+" ---  "+ responses );
			return null;

		}
		JsonArray iaItems = allItemsObject.get("items").getAsJsonArray();
		return iaItems.iterator();
	}
	
	private class MatchReason{
		String matchedReason ;
		String decrementReason;

		Integer matchConfidence = 0;
		MatchReason(String matchReason, Integer confidence){
			this.matchConfidence = confidence;
			this.matchedReason = matchReason;
		}

		MatchReason(MatchData matchData){
			this.matchConfidence += matchData.matchScore();
			this.matchedReason = matchData.matchReason();
		}
		
		public MatchReason(MatchData matchData, String decrReason) {
			this.matchConfidence += matchData.matchScore();
			this.matchedReason = matchData.matchReason();
			this.decrementReason=decrReason;
		}

		void add(String matchReason, Integer confidence){
			this.matchConfidence += confidence;
			this.matchedReason += "_";
			this.matchedReason += matchReason;
		}
		
		public void add(MatchData matchData) {
			this.matchConfidence += matchData.matchScore();
			this.matchedReason += "_";
			this.matchedReason += matchData.matchReason();
		}
		
		public String matchReason() {
			return matchedReason;
		}


		public Integer matchConfidence() {
			return matchConfidence;
		}

		@Override
		public String toString() {
			return "[Reason=" + matchedReason
					+ ",Conf=" + matchConfidence + "]"+ (this.decrementReason==null?"":decrementReason);
		}
		
		public void setDecrementReason(String decrementReason){
			if(this.decrementReason == null)
				this.decrementReason = decrementReason;
			else{
				this.decrementReason += ",";
				this.decrementReason += decrementReason;
			}
		}
		
		public String decrementReason() {
			return decrementReason;
		}
		
		

	}
}
