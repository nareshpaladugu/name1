package com.shi.content.storeloadtests;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.FileProviderClass;

/**
 * @author skadam
 * 
 */
public class StoreLoadTest {


	public static Map<String, TaxGeoCountyVO> geo_countyCode = null;

	@BeforeTest(groups = "StoreLoadTest")
	public void initMapWithGeoAndCounty()
	{
		String sKmartStoreLoadFile = System.getProperty("KmartStoreLoadFile","C:\\Swapnil\\StoreLoad\\kmart_sample.txt");

		System.out.println("KmartStoreLoadFile............ "+sKmartStoreLoadFile);

		readTaxFileForGeoAndCounty(sKmartStoreLoadFile);
	}

	@Test(dataProviderClass = FileProviderClass.class, dataProvider = "fileProvider", groups = "StoreLoadTest")
	public void testStoreLoad(String fileName) throws FileNotFoundException,
	IOException {

		processSearsAndKmartInputFile(fileName);
	}

	private void processSearsAndKmartInputFile(String fileName) {
		try {

			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String sSingleLine;

			final ExecutorService pool = Executors
					.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

			while ((sSingleLine = br.readLine()) != null) {

				pool.execute(new StoreLoadMatchJob(sSingleLine));
			}
			br.close();
			pool.shutdown();
			try {
				pool.awaitTermination(240, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				System.out.println("pool.awaitTermination - Exception");
			}
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFound- Exception");
		} catch (IOException ie) {
			ie.printStackTrace();
		}
	}

	private void readTaxFileForGeoAndCounty(String fileName) {
		try {

			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			TaxGeoCountyVO tax = null;
			String sSingleLine;

			geo_countyCode = new HashMap<String, TaxGeoCountyVO>();
			while ((sSingleLine = br.readLine()) != null) {

				String storeId = sSingleLine.substring(5, 12);
				String geoCode = sSingleLine.substring(176, 178);
				String countyCode=sSingleLine.substring(140,144);
				tax = new TaxGeoCountyVO();
				if (null != storeId && (storeId = storeId.trim()).length() > 0) {
					tax.setStoreID(storeId);
					tax.setGeoCode(geoCode);
					tax.setCountyCode(countyCode);
				} 
				else
				{
					tax.setGeoCode(null);
					tax.setCountyCode(null);
				}

				geo_countyCode.put(storeId, tax);

			}
			
			br.close();
		} catch (IOException e) {

		}
	}
}
