package com.shi.content.wcsmigration.mp;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.catdelta.Attribute;
import com.generated.vos.catdelta.Attributes;
import com.generated.vos.catdelta.CommissionRate;
import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.CommonItemFieldsGroup;
import com.generated.vos.catdelta.Cpc;
import com.generated.vos.catdelta.Fbm;
import com.generated.vos.catdelta.Flags;
import com.generated.vos.catdelta.Hierarchy;
import com.generated.vos.catdelta.ImageUrl;
import com.generated.vos.catdelta.Shipping;
import com.generated.vos.catdelta.Site;
import com.generated.vos.catdelta.SpecificFbmsFieldsGroup;
import com.generated.vos.catdelta.SwatchImageUrl;
import com.generated.vos.catdelta.Upsert;
import com.generated.vos.catdelta.VariantAttribute;
import com.generated.vos.catdelta.VariantItem;
import com.generated.vos.catdelta.Variation;
import com.generated.vos.catdelta.types.AttributeTypeType;
import com.generated.vos.catdelta.types.CompetitivenessType;
import com.generated.vos.catdelta.types.MapPriceIndicatorType;
import com.generated.vos.hierarchy.Attr;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.offer.AltIds;
import com.generated.vos.offer.Classifications;
import com.generated.vos.offer.Condition;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.DispTags;
import com.generated.vos.offer.Grocery;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Marketplace;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.Val;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.commons.WcsMigrationCommon;

public class MPCatalog_OfferVerificationsNew implements Runnable 
{
	WcsMigrationCommon wcsMigrationCommon = new WcsMigrationCommon(); 

	SHCContentCommons commonUtils = new SHCContentCommons("","sears");
	String programType;
	CommonFbmsFieldsGroup commonFields;
	CommonItemFieldsGroup commonItems;
	SpecificFbmsFieldsGroup specificFields;
	Cpc cpcNode;
	String confScore;
	String parentId, spinId,ssin, uid;
	Variation variation;
	VariantItem variantItem;
	private boolean bSingleProductOffer = true;
	String sellerId;
	String sModelNumber;
	Boolean isFit = true;
	private Boolean isBrandCodeFound = null;
	private static final String FBM = "FBM";
	private static final String FBS = "FBS";
	private static final String DSS = "DSS";
	private static final String CPC = "CPC";
	List<List<String>>  sellerDetails;
	Shipping shipping;

	public MPCatalog_OfferVerificationsNew(Upsert upsertNode, String sellerId, List<List<String>> sellerData){
		this.sellerId = sellerId;
		this.sellerDetails = sellerData;
		if(upsertNode.getUpsertTypeChoice().getFbm()!= null){
			programType = FBM;
			fetchData(upsertNode.getUpsertTypeChoice().getFbm());
			parentId = TestUtils.generateFBMId(upsertNode.getUpsertTypeChoice().getFbm().getItemId());

		}else if(upsertNode.getUpsertTypeChoice().getFbs()!= null){
			programType = FBS;
			fetchData(convertToFBM(upsertNode.getUpsertTypeChoice().getFbs()));
			parentId = upsertNode.getUpsertTypeChoice().getFbs().getDartPartNumber();

		}else if(upsertNode.getUpsertTypeChoice().getDss() != null){
			programType = DSS;
			fetchData(convertToFBM(upsertNode.getUpsertTypeChoice().getDss()));
			parentId = TestUtils.generateFBMId(upsertNode.getUpsertTypeChoice().getDss().getItemId());

		}else if(upsertNode.getUpsertTypeChoice().getCpc()!= null){
			programType = CPC;
			cpcNode = upsertNode.getUpsertTypeChoice().getCpc();
			commonItems = cpcNode.getCommonItemFieldsGroup();
			if(cpcNode.getConfidenceScore()!= null)
				confScore = cpcNode.getConfidenceScore().toPlainString();
			parentId = TestUtils.generateCPCId(sellerDetails.get(3).get(3),sellerId,cpcNode.getItemId());
			spinId = cpcNode.getItemId()+"";
			ssin = cpcNode.getSsin();
			uid = cpcNode.getGuid();
		}
		else if(upsertNode.getUpsertTypeChoice().getVariation() != null){

			variation = upsertNode.getUpsertTypeChoice().getVariation();
			programType = variation.getProgramType().name();
			commonFields = convertToCommon(variation.getCommonFbmsFieldsGroupVariation());
			if(variation.getConfidenceScore()!= null)
				confScore = variation.getConfidenceScore().toPlainString();
			parentId = TestUtils.generateVariationId(sellerId, variation.getVariationGroupId(), variation.getProgramType().toString());
			bSingleProductOffer  = false;
		}

	}

	public static <T> Fbm convertToFBM(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		Fbm fbm=new Fbm();
		try {
			BeanUtils.copyProperties(fbm, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fbm;
	}

	public static <T> CommonFbmsFieldsGroup convertToCommon(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		CommonFbmsFieldsGroup commonsIncommons=new CommonFbmsFieldsGroup();
		try {
			BeanUtils.copyProperties(commonsIncommons, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsIncommons;
	}

	public static <T> SpecificFbmsFieldsGroup convertToSpecificFields(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		SpecificFbmsFieldsGroup commonsInSpecificFields=new SpecificFbmsFieldsGroup();
		try {
			BeanUtils.copyProperties(commonsInSpecificFields, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsInSpecificFields;
	}


	public void fetchData(Fbm fbmItem){
		commonFields = fbmItem.getCommonFbmsFieldsGroup();
		specificFields=fbmItem.getSpecificFbmsFieldsGroup();
		if(fbmItem.getConfidenceScore()!=null)
			confScore=fbmItem.getConfidenceScore().toPlainString();
		spinId = fbmItem.getItemId()+"";
		ssin = fbmItem.getSsin();
		uid = fbmItem.getGuid();
	}

	public void run() {

		APIResponse<Offer> allResponse;
		String varSKUPartNumber;
		if(bSingleProductOffer){
			allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,parentId);
			callVerifications(allResponse, parentId);
		}
		else{
			for(VariantItem varItem : variation.getVariantItems().getVariantItem()){
				if(variation.getProgramType().toString() == FBS){
					varSKUPartNumber = varItem.getDartPartNumber();
				}else {
					varSKUPartNumber = TestUtils.generateFBMId(varItem.getItemId());
				}

				allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,varSKUPartNumber);
				variantItem = varItem;
				spinId = variantItem.getItemId()+"";
				specificFields = this.convertToSpecificFields(varItem.getSpecificFbmsFieldsGroupVariation());
				ssin = varItem.getSsin();
				uid = varItem.getGuid();
				callVerifications(allResponse,varSKUPartNumber);
				//				System.out.println("Setting specific for spinId "+ spinId+"  "+ specificFields.getSpecificFbmsFieldsGroupChoice().getPricing().getCompetitiveness());
			}
		}

	}

	private void callVerifications(APIResponse<Offer> allResponse, String offerId) {

		try{
			CompareValuesUtility.init();
			Offer gbOffer = (Offer)allResponse.getT();

			if(gbOffer == null){
				CompareValuesUtility.logFailed("Id", offerId, " Not found");
				CompareValuesUtility.setupResult(offerId, true);
				return;
			}else{
				if(programType.equals(CPC))
					verifyCPC(gbOffer, offerId);
				else
					verifyOffer(gbOffer, offerId);
			}
			verifySearch(allResponse);
			verifyFt(allResponse);
			CompareValuesUtility.setupResult(offerId, true);
		}catch(Throwable e){
			System.out.println("Check this id :"+ offerId);
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	private void verifyCPC(Offer gbOffer, String offerId) {
		offerCommon = new OfferCommons(gbOffer);

		compareValues("Id", offerId,gbOffer.getId());
		compareValues("Parent", parentId, gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getParentId());
		compareValues("Name", TestUtils.plainEncodeHTML(commonItems.getTitle().trim()), gbOffer.getName());

		//offerCommon.commonVerifications(offerId, parentId, commonItems.getTitle(),false);
		//commenting ssin and uid check
		//offerCommon.verifyIdentity(ssin, uid);
		offerCommon.verifyClassifications(bSingleProductOffer, programType);
		offerCommon.verifyBrandModel(cpcNode.getBrand()==null?null:cpcNode.getBrand().getName(), cpcNode.getModelNumber());

		verifyTaxonomy(gbOffer);

		compareValues("MarketPlace",programType, gbOffer.getMarketplace().getProgramType(),"ProgramType");
		verifySeller(gbOffer.getMarketplace());

		verifyAltIds(gbOffer.getAltIds());

		compareValues("isDispElg", true, gbOffer.getOperational().getSites().getSears().getIsDispElig());
		verifyNullOrEqual("Legal", commonItems.getMatureContent()==false?null:commonItems.getMatureContent(), gbOffer.getLegal() ==null? null:gbOffer.getLegal().getIsMatureContent(),"isMature");

		verifyMainImg(cpcNode.getImageUrl(),gbOffer.getMainImg());

		verifyCPCAttribs(gbOffer.getMarketplace().getCpc());


	}

	private void verifyCPCAttribs(com.generated.vos.offer.Cpc gbCPC) {

		if(gbCPC == null){
			CompareValuesUtility.logFailed("CPC", "CPC Tag", "Not found");
			return;
		}else{

			CompareValuesUtility.compareAsNumbers("ClickPrice", cpcNode.getCpcPricing().getClickPrices() == null? null:  String.valueOf(cpcNode.getCpcPricing().getClickPrices().getClickPrice()[0].getContent()), String.valueOf(gbCPC.getClickPrice()));

			/*verifyNullOrEqual("CPC",cpcNode.getCpcPricing().getClickPrices() == null? null: cpcNode.getCpcPricing().getClickPrices().getClickPrice()[0].getContent(),
					gbCPC.getClickPrice(),"ClickPrice");*/
			verifyNullOrEqual("CPC",cpcNode.getCpcPricing().getShip()==null? null: cpcNode.getCpcPricing().getShip().getShipPrice().getContent().doubleValue(),
					gbCPC.getShipPrice(),"ShipPrice");
			verifyNullOrEqual("CPC",cpcNode.getImportance()== null?null:cpcNode.getImportance().doubleValue(), gbCPC.getImportance(),"Importance");
			verifyNullOrEqual("CPC",cpcNode.getCpcPricing().getShip()==null?null:cpcNode.getCpcPricing().getShip().getPromotionalText(), gbCPC.getPromoTxt(),"Promotxt");

			verifyNullOrEqual("CPC",cpcNode.getItemUrl(), gbCPC.getItemLink()==null?null:gbCPC.getItemLink().getAttrs().getHref(),"ItemLinkAttrs");
			compareValues("CPC",cpcNode.getClickCaptureUrls().getClickCaptureUrl()[0].getContent(), gbCPC.getClickCaptureLink().getAttrs().getHref(),"ClickCapture");
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	OfferCommons offerCommon ;
	private void verifyOffer(Offer gbOffer, String offerId) 
	{

		offerCommon = new OfferCommons(gbOffer);
		commonItems = commonFields.getCommonItemFieldsGroup();

		compareValues("Id", offerId,gbOffer.getId());
		compareValues("Parent", parentId, gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getParentId());
		compareValues("Name", TestUtils.plainEncodeHTML(commonItems.getTitle().trim()), gbOffer.getName());

		//offerCommon.commonVerifications(offerId, parentId, commonItems.getTitle(),false);
		//offerCommon.verifyIdentity(ssin, uid);
		sModelNumber = commonFields.getModelNumber();
		if(sModelNumber == null)
			isFit = false;
		else
			isFit = true;
		offerCommon.verifyBrandModel(commonFields.getBrand().getName(),sModelNumber );
		offerCommon.verifyClassifications(bSingleProductOffer, bSingleProductOffer?programType: variation.getProgramType().name());

		verifyCompetitiveness(gbOffer.getCmt());

		CompareValuesUtility.verifyNullOrEqual("isDispElg", gbOffer.getOperational().getSites().getSears().getIsOnline(), gbOffer.getOperational().getSites().getSears().getIsDispElig());

		Attributes attrs = commonFields.getAttributes();
		verifyAutomotive(gbOffer, attrs);

		if(commonFields.getMapPriceIndicator()!= null){
			
			if(gbOffer.getPriceDispAttr()==null || gbOffer.getPriceDispAttr().getMapVal() ==null)
				CompareValuesUtility.logFailed("PriceMapVal", commonFields.getMapPriceIndicator().equals(MapPriceIndicatorType.STRICT)?2:1, "Not found in GB");
			else
				compareValues("PriceMapVal", commonFields.getMapPriceIndicator().equals(MapPriceIndicatorType.STRICT)?2:1, GenericUtil.convertToIntFromDouble(gbOffer.getPriceDispAttr().getMapVal()));
		}

		if(bSingleProductOffer)
			shipping = commonFields.getShipping();
		else
			shipping = variantItem.getSpecificFbmsFieldsGroupVariation().getShipping();

		if(gbOffer.getShipping().getWeight()!=null)
			offerCommon.verifyShipping(shipping.getLength(),shipping.getWidth(),shipping.getHeight(), shipping.getWeight());
		

		compareValues("ShippingTaxCode", specificFields.getSaleTaxCode()==null?"89998":specificFields.getSaleTaxCode(), GenericUtil.convertToString(gbOffer.getShipping().getTaxCode()));

		verifyFFM(gbOffer);
		CompareValuesUtility.addNewMultiValuedFields();

		verifyMarketplace(gbOffer.getMarketplace());
		CompareValuesUtility.addNewMultiValuedFields();

		verifyTaxonomy(gbOffer);

		verifyAltIds(gbOffer.getAltIds());

		verifyCondition(gbOffer.getCondition());

		verifyImages(gbOffer.getMainImg(), gbOffer.getSwatchImg());

		verifyLegal(gbOffer.getLegal());

		verifyGrocery(gbOffer.getGrocery());

		/*Gson gson = new Gson();
		gson.toJson(gbOffer.getDispTags());*/

		verifyDispTags(gbOffer.getDispTags());

		if(!bSingleProductOffer && variantItem.getVariantAttributes()!=null)
			verifyDefiningAttrs(variantItem.getVariantAttributes().getVariantAttribute(),gbOffer.getDefiningAttrs());

	}

	/**
	 * Verifies the automotive section in content if automotive attributes are present
	 * @param offer
	 * @param attrs
	 */
	private void verifyAutomotive(Offer offer, Attributes attrs){
		if(attrs!=null)
		{
			String brandCodeId = null;
			Attribute[] actAttrs = attrs.getAttribute();
			Classifications classifications = offer.getClassifications();
			for (Attribute attribute : actAttrs) {
				String attributeId = attribute.getItemAttributeGroup().getAttributeId().toString();
				if(attributeId.equals("873910")){
					brandCodeId = attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree();
					isBrandCodeFound=true;
				}
				if(attributeId.equals("1035210")){
					switch(attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId().toString()){
					case "2509410": case "92":{
						CompareValuesUtility.verifyNull("IsFitmentReq",classifications==null?null:classifications.getIsFitmentRequired());
						break;
					}

					case "2509310":{
						if(isFit && isBrandCodeFound == null){
							isBrandCodeFound = commonUtils.isBrandCodeIdFound(attrs);
							isFit = commonUtils.fitmentValidation(brandCodeId,sModelNumber );
						}
						//If model number and brand both are present 
						if(isFit  && isBrandCodeFound){
							isFit = commonUtils.fitmentValidation(brandCodeId,sModelNumber );
						}
						if(!isFit)
							isFit = null;

						CompareValuesUtility.verifyNullOrEqual("IsFitmentReq",isFit,classifications==null?null:classifications.getIsFitmentRequired());
						break;
					}
					}
					break;
				}

			}//End of checking all attributes	
		}
	}

	private void verifyDispTags(DispTags dispTags) {

		Flags xmlFlags = commonFields.getFlags();
		/*	if(!xmlFlags.getGoodHouseKeepingApproved() && !xmlFlags.getGiftMessageEligible()){
			CompareValuesUtility.verifyNull("DispTags",dispTags);
			return;
		}*/

		if(!xmlFlags.getGoodHouseKeepingApproved())
		{
			CompareValuesUtility.verifyNullOrFalse("DispTags", xmlFlags.getGoodHouseKeepingApproved(), dispTags==null?null:dispTags.getIsGhkApproved(),"GHK");
		}
		else
		{
			CompareValuesUtility.compareValues("DispTags", xmlFlags.getGoodHouseKeepingApproved(), dispTags==null?null:dispTags.getIsGhkApproved(),"GHK");
		}

		if( !xmlFlags.getGiftMessageEligible())
		{
			CompareValuesUtility.verifyNullOrFalse("DispTags", xmlFlags.getGiftMessageEligible(), dispTags==null?null:dispTags.getIsGiftMsgElig(),"GiftMsg");
		}
		else
		{
			CompareValuesUtility.compareValues("DispTags", xmlFlags.getGiftMessageEligible(), dispTags==null?null:dispTags.getIsGiftMsgElig(),"GiftMsg");
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
		//		verifyNullOrEqual("DispTags", xmlFlags.getGiftMessageEligible(), dispTags.getIsGiftMsgElig(),"GiftMsg");
	}

	private void verifyGrocery(Grocery grocery) {


	}

	//	00000000000000010186000000000021851-sizeP
	private void verifyLegal(Legal legal) {

		Flags xmlFlags = commonFields.getFlags();

		if(!xmlFlags.getCaliforniaEmissions() && !xmlFlags.getGiftMessageEligible() && !xmlFlags.getGoodHouseKeepingApproved()
				&& !xmlFlags.getHazardousMaterial() && !xmlFlags.getNoWarning() && !xmlFlags.getSafetyWarningOther()
				&& !xmlFlags.getChokingHazards().getBalloons() && !xmlFlags.getChokingHazards().getContainsMarble()
				&& !xmlFlags.getChokingHazards().getContainsSmallBall() && !xmlFlags.getChokingHazards().getOther()
				&& !xmlFlags.getChokingHazards().getSmallBall() && !xmlFlags.getChokingHazards().getSmallParts()
				&& (shipping.getRestrictions()==null)){
			CompareValuesUtility.verifyNull("Legal", legal);
			return;
		}


		verifyNullOrEqual("Legal", xmlFlags.getHazardousMaterial()?"true":null, legal.getHazmatStorageCd(),"HazmatStrgCd:");
		CompareValuesUtility.compareValues("Legal", xmlFlags.getCaliforniaEmissions(),
				legal.getIsCaEmmision(),false,true,"isCAEmsn?");
		CompareValuesUtility.compareValues("Legal", xmlFlags.getNoWarning(), legal.getIsNoWarning(),
				false, true,"isNoWarning?");
		CompareValuesUtility.compareValues("Legal", xmlFlags.getSafetyWarningOther(),
				legal.getSafetyWarnings(),false,true,"SafetyWarn");
		CompareValuesUtility.compareValues("Legal", specificFields.getUsDotShipType(),
				legal.getUsDotType(),false,true,"USDotType");
		CompareValuesUtility.compareValues("Legal", commonItems.getMatureContent(),
				legal.getIsMatureContent(),false,true,"isMature?");

		if(shipping.getRestrictions() != null){
			String exp = "["+shipping.getRestrictions()+"]";
			exp = exp.replaceAll("\\s", "").trim();
			String act = legal.getLimitedGeos().toString().replaceAll("\\s", "").trim();
			compareValues("Legal",exp, act);
		}
		CompareValuesUtility.addNewMultiValuedFields();
		if(xmlFlags.getChokingHazards().getContainsMarble())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Marble",legal.getChokingHazards());

		if(xmlFlags.getChokingHazards().getContainsSmallBall())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Small Balls",legal.getChokingHazards());

		if(xmlFlags.getChokingHazards().getBalloons())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Balloons",legal.getChokingHazards());
		if(xmlFlags.getChokingHazards().getSmallBall())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Small Balls",legal.getChokingHazards());
		if(xmlFlags.getChokingHazards().getSmallParts())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Small Parts",legal.getChokingHazards());

		if(xmlFlags.getChokingHazards().getOther())
			CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Other",legal.getChokingHazards());
		CompareValuesUtility.addNewMultiValuedFields();
	}


	private void verifyCompetitiveness(String offerCmt) {

		CompetitivenessType cmt;
		if(programType.equals(DSS)){
			if(bSingleProductOffer)
				cmt = specificFields.getSpecificFbmsFieldsGroupChoice().getDssPricing().getCompetitiveness();
			else
				cmt = variantItem.getSpecificFbmsFieldsGroupVariation().getSpecificFbmsFieldsGroupVariationChoice().getDssPricing().getCompetitiveness();
		}
		else{
			if(bSingleProductOffer)
				cmt = specificFields.getSpecificFbmsFieldsGroupChoice().getPricing().getCompetitiveness();
			else
				cmt = variantItem.getSpecificFbmsFieldsGroupVariation().getSpecificFbmsFieldsGroupVariationChoice().getPricing().getCompetitiveness();
		}

		String xmlcmt =  "" ;
		if(cmt!=null){
			switch(cmt){
			case NON_COMPARED:{
				xmlcmt = "0";
				break;
			}
			case NEEDS_ATTENTION:{
				xmlcmt = "3";
				break;
			}
			case MARGINALLY_COMPETITIVE:{
				xmlcmt = "2";
				break;
			}
			case MOST_COMPETITIVE:{
				xmlcmt = "1";
				break;
			}
			}
			compareValues("cmt",xmlcmt , offerCmt);
		}

		else
			verifyNullOrEqual("cmt", null, offerCmt);
	}

	/*private void verifyDefiningAttrs(	List<DefiningAttr> definingAttrs) {

		VariantAttribute[] variantAttributes =    variantItem.getVariantAttributes().getVariantAttribute();
		for(VariantAttribute var  : variantAttributes){
			ItemAttributeGroup varAttribute = var.getItemAttributeGroup();
			boolean bFound = false;
			for(DefiningAttr gbDefAttr : definingAttrs){
				if(String.valueOf(varAttribute.getAttributeId()).equals(gbDefAttr.getAttr().getId())){
					bFound=true;
					compareValues("DefAttrId", String.valueOf(varAttribute.getAttributeId()), gbDefAttr.getAttr().getId());
					compareValues("DefAttrValueId", String.valueOf(varAttribute.getItemAttributeGroupChoice().getAttributeValueId()),
							gbDefAttr.getVal().getId());

					List<String> names = fetchAttributeData(varAttribute.getAttributeId(), varAttribute.getItemAttributeGroupChoice().getAttributeValueId(),
							commonItems.getItemClassId());


					compareValues("DefAttrName", names.get(0), gbDefAttr.getAttr().getName());
					compareValues("DefAttrSeq", names.get(1), gbDefAttr.getAttr().getSeq());
					compareValues("DefAttrType", var.getAttributeType(), gbDefAttr.getAttr().getType());
					compareValues("DefAttrValName", varAttribute.getTrademarkText()==null?names.get(2): varAttribute.getTrademarkText(), gbDefAttr.getVal().getName());
					compareValues("DefAttrValFamily", names.get(2),gbDefAttr.getVal().getFamilyName());
					compareValues("DefAValSeq", names.get(3), gbDefAttr.getVal().getSeq());
					break;
				}
			}
			if(!bFound){
				logFailed("DefAttrId",varAttribute.getAttributeId(),"Not found");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}*/

	private void verifyDefiningAttrs(com.generated.vos.catdelta.VariantAttribute[] variantAttributes,List<DefiningAttr> definingAttrs) 
	{
		String itemClassId = String.valueOf(commonItems.getItemClassId());

		CompareValuesUtility.addNewMultiValuedFields();

		for (com.generated.vos.catdelta.VariantAttribute var : variantAttributes) 
		{
			boolean bFound = false;

			for (DefiningAttr gbDefAttr : definingAttrs) 
			{
				if (String.valueOf(var.getItemAttributeGroup().getAttributeId()).equals(gbDefAttr.getAttr().getId())) 
				{
					Val attrval = gbDefAttr.getVal();

					bFound = true;

					//--------------attribute -------------
					//id,name,seq,type

					AttrVo attrVo = getAttribute(String.valueOf(var.getItemAttributeGroup().getAttributeId()),itemClassId);

					compareValues("DefAttrId", String.valueOf(var.getItemAttributeGroup().getAttributeId()), gbDefAttr.getAttr().getId());

					compareValues("DefAttrType", var.getAttributeType(),gbDefAttr.getAttr().getType());

					if(attrVo==null)
					{
						CompareValuesUtility.addFailedDataFieldForReport("DefAttributeDetailsNotFound", "ItemClass : "+itemClassId+ " Attribute Id : "+String.valueOf(var.getItemAttributeGroup().getAttributeId()));
					}
					else
					{
						compareValues("DefAttrName", attrVo.getName() , gbDefAttr.getAttr().getName());

						compareValues("DefAttrSeq", attrVo.getSeq(), gbDefAttr.getAttr().getSeq().intValue());
					}

					//--------------attribute value-------------
					//id,name,familyname,seq

					AttrValVo attrVal = getAttrVal(String.valueOf(var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()),
							String.valueOf(var.getItemAttributeGroup().getAttributeId()));

					if ( var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree() != null) 
					{
						compareValues("DefAttrValueId", var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getId());

						compareValues("DefAttrValName", var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getName());

						compareValues("DefAttrValFamily", var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree(),
								attrval == null ? null : gbDefAttr.getVal().getFamilyName());

					} 
					else
					{
						compareValues("DefAttrValueId", String.valueOf(var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()),
								attrval == null ? null: gbDefAttr.getVal().getId());


						String tdText = var.getItemAttributeGroup().getTrademarkText();

						String sfinalVal  = tdText;

						if ( var.getItemAttributeGroup().getTrademarkText() != null)
							compareValues("DefAttrValName",	sfinalVal,	attrval == null ? null : gbDefAttr.getVal().getName());
						else
						{
							sfinalVal = attrVal.getName();							
							//System.out.println("================= TD text not available ============== ItemClass : "+itemClassId);
							compareValues("DefAttrValName",	sfinalVal ,
									attrval == null ? null : gbDefAttr.getVal().getName());
						}

						if(attrVal==null)
						{
							CompareValuesUtility.addFailedDataFieldForReport("DefAttributeValueDetailsNotFound"
									, "ItemClass : "+itemClassId+ " Attribute Id : "+String.valueOf(var.getItemAttributeGroup().getAttributeId())
									+" AttrValueId : "+String.valueOf(var.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId()));
						}
						else
						{
							sfinalVal = attrVal.getName();

							compareValues("DefAttrValFamily",	sfinalVal,
									attrval == null ? null : gbDefAttr.getVal()	.getFamilyName());

							compareValues("DefAValSeq",	attrVal.getSeq(), attrval == null ? null
									: gbDefAttr.getVal().getSeq().intValue());
						}
					}

					break;
				}
			}
			if (!bFound) {
				logFailed("DefAttrId", var.getItemAttributeGroup().getAttributeId(), "Not found");
			}
		}

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private AttrValVo getAttrVal(String attributeValId,String sAttrId)
	{
		AttrValVo attrValVo  =new AttrValVo();

		AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attributeValId);

		if(attrValsch==null)
		{
			return null;
		}
		attrValVo.setName(attrValsch.getDisplayName());
		List<AttrId> allAttrIds = attrValsch.getAttrIds();

		boolean found = false;

		for (AttrId attrId : allAttrIds) {

			if(attrId.getAttrId().equals(sAttrId))
			{
				attrValVo.setSeq(attrId.getRank());

				found=true;
				break;

			}
		}

		if(!found)
			return null;


		return attrValVo;
	}
	private AttrVo getAttribute(String attributeId,String itemClassId)
	{
		AttrVo attrVo = new AttrVo();

		String attrResp = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE, attributeId);

		String name = JsonStringParser.getJsonValue(attrResp, "{_blob{attribute{displayName}}}");

		attrVo.setName(name);

		com.generated.vos.hierarchy.Hierarchy masterHierarchy = RestExecutor.getDataById(CollectionValuesVal.ITEM_CLASS_HIERARCHY, itemClassId);

		List<Label> allLabels =masterHierarchy.getAttrs().getLabels();

		for (Label label : allLabels) {

			List<Attr> attrs = label.getAttrs();

			for (Attr attr : attrs) {

				if(attr.getId().equals(attributeId))
				{
					attrVo.setSeq(String.valueOf(attr.getRank().intValue()));
					return attrVo;
				}
			}
		}
		//

		return null;
	}


	class AttrVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		private String id;
		private String name;
		private String seq;
		private String type;
	}

	class AttrValVo
	{
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getFamiliyName() {
			return familiyName;
		}
		public void setFamiliyName(String familiyName) {
			this.familiyName = familiyName;
		}
		private String id;
		private String name;
		private String seq;
		private String familiyName;
	}


	/*private List<String> fetchAttributeData(long attributeId,
			long attributeValueId, long itemClassId) {
		String sQuery = "select att.displaylabel, arel.ATTRIBUTESEQUENCE, aval.STRINGVALUE, aval.SEQUENCE from xattribute att, " +
				"xattrvalue aval, XCATGRPATTRREL arel where att.XATTRIBUTE_ID in (select XATTRIBUTE_ID from XATTRIBUTE where " +
				"FIELD2 = '"+attributeId+"') and aval.XATTRIBUTE_ID = att.XATTRIBUTE_ID and aval.NAME='"+attributeValueId+"' and arel.XATTRIBUTE_ID " +
				"= att.XATTRIBUTE_ID and arel.XCATGRPATTRRELTYPE_ID='VARIATION' "+
				"and arel.CATGROUP_ID in (select catgroup_id from catgroup where MEMBER_ID=7000000000000000101 and identifier='"+itemClassId+"')";

		select att.displaylabel, aval.STRINGVALUE, aval.SEQUENCE, arel.ATTRIBUTESEQUENCE from xattribute att, xattrvalue aval, XCATGRPATTRREL arel
		where att.XATTRIBUTE_ID in (select XATTRIBUTE_ID from XATTRIBUTE where FIELD2 = '362501') and aval.XATTRIBUTE_ID = att.XATTRIBUTE_ID
		and aval.NAME='6091' and arel.XATTRIBUTE_ID = att.XATTRIBUTE_ID and arel.XCATGRPATTRRELTYPE_ID='VARIATION'
		and arel.CATGROUP_ID in (select catgroup_id from catgroup where MEMBER_ID=7000000000000000101 and identifier='1150')
		return DB2Utils.executeQueryMultiColumnSingleRow(sQuery);
	}*/

	private void verifyImages(List<MainImg> mainImg, List<SwatchImg> swatchImg) {

		ImageUrl xmlMainImg = specificFields.getImageUrl();
		verifyMainImg(xmlMainImg, mainImg);

		if (bSingleProductOffer)
			return;
		//Verify swatch image only if one of the variants has attribute type as swatch
		boolean bSwatchAttribFound = false;

		for(VariantAttribute varAttri : variantItem.getVariantAttributes().getVariantAttribute()){
			if(varAttri.getAttributeType().equals(AttributeTypeType.SWATCH)){
				bSwatchAttribFound = true;
				break;
			}
		}

		if(!bSwatchAttribFound)
			return;

		//Only for variant items
		SwatchImageUrl xmlSwatchImage = variantItem.getSwatchImageUrl();
		if(xmlSwatchImage != null){
			if(swatchImg.size() == 0)
				compareValues("SwatchImg", xmlSwatchImage.getUrl(),"Not found");
			else{
				compareValues("SwatchImg", TestUtils.modifyImgURL(xmlSwatchImage.getUrl()),swatchImg.get(0).getSrc(),"SwatchImgURL");
				compareValues("SwatchImg", xmlSwatchImage.getHeight()==null?1000:xmlSwatchImage.getHeight(),GenericUtil.convertToIntFromDouble(swatchImg.get(0).getHeight()),"SwatchHeight");
				compareValues("SwatchImg", xmlSwatchImage.getWidth()==null?1000:xmlSwatchImage.getWidth(),GenericUtil.convertToIntFromDouble(swatchImg.get(0).getWidth()),"SwatchWidth");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}
	}

	private void verifyMainImg(ImageUrl xmlMainImg, List<MainImg> mainImg){
		if(xmlMainImg != null){
			if(mainImg.size() == 0)
				compareValues("MainImg",specificFields.getImageUrl().getUrl() ,"Not found");
			else{
				compareValues("MainImg", TestUtils.modifyImgURL(xmlMainImg.getUrl()),mainImg.get(0).getSrc(),"Src");
				compareValues("MainImg", xmlMainImg.getHeight()==null?1000:xmlMainImg.getHeight(), GenericUtil.convertToIntFromDouble(mainImg.get(0).getHeight()),"Height");
				compareValues("MainImg", xmlMainImg.getWidth()==null?1000:xmlMainImg.getWidth(),GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()),"Width");
				CompareValuesUtility.addNewMultiValuedFields();
			}

		}
	}


	private void verifyCondition(Condition condition) {

		if(specificFields.getItemCondition() != null){
			if(condition == null){
				logFailed("Condition", specificFields.getItemCondition().getCondition(),"Condition is null");
				return;
			}
			//			compareValues("Condition",specificFields.getItemCondition().getCondition().name().equalsIgnoreCase(condition.getStatus()),"Status");
			CompareValuesUtility.verifyTrue(specificFields.getItemCondition().getCondition().name().equalsIgnoreCase(condition.getStatus()),
					"Condition", "Status-"+specificFields.getItemCondition().getCondition().name(), condition.getStatus());
			compareValues("Condition",specificFields.getItemCondition().getConditionComments(), condition.getComments(),"Comments");
			CompareValuesUtility.addNewMultiValuedFields();
			compareValues("CondImg",specificFields.getItemCondition().getConditionSpecificImageUrl().getUrl(), condition.getImg().getSrc(),"Src");
			compareValues("CondImg",specificFields.getItemCondition().getConditionSpecificImageUrl().getWidth().intValue(),
					condition.getImg().getWidth().intValue(),"Width");
			compareValues("CondImg",specificFields.getItemCondition().getConditionSpecificImageUrl().getHeight(), condition.getImg().getHeight().intValue(),"Height");
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	private void verifyAltIds( AltIds altIds) {

		compareValues("AltIds", spinId,altIds.getSpinId(),"SpinId");
		if(programType.equals(CPC)){
			verifyNullOrEqual("AltIds", cpcNode.getUpc(),altIds.getUpc(),"UPC");
		}
		else{
			verifyNullOrEqual("AltIds", specificFields.getUpc(),altIds.getUpc(),"UPC");
			compareValues("AltIds", specificFields.getSellerProductId(),altIds.getVendorStockNo(),"VendorStockNo");
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	private void verifyMarketplace(Marketplace gbOffer) {

		verifyNullOrEqual("MarketPlace",confScore==null?null:Double.parseDouble(confScore), gbOffer.getCatConfScore(),"ConfScore");
		verifyNullOrEqual("MarketPlace",commonFields.getSywRedemptionEligible(), gbOffer.getSywRdmElig(),"SYWRedemp");
		compareValues("MarketPlace",programType, gbOffer.getProgramType(),"ProgramType");
		verifyNullOrEqual("MarketPlace",commonFields.getCommissionRates()==null?null:commonFields.getCommissionRates().getDefaultCommissionRate(),gbOffer.getCommission()==null?null:gbOffer.getCommission().getDefaultRate(),"DefCommRate");

		CompareValuesUtility.addNewMultiValuedFields();

		if(commonFields.getCommissionRates()!=null){
			for(CommissionRate commRate : commonFields.getCommissionRates().getCommissionRate()){
				if(commRate.getSiteId() == 2){
					compareValues("MPCmsnRate",commRate.getContent(),gbOffer.getCommission().getSears()== null?null:gbOffer.getCommission().getSears().getRate(),"Sears");
					continue;
				}
				if(commRate.getSiteId() == 4){
					compareValues("MPCmsnRate",commRate.getContent(),gbOffer.getCommission().getMygofer()== null?null:gbOffer.getCommission().getMygofer().getRate(),"MGofer");
					continue;
				}
			}
	
			CompareValuesUtility.addNewMultiValuedFields();
		}else{
			CompareValuesUtility.verifyNull("MPCmsnRate", gbOffer.getCommission());
		}
		verifySeller(gbOffer);


	}

	private void verifySeller(Marketplace gbMP){
		compareValues("MPSeller",sellerId, GenericUtil.convertToString(gbMP.getSeller().getId()),"Id");
		compareValues("MPSeller",sellerDetails.get(0).get(1), gbMP.getSeller().getName(),"Name");
		if(programType.equals(DSS))
			compareValues("MPSeller",true, gbMP.getSeller().getIsDirectSears(),"IsDirectSears");
	}

	private void verifyTaxonomy(Offer gbOffer) 
	{
		SHCContentCommons commonUtils = new SHCContentCommons();

		if(gbOffer.getTaxonomy() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+commonItems.getItemClassId(), "Taxonomy is null");
			return;
		}else if(gbOffer.getTaxonomy().getMaster() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+commonItems.getItemClassId(), "Taxonomy-master is null");
			return;
		}

		//TODO - master hierarchy
		wcsMigrationCommon.compareMasterhierarchyGB(commonItems.getItemClassId(), gbOffer
				.getTaxonomy().getMaster().getHierarchy());

		//commonUtils.compareMasterhierarchy(commonItems.getItemClassId(), gbOffer.getTaxonomy().getMaster().getHierarchy());

		CompareValuesUtility.addNewMultiValuedFields();

		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for ( Site site : commonItems.getSite()) {

			long lSiteId = site.getId();
			if(lSiteId > 8 )
				return;
			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		if(gbOffer.getTaxonomy().getWeb() == null){
			CompareValuesUtility.logFailed("Taxonomy", "Itemclassid:"+commonItems.getItemClassId(), "Taxonomy-web is null");
			return;
		}

		//commonUtils.compareWebhierarchy(mpSiteHiearachies, gbOffer.getTaxonomy().getWeb());
		//boolean isCrossFormatted = commonUtils.isCrossFormattedItem( prodContent, siteToTest, singleProductOffer, varProdOffer, bSingleProductOffer);

		if(!(mpSiteHiearachies.size() == 0))
			commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb()
					,"Sears",false);

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFFM(Offer gbOffer) {
		String sDunsNo = null;
		String warehouseLocations = null;
		String channel = "VD";
		if(programType.equals(FBS)){
			channel = "TW";

		}

		//To be verified by operational load
		compareValues("FFMChannel", channel, gbOffer.getFfm().getChannel());
		//		compareValues("FFMIsShipEli", true, gbOffer.getFfm().getIsShipElig());
		if(specificFields.getShipToStoreEligibility() != null && specificFields.getShipToStoreEligibility()){
			CompareValuesUtility.verifyNullOrEqual("FFMIsSTSEli", specificFields.getShipToStoreEligibility(), gbOffer.getFfm().getIsSTSElig());
			compareValues("FFMSTSChannel", "CVDS", gbOffer.getFfm().getSTSChannel());
		}

		if(commonFields.getFlags() != null && commonFields.getFlags().getWebExclusive() != false)
			compareValues("isWebExclusive", true, gbOffer.getFfm().getIsWebExcl());
		else
			CompareValuesUtility.verifyNull("isWebExclusive", gbOffer.getFfm().getIsWebExcl());

		if (programType.equals(FBM))
			sDunsNo = sellerDetails.get(0)==null?null:sellerDetails.get(0).get(0);
		else if (programType.equals(DSS))
			sDunsNo = sellerDetails.get(2)==null?null:sellerDetails.get(2).get(0);
		else
			sDunsNo = sellerDetails.get(1)==null?null:sellerDetails.get(1).get(0);

		String sSellerName = sellerDetails.get(0)==null?null:sellerDetails.get(0).get(1);

		compareValues("FFMVndDunsNo", sDunsNo, gbOffer.getFfm().getVendorDunsNo());
		//		compareValues("wrhLcn", sDunsNo, gbOffer.getFfm().getWrhsLcn());
		if (programType.equals(DSS))
			compareValues("FFMSoldBy", "sears", gbOffer.getFfm().getSoldBy());
		else
			compareValues("FFMSoldBy", sSellerName, gbOffer.getFfm().getSoldBy());

		if(programType.equals(FBS))
			compareValues("FFMBy", "sears", gbOffer.getFfm().getFulfilledBy());
		else
			compareValues("FFMBy", sSellerName, gbOffer.getFfm().getFulfilledBy());

		if(programType.equals(FBS))
			warehouseLocations = "["+sellerDetails.get(1).get(2).replace("@D@", ", ")+"]";
		else
			warehouseLocations = "["+sDunsNo+"]";

		compareValues("WrhsLocations", warehouseLocations, gbOffer.getFfm().getWrhsLcns());
	}

	private void verifySearch(APIResponse<Offer> allResponse){
		//		TestUtils.replacesSPecialCharsFromURL(commonFields.getModelNumber());
		if(programType.equals(CPC)){
			verifyNullOrEqual("Search",cpcNode.getModelNumber()==null?null:
				cpcNode.getModelNumber().replaceAll("[^\\w]", "").replaceAll("_", "").toUpperCase(),
				allResponse.getSearchFieldValue("model_no"),"Model_no");
			verifyNullOrEqual("Search",cpcNode.getUpc(),allResponse.getSearchFieldValue("upc"),"Upc");
		}else{
			CompareValuesUtility.verifyNullOrEqual("Search",commonFields.getModelNumber()==null?
					commonFields.getModelNumber():commonFields.getModelNumber().replaceAll("[^\\w]", "").replaceAll("_", "").toUpperCase(),
					allResponse.getSearchFieldValue("model_no"),"Model_no");
			verifyNullOrEqual("Search",specificFields.getUpc(),allResponse.getSearchFieldValue("upc"),"Upc");
		}
		compareValues("Search",parentId,allResponse.getSearchFieldValue("parentId"),"ParentId");
		//	CompareValuesUtility.verifyNullOrEqual("Search",ssin,ssin==null?null:allResponse.getSearchFieldValue("ssin"),"SSIN");
		//	CompareValuesUtility.verifyNullOrEqual("Search",uid,uid==null?null:allResponse.getSearchFieldValue("uid"),"UID");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFt(APIResponse<Offer> allResponse){

		compareValues("Ft",bSingleProductOffer?"NV":"V",allResponse.getFtFieldValue("offerType"),"OfferType");
		compareValues("Ft",sellerId,allResponse.getFtFieldValue("sellerId"),"SellerId");
		compareValues("Ft",programType,allResponse.getFtFieldValue("pgrmType"),"pgrmType");

	}
}
