package com.shi.content.storepricing;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.content.Content;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.OfferSchema;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;


public class KmartDoorBusterVerification implements Runnable {

	static Map<String, Boolean> storeIds = new HashMap<String, Boolean>();
	String finalId=null;
	List<String> singlePricingBlob;
	int currentCount;
	
	public KmartDoorBusterVerification(List<String> pricingDataForProduct, int currentC){
		this.singlePricingBlob = pricingDataForProduct;
		this.currentCount = currentC;
	}
	


	public void run() {
		long l1 = System.currentTimeMillis();
        
		// Fill code here
		Offer offerPartGB;
        
        String[] singlePriceData = singlePricingBlob.get(0).split("\\|");
        String Ksn = singlePriceData[0];
        List<String> divPricingBlob=new ArrayList<String>();
		List<String> skuPricingBlob=new ArrayList<String>();
		ShcPricing storePricingGB;
		Content contentPartGB =null;
		Offer offerPartGB1=null;
		
		for (String s : singlePricingBlob) {
			String[] afterSplit = s.split("\\|");
			String ksn=afterSplit[0];
			String promoprice=afterSplit[1];
			String regprice=afterSplit[2];
			String promoendate=afterSplit[3];
			System.out.println(ksn+promoprice+regprice+promoendate);
			if(ksn!=null){
				List<String> pIds=new ArrayList<String>();   //to get list of products under the upc.
				pIds=RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"ksn",ksn);
				System.out.println(pIds);
				if(pIds.isEmpty()==true){
					System.out.println("No records found"+ksn);
					return;
				}else{
					for(int i=0;i<pIds.size();i++){
						OfferSchema offerObjs = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_SCHEMA, pIds.get(i));
						
						if(offerObjs.getFt().getPgrmType().equals("Kmart")){
							URI pricingURI = RestAPIs.getByIdURI(LoadProperties.OTHERGBBOX, CollectionValuesVal.SHCPRICING, "7840-"+offerObjs.getId());
							System.out.println(pricingURI);
							 storePricingGB = RestExecutor.getDataById(pricingURI, CollectionValuesVal.SHCPRICING);
							 System.out.println(storePricingGB.getP().getA().get(0).getIp());
						}
							System.out.println(offerObjs.getFt().getPgrmType());
						
						
					}
				}
			}
		
			    

					 
		}
	}
}
