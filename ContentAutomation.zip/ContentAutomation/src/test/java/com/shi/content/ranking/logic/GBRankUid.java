package com.shi.content.ranking.logic;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.shc.autocontent.utils.JodaDateTimeUtility;

import org.apache.commons.collections.comparators.ComparatorChain;
import org.apache.commons.lang.StringUtils;

import com.generated.vos.offer.OfferSchema;
import com.generated.vos.rankingauto.RankingResponseFull;
import com.generated.vos.rankingmongo.offer.Kmart;
import com.generated.vos.rankingmongo.offer.Sear;
import com.generated.vos.seller.NonContinentalSurcharge_;
import com.generated.vos.seller.NonContinentalSurcharge__;
import com.generated.vos.seller.OrderAmountChargeRange;
import com.generated.vos.seller.OrderAmountChargeRange_;
import com.generated.vos.seller.WeightRange;
import com.generated.vos.seller.WeightRange_;
import com.generated.vos.seller.WeightRange__;
import com.generated.vos.seller.WeightRange___;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.restutils.WebserviceUtil;
import com.shi.content.ranking.RankingTest;
import com.shi.content.ranking.vos.Item;
import com.shi.content.ranking.vos.ItemAvailabilityServiceSchema;
import com.shi.content.ranking.vos.PriceGridSchema;
import com.shi.content.ranking.vos.SellerSchema;
import com.shi.content.ranking.vos.SellerdtlsVO;
import com.shi.content.ranking.vos.ShipMode;
import com.shi.content.ranking.vos.ShippingResponseSchema;
import com.shi.content.ranking.vos.pricing.PricingSchema;

public class GBRankUid {
	WebserviceUtil gb= new WebserviceUtil();
	Gson gson = new Gson();
	final float BONUS_POINTS_VALUE = 0.0004f;
	public  ComparatorChain chain = null;
	public GBRankUid() {
		super();

		this.chain =  new ComparatorChain();

		//chain.addComparator(new ItemWebStatusComparator(true));
		
		chain.addComparator(new ItemStoreComparator());
		
		chain.addComparator(new ItemStockComparator(true));
		
		chain.addComparator(new ItemSellerTierComparator());
		
		chain.addComparator(new ItemConditionComparator());

		//chain.addComparator(new ItemSpuComparator(true));

		//chain.addComparator(new ItemSresComparator(true));

		chain.addComparator(new ItemCatConfComparator());

		chain.addComparator(new ItemPriceComparator());

		chain.addComparator(new TrustedSellerComparator(true));

		//chain.addComparator(new ItemSoptComparator());

		chain.addComparator(new ItemTransitDaysComparator());
	}

	@SuppressWarnings("unchecked")
	public List<GBRankBean> RankGroup(String uid, RankingResponseFull rankingResponse) throws URISyntaxException
	{
		List<String>partnumbers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"uid",uid);
		
		// Input from Madhavi: if in a group more than 100 items are present then only first 100 items will be evaluated for rankng.
		if(partnumbers.size()>100)
		{	
			partnumbers.subList(100, partnumbers.size()).clear();
		}
		
		//Remove offers with price error
		List<String> errorOffer = rankingResponse.getGroups().get(0).getErrors().getPrice();
		for (String partnumber : errorOffer)
		{
			if(partnumbers.contains(partnumber))
			{
				partnumbers.remove(partnumber);
				CompareValuesUtility.logPassed("Price Error",partnumber, partnumber);
			}
			else
			{
				CompareValuesUtility.logFailed("Price Error",partnumber, "");
			}
			
		}
		
		/* ------------ Logic to filter out sears and kmart site level offers -------------------- */

		if(!partnumbers.isEmpty())
		{
			List<GBRankBean> uidList = new ArrayList<GBRankBean>();

			for(String Pno : partnumbers){
				String PartNumber= Pno.toString().replaceAll("\"", "");
				GBRankBean rankItem=getRankParams(PartNumber, rankingResponse);
				if(rankItem!=null)
				{

					if(rankItem.getSites().contains(LoadProperties.STORESITE.toLowerCase()))
					{
						uidList.add(rankItem);
					}
					//removed this check as discussed
					/*if(LoadProperties.STORESITE.equalsIgnoreCase("Kmart"))
					{
						//sold-by KMART or any-cross-format = KMART
						if(rankItem.getSoldBy().equalsIgnoreCase("Kmart")   || rankItem.isCrossFormatted())
						{
							uidList.add(rankItem);
						}
					}
					else
					{
						//sold-by SEARS or MP or any-cross-format = SEARS

						if(rankItem.getSoldBy().equalsIgnoreCase("Kmart"))
						{
							if(	rankItem.isCrossFormatted())
								uidList.add(rankItem);
						}
						else
						{
							uidList.add(rankItem);
						}
					}*/
				}
			}

			Collections.sort(uidList,chain);
			int rank = 1;
			for(int i=0;i<uidList.size();i++){
				//System.out.println("Offer : "+ uidList.get(i).getPartnumber() + " WebStatus : " + uidList.get(i).getWebStatus());
				if(uidList.get(i).getWebStatus()){
					uidList.get(i).setRank(rank);
					rank++;
					//System.out.println(uidList.get(i).getPartnumber()+"\t\t"+ uidList.get(i).getWebStatus()+"\t\t"+ uidList.get(i).getItemCondition()+"\t"+uidList.get(i).getInstock()+"\t"+ uidList.get(i).getConfidenceScore()+ "\t"+uidList.get(i).getStoreName()+"\t" + uidList.get(i).getPrice()+"\t"+uidList.get(i).getTrustedSeller()+"\t"+ uidList.get(i).getSopt()+"\t"+uidList.get(i).getRank());
				}else{
					uidList.get(i).setRank(-1);
					//System.out.println(uidList.get(i).getPartnumber()+"\t\t"+ uidList.get(i).getWebStatus()+"\t\t"+uidList.get(i).getItemCondition()+"\t"+uidList.get(i).getInstock()+"\t"+	uidList.get(i).getConfidenceScore()+ "\t"+uidList.get(i).getStoreName()+"\t" +	 uidList.get(i).getPrice()+"\t"+uidList.get(i).getTrustedSeller()+"\t"+	uidList.get(i).getSopt()+"\t"+uidList.get(i).getRank());
				}

			}
			return uidList;
		}
		return null;
	}

	public GBRankBean getRankParams(String PartNumber, RankingResponseFull rankingResponse) throws URISyntaxException{
		GBRankBean rankObj= new GBRankBean();
		rankObj.setPartnumber(PartNumber);
		Float defaultConfScore=(float) 1;
		String offerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER, PartNumber);
		//gb.processGet(new URI(PropReader.getproperty("gb.get.offer")+ PartNumber));
		offerResponse=offerResponse.substring(1, offerResponse.length()-1);
		OfferSchema offerObj= gson.fromJson(offerResponse, OfferSchema.class);
		String itemType=offerObj.getFt().getPgrmType().toString().toUpperCase();

		String ksn = offerObj.getBlob().getOffer().getAltIds()==null?"":
			offerObj.getBlob().getOffer().getAltIds().getKsn()==null?"":offerObj.getBlob().getOffer().getAltIds().getKsn();

		Item iasItem = null;
		int sopt = 0;
		int transitDays = 0;
		int totalTrasitDays = 0;
		float itemPrice = 0;
		double shipPrice = 0;
		String sellerTier = "REGULAR";
		Boolean spuElig = false;
		Boolean sresElig = false;
		Boolean isSpuOrSres = false;
		float bonusPoints = 0;
		bonusPoints = getBonusPoints(rankingResponse,PartNumber);
		float itemPriceAfterBonusPointsDeduction = 0;
		rankObj.setSites(offerObj.getBlob().getOffer().getSites());
		switch(itemType)
		{
		case "SEARS" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			//rankObj.setInstock(getSearsItemAvailaibility(offerObj));
			iasItem = getItemAvailability(PartNumber, offerObj.getFt().getPgrmType().toString(), LoadProperties.ZIPCODE);
			rankObj.setInstock(iasItem.getAvailable());
			rankObj.setConfidenceScore(defaultConfScore);
			rankObj.setStoreName("Sears");
			rankObj.setStorePriority(0);
			spuElig = (offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			sresElig = (offerObj.getBlob().getOffer().getFfm().getIsSResElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSResElig();
			isSpuOrSres = spuElig||sresElig;
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);
			//			if (Boolean.valueOf(LoadProperties.LOCALADFLAG))
			//			{
			rankObj.setPriceType(getSearsPriceType(PartNumber,"Sears"));
			//			}
			itemPrice = getPrice(PartNumber,"Sears");
			itemPriceAfterBonusPointsDeduction = itemPrice - (bonusPoints * BONUS_POINTS_VALUE);
			shipPrice = getShipPrice(PartNumber, isSpuOrSres, itemPrice,"Sears");
			rankObj.setPrice((float) (itemPriceAfterBonusPointsDeduction + shipPrice));
			rankObj.setShipPrice(isSpuOrSres?null:shipPrice);

			rankObj.setTrustedSeller(true);
			sopt = getSoptDays(offerObj);
			rankObj.setSopt(sopt);
			transitDays = isSpuOrSres?0:(Integer.valueOf(iasItem.getTransitDays()==null?"2147483647":iasItem.getTransitDays()));
			rankObj.setTransitDays(transitDays);
			totalTrasitDays = ((sopt==2147483647) || (transitDays==2147483647))?2147483647:(sopt + transitDays);
			rankObj.setTotalTransitDays(totalTrasitDays);
			rankObj.setSellerTier("PLATINUM");
			rankObj.setSellerTierValue(1);
			rankObj.setMapViolation(getSearsMapViolation(PartNumber,"Sears"));
			rankObj.setSellerStoreUrl(null);
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(bonusPoints);
			}

			break;
		}
		/*----------------------------------------------------------------------------------------------*/
		case "KMART" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			iasItem = getItemAvailabilityKmart(PartNumber, offerObj.getFt().getPgrmType().toString(), LoadProperties.ZIPCODE,ksn);
			rankObj.setInstock(iasItem.getAvailable());
			rankObj.setConfidenceScore(defaultConfScore);
			rankObj.setStoreName("Kmart");
			rankObj.setStorePriority(0);
			spuElig = (offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			sresElig = (offerObj.getBlob().getOffer().getFfm().getIsSResElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSResElig();
			isSpuOrSres = spuElig||sresElig;
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);
			rankObj.setPriceType(getSearsPriceType(PartNumber,"Kmart"));
			itemPrice = getPrice(PartNumber,"Kmart");
			
			itemPriceAfterBonusPointsDeduction = itemPrice-(bonusPoints*BONUS_POINTS_VALUE);
			
			shipPrice = getShipPrice(PartNumber, isSpuOrSres, itemPrice,"Kmart");
			rankObj.setPrice((float) (itemPriceAfterBonusPointsDeduction + shipPrice));
			rankObj.setShipPrice(isSpuOrSres?null:shipPrice);

			rankObj.setTrustedSeller(true);
			sopt = getSoptDays(offerObj);
			rankObj.setSopt(sopt);
			transitDays = isSpuOrSres?0:(Integer.valueOf(iasItem.getTransitDays()==null?"2147483647":iasItem.getTransitDays()));
			rankObj.setTransitDays(transitDays);
			totalTrasitDays = ((sopt==2147483647) || (transitDays==2147483647))?2147483647:(sopt + transitDays);
			rankObj.setTotalTransitDays(totalTrasitDays);
			rankObj.setSellerTier("PLATINUM");
			rankObj.setSellerTierValue(1);
			rankObj.setMapViolation(getSearsMapViolation(PartNumber,"Kmart"));
			rankObj.setSellerStoreUrl(null);
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(bonusPoints);
			}
			break;
		}

		/*----------------------------------------------------------------------------------------------*/
		case "FBM" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			//rankObj.setInstock(getMpItemAvailaibility(offerObj));
			iasItem = getItemAvailability(PartNumber, offerObj.getFt().getPgrmType().toString(), LoadProperties.ZIPCODE);
			rankObj.setInstock(iasItem.getAvailable());
			rankObj.setConfidenceScore(getItemConfidenceScore(offerObj));
			rankObj.setStoreName("Fbm");
			rankObj.setStorePriority(0);
			spuElig = (offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);

			if(RankingTest.serialAcceesFlag)
			{
				itemPrice = getMpPrice(offerObj);
				rankObj.setPriceType(null);
				rankObj.setMapViolation(false);
			}
			else
			{
				itemPrice = getPrice(PartNumber,LoadProperties.STORESITE);
				rankObj.setPriceType(getSearsPriceType(PartNumber,LoadProperties.STORESITE));
				rankObj.setMapViolation(getSearsMapViolation(PartNumber,"FBM"));
			}
			
			itemPriceAfterBonusPointsDeduction = itemPrice-(bonusPoints*BONUS_POINTS_VALUE);
			
			shipPrice = getMpShipPrice(offerObj, itemPrice);
			rankObj.setPrice((float) (itemPriceAfterBonusPointsDeduction + shipPrice));
			rankObj.setShipPrice(shipPrice);

			rankObj.setTrustedSeller(getMPTrustNewFBM(offerObj));
			sopt = getMpSoptDaysNew(offerObj);
			rankObj.setSopt(sopt);
			transitDays = Integer.valueOf(iasItem.getTransitDays()==null? "2147483647" :iasItem.getTransitDays());
			rankObj.setTransitDays(transitDays);
			totalTrasitDays = ((sopt==2147483647) || (transitDays==2147483647))?2147483647:(sopt + transitDays);
			rankObj.setTotalTransitDays(totalTrasitDays);
			sellerTier = getMpSellerTierNew(offerObj);
			rankObj.setSellerTier(sellerTier);
			rankObj.setSellerTierValue(sellerTier.equals("BLACK")?5:1);
			rankObj.setSellerStoreUrl(getMpSellerStrUrlNew(offerObj));
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(getMPBonusPoints(PartNumber));
			}
			break;
		}

		/*----------------------------------------------------------------------------------------------*/
		case "FBS" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			//rankObj.setInstock(getMpItemAvailaibility(offerObj));
			iasItem = getItemAvailability(PartNumber, offerObj.getFt().getPgrmType().toString(), LoadProperties.ZIPCODE);
			rankObj.setInstock(iasItem.getAvailable());
			rankObj.setConfidenceScore(getItemConfidenceScore(offerObj));
			rankObj.setStoreName("Fbs");
			rankObj.setStorePriority(0);
			spuElig = (offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);

			if(RankingTest.serialAcceesFlag)
			{
				itemPrice = getMpPrice(offerObj);
				rankObj.setPriceType(null);
				rankObj.setMapViolation(false);
			}
			else
			{
				itemPrice = getPrice(PartNumber,LoadProperties.STORESITE);
				rankObj.setPriceType(getSearsPriceType(PartNumber,LoadProperties.STORESITE));
				rankObj.setMapViolation(getSearsMapViolation(PartNumber,"FBS"));
			}
			
			itemPriceAfterBonusPointsDeduction = itemPrice-(bonusPoints*BONUS_POINTS_VALUE);
			shipPrice = getMpShipPrice(offerObj, itemPrice);
			rankObj.setPrice((float) (itemPriceAfterBonusPointsDeduction + shipPrice));
			rankObj.setShipPrice(shipPrice);
			rankObj.setTrustedSeller(getMPTrustNewFBS(offerObj));
			sopt = getMpSoptDaysNew(offerObj);
			rankObj.setSopt(sopt);
			transitDays = Integer.valueOf(iasItem.getTransitDays()==null?"2147483647":iasItem.getTransitDays());
			rankObj.setTransitDays(transitDays);
			totalTrasitDays = ((sopt==2147483647) || (transitDays==2147483647))?2147483647:(sopt + transitDays);
			rankObj.setTotalTransitDays(totalTrasitDays);
			sellerTier = getMpSellerTierNew(offerObj);
			rankObj.setSellerTier(sellerTier);
			rankObj.setSellerTierValue(sellerTier.equals("BLACK")?5:1);
			rankObj.setSellerStoreUrl(getMpSellerStrUrlNew(offerObj));
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(getMPBonusPoints(PartNumber));
			}
			break;
		}

		/*----------------------------------------------------------------------------------------------*/
		case "DSS" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			//rankObj.setInstock(getMpItemAvailaibility(offerObj));
			iasItem = getItemAvailability(PartNumber, offerObj.getFt().getPgrmType().toString(), LoadProperties.ZIPCODE);
			rankObj.setInstock(iasItem.getAvailable());
			rankObj.setConfidenceScore(getItemConfidenceScore(offerObj));
			rankObj.setStoreName("DSS");
			rankObj.setStorePriority(0);
			spuElig = (offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);

			if(RankingTest.serialAcceesFlag)
			{
				itemPrice = getMpPrice(offerObj);
				rankObj.setPriceType(null);
				rankObj.setMapViolation(false);
			}
			else
			{
				itemPrice = getPrice(PartNumber,LoadProperties.STORESITE);
				rankObj.setPriceType(getSearsPriceType(PartNumber,LoadProperties.STORESITE));
				rankObj.setMapViolation(getSearsMapViolation(PartNumber,"DSS"));
			}
			
			itemPriceAfterBonusPointsDeduction = itemPrice-(bonusPoints*BONUS_POINTS_VALUE);
			shipPrice = getMpShipPrice(offerObj, itemPrice);
			rankObj.setPrice((float) (itemPriceAfterBonusPointsDeduction + shipPrice));
			rankObj.setShipPrice(shipPrice);
			rankObj.setTrustedSeller(true);
			sopt = getMpSoptDaysNew(offerObj);
			rankObj.setSopt(sopt);
			transitDays = Integer.valueOf(iasItem.getTransitDays()==null?"2147483647":iasItem.getTransitDays());
			rankObj.setTransitDays(transitDays);
			totalTrasitDays = ((sopt==2147483647) || (transitDays==2147483647))?2147483647:(sopt + transitDays);
			rankObj.setTotalTransitDays(totalTrasitDays);
			//sellerTier = getMpSellerTierNew(offerObj);
			//Daffy - DSS item defaulted to PLATINUM
			rankObj.setSellerTier("PLATINUM");
			//rankObj.setSellerTierValue(sellerTier.equals("BLACK")?5:1);
			rankObj.setSellerTierValue(1);
			rankObj.setSellerStoreUrl(getMpSellerStrUrlNew(offerObj));
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(bonusPoints);
			}
			break;
		}

		/*----------------------------------------------------------------------------------------------*/
		case "CPC" :
		{
			if(RankingTest.itemConditionFlag)
			{
				rankObj.setItemCondition(getItemConditionNew(offerObj));
				rankObj.setConditionString(getItemConditionStingNew(offerObj));
				rankObj.setConditionDispName(getItemConditionDispNameNew(offerObj));
			}
			else
			{
				rankObj.setItemCondition(getItemConditionOld(offerObj));
				rankObj.setConditionString(getItemConditionStingOld(offerObj));
			}
			rankObj.setWebStatus(getItemWebStatus(offerObj));
			//rankObj.setInstock(getMpItemAvailaibility(offerObj));
			rankObj.setInstock(true);
			rankObj.setConfidenceScore(getItemConfidenceScore(offerObj));
			rankObj.setStoreName("Cpc");
			rankObj.setStorePriority(3);
			rankObj.setSpuEligible(spuElig);
			rankObj.setSresEligible(sresElig);

			if(RankingTest.serialAcceesFlag)
			{
				itemPrice = getMpPrice(offerObj);
				rankObj.setPriceType(null);
			}
			else
			{
				itemPrice = getPrice(PartNumber,LoadProperties.STORESITE);
				rankObj.setPriceType(getSearsPriceType(PartNumber,LoadProperties.STORESITE));
			}
			
			itemPriceAfterBonusPointsDeduction = itemPrice-(bonusPoints*BONUS_POINTS_VALUE);
			//shipPrice = getMpShipPrice(offerObj, itemPrice);
			rankObj.setPrice(itemPriceAfterBonusPointsDeduction);
			rankObj.setShipPrice(null);

			rankObj.setTrustedSeller(false);
			rankObj.setSopt(null);
			rankObj.setTransitDays(null);
			rankObj.setTotalTransitDays(null);
			sellerTier = getMpSellerTierNew(offerObj);
			rankObj.setSellerTier("REGULAR"); //always retrun regular for CPC
			rankObj.setSellerTierValue(sellerTier.equals("BLACK")?5:1);
			rankObj.setMapViolation(false);
			rankObj.setSellerStoreUrl(getMpSellerStrUrlNew(offerObj));
			if(RankingTest.dbBonusPointsFlag)
			{
					rankObj.setBonusPoints(bonusPoints);
			}
			break;
		}

		default :
			rankObj=null;
			break;
		}

		try {
			rankObj.setSoldBy(offerObj.getBlob().getOffer().getFfm().getSoldBy());
		} catch (Exception e) {
			rankObj.setSoldBy("");
		}

		try {

			if(offerObj.getBlob().getOffer().getSites().contains("sears") && offerObj.getBlob().getOffer().getSites().contains("kmart")  )
			{
				rankObj.setCrossFormatted(true);
				/*------------------Commenting as naresh said ranking not checks taxonomy, it checks on sites and opr tag*/
				/*Sites sites = (offerObj.getBlob().getOffer().getTaxonomy()==null
						|| offerObj.getBlob().getOffer().getTaxonomy().getWeb()==null
						|| offerObj.getBlob().getOffer().getTaxonomy().getWeb().getSites()==null)?null:
							offerObj.getBlob().getOffer().getTaxonomy().getWeb().getSites();

				if(sites!=null)
				{
					List<Hierarchy_> kmartlst = sites.getKmart()==null?null:sites.getKmart().getHierarchies();
					List<Hierarchy_> searslst = sites.getSears()==null?null:sites.getSears().getHierarchies();

					if(kmartlst!=null && !kmartlst.isEmpty() && searslst!=null && !searslst.isEmpty())
					{
						rankObj.setCrossFormatted(true);
					}
				}*/
			}
		} catch (Exception e) {
			rankObj.setSoldBy("");
		}

		return rankObj;
	}

	private float getMPBonusPoints(String partNumber) 
	{
		double bonusPointsInRankingDB = 0.0d;
		float floatBonusPointsInRankingDB = 0.0f;
		Gson gson = new Gson();
		String bonusURI = LoadProperties.BONUSAPI + "/" + partNumber;
		String bonusResponse=RestExecutor.getJSonResponse(bonusURI);
		System.out.println("BonusURI=" + bonusURI);
		System.out.println("bonusResponse=" + bonusResponse);
		
		if(!bonusResponse.equalsIgnoreCase("null") && !bonusResponse.isEmpty() && bonusResponse != null && bonusResponse != "")
		{
			com.generated.vos.rankingmongo.offer.Rankingmongo bonusOfferObj= gson.fromJson(bonusResponse, com.generated.vos.rankingmongo.offer.Rankingmongo.class);
			
			if(bonusOfferObj != null && bonusOfferObj.getSywPoints() != null)
			{
				if(LoadProperties.STORESITE.equalsIgnoreCase("sears"))
				{
					if(bonusOfferObj.getSywPoints().getSears() != null &&
						bonusOfferObj.getSywPoints().getSears().get(0) != null &&
						bonusOfferObj.getSywPoints().getSears().get(0).getStartDt() != null && 
						bonusOfferObj.getSywPoints().getSears().get(0).getEndDt() != null &&
						bonusOfferObj.getSywPoints().getSears().get(0).getPoints() != null)
					{
						List<Sear> lstsywPoints = bonusOfferObj.getSywPoints().getSears();
						long iTemp = 0;

						for(Sear sywPoints : lstsywPoints)
						{
							if(JodaDateTimeUtility.validateDate(JodaDateTimeUtility.convertUnixTSToTZFormat(sywPoints.getStartDt().longValue(),"GMT"), 
									JodaDateTimeUtility.convertUnixTSToTZFormat(sywPoints.getEndDt().longValue(),"GMT")))
							{
								if(iTemp == 0)
								{
									bonusPointsInRankingDB = sywPoints.getPoints();
									floatBonusPointsInRankingDB = (float)bonusPointsInRankingDB;
									iTemp = sywPoints.getStartDt().longValue();
								}
								else if(sywPoints.getStartDt().longValue() > iTemp)
								{
									bonusPointsInRankingDB = sywPoints.getPoints();
									floatBonusPointsInRankingDB = (float)bonusPointsInRankingDB;
									iTemp = sywPoints.getStartDt().longValue();
								}
							}
						}
					}
				}
				else if(LoadProperties.STORESITE.equalsIgnoreCase("kmart"))
				{
					if(bonusOfferObj.getSywPoints().getKmart() != null &&
							bonusOfferObj.getSywPoints().getKmart().get(0) != null &&
							bonusOfferObj.getSywPoints().getKmart().get(0).getStartDt() != null && 
							bonusOfferObj.getSywPoints().getKmart().get(0).getEndDt() != null &&
							bonusOfferObj.getSywPoints().getKmart().get(0).getPoints() != null)
						{
							List<Kmart> lstsywPoints = bonusOfferObj.getSywPoints().getKmart();
							long iTemp = 0;
							for(Kmart sywPoints : lstsywPoints)
							{
								if(JodaDateTimeUtility.validateDate(JodaDateTimeUtility.convertUnixTSToTZFormat(sywPoints.getStartDt().longValue(),"GMT"), 
										JodaDateTimeUtility.convertUnixTSToTZFormat(sywPoints.getEndDt().longValue(),"GMT")))
								{
									if(iTemp == 0)
									{
										bonusPointsInRankingDB = sywPoints.getPoints();
										floatBonusPointsInRankingDB = (float)bonusPointsInRankingDB;
										iTemp = sywPoints.getStartDt().longValue();
									}
									else if(sywPoints.getStartDt().longValue() > iTemp)
									{
										bonusPointsInRankingDB = sywPoints.getPoints();
										floatBonusPointsInRankingDB = (float)bonusPointsInRankingDB;
										iTemp = sywPoints.getStartDt().longValue();
									}
								}
							}
						}
					}
			}
		}
		return floatBonusPointsInRankingDB;
	}
	
//	private float getMPBonusPointsTelluride(String partNumber) 
//	{
//		double bonusPointsInTelluride = 0.0d;
//		float floatBonusPointsInTelluride = 0.0f;
//		Gson gson = new Gson();
//		String bonusURITelluride = LoadProperties.BONUSAPITELLURIDE + "/" + partNumber;
//		String bonusResponseTelluride=RestExecutor.getJSonResponse(bonusURITelluride);
//		System.out.println("bonusURITelluride=" + bonusURITelluride);
//		System.out.println("bonusResponseTelluride=" + bonusResponseTelluride);
//		
//		if(!bonusResponseTelluride.equalsIgnoreCase("[]") && !bonusResponseTelluride.equalsIgnoreCase("null") && 
//				!bonusResponseTelluride.isEmpty() && bonusResponseTelluride != null && bonusResponseTelluride != "")
//		{
//			List<com.generated.vos.rankingmongo.telluride.GetFromTellurideApus> lstBonusOfferObj = 
//					Arrays.asList(gson.fromJson(bonusResponseTelluride, com.generated.vos.rankingmongo.telluride.GetFromTellurideApus[].class));
//			if(!lstBonusOfferObj.isEmpty())
//			{
//				for(com.generated.vos.rankingmongo.telluride.GetFromTellurideApus bonusOfferObj : lstBonusOfferObj)
//				{
//					if(LoadProperties.STORESITE.equalsIgnoreCase("sears") &&
//							bonusOfferObj != null && bonusOfferObj.getSite() != null &&
//							bonusOfferObj.getSite().equalsIgnoreCase("sears") &&
//							bonusOfferObj.getStartTime() != null &&
//							bonusOfferObj.getEndTime() != null)
//					{
//						if(JodaDateTimeUtility.validateDate(JodaDateTimeUtility.convertUnixTSToTZFormat(bonusOfferObj.getStartTime() == null ? 0 :bonusOfferObj.getStartTime().longValue(),"GMT"),
//								JodaDateTimeUtility.convertUnixTSToTZFormat(bonusOfferObj.getEndTime().longValue(),"GMT")))						
//						{
//							bonusPointsInTelluride = bonusOfferObj.getBonusPoints() == null ? 0.0d : bonusOfferObj.getBonusPoints();
//							floatBonusPointsInTelluride = (float)bonusPointsInTelluride;
//						}
//					}
//					else if(LoadProperties.STORESITE.equalsIgnoreCase("kmart") && 
//							bonusOfferObj != null && 
//							bonusOfferObj.getSite().equalsIgnoreCase("kmart") &&
//							bonusOfferObj.getStartTime() != null &&
//							bonusOfferObj.getEndTime() != null)
//					{
//						if(JodaDateTimeUtility.validateDate(JodaDateTimeUtility.convertUnixTSToTZFormat(bonusOfferObj.getStartTime() == null ? 0 : bonusOfferObj.getStartTime().longValue(),"GMT"),
//								JodaDateTimeUtility.convertUnixTSToTZFormat(bonusOfferObj.getEndTime().longValue())))						
//						{
//							bonusPointsInTelluride = bonusOfferObj.getBonusPoints() == null ? 0.0d : bonusOfferObj.getBonusPoints();
//							floatBonusPointsInTelluride = (float)bonusPointsInTelluride;
//						}
//					}
//				}
//			}
//			
//		}
//		return floatBonusPointsInTelluride;
//	}

	public float getBonusPoints(RankingResponseFull rankingResponse, String partNumber) {
		for (int i = 0; i < rankingResponse.getGroups().get(0).getOffers().size(); i++)
		{
			if(partNumber.equalsIgnoreCase(rankingResponse.getGroups().get(0).getOffers().get(i).getId().toString()))
			{
				float bonusPoints= rankingResponse == null ? 0 : 
									rankingResponse.getGroups() == null ? 0 : 
										rankingResponse.getGroups().get(0) == null ? 0 : 
											rankingResponse.getGroups().get(0).getOffers() == null ? 0 :
												rankingResponse.getGroups().get(0).getOffers().get(i) == null ? 0 :
													rankingResponse.getGroups().get(0).getOffers().get(i).getBonusPoints() == null ? 0 :
												Float.parseFloat(rankingResponse.getGroups().get(0).getOffers().get(i).getBonusPoints());
					return bonusPoints;
			}
		}
		return 0;		
	}

	public int getItemConditionNew(OfferSchema offerObj){
		String condition=null;
		if( offerObj != null 
				&& offerObj.getBlob() != null 
				&& (offerObj.getBlob().getOffer()) != null 
				&& (offerObj.getBlob().getOffer().getCondition()!=null) 
				&& (offerObj.getBlob().getOffer().getCondition().getStatus() != null))
		{
				condition=offerObj.getBlob().getOffer().getCondition().getStatus();
				if(condition.equals("NEW"))
				return 1;
				else if(condition.equals("NEW_BLEMISHED"))
					return 2;
				else if(condition.equals("NEW_OTHER"))
					return 3;
				else if(condition.equals("REFURBISHED"))
					return 4;
				else if(condition.equals("REFURBISHED_MANUFACTURER_AUTHORIZED"))
					return 4;
				else if(condition.equals("REFURBISHED_SELLER"))
					return 5;
				else if(condition.equals("USED_LIKE_NEW"))
					return 6;
				else if(condition.equals("USED_VERY_GOOD"))
					return 7;
				else if(condition.equals("USED_GOOD"))
					return 8;
				else if(condition.equals("USED_ACCEPTABLE"))
					return 9;
				else if(condition.equals("USED_POOR"))
					return 10;
		} else
		{
			condition="NEW";
		}
		return 1;
	}
	
	public String getItemConditionStingNew(OfferSchema offerObj){
		String condition=null;
		if( offerObj != null 
				&& offerObj.getBlob() != null 
				&& (offerObj.getBlob().getOffer()) != null 
				&& (offerObj.getBlob().getOffer().getCondition()!=null) 
				&& (offerObj.getBlob().getOffer().getCondition().getStatus() != null))
		{
				condition=offerObj.getBlob().getOffer().getCondition().getStatus();
				return condition;
		} else
		{
			condition="NEW";
		}
		return condition;
	}
	
	public String getItemConditionDispNameNew(OfferSchema offerObj)
	{
		String condition=null;
		if( offerObj != null 
				&& offerObj.getBlob() != null 
				&& (offerObj.getBlob().getOffer()) != null 
				&& (offerObj.getBlob().getOffer().getCondition()!=null) 
				&& (offerObj.getBlob().getOffer().getCondition().getStatus() != null))
		{
			condition=offerObj.getBlob().getOffer().getCondition().getStatus();
			if(condition.equals("NEW"))
			return "New";
			else if(condition.equals("NEW_BLEMISHED"))
				return "New - Blemished";
			else if(condition.equals("NEW_OTHER"))
				return "New - Other";
			else if(condition.equals("REFURBISHED"))
				return "Refurbished";
			else if(condition.equals("REFURBISHED_MANUFACTURER_AUTHORIZED"))
				return "Refurbished - Mfr Authorized";
			else if(condition.equals("REFURBISHED_SELLER"))
				return "Refurbished - Seller";
			else if(condition.equals("USED_LIKE_NEW"))
				return "Used - Like New";
			else if(condition.equals("USED_VERY_GOOD"))
				return "Used - Very Good";
			else if(condition.equals("USED_GOOD"))
				return "Used - Good";
			else if(condition.equals("USED_ACCEPTABLE"))
				return "Used - Acceptable";
			else if(condition.equals("USED_POOR"))
				return "Used - Poor";
	} else
	{
		condition="New";
	}
	return "New";		
	}
	
	public int getItemConditionOld(OfferSchema offerObj){
		String condition=null;
		if( offerObj != null 
				&& offerObj.getBlob() != null 
				&& (offerObj.getBlob().getOffer()) != null 
				&& (offerObj.getBlob().getOffer().getCondition()!=null) 
				&& (offerObj.getBlob().getOffer().getCondition().getStatus() != null))
		{
				condition=offerObj.getBlob().getOffer().getCondition().getStatus();
				if(condition.startsWith("N"))
				return 1;
				else if(condition.startsWith("R"))
					return 2;
				else if(condition.startsWith("U"))
					return 3;
		} else
		{
			condition="New";
		}
		return 1;
	}
	
	public String getItemConditionStingOld(OfferSchema offerObj){
		String condition=null;
		if( offerObj != null 
				&& offerObj.getBlob() != null 
				&& (offerObj.getBlob().getOffer()) != null 
				&& (offerObj.getBlob().getOffer().getCondition()!=null) 
				&& (offerObj.getBlob().getOffer().getCondition().getStatus() != null))
		{
				condition=offerObj.getBlob().getOffer().getCondition().getStatus();
				return condition;
		} else
		{
			condition="NEW";
		}
		return condition;
	}
	
	public boolean getSearsItemAvailaibility(OfferSchema offerObj) {
		boolean instock = false;
		//System.out.println("Item :" + offerObj.getId());
		if(offerObj.getFt().getPgrmType().equalsIgnoreCase("Sears"))
		{
			boolean isspu;
			try {
				isspu = offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
			} catch (Exception e) {
				isspu=false;
			}

			boolean issres;
			try {
				issres = offerObj.getBlob().getOffer().getFfm().getIsSResElig();
			} catch (Exception e) {
				issres=false;
			}

			boolean isavil;
			try {
				isavil = offerObj.getBlob().getOffer().getOperational().getSites().getSears().getIsAvail();

			} catch (Exception e) {
				isavil = false;
			}

			//System.out.println("isavil .... "+isavil);

			if(isspu || issres
					|| isavil){
				instock=true;
			} else
			{
				instock=false;
			}
		}
		return instock;
	}
	public Item getItemAvailability(String itemId, String type, String zip) throws URISyntaxException{

		String body = null;
		if(zip == null || zip.equals("") || zip.equals("0")){
			body="{\"items\":[{\"itemId\":\""+itemId+"\",\"type\":\""+type+"\"}]}";
		}
		else{
			body="{\"zip\":"+zip+",\"items\":[{\"itemId\":\""+itemId+"\",\"type\":\""+type+"\"}]}";
		}

		String iasUrl=LoadProperties.IASAPI;
		System.out.println(iasUrl +" : "+body);

		try
		{
				Thread.sleep(10);
		} 
		catch (InterruptedException e1)
		{
				e1.printStackTrace();
		}
		
		String iasResponse=RestExecutor.postForJSonResponse(new URI(iasUrl), body);
		System.out.println("iasResponse :"+iasResponse);
		if(iasResponse == null)
		{
			Item item = new Item();
			item.setAvailable(false);
			return item ;
		}

		ItemAvailabilityServiceSchema ias;

		try {
			ias = gson.fromJson(iasResponse, ItemAvailabilityServiceSchema.class);
		} catch (Exception e) {
			try {
				ias = gson.fromJson(iasResponse, ItemAvailabilityServiceSchema.class);
			} catch (Exception ee) {
				try {
					ias = gson.fromJson(iasResponse, ItemAvailabilityServiceSchema.class);
				} catch (Exception et) {
					//System.out.println("Error : IAS inv not present "+e.getMessage());

					Item item = new Item();
					item.setAvailable(false);
					return item ;
				}
			}
		}

		if(ias == null)
		{
			Item item = new Item();
			item.setAvailable(false);
			return item ;
		}

		return ias.getItems().get(0);

	}

	public Item getItemAvailabilityKmart(String itemId, String type, String zip,String ksn) throws URISyntaxException{

		String body = null;
		if( zip == null || zip.equals("") || zip.equals("0")){
			body="{\"items\":[{\"itemId\":\""+itemId+"\",\"type\":\""+type+"\",\"ksn\":\""+ksn+"\"}]}";
		}
		else{
			body="{\"zip\":"+zip+",\"items\":[{\"itemId\":\""+itemId+"\",\"type\":\""+type+"\",\"ksn\":\""+ksn+"\"}]}";
		}
		
		String iasUrl=LoadProperties.IASAPI;
		//System.out.println(iasUrl +" : "+body);

		//TODO in future make retry happen commonly
		String iasResponse=RestExecutor.postForJSonResponse(new URI(iasUrl), body);

		if(iasResponse.equals("TIME OUT ERROR"))
		{
			iasResponse=RestExecutor.postForJSonResponse(new URI(iasUrl), body);
		}

		if(iasResponse == null)
		{
			Item item = new Item();
			item.setAvailable(false);
			return item ;
		}

		ItemAvailabilityServiceSchema ias;

		try {
			ias = gson.fromJson(iasResponse, ItemAvailabilityServiceSchema.class);
		} catch (Exception e) {
			//System.out.println("Error : IAS inv not present "+e.getMessage());

			Item item = new Item();
			item.setAvailable(false);
			return item ;
		}

		if(ias == null)
		{
			Item item = new Item();
			item.setAvailable(false);
			return item ;
		}

		return ias.getItems().get(0);
	}

	public boolean getMpItemAvailaibility(OfferSchema offerObj) {
		boolean instock = false;
		if(offerObj.getBlob().getOffer().getOperational()!=null){
			instock=offerObj.getBlob().getOffer().getOperational().getSites().getSears().getIsAvail();
		} else
		{
			instock=false;
		}
		return instock;
	}

	public boolean getSearsMapViolation(String PartNumber,String store) throws URISyntaxException{

		String sStoreId = TestUtils.figureOutStoreIdFromStoreName(store);

		boolean mapViolation = false;
		String priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?storeId="+sStoreId+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber+"&site="+LoadProperties.STORESITE;

		System.out.println("priceGridUrl====="+priceGridUrl);
		
		String PricingGridResponse=RestExecutor.getJSonResponse(priceGridUrl);

		PricingGridResponse=StringUtils.replace(PricingGridResponse, "price-response", "priceresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "item-response", "itemresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sywrmember-price", "sywrmemberprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "regular-price", "regularprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "promo-price", "promoprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "ndd-price", "nddprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sell-price", "sellprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "map-details", "mapdetails");
		PriceGridSchema priceGrid = gson.fromJson(PricingGridResponse, PriceGridSchema.class);

		if(!priceGrid.getPriceresponse().getItemresponse().isEmpty()
				&& (priceGrid.getPriceresponse().getItemresponse().get(0).getMapdetails()!=null)){
			mapViolation = Boolean.valueOf(priceGrid.getPriceresponse().getItemresponse().get(0).getMapdetails().getViolation());
		}

		return mapViolation;
	}

	public String getSearsPriceType(String PartNumber,String store) throws URISyntaxException{
		String searsPriceType = "";
		String priceGridUrl="";

		String sStoreId = TestUtils.figureOutStoreIdFromStoreName(store);

		/*		local ad flag check commented as price type will be always displayed
		if (Boolean.valueOf(LoadProperties.LOCALADFLAG))
		{
			priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?storeId="+sStoreId+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber + "&site="+LoadProperties.STORESITE + "&storeUnitNumber=" + LoadProperties.STOREUNITNUMBER;

		}
		else
		{
			priceGridUrl = LoadProperties.PRICEGRIDAPI+"?storeId="+sStoreId+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&pid="+PartNumber;
		}*/

		priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?storeId="+sStoreId+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber + "&site="+LoadProperties.STORESITE;
		//				+ "&storeUnitNumber=" + LoadProperties.STOREUNITNUMBER; // removed store unit number from grid response

		String PricingGridResponse=RestExecutor.getJSonResponse(priceGridUrl);
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "price-response", "priceresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "item-response", "itemresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sywrmember-price", "sywrmemberprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "regular-price", "regularprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "promo-price", "promoprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "ndd-price", "nddprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sell-price", "sellprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "meta", "meta");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "map-details", "mapdetails");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "price-type", "metaTypePrice");

		PriceGridSchema priceGrid = gson.fromJson(PricingGridResponse, PriceGridSchema.class);


		if(priceGrid.getPriceresponse().getItemresponse().get(0).getMeta()!=null){

			searsPriceType = priceGrid.getPriceresponse().getItemresponse().get(0).getMeta().getMetaTypePrice();

		}

		return searsPriceType;
	}

	public float getPrice(String PartNumber,String store) throws URISyntaxException{
		float price = 0;

		//String sStoreId = TestUtils.figureOutStoreIdFromStoreName(store);

		String priceGridUrl="";

		/*
		 * Commenting local add flag check
		if (Boolean.valueOf(LoadProperties.LOCALADFLAG))
		{
			priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?site="+LoadProperties.STORESITE+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber + "&site="+LoadProperties.STORESITE + "&storeUnitNumber=" + LoadProperties.STOREUNITNUMBER;

		}
		else
		{
			priceGridUrl = LoadProperties.PRICEGRIDAPI+"?site="+LoadProperties.STORESITE+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber;
		}
		 */

		priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?site="+LoadProperties.STORESITE+"&pidType=0&zipCode="+LoadProperties.ZIPCODE+"&offer="+PartNumber + "&site="+LoadProperties.STORESITE;
		//		+ "&storeUnitNumber=" + LoadProperties.STOREUNITNUMBER;


		System.out.println("priceGridUrl...."+priceGridUrl);
		String PricingGridResponse=RestExecutor.getJSonResponse(priceGridUrl);
		//gb.processGet(new URI(uurl+PartNumber));

		//System.out.println("Price response debug=========="+PricingGridResponse);

		PricingGridResponse=StringUtils.replace(PricingGridResponse, "price-response", "priceresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "item-response", "itemresponse");
		
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "syw-price", "sywrmemberprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "regular-price", "regularprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "promo-price", "promoprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "ndd-price", "nddprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sell-price", "sellprice");

		PriceGridSchema priceGrid = gson.fromJson(PricingGridResponse, PriceGridSchema.class);

		if(!priceGrid.getPriceresponse().getItemresponse().isEmpty()){

			if(priceGrid.getPriceresponse().getItemresponse().get(0).getSywrmemberprice() > 0)
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getSywrmemberprice();
			} else if(priceGrid.getPriceresponse().getItemresponse().get(0).getNddprice()> 0)
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getNddprice();
			} else if((priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice()!=null)
					&& (priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice().getPrice() > 0))
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice().getPrice();
			} else if(priceGrid.getPriceresponse().getItemresponse().get(0).getPromoprice() > 0)
			{
				price= priceGrid.getPriceresponse().getItemresponse().get(0).getPromoprice();
			} else
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getRegularprice();
			}

		}
		//TODO - Bonus points QA db is not available. So commenting the code.
		//Dbconnection sqlObj = new Dbconnection();
		float bonuspoint = 0f;
		/*try {
			bonuspoint = sqlObj.getbonusPts(PartNumber);
		} catch (Exception e) {

			System.out.println("Exception while getting bonus points ... ");
			e.printStackTrace();
		}*/
		bonuspoint=(float) (bonuspoint * 0.0004);
		price=price-bonuspoint;

		return price;

	}

	private double getShipPrice(String PartNumber, boolean isSpuOrSres, float itemPrice,String store) {

		Double shipPrice = (double) 0;

		if((itemPrice==0) || isSpuOrSres){
			return shipPrice;
		}

		String zipCode = LoadProperties.ZIPCODE.equals("0")||LoadProperties.ZIPCODE.isEmpty()?"60179":LoadProperties.ZIPCODE;

		/*Changed on 30-Mar-2016
		  http://ffmapp302p.qa.ch3.s.com:8180/ecomservices/getShippingDetails/json
		  ?zipcode=60169&partNumber=004W002309874000&userType=GUEST&site=KMART&clientId=Buybox&shipChargeFlag=true */
		String shipUrl = LoadProperties.SHIPAPI+
				"?zipcode="+zipCode+
				"&partNumber="+PartNumber+
				"&userType="+LoadProperties.USERTYPE +
				"&site="+LoadProperties.STORESITE +
				"&clientId=Buybox" +
				"&shipChargeFlag=true";

		System.out.println("shipUrl... "+shipUrl);

		String shippingResponse = RestExecutor.getJSonResponse(shipUrl);
		shippingResponse = shippingResponse.replace("shipping-details-response", "shippingdetailsresponse");
		try{
			ShippingResponseSchema ship = gson.fromJson(shippingResponse, ShippingResponseSchema.class);
			shipPrice = ship.getShippingdetailsresponse().getSuccessItems().get(0).getShipModes().get(0).getShipCharge();
			for(ShipMode shipMode : ship.getShippingdetailsresponse().getSuccessItems().get(0).getShipModes()){
				if(shipMode.getShipCharge() < shipPrice){
					shipPrice = shipMode.getShipCharge();
				}
			}
		}catch(Exception e){
			shipPrice = (double) 0;
		}
		return shipPrice;
	}

	public float getMpPrice(OfferSchema offerObj) throws URISyntaxException {
		Float price = (float) 0.0;
		Double shipPrice = (double) 0;
		String PartNumber = offerObj.getId();
		//System.out.println("Partnumber :" + PartNumber);
		//String priceResponse = gb.getdataFromApi(PropReader.getproperty("gb.get.pricing") + PartNumber);
		String priceResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.PRICING_,PartNumber);
		//gb.processGet(new URI(PropReader.getproperty("gb.get.pricing") + PartNumber));
		if (!priceResponse.equalsIgnoreCase("[]")) {
			priceResponse = priceResponse.substring(1,priceResponse.length() - 1);
			PricingSchema priceObj = gson.fromJson(priceResponse,PricingSchema.class);
			if ((priceObj.get_blob().getPrice().getSale() != null)
					&& JodaDateTimeUtility.validateDate(null, priceObj.get_blob().getPrice().getSale().getSaleEndDate()))
			{
				price = priceObj.get_blob().getPrice().getSale().getSalePrice();
			} else
			{
				price = priceObj.get_blob().getPrice().getRegPrice();
			}
			
			//priceObj.get_blob().getPrice().get
		}else {
			price=(float) 0;
		}

		
		
		return price;
	}

	public double getMpShipPrice(OfferSchema offerObj, float itemPrice) {

		Double shipPrice = (double) 0;

		if(itemPrice==0){
			return shipPrice;
		}

		if(offerObj.getFt().getPgrmType().equalsIgnoreCase("CPC"))
		{
			shipPrice = (double) 0;
		}
		else if ((offerObj.getBlob().getOffer().getShipping() != null)
				&& (offerObj.getBlob().getOffer().getShipping().getMinRate() != null)) 
		{
			shipPrice = offerObj.getBlob().getOffer().getShipping().getMinRate();
		}
		else if((offerObj.getBlob().getOffer().getShipping().getMode() != null)
				&& (offerObj.getBlob().getOffer().getShipping().getMode().getGnd() != null)
				&& (offerObj.getBlob().getOffer().getShipping().getMode().getGnd().getFree() != null)
				&& (JodaDateTimeUtility.validateDate(offerObj.getBlob().getOffer().getShipping().getMode().getGnd().getFree().getStartDt(), 
						offerObj.getBlob().getOffer().getShipping().getMode().getGnd().getFree().getEndDt())))
		{
			shipPrice = (double) 0;
		}
		else if((offerObj.getBlob().getOffer().getShipping().getMode() != null)
				&& (offerObj.getBlob().getOffer().getShipping().getMode().getGnd() != null)
				&& (offerObj.getBlob().getOffer().getShipping().getMode().getGnd().getPrice() != null)) 
		{
			shipPrice = offerObj.getBlob().getOffer().getShipping().getMode().getGnd().getPrice();
		}
		else
		{
			shipPrice = getMPSellerShipPrice(offerObj, itemPrice);
		}
		return shipPrice;
	}

	public double getMPSellerShipPrice(OfferSchema offerObj, float itemPrice){
		Double sellerShipPrice = null;

		String itemType=offerObj.getFt().getPgrmType();
		boolean isMailable=offerObj.getBlob().getOffer().getShipping().getIsMailable();
		Double weight = offerObj.getBlob().getOffer().getShipping().getWeight();
		String sellerId=offerObj.getFt().getSellerId();
		com.generated.vos.seller.Seller seller = null;

		if(RankConstant.sellerMapNew.containsKey(sellerId)){
			seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
		}else{
			seller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);
			if(seller!=null){
				RankConstant.sellerMapNew.put(sellerId, seller);
			}
		}
		if(seller!=null){
			switch(itemType){
			case "FBM":
				if((seller.getPrograms().getFbm()!= null)
						&& (seller.getPrograms().getFbm().getShippingRates()!=null)
						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges()!=null)
						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)){

					if(isMailable && (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable()!=null)
							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()!=null)){
						for(WeightRange wtRange : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()){
							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
								sellerShipPrice = Double.parseDouble(wtRange.getGround());
							}
						}
					}else if(!isMailable && (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable()!=null)
							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()!=null)){
						for(WeightRange_ wtRange : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()){
							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
								sellerShipPrice = Double.parseDouble(wtRange.getGround());
							}
						}
					}
				}
				break;
			case "DSS":
				if((seller.getPrograms().getDss()!= null)
						&& (seller.getPrograms().getDss().getShippingRates()!=null)
						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges()!=null)
						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)){

					if(isMailable && (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable()!=null)
							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()!=null)){
						for(WeightRange__ wtRange : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()){
							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
								sellerShipPrice = Double.parseDouble(wtRange.getGround());
							}
						}
					}else if(!isMailable && (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable()!=null)
							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()!=null)){
						for(WeightRange___ wtRange : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()){
							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
								sellerShipPrice = Double.parseDouble(wtRange.getGround());
							}
						}
					}
				}
				break;
			}
		}

		if(sellerShipPrice==null)
		{
			return 6.25;
		} else
		{
			return sellerShipPrice;
		}
	}

// MP shipping price for non mailable items.
	
//	public double getMPSellerShipPrice(OfferSchema offerObj, float itemPrice){
//		Double sellerShipPrice = null;
//
//		String itemType=offerObj.getFt().getPgrmType();
//		boolean isMailable=offerObj.getBlob().getOffer().getShipping().getIsMailable();
//		Double weight = offerObj.getBlob().getOffer().getShipping().getWeight();
//		String sellerId=offerObj.getFt().getSellerId();
//		com.generated.vos.seller.Seller seller = null;
//
//		if(RankConstant.sellerMapNew.containsKey(sellerId)){
//			seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
//		}else{
//			seller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);
//			if(seller!=null){
//			//	RankConstant.sellerMapNew.put(sellerId, seller);
//			}
//		}
//		if(seller!=null){
//			switch(itemType){
//			case "FBM":
//				if(isMailable &&
//						(seller.getPrograms().getFbm()!= null)
//						&& (seller.getPrograms().getFbm().getShippingRates()!=null)
//						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges()!=null)
//						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)
//						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable()!=null)
//						&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()!=null))
//				{
//					for(WeightRange wtRange : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange())
//					{
//						if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
//							sellerShipPrice = Double.parseDouble(wtRange.getGround());
//						}
//					}
//				}
//				else if(!isMailable)
//				{
//
//					if( (seller.getPrograms().getFbm()!= null)
//							&& (seller.getPrograms().getFbm().getShippingRates()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges() != null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getOrderAmountChargeRange() !=null))
//					{
//						for(OrderAmountChargeRange orderAmountChargeRange : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getOrderAmountChargeRange())
//						{
//							if((Double.parseDouble(orderAmountChargeRange.getMin()) <= itemPrice) && (itemPrice <= Double.parseDouble(orderAmountChargeRange.getMax()))){
//								sellerShipPrice = Double.parseDouble(orderAmountChargeRange.getGround());
//							}
//						}
//						if(seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getNonContinentalSurcharge() !=null)
//						{
//							String zipCode = LoadProperties.ZIPCODE;
//							List<String> zipCodesHI = RestExecutor.getIdsByAltKey(CollectionValuesVal.ZIP_CODE, "state", "HI");
//							List<String> zipCodesAK = RestExecutor.getIdsByAltKey(CollectionValuesVal.ZIP_CODE, "state", "AK");
//
//
//							for(NonContinentalSurcharge_ nonContinentalSurcharge : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getNonContinentalSurcharge())
//							{
//								if(zipCodesHI.contains(zipCode))
//								{
//									if(nonContinentalSurcharge.getLocation().equalsIgnoreCase("hawaii"))
//									{
//										if(Double.parseDouble(nonContinentalSurcharge.getExpedited()) <= Double.parseDouble(nonContinentalSurcharge.getPremium()))
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getExpedited());
//										}
//										else
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getPremium());
//										}
//									}
//								}
//								if(zipCodesAK.contains(zipCode))
//								{
//									if(nonContinentalSurcharge.getLocation().equalsIgnoreCase("alaska"))
//									{
//										if(Double.parseDouble(nonContinentalSurcharge.getExpedited()) <= Double.parseDouble(nonContinentalSurcharge.getPremium()))
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getExpedited());
//										}
//										else
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getPremium());
//										}
//									}
//								}
//							}
//						}
//					}
//					else if( (seller.getPrograms().getFbm()!= null)
//							&& (seller.getPrograms().getFbm().getShippingRates()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable()!=null)
//							&& (seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()!=null))
//					{
//						for(WeightRange_ wtRange : seller.getPrograms().getFbm().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange())
//						{
//							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
//								sellerShipPrice = Double.parseDouble(wtRange.getGround());
//							}
//						}
//					}
//				}
//				break;
//				
//			case "DSS":
//				if(isMailable &&
//						(seller.getPrograms().getDss()!= null)
//						&& (seller.getPrograms().getDss().getShippingRates()!=null)
//						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges()!=null)
//						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)
//						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable()!=null)
//						&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange()!=null))
//				{
//					for(WeightRange__ wtRange : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getMailable().getWeightRange())
//					{
//						if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
//							sellerShipPrice = Double.parseDouble(wtRange.getGround());
//						}
//					}
//				}
//				else if(!isMailable)
//				{
//
//					if( (seller.getPrograms().getDss()!= null)
//							&& (seller.getPrograms().getDss().getShippingRates()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges() != null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getOrderAmountChargeRange() !=null))
//					{
//						for(OrderAmountChargeRange_ orderAmountChargeRange : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getOrderAmountChargeRange())
//						{
//							if((Double.parseDouble(orderAmountChargeRange.getMin()) <= itemPrice) && (itemPrice <= Double.parseDouble(orderAmountChargeRange.getMax()))){
//								sellerShipPrice = Double.parseDouble(orderAmountChargeRange.getGround());
//							}
//						}
//						if(seller.getPrograms().getDss().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getNonContinentalSurcharge() !=null)
//						{
//							String zipCode = LoadProperties.ZIPCODE;
//							List<String> zipCodesHI = RestExecutor.getIdsByAltKey(CollectionValuesVal.ZIP_CODE, "state", "HI");
//							List<String> zipCodesAK = RestExecutor.getIdsByAltKey(CollectionValuesVal.ZIP_CODE, "state", "AK");
//
//
//							for(NonContinentalSurcharge__ nonContinentalSurcharge : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getOrderAmountBasedShippingCharges().getNonContinentalSurcharge())
//							{
//								if(zipCodesHI.contains(zipCode))
//								{
//									if(nonContinentalSurcharge.getLocation().equalsIgnoreCase("hawaii"))
//									{
//										if(Double.parseDouble(nonContinentalSurcharge.getExpedited()) <= Double.parseDouble(nonContinentalSurcharge.getPremium()))
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getExpedited());
//										}
//										else
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getPremium());
//										}
//									}
//								}
//								if(zipCodesAK.contains(zipCode))
//								{
//									if(nonContinentalSurcharge.getLocation().equalsIgnoreCase("alaska"))
//									{
//										if(Double.parseDouble(nonContinentalSurcharge.getExpedited()) <= Double.parseDouble(nonContinentalSurcharge.getPremium()))
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getExpedited());
//										}
//										else
//										{
//											sellerShipPrice += Double.parseDouble(nonContinentalSurcharge.getPremium());
//										}
//									}
//								}
//							}
//						}
//					}
//					else if( (seller.getPrograms().getDss()!= null)
//							&& (seller.getPrograms().getDss().getShippingRates()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable()!=null)
//							&& (seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange()!=null))
//					{
//						for(WeightRange___ wtRange : seller.getPrograms().getDss().getShippingRates().getShippingCharges().getWeightBasedShippingCharges().getNonMailable().getWeightRange())
//						{
//							if((Double.parseDouble(wtRange.getMin()) <= weight) && (weight <= Double.parseDouble(wtRange.getMax()))){
//								sellerShipPrice = Double.parseDouble(wtRange.getGround());
//							}
//						}
//					}
//				}
//				break;
//			}
//		}
//
//		if(sellerShipPrice==null)
//		{
//			return 6.25;
//		} else
//		{
//			return sellerShipPrice;
//		}
//	}

	public int getSoptDays(OfferSchema offerObj){
		int soptDays=0;

		boolean isSpuOrSres;
		try {
			isSpuOrSres = ((offerObj.getBlob().getOffer().getFfm().getIsSpuElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSpuElig())
					|| ((offerObj.getBlob().getOffer().getFfm().getIsSResElig()!=null) && offerObj.getBlob().getOffer().getFfm().getIsSResElig());
		} catch (Exception e) {
			isSpuOrSres = false;
		}

		if(isSpuOrSres){
			soptDays=0;
		} else
		{
			soptDays=offerObj.getBlob().getOffer().getShipping().getSoptDays()==null ? 2 : offerObj.getBlob().getOffer().getShipping().getSoptDays().intValue();
		}
		return soptDays;
	}

	public int getMpSoptDays(OfferSchema offerObj) throws URISyntaxException{
		int soptDays=0;
		int sellerSoptSeconds=0;

		String itemType=offerObj.getFt().getPgrmType();
//		String PartNumber=offerObj.getId();
		String sellerId=offerObj.getFt().getSellerId();
		boolean isMailable=offerObj.getBlob().getOffer().getShipping().getIsMailable();

		//System.out.println("MP Offer :" + PartNumber + " Seller :" + sellerId);

		if(itemType.equalsIgnoreCase("FBM") || itemType.equalsIgnoreCase("DSS")){
			if(RankConstant.sellerMap.containsKey(sellerId)){
				SellerdtlsVO s=(SellerdtlsVO) RankConstant.sellerMap.get(sellerId);
				sellerSoptSeconds = isMailable?s.getRegularSopt():s.getOversizeSopt();
			}else{
				String sellerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER,sellerId);
				//gb.processGet(new URI(PropReader.getproperty("gb.get.seller")+ sellerId));
				if((sellerResponse!= null) && !sellerResponse.equalsIgnoreCase("TIME OUT ERROR")){
					sellerResponse=sellerResponse.substring(1, sellerResponse.length()-1);
					SellerSchema sellerObj= gson.fromJson(sellerResponse, SellerSchema.class);
					String trustSeller = "false";
					int soptRegular = 0;
					int soptOversize = 0;
					switch(itemType){
					case "FBM":
						if((sellerObj.get_blob().getSeller().getPrograms().getFbm()!= null)
								&& (sellerObj.get_blob().getSeller().getPrograms().getFbm().getTrustedSeller()!=null))
						{
							trustSeller = sellerObj.get_blob().getSeller().getPrograms().getFbm().getTrustedSeller();
						}
						soptRegular = sellerObj.get_blob().getSeller().getPrograms().getFbm().getWareHouse().getSopt().getRegular();
						soptOversize = sellerObj.get_blob().getSeller().getPrograms().getFbm().getWareHouse().getSopt().getOversize();
						sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					case "DSS":
						trustSeller = "true";
						soptRegular = sellerObj.get_blob().getSeller().getPrograms().getDss().getWareHouse().getSopt().getRegular();
						soptOversize = sellerObj.get_blob().getSeller().getPrograms().getDss().getWareHouse().getSopt().getOversize();
						sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					}
					/**Added sellerMap set**/
					SellerdtlsVO s = new SellerdtlsVO();
					s.setStore(itemType);
					s.setTrustedSeller(trustSeller);
					s.setSoptDays(soptRegular);
					s.setRegularSopt(soptRegular);
					s.setOversizeSopt(soptOversize);
					s.setSellerTier(sellerObj.get_blob().getSeller().getSellerTier());
					s.setSellerStoreUrl(sellerObj.get_blob().getSeller().getStoreFront()==null?null:sellerObj.get_blob().getSeller().getStoreFront().getUrlName());
					RankConstant.sellerMap.put(sellerId, s);
					/*****/
				}
			}
		}else if (itemType.equalsIgnoreCase("FBS")){
			return 2;
		}

		boolean isspu;
		try {
			isspu = offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
		} catch (Exception e) {
			isspu=false;
		}

		if(isspu)
		{
			soptDays=0;
		} else if(offerObj.getBlob().getOffer().getShipping().getSoptDays()!=null)
		{
			soptDays=offerObj.getBlob().getOffer().getShipping().getSoptDays().intValue();
		} else if(sellerSoptSeconds > 0)
		{
			soptDays=sellerSoptSeconds/(24*60*60);
		} else
		{
			soptDays=sellerSoptSeconds==0?0:2147483647;
		}

		return soptDays;
	}

	public int getMpSoptDaysNew(OfferSchema offerObj) throws URISyntaxException{
		int soptDays=0;
		int sellerSoptSeconds=0;

		String itemType=offerObj.getFt() == null ? null : offerObj.getFt().getPgrmType();
		//		String PartNumber=offerObj.getId();

		String sellerId= offerObj.getFt() == null ? null : offerObj.getFt().getSellerId();

		boolean isMailable =  offerObj.getBlob().getOffer().getShipping().getIsMailable();

		com.generated.vos.seller.Seller seller = null;

		//System.out.println("MP Offer :" + PartNumber + " Seller :" + sellerId);

		if(itemType.equalsIgnoreCase("FBM") || itemType.equalsIgnoreCase("DSS")){
			if(RankConstant.sellerMapNew.containsKey(sellerId)){
				seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);

			}else{
				seller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);

				if(seller!=null){
					RankConstant.sellerMapNew.put(sellerId, seller);
				}
			}

			if(
					((seller!= null)
							&&	(seller.getPrograms()!=null)
							&&	(seller.getPrograms().getFbm()!= null)
							&&	(seller.getPrograms().getFbm().getWareHouse()!=null)
							&&	(seller.getPrograms().getFbm().getWareHouse().getSopt()!=null))
							||
							((seller!= null)
									&&	(seller.getPrograms()!=null)
									&&	(seller.getPrograms().getDss()!= null)
									&& (seller.getPrograms().getDss().getWareHouse()!=null)
									&& (seller.getPrograms().getDss().getWareHouse().getSopt()!=null))
					)
			{
				int soptRegular = 0;
				int soptOversize = 0;

				switch(itemType){
				case "FBM":
					soptRegular = Integer.parseInt(seller.getPrograms().getFbm().getWareHouse().getSopt().getRegular());
					soptOversize = Integer.parseInt(seller.getPrograms().getFbm().getWareHouse().getSopt().getOversize());
					sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					break;
				case "DSS":
					if(seller.getPrograms().getDss()!=null)
					{
						soptRegular = Integer.parseInt(seller.getPrograms().getDss().getWareHouse().getSopt().getRegular());
						soptOversize = Integer.parseInt(seller.getPrograms().getDss().getWareHouse().getSopt().getOversize());
						sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					}
					break;
				}
			}
			if(
					((seller!= null)
							&&	(seller.getPrograms()!=null)
							&&	(seller.getPrograms().getFbm()!= null)
							&&	(seller.getPrograms().getFbm().getWareHouse()!=null)
							&&	(seller.getPrograms().getFbm().getWareHouse().getSopt()!=null))
							||
							((seller!= null)
									&&	(seller.getPrograms()!=null)
									&&	(seller.getPrograms().getDss()!= null)
									&& (seller.getPrograms().getDss().getWareHouse()!=null)
									&& (seller.getPrograms().getDss().getWareHouse().getSopt()!=null))
					){
				int soptRegular = 0;
				int soptOversize = 0;

				switch(itemType){
				case "FBM":
					soptRegular = Integer.parseInt(seller.getPrograms().getFbm().getWareHouse().getSopt().getRegular());
					soptOversize = Integer.parseInt(seller.getPrograms().getFbm().getWareHouse().getSopt().getOversize());
					sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					break;
				case "DSS":
					if(seller.getPrograms().getDss()!=null)
					{
						soptRegular = Integer.parseInt(seller.getPrograms().getDss().getWareHouse().getSopt().getRegular());
						soptOversize = Integer.parseInt(seller.getPrograms().getDss().getWareHouse().getSopt().getOversize());
						sellerSoptSeconds = isMailable?soptRegular:soptOversize;
					}
					break;
				}
			}

		}else if (itemType.equalsIgnoreCase("FBS")){
			return 2;
		}

		boolean isspu;
		try {
			isspu = offerObj.getBlob().getOffer().getFfm().getIsSpuElig();
		} catch (Exception e) {
			isspu=false;
		}

		if(isspu)
		{
			soptDays=0;
		} else if(offerObj.getBlob().getOffer().getShipping().getSoptDays()!=null)
		{
			soptDays=offerObj.getBlob().getOffer().getShipping().getSoptDays().intValue();
		} else if(sellerSoptSeconds > 0)
		{
			soptDays=sellerSoptSeconds/(24*60*60);
		} else
		{
			soptDays=sellerSoptSeconds==0?0:2147483647;
		}

		return soptDays;
	}

	private String getMpSellerTier(OfferSchema offerObj) {
		try{
			String sellerId=offerObj.getFt().getSellerId();
			SellerdtlsVO s=(SellerdtlsVO) RankConstant.sellerMap.get(sellerId);
			return s.getSellerTier();
		}catch (Exception e){
			return "REGULAR";
		}
	}

	private String getMpSellerTierNew(OfferSchema offerObj) {
		try{
			String sellerId=offerObj.getFt().getSellerId();
			com.generated.vos.seller.Seller seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
			return seller.getSellerTier();
		}catch (Exception e){
			return "REGULAR";
		}
	}

	private String getMpSellerStrUrl(OfferSchema offerObj) {
		try{
			String sellerId=offerObj.getFt().getSellerId();
			SellerdtlsVO s=(SellerdtlsVO) RankConstant.sellerMap.get(sellerId);
			return s.getSellerStoreUrl();
		}catch (Exception e){
			return null;
		}
	}

	private String getMpSellerStrUrlNew(OfferSchema offerObj) {
		try{
			String sellerId=offerObj.getFt().getSellerId();
			com.generated.vos.seller.Seller seller = null;

			if(RankConstant.sellerMapNew.containsKey(sellerId)){
				seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
			}else{
				seller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);
				if(seller!=null){
					/**Add to sellerMap**/
					RankConstant.sellerMapNew.put(sellerId, seller);
					/*****/
				}else{
					return null;
				}
			}

			return seller.getStoreFront()==null?null:seller.getStoreFront().getUrlName();

		}catch (Exception e){
			return null;
		}
	}

	public float getItemConfidenceScore(OfferSchema offerObj){
		float cc = 0;
		if(offerObj.getBlob().getOffer().getMarketplace().getCatConfScore() !=null){
			cc=offerObj.getBlob().getOffer().getMarketplace().getCatConfScore().intValue();
		}
		else{
			cc=1;
		}


		return cc;

	}
	public boolean getMPTrust(OfferSchema offerObj) throws URISyntaxException{
		String trustSeller="false";
		String PartNumber=offerObj.getId();
		String sellerId=offerObj.getFt().getSellerId();
		if(RankConstant.sellerMap.containsKey(sellerId)){
			SellerdtlsVO s=(SellerdtlsVO) RankConstant.sellerMap.get(sellerId);
			trustSeller=s.getTrustedSeller();
		}else{
			String sellerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER,sellerId);
			//gb.processGet(new URI(PropReader.getproperty("gb.get.seller")+ sellerId));
			if((sellerResponse!= null) && !sellerResponse.equalsIgnoreCase("TIME OUT ERROR")){
				sellerResponse=sellerResponse.substring(1, sellerResponse.length()-1);
				SellerSchema sellerObj= gson.fromJson(sellerResponse, SellerSchema.class);
				if((sellerObj.get_blob().getSeller().getPrograms().getFbm()!= null) && (sellerObj.get_blob().getSeller().getPrograms().getFbm().getTrustedSeller()!=null))
				{
					trustSeller=sellerObj.get_blob().getSeller().getPrograms().getFbm().getTrustedSeller();
				}

				/**Added sellerMap set**/
				SellerdtlsVO s = new SellerdtlsVO();
				s.setStore("FBM");
				s.setTrustedSeller(trustSeller);
				s.setSoptDays(sellerObj.get_blob().getSeller().getPrograms().getFbm().getWareHouse().getSopt().getRegular());
				s.setRegularSopt(sellerObj.get_blob().getSeller().getPrograms().getFbm().getWareHouse().getSopt().getRegular());
				s.setOversizeSopt(sellerObj.get_blob().getSeller().getPrograms().getFbm().getWareHouse().getSopt().getOversize());
				s.setSellerTier(sellerObj.get_blob().getSeller().getSellerTier());
				s.setSellerStoreUrl(sellerObj.get_blob().getSeller().getStoreFront()==null?null:sellerObj.get_blob().getSeller().getStoreFront().getUrlName());
				RankConstant.sellerMap.put(sellerId, s);
				/*****/
			}
		}
		if(trustSeller.equals("false"))
		{
			return false;
		} else
		{
			return true;
		}
	}

	public boolean getMPTrustNewFBM(OfferSchema offerObj) throws URISyntaxException{
		String trustSeller="false";
		String sellerId=offerObj.getFt().getSellerId();
		if(RankConstant.sellerMapNew.containsKey(sellerId)){
			com.generated.vos.seller.Seller seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
			if((seller.getPrograms().getFbm()!=null) && (seller.getPrograms().getFbm().getTrustedSeller()!=null)){
				trustSeller=seller.getPrograms().getFbm().getTrustedSeller().toString();
			}

			if((seller.getPrograms().getFbs()!=null) && (seller.getPrograms().getFbs().getTrustedSeller()!=null)){
				trustSeller=seller.getPrograms().getFbs().getTrustedSeller().toString();
			}

		}else{
			com.generated.vos.seller.Seller gbSeller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);

			if(gbSeller!=null){
				if((gbSeller.getPrograms().getFbm()!=null) && (gbSeller.getPrograms().getFbm().getTrustedSeller()!=null)){
					trustSeller=gbSeller.getPrograms().getFbm().getTrustedSeller().toString();
				}

				if((gbSeller.getPrograms().getFbs()!=null) && (gbSeller.getPrograms().getFbs().getTrustedSeller()!=null)){
					trustSeller=gbSeller.getPrograms().getFbs().getTrustedSeller().toString();
				}

				/**Add to sellerMap**/
				RankConstant.sellerMapNew.put(sellerId, gbSeller);
				/*****/
			}
		}
		if(trustSeller.equals("false"))
		{
			return false;
		} else
		{
			return true;
		}
	}


	public boolean getMPTrustNewFBS(OfferSchema offerObj) throws URISyntaxException{
		String trustSeller="false";
		String sellerId=offerObj.getFt().getSellerId();
		if(RankConstant.sellerMapNew.containsKey(sellerId)){
			com.generated.vos.seller.Seller seller = (com.generated.vos.seller.Seller) RankConstant.sellerMapNew.get(sellerId);
			if((seller.getPrograms().getFbs()!=null) && (seller.getPrograms().getFbs().getTrustedSeller()!=null)){
				trustSeller=seller.getPrograms().getFbs().getTrustedSeller().toString();
			}
		}else{
			com.generated.vos.seller.Seller gbSeller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER,sellerId);

			if(gbSeller!=null){
				if((gbSeller.getPrograms().getFbs()!=null) && (gbSeller.getPrograms().getFbs().getTrustedSeller()!=null)){
					trustSeller=gbSeller.getPrograms().getFbs().getTrustedSeller().toString();
				}

				/**Add to sellerMap**/
				RankConstant.sellerMapNew.put(sellerId, gbSeller);
				/*****/
			}
		}
		if(trustSeller.equals("false"))
		{
			return false;
		} else
		{
			return true;
		}
	}


	public boolean getItemWebStatus(OfferSchema offerObj) {
		boolean webStatus = false;

		if(LoadProperties.STORESITE.equalsIgnoreCase("sears"))
		{
			if((offerObj.getBlob().getOffer().getOperational()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites().getSears()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites().getSears().getIsDispElig()!=null)
					&& offerObj.getBlob().getOffer().getOperational().getSites().getSears().getIsDispElig()){
				webStatus=true;
			} else
			{
				webStatus=false;
			}
		}
		else
		{
			if((offerObj.getBlob().getOffer().getOperational()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites().getKmart()!=null)
					&& (offerObj.getBlob().getOffer().getOperational().getSites().getKmart().getIsDispElig()!=null)
					&& offerObj.getBlob().getOffer().getOperational().getSites().getKmart().getIsDispElig()){
				webStatus=true;
			} else
			{
				webStatus=false;
			}
		}
		return webStatus;
	}
}