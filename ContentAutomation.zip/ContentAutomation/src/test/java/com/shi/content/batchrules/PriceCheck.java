package com.shi.content.batchrules;


/**
 * @author ddaphal
 *
 */
public class PriceCheck {


	/*public static void main(String[] args) {

		//03827270090 -  r and x
		System.out.println("output "+checkForInValidPrice("sears", "00216312"));
	}*/
}
