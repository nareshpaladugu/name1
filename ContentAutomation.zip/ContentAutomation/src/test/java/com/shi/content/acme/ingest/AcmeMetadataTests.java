package com.shi.content.acme.ingest;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.attribute.Attribute;
import com.generated.xmls.masterhierarchy.Node;
import com.generated.xmls.seller.Seller;
import com.generated.xmls.storehierarchy.Level1;
import com.generated.xmls.vendor.Vendor;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class AcmeMetadataTests {
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="acmeMetadataIngestTests")
	public void acmeMPSellerIngest(String sFileName) throws InterruptedException{
		
		System.out.println("Testing sFileName "+ sFileName);

		if(sFileName.contains("seller-feed-export.xml")){
			//Create a blocking queue per thread	
			BlockingQueue<List<Seller>> sellerQ = new LinkedBlockingQueue<List<Seller>>(); 
	
			// Start producer thread to produce nodes
			ChunkProducerThread<Seller> prodThread = new ChunkProducerThread<Seller>(sFileName, sellerQ, Seller.class);
	
			prodThread.setBucketSize(1);
			Thread t = new Thread(prodThread);
			t.start();
	
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			while(true){
				try {
					List<Seller> nodeToTest = sellerQ.poll(20, TimeUnit.SECONDS);
					if(nodeToTest == prodThread.POISON_PILL){
						System.out.println("Got poison pill ..breaking out" + nodeToTest);
						break;
					}
					if(nodeToTest != null){
						pool.execute(new AcmeMetadataVerifications(nodeToTest.get(0)));
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	
			pool.shutdown();
	
			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else if(sFileName.contains("vendor.xml")){

			//Create a blocking queue per thread	
			BlockingQueue<List<Vendor>> vendorQ = new LinkedBlockingQueue<List<Vendor>>(); 
	
			// Start producer thread to produce nodes
			ChunkProducerThread<Vendor> prodThread = new ChunkProducerThread<Vendor>(sFileName, vendorQ, Vendor.class);
	
			prodThread.setBucketSize(1);
			Thread t = new Thread(prodThread);
			t.start();
	
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			while(true){
				try {
					List<Vendor> nodeToTest = vendorQ.poll(20, TimeUnit.SECONDS);
					if(nodeToTest == prodThread.POISON_PILL){
						System.out.println("Got poison pill ..breaking out" + nodeToTest);
						break;
					}
					if(nodeToTest != null){
						pool.execute(new AcmeMetadataVerifications(nodeToTest.get(0)));
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	
			pool.shutdown();
	
			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else if(sFileName.contains("master-hierarchy.xml")){

			//Create a blocking queue per thread	
			BlockingQueue<List<Node>> nodeQ = new LinkedBlockingQueue<List<Node>>(); 
	
			// Start producer thread to produce nodes
			ChunkProducerThread<Node> prodThread = new ChunkProducerThread<Node>(sFileName, nodeQ, Node.class);
	
			prodThread.setBucketSize(1);
			Thread t = new Thread(prodThread);
			t.start();
	
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			while(true){
				try {
					List<Node> nodeToTest = nodeQ.poll(20, TimeUnit.SECONDS);
					if(nodeToTest == prodThread.POISON_PILL){
						System.out.println("Got poison pill ..breaking out" + nodeToTest);
						break;
					}
					if(nodeToTest != null){
						pool.execute(new AcmeMetadataVerifications(nodeToTest.get(0)));
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	
			pool.shutdown();
	
			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else if(sFileName.contains("attribute-and-value.xml")){

			//Create a blocking queue per thread	
			BlockingQueue<List<Attribute>> attributeQ = new LinkedBlockingQueue<List<Attribute>>(); 
	
			// Start producer thread to produce nodes
			ChunkProducerThread<Attribute> prodThread = new ChunkProducerThread<Attribute>(sFileName, attributeQ, Attribute.class);
	
			prodThread.setBucketSize(1);
			Thread t = new Thread(prodThread);
			t.start();
	
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			while(true){
				try {
					List<Attribute> nodeToTest = attributeQ.poll(20, TimeUnit.SECONDS);
					if(nodeToTest == prodThread.POISON_PILL){
						System.out.println("Got poison pill ..breaking out" + nodeToTest);
						break;
					}
					if(nodeToTest != null){
						pool.execute(new AcmeMetadataVerifications(nodeToTest.get(0)));
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	
			pool.shutdown();
	
			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else if(sFileName.contains("store-hierarchy-")){

			//Create a blocking queue per thread	
			BlockingQueue<List<Level1>> levelQ = new LinkedBlockingQueue<List<Level1>>(); 
	
			// Start producer thread to produce nodes
			ChunkProducerThread<Level1> prodThread = new ChunkProducerThread<Level1>(sFileName, levelQ, Level1.class);
	
			prodThread.setBucketSize(1);
			Thread t = new Thread(prodThread);
			t.start();
	
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			while(true){
				try {
					List<Level1> nodeToTest = levelQ.poll(20, TimeUnit.SECONDS);
					if(nodeToTest == prodThread.POISON_PILL){
						System.out.println("Got poison pill ..breaking out" + nodeToTest);
						break;
					}
					if(nodeToTest != null){
						pool.execute(new AcmeMetadataVerifications(nodeToTest.get(0)));
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	
			pool.shutdown();
	
			try {
				pool.awaitTermination(1000, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
