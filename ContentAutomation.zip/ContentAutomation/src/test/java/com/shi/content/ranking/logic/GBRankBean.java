package com.shi.content.ranking.logic;

import java.util.List;

public class GBRankBean {
	
	public List<String> getSites() {
		return sites;
	}

	public void setSites(List<String> sites) {
		this.sites = sites;
	}


	private List<String> sites;
	
	private String soldBy; 
	public String getSoldBy() {
		return soldBy;
	}

	public void setSoldBy(String soldBy) {
		this.soldBy = soldBy;
	}

	public Boolean isCrossFormatted() {
		if(crossFormatted==null)
			crossFormatted=false;
		return crossFormatted;
	}

	public void setCrossFormatted(Boolean crossFormatted) {
		this.crossFormatted = crossFormatted;
	}


	private Boolean crossFormatted;
	
	private String partnumber;
	private Boolean webStatus;
	private int itemCondition;
	private String conditionString;
	private String conditionDispName;
	private String storeName;
	private Integer storePriority;
	private Boolean instock;
	private Boolean trustedSeller;
	private Float price;
	private Double shipPrice;
	private Integer sopt;
	private Float confidenceScore;
	private Integer rank;
	private Integer transitDays;
	private Integer totalTransitDays;
	private String sellerTier;
	private String sellerStoreUrl;
	private Integer sellerTierValue;
	private Boolean spuEligible;
	private Boolean sresEligible;
	private Boolean mapViolation;
	private String priceType;
	private Float bonusPoints;
	

	
	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public Integer getStorePriority() {
		return storePriority;
	}

	public void setStorePriority(Integer storePriority) {
		this.storePriority = storePriority;
	}

	public String getPartnumber() {
		return partnumber;
	}

	public void setPartnumber(String partnumber) {
		this.partnumber = partnumber;
	}

	public Boolean getWebStatus() {
		return webStatus;
	}

	public void setWebStatus(Boolean webStatus) {
		this.webStatus = webStatus;
	}

	public Integer getItemCondition() {
		return itemCondition;
	}

	public void setItemCondition(int i) {
		this.itemCondition = i;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public Boolean getInstock() {
		return instock;
	}

	public void setInstock(Boolean instock) {
		this.instock = instock;
	}

	public Boolean getTrustedSeller() {
		return trustedSeller;
	}

	public void setTrustedSeller(Boolean trustedSeller) {
		this.trustedSeller = trustedSeller;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getSopt() {
		return sopt;
	}

	public void setSopt(Integer sopt) {
		this.sopt = sopt;
	}

	public Float getConfidenceScore() {
		return confidenceScore;
	}

	public void setConfidenceScore(Float confidenceScore) {
		this.confidenceScore = confidenceScore;
	}
	
	public Integer getTransitDays() {
		return transitDays;
	}

	public void setTransitDays(Integer transitDays) {
		this.transitDays = transitDays;
	}
	
	public Integer getTotalTransitDays() {
		return totalTransitDays;
	}

	public void setTotalTransitDays(Integer totalTransitDays) {
		this.totalTransitDays = totalTransitDays;
	}
	
	public Double getShipPrice() {
		return shipPrice;
	}

	public void setShipPrice(Double shipPrice) {
		this.shipPrice = shipPrice;
	}
	
	public Integer getSellerTierValue() {
		return sellerTierValue;
	}

	public void setSellerTierValue(Integer sellerTierValue) {
		this.sellerTierValue = sellerTierValue;
	}

	public String getSellerTier() {
		return sellerTier;
	}

	public void setSellerTier(String sellerTier) {
		this.sellerTier = sellerTier;
	}
	
	public String getSellerStoreUrl() {
		return sellerStoreUrl;
	}

	public void setSellerStoreUrl(String sellerStoreUrl) {
		this.sellerStoreUrl = sellerStoreUrl;
	}
	
	public Boolean getSpuEligible() {
		return spuEligible;
	}

	public void setSpuEligible(Boolean spuEligible) {
		this.spuEligible = spuEligible;
	}

	public Boolean getSresEligible() {
		return sresEligible;
	}

	public void setSresEligible(Boolean sresEligible) {
		this.sresEligible = sresEligible;
	}
	
	public Boolean getMapViolation() {
		return mapViolation;
	}

	public void setMapViolation(Boolean mapViolation) {
		this.mapViolation = mapViolation;
	}

	
	@Override
	public String toString() {
		return "GBRankBean [partnumber=" + partnumber + ", webStatus="
				+ webStatus + ", itemCondition=" + itemCondition
				+ ", storeName=" + storeName + ", storePriority="
				+ storePriority + ", instock=" + instock + ", trustedSeller="
				+ trustedSeller + ", price=" + price + ", sopt=" + sopt
				+ ", transitDays=" + transitDays + ", totalTransitDays=" + totalTransitDays
				+ ", shipPrice=" + shipPrice
				+ ", sellerTier=" + sellerTier + ", sellerTierValue=" + sellerTierValue
				+ ", spuEligible=" + spuEligible + ", sresEligible=" + sresEligible
				+ ", mapViolation=" + mapViolation
				+ ", confidenceScore=" + confidenceScore + ", rank=" + rank + ", priceType=" + priceType
				+ "]";
	}

	public String getConditionString() {
		return conditionString;
	}

	public void setConditionString(String conditionString) {
		this.conditionString = conditionString;
	}

	public Float getBonusPoints() {
		return bonusPoints;
	}

	public void setBonusPoints(Float bonusPoints) {
		this.bonusPoints = bonusPoints;
	}

	public String getConditionDispName() {
		return conditionDispName;
	}

	public void setConditionDispName(String conditionDispName) {
		this.conditionDispName = conditionDispName;
	}
}
