package com.shi.content.wcstogb.test;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.ListCollectionsIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.shc.autocontent.LoadProperties;

public class TestGiftRegistryDbConnection 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		try
		{

			String dName="giftRegistry";

			System.out.println("dName... "+dName);

			MongoClientURI uri = new MongoClientURI
					("mongodb://"+LoadProperties.gbUser+":"+LoadProperties.gbPassword+"@"+LoadProperties.gbServer+":"+LoadProperties.gbServerPort+"/?authSource="+dName);

			System.out.println("URI ..."+uri.toString());

			MongoClient mongoClient = new MongoClient(uri);

			System.out.println(mongoClient);

			MongoDatabase database = mongoClient.getDatabase(dName);

			System.out.println("Listing all collections............... ");

			ListCollectionsIterable<Document> allCollections = database.listCollections();

			for (Document document : allCollections) {

				System.out.println(document);
			}

			System.out.println("-------------------------------------- ");

			MongoCollection<Document> colleciton = database.getCollection("userCollection");

			System.out.println("colleciton.getNamespace()... "+ colleciton.getNamespace());

			FindIterable<Document> myDoc = colleciton.find().limit(10);
			for (Document document : myDoc) {
				System.out.println(document.toJson());
			}

			System.out.println("END");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
