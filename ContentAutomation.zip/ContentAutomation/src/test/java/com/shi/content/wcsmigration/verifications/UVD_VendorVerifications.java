package com.shi.content.wcsmigration.verifications;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.vendor.Seller;
import com.generated.xmls.vendor.OrderDunsNumber;
import com.generated.xmls.vendor.ShcFbm;
import com.generated.xmls.vendor.Vendor;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class UVD_VendorVerifications implements Runnable {

	Vendor vendor;

	public UVD_VendorVerifications(Vendor vendor) {
		this.vendor = vendor;
	}

	public void run() {

		CompareValuesUtility.init();

		try {
			if(vendor.getId()==0) {
				System.out.println("Ignoring vendor as vendor-id=0 : " + vendor.getId());
				return;
			}
			if(vendor.getPrograms().getShcFbm() == null) {
				System.out.println("Ignoring vendor as shc FBM program not present : " + vendor.getId());
				return;
			}
			ShcFbm vnd = vendor.getPrograms().getShcFbm();
			
			if(vnd.getPayDunsNumber()==null){
				System.out.println("Ignoring vendor as Pay Duns not present : " + vendor.getId());
			return;
			}
			
			Boolean vFound = false;
			
			for(OrderDunsNumber duns : vnd.getOrderDunsNumber()) {
				if(duns.getStoreId() == 1) {
					System.out.println("Ignoring vendor as orderDunsNumber has store=1 : " + vendor.getId());
					continue;
				}else if(duns.getStoreId() == 2 && (duns.getDefault()==null || !duns.getDefault())){
					System.out.println("Sears vendor with default not true : " + vendor.getId());
					continue;
				}else if(duns.getStoreId() == 2 && duns.getDefault()) {
					vFound = true;
					System.out.println("Sears vendor with default true : " + vendor.getId());

					String id = "shc_" + duns.getContent().toString().substring(1);

					System.out.println("Id to hit GB seller: " + id);

					APIResponse<Seller> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.SELLER, id);
					Seller gbVendor = (Seller) allResponse.getT();
					
					if (allResponse == null || gbVendor == null) {
						CompareValuesUtility.logFailed("Id", id, "Vendor NOT found in GB");
						CompareValuesUtility.setupResult(vendor.getId().toString(), true);
						return;
					}
					
					CompareValuesUtility.compareValues("Id", id, gbVendor.getId());
					CompareValuesUtility.verifyNullOrEqual("VendorID", vendor.getId(), gbVendor.getPrograms().getVd().getVendorID());
					CompareValuesUtility.setupResult(vendor.getId().toString(), true);
				}
			}
			if(!vFound){
				String payDuns = vnd.getPayDunsNumber().toString();
				
				if(vnd.getPayDunsNumber().toString().length()<9){
					payDuns = StringUtils.leftPad(vnd.getPayDunsNumber().toString(), 9, "0");
				}
				else if(vnd.getPayDunsNumber().toString().length()>9){
					payDuns = vnd.getPayDunsNumber().toString().substring(vnd.getPayDunsNumber().toString().length()-9);
				}
					
				List<String> sellerIds = RestExecutor.getIdsByAltKey(CollectionValuesVal.SELLER, "payDunsNumber", payDuns);
				
				if(sellerIds.size()==0){
					System.out.println("Vendor not present in GB for payDuns="+payDuns+ " : " + vendor.getId());
					return;
				}
				String id = sellerIds.get(0);
				System.out.println("Id to hit GB seller: " + id);
				
				APIResponse<Seller> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.SELLER, id);
				Seller gbVendor = (Seller) allResponse.getT();
				
				if (allResponse == null || gbVendor == null) {
					CompareValuesUtility.logFailed("Id", id, "Vendor NOT found in GB");
					CompareValuesUtility.setupResult(vendor.getId().toString(), true);
					return;
				}
				
				CompareValuesUtility.compareValues("Id", id, gbVendor.getId());
				CompareValuesUtility.verifyNullOrEqual("VendorID", vendor.getId(), gbVendor.getPrograms().getVd().getVendorID());
				CompareValuesUtility.setupResult(vendor.getId().toString(), true);
			}
			
		} catch (Throwable e) {
			System.out.println("Check this id :" + vendor.getId());
			e.printStackTrace();
		} finally {
			CompareValuesUtility.teardown();
		}

	}
}
