package com.shi.content.ranking.vos;

public class Sopt {
	private int regular;
	private int oversize;
	public int getRegular() {
		return regular;
	}
	public void setRegular(int regular) {
		this.regular = regular;
	}
	public int getOversize() {
		return oversize;
	}
	public void setOversize(int oversize) {
		this.oversize = oversize;
	}
	

}
