package com.shi.content.northstar.tests;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.MeetExpert;
import com.shi.content.northstar.pages.SearchStorePage;
import com.shi.content.northstar.pages.EditStoreDetails.SERVICES;
import com.shi.content.northstar.pages.EditStoreDetails.VERTICALS;


/**
 * Test meet with expert for PR Stores
 * @author inaikwa
 *
 */
public class MeetExpertTest_PRStoresTest extends NorthStarBaseTest {
	private ArrayList<String> listStoreIds;
	private String storeId="0002707";
	
//	In progress
	
//	@Test(description="Test to verify MeetWithExpert fields addition and removal in Northstar and Greenbox for PR Stores", groups = {"NS-P1"})
	public void testMeetWithExpert() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();

		searchPage.searchByStoreNumber("0002707");

		listStoreIds= searchPage.getAllStoreIds();
		
		Asserts.verifyNotNull(listStoreIds.size(), "Verifed required storeIds found");
		
		Assert.assertNotNull(listStoreIds.size(), listStoreIds.size()+ " =: Zero stores found, terminating......... ");
		
		storeId =listStoreIds.get(0);

		searchPage.clickStore(storeId);
		
		MeetExpert eView = new MeetExpert();
		
		List<VERTICALS> verticals = new ArrayList<VERTICALS>();
		verticals.add(VERTICALS.APPLIANCES);
		eView.addMeetWithExpert_Sears(verticals);
		eView.addMeetWithExpert_PR(verticals);
		eView.saveDocument();	
		/*
		Asserts.assertTrue(eView.isOptionAdded(SERVICES.MEETWITHEXPERT), "Assert if meet with expert has been added to services list");
		
		String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 

		String sMeetExpertEligFlagVal = JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strAttr.sites.sears.meetExpertElig");
		Asserts.verifyTrue(Boolean.parseBoolean(sMeetExpertEligFlagVal), "Verify meetExpertElig flag is set to true in Store collection");

		String sMeetExpertHierId = JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strAttr.sites.sears.meetExpertHier").replaceAll("\"", "").replaceAll("\\[", "").replaceAll("\\]", "");
		String webHierarchyResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.WEB_HIERARCHY,sMeetExpertHierId);
		String hierarchyName = JsonStringParser.getJsonValueNew(webHierarchyResponse, "_blob.hierarchy.name");
		Asserts.verifyEquals(VERTICALS.APPLIANCES.getName(), hierarchyName.replaceAll("\"", ""),"Verified Clothing vertical added to store" );
		
		/**
		 * Remove meet expert flag
		 */
		/*
		eView.goToDepartmentsView();
		eView.removeMeetWithExpertOption();
		eView.saveDocument();		
		
		eView.goToDepartmentsView();
		
		String storeResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,storeId); 
	
		String sMeetExpertEligFlagValAfterRemove= JsonStringParser.getJsonValueNew(storeResponse, "_blob.unit.strAttr.sites.sears.meetExpertElig");
		
		Asserts.verifyFalse(Boolean.parseBoolean(sMeetExpertEligFlagValAfterRemove), "Verify meetExpertElig flag is set to false in Store collection");
		
		Asserts.verifyNull(JsonStringParser.getJsonValueNew(storeResponse, "_blob.unit.strAttr.sites.sears.meetExpertHier").equals("null")?null:JsonStringParser.getJsonValueNew(storeResponse, "_blob.unit.strAttr.sites.sears.meetExpertHier"), "Verified the Hierarchy tag is removed from Store collection after removing meet Expert Service");
	*/	
	}
	
}
	
