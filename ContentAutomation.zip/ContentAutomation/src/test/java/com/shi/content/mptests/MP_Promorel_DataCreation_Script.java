package com.shi.content.mptests;

import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.Test;

import com.generated.vos.promos.Promo;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.kafkautils.KafkaProducer;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

/**
 * Script to create test data for testing MP Promorel Loader job.
 * Creates new promotions from all different groups, associates it with FBM/FBS items & pushes it to Kafka Producer to generate promorel document.
 * Covers all possible combinations of Promo Group, Domain, PgmTypes & Mode.
 * @author vshar10
 *
 */
public class MP_Promorel_DataCreation_Script {

	enum PgmType{FBM, FBS};
	enum PromoGroup{SYWMAX,INSTSAVINGS,BILLFREEDELIVERY,SYWMBR,CRAFTCLB,SYWRDMPT,FINANCING,REGULAR,MISC,COUPON};
	enum Domain{SEARS,KMART};
	enum Mode{PREVIEW,PRODUCTION};

	String sywMaxPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555796_1467209015552\",\"msgDtm\":1467209015552},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"SywMaxrepPromoId\",\"promoType\":\"Shipping\",\"couponCode\":\"SHIPVANTAGEPROMO\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 18:59:59.0\",\"markdownCode\":6,\"markdownCodeName\":\"Shipping\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":790,\"displayRank\":1,\"shippingInformation\":\"Economy, UPS\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsShippingDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 05:41:38.0\",\"updatedDate\":\"2016-06-29 09:03:35.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110147_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String financePromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555799_1467200765862\",\"msgDtm\":1467200765862},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"FinancerepPromoId\",\"promoType\":\"Financing\",\"couponCode\":\"Promo1\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 17:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Finance\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":990,\"displayRank\":1,\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"ZPF\",\"displayEndDate\":false,\"promoGroup\":\"SearsItemLevelCouponDiscountPromotion\",\"dealSetting\":\"2\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 06:45:58.0\",\"updatedDate\":\"2016-06-29 06:46:05.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Price\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110072_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String sywMbrPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555802_1467201689149\",\"msgDtm\":1467201689149},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"SYWMBRrepPromoId\",\"promoType\":\"Simple\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 03:00:00.0\",\"endDate\":\"repEndDate 13:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"customerSegment\":\"SYWR Member GROUP\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":990,\"displayRank\":1,\"exclusionText\":\"Excludes Everyday Great Price, Hot Buy, Smart Buy, and Unilateral Pricing Policy (UPP) items.\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"2|3\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:01:23.0\",\"updatedDate\":\"2016-06-29 07:01:29.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110075_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String couponPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555805_1467202683979\",\"msgDtm\":1467202683979},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"CouponrepPromoId\",\"promoType\":\"SYWRPromo\",\"couponCode\":\"SYWRPROMOCODE\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 23:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":1000,\"displayRank\":1,\"exclusionText\":\"Internationally Shipped Orders are excluded\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:17:56.0\",\"updatedDate\":\"2016-06-29 07:18:03.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110087_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String sywRdmptPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555808_1467203273178\",\"msgDtm\":1467203273178},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"SYWRDMPTrepPromoId\",\"promoType\":\"SYWRPromo\",\"couponCode\":\"SYWRXRPROMOCODE\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 23:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":960,\"displayRank\":1,\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:27:47.0\",\"updatedDate\":\"2016-06-29 07:27:53.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110090_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String instSavingsPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555811_1467203886099\",\"msgDtm\":1467203886099},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"instSavingsrepPromoId\",\"promoType\":\"Simple\",\"couponCode\":\"NOSPECIALFINANCEPROMO\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 23:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":30,\"displayRank\":1,\"exclusionText\":\"Internationally Shipped Orders are excluded\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:38:01.0\",\"updatedDate\":\"2016-06-29 07:38:06.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110093_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]},{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[]},{\"itemType\":\"Target\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Exclusion\",\"catalog\":\"\",\"ruleName\":\"110095_Exclusion\",\"categoryName\":[\" \"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String craftClbPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555814_1467204510512\",\"msgDtm\":1467204510512},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"CraftrepPromoId\",\"promoType\":\"Companion\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 23:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Dealofday\",\"customerSegment\":\"Sears Craftsman Club Member Group\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":988,\"displayRank\":1,\"exclusionText\":\"Internationally Shipped Orders are excluded\",\"shippingInformation\":\"Delivery\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsDealofdayDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":true,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:48:24.0\",\"updatedDate\":\"2016-06-29 07:48:30.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110102_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]},{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[]},{\"itemType\":\"Target\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String billFreeDelPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555817_1467204856494\",\"msgDtm\":1467204856494},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"BILLINGFREEDELIVERY2repPromoId\",\"promoType\":\"Simple\",\"couponCode\":\"BILLINGFREEDELIVERY\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 11:00:00.0\",\"endDate\":\"repEndDate 16:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":990,\"displayRank\":1,\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 07:54:10.0\",\"updatedDate\":\"2016-06-29 07:54:16.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110111_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String regularAprPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555823_1467206522085\",\"msgDtm\":1467206522085},\"promo\":{\"promoId\":repPromoId,\"aprLinkedPromoId\":555824,\"promoName\":\"RegularAPRDealrepPromoId\",\"promoType\":\"Simple\",\"couponCode\":\"APR9\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 18:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBS\",\"FBM\",\"Kmart\"],\"priority\":990,\"displayRank\":1,\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":true,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"2\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 08:06:09.0\",\"updatedDate\":\"2016-06-29 08:22:02.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110135_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String regularNonAprPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555829_1467207080776\",\"msgDtm\":1467207080776},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"RegularNonAprrepPromoId\",\"promoType\":\"Simple\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 18:00:00.0\",\"endDate\":\"repEndDate 16:59:59.0\",\"markdownCode\":4,\"markdownCodeName\":\"Storesale\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":990,\"displayRank\":1,\"exclusionText\":\"Excludes Everyday Great Price, Hot Buy, Smart Buy, and Unilateral Pricing Policy (UPP) items.\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsStoresaleDiscountPromotion\",\"dealSetting\":\"2|3\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":false,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 08:31:15.0\",\"updatedDate\":\"2016-06-29 08:31:20.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110141_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";
	String miscPromo = "{\"header\":{\"ver\":\"v2\",\"msgId\":\"555832_1467207677199\",\"msgDtm\":1467207677199},\"promo\":{\"promoId\":repPromoId,\"promoName\":\"MiscrepPromoId\",\"promoType\":\"Shipping\",\"couponCode\":\"FSCONCESSION\",\"storeName\":\"Sears\",\"startDate\":\"repStartDate 00:00:01.0\",\"endDate\":\"repEndDate 00:59:59.0\",\"markdownCode\":6,\"markdownCodeName\":\"Shipping\",\"shortDescription\":\"Test\",\"pgmTypes\":[\"Sears\",\"DSS\",\"FBM\",\"FBS\",\"Kmart\"],\"priority\":960,\"displayRank\":1,\"shippingInformation\":\"Economy, UPS\",\"perOrderLimit\":-1,\"perShopperLimit\":-1,\"applicationLimit\":-1,\"giftCardInclusion\":false,\"serviceInclusion\":false,\"aprDeal\":false,\"csoDeal\":false,\"affectedItem\":\"Individual\",\"discountType\":\"PMD_DOLLAR_OFF\",\"displayEndDate\":false,\"promoGroup\":\"SearsShippingDiscountPromotion\",\"dealSetting\":\"0\",\"freePromoFlag\":false,\"appliedToRegularPrice\":false,\"parentStoreField\":\"Sears\",\"isExclusiveDeal\":false,\"excludeAssociate\":true,\"excludeOptionalItems\":false,\"dealStatus\":\"a\",\"createdDate\":\"2016-06-29 08:41:10.0\",\"updatedDate\":\"2016-06-29 08:41:17.0\",\"rules\":[{\"itemType\":\"Source\",\"thresholdName\":\"Quantity\",\"thresholdCondition\":[1.0],\"discountAmount\":[1.0],\"ruleDetails\":[{\"ruleType\":\"Inclusion\",\"catalog\":\"web\",\"ruleName\":\"110144_Inclusion\",\"categoryName\":[\"TVs & Electronics\"]}]}],\"channels\":[{\"channelType\":\"KIOSK\",\"channelName\":[\"SHC-FLS\",\"SHC-HTS\",\"SHC-HAS\",\"SHC-AHS\",\"SHC-OUT\",\"SHC-KMT\",\"SHC-POS\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"MOBILE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"ONLINE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"},{\"channelType\":\"STORE\",\"channelName\":[\"*\"],\"domain\":\"repDomain\",\"tgtItmTrtmnt\":\"Online\",\"client\":\"*\"}],\"mode\":\"repMode\",\"subscriptionFreeShipping\":false,\"updatedUserId\":\"vshar10\",\"userId\":\"vshar10\"}}";

	HashMap<PromoGroup, Promo> promoMap = null;
	HashMap<String,String> itemsMap = null;
	String message = "";
	KafkaProducer kafkaProducer = null;
	Integer noOfItem;
	String pgmTypeStr;
	String modeStr;
	String domainStr;
	ArrayList<PgmType> pgmTypeList = null;
	ArrayList<Domain> domainList = null;
	ArrayList<Mode> modeList = null;
	
	@Test(groups="MPPromorelCreateData")
	public void createDataForMPPromorelLoader() {
		try {
			initData();

			for (PgmType pgmType : pgmTypeList) {	
				for (Mode mode : modeList) {
					for (Domain domain : domainList) {
						promoMap = createPromosWithDiffGroups(domain, mode);
						itemsMap = getItems(pgmType, noOfItem);
						message = prepareMessage(itemsMap, promoMap, mode);
						kafkaProducer.publishMessage(LoadProperties.KAFKATOPIC, message);
						System.out.println("Message pushed to Kafka : "+message);
						try {
							// Add to report
							for (String itemId : itemsMap.keySet()) {
								CompareValuesUtility.init();
								CompareValuesUtility.addDataFieldForReport("PgmType", pgmType.toString(),INFOTYPE.DATA);
								CompareValuesUtility.addDataFieldForReport("Domain", domain.toString(),INFOTYPE.DATA);
								CompareValuesUtility.addDataFieldForReport("Mode", mode.toString(),INFOTYPE.DATA);
								CompareValuesUtility.setupResult(itemId, true);
							}
						} catch(Exception e) {
							System.out.println(e.getMessage());
						}
					}
				}
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			CompareValuesUtility.teardown();
		}
	}

	public void initData() throws Exception {
		noOfItem = Integer.parseInt(LoadProperties.getProperty("noOfItems","0"));
		if (noOfItem == null || noOfItem == 0) {
			noOfItem = 1;
		}

		pgmTypeStr = LoadProperties.getProperty("pgmType","");
		if (pgmTypeStr == null || pgmTypeStr.equals("")) {
			throw new Exception("pgmType is not specified");
		}

		modeStr = LoadProperties.getProperty("envMode","");
		if (modeStr == null || modeStr.equals("")) {
			throw new Exception("mode is not specified");
		}

		domainStr = LoadProperties.getProperty("domain","");
		if (domainStr == null || domainStr.equals("")) {
			throw new Exception("domain is not specified");
		}

		kafkaProducer = new KafkaProducer();

		pgmTypeList = new ArrayList<>();
		if (pgmTypeStr.equals("ALL")) {
			for (PgmType pgmType : PgmType.values()) {
				pgmTypeList.add(pgmType);
			}
		} else if (pgmTypeStr.equals("FBM")) {
			pgmTypeList.add(PgmType.FBM);
		} else if (pgmTypeStr.equals("FBS")) {
			pgmTypeList.add(PgmType.FBS);
		}

		domainList = new ArrayList<>();
		if (domainStr.equals("ALL")) {
			for (Domain domain : Domain.values()) {
				domainList.add(domain);
			}
		} else if (domainStr.equals("SEARS")) {
			domainList.add(Domain.SEARS);
		}  else if (domainStr.equals("KMART")) {
			domainList.add(Domain.KMART);
		}

		modeList = new ArrayList<>();
		if (modeStr.equals("ALL")) {
			for (Mode mode : Mode.values()) {
				modeList.add(mode);
			}
		} else if (modeStr.equals("PREVIEW")) {
			modeList.add(Mode.PREVIEW);
		}  else if (modeStr.equals("PRODUCTION")) {
			modeList.add(Mode.PRODUCTION);
		} 
	}

	/**
	 * Method to prepare kafka message based on items, promotions & mode. 
	 * @param items	- Hashmap of item ids & their pgmType
	 * @param promotions - Hashmap of Promogroup & promo Id
	 * @param mode - Should be PREVIEW/PRODUCTION
	 * @return
	 */
	public String prepareMessage(HashMap<String,String> items, HashMap<PromoGroup, Promo> promotions, Mode mode) {
		String message = "{\"header\":{\"ver\":\"v1\",\"msgId\":\"31532630_1005593\",\"modifiedDtm\":1449101055000},\"promorel\":[repItemsList]}";
		String jItem = "{\"itemId\": repItemId,\"accountId\": 1234,\"prgm\": \"repPgmType\",\"activePromo\": [repPromoList] repDartPartNo}";
		String jPromo = "{\"promoId\":\"repPromoId\",\"promoType\":\"repPromoType\",\"mode\":\"repPromoMode\"}";
		String itemList = "";
		String modeStr = mode.toString().toLowerCase();

		// Prepare Items List
		for (String itemId : items.keySet()) {
			String pgmTypeStr = items.get(itemId).trim();
			String promoList = "", dartPartNo = "";

			// Prepare Promo List
			for (PromoGroup group : promotions.keySet()) {
				Promo promo = promotions.get(group);
				if (!promoList.equals(""))
					promoList += ",";
				promoList += jPromo.replace("repPromoId", promo.getPromoIds().getId().split("_")[0])
						.replace("repPromoType", promo.getPromoDetails().getType().toString())
						.replace("repPromoMode", modeStr);
			}

			if (pgmTypeStr.equals("FBS")) {
				dartPartNo = ",\"dartPartNbr\": \""+itemId+"\"";
			}

			if (!itemList.equals(""))
				itemList += ",";
			itemList += jItem.replace("repItemId", itemId)
					.replace("repPgmType", pgmTypeStr)
					.replace("repPromoList", promoList)
					.replace("repDartPartNo", dartPartNo);
		}
		message = message.replace("repItemsList", itemList);
		return message;
	}

	/**
	 * Method to get hashmap of random item numbers with their pgmType.
	 * @param pgmType - Specify FBM/FBS to associate it in the hashmap
	 * @param n - number of random items required
	 * @return
	 */
	public HashMap<String,String> getItems(PgmType pgmType, int n) {
		HashMap<String,String> itemsMap = new HashMap<>();
		for(int i=0; i<n; i++) {
			itemsMap.put(Integer.toString(GenericUtil.getRandomNumberInRange(600000, 9999999)), pgmType.toString());
		}
		return itemsMap;
	}

	/**
	 * Returns map of promo Id & its promo group by generating new promotions of all promo groups based on domain & mode specified.
	 * @param domain
	 * @param mode
	 * @return
	 */
	public HashMap<PromoGroup, Promo> createPromosWithDiffGroups(Domain domain, Mode mode) {
		HashMap<PromoGroup, Promo> promoMap = new HashMap<>();
		for (PromoGroup promoGroup : PromoGroup.values()) {
			promoMap.put(promoGroup, generatePromo(promoGroup, domain, mode));
		}
		return promoMap;
	}

	/**
	 * Method to generate a new promo based on promGroup, domain & mode specified.
	 * @param promoGroup
	 * @param domain
	 * @param mode
	 * @return
	 */
	public Promo generatePromo(PromoGroup promoGroup, Domain domain, Mode mode) {
		String domainStr = "", modeStr = "", finalPromoMessage = "";
		CollectionValues collection = null;

		switch (domain) {
		case SEARS:
			domainStr = "SEARS";
			break;
		case KMART:
			domainStr = "KMART";
			break;
		}

		switch (mode) {
		case PREVIEW:
			modeStr = "preview";
			collection = CollectionValuesVal.PREVIEWPROMO;
			break;
		case PRODUCTION:
			modeStr = "production";
			collection = CollectionValuesVal.PROMO;
			break;
		}

		switch (promoGroup) {
		case BILLFREEDELIVERY:
			finalPromoMessage = billFreeDelPromo;
			break;
		case CRAFTCLB:
			finalPromoMessage = craftClbPromo;
			break;
		case INSTSAVINGS:
			finalPromoMessage = instSavingsPromo;
			break;
		case SYWMAX:
			finalPromoMessage = sywMaxPromo;
			break;
		case SYWMBR:
			finalPromoMessage = sywMbrPromo;
			break;
		case SYWRDMPT:
			finalPromoMessage = sywRdmptPromo;
			break;
		case FINANCING:
			finalPromoMessage = financePromo;
			break;
		case COUPON:
			finalPromoMessage = couponPromo;
			break;
		case MISC:
			finalPromoMessage = miscPromo;
			break;
		case REGULAR:
			finalPromoMessage = regularAprPromo;
			break;
		}

		// Generate required random data
		String repPromoId = Integer.toString(GenericUtil.getRandomNumberInRange(600000, 9999999));
		String repStartDate = JodaDateTimeUtility.getDateFromCurrentDate(-1, "yyyy-MM-dd");
		String repEndDate = JodaDateTimeUtility.getDateFromCurrentDate(7, "yyyy-MM-dd");

		// Update required string 
		finalPromoMessage = finalPromoMessage.replaceAll("repDomain", domainStr)
				.replaceAll("repMode", modeStr)
				.replaceAll("repPromoId", repPromoId)
				.replaceAll("repStartDate", repStartDate)
				.replaceAll("repEndDate", repEndDate);

		// Send message to kafka to create promo
		KafkaProducer kafkaProducer = new KafkaProducer();
		kafkaProducer.publishMessage(LoadProperties.KAFKAPROMOMETATOPIC, finalPromoMessage);

		// Wait till promo is created in promo/previewpromo collection 
		if (promoGroup == PromoGroup.FINANCING) 
			repPromoId+="_z";
		else
			repPromoId+="_p";

		int cnt=0;
		do {
			try {
				Promo promo = RestExecutor.getAllDataById(collection, repPromoId).getT();
				if (promo.getPromoIds().getId().trim().equalsIgnoreCase(repPromoId)) {
					System.out.println("  Created Promo "+promo.getPromoIds().getId()+" ("+promoGroup+")");
					return promo;
				}
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				cnt++;
			}
		} while(cnt < 5);	// To check whether promo is created or not
		return null;
	}

	/**
	 * Method to validate specified promotion based on its status, start date & end date.
	 * @param promo
	 * @return
	 */
	public boolean isValidPromo(Promo promo) {
		if (promo.getMeta().getStatus().toString().equalsIgnoreCase("a") && JodaDateTimeUtility.validateDate(promo.getPromoDetails().getStartDt(), promo.getPromoDetails().getEndDt())) {
			return true;
		}
		return false;
	}
}