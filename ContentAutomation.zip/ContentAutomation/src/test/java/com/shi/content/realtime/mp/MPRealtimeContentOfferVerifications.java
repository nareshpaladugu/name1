package com.shi.content.realtime.mp;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.types.AttributeTypeType;
import com.generated.vos.content.Attachment;
import com.generated.vos.offer.AlternateImg;
import com.generated.vos.offer.Classifications;
import com.generated.vos.offer.Condition;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.Fee;
import com.generated.vos.offer.Legal;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Marketplace;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.offer.Taxonomy;
import com.generated.vos.proto.catalog.Catalog;
import com.generated.vos.proto.catalog.Item;
import com.generated.vos.proto.catalogcommons.Attribute;
import com.generated.vos.proto.catalogcommons.Image;
import com.generated.vos.proto.content.CommRate;
import com.generated.vos.proto.content.Content;
import com.generated.vos.proto.content.Site;
import com.generated.vos.proto.offer.ConditionType;
import com.generated.vos.proto.offer.Dimensions;
import com.generated.vos.proto.offer.Offer;
import com.generated.vos.proto.offer.StateFees;
import com.generated.vos.seller.Seller;
import com.generated.vos.seller.WareHouseLocation_;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.batchrules.SpecificConditionsCheck;
import com.shi.content.wcsmigration.mp.MpCommon;


public class MPRealtimeContentOfferVerifications<T> implements Runnable {

	Catalog mpContOffrDoc;
	SHCContentCommons commonUtils = new SHCContentCommons("","sears");
	CommonFbmsFieldsGroup commonFields;
	Boolean isFit = true;
	private Boolean isBrandCodeFound = null;
	String brandCodeId = null;
	Boolean isFitReqd = false;
	Map<String, Map<Long, List<String>>> offerHierarchyMap = null;
	
	public MPRealtimeContentOfferVerifications(Catalog mpContOffrDoc) {
		this.mpContOffrDoc = mpContOffrDoc;
	}

	public void run() {

		try {
			for(Item item : mpContOffrDoc.getItemList()){
				CompareValuesUtility.init();
				String pgrmType = item.getContent().getPgmType().toString();
				Content rtContent = item.getContent();
				List<Offer> rtOfferList = item.getOfferList();
				Boolean isVariation = false;
				String gbContentId = "";
				String sellerId = rtContent.getOwnerId().toString();
				Offer offer = null;

				if(rtContent.getExternalGroupId()!=null){
					isVariation = true;
					gbContentId  = TestUtils.generateVariationId(sellerId,rtContent.getExternalGroupId(),pgrmType);
				}else{
					offer = item.getOfferList().get(0);
					switch(pgrmType){
					case "FBM":
					case "DSS":
						gbContentId  = "SPM" + offer.getItemId().toString();
						break;
					case "FBS":
						gbContentId  = offer.getDartPartNbr();
						break;
					case "CPC":
						String sellerDoc = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, sellerId);
						String aggregatorId = JsonStringParser.getJsonValue(sellerDoc,"{_blob{seller{programs{cpc{aggregatorId}}}}}");
						if(!(aggregatorId.equalsIgnoreCase(""))&&!(sellerId.equalsIgnoreCase("")))
							gbContentId = TestUtils.generateCPCId(aggregatorId, sellerId, offer.getItemId());
						break;
					}
				}

				// Check whether offer hierarchies are valid
				Map<String, Map<Long, List<String>>> offerSiteHierarchyMap = getOfferSiteHierarchyMap(rtOfferList);
				boolean flag = false;
				for(String s : offerSiteHierarchyMap.keySet()) {
					Map<Long, List<String>> map = offerSiteHierarchyMap.get(s);
					if ( map != null && map.size() != 0) {
						flag = true;
						break;
					}
				}
				
				if (flag) {
					APIResponse<com.generated.vos.content.Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,gbContentId);
					com.generated.vos.content.Content gbContent =  (com.generated.vos.content.Content)allResponse.getT();

					if(gbContent == null && rtOfferList.get(0).getSkinnyOffer()==null){
						CompareValuesUtility.logFailed("id", gbContentId, " Not found in GB content");
						CompareValuesUtility.setupResult(gbContentId+"", true);
						continue;
					}else if(gbContent != null && rtOfferList.get(0).getSkinnyOffer()!=null){
						CompareValuesUtility.logFailed("id", gbContentId, " For Skinny Offer Content should not be loaded");
					}
					Long contentMsgDtm = getContentMsgDtm(rtOfferList);
					if(JodaDateTimeUtility.isFirstDateBeforeSecond(JodaDateTimeUtility.convertUnixTSToTZFormat(contentMsgDtm, "CST"), gbContent.getTimeChecker()==null?null:gbContent.getTimeChecker().getMpcontentofferUpdate())){
						System.out.println("Skipping content validation as TS in msg < timeChecker in GB content for id: " + gbContentId);
					}else{
						System.out.println("Testing content Id: " + gbContentId);
						Offer firstOffer = rtOfferList.get(0);
						verifyContent(gbContentId, gbContent, rtContent, isVariation, isVariation?rtContent.getExternalGroupId():offer.getItemId().toString(), contentMsgDtm, firstOffer);

						CompareValuesUtility.verifyNullOrEqual("Content_ft", isVariation?"V":"NV", allResponse.getFtFieldValue("catentrySubType").toString(),"catentrySubType");
						CompareValuesUtility.verifyNullOrEqual("Content_search", isVariation?rtContent.getExternalGroupId():offer.getItemId().toString(), allResponse.getSearchFieldValue("spinId").toString(),"spinId");
						//CompareValuesUtility.verifyNullOrEqual("Content_search", "[MP,"+rtContent.getPgmType()+"]", allResponse.getSearchFieldValue("dispSite").toString(),"dispSite");
						//System.out.println(allResponse.getSearchFieldValue("dispSite"));
						CompareValuesUtility.addNewMultiValuedFields();
					}
					//CompareValuesUtility.addNewMultiValuedFields();
					verifyOffer(gbContentId,rtOfferList,isVariation,pgrmType,sellerId,rtContent);

				} else {
					CompareValuesUtility.addDataFieldForReport("Error", "Message got skipped since none of the offer has valid web hierarchy for offer");
				}

				CompareValuesUtility.setupResult(gbContentId, true);
				CompareValuesUtility.teardown();
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			CompareValuesUtility.teardown();
		}
	}

	public Map<String, Map<Long, List<String>>> getOfferSiteHierarchyMap(List<Offer> rtOfferList) {
		offerHierarchyMap = new HashMap<>();
		
		for (Offer offer : rtOfferList) {
			String itemId = offer.getItemId().toString();
			List<com.generated.vos.proto.offer.Site> siteList = offer.getSiteList();
			
			Map<Long, List<String>> validOfferHierarchies = getValidOfferHierarchies(siteList);
			offerHierarchyMap.put(itemId, validOfferHierarchies);
		}
		
		return offerHierarchyMap;
	}
	
	private void verifyContent(String gbContentId, com.generated.vos.content.Content gbContent, Content rtContent, Boolean isVariation, String spinId, Long msgDtm, Offer firstOffer) {

		CompareValuesUtility.verifyNullOrEqual("id", gbContentId, gbContent.getId());
		CompareValuesUtility.addDataFieldForReport("contlastModifiedBy", gbContent.getMeta().getLastModifiedBy());
		CompareValuesUtility.verifyNullOrEqual("name", rtContent.getTitle(), gbContent.getName());

		CompareValuesUtility.verifyNullOrEqual("classifications", "P", gbContent.getClassifications().getCatentryType(), "catentryType");
		CompareValuesUtility.verifyNullOrEqual("classifications", isVariation?"V":"NV", gbContent.getClassifications().getCatentrySubType(), "catentrySubType");
		CompareValuesUtility.verifyNullOrEqual("classifications", rtContent.getEnrichInfo()!=null?"CN":"SP", gbContent.getClassifications().getEnrichmentProvider(), "enrichmentProvider");
		CompareValuesUtility.addNewMultiValuedFields();
		for (Site site : rtContent.getSiteList()){
			if(site.getId().toString().equalsIgnoreCase("2")){
				CompareValuesUtility.verifyNullOrEqual("Sites", "sears", gbContent.getSites()==null?null:gbContent.getSites().get(0));	
			}
			if(site.getId().toString().equalsIgnoreCase("1")){
				if(gbContent.getSites().size()>1)
					CompareValuesUtility.verifyNullOrEqual("Sites", "kmart", gbContent.getSites()==null?null:gbContent.getSites().get(1));	
				if(gbContent.getSites().size()==1)
					CompareValuesUtility.verifyNullOrEqual("Sites", "kmart", gbContent.getSites()==null?null:gbContent.getSites().get(0));
			}
			if(site.getId().toString().equalsIgnoreCase("4")){
				if(gbContent.getSites().size()==2)
					CompareValuesUtility.verifyNullOrEqual("Sites", "mygofer", gbContent.getSites()==null?null:gbContent.getSites().get(1));
				if(gbContent.getSites().size()>2)
					CompareValuesUtility.verifyNullOrEqual("Sites", "mygofer", gbContent.getSites()==null?null:gbContent.getSites().get(2));
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
		//TODO
		//automotive - brandCodeId, autoFitment, isFitmentRequired
		//verifyAutomotiveContent(gbContent,rtContent);

		commonUtils.verifyDesc(rtContent.getFeatDesc(), rtContent.getMktgDesc(), gbContent.getDesc(),false);
		CompareValuesUtility.addNewMultiValuedFields();

		if(rtContent.getBrand()!=null){
			CompareValuesUtility.verifyNullOrEqual("brand", rtContent.getBrand().getId(), gbContent.getBrand()==null?null:gbContent.getBrand().getId(), "id");
			CompareValuesUtility.verifyNullOrEqual("brand", rtContent.getBrand().getName(), gbContent.getBrand()==null?null:gbContent.getBrand().getName(), "name");
			if(rtContent.getBrand().getBrandImg()!=null && gbContent.getBrand()!=null && gbContent.getBrand().getImg()!=null && rtContent.getBrand().getBrandImg().getUrl().equals(gbContent.getBrand().getImg().getSrc()))
				CompareValuesUtility.verifyNullOrEqual("brand", rtContent.getBrand().getBrandImg()==null?null:rtContent.getBrand().getBrandImg().getUrl(), gbContent.getBrand()==null?null:gbContent.getBrand().getImg()==null?null:gbContent.getBrand().getImg().getSrc(), "logoUrl");
			else
				CompareValuesUtility.verifyNullOrEqual("brand", rtContent.getBrand().getBrandImg()==null?null:TestUtils.modifyBrandImgURL(rtContent.getBrand().getBrandImg().getUrl()), gbContent.getBrand()==null?null:gbContent.getBrand().getImg()==null?null:gbContent.getBrand().getImg().getSrc(), "logoUrl");	
			CompareValuesUtility.addNewMultiValuedFields();
		}

		CompareValuesUtility.verifyNullOrEqual("mfr", rtContent.getMfgName()==null?null:rtContent.getMfgName(), gbContent.getMfr()==null?null:gbContent.getMfr().getName()==null?null:gbContent.getMfr().getName(), "name");
		CompareValuesUtility.verifyNullOrEqual("mfr", rtContent.getModelNbr()==null?null:rtContent.getModelNbr(), gbContent.getMfr()==null?null:gbContent.getMfr().getModelNo()==null?null:gbContent.getMfr().getModelNo(), "modelNo");
		CompareValuesUtility.addNewMultiValuedFields();

		MpCommon common = new MpCommon();
		if(rtContent.getPrdAttrList()!=null)
		{
			common.verifyFacetsRTGB(rtContent.getPrdAttrList(),gbContent, rtContent.getItemClassId().toString());
			CompareValuesUtility.addNewMultiValuedFields();

			common.verifySpecsGB(gbContent.getSpecs());
			CompareValuesUtility.addNewMultiValuedFields();
		}

		if(rtContent.getAssetList()!=null && gbContent.getAssets()!=null && gbContent.getAssets().getAttachments()!=null){
			verifyAssetAttachments(rtContent.getAssetList(), gbContent.getAssets().getAttachments());
			CompareValuesUtility.addNewMultiValuedFields();
		}

		System.out.println(rtContent.getItemClassId());

		verifyContentTaxonomy(rtContent.getItemClassId(),rtContent.getSiteList(),gbContent, firstOffer);

		CompareValuesUtility.verifyNullOrTrue("MatureContent", rtContent.getMatureCont()==null?null:rtContent.getMatureCont(), gbContent.getLegal()==null?null:gbContent.getLegal().getIsMatureContent()==null?null:gbContent.getLegal().getIsMatureContent());

		//check isdispelig=true when mfd is not set
		Boolean isMfd = (gbContent.getOperational().getIsMarkForDelete()!=null && gbContent.getOperational().getIsMarkForDelete()==true)?true:false;
		CompareValuesUtility.verifyNullOrEqual("isDispElg", isMfd?false:true, gbContent.getOperational()==null?null:gbContent.getOperational().getSites()==null?null:gbContent.getOperational().getSites().getSears()==null?null:gbContent.getOperational().getSites().getSears().getIsDispElig()==null?null:gbContent.getOperational().getSites().getSears().getIsDispElig());

		commonUtils.compareSeo(gbContent,false);
		CompareValuesUtility.addNewMultiValuedFields();

		CompareValuesUtility.verifyNullOrEqual("AltIds", spinId, gbContent.getAltIds()==null?null:gbContent.getAltIds().getSpinId()==null?null:gbContent.getAltIds().getSpinId(),"spinId");
		CompareValuesUtility.verifyNullOrEqual("AltIds", rtContent.getCoreHierarchy()==null?null:rtContent.getCoreHierarchy().getClassControlNumber()==null?null:rtContent.getCoreHierarchy().getClassControlNumber(), gbContent.getAltIds()==null?null:gbContent.getAltIds().getImaClassControlPid()==null?null:gbContent.getAltIds().getImaClassControlPid(),"imaClassControlPid");
		CompareValuesUtility.verifyNullOrEqual("ContentTimeChecker", JodaDateTimeUtility.convertUnixTSToTZFormat(msgDtm, "CST"), gbContent.getTimeChecker()==null?null:gbContent.getTimeChecker().getMpcontentofferUpdate()==null?null:gbContent.getTimeChecker().getMpcontentofferUpdate());
	}


	/**
	 * Verifies asset attachments
	 * @param productAsset
	 * @param attachments
	 */
	public void verifyAssetAttachments(List<com.generated.vos.proto.catalogcommons.Asset> asset,
			List<Attachment> attachments) { 

		SHCContentCommons commons = new SHCContentCommons();
		for(com.generated.vos.proto.catalogcommons.Asset attachmentAsset: asset){
			Boolean bFound = false;
			commons.convertType(attachmentAsset.getType().name());
			for(Attachment gbAttachment: attachments){

				if(attachmentAsset.getUrl().equals(gbAttachment.getLink().getAttrs().getHref()) && !commons.assetTypeGB.equals("PRODUCT_VIDEO") 
						&& commons.assetTypeGB.equals(gbAttachment.getType().toString())){
					bFound = true;
					CompareValuesUtility.verifyTrue(true, "AttchmtLinkHref", attachmentAsset.getUrl(), attachmentAsset.getUrl());
					CompareValuesUtility.verifyNullOrEqual("AttType", commons.assetTypeGB, gbAttachment.getType());
					if(commons.assetTypeGB.equals("MS"))
						CompareValuesUtility.verifyNullOrEqual("AttchmtName", attachmentAsset.getName(), gbAttachment.getName());
					else
						CompareValuesUtility.verifyNullOrEqual("AttchmtName", commons.assetName, gbAttachment.getName());
					if(commons.assetName!= null){
						if( commons.assetName.contains("Spanish"))
							CompareValuesUtility.verifyNullOrEqual("AttchLang", "Spanish", gbAttachment.getLang());
						else if(commons.assetName.contains("English"))
							CompareValuesUtility.verifyNullOrEqual("AttchLang", "English", gbAttachment.getLang());
					}
					break;
				}

			}
			if(!bFound){
				CompareValuesUtility.logFailed("AttchmtLinkHref", attachmentAsset.getUrl(), "Not found");
				CompareValuesUtility.logFailed("AttType", commons.assetTypeGB, "Not found");

			}
		}

	}

	public String getSiteName(String siteId) {
		if (siteId != null && ! siteId.equals("")) {
			switch (siteId) {
			case "1":
				return "kmart";
			case "2":
				return "sears";
			case "4":
				return "mygofer";
			case "5":
				return "kenmore";
			case "6":
				return "craftsman";
			case "11":
				return "puertorico";
			default:
				return null;
			}
		}
		return null;
	}

	private void verifyContentTaxonomy(Long itemClassID, List<com.generated.vos.proto.content.Site>siteList,com.generated.vos.content.Content gbContent, Offer firstOffer){
		
		// Get Valid Content Hierarchies
		Map<Long, List<String>> validContentHierarchies = getValidContentHierarchies(siteList);
		
		// replace all content hierarchies with first offer's hierarchies
		if (firstOffer != null) {
			Map<Long, List<String>> validOfferHierarchies = getValidOfferHierarchies(firstOffer.getSiteList());
			for(Long s : validOfferHierarchies.keySet()) {
				validContentHierarchies.put(s, validOfferHierarchies.get(s));
			}
		}
		
		com.generated.vos.content.Taxonomy taxonomy = gbContent.getTaxonomy();
		
		if (validContentHierarchies.size() == 0) {
			// Add code to check there is no web hierarchy in the content document
			CompareValuesUtility.verifyNullOrEqual("Content Hierarchy", null, taxonomy.getWeb(), "");
		} else {

			for(Long siteId : validContentHierarchies.keySet()) {
				if (siteId == 2) {
					commonUtils.compareWebhierarchyGB(validContentHierarchies, gbContent.getTaxonomy() == null? null : 
						gbContent.getTaxonomy().getWeb(),"Sears",false, true);
				}
				
				if (siteId == 1) {
					commonUtils.compareWebhierarchyGB(validContentHierarchies, gbContent.getTaxonomy() == null? null : 
						gbContent.getTaxonomy().getWeb(),"Kmart",false, true);
				}
			}
		}
		
		// Verify Master Hierarchy
		commonUtils.compareMasterhierarchyGB(itemClassID, gbContent.getTaxonomy() == null? null : gbContent.getTaxonomy().getMaster().getHierarchy(), true);
		
		/*		for ( com.generated.vos.proto.content.Site site : siteList) {

			long lSiteId = Long.parseLong(site.getId());
			List<String> lstHieararchyIds = new ArrayList<String>();
			for(com.generated.vos.proto.content.Hierarchy hierarchy : site.getTaxo().getHierList()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
			if(lSiteId==2)
				commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbContent.getTaxonomy() == null? null : 
					gbContent.getTaxonomy().getWeb(),"Sears",false, true);
			if(lSiteId==1)
				commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbContent.getTaxonomy() == null? null : 
					gbContent.getTaxonomy().getWeb(),"Kmart",false, true);	
		}

		commonUtils.compareMasterhierarchyGB(itemClassID, gbContent.getTaxonomy() == null? null : gbContent.getTaxonomy().getMaster().getHierarchy(), true);
		 */	
		}

	public Map<Long, List<String>> getValidOfferHierarchies(List<com.generated.vos.proto.offer.Site> siteList) {
		Map<Long, List<String>> expHierarchies = new HashMap<>();
		
		if (siteList != null && siteList.size() > 0) {
			for(com.generated.vos.proto.offer.Site site : siteList) {
				String siteId = site.getId();
				String siteName = getSiteName(siteId);

				if (siteId != null) {
					List<com.generated.vos.proto.offer.Hierarchy> hierList = site.getTaxo().getHierList();
					for (com.generated.vos.proto.offer.Hierarchy hierarchy : hierList) {
						String hierarchyId = hierarchy.getId();
						APIResponse<Object> obj = RestExecutor.getAllDataById(CollectionValuesVal.WEB_HIERARCHY, hierarchyId);
						com.generated.vos.hierarchy.Hierarchy hierarchyDoc = obj.getT();
						if (hierarchyDoc != null) {
							if (hierarchyDoc.getSite().equalsIgnoreCase(siteName)) {
								if (expHierarchies.containsKey(siteId)) {
									expHierarchies.get(siteId).add(hierarchyDoc.getId());
								} else {
									ArrayList<String> list = new ArrayList<>();
									list.add(hierarchyDoc.getId());
									expHierarchies.put(Long.parseLong(siteId), list);
								}
							}
						}
					}
				}
			}
		}
		return expHierarchies;
	}
	
	public Map<Long, List<String>> getValidContentHierarchies(List<Site> siteList) {
		Map<Long, List<String>> expHierarchies = new HashMap<>();
		
		if (siteList != null && siteList.size() > 0) {
			for(Site site : siteList) {
				String siteId = site.getId();
				String siteName = getSiteName(siteId);

				if (siteId != null) {
					List<com.generated.vos.proto.content.Hierarchy> hierList = site.getTaxo().getHierList();
					for (com.generated.vos.proto.content.Hierarchy hierarchy : hierList) {
						String hierarchyId = hierarchy.getId();
						APIResponse<Object> obj = RestExecutor.getAllDataById(CollectionValuesVal.WEB_HIERARCHY, hierarchyId);
						if (obj != null) {
							com.generated.vos.hierarchy.Hierarchy hierarchyDoc = obj.getT();
							if (hierarchyDoc != null && hierarchyDoc.getSite().equalsIgnoreCase(siteName)) {
								if (expHierarchies.containsKey(siteId)) {
									expHierarchies.get(siteId).add(hierarchyDoc.getId());
								} else {
									List<String> list = new ArrayList<>();
									list.add(hierarchyDoc.getId());
									expHierarchies.put(Long.parseLong(siteId), list);
								}
							}
						}
					}
				}
			}
		}
		return expHierarchies;
	}
	
	private void verifyOffer(String gbContentId, 
			List<Offer> rtOfferList,boolean isVariation, String pgrmType, String sellerId, Content rtContent){
		String offerId = null;
		String sellerDoc = null;
		String aggregatorId = null;
		String parentId = null;
		sellerDoc = RestExecutor.getJSonResponseById(CollectionValuesVal.SELLER, sellerId);
		if(!isVariation){
			Offer rtOffer = rtOfferList.get(0);
			switch(pgrmType){
			case "FBM":
			case "DSS":
				offerId  = "SPM" + rtOffer.getItemId().toString();
				parentId = TestUtils.generateFBMId(rtOffer.getItemId());
				break;
			case "FBS":
				offerId  = rtOffer.getDartPartNbr();
				parentId = rtOffer.getDartPartNbr();
				break;
			case "CPC":
				aggregatorId = JsonStringParser.getJsonValue(sellerDoc,"{_blob{seller{programs{cpc{aggregatorId}}}}}");
				offerId = TestUtils.generateCPCId(aggregatorId, sellerId, rtOffer.getItemId());
				parentId = TestUtils.generateCPCId(aggregatorId, sellerId, rtOffer.getItemId());
				break;
			}
			APIResponse<com.generated.vos.offer.Offer> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offerId);
			com.generated.vos.offer.Offer gbOffer = (com.generated.vos.offer.Offer)allResponse.getT();

			if(allResponse==null || gbOffer==null){
				CompareValuesUtility.logFailed("OfferId", offerId, " Not found in GB offer");	
			}else if(JodaDateTimeUtility.isFirstDateBeforeSecond(JodaDateTimeUtility.convertUnixTSToTZFormat(rtOffer.getTransDtm(), "CST"), gbOffer.getTimeChecker()==null?null:gbOffer.getTimeChecker().getMpcontentofferUpdate())){
				System.out.println("Skipping offer validation as TS in msg < timeChecker in GB offer for id: " + offerId);
			}else{
				verifyOfferdetails(allResponse,gbOffer,rtOffer, rtContent, isVariation,sellerDoc, sellerId,pgrmType,parentId,offerId);
			}

		}else{
			int iOfferNum = 0;
			for(Offer rtOffer : rtOfferList){
				if(!(iOfferNum == 0))
					CompareValuesUtility.addNewData();
				iOfferNum++;
				switch(pgrmType){
				case "FBM":
				case "DSS":
					offerId  = "SPM" + rtOffer.getItemId().toString();
					break;
				case "FBS":
					offerId  = rtOffer.getDartPartNbr();
					break;
				}
				parentId  = TestUtils.generateVariationId(sellerId,rtContent.getExternalGroupId(),pgrmType);
				APIResponse<com.generated.vos.offer.Offer> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offerId);
				com.generated.vos.offer.Offer gbOffer = (com.generated.vos.offer.Offer)allResponse.getT();

				if(allResponse==null || gbOffer==null){
					CompareValuesUtility.logFailed("OfferId", offerId, " Not found in GB offer");	
				}else if(JodaDateTimeUtility.isFirstDateBeforeSecond(JodaDateTimeUtility.convertUnixTSToTZFormat(rtOffer.getTransDtm(), "CST"), gbOffer.getTimeChecker()==null?null:gbOffer.getTimeChecker().getMpcontentofferUpdate())){
					System.out.println("Skipping offer validation as TS in msg < timeChecker in GB offer for id: " + offerId);
				}else{
					verifyOfferdetails(allResponse,gbOffer,rtOffer, rtContent, isVariation,sellerDoc, sellerId,pgrmType,parentId,offerId);
				}
			}
		}
	}
	private void verifyOfferdetails(APIResponse<com.generated.vos.offer.Offer> allResponse,com.generated.vos.offer.Offer gbOffer,Offer rtOffer, Content rtContent,boolean isVariation, String sellerDoc, String sellerId,String pgrmType, String parentId, String offerId){ 	
		CompareValuesUtility.logPassed("", "", "");
		System.out.println("Testing offer id: " + offerId);
		CompareValuesUtility.verifyNullOrEqual("OfferId", offerId==null?null:offerId, gbOffer.getId()==null?null:gbOffer.getId());
		CompareValuesUtility.addDataFieldForReport("offrlastModifiedBy", gbOffer.getMeta().getLastModifiedBy());

		CompareValuesUtility.verifyNullOrEqual("Name", rtContent.getTitle()==null?null:rtContent.getTitle(), gbOffer.getName()==null?null:gbOffer.getName());
		CompareValuesUtility.verifyNullOrEqual("Desc", rtContent.getMktgDesc()==null?null:rtContent.getMktgDesc(), gbOffer.getDesc()==null?null:gbOffer.getDesc());
		for (Site site : rtContent.getSiteList()){
			if(site.getId().toString().equalsIgnoreCase("2")){
				CompareValuesUtility.verifyNullOrEqual("Site", "sears", gbOffer.getSites()==null?null:gbOffer.getSites().get(0));	
			}
			if(site.getId().toString().equalsIgnoreCase("1")){
				if(gbOffer.getSites().size()>1)
					CompareValuesUtility.verifyNullOrEqual("Site", "kmart", gbOffer.getSites()==null?null:gbOffer.getSites().get(1));	
				if(gbOffer.getSites().size()==1)
					CompareValuesUtility.verifyNullOrEqual("Site", "kmart", gbOffer.getSites()==null?null:gbOffer.getSites().get(0));
			}
			if(site.getId().toString().equalsIgnoreCase("4")){
				if(gbOffer.getSites().size()==2)
					CompareValuesUtility.verifyNullOrEqual("Site", "mygofer", gbOffer.getSites()==null?null:gbOffer.getSites().get(1));
				if(gbOffer.getSites().size()>2)
					CompareValuesUtility.verifyNullOrEqual("Site", "mygofer", gbOffer.getSites()==null?null:gbOffer.getSites().get(2));
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

		//verifyAutomotiveOffer(gbOffer,rtContent);
		verifyAutomotiveOfferNew(gbOffer,rtContent,rtOffer);

		verifyAltrImages(rtContent, gbOffer.getAlternateImg());

		/*
			if(rtContent.getModelNbr() == null)
			   isFit = false;
			else
			   isFit = true;
		 */

		CompareValuesUtility.verifyNullOrEqual("ModelNo", rtOffer.getModelNbr()==null?(rtContent.getModelNbr()==null?null:rtContent.getModelNbr()):rtOffer.getModelNbr(), gbOffer.getModelNo()==null?null:gbOffer.getModelNo());
		CompareValuesUtility.verifyNullOrEqual("BrandName",rtContent.getBrand()==null?null:rtContent.getBrand().getName()==null?null:rtContent.getBrand().getName(), gbOffer.getBrandName()==null?null:gbOffer.getBrandName());

		CompareValuesUtility.verifyNullOrEqual("classification", rtOffer.getPrgm(), gbOffer.getClassifications().getIsMpPgmType(), "isMpPgmType");
		CompareValuesUtility.verifyNullOrEqual("classification", isVariation?"V":"NV", gbOffer.getClassifications().getOfferType(), "offerType");
		CompareValuesUtility.addNewMultiValuedFields();

		verifyLegal(gbOffer.getLegal(),rtOffer);
		CompareValuesUtility.addNewMultiValuedFields();

		CompareValuesUtility.verifyNullOrTrue("matureContent", rtContent.getMatureCont()==null?null:rtContent.getMatureCont(), gbOffer.getLegal()==null?null:gbOffer.getLegal().getIsMatureContent()==null?null:gbOffer.getLegal().getIsMatureContent());

		verifyCondition(gbOffer.getCondition(), rtOffer);
		CompareValuesUtility.addNewMultiValuedFields();
		if(isVariation){
			verifyDefiningAttr(rtOffer,gbOffer);
			CompareValuesUtility.addNewMultiValuedFields();
		}

		verifyImages(rtOffer,gbOffer.getMainImg(), gbOffer.getSwatchImg(), isVariation);
		CompareValuesUtility.addNewMultiValuedFields();
		verifyOfferTaxonomy(rtOffer.getItemClassId(),rtContent.getSiteList(),gbOffer);
		CompareValuesUtility.addNewMultiValuedFields();

		/*		if(rtOffer.getItemDimensions()!=null){
			verifyShipDetails(rtOffer, gbOffer);
		}
		 */
		if(gbOffer.getFfm()!=null && !(pgrmType.equals("CPC"))){
			verifyFFM(rtOffer,gbOffer,sellerId);
		}

		CompareValuesUtility.verifyNullOrEqual("Replenishment", rtOffer.getCoo(), gbOffer.getReplenishment()==null?null:gbOffer.getReplenishment().getCntryOfOrig(), "cntryOfOrig");

		verifyMarketplace(gbOffer.getMarketplace(),rtOffer ,rtContent);
		CompareValuesUtility.addNewMultiValuedFields();
		if(gbOffer.getMarketplace()!=null)
			CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getSellerId()==null?null:rtOffer.getSellerId().toString(), gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getSeller().getId().intValue(),"sellerId");

		if(sellerDoc!=null){
			String sellerName = JsonStringParser.getJsonValue(sellerDoc,"{_blob{seller{name}}}");
			CompareValuesUtility.verifyNullOrEqual("Marketplace", sellerName==null?null:sellerName, gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getSeller().getName(),"sellerName");
			//CompareValuesUtility.verifyNullOrEqual("Seller", rtOffer.getAggPdtId()==null?"0":rtOffer.getAggPdtId(), aggregatorId==null?null:aggregatorId,"aggrID");
		}
		if(pgrmType.equals("DSS"))
			CompareValuesUtility.verifyNullOrEqual("Marketplace",true, gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getSeller().getIsDirectSears(),"isDirectSears");				

		if(pgrmType.equals("FBS")){
			String pickPayFee =  JsonStringParser.getJsonValue(sellerDoc,"{_blob{seller{programs{fbs{pickAndPackFee}}}}}");
			CompareValuesUtility.verifyNullOrEqual("Marketplace", Double.valueOf(pickPayFee), gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getPickPayFee(),"pickPayFee");				
		}

		if(pgrmType.equals("CPC")){
			CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getItemUrl()==null?null:rtOffer.getItemUrl(),gbOffer.getMarketplace().getCpc()==null?null:gbOffer.getMarketplace().getCpc().getItemLink()==null?null:gbOffer.getMarketplace().getCpc().getItemLink().getAttrs().getHref(),"cpc.itemLink");
			CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getClickCaptureUrlsList().get(0).getUrl(), gbOffer.getMarketplace().getCpc()==null?null:gbOffer.getMarketplace().getCpc().getClickCaptureLink()==null?null:gbOffer.getMarketplace().getCpc().getClickCaptureLink().getAttrs().getHref(),"cpc.clickCaptureLink");
		}
		CompareValuesUtility.addNewMultiValuedFields();

		verifyGroceryAndDispTags(rtOffer,gbOffer, rtContent);
		CompareValuesUtility.addNewMultiValuedFields();
		if(!StringUtils.equals("CPC", pgrmType))
			CompareValuesUtility.verifyNullOrEqual("OfferAltIds", rtOffer.getSellerPrdId(), gbOffer.getAltIds().getVendorStockNo(), "vendorStockNo");
		CompareValuesUtility.verifyNullOrEqual("OfferAltIds", rtOffer.getItemId()==null?null:rtOffer.getItemId().toString(), gbOffer.getAltIds()==null?null:gbOffer.getAltIds().getSpinId()==null?null:gbOffer.getAltIds().getSpinId(),"spinId");
		CompareValuesUtility.verifyNullOrEqual("OfferAltIds", rtOffer.getUpc()==null?null:rtOffer.getUpc(), gbOffer.getAltIds()==null?null:gbOffer.getAltIds().getUpc()==null?null:gbOffer.getAltIds().getUpc(),"upc");
		CompareValuesUtility.verifyNullOrEqual("OfferAltIds", rtContent.getCoreHierarchy()==null?null:rtContent.getCoreHierarchy().getClassControlNumber()==null?null:rtContent.getCoreHierarchy().getClassControlNumber(), gbOffer.getAltIds()==null?null:gbOffer.getAltIds().getImaClassControlPid()==null?null:gbOffer.getAltIds().getImaClassControlPid(),"imaClassControlPid");
		CompareValuesUtility.addNewMultiValuedFields();

		if(pgrmType.equals("FBS"))
			CompareValuesUtility.verifyNullOrEqual("ffmElig",true,gbOffer.getFfmElig()==null?null:gbOffer.getFfmElig().getIsFbs()==null?null:gbOffer.getFfmElig().getIsFbs(),"isFbs");

		CompareValuesUtility.verifyNullOrEqual("ParentId", parentId==null?null:parentId, gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getParentId()==null?null:gbOffer.getIdentity().getParentId());

		CompareValuesUtility.verifyNullOrEqual("OfferTimeChecker", JodaDateTimeUtility.convertUnixTSToTZFormat(rtOffer.getTransDtm(), "CST"), gbOffer.getTimeChecker()==null?null:gbOffer.getTimeChecker().getMpcontentofferUpdate()==null?null:gbOffer.getTimeChecker().getMpcontentofferUpdate());

		if(allResponse!=null){
			verifyOfferSearch(allResponse, rtContent, rtOffer, parentId);
			CompareValuesUtility.addNewMultiValuedFields();
			verifyOfferFt(allResponse, isVariation, sellerId, rtOffer.getPrgm().toString());
			CompareValuesUtility.addNewMultiValuedFields();
		}
		if(rtContent.getCoreHierarchy()!=null && (pgrmType.equals("DSS"))){
			verifyCoreHierarchy(rtContent.getCoreHierarchy().getId(), gbOffer.getTaxonomy());
		}
		if(rtOffer.getItemClassTier()!=null){
			CompareValuesUtility.verifyNullOrEqual("Tier", rtOffer.getItemClassTier().getTierName()==null?null:rtOffer.getItemClassTier().getTierName(), gbOffer.getMarketplace()==null?null:gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getSeller().getTier().getName()==null?null:gbOffer.getMarketplace().getSeller().getTier().getName(),"name");
			CompareValuesUtility.verifyNullOrEqual("Tier", rtOffer.getItemClassTier().getScore()==null?null:rtOffer.getItemClassTier().getScore(), gbOffer.getMarketplace()==null?null:gbOffer.getMarketplace().getSeller()==null?null:gbOffer.getMarketplace().getSeller().getTier().getScore()==null?null:gbOffer.getMarketplace().getSeller().getTier().getScore(),"score");
		}

		if(rtOffer.getStateFeesList()!=null){
			List<String> fees =new ArrayList<String>();
			List<String> gbfees =new ArrayList<String>();
			for (StateFees stfee: rtOffer.getStateFeesList()){
				fees.add(stfee.getFeesType());
			}
			for (Fee stfee: gbOffer.getStFees().getFees()){
				gbfees.add(stfee.getType());
			}
			String[] stringArray = fees.toArray(new String[fees.size()]);
			String str1 = Arrays.toString(stringArray); 
			String[] gbArray = gbfees.toArray(new String[gbfees.size()]);
			String str2 = Arrays.toString(gbArray); 
			CompareValuesUtility.verifyNullOrEqual("StateFee", str1==null?null:str1, str2==null?null:str2);
		}
		if(rtOffer.getSkinnyOffer()!=null){
			CompareValuesUtility.verifyNullOrEqual("Ssin", rtOffer.getSsin()==null?null:rtOffer.getSsin(), gbOffer.getIdentity().getSsin()==null?null:gbOffer.getIdentity().getSsin());   

		}
		if(rtOffer.getRecycleFeeItemCount()!=null){
			CompareValuesUtility.verifyNullOrEqual("RecycleFeeCount", rtOffer.getRecycleFeeItemCount(), gbOffer.getRclFeeCnt()==null?null:gbOffer.getRclFeeCnt());   

		}
	}

	private void verifyCoreHierarchy(Integer coreHierId, Taxonomy taxo) {

		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, coreHierId+"");
		if(response!=null) {  
			if(taxo.getStore()!=null && taxo.getStore().getHierarchy()!=null){
				List<com.generated.vos.offer.Hierarchy> hierarchy= taxo.getStore().getHierarchy();

				List<String> lstPaths = new LinkedList<String>();
				List<String> lstids = new LinkedList<String>();


				String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");

				String idpath = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{path{idPath}}}}");

				name = name.replace("SRWI", "");
				name = name.replace("KWSC", "");

				lstPaths.addAll(Arrays.asList(name.split("-")));

				lstids.addAll(Arrays.asList(idpath.split("\\|")));

				if (lstPaths.isEmpty()) {
					CompareValuesUtility.verifyTrue(hierarchy.size() == 0, "store-taxo-id",
							"null", "Store Hierarchy should be null");
					CompareValuesUtility.verifyTrue(hierarchy.size() == 0,
							"store-taxo-name", "null", "Store Hierarchy should be null");
					return;
				}

				if (hierarchy.size() == 0) {
					CompareValuesUtility.logFailed("store-taxo-id", coreHierId, "StoreHierarchy is null");
					CompareValuesUtility.logFailed("store-taxo-name", coreHierId, "StoreHierarchy is null");
					return;
				}

				int iHierarchy = 0;

				for (com.generated.vos.offer.Hierarchy hrchy_ : hierarchy) 
				{
					compareValues("store-taxo-name", lstPaths.get(iHierarchy),hrchy_ == null ? null : hrchy_.getName());

					compareValues("store-taxo-id", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getId());

					compareValues("store-taxo-spinid", lstids.get(iHierarchy),hrchy_ == null ? null : hrchy_.getSpinId());

					iHierarchy++;
				}
			}else{
				CompareValuesUtility.logFailed("store-taxo-name", coreHierId, "StoreHierarchy is null");  
			}
			CompareValuesUtility.addNewMultiValuedFields();               
		}
	}

	private void verifyOfferTaxonomy(Long itemClassID, List<com.generated.vos.proto.content.Site>siteList,com.generated.vos.offer.Offer gbOffer){

		Map<Long, List<String>> mpSiteHiearachies = offerHierarchyMap.get(gbOffer.getAltIds().getSpinId());
		
		if (mpSiteHiearachies != null && mpSiteHiearachies.size() > 0) {
			for(Long siteId : mpSiteHiearachies.keySet()) {
				if(siteId==2)
					commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb(),"Sears",false);
				if(siteId==1)
					commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb(),"Kmart",false);

			}
		}
		
/*		for(com.generated.vos.proto.content.Site site : siteList) {
			long lSiteId = Long.parseLong(site.getId());
			List<String> lstHieararchyIds = new ArrayList<String>();
			for(com.generated.vos.proto.content.Hierarchy hierarchy : site.getTaxo().getHierList()){
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}
			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
			if(lSiteId==2)
				commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb(),"Sears",false);
			if(lSiteId==1)
				commonUtils.compareWebhierarchyGB(mpSiteHiearachies, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getWeb(),"Kmart",false);
		}
*/
		commonUtils.compareMasterhierarchyGB(itemClassID, gbOffer.getTaxonomy() == null? null : gbOffer.getTaxonomy().getMaster().getHierarchy());
	}

	private void verifyMarketplace(Marketplace gbOfrMkp, Offer rtOffer, Content rtContent) {
		CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getConfScore()==null?null:rtOffer.getConfScore().toString(), gbOfrMkp.getCatConfScore()==null?null:gbOfrMkp.getCatConfScore().toString(),"catConfScore");
		CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getSywRedElig()==null?null:rtOffer.getSywRedElig(), gbOfrMkp.getSywRdmElig()==null?null:gbOfrMkp.getSywRdmElig(),"sywRdmElig");
		CompareValuesUtility.verifyNullOrEqual("Marketplace", rtOffer.getPrgm(), gbOfrMkp.getProgramType()==null?null:gbOfrMkp.getProgramType(),"programType");

		if(rtContent.getCommRates()!=null){
			CompareValuesUtility.verifyNullOrEqual("Marketplace",rtContent.getCommRates().getDefRate(), gbOfrMkp.getCommission().getDefaultRate(),"DefCommRate");
			if(rtContent.getCommRates().getCommRateList()!=null){
				for(CommRate commRate : rtContent.getCommRates().getCommRateList()){
					if(commRate.getSiteId() == 2){
						CompareValuesUtility.verifyNullOrEqual("Marketplace",commRate.getRateVal(),gbOfrMkp.getCommission().getSears()== null?null:gbOfrMkp.getCommission().getSears().getRate(),"CommRateSr");
						continue;
					}
					if(commRate.getSiteId() == 4){
						CompareValuesUtility.verifyNullOrEqual("Marketplace",commRate.getRateVal(),gbOfrMkp.getCommission().getMygofer()== null?null:gbOfrMkp.getCommission().getMygofer().getRate(),"CommRateMg");
						continue;
					}
					if(commRate.getSiteId() == 1){
						CompareValuesUtility.verifyNullOrEqual("Marketplace",commRate.getRateVal(),gbOfrMkp.getCommission().getKmart()== null?null:gbOfrMkp.getCommission().getKmart().getRate(),"CommRateKm");
						continue;
					}
				}
			}else{
				CompareValuesUtility.verifyNull("Marketplace", gbOfrMkp.getCommission().getSears()== null?null:gbOfrMkp.getCommission().getSears().getRate(),"CommRateSr");
				CompareValuesUtility.verifyNull("Marketplace", gbOfrMkp.getCommission().getMygofer()== null?null:gbOfrMkp.getCommission().getMygofer().getRate(),"CommRateMg");
				CompareValuesUtility.verifyNull("Marketplace", gbOfrMkp.getCommission().getKmart()== null?null:gbOfrMkp.getCommission().getKmart().getRate(),"CommRateKm");
			}
		}
	}
	
	private void verifyShipDetails(Offer rtOffer, com.generated.vos.offer.Offer gbOffer ){

		CompareValuesUtility.verifyNullOrEqual("Shipping",rtOffer.getSaleTaxCd()==null?"89998":rtOffer.getSaleTaxCd(), gbOffer.getShipping().getTaxCode()==null?null:gbOffer.getShipping().getTaxCode().intValue(),"taxCode");
		CompareValuesUtility.verifyNullOrEqual("Shipping",rtOffer.getItemDimensions()==null?null:rtOffer.getItemDimensions().getHt()==null?null:rtOffer.getItemDimensions().getHt(), gbOffer.getShipping().getDimensions()==null?null:gbOffer.getShipping().getDimensions().getHeight()==null?null:gbOffer.getShipping().getDimensions().getHeight(),"height");
		CompareValuesUtility.verifyNullOrEqual("Shipping",rtOffer.getItemDimensions()==null?null:rtOffer.getItemDimensions().getWid()==null?null:rtOffer.getItemDimensions().getWid(), gbOffer.getShipping().getDimensions()==null?null:gbOffer.getShipping().getDimensions().getHeight()==null?null:gbOffer.getShipping().getDimensions().getWidth(),"width");
		CompareValuesUtility.verifyNullOrEqual("Shipping",rtOffer.getItemDimensions()==null?null:rtOffer.getItemDimensions().getLen()==null?null:rtOffer.getItemDimensions().getLen(), gbOffer.getShipping().getDimensions()==null?null:gbOffer.getShipping().getDimensions().getLength()==null?null:gbOffer.getShipping().getDimensions().getLength(),"length");
		CompareValuesUtility.verifyNullOrEqual("Shipping",rtOffer.getItemDimensions()==null?null:rtOffer.getItemDimensions().getWt()==null?null:rtOffer.getItemDimensions().getWt(), gbOffer.getShipping().getWeight()==null?null:gbOffer.getShipping().getWeight(),"weight");

		Dimensions dim = rtOffer.getItemDimensions();

		boolean isMailable = dim == null? true : 
			SpecificConditionsCheck.checkIsMailable(dim.getWt(), dim.getLen(), dim.getHt(), dim.getWid());

		compareValues("Shipping", isMailable, gbOffer.getShipping()==null?null:gbOffer.getShipping().getIsMailable()==null?null:gbOffer.getShipping().getIsMailable(),"isMailable");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFFM(Offer rtOffer, com.generated.vos.offer.Offer gbOffer , String sellerId ) {
		String sDunsNo = null;
		String warehouseLocations = null;
		String channel = "VD";
		Boolean isShipElig = true;
		String pgrmType=rtOffer.getPrgm().toString();
		Seller seller = RestExecutor.getDataById(CollectionValuesVal.MPSELLER, sellerId);

		if(pgrmType.equals("FBS")){
			channel = "TW";
		}else{
			if(seller!=null && 
					seller.getPrograms()!=null && 
					(seller.getPrograms().getFbm()!=null && seller.getPrograms().getFbm().getWareHouseLocations().isEmpty() || 
					seller.getPrograms().getDss()!=null && seller.getPrograms().getDss().getWareHouseLocations().isEmpty())){
				channel = "SPU";
				isShipElig = false;
			}
		}

		CompareValuesUtility.verifyNullOrEqual("FFM", channel==null?null:channel, gbOffer.getFfm().getChannel(),"channel");
		CompareValuesUtility.verifyNullOrEqual("FFM", isShipElig, gbOffer.getFfm().getIsShipElig(),"isShipElig");

		if(rtOffer.getStsElig()!=null && rtOffer.getStsElig()==true){
			CompareValuesUtility.verifyNullOrEqual("FFM", rtOffer.getStsElig()==null?null: rtOffer.getStsElig(), gbOffer.getFfm().getIsSTSElig()==null?null:gbOffer.getFfm().getIsSTSElig(),"STSElig");
			CompareValuesUtility.verifyNullOrEqual("FFM", "CVDS", gbOffer.getFfm().getSTSChannel()==null?null:gbOffer.getFfm().getSTSChannel(),"STSChannel");
		}
		CompareValuesUtility.verifyNullOrTrue("FFM", rtOffer.getFlags()==null?null:rtOffer.getFlags().getWebExclusive(), gbOffer.getFfm().getIsWebExcl()==null?null:gbOffer.getFfm().getIsWebExcl(),"isWebExclusive");

		if(seller!=null){
			if (pgrmType.equals("FBM"))
				sDunsNo = seller.getPrograms().getFbm().getDunsNumber();
			else if (pgrmType.equals("DSS"))
				sDunsNo = seller.getPrograms().getDss().getDunsNumber();
			else if (pgrmType.equals("FBS"))
				sDunsNo = seller.getPrograms().getFbs().getDunsNumber();

			String sSellerName = seller.getName();

			CompareValuesUtility.verifyNullOrEqual("FFM", sDunsNo==null?null:sDunsNo, gbOffer.getFfm().getVendorDunsNo(),"VndDunsNo");
			if (pgrmType.equals("DSS"))
				CompareValuesUtility.verifyNullOrEqual("FFM", "sears",gbOffer.getFfm()==null?null:gbOffer.getFfm().getSoldBy()==null?null:gbOffer.getFfm().getSoldBy(),"soldBy");
			else
				CompareValuesUtility.verifyNullOrEqual("FFM", sSellerName, gbOffer.getFfm()==null?null:gbOffer.getFfm().getSoldBy()==null?null:gbOffer.getFfm().getSoldBy(),"soldBy");

			if(pgrmType.equals("FBS"))
				CompareValuesUtility.verifyNullOrEqual("FFM", "sears", gbOffer.getFfm()==null?null:gbOffer.getFfm().getFulfilledBy()==null?null:gbOffer.getFfm().getFulfilledBy(),"fullfilledBy");
			else
				CompareValuesUtility.verifyNullOrEqual("FFM", sSellerName, gbOffer.getFfm()==null?null:gbOffer.getFfm().getFulfilledBy()==null?null:gbOffer.getFfm().getFulfilledBy(),"fullfilledBy");

			if(pgrmType.equals("FBS")){
				List<String>warehouse = new ArrayList<String>() ;
				for(WareHouseLocation_ ware: seller.getPrograms().getFbs().getWareHouseLocations()){
					warehouse.add(ware.getLocationId());	
				}
				CompareValuesUtility.verifyNullOrEqual("FFM", warehouse==null?null:warehouse,gbOffer.getFfm()==null?null:gbOffer.getFfm().getWrhsLcns()==null?null:gbOffer.getFfm().getWrhsLcns(),"WrhsLocations");
			}else{
				warehouseLocations = "["+sDunsNo+"]";
				CompareValuesUtility.verifyNullOrEqual("FFM", warehouseLocations==null?null:warehouseLocations,gbOffer.getFfm()==null?null:gbOffer.getFfm().getWrhsLcns()==null?null:gbOffer.getFfm().getWrhsLcns(),"WrhsLocations");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyOfferSearch(APIResponse<com.generated.vos.offer.Offer> allResponse,Content rtContent, Offer rtOffer, String parentId){
		CompareValuesUtility.verifyNullOrEqual("offer_search",rtOffer.getModelNbr()==null?(rtContent.getModelNbr()==null?null:rtContent.getModelNbr().replaceAll("[-_]", "").toUpperCase()):rtOffer.getModelNbr().replaceAll("[-_]", "").toUpperCase(), allResponse.getSearchFieldValue("model_no")==null?null:allResponse.getSearchFieldValue("model_no"),"Model_no");
		CompareValuesUtility.verifyNullOrEqual("offer_search",rtOffer.getUpc()==null?null:rtOffer.getUpc(),allResponse.getSearchFieldValue("upc")==null?null:allResponse.getSearchFieldValue("upc"),"Upc");
		if(rtOffer.getSkinnyOffer()!=null){
			if(allResponse.getSearchFieldValue("parentId")!=null){
				CompareValuesUtility.logFailed("offer_search", parentId, "Parent id should not be loaded","ParentId");	
			}
			CompareValuesUtility.verifyNullOrEqual("offer_search", rtOffer.getSsin()==null?null:rtOffer.getSsin(), allResponse.getSearchFieldValue("ssin")==null?null:allResponse.getSearchFieldValue("ssin"),"Ssin");		
		}else{
			CompareValuesUtility.verifyNullOrEqual("offer_search",parentId,allResponse.getSearchFieldValue("parentId")==null?null:allResponse.getSearchFieldValue("parentId"),"ParentId");
		}
		CompareValuesUtility.verifyNullOrEqual("offer_search",rtOffer.getItemId()==null?null:rtOffer.getItemId(),allResponse.getSearchFieldValue("spinId")==null?null:allResponse.getSearchFieldValue("spinId"),"SpinId");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyOfferFt(APIResponse<com.generated.vos.offer.Offer> allResponse, boolean isVariation, String sellerId, String programType){
		CompareValuesUtility.verifyNullOrEqual("Offer_ft",isVariation?"V":"NV",allResponse.getFtFieldValue("offerType")==null?null:allResponse.getFtFieldValue("offerType"),"OfferType");
		CompareValuesUtility.verifyNullOrEqual("Offer_ft",sellerId,allResponse.getFtFieldValue("sellerId")==null?null:allResponse.getFtFieldValue("sellerId"),"SellerId");
		CompareValuesUtility.verifyNullOrEqual("Offer_ft",programType,allResponse.getFtFieldValue("pgrmType")==null?null:allResponse.getFtFieldValue("pgrmType"),"PgrmType");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyImages(Offer rtoffOffer,List<MainImg> mainImg, List<SwatchImg> swatchImg, boolean isVariation){


		Image kafkaMainImg = rtoffOffer.getPrdImg();
		verifyMainImg(kafkaMainImg, mainImg);

		//Verify swatch image only if one of the variants has attribute type as swatch
		if (!isVariation)
			return;


		boolean bSwatchAttribFound = false;

		for(Attribute varAttri :rtoffOffer.getSkuAttributesList()){
			if(varAttri.getAttrType().name().equals(AttributeTypeType.SWATCH.value())){
				bSwatchAttribFound = true;
				break;
			}
		}

		if(!bSwatchAttribFound)
			return;

		//Only for variant items
		Image kafkaSwatchImage = rtoffOffer.getSwatchImg();
		if(kafkaSwatchImage != null){
			if(swatchImg.size() == 0)
				compareValues("SwatchImg", kafkaSwatchImage.getUrl(),"Not found");
			else{
				compareValues("SwatchImg", TestUtils.modifyImgURL(kafkaSwatchImage.getUrl()),swatchImg.get(0).getSrc(),"SwatchImgURL");
				compareValues("SwatchImg", kafkaSwatchImage.getHeight()==null?1000:kafkaSwatchImage.getHeight(),GenericUtil.convertToIntFromDouble(swatchImg.get(0).getHeight()),"SwatchHeight");
				compareValues("SwatchImg", kafkaSwatchImage.getWidth()==null?1000:kafkaSwatchImage.getWidth(),GenericUtil.convertToIntFromDouble(swatchImg.get(0).getWidth()),"SwatchWidth");
				CompareValuesUtility.addNewMultiValuedFields();
			}
		}

	}

	private void verifyMainImg(Image kafkaMainImg, List<MainImg> mainImg){
		if(kafkaMainImg != null){
			if(mainImg.size() == 0)
				CompareValuesUtility.verifyNullOrEqual("MainImg",kafkaMainImg.getUrl() ,"Not found");
			else{
				CompareValuesUtility.verifyNullOrEqual("MainImg", TestUtils.modifyImgURL(kafkaMainImg.getUrl()),mainImg.get(0).getSrc(),"Src");
				CompareValuesUtility.verifyNullOrEqual("MainImg", kafkaMainImg.getHeight()==null?1000:kafkaMainImg.getHeight(), GenericUtil.convertToIntFromDouble(mainImg.get(0).getHeight()),"Height");
				CompareValuesUtility.verifyNullOrEqual("MainImg", kafkaMainImg.getWidth()==null?1000:kafkaMainImg.getWidth(),GenericUtil.convertToIntFromDouble(mainImg.get(0).getWidth()),"Width");
				CompareValuesUtility.addNewMultiValuedFields();
			}

		}
	}


	private void verifyCondition(Condition condition , Offer rtOffer) {
		CompareValuesUtility.verifyNullOrEqual("Condition",rtOffer.getItemCondition()==null?null:rtOffer.getItemCondition().getTyp()==null?null:getConditionStatus(rtOffer.getItemCondition().getTyp()),condition==null?null:condition.getStatus()==null?null:condition.getStatus(),"status");
		CompareValuesUtility.verifyNullOrEqual("Condition",rtOffer.getItemCondition()==null?null:rtOffer.getItemCondition().getCmnt()==null?null:rtOffer.getItemCondition().getCmnt(), condition==null?null:condition.getComments()==null?null:condition.getComments(),"Comments");
		CompareValuesUtility.verifyNullOrEqual("Condition",rtOffer.getItemCondition()==null?null:rtOffer.getItemCondition().getImg()==null?null:rtOffer.getItemCondition().getImg().getUrl(), condition==null?null:condition.getImg()==null?null:condition.getImg().getSrc(),"ImgSrc");
		CompareValuesUtility.verifyNullOrEqual("Condition",rtOffer.getItemCondition()==null?null:rtOffer.getItemCondition().getImg()==null?null:rtOffer.getItemCondition().getImg().getWidth()==null?null:rtOffer.getItemCondition().getImg().getWidth().intValue(), condition==null?null:condition.getImg()==null?null:condition.getImg().getWidth()==null?null:condition.getImg().getWidth().intValue(),"ImgWidth");
		CompareValuesUtility.verifyNullOrEqual("Condition",rtOffer.getItemCondition()==null?null:rtOffer.getItemCondition().getImg()==null?null:rtOffer.getItemCondition().getImg().getHeight()==null?null:rtOffer.getItemCondition().getImg().getHeight().intValue(), condition==null?null:condition.getImg()==null?null:condition.getImg().getHeight()==null?null:condition.getImg().getHeight().intValue(),"ImgHeight");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private String getConditionStatus(ConditionType conditionType) {
		/*switch(conditionType.toString()){
			case "NEW": return null;
			case "REFURBISHED": return "Refurbished";
			case "USED_GENERAL": return "Used-General";
			case "USED_LIKE_NEW": return "Used-Like New";
			case "USED_VERY_GOOD": return "Used-Very Good";
			case "USED_GOOD": return "Used-Good";
			case "USED_ACCEPTABLE": return "Used-Acceptable";
			case "USED_POOR": return "Used-Poor";
		}*/

		if(conditionType.toString().equals("NEW"))
			return null;
		else
			return conditionType.toString();
	}

	private void verifyLegal(Legal legal, Offer rtOffer) {


		CompareValuesUtility.verifyNullOrTrue("Legal", rtOffer.getFlags()==null?null:rtOffer.getFlags().getHazardousMaterial()==null?null:rtOffer.getFlags().getHazardousMaterial(), legal==null?null:legal.getHazmatStorageCd(),"HazmatStrgCd:");
		CompareValuesUtility.verifyNullOrTrue("Legal", rtOffer.getFlags()==null?null:rtOffer.getFlags().getCaliforniaEmissions()==null?null:rtOffer.getFlags().getCaliforniaEmissions(),legal==null?null:legal.getIsCaEmmision(),"isCAEmsn?");
		CompareValuesUtility.verifyNullOrTrue("Legal", rtOffer.getFlags()==null?null:rtOffer.getFlags().getNowarning()==null?null:rtOffer.getFlags().getNowarning(), legal==null?null:legal.getIsNoWarning(),"isNoWarning?");
		CompareValuesUtility.verifyNullOrTrue("Legal", rtOffer.getFlags()==null?null:rtOffer.getFlags().getSafetyWarningOther()==null?null:rtOffer.getFlags().getSafetyWarningOther(), legal==null?null:legal.getSafetyWarnings(),"SafetyWarn");
		CompareValuesUtility.verifyNullOrEqual("Legal", rtOffer.getUsDotShipTyp()==null?null:rtOffer.getUsDotShipTyp()==rtOffer.getUsDotShipTyp().N?null:rtOffer.getUsDotShipTyp(), legal==null?null:legal.getUsDotType(),"USDotType");

		if(rtOffer.getGeoLimits()!=null){
			if(legal!=null && legal.getLimitedGeos()!=null){
				String geos = legal.getLimitedGeos().toString().replaceAll("\\s", "").trim();
				CompareValuesUtility.verifyNullOrEqual("Legal", rtOffer.getGeoLimits()==null?null:rtOffer.getGeoLimits().getStates().isEmpty()?null:"["+rtOffer.getGeoLimits().getStates().replaceAll("\\s", "").trim()+"]", geos,"limitedGeos");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

		if(rtOffer.getFlags()!=null 
				&& rtOffer.getFlags().getChokingHazards()!=null){

			if(rtOffer.getFlags().getChokingHazards().getContainsMarble())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Marble",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			if(rtOffer.getFlags().getChokingHazards().getContainsSmallBall())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Small Balls",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			if(rtOffer.getFlags().getChokingHazards().getBalloons())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Balloons",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			if(rtOffer.getFlags().getChokingHazards().getSmallBall())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Small Balls",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			if(rtOffer.getFlags().getChokingHazards().getSmallParts())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Contains Small Parts",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			if(rtOffer.getFlags().getChokingHazards().getOther())
				CompareValuesUtility.verifyItemInList("ChokingHazard","Choke Hazard - Other",legal==null?null:legal.getChokingHazards()==null?null:legal.getChokingHazards());
			CompareValuesUtility.addNewMultiValuedFields();
		}
	}

	private void verifyDefiningAttr(Offer rtOffer,com.generated.vos.offer.Offer gbOffer){
		for(com.generated.vos.proto.catalogcommons.Attribute attr: rtOffer.getSkuAttributesList()){
			String attrDoc = null;
			String attrValDoc = null;
			String attrName=null;
			String attrValName=null;
			String attrValFamilyName=null;

			if(attr.getId()!=null){
				attrDoc = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE, attr.getId().toString());
			}

			if(attrDoc!=null){
				attrName = JsonStringParser.getJsonValue(attrDoc,"{_blob{attribute{displayName}}}");
			}

			if(attr.getValueId()!=null){
				attrValDoc = RestExecutor.getJSonResponseById(CollectionValuesVal.ATTRIBUTE_VALUE, attr.getValueId().toString());
			}else{
				attrValName = attr.getValueFree()==null?attr.getValueFlag().toString():attr.getValueFree();
				attrValFamilyName = attrValName;
			}

			if(attrValDoc!=null){
				attrValName = JsonStringParser.getJsonValue(attrValDoc,"{_blob{attrvalue{displayName}}}");
				attrValFamilyName = attrValName;
			}

			if(attr.getTrademarkTxt()!=null){
				attrValName = attr.getTrademarkTxt();
			}

			for(DefiningAttr defattr : gbOffer.getDefiningAttrs()){
				if(defattr.getAttr().getId().equalsIgnoreCase(attr.getId().toString())){
					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attr.getId(), defattr.getAttr().getId(),"attrId");	
					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attr.getAttrType(), defattr.getAttr().getType(),"attrType");
					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attrName, defattr.getAttr().getName(),"attrName");

					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attr.getValueId()==null?attrValName:attr.getValueId(),
							defattr.getVal()==null?null:defattr.getVal().getId(),"attrValId");
					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attrValName==null?null:attrValName,
							defattr.getVal()==null?null:defattr.getVal().getName(),"attrValName");
					CompareValuesUtility.verifyNullOrEqual("DefiningAttr", attrValName==null?null:attrValFamilyName,
							defattr.getVal()==null?null:defattr.getVal().getFamilyName(),"attrValFamilyName");
				}
			}
		}

	}

	private void verifyGroceryAndDispTags(Offer rtOffer,com.generated.vos.offer.Offer gbOffer, Content rtContent){

		Boolean isEnergyStar = false;
		Boolean hasJewelry = false;
		String jewelryValue = null;
		if(rtContent.getPrdAttrList()!=null){
			for(Attribute prdattr : rtContent.getPrdAttrList()){
				if(prdattr.getId().toString().equals("1774")){
					if(prdattr.getValueId().toString().equals("19")){
						isEnergyStar = true;
					}
				}
				else if(prdattr.getId().toString().equals("797010")){
					if(prdattr.getValueFlag()){
						CompareValuesUtility.verifyNullOrEqual("grocery",true, gbOffer.getGrocery()==null?null:gbOffer.getGrocery().getIsPerishable(),"isPerishable");
					}
				}
				else if(prdattr.getId().toString().equals("781110")){
					if(prdattr.getValueId().toString().equals("19")){
						CompareValuesUtility.verifyNullOrEqual("grocery",true, gbOffer.getGrocery()==null?null:gbOffer.getGrocery().getIsAlcohol(),"isAlcohol");
					}
				}
				else if(prdattr.getId().toString().equals("250601")){
					if(prdattr.getValueId().toString().equals("19")){
						CompareValuesUtility.verifyNullOrEqual("grocery",true, gbOffer.getGrocery()==null?null:gbOffer.getGrocery().getIsRefrigeration(),"isRefrigeration");
					}
				}
				else if(prdattr.getId().toString().equals("796910")){
					if(prdattr.getValueFlag()){
						CompareValuesUtility.verifyNullOrEqual("grocery",true, gbOffer.getGrocery()==null?null:gbOffer.getGrocery().getIsFreezing(),"isFreezing");
					}
				}
				else if(prdattr.getId().toString().equals("796810")){
					if(prdattr.getValueFlag()){
						CompareValuesUtility.verifyNullOrEqual("grocery",true, gbOffer.getGrocery()==null?null:gbOffer.getGrocery().getIsTobacco(),"isTobacco");
					}
				}
				else if(prdattr.getId().toString().equals("30201")){
					hasJewelry = true;
					jewelryValue = prdattr.getValueId()==null?null:prdattr.getValueId().toString();
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}

		CompareValuesUtility.verifyNullOrTrue("dispTags", rtOffer.getFlags()==null?null:rtOffer.getFlags().getGoodHouseKeepingApprd(), gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsGhkApproved(),"isGhkApproved");
		CompareValuesUtility.verifyNullOrTrue("dispTags", rtOffer.getFlags()==null?null:rtOffer.getFlags().getGiftMessageElg(), gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsGiftMsgElig(),"isGiftMsgElig");
		CompareValuesUtility.verifyNullOrEqual("dispTags", !isEnergyStar?null:isEnergyStar, gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsEnergyStar(),"isEnergyStar");
		if(!StringUtils.equals(rtOffer.getPrgm().toString(), "CPC"))
			CompareValuesUtility.verifyNullOrEqual("dispTags", rtOffer.getSywRedElig()==null?null:rtOffer.getSywRedElig(), gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getSywRdmElig(),"sywRdmElig");
		CompareValuesUtility.verifyNullOrEqual("dispTags", rtContent.getTires()==null?null:(rtContent.getTires()?true:null), gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsTire(),"isTire");
		CompareValuesUtility.addNewMultiValuedFields();

		if(hasJewelry && jewelryValue!=null){
			if(jewelryValue.equals("2534") || jewelryValue.equals("666001")){
				CompareValuesUtility.verifyNullOrEqual("jewelry", "No Disclosure", 
						gbOffer.getLegal()==null?null:(gbOffer.getLegal().getJewelry()==null?null:gbOffer.getLegal().getJewelry().getDisclosure()));
			}else if(jewelryValue.equals("52")){
				CompareValuesUtility.verifyNullOrEqual("jewelry", "Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care", 
						gbOffer.getLegal()==null?null:(gbOffer.getLegal().getJewelry()==null?null:gbOffer.getLegal().getJewelry().getDisclosure()));
			}else if(jewelryValue.equals("53")){
				CompareValuesUtility.verifyNullOrEqual("jewelry", "Diamond weights may not be exact, but are never more than .05 carats below the stated weight", 
						gbOffer.getLegal()==null?null:(gbOffer.getLegal().getJewelry()==null?null:gbOffer.getLegal().getJewelry().getDisclosure()));
			}else if(jewelryValue.equals("84")){
				CompareValuesUtility.verifyNullOrEqual("jewelry", "Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight", 
						gbOffer.getLegal()==null?null:(gbOffer.getLegal().getJewelry()==null?null:gbOffer.getLegal().getJewelry().getDisclosure()));
			}
		}
	}
	/*
 private void verifyAutomotiveOffer(com.generated.vos.offer.Offer gbOffer, Content rtContent){
		if(rtContent.getPrdAttrList()!=null)
		{
			String brandCodeId = null;
			List<Attribute> actAttrs = rtContent.getPrdAttrList();
			Classifications classifications = gbOffer.getClassifications();
			for (Attribute attribute : actAttrs) {
				String attributeId = attribute.getId().toString();
				if(attributeId.toString().equals("873910")){
					brandCodeId = attribute.getValueFree();
					isBrandCodeFound=true;
				}
				if(attributeId.toString().equals("1035210")){
					switch(attribute.getValueId().toString()){
					case "2509410": case "92":{
						CompareValuesUtility.verifyNull("IsFitmentReq",classifications==null?null:classifications.getIsFitmentRequired());
						break;
					}

					case "2509310":{
						if(isFit && isBrandCodeFound == null){
							isBrandCodeFound = isBrandCodeIdFound(rtContent.getPrdAttrList());
							isFit = commonUtils.fitmentValidation(brandCodeId,rtContent.getModelNbr());
						}
						//If model number and brand both are present 
						if(isFit  && isBrandCodeFound){
							isFit = commonUtils.fitmentValidation(brandCodeId,rtContent.getModelNbr());
						}
						if(!isFit)
							isFit = null;

						CompareValuesUtility.verifyNullOrEqual("IsFitmentReq",isFit,classifications==null?null:classifications.getIsFitmentRequired());
						break;
					}
					}
					break;
				}
				if(isBrandCodeFound != null && isBrandCodeFound){
				verifyNullOrEqual("brandCodeId", attribute.getValueFree() ,gbOffer.getBrandCodeId());
				isBrandCodeFound=false;
				}
				//String pkgQty = attribute.getValueFree();
				//verifyNullOrEqual("packageQuantity", pkgQty ,gbOffer.getPackageQty);
			}	//End of checking all attributes	
		}
	}
	 */

	private void verifyAutomotiveOfferNew(com.generated.vos.offer.Offer gbOffer, Content rtContent, Offer rtOffer){
		if(rtContent.getPrdAttrList()!=null)
		{

			List<Attribute> actAttrs = rtContent.getPrdAttrList();
			Classifications classifications = gbOffer.getClassifications();

			if(brandCodeId==null){
				for (Attribute attribute : actAttrs) {
					String attributeId = attribute.getId().toString();
					if(attributeId.toString().equals("873910")){
						brandCodeId = attribute.getValueFree();
					}
				}
			}
			verifyNullOrEqual("brandCodeId", brandCodeId, gbOffer.getBrandCodeId());

			if(!isFitReqd){
				for (Attribute attribute : actAttrs) {
					String attributeId = attribute.getId().toString();
					if(attributeId.toString().equals("1035210")){
						switch(attribute.getValueId().toString()){
						case "2509410": 
						case "92":{
							isFitReqd = false;
							break;
						}
						case "2509310":{
							if(brandCodeId == null || rtContent.getModelNbr() == null){
								isFitReqd = false;
							}
							else{
								isFitReqd = commonUtils.fitmentValidation(brandCodeId, rtOffer.getModelNbr()==null?rtContent.getModelNbr():rtOffer.getModelNbr());
							}
							break;
						}
						}
						break;
					}
				}
			}
			CompareValuesUtility.verifyNullOrEqual("IsFitmentReq", !isFitReqd?null:isFitReqd, classifications==null?null:classifications.getIsFitmentRequired());
		}
	}
	/*
 private void verifyAutomotiveContent(com.generated.vos.content.Content gbContent, Content rtContent){
		if(rtContent.getPrdAttrList()!=null)
		{
			String brandCodeId = null;
			List<Attribute> actAttrs = rtContent.getPrdAttrList();
			Automotive automotive = gbContent.getAutomotive();
			for (Attribute attribute : actAttrs) {
				String attributeId = attribute.getId().toString();
				if(attributeId.toString().equals("873910")){
					brandCodeId = attribute.getValueFree();
					isBrandCodeFound=true;
				}
				if(attributeId.toString().equals("1035210")){
					switch(attribute.getValueId().toString()){
						case "2509410": 
						case "92": {
							CompareValuesUtility.verifyNull("IsFitmentReq",automotive==null?null:automotive.getIsFitmentRequired());
							break;
						}

					case "2509310":{
						if(isFit && isBrandCodeFound == null){
							isBrandCodeFound = isBrandCodeIdFound(rtContent.getPrdAttrList());
							isFit = commonUtils.fitmentValidation(brandCodeId, rtContent.getModelNbr());
						}
						//If model number and brand both are present 
						if(isFit  && isBrandCodeFound){
							isFit = commonUtils.fitmentValidation(brandCodeId, rtContent.getModelNbr());
						}
						if(!isFit)
							isFit = null;

						CompareValuesUtility.verifyNullOrEqual("IsFitmentReq",isFit,automotive==null?null:automotive.getIsFitmentRequired());
						break;
					}
					}
					break;
				}
				if(isBrandCodeFound)
					verifyNullOrEqual("brandCodeId", brandCodeId, automotive.getBrandCodeId()==null?null:automotive.getBrandCodeId());

				//String pkgQty = attribute.getValueFree();
				//verifyNullOrEqual("packageQuantity", pkgQty ,gbOffer.getPackageQty);
			}   //End of checking all attributes	
		}
	}
	 */
	/**
	 * Checks whether brandcodeid attribute is present
	 * 
	 * @param attrs
	 * @return
	 */

	public boolean isBrandCodeIdFound(List<Attribute> attrs) {

		for (Attribute attribute : attrs) {
			String attributeId = attribute.getId().toString();
			if (attributeId.equals("873910")) {
				return true;
			}
		}
		return false;
	}


	private void verifyAltrImages(Content rtContent,List<AlternateImg> altrImg){

		List<Image> kafkaAltrImg = rtContent.getFtrImgList();
		if(kafkaAltrImg!=null &&kafkaAltrImg.size()!=0){
			if(altrImg.size() == 0)
				CompareValuesUtility.verifyNullOrEqual("AltrImg",kafkaAltrImg.get(0).getUrl() ,"Not found");
			else{
				for(Image img: kafkaAltrImg){
					for(AlternateImg image: altrImg){
						if(TestUtils.modifyImgURL(img.getUrl()).equalsIgnoreCase(image.getSrc())){
							CompareValuesUtility.verifyNullOrEqual("AltrImg", TestUtils.modifyImgURL(img.getUrl()),image.getSrc(),"Src");
							CompareValuesUtility.verifyNullOrEqual("AltrImg", img.getHeight()==null?1000:img.getHeight(), GenericUtil.convertToIntFromDouble(image.getHeight()),"Height");
							CompareValuesUtility.verifyNullOrEqual("AltrImg", img.getWidth()==null?1000:img.getWidth(),GenericUtil.convertToIntFromDouble(image.getWidth()),"Width");
							CompareValuesUtility.addNewMultiValuedFields();
							break;
						}
					}
				}
			}

		}
	}

	private Long getContentMsgDtm(List<Offer> offerList){
		Long msgDtm = null;
		List<Long> dtmList = new ArrayList<>();
		for(Offer sellPoOfferObj : offerList){
			dtmList.add(sellPoOfferObj.getTransDtm());
		}
		Collections.reverse(dtmList);
		msgDtm = dtmList.get(0);
		return msgDtm;
	}


	/*private void verifyCompetitiveness(Offer rtOffer,com.generated.vos.offer.Offer gbOffer, Content rtContent, boolean isVariation) {

		CompetitivenessType cmt;
		if(rtOffer.getPrgm().equals("DSS")){
			if(!isVariation)
				cmt = rtContent.getc;
			else
				cmt = variantItem.getSpecificFbmsFieldsGroupVariation().getSpecificFbmsFieldsGroupVariationChoice().getDssPricing().getCompetitiveness();
		}
		else{
			if(bSingleProductOffer)
				cmt = specificFields.getSpecificFbmsFieldsGroupChoice().getPricing().getCompetitiveness();
			else
				cmt = variantItem.getSpecificFbmsFieldsGroupVariation().getSpecificFbmsFieldsGroupVariationChoice().getPricing().getCompetitiveness();
		}

		String xmlcmt =  "" ;
		if(cmt!=null){
			switch(cmt){
			case NON_COMPARED:{
				xmlcmt = "0";
				break;
			}
			case NEEDS_ATTENTION:{
				xmlcmt = "3";
				break;
			}
			case MARGINALLY_COMPETITIVE:{
				xmlcmt = "2";
				break;
			}
			case MOST_COMPETITIVE:{
				xmlcmt = "1";
				break;
			}
			}
			compareValues("cmt",xmlcmt , offerCmt);
		}

		else
			verifyNullOrEqual("cmt", null, offerCmt);
	}*/


}
