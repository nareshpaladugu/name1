package com.shi.content.wcsmigration.verifications;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class OfferTestCache {

	public static Map<String,Map<String,Boolean>> AttrValAndAttrAssocMap = new HashMap<String, Map<String,Boolean>>();

	public static boolean checkAttrAssoc(String attr,String attrVal)
	{
		Map<String, Boolean> innerMap = AttrValAndAttrAssocMap.get(attr);

		if(innerMap==null)
		{
			innerMap = new HashMap<String,Boolean>();
		}		

		if(innerMap.get(attrVal)==null)
		{
			boolean found = false;

			AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, attrVal);

			if(attrValsch!=null)
			{
				List<AttrId> lstIds = attrValsch.getAttrIds();
				for (AttrId attrId : lstIds) {

					if(attrId.getAttrId().equals(attr))
					{
						found = true;
						break;
					}
				}
			}
			innerMap.put(attrVal, found);

			AttrValAndAttrAssocMap.put(attr, innerMap);

		}
		return	AttrValAndAttrAssocMap.get(attr).get(attrVal);
	}

}
