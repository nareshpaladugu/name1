package com.shi.content.utilitytests;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.utils.EmailUtils;

/**
 * @author ddaphal
 *
 */
public class UpdateDbTest 
{

	private static int totalHomeServicesProducts;
	
	@Test(groups="chkAvailReqTest")
	public void chkAvailReqTest()
	{
		try
		{
			
			String offerIds = System.getProperty("offerIds","");
			//offerIds = "07071388292";
			
			MongoClient mongoClient = MongoDBClient.connectToMongoDB();

			DB db = mongoClient.getDB("offer");

			DBCollection dbCollection = db.getCollection("offer");

			BasicDBObject criteria = new BasicDBObject();
			
			if(offerIds!=null && !offerIds.isEmpty())
			{
				criteria.append("_blob.offer.id",new BasicDBObject("$in",offerIds.split(",")));
			}else
			{
				criteria.append("_blob.offer.classifications.offerType","HS");
			}
				
			
			DBCursor result = dbCollection.find(criteria);

			totalHomeServicesProducts = result.size();

			System.out.println("totalHomeServicesProducts .... "+totalHomeServicesProducts);

			BasicDBObject whatToSet = new BasicDBObject();
			
			BasicDBObject whatToUpdate = new BasicDBObject();
			
			Boolean value = Boolean.parseBoolean(System.getProperty("chkAvailReq","false"));
			
			whatToUpdate.append("_blob.offer.chkAvailReq",value);

			whatToSet.append("$set",whatToUpdate );
				
			dbCollection.update(criteria,whatToSet,false,true);
			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	@AfterClass(groups="GBCountUtility")
	public void result()
	{

		String sCustomeBody="<br><font face='Calibri' color='black' size='2'> Bucket No(s). : "
				+"<br>GB : "+LoadProperties.gbServer
				+"<br>Collection : offer"
				+"<br>Home Service Product Updated : "+totalHomeServicesProducts
				+ "<font face='Calibri' color='red' size='2'>" 
				+"<br><br><font face='Calibri' color='black' size='2'>";

		EmailUtils.sendEmail("Offer Update (chkAvailReq) ", sCustomeBody, null);

	}
}
