package com.shi.content.matching.acme;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.acme.ItemAuthorityTestCommon;

/**
 * @author ddaphal
 *
 */
public class MatchingTestACME 
{
	public static List<String> exceptionVerticals = null;
	public static boolean findMissingOffers = true;
	public static boolean printEmptySSINs = false;
	private static boolean goAhead = true;
	private static String goAheadError = null;

	public static boolean excludeVerticalFromMatching=Boolean.parseBoolean(System.getProperty("excludeVerticalFromMatching","false"));
	
	Set<String> SSINSet = Collections.synchronizedSet(new HashSet<String>());
	
	public static String LogMisClassAndContentScore="false";
	
	@Test(dataProvider="sourceIdProvider",groups="MatchingTestACME")
	public void itemAuthorityTest(Set<String> IDs, Integer pageNumber, Integer pageSize)
	{
		LogMisClassAndContentScore=System.getProperty("LogMisClassAndContentScore", "false");
		System.out.println("LogMisClassAndContentScore.... "+LogMisClassAndContentScore);
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("AUTO_FETCH"))
		{
			IDs = new HashSet<String>();

			String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled?page-size="+pageSize+"&page="+pageNumber;
			if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH")){
				String sSubUrl = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
				if(sSubUrl == null)
				{
					goAheadError = "Incorrect runparam";
					goAhead=false;
				}else
					sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled"+sSubUrl+"&page-size="+pageSize+"&page="+pageNumber;
			}else{

				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled?page-size="+pageSize+"&page="+pageNumber;
			}

			if(goAhead){

				String jsonResponse = RestExecutor.getJSonResponse(sUrl);
				try{
					String ids = JsonStringParser.getJsonValue(jsonResponse, "{items{ssin}}",",");

					if(ids==null || ids.isEmpty())
					{
						//ignore if id null or empty
						return;
					}
					String spSourceids[] = ids.split(",");

					for (String ssin : spSourceids) {

						if(!SSINSet.contains(ssin))
						{
							pool.execute(new MatchingValidationACME(ssin));
							SSINSet.add(ssin);
						}
					}
				}catch(Exception e){
					System.out.println("Response "+ jsonResponse);
					throw e;
				}
			}
		}
		else
		{
			System.out.println("Size of Source IDs list ... "+IDs.size());

			for (String id : IDs) 
			{
				if(id!=null && !id.isEmpty() )
				{
					pool.execute(new MatchingValidationACME(id.trim()));
				}
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}


		if(goAheadError!=null)
			LoadProperties.setCustomMsgForEmail(goAheadError,MSGTYPE.ERROR);
	}

	/**
	 * Supported mode
	 * SOURCE
	 * SOURCE-FileMode
	 * AUTO_FETCH
	 * @return
	 */
	@DataProvider(name="sourceIdProvider", parallel=true)
	public Object[][] sourceIdProvider()
	{
		Set<String> idsList = new java.util.HashSet<String>();
		String sSourceIds = LoadProperties.RUN_PARAMS;

		Integer pageSize = null, pageNumber = null;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE")) {
			idsList.addAll(Arrays.asList(sSourceIds.split(",")));
			return new Object[][] { { idsList, pageSize, pageNumber } };
		}
		else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE-FileMode"))
		{
			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");
			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty() )
					{
						idsList.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
			return new Object[][] { { idsList, pageSize, pageNumber } };

		}
		else if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("AUTO_FETCH") || LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH"))
		{
			int expectedLimit;

			try {
				expectedLimit = LoadProperties.TESTDATALIMIT;
			} catch (NumberFormatException e1) {
				expectedLimit = -1;
				System.out.println("Setting expected limit to entire source collection");
			}

			String sUrl = null;
			String sSubURL = null;
			if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("SOURCE_AUTO_FETCH"))
			{
				sSubURL = ItemAuthorityTestCommon.getSubUrlForSourceAutoFetchMode();
				if(sSubURL != null)
					sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled"+sSubURL+"&count";
				else{
					goAheadError = "Incorrect runparam";
					goAhead=false;
					return null;
				}

			}else{
				sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled?count";
			}

			String jsonResponse = RestExecutor.getJSonResponse(sUrl);
			String totalSourceCountValue = JsonStringParser.getJsonValue(jsonResponse, "{count}");
			Integer totalSourceCount = 0;
			if(totalSourceCount != null){
				totalSourceCount = Integer.parseInt(totalSourceCountValue);
			}

			int totalPages = 0;
			int lastPageSize = 0;
			if(expectedLimit == -1){
				pageSize =  100;
				totalPages = totalSourceCount/pageSize;
				lastPageSize = totalSourceCount%pageSize;
				if(totalSourceCount%pageSize == 0)
					totalPages--;

			}
			else{
				pageSize = 100;

				if(expectedLimit > totalSourceCount){
					expectedLimit = totalSourceCount;
				}
				if(expectedLimit <= pageSize){
					pageSize = expectedLimit;
					totalPages = 0;
				}
				else{
					totalPages = expectedLimit/pageSize;
					lastPageSize = expectedLimit%pageSize;
					if(expectedLimit%pageSize == 0)
						totalPages--;

				}
			}
			System.out.println( "--------Total sources : "+ totalSourceCount + " Pages to hit :"+ totalPages + "  PageSize : "+ pageSize);
			Object[][] toSend = new Object[totalPages+1][3];
			for(int i = 0 ; i < totalPages; i++){
				toSend[i] = new Object[]{null, i, pageSize};
			}
			toSend[totalPages] = new Object[]{null,totalPages, (lastPageSize == 0? pageSize:lastPageSize)};
			return toSend;

		} else {
			goAhead  = false;
			goAheadError = "Unsupported Execution Mode";
		}
		return null;
	}

	@BeforeSuite(groups="MatchingTestACME")
	public void beforeSetting()
	{
		printEmptySSINs = Boolean.parseBoolean(System.getProperty("printEmptySSINs","false"));
		exceptionVerticals = Arrays.asList(System.getProperty("exceptionVerticals","8").split(","));
		findMissingOffers = Boolean.parseBoolean(System.getProperty("findMissingOffers","true"));
		System.out.println("----------------------------------------------------------");
		System.out.println("exceptionVerticals			 : "+exceptionVerticals);
		System.out.println("findMissingOffers			 : "+findMissingOffers);
		System.out.println("excludeVerticalFromMatching  : "+excludeVerticalFromMatching);
		System.out.println("----------------------------------------------------------");
		
	}
	
	@AfterSuite(groups="MatchingTestACME")
	public void after()
	{
		LoadProperties.setCustomMsgForEmail("Exclude Vertical From Matching Flag : "+excludeVerticalFromMatching );
	}
}
