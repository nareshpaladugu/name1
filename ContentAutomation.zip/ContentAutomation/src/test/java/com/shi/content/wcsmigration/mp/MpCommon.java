package com.shi.content.wcsmigration.mp;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Static;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Label;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;

public class MpCommon {

	String sSiteToTest="Sears";
	
	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	List<String> lstAttributeVals = new ArrayList<String>();
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	List<String>  lstAttribsNotFound = new ArrayList<>();
	String brandCodeId = null, autoFitmentType = null;
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });

	public void verifySpecsGB(List<Spec> specsXML) {

		if(masterHierarchyAttributes == null){
			return;
		}

		if(lstSpecAttributes.isEmpty()){
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecVal", "No specs expected", "Specs found");

			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstSpecAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		verifySpecValues(attributeData, attributeValData, specsXML);

	}

	public void verifySpecValues(Map<String, String> attribData,  Map<String, String> attribValData,List<Spec> specsXML)
	{
		for(String attributeId : lstSpecAttributes)
		{
			String grpNameIA = attributeToGroup.get(attributeId)==null?"Others:":attributeToGroup.get(attributeId);
			boolean bAttributeFound = false;
			boolean bGroupFound = false;
			boolean bAttrValueFound = false;
			boolean bIsDoNotDisplaySpecFound = false;
			String displayEligibility = GreenBoxCache.isDoNotDisplay(attributeId);
			for (Spec spec : specsXML) {
				String grpNameJson = spec.getGrpName();
				if(grpNameIA.equals(grpNameJson)){
					bGroupFound = true;
					for(Attr attr : spec.getAttrs()){

						if(displayEligibility!= null && attr.getName().equals(displayEligibility)){
							bIsDoNotDisplaySpecFound = true;
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName",displayEligibility+ ": Do not display set("+attributeId+").  Attribute should not be in specs.", attr.getName() + " found in specs");
							break;
						}
						//Checking to prevent it getting printed everytime the same attribute is found 
						if (attr.getName().equals(attribData.get(attributeId))){
							if(!bAttributeFound){
								CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
								bAttributeFound = true;
								CompareValuesUtility.logPassed("SpecName",attribData.get(attributeId), attr.getName());
							}

							boolean bRes;
							try {
								bRes = bAttributeFound && 
										(attributeToVal.get(attributeId).equals(attr.getVal()) 
												||	TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()) || TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()));
							} catch (Exception e) {
								bRes = false;
							}

							if(bRes){
								bAttrValueFound = true;

								if(attributeToVal.get(attributeId).equals(attr.getVal())){
									CompareValuesUtility.logPassed("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}else
								{
									if(TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal", TestUtils.encodeHTML(attributeToVal.get(attributeId)) , attr.getVal());

									else if (TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()))
										CompareValuesUtility.logPassed("SpecVal",TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))) , attr.getVal());
								}
								break;
							}
						}
					}

					//If attribute is donotdisplay type and is not displayed, mark as passed
					if(displayEligibility!= null && !bIsDoNotDisplaySpecFound){
						CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
						CompareValuesUtility.logPassed("SpecName", attributeId+":"+displayEligibility, "Do not display set.Not found in specs.");
					}
					//Do the following checks only for displayable attributes
					if(displayEligibility == null){
						if(!bAttributeFound){
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
						}
						if(bAttributeFound && !bAttrValueFound){
							CompareValuesUtility.logFailed("SpecVal", attributeToVal.get(attributeId), "Not found");
						}
					}
					break;
				}
			}

			if(!bAttributeFound && !bGroupFound)
				CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	Attrs masterHierarchyAttributes;
	
	public void verifyFacetsGB( com.generated.vos.catdelta.Attributes attrs,Content content,String itemClassId)
	{
		if(attrs.getAttribute()==null)
			return;

		masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
		if(masterHierarchyAttributes == null){
			CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
			return;
		}

		segregateAttributes(attrs.getAttribute());

		if(lstFacetAttributes.isEmpty()){
			CompareValuesUtility.verifyNull("FacetName", content.getFacets());
			CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		List<Static> staticFacets=null;

		String val ;

		if(sSiteToTest.equalsIgnoreCase("sears"))
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getKmart().getStatic();

		for(String facetAttributeId : lstFacetAttributes){
			boolean bFound = false;
			boolean bAttrValueFound = false;
			if(staticFacets ==  null){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found");
				continue;
			}
			for(Static gbFacet : staticFacets){
				if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
					if(!bFound){
						bFound = true;
						CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId));
					}

					val = attributeValData.get(attributeToVal.get(facetAttributeId));
					val= val==null?"null":val;

					if(bFound &&
							(attributeToVal.get(facetAttributeId).equals(gbFacet.getValue())
									|| val.equals(gbFacet.getValue())))
					{
						bAttrValueFound = true;
						if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
							compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue());
						else //free value
							compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue());
						break;
					}
				}
			}
			if(!bFound){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found");
			}

			if(!bAttrValueFound){
				CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found");
			}
		}
	}


	public void verifyFacetsRTGB(List<com.generated.vos.proto.catalogcommons.Attribute> attrs,Content content,String itemClassId)
	{
		if(attrs.isEmpty())
			return;

		masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
		if(masterHierarchyAttributes == null){
			CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
			return;
		}

		segregateAttributesRT(attrs);

		if(lstFacetAttributes.isEmpty()){
			CompareValuesUtility.verifyNull("FacetName", content.getFacets());
			CompareValuesUtility.verifyNull("FacetVal", content.getFacets());
			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		List<Static> staticFacets=null;

		String val ;

		if(sSiteToTest.equalsIgnoreCase("sears"))
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
		else if(sSiteToTest.equalsIgnoreCase("kmart"))
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getKmart().getStatic();

		for(String facetAttributeId : lstFacetAttributes){
			boolean bFound = false;
			boolean bAttrValueFound = false;
			if(staticFacets ==  null){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found");
				continue;
			}
			for(Static gbFacet : staticFacets){
				if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
					if(!bFound){
						bFound = true;
						CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId));
					}

					val = attributeValData.get(attributeToVal.get(facetAttributeId));
					val= val==null?"null":val;

					if(bFound &&
							(attributeToVal.get(facetAttributeId).equals(gbFacet.getValue())
									|| val.equals(gbFacet.getValue())))
					{
						bAttrValueFound = true;
						if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
							compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue());
						else //free value
							compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue());
						break;
					}
				}
			}
			if(!bFound){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found");
			}

			if(!bAttrValueFound){
				CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found");
			}
		}
	}
	
	
	
	private void segregateAttributesRT(  List<com.generated.vos.proto.catalogcommons.Attribute> attributes){


		Integer iCheckValId;
		String sAttrId;
		String sValFree;
		String valueFlag;
		String sValId;
		boolean foundCheck;

		for(com.generated.vos.proto.catalogcommons.Attribute attribute : attributes )
		{
			sAttrId = String.valueOf(attribute.getId().intValue());
			
			try {
				if(! attribute.getValueFlag())
				{
					System.out.println("Attribute "+sAttrId+" attribute-value-flag = false");
					continue;
				}
			} catch (Exception e1) {
			}
			
			foundCheck  = false;
			try 
			{
				try {
					iCheckValId = attribute.getValueId().intValue();
				} catch (Exception e) {

					iCheckValId =null;
				}

				if(iCheckValId!=null)
				{
					AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, iCheckValId+"");

					//System.out.println("attrValsch.......... "+attrValsch);
					if(attrValsch==null)
					{
						//System.out.println("Attribute "+sAttrId+" Value id "+iCheckValId +" attrvalue resp is null");
						continue;
					}
					else
					{
						List<AttrId> allattrids = attrValsch.getAttrIds();

						for (AttrId attrId : allattrids) {

							if(attrId.getAttrId().equals(sAttrId))
							{
								foundCheck = true;
								break;
							}
						}

						if(!foundCheck)
						{
							//System.out.println("Attribute "+sAttrId+" is not associate with value "+iCheckValId +" hence skipping");
							continue;
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();

			}


			sValFree =  attribute.getValueFree();

			valueFlag = String.valueOf( attribute.getValueFlag());

			try {
				sValId =String.valueOf( attribute.getValueId());
			} catch (Exception e) {
				sValId = null;
			}

			if(autoIds.contains(sAttrId)){
				if(sAttrId.equals("873910")){
					brandCodeId = sValFree;
				}
				if(sAttrId.equals("1035210")){
					switch(sValId){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}

					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(sAttrId) )
				continue;
			boolean bFound = false;

			//label is array
			for(Label label : masterHierarchyAttributes.getLabels())
			{
				//each label has attr array again
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs())
				{
					if(sAttrId.equals(attr.getId()) && (attr.getType().contains("search") 
							|| attr.getType().contains("label")))
					{

						bFound = true;
						if(attr.getType().contains("search"))
							lstFacetAttributes.add(sAttrId);
						if( attr.getType().contains("label")){
							lstSpecAttributes.add(sAttrId);
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());

						}
						attributeToGroup.put(sAttrId, label.getName());

						if(sValId != null)
							lstAttributeVals.add(sValId);

						//Commenting td text - ECOM-361803

						/*if(attributeXML.getTrademarkText() != null){
							attributeToVal.put(sAttrId, attributeXML.getTrademarkText());
						}
						else 
						 */


						if( sValFree != null)
							attributeToVal.put(sAttrId, sValFree);
						else if(valueFlag != null && !valueFlag .equals("null"))
							attributeToVal.put(sAttrId, valueFlag.toString());
						else if(sValId != null){
							lstAttributeVals.add(sValId);
							attributeToVal.put(sAttrId, sValId);
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
							//							throw new IllegalArgumentException("No attribute val data found");

							break;
					}

				}
				if(bFound)
					break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(sAttrId);
			}
		}
	}
	
	private void segregateAttributes(  com.generated.vos.catdelta.Attribute[] attributes){


		Integer iCheckValId;
		String sAttrId;
		String sValFree;
		String valueFlag;
		String sValId;
		boolean foundCheck;

		for(com.generated.vos.catdelta.Attribute attribute : attributes )
		{
			sAttrId = String.valueOf(attribute.getItemAttributeGroup().getAttributeId().intValue());
			
			try {
				if(! attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag())
				{
					System.out.println("Attribute "+sAttrId+" attribute-value-flag = false");
					continue;
				}
			} catch (Exception e1) {
			}
			
			foundCheck  = false;
			try 
			{
				try {
					iCheckValId = attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId().intValue();
				} catch (Exception e) {

					iCheckValId =null;
				}

				if(iCheckValId!=null)
				{
					AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, iCheckValId+"");

					//System.out.println("attrValsch.......... "+attrValsch);
					if(attrValsch==null)
					{
						//System.out.println("Attribute "+sAttrId+" Value id "+iCheckValId +" attrvalue resp is null");
						continue;
					}
					else
					{
						List<AttrId> allattrids = attrValsch.getAttrIds();

						for (AttrId attrId : allattrids) {

							if(attrId.getAttrId().equals(sAttrId))
							{
								foundCheck = true;
								break;
							}
						}

						if(!foundCheck)
						{
							//System.out.println("Attribute "+sAttrId+" is not associate with value "+iCheckValId +" hence skipping");
							continue;
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();

			}


			sValFree =  attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFree();

			valueFlag = String.valueOf( attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueFlag());

			try {
				sValId =String.valueOf( attribute.getItemAttributeGroup().getItemAttributeGroupChoice().getAttributeValueId());
			} catch (Exception e) {
				sValId = null;
			}

			if(autoIds.contains(sAttrId)){
				if(sAttrId.equals("873910")){
					brandCodeId = sValFree;
				}
				if(sAttrId.equals("1035210")){
					switch(sValId){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}

					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(sAttrId) )
				continue;
			boolean bFound = false;

			//label is array
			for(Label label : masterHierarchyAttributes.getLabels())
			{
				//each label has attr array again
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs())
				{
					if(sAttrId.equals(attr.getId()) && (attr.getType().contains("search") 
							|| attr.getType().contains("label")))
					{

						bFound = true;
						if(attr.getType().contains("search"))
							lstFacetAttributes.add(sAttrId);
						if( attr.getType().contains("label")){
							lstSpecAttributes.add(sAttrId);
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());

						}
						attributeToGroup.put(sAttrId, label.getName());

						if(sValId != null)
							lstAttributeVals.add(sValId);

						//Commenting td text - ECOM-361803

						/*if(attributeXML.getTrademarkText() != null){
							attributeToVal.put(sAttrId, attributeXML.getTrademarkText());
						}
						else 
						 */


						if( sValFree != null)
							attributeToVal.put(sAttrId, sValFree);
						else if(valueFlag != null && !valueFlag .equals("null"))
							attributeToVal.put(sAttrId, valueFlag.toString());
						else if(sValId != null){
							lstAttributeVals.add(sValId);
							attributeToVal.put(sAttrId, sValId);
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
							//							throw new IllegalArgumentException("No attribute val data found");

							break;
					}

				}
				if(bFound)
					break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(sAttrId);
			}
		}
	}


}
