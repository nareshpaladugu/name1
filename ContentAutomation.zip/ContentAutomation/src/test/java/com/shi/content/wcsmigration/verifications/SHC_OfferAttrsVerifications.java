package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.logFailed;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.hierarchy.Path;
import com.generated.vos.offer.Offer;
import com.generated.vos.offerattrs.Hrchy;
import com.generated.vos.offerattrs.Hrchy_;
import com.generated.vos.offerattrs.Offerattrs;
import com.generated.vos.offerattrs.OfferattrsSchema;
import com.generated.vos.offerattrs.PrimHrchy;
import com.generated.vos.offerattrs.Sites_;
import com.generated.vos.productoffering.Attribute;
import com.generated.vos.productoffering.OfferingIndicatorsGroup;
import com.generated.vos.productoffering.OperationalAttribute;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.ShipDimension;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.Source;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.VendorPack;
import com.generated.vos.productoffering.types.UpcTypeType;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.wcsmigration.tests.SHC_OfferAttrsLoadTest;


/**
 * @author ddaphal
 *
 */
public class SHC_OfferAttrsVerifications implements Runnable
{
	Boolean bSingleProductOffer = true;
	private SingleProductOffer singleProductOffer;
	private  VariationProductOffer varProdOffer;
	private String siteToTest;
	ProductContent prodContent;
	String sItemClassId;
	String parentId;
	public SHC_OfferAttrsVerifications(SingleProductOffer wNodeListToTest, VariationProductOffer varProdOffer,String siteToTest,	String sItemClassId)
	{
		this.singleProductOffer=wNodeListToTest;
		this.varProdOffer=varProdOffer;
		this.siteToTest=siteToTest;
		if (wNodeListToTest == null) {
			bSingleProductOffer = false;
		}

		this.	 sItemClassId=	 sItemClassId;
	}
	String partNumberToTest=null;
	public void run() 
	{
		if(bSingleProductOffer)
		{
			if (siteToTest.equalsIgnoreCase("sears")) {
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getSearsPartNumber();

			} else {
				partNumberToTest = singleProductOffer.getProductOfferings()
						.getProductOffer(0).getPartNumber()
						.getKmartPartNumber();
			}

			prodContent = singleProductOffer.getProductContent();

			parentId = partNumberToTest + "P";

			if (SHC_OfferAttrsLoadTest.erroredPartNumbers.contains(partNumberToTest)
					|| SHC_OfferAttrsLoadTest.erroredPartNumbers.contains(parentId)) {
				System.out.println("Skipping  " + partNumberToTest);
				return;
			}

			testUsingPartNumber(singleProductOffer.getProductOfferings()
					.getProductOffer(0),partNumberToTest);
		}
		else
		{
			ProductOffer[]  prodOffers = varProdOffer.getProductOfferings()
					.getProductOffer();

			for (ProductOffer productOffer : prodOffers) {

				partNumberToTest = (siteToTest.equalsIgnoreCase("sears") ? productOffer
						.getPartNumber().getSearsPartNumber() : productOffer
						.getPartNumber().getKmartPartNumber());

				if (siteToTest.equalsIgnoreCase("sears")) {
					parentId = varProdOffer.getVariationSearsPartNumber() + "P";
				} else {
					parentId = varProdOffer.getVariationKmartPartNumber() + "P";
				}

				if (SHC_OfferAttrsLoadTest.erroredPartNumbers.contains(partNumberToTest)
						|| SHC_OfferAttrsLoadTest.erroredPartNumbers.contains(parentId)) {
					System.out.println("Skipping  " + partNumberToTest);
					return;
				}

				prodContent = varProdOffer.getProductContent();

				testUsingPartNumber(productOffer,partNumberToTest);

			}
		}


	}

	private void web(ProductOffer xmlProductOffer,	Offerattrs offerattrs)
	{
		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();
		for (Site site : prodContent.getSite()) {

			long lSiteId = site.getId();
			if (lSiteId > 11 || lSiteId == 10)
				continue;
			String siteName = TestUtils.getSite(lSiteId);
			if ((siteToTest.equalsIgnoreCase("sears") && siteName
					.equalsIgnoreCase("kmart"))
					|| (siteToTest.equalsIgnoreCase("kmart") && siteName
							.equalsIgnoreCase("sears"))) {
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for (com.generated.vos.productoffering.Hierarchy hierarchy : site
					.getTaxonomy().getHierarchy()) {
				if(hierarchy.getPrimary())
				{
					lstHieararchyIds.add(GenericUtil.convertToString(hierarchy
							.getId()));
				}
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		if(offerattrs.getTaxo().getWeb()!=null)
			compareWebhierarchyGB(mpSiteHiearachies, offerattrs.getTaxo().getWeb());

	}

	public void compareWebhierarchyGB(Map<Long, List<String>> sitehiearchyMap, com.generated.vos.offerattrs.Web contentWebTaxonomy)
	{
		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		this.setGBHierarchySeparator();
		for (Long lSiteId : sitehiearchyMap.keySet()) {
			String sSiteName = TestUtils.getSite(lSiteId);

			if(siteToTest.equalsIgnoreCase("kmart") && (sSiteName.equalsIgnoreCase("puertorico")||  sSiteName.equalsIgnoreCase("craftsman")))
			{
				System.out.println("ignore "+sSiteName+" for Kmart ..."+partNumberToTest);
				continue;
			}
			CompareValuesUtility.addDataFieldForReport("TaxonomySite", sSiteName);
			List<com.generated.vos.hierarchy.Hierarchy> hierarchyInfoList = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, sitehiearchyMap.get(lSiteId));

			if(hierarchyInfoList == null || hierarchyInfoList.size() == 0){
				//				logFailed("web-idPath",sitehiearchyMap.get(lSiteId),"Id not found in webhierarchy collection");
				continue;
			}else{
				if(contentWebTaxonomy == null){
					logFailed("web-idPath", "Web Taxonomy expected for site :"+ lSiteId+ " "+ sitehiearchyMap.get(lSiteId), "No taxonomy found");
					break;
				}
			}
			Sites_ contentSites = contentWebTaxonomy.getSites();

			if(contentSites!=null)
			{
				if(!processSiteForWebHierarchy(sSiteName, contentSites, hierarchyMap)){
					logFailed("web-idPath",sitehiearchyMap.get(lSiteId),"Site "+sSiteName +" not found in gb");
					continue;
				}

				for (com.generated.vos.hierarchy.Hierarchy hierarchy : hierarchyInfoList) 
				{
					for(Path path : hierarchy.getPath() )
					{
						if(path.getIsPrimary())
						{
							compareValues("web-idPath", path.getIdPath() ,checkInList(hierarchyMap.get(sSiteName).getLstIds(),path.getIdPath()));
							compareValues("web-displayPath", path.getDisplayPath() ,checkInList(hierarchyMap.get(sSiteName).getDisplayPaths(),path.getDisplayPath()));
						}
					}
				}
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();

	}

	public static String checkInList(List<String> lst, String exp)
	{
		try {
			for (String string : lst) {

				if(string.equals(exp))
				{
					return string;
				}
			}
			return "Not in list : "+lst.toString();

		} catch (Exception e) {

			e.printStackTrace();
			return "";
		}
	}

	/**
	 * Process site for web hierarchy
	 * @param siteName
	 * @param contentSites
	 * @param hierarchyMap
	 */
	public boolean processSiteForWebHierarchy(String siteName,Sites_ contentSites,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<PrimHrchy> lstHierarchies = null;

		try 
		{

			switch (siteName.toLowerCase()) 
			{

			case "kmart":  		lstHierarchies = contentSites.getKmart().getPrimHrchy();		break;

			case "sears":  		lstHierarchies = contentSites.getSears().getPrimHrchy();		break;

			case "mygofer": 	lstHierarchies = contentSites.getMygofer().getPrimHrchy(); 		break;

			case "puertorico":  lstHierarchies = contentSites.getPuertorico().getPrimHrchy(); 	break;

			case "kenmore":  lstHierarchies = contentSites.getKenmore().getPrimHrchy(); 	break;

			case "craftsman":  lstHierarchies = contentSites.getCraftsman().getPrimHrchy(); 	break;

			default:
				break;
			}

			if(lstHierarchies==null)
			{
				System.out.println("Primary hierarchy not found ..."+partNumberToTest);
				return false;

			}
			else
			{
				processWebHierarchy(lstHierarchies, siteName, hierarchyMap);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Site not found in json"+partNumberToTest);
			return false;
		}

	}

	/**
	 * 
	 * @param lstHierarchies 
	 * @param siteName
	 * @param hierarchyMap - Map to be updated with hierarchies. 
	 * eg. <Sears, [{Kids|Kids' Clothing|Boys' Clothing|Boys' Outerwear|All Boys' Outerwear,Clothing, Shoes & Jewelry|Clothing|Kids' Clothing|Boys' Clothing}]>
	 */
	public void processWebHierarchy(List<PrimHrchy> lstHierarchies ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();

		String id="", name="";

		for (PrimHrchy hierarchy : lstHierarchies) 
		{
			//System.out.println("id..."+id +"  hierarchySeparator .."+hierarchySeparator);
			if((id==null || id.isEmpty()) && hierarchySeparator.equals("|")){
				id=GenericUtil.convertToString(hierarchy.getSpinId());
			}
			else
				id=id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

			if(name.isEmpty() && hierarchySeparator.equals("|")){
				name =  hierarchy.getName();
			}
			else
				name = name+this.hierarchySeparator+hierarchy.getName();

			lstIds.add(id);
			lstName.add(name);

		}

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}




	/**
	 * Input : part number to test
	 * @param partNumberToTest
	 */
	private void testUsingPartNumber(ProductOffer productOffer,String partNumberToTest)
	{
		if(partNumberToTest==null){
			return;
		}

		/*if(!partNumberToTest.contains("00872394000"))
		{
			return;
		}
		 */
		//System.out.println("partNumberToTest... "+partNumberToTest);

		CompareValuesUtility.init();

		//Offerattrs offerAttrsDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER_ATTR, partNumberToTest);

		OfferattrsSchema offerattrsSchema = RestExecutor.getDataByIdFullSchema(CollectionValuesVal.OFFER_ATTR_SCHEMA, partNumberToTest);

		Offer offerDoc = RestExecutor.getDataById(CollectionValuesVal.OFFER, partNumberToTest);

		if(offerattrsSchema==null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("Offerattrs-not-found",partNumberToTest);
		}
		else
		{
			doVerification( productOffer, offerattrsSchema , offerDoc);
		}
		CompareValuesUtility.setupResult(partNumberToTest,true);
	}

	private void testNewChanges5_20(ProductOffer xmlProductOffer, Offerattrs offerattrs,
			String sOfferId, String site)
	{
		
		VendorPack[] vendorPack = xmlProductOffer.getImaAttributes()==null?null: xmlProductOffer.getImaAttributes().getVendorPack();

		Object cost = null;
		if(vendorPack!=null)
		{
			for(VendorPack vendorPackk : vendorPack){
				if(vendorPackk.getStoreName().equalsIgnoreCase(siteToTest)){

					cost = vendorPackk.getCost();
				}
			}
		}

		/*It will come under vendor pack tag or can come under operational attributes where source="core system"*/
		if(cost!=null)
		{
			CompareValuesUtility.compareAsNumbers("Unit Cost", cost.toString(), offerattrs.getDesc().getUnitCost()==null?"null":
				offerattrs.getDesc().getUnitCost().toString());
		}

		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		if(sources!=null)
		{
			String valueXml = null;
			String attrName = null;
			Long operSiteId = null;

			for (Source source : sources) {

				OperationalAttribute[] allAttributes = source.getOperationalAttribute();
				

				/*============================= SPIN =====================*/
				if(source.getName().equalsIgnoreCase("SPIN"))
				{
					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();
						operSiteId= attribute.getSiteId();

						Long siteId = attribute.getSiteId();

						switch(attrName.toUpperCase())
						{

						case "PREMIUM_SHIPPING":

							compareAsBoolean("PREMIUM_SHIPPING", valueXml, offerattrs.getOper().getIsMxShpInElig());
							break;
							
						case "HAULAWAY_ELIGIBLE":

							compareAsBoolean("HAULAWAY_ELIGIBLE", valueXml, offerattrs.getOper().getIsHaulawayElig());
							break;
							
						case "PRESELL_QTY":
							CompareValuesUtility.verifyNullOrEqual("PRESELL_QTY", valueXml, offerattrs.getOper().getQty());

							break;
							
						case "PRESELL_DATE":
							CompareValuesUtility.verifyNullOrEqual("PRESELL_DATE", valueXml, offerattrs.getOper().getStreetDt());

							break;
						case "INVENTORY_THRESHOLD":
						{
							
							if(TestUtils.getSite(siteId).equalsIgnoreCase("sears") && siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) 
									)
							{
								if((valueXml==null || valueXml.equals("0") )
										&& (offerattrs.getOper()==null||
												offerattrs.getOper().getInvThresholdRaw()==null))
								{
									CompareValuesUtility.logPassed("INVENTORY_THRESHOLD",valueXml==null?"null":valueXml,"null");
								}
								else
								{
									CompareValuesUtility.compareAsNumbers("INVENTORY_THRESHOLD", valueXml, 
											offerattrs.getOper()==null?"null":offerattrs.getOper().getInvThresholdRaw()) ;
									
								}
							}
							else if(TestUtils.getSite(siteId).equalsIgnoreCase("kmart")&& siteToTest.equalsIgnoreCase(TestUtils.getSite(siteId)) 
									)
							{
								if((valueXml==null || valueXml.equals("0") ) && (offerattrs.getOper()==null||offerattrs.getOper().getInvThresholdRaw()==null))
								{
									CompareValuesUtility.logPassed("INVENTORY_THRESHOLD",valueXml==null?"null":valueXml,"null");
								}
								else
								{
									CompareValuesUtility.compareAsNumbers("INVENTORY_THRESHOLD", valueXml, 
											offerattrs.getOper()==null||offerattrs.getOper()==null?"null":offerattrs.getOper().getInvThresholdRaw()) ;
								}
							}
							else{
								CompareValuesUtility.compareAsNumbers("INVENTORY_THRESHOLD", valueXml, offerattrs.getOper().getInvThresholdRaw());
							}

							break;
						}
						}
									}
				}
				/*============================= Finance System =====================*/
				else if(source.getName().equalsIgnoreCase("Finance System"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{

						}
					}
				}
				/*============================= IMA =====================*/
				else if(source.getName().equals("IMA"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{

						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{
						}
					}
				}
				/*============================= RIM =====================*/
				else if(source.getName().equals("RIM"))
				{

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase(""))
						{
						}
					}
				}
				else if(source.getName().equalsIgnoreCase("Core System"))
				{
					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("Unit Cost"))
						{
							CompareValuesUtility.compareAsNumbers("Unit Cost", valueXml, offerattrs.getDesc().getUnitCost());
						}
					}
				}
			}
		}
	}
	
	private void compareAsBoolean(String field,String sExpectedvalue,Boolean actaul)
	{
		Boolean bExpectedvalue = false;
		if(sExpectedvalue.equals("1") || sExpectedvalue.equals("YES") || sExpectedvalue.equals("Y"))
		{
			bExpectedvalue = true;
		}
		else if (sExpectedvalue.equals("0") || sExpectedvalue.equals("NO")|| sExpectedvalue.equals("N"))
		{
			bExpectedvalue = false;
		}

		//false and null is equal

		if(actaul==null && bExpectedvalue==false)
		{
			CompareValuesUtility.logPassed(field, "false", "null");
		}
		else
		{
			CompareValuesUtility.compareValues(field, bExpectedvalue, actaul);
		}
	}

	private String validateUPC(String upc, int length){

		if(upc==null)
			return null;

		if(upc.length()>length)
		{
			StringBuffer buf = new StringBuffer(upc);
			upc = buf.reverse().toString();

			upc = upc.substring(0, length);

			StringBuffer buf2 = new StringBuffer(upc);

			return buf2.reverse().toString();
		}
		else
		{
			return StringUtils.leftPad(upc, length, "0");
		}
	}

	/**
	 * @param offer
	 * @param offerattrs
	 */
	public void doVerification(ProductOffer xmlProductOffer, OfferattrsSchema offerattrsSchema,Offer offerDoc )
	{

		Offerattrs offerattrs = offerattrsSchema.getBlob().getOfferattrs();

		CompareValuesUtility.verifyNullOrEqual("FutureActiveStartDate",xmlProductOffer.getFutureActiveStartDate()
				,offerattrs.getOper()==null?null:offerattrs.getOper().getActStd());

		String upcToCheck=xmlProductOffer.getUpc();

		if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_0.value())){
			upcToCheck = validateUPC(upcToCheck, 12);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_1.value()) || xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_2.value())){
			upcToCheck = validateUPC(upcToCheck, 8);
		}else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_3.value())){
			upcToCheck = validateUPC(upcToCheck, 13);
		}
		else if(xmlProductOffer.getUpcType().value().equals(UpcTypeType.VALUE_7.value())){
			upcToCheck = validateUPC(upcToCheck, 14);
		}


		String ffFromXml="";
		try {
			ffFromXml = xmlProductOffer.getFulfillment().value();
		} catch (Exception e1) {
			ffFromXml="";
		}

		if( siteToTest.equalsIgnoreCase("kmart") && (ffFromXml.equalsIgnoreCase("FBM")))
		{
			String act =  offerattrs.getOper()==null?null:offerattrs.getOper().getRsosInd();

			compareValues("rsos ind", "YES", act);
		}

		CompareValuesUtility.verifyNullOrEqual("UPC",upcToCheck
				,offerattrs.getDesc()==null?null:offerattrs.getDesc().getUpc(),"desc");

		CompareValuesUtility.verifyNullOrEqual("UPC",upcToCheck
				,offerattrsSchema.getSearch()==null?null:offerattrsSchema.getSearch().getUpc(),"_search");

		CompareValuesUtility.addNewMultiValuedFields();


		CompareValuesUtility.verifyNullOrEqual("KSN",xmlProductOffer.getImaAttributes().getKsnId()
				,offerattrs.getDesc()==null?null:offerattrs.getDesc().getKsn(),"desc");

		CompareValuesUtility.verifyNullOrEqual("KSN",xmlProductOffer.getImaAttributes().getKsnId()
				,offerattrsSchema.getSearch().getKsn(),"_search");

		CompareValuesUtility.addNewMultiValuedFields();

		if(prodContent.getBrand()!=null)
		{
			if(prodContent.getBrand().getName().equals(" ") &&offerattrs.getDesc().getBrandName().equalsIgnoreCase("&#160;") )
			{
				CompareValuesUtility.logPassed("BrandName", " ", "&#160;");
			}
			else
			{
				//TODO
				CompareValuesUtility.verifyNullOrEqual("BrandName",prodContent.getBrand()==null?null:
					TestUtils.encodeHTML(prodContent.getBrand().getName()).replaceAll("`", "&#96;")
					,offerattrs.getDesc().getBrandName());


			}
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("BrandName",prodContent.getBrand()==null?null:
				TestUtils.encodeHTML(prodContent.getBrand().getName()).replaceAll("`", "&#96;")
				,offerattrs.getDesc().getBrandName());
		}

		ShipDimension shipDim = xmlProductOffer.getShipDimension();

		if(shipDim!=null)
		{
			compareValues("Shipping", shipDim.getHeight(), offerattrs.getDesc().getHgt(),"Height");
			compareValues("Shipping", shipDim.getWidth(), offerattrs.getDesc().getWdth(),"Width");
			compareValues("Shipping", shipDim.getLength(), offerattrs.getDesc().getLeng(),"Length");
			compareValues("Shipping", shipDim.getWeight(), offerattrs.getDesc().getWeight(),"Weight");

			CompareValuesUtility.addNewMultiValuedFields();
		}

		boolean bRimProduct = isRimProduct(xmlProductOffer);

		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		if(sources!=null)
		{
			String valueXml = null;
			String attrName = null;
			
			if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),offerattrs.getOper().getLimitedGeosRaw());
								//legal.getLimitedGeos());
			
			for (Source source : sources) {
				
				if(source.getName().equals("IMA"))
				{
					OperationalAttribute[] allAttributes = source.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) {

						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();


						if(attrName.equals("kmart sres ind"))
						{
							if(siteToTest.equalsIgnoreCase("kmart") && valueXml.equalsIgnoreCase("Y"))
							{
								CompareValuesUtility.verifyNullOrFalse("kmart sres ind",true,offerattrs.getOper().getKmSresInd());
							}
						}
						else if(attrName.equals("order system"))
						{
							if(siteToTest.equalsIgnoreCase("sears") && valueXml.equals("SAMS"))
							{
								CompareValuesUtility.verifyNullOrFalse("is-sam-product",true,offerattrs.getOper().getIsSam());
							}

							if(siteToTest.equalsIgnoreCase("sears") && valueXml.equals("RIM"))
							{
								CompareValuesUtility.verifyNullOrFalse("is-rim-product",true,offerattrs.getOper().getIsRim());
							}

						}
						else if(attrName.equalsIgnoreCase("rsos ind"))
						{
							if (siteToTest.equalsIgnoreCase("sears")){
								valueXml=valueXml==null?"N":valueXml;

								String act =  offerattrs.getOper()==null?null:offerattrs.getOper().getRsosInd();

								if(valueXml.equals("N"))
								{
									CompareValuesUtility.verifyNull("rsos ind", act);
								}
								else
								{
									act=act==null?"null":act;

									if(valueXml.equals("Y") && act.equalsIgnoreCase("YES"))
									{
										CompareValuesUtility.logPassed("rsos ind", valueXml, act);
									}
									else
									{
										CompareValuesUtility.logFailed("rsos ind", valueXml, act);
									}
								}
							}
						}
						else if(attrName.equalsIgnoreCase("instl ind"))
						{
							if(valueXml.equals("N"))
							{
								CompareValuesUtility.verifyNull( "instl ind", offerattrs.getOper()==null?null:offerattrs.getOper().getIsInstAble());
							}
							else
							{
								if(valueXml.equals("Y") && offerattrs.getOper().getIsInstAble())
								{
									CompareValuesUtility.logPassed("instl ind", valueXml, offerattrs.getOper().getIsInstAble());
								}
								else
								{
									CompareValuesUtility.logFailed("instl ind", valueXml, offerattrs.getOper().getIsInstAble());
								}
							}
						}
						else if(attrName.equalsIgnoreCase("wg_code"))
						{
							compareValues("wg_code", valueXml, offerattrs.getDesc().getWgCd());
						}
						else if(attrName.equalsIgnoreCase("recall-flag")||attrName.equalsIgnoreCase("recall flag"))
						{
							compareValues("recall-flag", valueXml, offerattrs.getOper().getIsRecld());
						}
					}
				}
				else if(source.getName().equals("RIM"))
				{
					OperationalAttribute[] allAttributes = source.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("fulfill source"))
						{
							if(bRimProduct && siteToTest.equalsIgnoreCase("sears"))
								compareValues("fulfill source", valueXml, offerattrs.getDesc().getFfmsrc());
						}
						else if(attrName.equalsIgnoreCase("rim status"))
						{
							if(bRimProduct &&  !siteToTest.equalsIgnoreCase("kmart"))
							{
								compareValues("rim status", valueXml, offerattrs.getOper().getRimSts());
							}
						}
						else if(attrName.equalsIgnoreCase("factory pack"))
						{
							if(bRimProduct &&  !siteToTest.equalsIgnoreCase("kmart"))
							{
								compareValues("factory pack", valueXml, offerattrs.getDesc().getFactPck());
							}
						}
						else if(attrName.equalsIgnoreCase("purchase status"))
						{
							if(bRimProduct && siteToTest.equalsIgnoreCase("sears"))
							{
								CompareValuesUtility.verifyNullOrEqual("purchase status", valueXml,offerattrs.getOper()==null?null:offerattrs.getOper().getPrchSts());
							}
						}

					}
				}
			}
		}

		VendorPack[] vendorPack = xmlProductOffer.getImaAttributes()==null?null: xmlProductOffer.getImaAttributes().getVendorPack();

		Object cost = null;
		if(vendorPack!=null)
		{
			for(VendorPack vendorPackk : vendorPack){
				if(vendorPackk.getStoreName().equalsIgnoreCase(siteToTest)){

					CompareValuesUtility.verifyNullOrEqual("VendorPackId",vendorPackk.getVendorPackId(),offerattrs.getDesc().getVndPckId());

					cost = vendorPackk.getCost();

					if(siteToTest.equalsIgnoreCase("kmart"))
					{
						CompareValuesUtility.verifyNullOrEqual("fulfill source",vendorPackk.getPayDunsNumber(),offerattrs.getDesc().getFfmsrc());

						CompareValuesUtility.verifyNullOrEqual("purchase status",vendorPackk.getPurchaseStatus().value(),offerattrs.getOper().getPrchSts());
					}
				}
			}
		}

		String sHmid;
		try {
			sHmid = xmlProductOffer.getImaAttributes().getHazardMaterialCode().value();
		} catch (Exception e) {
			sHmid=null;
		}

		CompareValuesUtility.verifyNullOrEqual("HazardMaterialCode",sHmid
				,offerattrs.getDesc()==null?null:offerattrs.getDesc().getHazmatCd());


		CompareValuesUtility.addDataFieldForReport("xml-ssin", xmlProductOffer.getSsin());

		try {
			CompareValuesUtility.verifyNullOrEqual("ssin",offerDoc.getIdentity()==null?null:offerDoc.getIdentity().getSsin(),
					offerattrs.getDesc()==null?null:offerattrs.getDesc().getSsin());
		} catch (Exception e) {
			System.out.println("Check ssin chech error, part : "+partNumberToTest);
		}


		OfferingIndicatorsGroup offeringsIndGrp = xmlProductOffer.getOfferingIndicatorsGroup();

		if(offeringsIndGrp!=null)
		{
			CompareValuesUtility.verifyNullOrEqual("ViewOnlyCode",offeringsIndGrp.getViewOnlyCode(),offerattrs.getOper()==null?null:offerattrs.getOper().getVwOnly());

			CompareValuesUtility.verifyNullOrFalse("web-only-flag",offeringsIndGrp.getWebOnlyFlag(),offerattrs.getOper()==null?null:offerattrs.getOper().getWebExcl());
		}


		//CompareValuesUtility.verifyNullOrEqual("web-only-flag",offeringsIndGrp.getWebOnlyFlag(),offerattrs.getOper().getWebExcl());

		CompareValuesUtility.verifyNullOrEqual("ProductType",prodContent.getProductType()==null?null:getProcProdType(prodContent.getProductType().value())
				,offerattrs.getDesc().getPrdTyp());

		compareValues("soldby",
				siteToTest.substring(0, 1).toUpperCase() + siteToTest.substring(1),
				offerattrs.getDesc().getSoldBy());


		List<String> sites = offerattrs.getDesc().getSites();

		for(com.generated.vos.productoffering.Site s : prodContent.getSite()){

			if(siteToTest.equalsIgnoreCase("kmart") && (s.getId()==11 || s.getId()==6))
			{
				System.out.println("ignore "+s.getId()+" site for Kmart ..."+partNumberToTest);
				continue;
			}

			if(s.getId() == 10 || s.getId() == 13)
				continue;
			if((siteToTest.equalsIgnoreCase("sears") && s.getId() == 1) || (siteToTest.equalsIgnoreCase("kmart") && s.getId() == 2))
				continue;

			CompareValuesUtility.verifyItemInList("Site", TestUtils.getSite(s.getId()),sites );
		}
		CompareValuesUtility.addNewMultiValuedFields();

		for (Attribute a : xmlProductOffer.getImaAttributes().getAttribute()) {
			if (a.getName().equals("SYW_ITEM_TYPE"))
				CompareValuesUtility.compareValues("syw-item-type", a.getContent(),
						offerattrs.getOper().getSywItmTyp());
		}


		compareValues("item-type",bSingleProductOffer?"NV":"V" , offerattrs.getDesc().getItmType());

		if (siteToTest.equalsIgnoreCase("kmart")) {
			CompareValuesUtility.verifyNullOrEqual("unit-cost", cost , offerattrs.getDesc().getUnitCost());
		}
		compareMasterhierarchyGB(sItemClassId, offerattrs.getTaxo().getMst().getHrchy());

		if(offerattrs.getTaxo().getStr()!=null)
		{
			verifyStoreTaxonomy(xmlProductOffer, offerattrs.getTaxo().getStr().getHrchy());
		}

		web(xmlProductOffer,	 offerattrs);


		if(prodContent.getProductAttributes()!=null)
		{
			ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();

			if (siteToTest.equalsIgnoreCase("kmart")) 
			{
				for (ProductAttribute productAttribute : attrs) {

					if(productAttribute.getAttributeId().equals("886710") 
							&& productAttribute.getProductAttributeTypeChoice().getAttributeValueFree().equalsIgnoreCase("true"))
					{
						CompareValuesUtility.verifyNullOrEqual("kmart-delivery (KHD)",true,offerattrs.getOper().getKmDelvry());
					}
				}
			}
		}

		testNewChanges5_20(xmlProductOffer, offerattrs, partNumberToTest, siteToTest);
	}

	private String getProcProdType(String type)
	{
		if (type==null||type.isEmpty())
			return type;

		switch(type)
		{
		case "SHIPVANTAGE":			 return "SV";
		case "PHYSICAL":			 return "GC";
		case "E-CARDS": 			 return  "VGC";
		}

		return type;
	}


	private boolean isRimProduct(ProductOffer xmlProductOffer)
	{
		Source[] sources = xmlProductOffer.getOperationalAttributes().getSource();

		if(sources!=null)
		{
			String valueXml = null;
			String attrName = null;

			for (Source source : sources) {

				if(source.getName().equals("IMA"))
				{
					OperationalAttribute[] allAttributes = source.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) {

						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equals("order system"))
						{
							if(siteToTest.equalsIgnoreCase("sears") && valueXml.equals("RIM"))
							{
								return true;
							}
						}
					}
				}
				/*else if(source.getName().equals("RIM"))
				{
					OperationalAttribute[] allAttributes = source.getOperationalAttribute();

					for (OperationalAttribute attribute : allAttributes) 
					{
						valueXml = attribute.getOperationalValue()[0].getValue();
						attrName = attribute.getName();

						if(attrName.equalsIgnoreCase("rim status"))
						{
							if(!siteToTest.equalsIgnoreCase("kmart"))
							{

							}
						}
					}
				}*/
			}
		}

		return false;
	}
	private void verifyStoreTaxonomy(ProductOffer xmlProductOffer,List<Hrchy_> list) 
	{

		long XMLHierarchyId;

		if (siteToTest.equalsIgnoreCase("sears")) {
			if (xmlProductOffer.getCoreHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getCoreHierarchyId();
		} else {
			if (xmlProductOffer.getShcHierarchyId() == null)
				return;
			XMLHierarchyId = xmlProductOffer.getShcHierarchyId();
		}

		List<String> lstPaths = new ArrayList<String>();

		String response = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE_HIERARCHY, XMLHierarchyId+"");

		String name = JsonStringParser.getJsonValue(response, "{_blob{hierarchy{name}}}");

		name = name.replace("SRWI", "");
		name = name.replace("KWSC", "");

		lstPaths.addAll(Arrays.asList(name.split("-")));

		if (lstPaths.isEmpty()) {
			CompareValuesUtility.verifyTrue(list.size() == 0,
					"StoreHName", "null", "Store Hierarchy should be null");
			return;
		}

		if (list.size() == 0) {
			logFailed("StoreHName", XMLHierarchyId, "StoreHierarchy is null");
			return;
		}

		int iHierarchy = 0;

		for (Hrchy_ hrchy_ : list) 
		{
			compareValues("StoreHName", lstPaths.get(iHierarchy++),
					hrchy_ == null ? null : hrchy_.getName());
		}

		CompareValuesUtility.addNewMultiValuedFields();

	}

	public void compareMasterhierarchyGB(String lItemClassId, List<Hrchy> list)
	{

		Map<String,HierarchyPathVo> hierarchyMap = new LinkedHashMap<>();

		Path masterHierarchyPath=null;
		try {
			masterHierarchyPath = GreenBoxCache.getPathForItemClass(lItemClassId+"");
		} catch (Exception e) {
			e.printStackTrace();
		}

		if(masterHierarchyPath == null){
			logFailed("Master", "Hierarchy for "+lItemClassId+" should exist", "No hierarchy exists");
			return;
		}

		if(list == null){
			logFailed("Master", "Hierarchy for "+lItemClassId+" should exist", "Master taxonomy not found");
			return;
		}
		this.setGBHierarchySeparator();

		processMasterHierarchy(list, "no-site-required-for-master", hierarchyMap);

		compareValues("Master", masterHierarchyPath.getIdPath(),hierarchyMap.get("no-site-required-for-master").getLstIds().get(0),"IDPath");
		compareValues("Master", masterHierarchyPath.getDisplayPath(),hierarchyMap.get("no-site-required-for-master").getDisplayPaths().get(0),"DisplayPath");
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void setGBHierarchySeparator(){
		this.hierarchySeparator = "|";
	}

	private String hierarchySeparator = "/";

	public void processMasterHierarchy(List<Hrchy> list ,String siteName,Map<String,HierarchyPathVo> hierarchyMap)
	{
		List<String> lstIds  = new LinkedList<String>();
		List<String> lstName  = new LinkedList<String>();
		List<String> lstCids  = new LinkedList<String>();

		String id=null, name=null,cid=null;

		for (Hrchy hierarchy : list) {

			if(id==null)
				id= GenericUtil.convertToString(hierarchy.getSpinId()); //replaced getId
			else
				id = id+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

			if(name==null)
				name=hierarchy.getName();
			else
				name = name+this.hierarchySeparator+hierarchy.getName();

			if(cid==null)
				cid=GenericUtil.convertToString(hierarchy.getSpinId());
			else
				cid = cid+this.hierarchySeparator+GenericUtil.convertToString(hierarchy.getSpinId());

		}

		/* ======  For master there will be always one entry ========= */
		lstIds.add(id);
		lstName.add(name);
		lstCids.add(cid);

		HierarchyPathVo hierarchyPathVo = new HierarchyPathVo();
		hierarchyPathVo.setLstIds(lstIds);
		hierarchyPathVo.setDisplayPaths(lstName);
		hierarchyPathVo.setLstCIds(lstCids);

		hierarchyMap.put(siteName, hierarchyPathVo);

	}


	private class HierarchyPathVo
	{
		public List<String> getLstIds() {
			return lstIds;
		}
		public void setLstIds(List<String> lstIds) {
			this.lstIds = lstIds;
		}
		public List<String> getLstCIds() {
			return lstCIds;
		}
		public void setLstCIds(List<String> lstCIds) {
			this.lstCIds = lstCIds;
		}
		public List<String> getDisplayPaths() {
			return displayPaths;
		}
		public void setDisplayPaths(List<String> displayPaths) {
			this.displayPaths = displayPaths;
		}
		private List<String> lstIds;
		private List<String> lstCIds;
		private List<String> displayPaths;

	}

}
