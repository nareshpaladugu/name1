package com.shi.content.urlredirect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * @author ddaphal
 *
 */
public class UrlRedirectionUtil 
{
	@org.testng.annotations.Test(groups="UrlRedirectionTest1")
	public void test()
	{
		InnerVo vo = getOldURLMapData();

		Map<String, Map<String,LinkedList<URLVo>>>  oldMap = vo.getOldMapMap();

		LinkedList<URLVo> listUrls = vo.getSimpleListOfUrlData();

		for (URLVo urlVo : listUrls) 
		{
			//if(urlVo.getId().equals("17572"))
			UrlRedirectionUtil.getRedirectedUrl(urlVo,oldMap);
		}
	}

	public static InnerVo   getOldURLMapData()
	{

		InnerVo innerVo = new InnerVo();
		//key1 = old url
		//key2 = catalog id

		LinkedList<URLVo> simpleListOfUrlData = new LinkedList<URLVo>();

		Map<String, Map<String,LinkedList<URLVo>>> OldURlMap  = null;

		try 
		{
			MySqlDatabase mysqldb = new MySqlDatabase();

			Connection connection = mysqldb.getDBConnection();

			Statement stmt = connection.createStatement();

			String sQuery  = "Select XTAXOCHANGE_ID,CATALOG_ID,OLDURL,NEWURL,CREATEDATE from XTAXOCHANGE where OLDURL is not null and OLDURL <> '' ";

			ResultSet rSet = stmt.executeQuery(sQuery);

			OldURlMap = new HashMap<String, Map<String,LinkedList<URLVo>>>();

			String catalogId;

			String oldUrl = null;

			while (rSet.next()) 
			{
				oldUrl = rSet.getString("OLDURL");

				catalogId = rSet.getString("CATALOG_ID");

				if(oldUrl==null || oldUrl.isEmpty() || oldUrl.equals("null"))
				{
					continue;
				}

				//Check 1....  only for not null and not blank old URLS

				if(rSet.getString("CATALOG_ID")!=null &&
						(rSet.getString("CATALOG_ID").equals("10104")
								|| rSet.getString("CATALOG_ID").equals("12605")))
				{
					simpleListOfUrlData.add(new URLVo(
							rSet.getString("XTAXOCHANGE_ID"),
							rSet.getString("OLDURL")
							,rSet.getString("NEWURL")
							,rSet.getString("CATALOG_ID")
							,rSet.getString("CREATEDATE")));

					//check2 .... only for KMART OR SEARS

					Map<String, LinkedList<URLVo>> innerMap = OldURlMap.get(oldUrl);

					if(innerMap==null)
					{
						innerMap=new HashMap<String, LinkedList<URLVo>>();
					}

					LinkedList<URLVo> innerList = innerMap.get(catalogId);

					if(innerList==null)
					{
						innerList=new LinkedList<>();
					}

					innerList.add(new URLVo(
							rSet.getString("XTAXOCHANGE_ID"),
							rSet.getString("OLDURL")
							,rSet.getString("NEWURL")
							,rSet.getString("CATALOG_ID")
							,rSet.getString("CREATEDATE")));


					innerMap.put(catalogId, innerList);

					OldURlMap.put(oldUrl,innerMap);
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

		innerVo.setOldMapMap(OldURlMap);
		innerVo.setSimpleListOfUrlData(simpleListOfUrlData);

		return innerVo;
	}

	public static URLVo getRedirectedUrl(URLVo urlVo,Map<String, Map<String,LinkedList<URLVo>>> OldURlMap)
	{
		//System.out.println("Processing redirect for urlVo.getId().... "+urlVo.getId());

		String sCurrentCatalog;

		String currentOldDate;

		String sFinalNewUrl;

		String sTempdate;

		currentOldDate = urlVo.getCreateDate();

		sCurrentCatalog = urlVo.getCatalogId();

		sFinalNewUrl = urlVo.getNewUrl();

		boolean found;

		int iii=0;

		String processed = "";

		String processed2 = "";

		while(true)
		{

			//System.out.println("Looping ....  for "+urlVo.getId());

			Map<String, LinkedList<URLVo>> dataList  = OldURlMap.get(sFinalNewUrl);

			if(dataList==null)
			{
				//	System.out.println("Breaking ... loop ..."+urlVo.getId());
				//this is last entry
				break;
			}

			LinkedList<URLVo> innerList = dataList.get(sCurrentCatalog);

			if(innerList==null)
			{
				//System.out.println("Breaking ... loopp ..."+urlVo.getId());
				break;
			}

			found = false;

			for (URLVo urlVo2 : innerList) 
			{
				if(iii==0)
					processed=processed+","+urlVo2.getId();
				else
					processed2=processed2+","+urlVo2.getId();

				//no need to check which same row
				if(urlVo2.getId().equals(urlVo.getId()))
				{
					continue;
				}

				// here we are iterating through all duplicate entries for url
				sTempdate = urlVo2.getCreateDate();

				if(isDateGreaterOrEqual(currentOldDate,sTempdate))
				{
					//update new URL
					sFinalNewUrl = urlVo2.getOldUrl();
					found = true;
				}
			}
			iii++;

			if(processed.equals(processed2))
			{
				//System.out.println("Cycle detected for "+urlVo.getId());
				break;
			}

			if(!found)
			{
				//System.out.println("breaking ... not found any redirection with greater date...." );
				break;
			}
			else
			{
				//	System.out.println("New URL Changed ... with id : "+urlVo.getId());
			}


			if(sFinalNewUrl.equals(urlVo.getOldUrl()))
			{
				//	System.out.println("Old and new is same ... breaking ...");
				break;
			}
		}

		urlVo.setCalculatedNewUrl(sFinalNewUrl);

		return urlVo;
	}

	public static boolean isDateGreaterOrEqual(String d1,String d2)
	{
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

			Date date = formatter.parse(d1+".000");
			Date date2 = formatter.parse(d2+".000");

			int res =date.compareTo(date2);

			if(res==1 || res==0)
			{
				//date is greater or equal to date2
				return true;
			}

			return false;
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
	}
}
