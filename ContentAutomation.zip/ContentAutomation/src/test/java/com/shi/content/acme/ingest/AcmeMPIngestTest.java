package com.shi.content.acme.ingest;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.catdelta.Delete;
import com.generated.vos.catdelta.Upsert;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

/**
 * @author ddaphal
 *
 */
public class AcmeMPIngestTest 
{

	public static boolean bVerifyNotNullSsinGuid;


	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider" ,groups="AcmeMPIngestTests")
	public void mpIngestTest(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread

		bVerifyNotNullSsinGuid= Boolean.parseBoolean(System.getProperty("verifyNotNullSsinGuid","false"));
		
		System.out.println("Testing sFileName "+ sFileName);

		String sTempFileName=sFileName;
		if(sFileName.contains("/"))
		{
			sTempFileName=sFileName.substring(sFileName.lastIndexOf("/"));
		}

		String sSeller = sTempFileName.split("\\.")[0].split("-")[2];
		if(sSeller.equalsIgnoreCase("DSS")) {
			sSeller = sTempFileName.split("\\.")[0].split("-")[3];
		}
		System.out.println("Seller is "+sSeller);

		BlockingQueue<List<Upsert>> fbmNodeQueue = new LinkedBlockingQueue<List<Upsert>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Upsert> prodThread = new ChunkProducerThread<Upsert>(sFileName, fbmNodeQueue, Upsert.class);//, poison);

		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Upsert> nodeToTest = fbmNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new AcmeMPIngestVerifications(nodeToTest.get(0),sSeller));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		BlockingQueue<List<Delete>> fbmNodeQueueDelete = new LinkedBlockingQueue<List<Delete>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Delete> prodThreadDelete = new ChunkProducerThread<Delete>(sFileName, fbmNodeQueueDelete, Delete.class);//, poison);

		prodThreadDelete.setBucketSize(1);
		Thread t2 = new Thread(prodThreadDelete);
		t2.start();

		while(true){
			try {
				List<Delete> nodeToTest = fbmNodeQueueDelete.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThreadDelete.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new AcmeMPIngestVerifications(nodeToTest.get(0),sSeller));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}


