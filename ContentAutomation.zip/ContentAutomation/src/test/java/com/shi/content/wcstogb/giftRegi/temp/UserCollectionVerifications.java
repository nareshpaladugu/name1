package com.shi.content.wcstogb.giftRegi.temp;

import java.util.List;
import java.util.Map;

import org.bson.Document;

import com.generated.vos.gr.user.GiftRegistry;
import com.generated.vos.gr.user.UserCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shi.content.wcstogb.giftRegi.CommonGiftReg;

public class UserCollectionVerifications implements Runnable
{
	private String userId_USERPROF;

	String userId_UserCollection;

	UserCollection userCollection;

	public UserCollectionVerifications(String userId,String field2)
	{
		this.userId_USERPROF=userId;

		this.userId_UserCollection=field2;
	}

	public void run() 
	{

		String grId;

		String storeId;

		String userCollectionDocument;

		System.out.println("Testing user id : "+this.userId_UserCollection);

		CompareValuesUtility.init();

		MongoCollection<Document> collection = CommonGiftReg.getCollection("userCollection");   

		BasicDBObject criteria = new BasicDBObject();
		criteria.put("_id", userId_UserCollection);

		Document dDocument = collection.find(criteria).first();

		//String defRegId = null;

		String defRegIdS = null;
		String defRegIdK = null;
		if(dDocument==null)
		{
			CompareValuesUtility.addFailedDataFieldForReport("userCollection", "Not Found");
		}
		else
		{
			userCollectionDocument = dDocument.toJson();

			if(TestUtils.isEmptyJsonResponse(userCollectionDocument))
			{
				CompareValuesUtility.addFailedDataFieldForReport("userCollection", "Not Found");
			}
			else
			{

				userCollection = CommonGiftReg.getCollectionObject(userCollectionDocument,UserCollection.class);

				//System.out.println("userCollectionDocument... "+userCollectionDocument);

				CompareValuesUtility.compareValues("_id", userId_UserCollection,userCollection.getId());

				CompareValuesUtility.compareValues("userId", userId_UserCollection,userCollection.getUserId());

				//CompareValuesUtility.verifyNullOrEqual("SYWRID",WcsCache.getSYWRIDVal(userId_USERPROF),userCollection.getSywrMemberId());

				List<Map<String, String>>  getAllGrDetails = UserCollectionCache.mapGRGFTREG_U.get(userId_USERPROF) ;

				List<Map<String, String>> listofMaps = UserCollectionCache.RegistryIdMap.get(userId_USERPROF);

				String tmp = null;

				for (Map<String, String> map : listofMaps) 
				{
					tmp = map.get("MBRATTR_ID");

					if(tmp!=null && tmp.equals("111"))
					{
						defRegIdS = map.get("STRINGVALUE");
					}
					else if(tmp!=null && tmp.equals("222"))
					{
						defRegIdK = map.get("STRINGVALUE");
					}
				}


				if(defRegIdS!=null && userCollection.getSears()!=null)
					CompareValuesUtility.verifyNullOrEqual("defaultRegistryId-sears",defRegIdS,
							userCollection.getSears().getDefaultRegistryId());

				//defRegId = WcsCache.getdefaultRegistryId("kmart", userId_UserCollection);

				if(defRegIdK!=null && userCollection.getKmart()!=null)
					CompareValuesUtility.verifyNullOrEqual("defaultRegistryId-kmart",defRegIdK ,
							userCollection.getKmart().getDefaultRegistryId());


				for (Map<String, String> singleGrDetail : getAllGrDetails) 
				{

					grId = singleGrDetail.get("giftregistry_id".toUpperCase());

					storeId = singleGrDetail.get("STOREID");

					if(storeId.equals("10153"))
					{
						//sears
						checkGr(grId, userCollection.getSears().getGiftRegistries(),singleGrDetail);

					}
					else if(storeId.equals("10151"))
					{
						//kmart
						checkGr(grId, userCollection.getKmart().getGiftRegistries(),singleGrDetail);
					}
					else
					{
						CompareValuesUtility.addDataFieldForReport("UnHandled Store", "Store: "+storeId);
					}
				}

			}
		}

		CompareValuesUtility.setupResult(userId_UserCollection,true);
	}

	private void checkGr(String grId,List<GiftRegistry> listOfRegs,Map<String, String> singleGrDetail )
	{
		String userRole = null;
		boolean found = false;

		for (GiftRegistry giftRegistry : listOfRegs) {

			if(giftRegistry.getGiftRegistryId().equals(grId))
			{
				//GR Found
				found = true;

				CompareValuesUtility.logPassed("giftRegistryId", grId, grId);

				CompareValuesUtility.verifyNullOrEqual("EventName",singleGrDetail.get("DESCRIPTION"),giftRegistry.getEventName());

				CompareValuesUtility.verifyNullOrEqual("STATUS",singleGrDetail.get("STATUS"),giftRegistry.getStatus());

				CompareValuesUtility.verifyNullOrEqual("EventTypeName",UserCollectionCache.EVENTTYPENAME_MAP.get(singleGrDetail.get("EVENTTYPE_ID"))
						,giftRegistry.getEventType());


				userRole = UserCollectionCache.UserRole_MAP.get(userId_USERPROF);

				if(userRole.equals("0"))
				{
					CompareValuesUtility.compareValues("UserRole","Reg"
							,giftRegistry.getUserRole());
				}
				else if(userRole.equals("1"))
				{
					CompareValuesUtility.compareValues("UserRole","Coreg"
							,giftRegistry.getUserRole());
				}
				else
				{
					CompareValuesUtility.addFailedDataFieldForReport("UnkownUserRole", userRole);
				}
				break;
			}
		}

		if(!found)
		{
			CompareValuesUtility.addDataFieldForReport("GiftRegistry-NotFound", grId);
		}
	}
}
