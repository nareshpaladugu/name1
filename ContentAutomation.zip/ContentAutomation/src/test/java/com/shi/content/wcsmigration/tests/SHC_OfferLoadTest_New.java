package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.parsers.XMLParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.commons.ErrorPartReader;
import com.shi.content.wcsmigration.verifications.SHC_OfferVerifications_New;

public class SHC_OfferLoadTest_New 
{
	public static boolean checkSSINAndUID = false;

	static List<String> erroredPartNumbers = new ArrayList<String>();

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="SHCOfferLoadTestNew")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException
	{
		if(CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Skipping file since threshold exceeded "+ sFileName);
			return;
		}
		
		System.out.println("Testing file "+ sFileName);

		String sSite = sFileName.split("\\.")[0].split("-")[1];

		BlockingQueue<List<SingleProductOffer>> singleProductOfferQueue = new LinkedBlockingQueue<List<SingleProductOffer>>(500); 

		BlockingQueue<List<VariationProductOffer>> variationProductOfferQueue = new LinkedBlockingQueue<List<VariationProductOffer>>(500);

		

		String sItemClassId=null;
		try {
			sItemClassId = XMLParser.findNodeValue(sFileName, "catalog", "item-class-id");
		} catch (Exception e1) {
			e1.printStackTrace();

			System.out.println("-------------------------\n\tNot able to find item class id \n\n-----------------------"+sFileName);
		}

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleProductOffer> prodThread = new ChunkProducerThread<SingleProductOffer>(sFileName, singleProductOfferQueue, SingleProductOffer.class,"single-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		ChunkProducerThread<VariationProductOffer> prodVariationThread = 
				new ChunkProducerThread<VariationProductOffer>(sFileName, variationProductOfferQueue, VariationProductOffer.class,"variation-product-offer");//, poison);
		prodVariationThread.setBucketSize(1);
		Thread variationProdThread = new Thread(prodVariationThread);
		variationProdThread.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
					pool.shutdownNow();
					break;
				}
				List<SingleProductOffer> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					//System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){
					pool.execute(new SHC_OfferVerifications_New(nodeToTest.get(0), sItemClassId, null, sSite, erroredPartNumbers));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();

			}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else{

			while(true){
				try {
					List<VariationProductOffer> varProdOfferList = variationProductOfferQueue.poll(20, TimeUnit.SECONDS);
					if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
						pool.shutdownNow();
						break;
					}
					if(varProdOfferList == prodVariationThread.POISON_PILL || CompareValuesUtility.getTotalResultsCount() >= LoadProperties.CONSUMER_THREADCOUNT){
						//System.out.println("Got poison pill ..breaking out" + varProdOfferList);
						break;
					}
					if(varProdOfferList != null ){
						pool.execute(new SHC_OfferVerifications_New(null, sItemClassId, varProdOfferList.get(0), sSite,erroredPartNumbers));
					}

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else
			pool.shutdown();

		while ((CompareValuesUtility.getFinalResult().getFailedCount() < LoadProperties.FAILURE_THRESHOLD) && !pool.isTerminated()){
			Thread.sleep(1000);
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Failure count exceed "+ CompareValuesUtility.getFinalResult().getFailedCount());
			pool.shutdownNow();
			CompareValuesUtility.setRunAborted(true);


		}
		//System.out.println("Pool terminated "+ pool.isTerminated());
	}

	@BeforeClass(groups="SHCOfferLoadTestNew")
	public void initErrorParts(){

		checkSSINAndUID = Boolean.parseBoolean(System.getProperty("checkSSINandUID", "true"));

		String errorlogFile = System.getProperty("errorLogFile", "");

		if(errorlogFile!=null && !errorlogFile.isEmpty())
		{
			erroredPartNumbers = ErrorPartReader.  getErrorPartsFromLogFile(errorlogFile);
		}
	}
}
