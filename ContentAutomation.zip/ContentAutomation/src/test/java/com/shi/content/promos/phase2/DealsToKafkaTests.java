package com.shi.content.promos.phase2;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.promokafka.PromoKafka;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class DealsToKafkaTests {
	
	@Test(description = "Tests that Kafka message contains correct data from mysql db", groups="DealsToPromoKafka")
	public void testDealsToKafka() throws Exception {

		BlockingQueue<List<PromoKafka>> iaPromoDocs = new LinkedBlockingQueue<List<PromoKafka>>();

		KafkaIAConsumer<PromoKafka> prodThread = new KafkaIAConsumer<PromoKafka>(PromoKafka.class,iaPromoDocs);		
		Thread t = new Thread(prodThread);
		t.start();
		
		int totalMessagesProcessed = 0;
		
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
//			pool.execute(new DealsToPromoVerifications(new PromoKafka()));
			while (true) {
				List<PromoKafka> nodeToTest;

				nodeToTest = iaPromoDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					pool.execute(new DealsToPromoVerifications(nodeToTest.get(0)));
					totalMessagesProcessed++;
				//	System.out.println("nodeToTest : "+nodeToTest.get(0).getPromo().getPromoId());
					
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}
		
		if(totalMessagesProcessed == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue", MSGTYPE.WARNING);
		}
	}
	

}
