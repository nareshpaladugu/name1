package com.shi.content.acme.threezero;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class MisClassIngestVerification implements Runnable{

	private String id;


	public MisClassIngestVerification(String id)
	{
		this.id=id;
	}

	@Override
	public void run() 
	{

		CompareValuesUtility.init();

		Offer offer = RestExecutor.getDataById(CollectionValuesVal.OFFER, id);

		String spinId = offer.getAltIds()==null?null:offer.getAltIds().getSpinId();

		if(spinId==null)
		{
			CompareValuesUtility.addDataFieldForReport("GB-SpinId", "not Found-skip");
		}
		else
		{
			CompareValuesUtility.addDataFieldForReport("GB-SpinId", spinId);

			String resp = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/misclass/"+spinId);

			if(TestUtils.isEmptyJsonResponse(resp))
			{
				CompareValuesUtility.addFailedDataFieldForReport("IA-misClass", "not Found");
			}
			else
			{
				String actualFlag = 	JsonStringParser.getJsonValueNew(resp, "item.attributes.misclass",true);
				actualFlag=actualFlag==null?"null":actualFlag;

				if(AcmeMisClassIngestTests.misClassFlag.equalsIgnoreCase(actualFlag))
				{
					CompareValuesUtility.logPassed("MisClass-Flag", actualFlag,actualFlag);
				}
				else
				{
					CompareValuesUtility.logFailed("MisClass-Flag", AcmeMisClassIngestTests.misClassFlag,actualFlag);
				}
			}
		}

		CompareValuesUtility.setupResult(id,true);
	}

}
