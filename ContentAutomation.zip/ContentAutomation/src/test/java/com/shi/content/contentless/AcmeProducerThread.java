package com.shi.content.contentless;

import java.net.URI;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.BlockingQueue;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;

public class AcmeProducerThread<T> implements Runnable{
	
	private BlockingQueue<T> blockingQueue;
	private Set<T> alreadyFoundData;
	public T POISON_PILL ;
	private static Gson gson = new Gson();
	private Class<T> classToTest ;
	
	AcmeProducerThread(BlockingQueue<T> blockingQueue, Class<T> classToParseTo) {
		this.blockingQueue = blockingQueue;
		this.alreadyFoundData = new HashSet<T>();
		this.classToTest = classToParseTo;
		try {
			POISON_PILL = classToTest.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void createData(String pageNum){
		String pageSize = "30";
		if(LoadProperties.TESTDATALIMIT < 30 && LoadProperties.TESTDATALIMIT > 0)
			pageSize = LoadProperties.TESTDATALIMIT+"";
		URI uri = RestAPIs.getAcmeMultiDocFetchURI(CollectionValuesVal.IA_SOURCE_BY_ID, pageSize, pageNum);
		String allSources = RestExecutor.getJSonResponse(uri);
		JsonObject allSourcesObject ;
		if(allSources.contains("TIME OUT"))
			allSources = RestExecutor.getJSonResponse(uri);
		
		if(allSources.contains("TIME OUT")){
			System.out.println("Time out error for "+ uri);
			return ;
		}
		
		try{
			allSourcesObject = gson.fromJson(allSources, JsonObject.class);
		}
		catch(Exception e){
			System.out.println("Caught parsing exception "+e.getCause()+" ---  "+ allSources );
			return ;

		}
		JsonArray iaItems = allSourcesObject.get("items").getAsJsonArray();
		Iterator<JsonElement> iterator = iaItems.iterator();
		while(iterator.hasNext()){
			T iaItem =  gson.fromJson(iterator.next(), classToTest);
			if(alreadyFoundData.add(iaItem))
				this.blockingQueue.add(iaItem);
			if(LoadProperties.TESTDATALIMIT!= -1 && LoadProperties.TESTDATALIMIT!= 0 && alreadyFoundData.size()>= LoadProperties.TESTDATALIMIT)
				break;
		}
		
//		return  getUniqueData(JsonStringParser.getJsonValueNew(allSources, "items.ssin"));
		
	}
	
	/*public static Set<String> getUniqueData(String listOfData){
		listOfData = listOfData.replaceAll("\"", "");
		
		return new HashSet<>(Arrays.asList(listOfData.split(";")));
	}*/

	@Override
	public void run() {
		int iEnd = 0, iStart = 0;
		if(!LoadProperties.RUN_PARAMS.isEmpty()){
			String[] pageNums = LoadProperties.RUN_PARAMS.split("-");
			if(pageNums.length > 1 ){
				 iStart = Integer.parseInt(pageNums[0]);
				 iEnd = Integer.parseInt(pageNums[1]);
			}else
				iEnd=Integer.parseInt(pageNums[0]);
		}
		if(LoadProperties.TESTDATALIMIT > 30)
			iEnd = LoadProperties.TESTDATALIMIT/30;
		else
			iEnd = (iEnd==0)? 20000 : iEnd;
		for(int i = iStart; i < iEnd; i++){
			createData(i+"");
			if(LoadProperties.TESTDATALIMIT!= -1 && LoadProperties.TESTDATALIMIT!= 0 && this.alreadyFoundData.size()>= LoadProperties.TESTDATALIMIT)
				break;
		}
		try {
			blockingQueue.put(POISON_PILL);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
