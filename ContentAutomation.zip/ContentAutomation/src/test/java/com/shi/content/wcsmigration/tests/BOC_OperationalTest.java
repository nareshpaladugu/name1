package com.shi.content.wcsmigration.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.ParamBasedDataProvider;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.verifications.BOC_OperationalVerifications;

public class BOC_OperationalTest {

	@Test(dataProviderClass=ParamBasedDataProvider.class, dataProvider="executionModeBasedDp", groups="BOC_OperationalTest")
	public void bundleTests(String sRunParam) {
		if (LoadProperties.IS_BUCKETBASED_RUN) {

			List<String> ids = new ArrayList<String>();
			List<String> lstBundleIds = new ArrayList<String>();
			List<String> lstCollectionIds = new ArrayList<String>();
			List<String> lstOutfitIds = new ArrayList<String>();

			switch(LoadProperties.gbSearchString){
				case "bundles":
					lstBundleIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "B");
					ids.addAll(lstBundleIds);
					break;
				case "variant-bundles":
					lstBundleIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "VB");
					ids.addAll(lstBundleIds);
					break;
				case "collections-outfits":
					lstCollectionIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "C");
					lstOutfitIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "O");	
					ids.addAll(lstCollectionIds);
					ids.addAll(lstOutfitIds);
					break;
				case "all":
					lstBundleIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "B");
					lstCollectionIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "C");
					lstOutfitIds = RestExecutor.getFilteredIds(CollectionValuesVal.CONTENT, Integer.parseInt(sRunParam), "catentrySubType", "O");	
					ids.addAll(lstBundleIds);
					ids.addAll(lstCollectionIds);
					ids.addAll(lstOutfitIds);
					break;
				default :
					System.out.println("Please provide search string");
					break;
			}
			
			final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
			for (String id : ids) {
				pool.execute(new BOC_OperationalVerifications(id));
			}

			pool.shutdown();

			try {
				pool.awaitTermination(40, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else if (LoadProperties.IS_LISTBASED_RUN) {
			new BOC_OperationalVerifications(sRunParam).run();
		} else {
			System.out.println("Please set property executionMode");
		}
	}
}
