
package com.shi.content.storepricing;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * competitor price for an item
 * 
 */
@Generated("org.jsonschema2pojo")
public class Cp {

    /**
     * was price of an item
     * (Required)
     * 
     */
    @Expose
    private Double ap;
    /**
     * name of a competitor/vendor
     * (Required)
     * 
     */
    @Expose
    private String vn;

    /**
     * was price of an item
     * (Required)
     * 
     */
    public Double getAp() {
        return ap;
    }

    /**
     * was price of an item
     * (Required)
     * 
     */
    public void setAp(Double ap) {
        this.ap = ap;
    }

    /**
     * name of a competitor/vendor
     * (Required)
     * 
     */
    public String getVn() {
        return vn;
    }

    /**
     * name of a competitor/vendor
     * (Required)
     * 
     */
    public void setVn(String vn) {
        this.vn = vn;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
