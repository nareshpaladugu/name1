package com.shi.content.ranking.vos;

public class SetSellerDtls {

	public Boolean setSeller() {
		// TODO Auto-generated method stub
		return null;
	}

}
