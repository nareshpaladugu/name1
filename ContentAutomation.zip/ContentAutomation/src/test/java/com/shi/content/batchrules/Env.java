package com.shi.content.batchrules;

public class Env {

	public static String OUTPUT="";

}
