package com.shi.content.storeLocalAd;

import java.util.Map;
import com.generated.vos.storelocalads.LocalAd;
import com.generated.vos.storelocalads.Storelocalads;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class StoreLocalAdVerification implements Runnable{

	Storelocalads storeLocalad;
	String storeId;
	String mediaType;
	String activityId;
	String activityName;
	String startDate;
	String endDate;
	Map<String, String> mapPageIdPageNum;

	public StoreLocalAdVerification(String storeId, String mediaType, String activityId, String activityName,
		String startDate, String endDate, Map<String, String> mapPageIdPageNum) {

		this.storeId = storeId;
		this.mediaType = mediaType;
		this.activityId = activityId;
		this.activityName = activityName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.mapPageIdPageNum = mapPageIdPageNum;
	}

	@Override
	public void run() {
	    
	    CompareValuesUtility.init();
	   
	    String id = mediaType + "_" + storeId;
		
		// testing storeID
		System.out.println("Testing storeLocalad: " + id + " : " + Thread.currentThread().getName());
	    
		// Hit the GB
		storeLocalad = RestExecutor.getDataById(CollectionValuesVal.STORELOCALAD, id);
		
		if (storeLocalad == null) {
		    CompareValuesUtility.logFailed("Id",id, "Not found"); // store level value
		} 
		else {
		    
		    CompareValuesUtility.compareValues("Id",id, storeLocalad.getId()); // store level value
		    CompareValuesUtility.compareValues("StoreType", mediaType,storeLocalad.getStoreType()); // store level value
		    CompareValuesUtility.compareValues("UnitNumber", storeId,storeLocalad.getUnitNumber()); // store level value
		    
		    if(StoreLocaladTest.ignorePageImage){

				CompareValuesUtility.compareValues("IgnorePageImage", true,storeLocalad.getIgnorePageImage());	 // store level value	
			    
		    }
		    else{

		    	if((mediaType.equalsIgnoreCase("sears") && StoreLocaladTest.searsExcludeStores.contains(storeId))
		    			|| (mediaType.equalsIgnoreCase("kmart") && StoreLocaladTest.kmartExcludeStores.contains(storeId))){

		    		CompareValuesUtility.compareValues("IgnorePageImage", true,storeLocalad.getIgnorePageImage());	// store level value
		    	}
		    	else{

		    		CompareValuesUtility.verifyNull("IgnorePageImage", storeLocalad.getIgnorePageImage());  // store level value
		    	}

		    }
		    
		    
		    boolean activityFound = false;
		    
		    for (LocalAd ads : storeLocalad.getLocalAds()) {
			
			if (activityId.equalsIgnoreCase(ads.getActivityId())) {
			    
			    CompareValuesUtility.compareValues("ActivityId",activityId,ads.getActivityId());
			    CompareValuesUtility.compareValues("ActivityName",activityName,ads.getActivityName());
			    CompareValuesUtility.compareValues("StartDate",startDate,ads.getStartDate());
			    CompareValuesUtility.compareValues("EndDate",endDate,ads.getEndDate());
			    CompareValuesUtility.compareValues("TotalPageCount_1",ads.getPages().size(),ads.getTotalPageCount());
			    CompareValuesUtility.compareValues("TotalPageCount_2",ads.getPages().size(),ads.getTotalPageCount());
			    boolean pageFound = false;
			    
			    for (Map.Entry<String, String> pageIdPageNum : mapPageIdPageNum.entrySet()) {
				
				for(com.generated.vos.storelocalads.Page pag : ads.getPages()){
				    
				    if (pageIdPageNum.getKey().equalsIgnoreCase(pag.getPageId().toString())) {
					    
					CompareValuesUtility.compareValues("PageId",pageIdPageNum.getKey(),pag.getPageId().toString());
					CompareValuesUtility.compareValues("PageNum",pageIdPageNum.getValue(),pag.getPageNum());
					pageFound = true;
					break;
					
				    }
				    
				}
				if (!pageFound) {
					
					CompareValuesUtility.logFailed("PageId",pageIdPageNum.getKey(),"Not Found");
					
				 }
				
			    }
			    activityFound = true;
			    break;
			    
			}
			
		    }
		    if (!activityFound) {
			
			CompareValuesUtility.logFailed("ActivityId", activityId,"Not Found");
			
		    }
		    
		}
		CompareValuesUtility.setupResult(id, true);
		
	}
	
}