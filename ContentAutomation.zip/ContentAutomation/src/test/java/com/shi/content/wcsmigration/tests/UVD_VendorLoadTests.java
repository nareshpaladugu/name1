package com.shi.content.wcsmigration.tests;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.vendor.Vendor;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shi.content.wcsmigration.verifications.UVD_VendorVerifications;

public class UVD_VendorLoadTests {

	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="UVDVendorLoadTest")
	public void testUvdVendor(String sFileName) throws InterruptedException
	{
		System.out.println("Testing sFileName "+ sFileName);

		BlockingQueue<List<Vendor>> vendorQueue = new LinkedBlockingQueue<List<Vendor>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Vendor> prodThread = new ChunkProducerThread<Vendor>(sFileName, vendorQueue, Vendor.class,"vendor");
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Vendor> nodeToTest = vendorQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null)
				{
					pool.execute(new UVD_VendorVerifications(nodeToTest.get(0)));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
