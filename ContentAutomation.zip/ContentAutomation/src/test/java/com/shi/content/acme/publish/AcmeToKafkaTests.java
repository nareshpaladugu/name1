package com.shi.content.acme.publish;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.vos.acmematchdata.AcmeMatchData;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.kafkautils.KafkaIAConsumer;

public class AcmeToKafkaTests {

	
	@Test(description="Tests to read from qa-1.0_match queue and validate data against source/reconciled db", groups="AcmeToKafkaTests")
	public void acmeToKafkaTests() throws Exception {


		BlockingQueue<List<AcmeMatchData>> acmeMatchdataDocs = new LinkedBlockingQueue<List<AcmeMatchData>>();

		KafkaIAConsumer<AcmeMatchData> prodThread = new KafkaIAConsumer<AcmeMatchData>("AcmeToKafkaTestsQAConsumer", AcmeMatchData.class, acmeMatchdataDocs);		
		Thread t = new Thread(prodThread);
		t.start();
		
		int iMessageCount=0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		try {
			while (true) {
				List<AcmeMatchData> nodeToTest;

				nodeToTest = acmeMatchdataDocs.poll(50, TimeUnit.SECONDS);

				if (nodeToTest == prodThread.POISON_PILL) {
					System.out.println("Got poison pill ..breaking out");
					break;
				}
				if (nodeToTest != null)
				{
					iMessageCount++;
					pool.execute(new AcmeToKafkaVerifications<AcmeMatchData>(nodeToTest.get(0)));
					
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		pool.shutdown();
		try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(iMessageCount == 0 ){
			LoadProperties.setCustomMsgForEmail("No messages received from queue for topic : "+ LoadProperties.KAFKATOPIC, MSGTYPE.WARNING);
		}
	}

}
