package com.shi.content.northstar.tests;


import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditLinks;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
 * Test Regular hours are updating for  multiple stores 
 * @author inaikwa
 *
 */

public class RegularHours_MultiStoreTest extends NorthStarBaseTest {
	private int noOfStoresToSelect=2;
	private ArrayList<String> listStoreIds;
	private String SundayOpenTime;
	
	@Test(description="Test to verify if the UnitRegHour are updating ", groups = {"NS-P1"})
	public void testUpdateHours_MultiView() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();
		
//		searchPage.searchByZipCode("60173");
//		
//		listStoreIds = searchPage.getAllSearsOpenNonICEEStores();
		
//		Kmart
		searchPage.searchByZipCode("95351");
		listStoreIds = searchPage.getAllKmartOpenStores();
		Asserts.verifyNotNull(listStoreIds.size(), "Verifed required storeIds found.");
		
		Assert.assertNotNull(listStoreIds.size(), listStoreIds.size()+ " =: Zero stores found, terminating......... ");
		
		Assert.assertNotEquals(1, listStoreIds.size()+ " =: Only one store found but multiple stores needed to test hence terminating......... ");
			
		searchPage.selectStore(listStoreIds,noOfStoresToSelect);
		
		searchPage.searchPageEdit();
		
		EditStoreDetails edit = new EditStoreDetails();
		
		edit.goToRegHoursView();
		
		SundayOpenTime=edit.updateHours_Multi();
		
		edit.saveDocument();
		
		for(int i = 0; i < listStoreIds.size();i++){
			
			String sJsonRep = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE,listStoreIds.get(i));
		
			String sSundayOpenTime = "0"+Integer.toString(Integer.parseInt(JsonStringParser.getJsonValueNew(sJsonRep, "_blob.unit.strHrs.sun.opn").replaceAll("\"", ""))/3600);
			
			Asserts.verifyEquals(SundayOpenTime,sSundayOpenTime,"Verified that the store time is updated successfully for store : "+listStoreIds.get(i)+"\nUpdated Time : "+SundayOpenTime +" Time found in response : "+sSundayOpenTime);
			
		}
	
	}
	
}
