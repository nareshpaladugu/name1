package com.shi.content.acme.threezero;

import com.generated.vos.contentscore.Attributes;
import com.generated.vos.contentscore.Contentscore;
import com.generated.vos.contentscore.Image;
import com.generated.vos.contentscore.Item;
import com.generated.vos.contentscoreMsg.ContentscoreMsg;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.content.restutils.RestExecutor;

public class ACMEContentScoreRealTimeIngestVerification implements Runnable
{

	private ContentscoreMsg inputRealTimeMsg;


	public ACMEContentScoreRealTimeIngestVerification (ContentscoreMsg inputRealTimeMsg)
	{
		this.inputRealTimeMsg= inputRealTimeMsg;
	}

	@Override
	public void run() 
	{
		String spinId = inputRealTimeMsg.getItemID();

		String respIA = RestExecutor.getJSonResponse("http://"+LoadProperties.IA_SERVER+"/acme/contentscore/"+spinId);

		Gson g=new Gson();

		Contentscore contentscore = g.fromJson( respIA, Contentscore.class);

		CompareValuesUtility.init();

		System.out.println("respIA... "+respIA);
		if(TestUtils.isEmptyJsonResponse(respIA) || contentscore==null || contentscore.getItem()==null)
		{
			//fail
			CompareValuesUtility.addFailedDataFieldForReport("IA-ContentScore", "Not Found");
		}
		else
		{

			try {
				Item item = contentscore.getItem();

				Image image = item.getAttributes()==null?null:item.getAttributes().getImage();

				Attributes attribute  = item.getAttributes();

				CompareValuesUtility.compareValues("Id", inputRealTimeMsg.getItemID(),item.getId());

				CompareValuesUtility.verifyNullOrEqual("Alt1", inputRealTimeMsg.getAlt1(),image==null?null:image.getAlt1());

				CompareValuesUtility.verifyNullOrEqual("Alt2", inputRealTimeMsg.getAlt2(),image==null?null:image.getAlt2());

				CompareValuesUtility.verifyNullOrEqual("Alt3", inputRealTimeMsg.getAlt3(),image==null?null:image.getAlt3());

				CompareValuesUtility.verifyNullOrEqual("Alt4", inputRealTimeMsg.getAlt4(),image==null?null:image.getAlt4());

				CompareValuesUtility.verifyNullOrEqual("Primary", inputRealTimeMsg.getPrimary(),image==null?null:image.getPrimary());

				CompareValuesUtility.verifyNullOrEqual("AttrCompleteness", inputRealTimeMsg.getATBRCOMPLETENESS(),  attribute==null?null:attribute.getAttrCompleteness());

				CompareValuesUtility.verifyNullOrEqual("TitleCons.", inputRealTimeMsg.getTITLECONSISTENCY(),attribute==null?null:attribute.getTitleConsistency());

				CompareValuesUtility.verifyNullOrEqual("LongDesc.", inputRealTimeMsg.getLONGDESC(), attribute.getDescription()==null?null:
					attribute.getDescription().getLongDesc());

				CompareValuesUtility.verifyNullOrEqual("ShortDesc.", inputRealTimeMsg.getSHORTDESC(), attribute.getDescription()==null?null:
					attribute.getDescription().getShortDesc());

				compareAggrScore(contentscore);
			} catch (Exception e) {
				System.out.println("Check this id.... "+spinId);
				e.printStackTrace();
			}
		}

		CompareValuesUtility.setupResult(spinId, true);

	}


	public static void compareAggrScore(Contentscore contentscore)
	{
		/*1. Image Quality (50%)

		Primary Image (40%) : (40/100*0.8) = 0.32
		Alt Image 1 (20%) : (20/100*0.8) = 0.16
		Alt Image 2 (20%) : (20/100*0.8) = 0.16
		Alt Image 3 (20%) : (20/100*0.8) = 0.16
		Sum of above score: 0.8
		Final Image Quality Score: (50/100)*0.8 = 0.4
		2. Title Consistency (20%) : (20/100*1) = 0.2 
		3. Attribute Completeness (10%) : (10/100*0.8) = 0.08
		4. Product Description Quality (10%) : (10/100*0.7) = 0.07
		5. Product Features Quality (10%) : (10/100*0.7) = 0.07*/

		Double expectedAggrScrore= 0d;

		Attributes attr = contentscore.getItem().getAttributes();

		String title = attr.getTitleConsistency();

		String attrComp = attr.getAttrCompleteness();

		String features = attr.getDescription()==null?null:attr.getDescription().getLongDesc();

		String prodDescription = attr.getDescription()==null?null:attr.getDescription().getShortDesc();

		Image image = attr.getImage();

		if(image!=null)
		{

			String primary  = image.getPrimary();

			if(!TestUtils.isEmptyString(primary))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(primary) * .40d);
			}

			String alt1= image.getAlt1();

			if(!TestUtils.isEmptyString(alt1))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt1) * .20d);
			}


			String alt2= image.getAlt2();

			if(!TestUtils.isEmptyString(alt2))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt2) * .20d);
			}

			String alt3= image.getAlt3();

			if(!TestUtils.isEmptyString(alt3))
			{
				expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(alt3) * .20d);
			}

			expectedAggrScrore = expectedAggrScrore/2;
		}

		if(!TestUtils.isEmptyString(title))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(title) * .20d);
		}

		if(!TestUtils.isEmptyString(attrComp))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(attrComp) * .10d);
		}

		if(!TestUtils.isEmptyString(features))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(features) * .10d);
		}

		if(!TestUtils.isEmptyString(prodDescription))
		{
			expectedAggrScrore = expectedAggrScrore+ (Double.parseDouble(prodDescription) * .10d);
		}

		expectedAggrScrore = Double.parseDouble(TestUtils.roundToNDigits(expectedAggrScrore, 2));

		System.out.println("expectedAggrScrore... "+expectedAggrScrore);

		Double aggregateActual = contentscore.getItem().getAttributes().getAggregateScore();

		System.out.println("aggregateActual... "+aggregateActual);

		CompareValuesUtility.verifyNullOrEqual("AggrScrore.", expectedAggrScrore, aggregateActual);
	}
}
