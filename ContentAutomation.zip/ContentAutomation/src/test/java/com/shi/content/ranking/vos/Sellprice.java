package com.shi.content.ranking.vos;

public class Sellprice {
	private float price;

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}


}
