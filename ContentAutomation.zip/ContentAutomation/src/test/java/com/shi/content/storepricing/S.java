
package com.shi.content.storepricing;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * sales price object of an item
 * 
 */
@Generated("org.jsonschema2pojo")
public class S {

    /**
     * sales price of an item
     * (Required)
     * 
     */
    @Expose
    private Double ip;
    /**
     * ISO Date Format(Example start time for sales price
     * (Required)
     * 
     */
    @Expose
    private String st;
    /**
     * ISO Date Format(Example  end time for sales price
     * (Required)
     * 
     */
    @Expose
    private String et;

    /**
     * sales price of an item
     * (Required)
     * 
     */
    public Double getIp() {
        return ip;
    }

    /**
     * sales price of an item
     * (Required)
     * 
     */
    public void setIp(Double ip) {
        this.ip = ip;
    }

    /**
     * ISO Date Format(Example start time for sales price
     * (Required)
     * 
     */
    public String getSt() {
        return st;
    }

    /**
     * ISO Date Format(Example start time for sales price
     * (Required)
     * 
     */
    public void setSt(String st) {
        this.st = st;
    }

    /**
     * ISO Date Format(Example  end time for sales price
     * (Required)
     * 
     */
    public String getEt() {
        return et;
    }

    /**
     * ISO Date Format(Example  end time for sales price
     * (Required)
     * 
     */
    public void setEt(String et) {
        this.et = et;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
