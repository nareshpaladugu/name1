package com.shi.content.varattrs;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyInListField;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.generated.vos.content.Content;
import com.generated.vos.offer.Attr;
import com.generated.vos.offer.DefiningAttr;
import com.generated.vos.offer.LinkedSwatch;
import com.generated.vos.offer.MainImg;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.SwatchImg;
import com.generated.vos.varattr.Attributes;
import com.generated.vos.varattr.PrimaryImg;
import com.generated.vos.varattr.Uid;
import com.generated.vos.varattr.UidDefAttr;
import com.generated.vos.varattr.Val;
import com.generated.vos.varattr.VarAttributeSchema;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;

public class VarAttributeVerifications implements Runnable{

	String id;
	Map<String, UIDStatus> uidStatuses = new HashMap<String, UIDStatus>();
	//Map to maintain color vals which have been processed
	Set<String> primaryImgprocessedVal = new HashSet<String>();
	Set<String> swatchImgprocessedVal = new HashSet<String>();
	List<String> failedOffers = new ArrayList<String>();
	private List<String> actualFailed  = new ArrayList<String>();
	Map<String, Boolean> offerContentStatus = new HashMap<String, Boolean>();
	String ssin;
	
	boolean isSSDoc = false;
	boolean isSearsDoc = false;
	boolean isKmartDoc = false;
	
	public VarAttributeVerifications(String ssin){
		this.id = ssin;
		this.ssin = ssin.replace("/a", "").replace("_SS", "").replace("sears_", "").replace("kmart_", "");
	}
	
	public void run(){
		
		try{
			CompareValuesUtility.init();
			System.out.println("Testing varattribute id: " + id);
			APIResponse<VarAttributeSchema> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.VARATTRIBUTE, id);
			Attributes varAttr = (Attributes)allResponse.getT();
			if(varAttr != null)
				CompareValuesUtility.addDataFieldForReport("Meta", varAttr.getMeta().getModifiedTs(), INFOTYPE.DATA);
			
			boolean bAtleastOneOfferOnline = false;
			
			if(id.contains("_SS"))
				isSSDoc = true;
			
			if(id.contains("sears_"))
				isSearsDoc = true;
			
			if(id.contains("kmart_"))
				isKmartDoc = true;
			
			//Fetch all offers for ssin by alt key api
			String forAltKey = id.replace("/a", "").replace("_SS", "").replace("sears_", "").replace("kmart_", "");
			List<String> allOffers = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "ssin", forAltKey);
	
			
			//Fetch all offer data from offer collection and create a map for easy access
			List<Offer> allOffersGB = RestExecutor.getDataById(CollectionValuesVal.OFFER, allOffers);
			Map<String, Offer> mpOffers = new HashMap<String, Offer>();		
			List<String> linkedSwatchIds = new ArrayList<String>();
			
			for(Offer off : allOffersGB){
				mpOffers.put(off.getId(), off);
				if(off.getAssocs()!=null 
						&& off.getAssocs().getLinkedSwatch()!=null 
						&& off.getAssocs().getLinkedSwatch().size() > 0){
					for(LinkedSwatch lnkdSwtch : off.getAssocs().getLinkedSwatch()){
						if(linkedSwatchIds.contains(lnkdSwtch.getId()))
							continue;
						else
							linkedSwatchIds.add(lnkdSwtch.getId());
					}
				}
				
				if(linkedSwatchIds.size() > 0){
					List<String> linkedSwatchOffers = new ArrayList<String>();
					for(String id : linkedSwatchIds){
						linkedSwatchOffers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId", id);
						List<Offer> swatchOffers = RestExecutor.getDataById(CollectionValuesVal.OFFER, linkedSwatchOffers);
						for(Offer swatchOffer : swatchOffers)
							mpOffers.put(swatchOffer.getId(), swatchOffer);
					}
				}
			}
			

			
			//If current varAttribute contains no definingattrs, verify all offers are offline
			if(varAttr.getDefiningAttrs() == null || varAttr.getDefiningAttrs().size() == 0){
				verifyOffline(allOffersGB);
				if(failedOffers.size() > 0){
					if(actualFailed.size()>0)
						CompareValuesUtility.logFailed("UUID", failedOffers , "Offers are online and have defining attrs, but no data for variation attribute");
					else
						CompareValuesUtility.logPassed("UUID", failedOffers , "Offers are online,but no defining attrs. Verified no defining attrs");
				}else{
					CompareValuesUtility.verifyTrue(varAttr.getUids() == null  || varAttr.getUids().size() == 0,
							"UUID", "UUID list is empty",varAttr.getUids());
					compareValues("AttrName", 0,varAttr.getDefiningAttrs().size(),"All offers offline : Exp DefAttrs size");
				}
			}
			else{
				if(allOffersGB.size() == 0){
					CompareValuesUtility.logFailed("UUID", "DefAttrs exist. Offers should exist", "No offers exist");
				}else{
//					List<String> linkedSwatchIds = new ArrayList<String>();
					List<String> processedParentIds = new ArrayList<String>();
					for(Offer gbOffer : mpOffers.values()){
						boolean isOnline = checkOnline(gbOffer);
						//If offer is not online, then proceed only if it is a ss document being verified
						if(!isOnline && !isSSDoc)
							continue;
						
						//Added for Kmart MP
						boolean isItemEligibleForSite = checkEligibility(gbOffer);
						
						if(!isItemEligibleForSite)
							continue;
						
						if(isOnline)
							bAtleastOneOfferOnline = true;
						
						String currentUID = gbOffer.getIdentity().getUid();
						
						if(currentUID == null){
							failedOffers.add(gbOffer.getId());
							continue;
						}
						
						//Validate current uid
						if(!uidStatuses.keySet().contains(currentUID)){
							//Verify uid in uid section of varattribute
							
							int uidPosition = verifyUIDData(currentUID, mpOffers, varAttr.getUids(),gbOffer);
							
							//If uid is found 
							if(uidPosition != -1)
								verifyDefiningAttrsForOffer(gbOffer,varAttr,uidPosition,mpOffers);
							
						}else{
							System.out.println("Offer "+ gbOffer.getId()+"  for this uuid :"+ currentUID+" is already processed");
						}
						
						
						//Validate linked swatch uids
						
						if(processedParentIds.contains(gbOffer.getIdentity().getParentId()))
							continue;
						
						processedParentIds.add(gbOffer.getIdentity().getParentId());
						
					
					
				}
					if(failedOffers.size() > 0)
						CompareValuesUtility.logFailed("UUID", failedOffers, "List of Offers found by get-alt-key for ssin but missing uids in offer.identity.ssin :");
					
					if(!bAtleastOneOfferOnline && !isSSDoc)
						CompareValuesUtility.logFailed("UUID", "No offers are available. Id should not have defAttrs.",
								"Id has defAttrs inspite of no offers being available for ssin");
				}
			}
			
			CompareValuesUtility.setupResult(id, true);
			CompareValuesUtility.teardown();
		}catch(Exception e){
			System.out.println("Check this id :"+ id);
			e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
		}finally{
			CompareValuesUtility.teardown();
		}
			
		}

	/**
	 * Check whether the offer is eligible for varattribute for this site
	 * for eg. in grouped items, if kmart item is there and sears doc is being checked then that offer needs to be ignored
	 * @param offerUnderCheck
	 * @return
	 */
	private boolean checkEligibility(Offer offerUnderCheck) {

		if(isSearsDoc){
			//Check display eligibility and sears hierarchy
			
			if(offerUnderCheck.getFfm().getSoldBy().equalsIgnoreCase("sears"))
				return true;
			if((offerUnderCheck.getTaxonomy().getWeb().getSites().getSears() != null
					&& offerUnderCheck.getTaxonomy().getWeb().getSites().getSears().getHierarchies().size() > 0)
					||
					( offerUnderCheck.getFfm().getSoldBy().equalsIgnoreCase("sears") &&
							offerUnderCheck.getTaxonomy().getWeb().getSites().getMygofer() != null
							&& offerUnderCheck.getTaxonomy().getWeb().getSites().getMygofer().getHierarchies().size() > 0)
							||
							(offerUnderCheck.getFfm().getSoldBy().equalsIgnoreCase("sears") &&
									offerUnderCheck.getTaxonomy().getWeb().getSites().getPuertorico() != null
									&& offerUnderCheck.getTaxonomy().getWeb().getSites().getPuertorico().getHierarchies().size() > 0)
					)
				return true;
					
		}
		
		if(isKmartDoc){
			//Check display eligibility on kmart and kmart web hierarchies
				
				if((offerUnderCheck.getTaxonomy().getWeb().getSites().getKmart() != null
						&& offerUnderCheck.getTaxonomy().getWeb().getSites().getKmart().getHierarchies().size() > 0)
						||
						offerUnderCheck.getFfm().getSoldBy().equalsIgnoreCase("kmart")
					)
					return true;
					
		}
		
		/*if(isSSDoc){
			if(offerUnderCheck.getFfm().getSoldBy().equalsIgnoreCase("kmart") || offerUnderCheck.getClassifications().getIsMpPgmType() != null)
				return false;
			else 
				return true;
		}*/
		
		return false;
	}

	private int verifyUIDData(String currentUID, Map<String, Offer> mpOffers, List<Uid> listOfUids, Offer gbOffer) {
		
		UIDStatus currentUUIDData = new UIDStatus(currentUID);
		uidStatuses.put(currentUID, currentUUIDData);
		
		List<String> uidOffers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid", currentUID);
		
		//Sets various statuses for the uuid
		setUIDOnlineStatus(uidOffers,mpOffers,currentUUIDData);
		
		int uidPosition = CompareValuesUtility.getPositionInList(currentUID, listOfUids, "uid", Uid.class);
		
		/*if(!currentUUIDData.hasContentSSIN){
			CompareValuesUtility.verifyTrue(uidPosition== -1, "UUID", "All offers for : "+ currentUID+ " do not have parent ssin.  UUID not present.",
					"Uuid is present in list.");
			return -1;
		}*/
		
		if(currentUUIDData.isOnline ){
			if(uidPosition != -1){
				Uid uid = listOfUids.get(uidPosition);
				compareValues("UUID", currentUID, uid.getUid());
				compareValues("SSIN", currentUUIDData.ssin, uid.getSsin());
				compareValues("UIDOfferCount", currentUUIDData.onlineOfferLst.size(), GenericUtil.convertToIntFromDouble(uid.getOfferCnt()));
				if(currentUUIDData.onlineOfferLst.size() == 1){
					compareValues("UIDOffer", currentUUIDData.onlineOffer, uid.getOfferId());
				}else{
					CompareValuesUtility.verifyNull("UIDOffer", uid.getOfferId());
				}
				for(String ofrId : currentUUIDData.onlineOfferLst){
					
					CompareValuesUtility.verifyItemInList("UIDOfferList", ofrId, uid.getOfferList());
				}
//				CompareValuesUtility.addNewMultiValuedFields();
				
				CompareValuesUtility.verifyNullOrEqual("UIDisAvail", !isSSDoc?null:(currentUUIDData.isAvail==null?null:Boolean.valueOf(currentUUIDData.isAvail)), uid.getIsAvail());
			}else{
				
				if(currentUUIDData.hasAtleastOneValidDefAttr)
					CompareValuesUtility.logFailed("UUID", currentUID, "Offer for this uid is online, but uid not present in varattribute");
				else
					CompareValuesUtility.logPassed("UUID", currentUID, "Offer for this uid is online with invalid defAttr, hence uid not present in varattribute");
			}
			return uidPosition;
		}else{
			if(isSSDoc && uidPosition != -1){
				Uid uid = listOfUids.get(uidPosition);
				compareValues("UUID", currentUID, uid.getUid());
				compareValues("UIDOfferCount", currentUUIDData.onlineOfferLst.size(), GenericUtil.convertToIntFromDouble(uid.getOfferCnt()));
				if(currentUUIDData.onlineOfferLst.size() == 1){
					compareValues("UIDOffer", currentUUIDData.onlineOffer, uid.getOfferId());
				}else{
					CompareValuesUtility.verifyNull("UIDOffer", uid.getOfferId());
				}
				for(String ofrId : currentUUIDData.onlineOfferLst){
					CompareValuesUtility.verifyItemInList("UIDOfferList", ofrId, uid.getOfferList());
				}
				CompareValuesUtility.verifyNullOrEqual("UIDisAvail", currentUUIDData.isAvail==null?null:Boolean.valueOf(currentUUIDData.isAvail), uid.getIsAvail());
			}
			if(uidPosition != -1 && !isSSDoc){
				CompareValuesUtility.verifyTrue(uidPosition== -1, "UUID", currentUUIDData.uuid+ " should not exist since all offers are offline/or with no parents",
				currentUUIDData +" is in list. Failed" );
				return -1;
			}
			
		}
		
		return uidPosition;
	}
	

	/**
	 * Check if all offers are online <br>
	 * Sets failedOffers and actual failed <br>
	 * failedOffers - Offers which are online <br>
	 * actualFailed - Offers which are online and also have defining attributes
	 * @param allOffersGB
	 */
	private void verifyOffline(List<Offer> allOffersGB) {
		for(Offer gbOffer : allOffersGB){
			if(checkOnline(gbOffer)){
				failedOffers.add(gbOffer.getId());
				//There are some offers which have defining attrs section but no val in them.  
				//Add this to actualFailed only if values exist 
				if(gbOffer.getDefiningAttrs().size()>0 && gbOffer.getDefiningAttrs().get(0).getVal()!= null)
					actualFailed.add(gbOffer.getId());
			}
		}
		
	}
	Map<String, String> testedVarDefAttributes = new HashMap<String, String>();
	
	private void verifyDefiningAttrsForOffer(Offer gbOffer, Attributes varAttrs,
			Integer currentUIDposition,  Map<String,Offer> mpOffers) {

		
		Uid uid = varAttrs.getUids().get(currentUIDposition);
		Map<String, String> testedAttributes = new HashMap<String, String>();
		for(DefiningAttr defAttr : gbOffer.getDefiningAttrs()){
			boolean bFound = false;
			boolean bAttrMatchDone = false;
			Attr offerAttribute = defAttr.getAttr();
			com.generated.vos.offer.Val offerAttrVal = defAttr.getVal();

			if(testedAttributes.keySet().contains(offerAttribute.getName())){
				bAttrMatchDone = true;
				//Check whether the value has been matched too.  
				List<String> attrValuesTested = Arrays.asList(testedAttributes.get(offerAttribute.getName()).split("@@@"));
				//If value is also tested, continue
				if(attrValuesTested.contains(offerAttrVal.getName()))  
						continue;
			}

			
			//Validate attribute in uid attributes
			validateUIDAttr(uid, offerAttribute.getName(), offerAttrVal.getName());
			
			//If attribute exists, but new value, then add value to tested list
			if(bAttrMatchDone)
				testedAttributes.put(offerAttribute.getName(), testedAttributes.get(offerAttribute.getName())+"@@@"+offerAttrVal.getName());
			else
				testedAttributes.put(offerAttribute.getName(), offerAttrVal.getName());
			
			
			//To check if this attribute has been tested as part of some other verif
			int iMainAttrTested = -1;
			if((iMainAttrTested=isDefAttrAlreadyTested(offerAttribute,offerAttrVal)) == 0)
					continue;
			
			//Verify attribute in definingAttrs
			for(com.generated.vos.varattr.DefiningAttr varAttr : varAttrs.getDefiningAttrs()){
				if(varAttr.getName().equals(offerAttribute.getName())){
					compareValues("AttrName", offerAttribute.getName(), varAttr.getName());
					
					//If attribute has been verified to be present but value is different, then skip sequence validation
					if(iMainAttrTested==2 && !bAttrMatchDone){
						
						//commented below line and new code added to consider attrSeq from other offers also if needed
						//compareValues("AttrSeq", offerAttribute.getSeq()==null?0:offerAttribute.getSeq().intValue(), varAttr.getSeq().intValue());
						
						//new code starts
						int currOfferAttrSeq = offerAttribute.getSeq()==null?0:offerAttribute.getSeq().intValue();
						boolean bSeqFound = true;
						boolean bAttrTypeFound = true;
						if(!(currOfferAttrSeq == varAttr.getSeq().intValue())){
							
							bSeqFound = false;
							
						}
						
						if(!(offerAttribute.getType().equals(varAttr.getDispType()))){
							
							bAttrTypeFound = false;
							
						}
						
						if(!bAttrTypeFound || !bSeqFound){
							
							
							for(String offerId : mpOffers.keySet()){
								
								Offer nxtOffer = mpOffers.get(offerId);
								if(nxtOffer.equals(gbOffer))
									continue;
								Integer nxtOfferAttrSeq = null;
								String nxtOfferAttrType = null;
								if(nxtOffer.getDefiningAttrs()!=null){
									for(DefiningAttr nxtDefAttr : nxtOffer.getDefiningAttrs()){
										if(nxtDefAttr.getAttr().getName().equals(offerAttribute.getName())){
											nxtOfferAttrSeq = nxtDefAttr.getAttr().getSeq()==null?0:nxtDefAttr.getAttr().getSeq().intValue();
											nxtOfferAttrType = nxtDefAttr.getAttr().getType();
											break;
										}
									}
								}
								if((!bAttrTypeFound && nxtOfferAttrType == null) || (!bSeqFound && nxtOfferAttrSeq == null))
									continue;
								
								if(!bSeqFound){
									if( !(nxtOfferAttrSeq == varAttr.getSeq().intValue())){
										if(bAttrTypeFound == true)
											continue;
									}else{
										bSeqFound = true;
										if(bAttrTypeFound == true)
											break;
									}
								}
								
								if(!bAttrTypeFound){
									if(!bAttrTypeFound && !(nxtOfferAttrType.equals(varAttr.getDispType()))){
										continue;
									}else{
										bAttrTypeFound = true;
										if(bSeqFound == true)
											break;
									}
								}
							}
							
							if(!bSeqFound){
								CompareValuesUtility.logFailed("AttrSeq", offerAttribute.getSeq().intValue(), "Not found");
							}else{
								//Comparing same values since equality has already been established by flag being true
								compareValues("AttrSeq", varAttr.getSeq().intValue(), varAttr.getSeq().intValue());
							}
							if(!bAttrTypeFound){
								CompareValuesUtility.logFailed("AttrType", offerAttribute.getType(), "Not found");
							}else
								compareValues("AttrType",  varAttr.getDispType(), varAttr.getDispType());
							
						}
						
						
						
						
						
					
					}
					//compareValues("AttrType", offerAttribute.getType(), varAttr.getDispType());
					//new code ends
					
					//Verify value of uid exists as one of the values in vals
					
					int i = verifyInListField("AValName", offerAttrVal.getName(), varAttr.getVals(), "name", Val.class, true);
					if(i!= -1){
						Val varAttrValue = varAttr.getVals().get(i);
						
						//commented below lines and new code added to consider attrValSeq/attrValFamilyName from other offers also if needed
						//compareValues("AValSeq", offerAttrVal.getSeq()==null?0:offerAttrVal.getSeq().intValue(), varAttrValue.getSeq().intValue());
						//compareValues("AValFamilyName", offerAttrVal.getFamilyName(), varAttrValue.getFamilyName());
						
						//new code starts AValSeq
						int currOffrAttrValSeq = offerAttrVal.getSeq()==null?0:offerAttrVal.getSeq().intValue();
						
						if(!(currOffrAttrValSeq == varAttrValue.getSeq().intValue())){
							List<String> uidOffers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid", gbOffer.getIdentity().getUid());
							for(String offerId : uidOffers){
								
								//if current offer, then continue to next offer
								if(offerId.equals(gbOffer.getId())) 
									continue;
								else{
									Offer nxtOffer = mpOffers.get(offerId);
					
									Integer nxtOfferAttrValSeq = null;
									if(nxtOffer.getDefiningAttrs()!=null){
										for(DefiningAttr nxtDefAttr : nxtOffer.getDefiningAttrs()){
											if(nxtDefAttr.getAttr().getName().equals(offerAttribute.getName())
													&& nxtDefAttr.getVal().getName().equals(offerAttrVal.getName())){
												nxtOfferAttrValSeq = nxtDefAttr.getVal().getSeq()==null?0:nxtDefAttr.getVal().getSeq().intValue();
												break;
											}
										}
									}
									if(nxtOfferAttrValSeq==null){
										continue;
									}else{
										if(!(nxtOfferAttrValSeq == varAttrValue.getSeq().intValue())){
											continue;
										}else{
											compareValues("AValSeq", nxtOfferAttrValSeq, varAttrValue.getSeq().intValue());
											break;
										}
									}
								}
							}
						}else{
							compareValues("AValSeq", currOffrAttrValSeq, varAttrValue.getSeq().intValue());
						}
						//new code ends
							
						//starts AValFamilyName
						if(!offerAttrVal.getFamilyName().equals(varAttrValue.getFamilyName())){
							List<String> uidOffers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid", gbOffer.getIdentity().getUid());
							for(String offerId : uidOffers){
								
								//if current offer, then continue to next offer
								if(offerId.equals(gbOffer.getId())) 
									continue;
								else{
									Offer nxtOffer = mpOffers.get(offerId);
					
									String nxtOfferAttrValFamName = null;
									if(nxtOffer.getDefiningAttrs()!=null){
										for(DefiningAttr nxtDefAttr : nxtOffer.getDefiningAttrs()){
											if(nxtDefAttr.getAttr().getName().equals(offerAttribute.getName())
													&& nxtDefAttr.getVal().getName().equals(offerAttrVal.getName())){
												nxtOfferAttrValFamName = nxtDefAttr.getVal().getFamilyName();
												break;
											}
										}
									}
									if(nxtOfferAttrValFamName==null){
										continue;
									}else{
										if(!nxtOfferAttrValFamName.equals(varAttrValue.getFamilyName())){
											continue;
										}else{
											compareValues("AValFamilyName", nxtOfferAttrValFamName, varAttrValue.getFamilyName());
											break;
										}
									}
								}
							}
						}else{
							compareValues("AValFamilyName", offerAttrVal.getFamilyName(), varAttrValue.getFamilyName());
						}
						//ends
						
					
						if(offerAttribute.getName().equals("Color"))
							verifyImages(varAttrValue, mpOffers);
						
					}
					bFound = true;
					break;
				}
			}
			if(!bFound)
				CompareValuesUtility.logFailed("AttrId", offerAttribute.getId(), "Not found");
			
		}
	}
	
	/**
	 * Returns 0 if <attrname, attrvalue> is tested already
	 * Returns 1 if <attrname> is tested but not value
	 * Returns 2 if <attrname,attrvalue> both are not tested
	 * @param offerAttribute
	 * @param offerAttrVal
	 * @return
	 */
	private int isDefAttrAlreadyTested(Attr offerAttribute,com.generated.vos.offer.Val offerAttrVal){
		if(testedVarDefAttributes.keySet().contains(offerAttribute.getName())){
			//Check whether the value has been matched too.  
			List<String> attrValuesTested = Arrays.asList(testedVarDefAttributes.get(offerAttribute.getName()).split("@@@"));
			//If value is also tested, continue
			if(attrValuesTested.contains(offerAttrVal.getName()))  
					return 0;
			else{
				testedVarDefAttributes.put(offerAttribute.getName(), testedVarDefAttributes.get(offerAttribute.getName())+"@@@"+offerAttrVal.getName());
				return 1;
			}
		}else{
			
			testedVarDefAttributes.put(offerAttribute.getName(), offerAttrVal.getName());
			return 2;
		}
		
	}
	
	private void validateUIDAttr(Uid uid, String offerAttrName, String offerAttrValue){
		boolean bFound = false;
		boolean bAttrFound = false;
		/*int uidAttrPosition = verifyInListField("UIDAttr", offerAttribute.getName(), uid.getUidDefAttrs(), "attrName", UidDefAttr.class);
		compareValues("UIDAVal", offerAttrVal.getName(), uidAttrPosition==-1?null:uid.getUidDefAttrs().get(uidAttrPosition).getAttrVal());*/
		
		for(UidDefAttr uidDefAttr : uid.getUidDefAttrs()){
			if(uidDefAttr.getAttrName().equals(offerAttrName))
				bAttrFound = true;
			if(uidDefAttr.getAttrName().equals(offerAttrName) && uidDefAttr.getAttrVal().equalsIgnoreCase(offerAttrValue)){
				CompareValuesUtility.logPassed("UIDAttr", offerAttrName, uidDefAttr.getAttrName());
				CompareValuesUtility.logPassed("UIDAVal", offerAttrValue, uidDefAttr.getAttrVal());
				bFound = true;
				break;
			}
		}
		if(!bFound && !bAttrFound){
			CompareValuesUtility.logFailed("UIDAttr", offerAttrName, "Not found");
			CompareValuesUtility.logFailed("UIDAVal", offerAttrName, "Not found");
		}
		if(!bFound && bAttrFound){
			CompareValuesUtility.logPassed("UIDAttr", offerAttrName, offerAttrName);
			CompareValuesUtility.logFailed("UIDAVal", offerAttrValue, "Not found");
		}
	}
	
	private void setUIDOnlineStatus(List<String> uidOffers,Map<String,Offer> mpOffers,UIDStatus currentUIDData){
		
		for(String uidOffer : uidOffers){
			Offer offerUnderCheck = mpOffers.get(uidOffer);
			if(offerUnderCheck == null)
				continue;
			
			//If mp item and doc being tested is ss doc, skip this item	
			if(offerUnderCheck.getClassifications().getIsMpPgmType() != null && isSSDoc){
				continue;
			}
			
			//Kmart MP
			if(!checkEligibility(offerUnderCheck))
				continue;
			
			
			//Check if offer has parent.  If no parent, this offer should not be considered 
			/*if(!fetchContentStatus(offerUnderCheck)){
				currentUIDData.hasContentSSIN = currentUIDData.hasContentSSIN || false;
				//continue; //Commented by Sajid 1/5/2016
			}else{
				currentUIDData.hasContentSSIN = true;
			}*/
			currentUIDData.ssin = offerUnderCheck.getIdentity().getSsin();
			
			//if offer is onilne , add to counts.  
			//For ss : only sears item will reach here. 
			//For non-ss, all items will reach
			
			if(checkOnline(offerUnderCheck)){
				currentUIDData.isOnline = true;
				currentUIDData.isAvail = getIsAvail(offerUnderCheck);
				currentUIDData.onlineOffer = uidOffer;
				if(offerUnderCheck.getDefiningAttrs()!=null && offerUnderCheck.getDefiningAttrs().size() > 0
						   && offerUnderCheck.getDefiningAttrs().get(0)!=null
						   && offerUnderCheck.getDefiningAttrs().get(0).getAttr()!=null
						   && offerUnderCheck.getDefiningAttrs().get(0).getAttr().getName()!=null
						   && offerUnderCheck.getDefiningAttrs().get(0).getVal()!=null
						   && offerUnderCheck.getDefiningAttrs().get(0).getVal().getName()!=null){
							currentUIDData.hasAtleastOneValidDefAttr = true;
							currentUIDData.onlineOfferLst.add(uidOffer);
				}
			}
			//If offer is not available
			//SS - still process it and increase the offer count
			//Non-SS - do not process
			else{
				if(isSSDoc){
					currentUIDData.onlineOffer = uidOffer;
					currentUIDData.isAvail = getIsAvail(offerUnderCheck);
					currentUIDData.onlineOfferLst.add(uidOffer);
				}
			}
			
			/*if(offerUnderCheck.getAssocs()!=null 
					&& offerUnderCheck.getAssocs().getLinkedSwatch()!=null 
					&& offerUnderCheck.getAssocs().getLinkedSwatch().size() > 0){
				for(LinkedSwatch lnkdSwtch : offerUnderCheck.getAssocs().getLinkedSwatch()){
					if(linkedSwatchIds.contains(lnkdSwtch.getId()))
						continue;
					else
						linkedSwatchIds.add(lnkdSwtch.getId());
				}
			}*/
			
		}
		
		/*int linkedSwatchOfferCnt = 0;
		if(linkedSwatchIds.size() > 0){
			List<String> linkedSwatchOffers = new ArrayList<String>();
			for(String id : linkedSwatchIds){
				linkedSwatchOffers =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId", id);
			}
			List<String> processedOffers = new ArrayList<String>();
			for(String offerId : linkedSwatchOffers){
				if(processedOffers.contains(offerId))
					continue;
				else{
					Offer offerUnderCheck = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerId);
					if(checkOnline(offerUnderCheck)){
						linkedSwatchOfferCnt++;
					}else{
						if(isSSDoc){
							linkedSwatchOfferCnt++;
						}
					}
					processedOffers.add(offerId);
				}
			}
		}
		*/
		currentUIDData.isProcessed = true;
		
	}
	
	private String getIsAvail(Offer offerUnderCheck) {
		if((offerUnderCheck.getOperational() == null || 
				offerUnderCheck.getOperational().getSites() == null || 
				offerUnderCheck.getOperational().getSites().getSears() == null || 
				offerUnderCheck.getOperational().getSites().getSears().getIsAvail() == null))
			return null;
		else if(offerUnderCheck.getOperational().getSites().getSears().getIsAvail() == true)
			return "true";
		else
			return "false";
	}
	
	Content content = null;
	
	/*private boolean fetchContentStatus(Offer offerUnderCheck) {

		if(offerContentStatus.keySet().contains(offerUnderCheck.getId()))
				return offerContentStatus.get(offerUnderCheck.getId());
		if(offerUnderCheck.getIdentity().getParentId() != null){
			if(content == null || !content.getId().equals(offerUnderCheck.getIdentity().getParentId()))
				content = RestExecutor.getDataById(CollectionValuesVal.CONTENT,offerUnderCheck.getIdentity().getParentId());
			if(content == null || content.getIdentity() == null || content.getIdentity().getSsin() == null){
				offerContentStatus.put(offerUnderCheck.getId(), false);
				return false;
			}else{
				offerContentStatus.put(offerUnderCheck.getId(), true);
				return true;
			}
		}else{
			offerContentStatus.put(offerUnderCheck.getId(), false);
			return false;
		}
		
	}*/
	
	private boolean checkOnline(Offer offerUnderCheck){
		if(isSSDoc){
			if((offerUnderCheck.getOperational() != null && 
					offerUnderCheck.getOperational().getSites() != null && 
					offerUnderCheck.getOperational().getSites().getSears() != null && 
					offerUnderCheck.getOperational().getSites().getSears().getIsDispElig() != null && 
					offerUnderCheck.getOperational().getSites().getSears().getIsDispElig() == true))
				return true;
			else
				return false;
		}else{
			if((offerUnderCheck.getOperational() != null && 
					offerUnderCheck.getOperational().getSites() != null &&
					offerUnderCheck.getOperational().getSites().getSears() != null && 
					offerUnderCheck.getOperational().getSites().getSears().getIsDispElig() != null && 
					offerUnderCheck.getOperational().getSites().getSears().getIsDispElig() == true) ||
			   (offerUnderCheck.getOperational() != null && 
					offerUnderCheck.getOperational().getSites() != null &&
					offerUnderCheck.getOperational().getSites().getKmart() != null && 
					offerUnderCheck.getOperational().getSites().getKmart().getIsDispElig() != null && 
					offerUnderCheck.getOperational().getSites().getKmart().getIsDispElig() == true) ||
				(offerUnderCheck.getOperational() != null && 
					offerUnderCheck.getOperational().getSites() != null &&
					offerUnderCheck.getOperational().getSites().getMygofer() != null && 
					offerUnderCheck.getOperational().getSites().getMygofer().getIsDispElig() != null && 
					offerUnderCheck.getOperational().getSites().getMygofer().getIsDispElig() == true) ||
				(offerUnderCheck.getOperational() != null && 
					offerUnderCheck.getOperational().getSites() != null &&
					offerUnderCheck.getOperational().getSites().getPuertorico() != null && 
					offerUnderCheck.getOperational().getSites().getPuertorico().getIsDispElig() != null && 
					offerUnderCheck.getOperational().getSites().getPuertorico().getIsDispElig() == true)
				)
				return true;
			else 
				return false;
		}
	}
	
	
	
	

	private void verifyImages(Val varAttrValue, Map<String,Offer> mpOffers) {

		
		if(! primaryImgprocessedVal.contains(varAttrValue.getName()) || !swatchImgprocessedVal.contains(varAttrValue.getName())){
			boolean bPrimaryImgCheck = false, bSwatchImgCheck = false;
			//Loop all offers and check images if val name matches the val in the offer
			for(String offer : mpOffers.keySet()){
				Offer offerUnderCheck = mpOffers.get(offer);
				if(!isSSDoc && !checkOnline(offerUnderCheck))
					continue;
				
				/*if(!primaryImgprocessedVal.contains(varAttrValue.getName())){
					if(offerUnderCheck.getMainImg() == null && varAttrValue.getPrimaryImg() == null){
						CompareValuesUtility.logPassed("PImgSrc", "null", "null");
						bPrimaryImgCheck = true;
						primaryImgprocessedVal.add(varAttrValue.getName());
					}
				}*/
				
				//Only if main image exists for this offer, check
//				if(offerUnderCheck.getMainImg() != null && offerUnderCheck.getMainImg().size()>0 && 
//						offerUnderCheck.getSwatchImg().size() != 0){
					for(DefiningAttr defAttr : offerUnderCheck.getDefiningAttrs()){
						if(defAttr.getAttr().getName().equals("Color") && defAttr.getVal()!=null
								&& defAttr.getVal().getName().equals(varAttrValue.getName())){
							
							if(!primaryImgprocessedVal.contains(varAttrValue.getName())){
								if((offerUnderCheck.getMainImg().size() == 0 && varAttrValue.getPrimaryImg() == null)|| 
										(offerUnderCheck.getSwatchImg().size()==0 && varAttrValue.getPrimaryImg() == null)){
									CompareValuesUtility.logPassed("PImgSrc", "null", "null");
									bPrimaryImgCheck = true;
									primaryImgprocessedVal.add(varAttrValue.getName());
								}
								if(varAttrValue.getPrimaryImg()!= null){
									if (offerUnderCheck.getMainImg().get(0).getSrc().equals(varAttrValue.getPrimaryImg().getSrc())){
										verifyImage(offerUnderCheck.getMainImg().get(0), varAttrValue.getPrimaryImg());
										primaryImgprocessedVal.add(varAttrValue.getName());
										bPrimaryImgCheck = true;
									}
								}/*else{
									CompareValuesUtility.logFailed("PImgSrc",offerUnderCheck.getMainImg().get(0).getSrc(), "null" );
									primaryImgprocessedVal.add(varAttrValue.getName());
//									return;
								}*/
							}
							//Verify swatch image
							if(!swatchImgprocessedVal.contains(varAttrValue.getName())){
									if(offerUnderCheck.getSwatchImg().size() == 0 && varAttrValue.getSwatchImg() == null){
										CompareValuesUtility.logPassed("SwatchImgSrc", "null", "null");
										swatchImgprocessedVal.add(varAttrValue.getName());
										bSwatchImgCheck = true;
									}
								if(varAttrValue.getSwatchImg()!= null){
									if (offerUnderCheck.getSwatchImg().get(0).getSrc().equals(varAttrValue.getSwatchImg().getSrc())){
										verifySwatchImage(offerUnderCheck.getSwatchImg().get(0), varAttrValue.getSwatchImg());
										swatchImgprocessedVal.add(varAttrValue.getName());
										bSwatchImgCheck = true;
									}
								}/*else{
									CompareValuesUtility.logFailed("SwatchImgSrc",offerUnderCheck.getMainImg().get(0).getSrc(), "null" );
									swatchImgprocessedVal.add(varAttrValue.getName());
//									return;
								}*/
							}
							break;
							
						}
					}
					
					/*if (bImagesFound)
						break;*/
//				}
				//If both images found, stop scanning further offers
				if(swatchImgprocessedVal.contains(varAttrValue.getName()) && primaryImgprocessedVal.contains(varAttrValue.getName()))
					break;
			}
			
			if(!bPrimaryImgCheck){
				CompareValuesUtility.logFailed("PImgSrc","Image has value different from all images and not null", 
						varAttrValue.getPrimaryImg()==null?"null":varAttrValue.getPrimaryImg().getSrc());
				primaryImgprocessedVal.add(varAttrValue.getName());
			}
			

			if(!bSwatchImgCheck){
				CompareValuesUtility.logFailed("SwatchImgSrc","Image has value different from all images and not null",
						varAttrValue.getSwatchImg()==null?"null":varAttrValue.getSwatchImg().getSrc());
				swatchImgprocessedVal.add(varAttrValue.getName());
			}
				
			//At the end of looping all offers, if image has not been found
			//and a primary image exists for this value in varattribute collection, then the image is incorrect, log failure
			if(!primaryImgprocessedVal.contains(varAttrValue.getName()) && varAttrValue.getPrimaryImg() != null){
				CompareValuesUtility.logFailed("PImgSrc","Prim/Swatch Img not found in all offers.  Img should be null.", varAttrValue.getPrimaryImg().getSrc() );
				primaryImgprocessedVal.add(varAttrValue.getName());
			}
		}/*else{
			CompareValuesUtility.logPassed("PImgSrc", varAttrValue.getPrimaryImg().getSrc(), processedVal.get(varAttrValue.getName())+" :Matched with same val in another uuid's offer.");
		}*/
	}

	public void verifyImage(MainImg offerMainImg,PrimaryImg primImg){
		compareValues("PImgSrc", offerMainImg.getSrc(), primImg.getSrc());
		CompareValuesUtility.verifyNullOrEqual("PImgTitle", offerMainImg.getTitle(), primImg.getTitle());
		CompareValuesUtility.verifyNullOrEqual("PImgWidth", offerMainImg.getWidth(), primImg.getWidth());
		CompareValuesUtility.verifyNullOrEqual("PImgHeight", offerMainImg.getHeight(), primImg.getHeight());
	}
	
	public void verifySwatchImage(SwatchImg swatchImg, com.generated.vos.varattr.SwatchImg valSwatchImg){
		compareValues("SwatchImgSrc", swatchImg.getSrc(), valSwatchImg.getSrc());
		CompareValuesUtility.verifyNullOrEqual("SwatchImgTitle", swatchImg.getTitle(), valSwatchImg.getTitle());
		CompareValuesUtility.verifyNullOrEqual("SwatchImgWidth", swatchImg.getWidth(), valSwatchImg.getWidth());
		CompareValuesUtility.verifyNullOrEqual("SwatchImgHeight", swatchImg.getHeight(), valSwatchImg.getHeight());
	}
		
	
	class UIDStatus{
		String uuid, onlineOffer,ssin;
		boolean isProcessed, isOnline, isMP, hasContentSSIN;
		boolean hasAtleastOneValidDefAttr;
		String isAvail;
		List<String> onlineOfferLst = new ArrayList<String>();
		
		UIDStatus(String uuid){
			this.uuid = uuid;
		}
		
	}
		
		
		//for ssin, fetch all uuids
		
		//do verification on count if required
		
		//for each uuids
			//fetch offer ids
			//for each offer id
				//Verify defining attrs
				//Check whether image is available?
				//If yes, break for this uuid 
		
		
			
		
	
}
