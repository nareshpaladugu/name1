package com.shi.content.storepricing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.FileProviderClass;

	public class KmartMemberPricingTest {

		static Map<String, Boolean> storeIds = Collections.synchronizedMap(new HashMap<String, Boolean>());

		static BufferedWriter invalidPartNumberWriter;
		
		
		@AfterTest
		public void closeFile()
		{
			System.out.println("Closing file........");
			try {
				invalidPartNumberWriter.flush();
				invalidPartNumberWriter.close();
			} catch (IOException e) {
			  e.printStackTrace();
			}
			System.out.println("Counts of rows with all prices < 0.02 "+ KmartMemberPriceEvaluation.countOfNullPricedItems);
		}
		
		@BeforeTest
		public void openFile()
		{
			System.out.println("Opening file........");
			//open file

			try {
				
				File F=new File("Upc_InvalidPartnumbers.txt");   //C:/Users/hthamar/workspace/Variations_8.30_release/test-output/
				invalidPartNumberWriter=new BufferedWriter(new FileWriter(F));


			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		
		@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
		public void kmartPricingTests(String fileName){
			
			try{
				FileReader fr=new FileReader(fileName);
				BufferedReader br=new BufferedReader(fr);      ////get filename one by one and start reading each line

				String processLine;
				
				final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
				
				
				while((processLine=br.readLine())!=null){
					pool.execute(new KmartMemberPriceEvaluation(processLine));
				}
				
				br.close();
				pool.shutdown();
				
				pool.awaitTermination(300, TimeUnit.MINUTES);
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
			
				
		}
	}
		
		
		
	
	
	