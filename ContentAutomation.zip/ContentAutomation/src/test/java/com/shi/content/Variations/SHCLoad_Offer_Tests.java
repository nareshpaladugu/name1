package com.shi.content.Variations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.VariationProductOffer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.parsers.StaxXMLChunker;
import com.shc.autocontent.parsers.XMLParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.FileProviderClass;
import com.shc.content.entity.CatentryIds;

public class SHCLoad_Offer_Tests {
	
	static List<String> erroredPartNumbers = new ArrayList<String>();
	
	@BeforeClass
	public void initErrorParts(){
		System.out.println("Initialize Error numbers");
		if(LoadProperties.LST_FILES.contains("kmart")){
			erroredPartNumbers = fetchListOfErrors(2);
		}
		else{
			if(LoadProperties.LST_FILES.contains("sears"))
				erroredPartNumbers = fetchListOfErrors(1);
		}
	}
	
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider")
	public void testSHCStaticLoad(String sFileName) throws InterruptedException{
		//Create a blocking queue per thread
		if(CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Skipping file since threshold exceeded "+ sFileName);
			return;
		}
		System.out.println("Testing sFileName "+ sFileName);
		long l1 = System.currentTimeMillis();
		
		String sSite = sFileName.split("\\.")[0].split("-")[1];
		System.out.println(sSite);
		HashMap<String, List<String>> partNumbers  = readXml(sFileName,sSite);
		System.out.println("Sears partNumbers Size: "+partNumbers.get("Sears").size());
		System.out.println("Kmart partNumbers Size: "+partNumbers.get("Kmart").size());
		CatentryIds catentryIds = ContentCache.getcatentryIds(partNumbers);
//		catentryIds = ContentCache.checkFlagsFromAttribsQuery1(catentryIds);
//		catentryIds = ContentCache.checkFlagsFromAttribsQuery2(catentryIds);
		
		System.out.println("Fetched all attributes. Time : "+ (System.currentTimeMillis() - l1));
		
		BlockingQueue<List<SingleProductOffer>> singleProductOfferQueue = new LinkedBlockingQueue<List<SingleProductOffer>>(500); 
		
		BlockingQueue<List<VariationProductOffer>> variationProductOfferQueue = new LinkedBlockingQueue<List<VariationProductOffer>>(500);
		
		SHCContentCommons shcOfferCommons = new SHCContentCommons(sFileName,sSite);
		
		String sItemClassId = XMLParser.findNodeValue(sFileName, "catalog", "item-class-id");
		
		

		// Start producer thread to produce nodes
		ChunkProducerThread<SingleProductOffer> prodThread = new ChunkProducerThread<SingleProductOffer>(sFileName, singleProductOfferQueue, SingleProductOffer.class,"single-product-offer");//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();
		
		ChunkProducerThread<VariationProductOffer> prodVariationThread = 
				new ChunkProducerThread<VariationProductOffer>(sFileName, variationProductOfferQueue, VariationProductOffer.class,"variation-product-offer");//, poison);
		prodVariationThread.setBucketSize(1);
		Thread variationProdThread = new Thread(prodVariationThread);
		variationProdThread.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
					pool.shutdownNow();
					break;
				}
				List<SingleProductOffer> nodeToTest = singleProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" );
					break;
				}
				if(nodeToTest != null){
					pool.execute(new SHC_OfferVerifications(nodeToTest.get(0),shcOfferCommons, sItemClassId, null, sSite,catentryIds, erroredPartNumbers));
				}
				} catch (InterruptedException e) {
				e.printStackTrace();
				
			}
		}
		
		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else{
		
		while(true){
			try {
				List<VariationProductOffer> varProdOfferList = variationProductOfferQueue.poll(20, TimeUnit.SECONDS);
				if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
					pool.shutdownNow();
					break;
				}
				if(varProdOfferList == prodVariationThread.POISON_PILL || CompareValuesUtility.getTotalResultsCount() >= LoadProperties.CONSUMER_THREADCOUNT){
					System.out.println("Got poison pill ..breaking out" + varProdOfferList);
					break;
				}
				if(varProdOfferList != null ){
					pool.execute(new SHC_OfferVerifications(null,shcOfferCommons, sItemClassId, varProdOfferList.get(0), sSite, catentryIds,erroredPartNumbers));
				}
				
				} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		}

		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			pool.shutdownNow();
		}else
			pool.shutdown();
		
		while ((CompareValuesUtility.getFinalResult().getFailedCount() < LoadProperties.FAILURE_THRESHOLD) && !pool.isTerminated()){
			Thread.sleep(1000);
		}
		
		if(!pool.isTerminated() && CompareValuesUtility.getFinalResult().getFailedCount() >= LoadProperties.FAILURE_THRESHOLD){
			System.out.println("Failure count exceed "+ CompareValuesUtility.getFinalResult().getFailedCount());
			pool.shutdownNow();
			CompareValuesUtility.setRunAborted(true);
			
			
		}
		System.out.println("Pool terminated "+ pool.isTerminated());
		/*try {
			pool.awaitTermination(1000, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
//		System.out.println("Size Map :  "+CompareValuesUtility.allResultsMap.size());
		//Moved to reporting
//		ExcelReportListener.createDetailedReport_updated(CompareValuesUtility.getFieldNames(), CompareValuesUtility.allResultsMap);
}
	private List<String> fetchListOfErrors(int iSite) {
		// TODO Auto-generated method stub
		String tableName;
		if(iSite == 1)
			tableName = "XSEARSITEMERR";
		else
			tableName = "XKMARTITEMERR";
			
		String sQuery = "select PARTNUMBER from wcsadm."+tableName+" where  LASTUPDATE > (SELECT date(days(current date) - 1)"+
				" FROM SYSIBM.SYSDUMMY1)";
		
		
		List<String> erroredOutPartNumbers = DBUtil.executeQuerySingleColMulRow(sQuery);
		if(erroredOutPartNumbers == null){
			System.out.println("No results returned for "+ sQuery);
			return new ArrayList<String>();
		}
		else
			System.out.println(erroredOutPartNumbers);
		return erroredOutPartNumbers;
	}


	public HashMap<String, List<String>> readXml(String fileName,String site){
        HashMap<String, List<String>> partNumbers = new HashMap<String, List<String>>();
        List<String> kmartPartNumbers = new ArrayList<>();
        List<String> searsPartNumbers = new ArrayList<>();
        try{
               StaxXMLChunker nodeFinder = new StaxXMLChunker(fileName);
               if(site.equalsIgnoreCase("sears")){
                     searsPartNumbers = nodeFinder.findNodeValues("sears-part-number");
               }
               else if(site.equalsIgnoreCase("kmart")){
                     kmartPartNumbers = nodeFinder.findNodeValues("kmart-part-number");
               }
               partNumbers.put("Sears", searsPartNumbers);
               partNumbers.put("Kmart", kmartPartNumbers);
        } catch (Exception e) {
               e.printStackTrace();
        }
        return partNumbers;
 }


}
	
	
	


	
