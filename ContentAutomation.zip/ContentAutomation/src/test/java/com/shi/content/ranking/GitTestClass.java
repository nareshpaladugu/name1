package com.shi.content.ranking;

public class GitTestClass {

	
	private void psvm() {
		//  this is test class 

	}
}
