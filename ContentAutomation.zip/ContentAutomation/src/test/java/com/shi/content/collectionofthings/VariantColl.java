package com.shi.content.collectionofthings;

import java.util.ArrayList;
import java.util.List;

public class VariantColl {
	
	String primAttrName;
	String primAttrVal;
	List<com.generated.xmls.collections.Group> groups = new ArrayList<com.generated.xmls.collections.Group>();
	
	Boolean isDeliveryElig;
	Boolean isShipElig;
	Boolean isSpuElig;
	Boolean isPickupOnly;
	Boolean isSResElig;
	Boolean isSTSElig;
	Boolean isDispEligSr;
	Boolean isDispEligKm;
	Boolean isDispEligMg;
	Boolean isDispEligPr;
	
	public String getPrimAttrName() {
		return primAttrName;
	}
	public void setPrimAttrName(String primAttrName) {
		this.primAttrName = primAttrName;
	}
	public String getPrimAttrVal() {
		return primAttrVal;
	}
	public void setPrimAttrVal(String primAttrVal) {
		this.primAttrVal = primAttrVal;
	}
	public List<com.generated.xmls.collections.Group> getGroups() {
		return groups;
	}
	public void setGroups(List<com.generated.xmls.collections.Group> groups) {
		this.groups = groups;
	}
	
	public Boolean getIsDeliveryElig() {
		return isDeliveryElig;
	}
	public void setIsDeliveryElig(Boolean isDeliveryElig) {
		this.isDeliveryElig = isDeliveryElig;
	}
	public Boolean getIsShipElig() {
		return isShipElig;
	}
	public void setIsShipElig(Boolean isShipElig) {
		this.isShipElig = isShipElig;
	}
	public Boolean getIsSpuElig() {
		return isSpuElig;
	}
	public void setIsSpuElig(Boolean isSpuElig) {
		this.isSpuElig = isSpuElig;
	}
	public Boolean getIsPickupOnly() {
		return isPickupOnly;
	}
	public void setIsPickupOnly(Boolean isPickupOnly) {
		this.isPickupOnly = isPickupOnly;
	}
	public Boolean getIsSResElig() {
		return isSResElig;
	}
	public void setIsSResElig(Boolean isSResElig) {
		this.isSResElig = isSResElig;
	}
	public Boolean getIsSTSElig() {
		return isSTSElig;
	}
	public void setIsSTSElig(Boolean isSTSElig) {
		this.isSTSElig = isSTSElig;
	}
	public Boolean getIsDispEligSr() {
		return isDispEligSr;
	}
	public void setIsDispEligSr(Boolean isDispEligSr) {
		this.isDispEligSr = isDispEligSr;
	}
	public Boolean getIsDispEligKm() {
		return isDispEligKm;
	}
	public void setIsDispEligKm(Boolean isDispEligKm) {
		this.isDispEligKm = isDispEligKm;
	}
	public Boolean getIsDispEligMg() {
		return isDispEligMg;
	}
	public void setIsDispEligMg(Boolean isDispEligMg) {
		this.isDispEligMg = isDispEligMg;
	}
	public Boolean getIsDispEligPr() {
		return isDispEligPr;
	}
	public void setIsDispEligPr(Boolean isDispEligPr) {
		this.isDispEligPr = isDispEligPr;
	}
}
