package com.shi.content.northstar.tests;


import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.assertions.Asserts;
import com.shi.content.northstar.pages.EditStoreDetails;
import com.shi.content.northstar.pages.ICCEStores;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.SearchStorePage;

/**
*Test search by District
* @author inaikwa
*/
public class SearchStoresByDistrict extends NorthStarBaseTest {

	private ArrayList<String> stores;
	
	@Test(description="Test to verify search by District", groups = {"NS-P1"})
	public void testSearchByDistrict() {

		LinkPanel menuLinks = new LinkPanel();
		
		menuLinks.goToStoreLocator();
		
		SearchStorePage searchPage = new SearchStorePage();
		
		searchPage.searchByDistrict("306");
		
		stores= searchPage.getAllStoreIds();
		
		
		System.out.println("\nonline "+stores.size());
	
		System.out.println(stores);
		
		ArrayList<String> sStores = (ArrayList<String>) RestExecutor.getIdsByAltKey(CollectionValuesVal.STORE, "district","306"); 
		
		for (int i=0; i <sStores.size();i++){
			
			String storeType = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, sStores.get(i));
			String type =JsonStringParser.getJsonValueNew(storeType, "_blob.unit.strClsReason");
			if (type.replaceAll("\"", "").equalsIgnoreCase("Closed")) {

				sStores.remove(i);
			}
	
		}
		
		Asserts.verifyEquals(stores.size(), sStores.size(), "Stores fecthed are equal to stores displayed");
		
		Asserts.verifyTrue(stores.containsAll(sStores), "All stores fetched are matching with the stores displayed");
		
	
	
	}
	
}