package com.shi.content.wcsmigration.verifications;

import java.util.ArrayList;
import java.util.List;

import com.generated.vos.content.Content;
import com.generated.vos.contentbco.Bundle;
import com.generated.vos.contentbco.BundleGroup;
import com.generated.vos.contentbco.CollProduct;
import com.generated.vos.contentbco.DispTags;
import com.generated.vos.contentbco.Ffm;
import com.generated.vos.contentbco.Group;
import com.generated.vos.contentbco.Operational;
import com.generated.vos.contentbco.Product;
import com.generated.vos.contentbco.VariantColl;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.Replenishment;
import com.generated.vos.offer.Replenishment.PurchaseSts;
import com.generated.vos.promo.PromoDetails;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

public class BOC_OperationalVerifications implements Runnable {

	String idToTest;
	String type;
	Boolean isCrossformatted = false;
	String parentSite;
	
	List<BndlGrp> bundleGroups = new ArrayList<BndlGrp>();
	
	public BOC_OperationalVerifications(String id) {
		this.idToTest = id;
	}

	@Override
	public void run() {
		if(idToTest!=null) {
			
			APIResponse<Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENTBCO,idToTest);

			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Id", idToTest, " Bundle Not found in Content");
					CompareValuesUtility.setupResult(idToTest, true);
					return;
				}
				
				Bundle gbBundleContent = (Bundle)allResponse.getT();
				if(gbBundleContent == null){
					CompareValuesUtility.logFailed("Id", idToTest, " Bundle Not found in Content");
					CompareValuesUtility.setupResult(idToTest, true);
					return;
				}
				
				this.type = gbBundleContent.getClassifications().getCatentrySubType().toString();
				this.parentSite = this.type.equals("VB")?allResponse.getFtFieldValue("pgrmType"):gbBundleContent.getFfm().getSoldBy();
				
				if(!LoadProperties.SITE_NAME.equals("Both") && !LoadProperties.SITE_NAME.equals(this.parentSite)) {
					System.out.println("Ignoring "+this.parentSite+" bundle "+idToTest);
					return;
				}
				
				if((this.parentSite.equals("Sears") && gbBundleContent.getSites().contains("kmart"))
						||(this.parentSite.equals("Kmart") && gbBundleContent.getSites().contains("sears"))){
					this.isCrossformatted = true;
				}
				
				CompareValuesUtility.addDataFieldForReport("catentrySubType", type);
				CompareValuesUtility.addDataFieldForReport("soldBy", parentSite);
				CompareValuesUtility.addDataFieldForReport("sites", gbBundleContent.getSites().toString());
				CompareValuesUtility.addDataFieldForReport("isCrossformatted", isCrossformatted.toString());
				
				//System.out.println("Testing id: " + idToTest + "; catentrySubType:" + type + "; soldBy:" + parentSite);

				if(type.equals("B")){
					verifyBundle(gbBundleContent, type, idToTest);
				}
				else if(type.equals("VB")){
					verifyVariantBundle(gbBundleContent, type, idToTest);
				}
				else{
					verifyCollection(gbBundleContent, type, idToTest);
				}
					
				CompareValuesUtility.setupResult(idToTest, true);
			}catch(Throwable e){
				System.out.println("Check this id : "+ idToTest);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
		
	}

	private void verifyVariantBundle(Bundle gbBundleContent, String type, String id) {
		
		List<String> sites = gbBundleContent.getSites();
		
		//Operational flags for root level bundle
		Boolean srIsDispEligRoot = false;
		Boolean kmIsDispEligRoot = false;
		Boolean mgIsDispEligRoot = false;
		Boolean prIsDispEligRoot = false;
		
		List<VariantColl> variantColls = gbBundleContent.getVariantColls();
		Integer index = 0;
		
		for(VariantColl variantColl : variantColls){
			
			//Ffm flags for logical bundle
			Boolean isDeliveryElig = false;
			Boolean isShipElig = false;
			Boolean isSpuElig = false;
			Boolean isPickupOnly = true;
			Boolean isSRESElig = false;
			Boolean isSTSElig = false;
			
			//Operational flags for logical bundle
			Boolean srIsDispElig = false;
			Boolean kmIsDispElig = false;
			Boolean mgIsDispElig = false;
			Boolean prIsDispElig = false;
			
			for(Group group : variantColl.getGroups()){
				if(group.getIsPrimary()!=null && group.getIsPrimary()){
					if(group.getProducts().get(0).getFfm().getIsDeliveryElig()!=null && group.getProducts().get(0).getFfm().getIsDeliveryElig())
						isDeliveryElig = true;
					if(group.getProducts().get(0).getFfm().getIsShipElig()!=null && group.getProducts().get(0).getFfm().getIsShipElig())
						isShipElig = true;
					if(group.getProducts().get(0).getFfm().getIsSpuElig()!=null && group.getProducts().get(0).getFfm().getIsSpuElig())
						isSpuElig = true;
					if(group.getProducts().get(0).getFfm().getIsSResElig()!=null && group.getProducts().get(0).getFfm().getIsSResElig())
						isSRESElig = true;
					if(group.getProducts().get(0).getFfm().getIsSTSElig()!=null && group.getProducts().get(0).getFfm().getIsSTSElig())
						isSTSElig = true;
					if(group.getProducts().get(0).getFfm().getIsPickupOnly()!=null && !group.getProducts().get(0).getFfm().getIsPickupOnly())
						isPickupOnly = false;
					
					if(sites.contains("sears") && group.getProducts().get(0).getOperational().getSites().getSears().getIsDispElig())
						srIsDispElig = true;
					if(sites.contains("kmart") && group.getProducts().get(0).getOperational().getSites().getKmart().getIsDispElig())
						kmIsDispElig = true;
					if(sites.contains("mygofer") && group.getProducts().get(0).getOperational().getSites().getMygofer().getIsDispElig())
						mgIsDispElig = true;
					if(sites.contains("puertorico") && group.getProducts().get(0).getOperational().getSites().getPuertorico().getIsDispElig())
						prIsDispElig = true;
				}
			}
			
			CompareValuesUtility.addDataFieldForReport("variantCollIndex", index.toString());
			
			CompareValuesUtility.verifyNullOrEqual("Ffm", isDeliveryElig, variantColl.getFfm().getIsDeliveryElig(), "isDeliveryElig");
			CompareValuesUtility.verifyNullOrEqual("Ffm", isShipElig, variantColl.getFfm().getIsShipElig(), "isShipElig");
			CompareValuesUtility.verifyNullOrEqual("Ffm", isSpuElig, variantColl.getFfm().getIsSpuElig(), "isSpuElig");
			CompareValuesUtility.verifyNullOrEqual("Ffm", isPickupOnly, variantColl.getFfm().getIsPickupOnly(), "isPickupOnly");
			CompareValuesUtility.verifyNullOrEqual("Ffm", isSRESElig, variantColl.getFfm().getIsSResElig(), "isSRESElig");
			CompareValuesUtility.verifyNullOrEqual("Ffm", isSTSElig, variantColl.getFfm().getIsSTSElig(), "isSTSElig");
			CompareValuesUtility.addNewMultiValuedFields();
		
			CompareValuesUtility.verifyNullOrEqual("Operational", sites.contains("sears")?srIsDispElig:null, variantColl.getOperational()==null?null:(variantColl.getOperational().getSites()==null?null:(variantColl.getOperational().getSites().getSears()==null?null:variantColl.getOperational().getSites().getSears().getIsDispElig())), "SearsIsDispElig");
			CompareValuesUtility.verifyNullOrEqual("Operational", sites.contains("kmart")?kmIsDispElig:null, variantColl.getOperational()==null?null:(variantColl.getOperational().getSites()==null?null:(variantColl.getOperational().getSites().getKmart()==null?null:variantColl.getOperational().getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
			CompareValuesUtility.verifyNullOrEqual("Operational", sites.contains("mygofer")?mgIsDispElig:null, variantColl.getOperational()==null?null:(variantColl.getOperational().getSites()==null?null:(variantColl.getOperational().getSites().getMygofer()==null?null:variantColl.getOperational().getSites().getMygofer().getIsDispElig())), "MygoferIsDispElig");
			CompareValuesUtility.verifyNullOrEqual("Operational", sites.contains("puertorico")?prIsDispElig:null, variantColl.getOperational()==null?null:(variantColl.getOperational().getSites()==null?null:(variantColl.getOperational().getSites().getPuertorico()==null?null:variantColl.getOperational().getSites().getPuertorico().getIsDispElig())), "PRIsDispElig");
			CompareValuesUtility.addNewMultiValuedFields();
			
			if(sites.contains("sears") && srIsDispElig)
				srIsDispEligRoot = true;
			if(sites.contains("kmart") && kmIsDispElig)
				kmIsDispEligRoot = true;
			if(sites.contains("mygofer") && mgIsDispElig)
				mgIsDispEligRoot = true;
			if(sites.contains("puertorico") && prIsDispElig)
				prIsDispEligRoot = true;
			
			CompareValuesUtility.addNewData();
			index++;
		}

		/*If markfordelete is set, variant bundle dispelig should be false*/
		if(gbBundleContent.getOperational()!=null && gbBundleContent.getOperational().getIsMarkForDelete()!=null && gbBundleContent.getOperational().getIsMarkForDelete()){
			srIsDispEligRoot = false;
			kmIsDispEligRoot = false;
			mgIsDispEligRoot = false;
			prIsDispEligRoot = false;
		}
		
		CompareValuesUtility.verifyNullOrEqual("OperVarBundle", sites.contains("sears")?srIsDispEligRoot:null, gbBundleContent.getOperational()==null?null:(gbBundleContent.getOperational().getSites()==null?null:(gbBundleContent.getOperational().getSites().getSears()==null?null:gbBundleContent.getOperational().getSites().getSears().getIsDispElig())), "srIsDispElig");
		CompareValuesUtility.verifyNullOrEqual("OperVarBundle", sites.contains("kmart")?kmIsDispEligRoot:null, gbBundleContent.getOperational()==null?null:(gbBundleContent.getOperational().getSites()==null?null:(gbBundleContent.getOperational().getSites().getKmart()==null?null:gbBundleContent.getOperational().getSites().getKmart().getIsDispElig())), "kmIsDispElig");
		CompareValuesUtility.verifyNullOrEqual("OperVarBundle", sites.contains("mygofer")?mgIsDispEligRoot:null, gbBundleContent.getOperational()==null?null:(gbBundleContent.getOperational().getSites()==null?null:(gbBundleContent.getOperational().getSites().getMygofer()==null?null:gbBundleContent.getOperational().getSites().getMygofer().getIsDispElig())), "mgIsDispElig");
		CompareValuesUtility.verifyNullOrEqual("OperVarBundle", sites.contains("puertorico")?prIsDispEligRoot:null, gbBundleContent.getOperational()==null?null:(gbBundleContent.getOperational().getSites()==null?null:(gbBundleContent.getOperational().getSites().getPuertorico()==null?null:gbBundleContent.getOperational().getSites().getPuertorico().getIsDispElig())), "prIsDispElig");
		CompareValuesUtility.addNewMultiValuedFields();
		
	}

	private void verifyCollection(Bundle gbBundleContent, String type, String id) {
		List<BndlGrpProduct> products = new ArrayList<BndlGrpProduct>();
		
		for(CollProduct prd : gbBundleContent.getProducts()){
			BndlGrpProduct product = verifyProduct(prd.getId(), prd.getOfferId());
			products.add(product);
		}
		CompareValuesUtility.addNewMultiValuedFields();

		Operational gbCntOper = gbBundleContent.getOperational();
		Ffm collectionFfm = gbBundleContent.getFfm();
		
		Boolean isDispElig = isCollectionDispElig(products, gbBundleContent);
		Boolean isAvail = isCollectionAvail(products, gbBundleContent, isDispElig);
		Boolean isSpuElig = isCollectionSpuElig(products);
		Boolean isMailable = isCollectionMailable(products);
		Boolean isSResElig = isCollectionSResElig(products);
		PurchaseSts purchaseSts = CollectionPurchaseSts(products);
		//String firstOnlineDt = findCollectionFOD(products);
		
		String channel = null;
		String warehouseLocation = null;
		
		for(BndlGrpProduct p : products){
			if(p.getIsDispElig()){
				channel = p.getChannel()==null?null:p.getChannel();
				warehouseLocation = p.getWarehouseLocation()==null?null:p.getWarehouseLocation();
			}
		}

		CompareValuesUtility.verifyNullOrEqual("Shipping", isMailable, gbBundleContent.getShipping()==null?null:gbBundleContent.getShipping().getIsMailable(),"isMailable");
		
		CompareValuesUtility.verifyNullOrEqual("Ffm", isSResElig, collectionFfm.getIsStoreResElig()==null?null:collectionFfm.getIsStoreResElig(),"isStoreResElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isSpuElig, collectionFfm.getIsSpuElig()==null?null:collectionFfm.getIsSpuElig(),"isSpuElig");
		//CompareValuesUtility.verifyNullOrEqual("Ffm", false, collectionFfm.getIsDeliveryElig()==null?null:collectionFfm.getIsDeliveryElig(),"isDeliveryElig");
		//CompareValuesUtility.verifyNullOrEqual("Ffm", false, collectionFfm.getIsShipElig()==null?null:collectionFfm.getIsShipElig(),"isShipElig");
		
		String collChannel = collectionFfm.getChannel()==null?null:collectionFfm.getChannel();
		String collWrhsLcn = collectionFfm.getWarehouseLocation()==null?null:collectionFfm.getWarehouseLocation();
		
		if(collChannel!=null && channel==null){
			CompareValuesUtility.logPassed("Ffm", collChannel, collChannel, "channel");
		}else{
			CompareValuesUtility.verifyNullOrEqual("Ffm", channel, collChannel, "channel");
		}
		if(collWrhsLcn!=null && warehouseLocation==null){
			CompareValuesUtility.logPassed("Ffm", collWrhsLcn, collWrhsLcn, "warehouseLocation");
		}else{
			CompareValuesUtility.verifyNullOrEqual("Ffm", warehouseLocation, collWrhsLcn, "warehouseLocation");
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("Replenishment", purchaseSts, gbBundleContent.getReplenishment()==null?null:gbBundleContent.getReplenishment().getPurchaseSts(),"purchaseSts");
		
		if(parentSite.equals("Sears")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsOnline())), "SearsIsOnline");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsAvail())), "SearsIsAvail");
			if(isCrossformatted){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsOnline())), "KmartIsOnline");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsAvail())), "KmartIsAvail");
			}
		}else if(parentSite.equals("Kmart")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsOnline())), "KmartIsOnline");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsAvail())), "KmartIsAvail");
			if(isCrossformatted){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsOnline())), "SearsIsOnline");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsAvail())), "SearsIsAvail");
			}
		}
		//CompareValuesUtility.verifyNullOrEqual("Operational", firstOnlineDt, gbCntOper==null?null:(gbCntOper.getFirstOnlineDt()==null?null:gbCntOper.getFirstOnlineDt()), "firstOnlineDt");
		if(isDispElig){
			CompareValuesUtility.verifyNotNull("Operational", gbCntOper==null?null:(gbCntOper.getFirstOnlineDt()==null?null:gbCntOper.getFirstOnlineDt()), "firstOnlineDt");
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyBundle(Bundle gbBundleContent, String type, String id) {

		for(BundleGroup group : gbBundleContent.getBundleGroup()){
			BndlGrp bundleGroup = new BndlGrp();
			List<BndlGrpProduct> products = new ArrayList<BndlGrpProduct>();
			
			bundleGroup.setName(group.getName());
			bundleGroup.setType(group.getType());
			
			for(Product prd : group.getProducts()){
				BndlGrpProduct product = verifyProduct(prd.getId(), prd.getOfferId());
				products.add(product);
			}
			CompareValuesUtility.addNewMultiValuedFields();

			bundleGroup.setProducts(products);
			bundleGroups.add(bundleGroup);
		}
		
		/*Ffm*/
		Ffm bundleFfm = gbBundleContent.getFfm();
		
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleDeliveryElig(), bundleFfm.getIsDeliveryElig()==null?null:bundleFfm.getIsDeliveryElig()," isDeliveryElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleShipElig(), bundleFfm.getIsShipElig()==null?null:bundleFfm.getIsShipElig(),"isShipElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleSpuElig(), bundleFfm.getIsSpuElig()==null?null:bundleFfm.getIsSpuElig(),"isSpuElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundlePickupOnly(), bundleFfm.getIsPickupOnly()==null?null:bundleFfm.getIsPickupOnly(),"isPickupOnly");
		CompareValuesUtility.addNewMultiValuedFields();
		
		/*Operational*/
		Operational gbCntOper = gbBundleContent.getOperational();
		DispTags dispTags = gbBundleContent.getDispTags();
		
		Boolean isDispElig = isBundleDispElig(gbCntOper, parentSite, dispTags);
		Boolean isAvail = isBundleAvail(gbCntOper, isDispElig);
		//String firstOnlineDt = findBundleFOD(bundleGroups);
		
		if(parentSite.equals("Sears")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsOnline())), "SearsIsOnline");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsAvail())), "SearsIsAvail");
			if(isCrossformatted){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsOnline())), "KmartIsOnline");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsAvail())), "KmartIsAvail");
			}
		}else if(parentSite.equals("Kmart")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsOnline())), "KmartIsOnline");
			//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getIsAvail())), "KmartIsAvail");
			if(isCrossformatted){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsOnline())), "SearsIsOnline");
				//CompareValuesUtility.verifyNullOrEqual("Operational", isAvail, gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getIsAvail())), "SearsIsAvail");
			}
		}
		//CompareValuesUtility.verifyNullOrEqual("Operational", firstOnlineDt, gbCntOper==null?null:(gbCntOper.getFirstOnlineDt()==null?null:gbCntOper.getFirstOnlineDt()), "firstOnlineDt");
		if(isDispElig){
			CompareValuesUtility.verifyNotNull("Operational", gbCntOper==null?null:(gbCntOper.getFirstOnlineDt()==null?null:gbCntOper.getFirstOnlineDt()), "firstOnlineDt");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	private Boolean isBundleAvail(Operational gbCntOper, Boolean isDispElig) {
		/*If bundle isDispElig=false, return isAvail as false*/
		if(!isDispElig){
			return false;
		}
		
		Boolean isAvail = false;
				
		/*Check at least one product from each required group is Disp eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsAvail()){
						bFound = true;
						isAvail = true;
						break;
					}
				}
				if(!bFound){
					isAvail = false;
					break;
				}
			}
		}
		return isAvail;
	}

	/*Returns the latest firstOnlineDt among online child items under the collection*/
	private String findCollectionFOD(List<BndlGrpProduct> products) {
		String fod = null;
		
		for(BndlGrpProduct prd : products){
			if(prd.isDispElig){
				if(fod==null){
					fod = prd.getFirstOnlineDt();
				}else if(JodaDateTimeUtility.isFirstDateBeforeSecond(fod, prd.getFirstOnlineDt())){
					fod = prd.getFirstOnlineDt();
				}
			}
		}
		return fod;
	}

	/*Set collection purchaseSts to U if all child items has purchaseSts=U*/
	private PurchaseSts CollectionPurchaseSts(List<BndlGrpProduct> products) {
		PurchaseSts purchaseSts = null;
		Integer onlineCount = 0;
		Integer unAvailableCount = 0;
		for(BndlGrpProduct prd : products){
			if(prd.getIsDispElig()){
				onlineCount++;
				if(prd.getPurchaseSts()!=null && prd.getPurchaseSts().equals(Replenishment.PurchaseSts.U)){
					unAvailableCount++;
				}
			}		
		}
		if(onlineCount > 0 
				//&& onlineCount.equals(products.size()) 
				&& onlineCount.equals(unAvailableCount))
			purchaseSts = Replenishment.PurchaseSts.U;
		
		return purchaseSts;
	}

	/*Set collection isSresElig to true if all child items are isSresElig*/
	private Boolean isCollectionSResElig(List<BndlGrpProduct> products) {
		Boolean isSResElig = false;
		for(BndlGrpProduct prd : products){
			if(prd.getIsDispElig()){
				isSResElig = true;
			}
			if(!prd.getIsSResElig() && prd.getIsDispElig()){
				isSResElig = false;
				break;
			}
		}
		
		return isSResElig;
	}

	/*Set collection isMailable to true if all child items are isMailable*/
	private Boolean isCollectionMailable(List<BndlGrpProduct> products) {
		Boolean isMailable = false;
		for(BndlGrpProduct prd : products){
			if(prd.getIsDispElig()){
				isMailable = true;
			}
			if(!prd.getIsMailable() && prd.getIsDispElig()){
				isMailable = false;
				break;
			}
		}
		
		return isMailable;
	}
	
	/*Set collection isSpuElig to true if any one child item is isSpuElig*/
	private Boolean isCollectionSpuElig(List<BndlGrpProduct> products) {
		Boolean isSpuElig = false;
		for(BndlGrpProduct prd : products){
			if(prd.getIsSpuElig() && prd.getIsDispElig()){
				isSpuElig = true;
				break;
			}
		}
		
		return isSpuElig;
	}

	/*Return collection isDispElig*/
	private Boolean isCollectionDispElig(List<BndlGrpProduct> products, Bundle gbBundleContent) {
		Integer onlineCount = 0;
		Boolean isDispElig = false;
		
		/*If isMarkForDelete is set, set collection isDispElig as false*/
		if(gbBundleContent.getOperational()!=null && gbBundleContent.getOperational().getIsMarkForDelete()!=null && gbBundleContent.getOperational().getIsMarkForDelete()){
			return false;
		}
		
		for(BndlGrpProduct prd : products){
			if(prd.getIsDispElig()){
				onlineCount++;
			}
		}
		
		/*If at least two child products are online, set collection isDispElig as true*/
		if(onlineCount > 2 || onlineCount.equals(2))
			isDispElig = true;
		else
			isDispElig = false;
		
		return isDispElig;
	}
	
	private Boolean isCollectionAvail(List<BndlGrpProduct> products, Bundle gbBundleContent, Boolean isDispElig) {
		
		if(!isDispElig){
			return false;
		}
		
		Integer availCount = 0;
		Boolean isAvail = false;
		
		for(BndlGrpProduct prd : products){
			if(prd.getIsDispElig() && prd.getIsAvail()){
				availCount++;
			}
		}
		
		/*If at least two child products are online, set collection isDispElig as true*/
		if(availCount > 2 || availCount.equals(2))
			isAvail = true;
		else
			isAvail = false;
		
		return isAvail;
	}

	@SuppressWarnings("finally")
	private BndlGrpProduct verifyProduct(String prdId, String prdOfferId) {
		
		BndlGrpProduct product = new BndlGrpProduct();
		
		APIResponse<Content> contResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,prdId);
			
		try{
			if(contResponse == null){
				CompareValuesUtility.logFailed("BundleGroupPrds", prdId, " Not found in GB Content", "ProductId");
			}else{
				Content gbContent = (Content)contResponse.getT();
				if(gbContent == null){
					CompareValuesUtility.logFailed("BundleGroupPrds", prdId, " Not found in GB Content", "ProductId");
				}else{
					
					List<String> offerList = new ArrayList<String>();
					Boolean isVariation = gbContent.getClassifications().getCatentrySubType().equals("NV")?false:true;
					/*if(gbContent.getClassifications().getCatentrySubType().equals("NV")){
						offerList.add(prdId.substring(0, prdId.length()-1));
					}else{*/
					List<String> onlineOfferList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+prdId+"&isDispElig=true"+"&dispSite="+parentSite.toLowerCase());
					
					/*Check if online offer list is empty. If so get all offer for the product*/
					if(onlineOfferList.size()==0 || onlineOfferList.isEmpty()){
						offerList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+prdId);
					}else{
						offerList = onlineOfferList;
					}
					//}
					if(offerList.size()!=0 && !offerList.isEmpty()){
						
						String offerId = null;
						APIResponse<com.generated.vos.offer.Offer> offerResponse = null;
						com.generated.vos.offer.Offer gbOffer = null;
						
						if(!type.equals("B")){
							for(String ofrId : offerList){
								offerResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,ofrId);
								if(offerResponse != null){
									gbOffer = (com.generated.vos.offer.Offer)offerResponse.getT();
									if(gbOffer != null){
										if(gbOffer.getOperational()==null || gbOffer.getOperational().getSites()==null){
											continue; //check next offer if no operational tag
										}else if(offerResponse.getFtFieldValue("pgrmType").equals("Sears") && 
												gbOffer.getOperational().getSites().getSears()!=null && 
												gbOffer.getOperational().getSites().getSears().getIsDispElig()!=null && 
												gbOffer.getOperational().getSites().getSears().getIsDispElig()){
											offerId = ofrId;
											break; //break if offer is online in sears
										}else if(offerResponse.getFtFieldValue("pgrmType").equals("Kmart") &&
												gbOffer.getOperational().getSites().getKmart()!=null && 
												gbOffer.getOperational().getSites().getKmart().getIsDispElig()!=null && 
												gbOffer.getOperational().getSites().getKmart().getIsDispElig()){
											offerId = ofrId;	
											break; //break is offer is online in kmart
										}
									}
								}
								offerResponse = null;
								gbOffer = null;
							}
						}
						
						if(offerId == null){
							offerId = offerList.get((offerList.size()-1));
						}
						
						CompareValuesUtility.addDataFieldForReport("ProductId", prdId);
						CompareValuesUtility.addDataFieldForReport("ProductType", gbContent.getClassifications().getCatentrySubType());
						
						if(offerResponse == null){
							offerResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offerId);
						}
	
						if(offerResponse == null){
							CompareValuesUtility.logFailed("BundleGroupPrds", offerId, " Not found in GB Offer", "OfferId");
						}else{
							gbOffer = (com.generated.vos.offer.Offer)offerResponse.getT();
							if(gbOffer == null){
								CompareValuesUtility.logFailed("BundleGroupPrds", offerId, " Not found in GB Offer", "OfferId");
							}else{								

								Boolean isDispElig = false;
								Boolean isAvail = false;
								
								/*Setting isDispElig based on parent store*/
								if(gbOffer.getOperational()==null || gbOffer.getOperational().getSites()==null){
									isDispElig = false;
									isAvail = false;
								}else if(offerResponse.getFtFieldValue("pgrmType").equals("Sears")){
									isDispElig = (gbOffer.getOperational().getSites().getSears()==null || !gbOffer.getSites().contains("sears"))?false:(gbOffer.getOperational().getSites().getSears().getIsDispElig()==null?false:gbOffer.getOperational().getSites().getSears().getIsDispElig());
									isAvail = (gbOffer.getOperational().getSites().getSears()==null || !isDispElig)?false:(gbOffer.getOperational().getSites().getSears().getIsAvail()==null?false:gbOffer.getOperational().getSites().getSears().getIsAvail());
								}else if(offerResponse.getFtFieldValue("pgrmType").equals("Kmart")){
									isDispElig = (gbOffer.getOperational().getSites().getKmart()==null || !gbOffer.getSites().contains("kmart"))?false:(gbOffer.getOperational().getSites().getKmart().getIsDispElig()==null?false:gbOffer.getOperational().getSites().getKmart().getIsDispElig());
									isAvail = (gbOffer.getOperational().getSites().getKmart()==null || !isDispElig)?false:(gbOffer.getOperational().getSites().getKmart().getIsAvail()==null?false:gbOffer.getOperational().getSites().getKmart().getIsAvail());
								}else{
									isDispElig = false;
									isAvail = false;
								}
								
								product.setIsDispElig(isDispElig);
								product.setIsAvail(isAvail);
								
								Boolean mailable = false;
								Boolean isSres = false;
								Boolean isSpu = false;
								Boolean isShip = false;
								Boolean isDelivery = false;
								PurchaseSts purSts = null;
								String onlineOfrId = offerId;
								if(isVariation){
									List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
									mailable = getVarMailable(offers);
									isSres = getVarSresElig(offers);
									isSpu = getVarSpuElig(offers);
									isShip = getVarShipElig(offers);
									isDelivery = getVarDelvElig(offers);
									purSts = getVarPurSts(offers);
									isAvail = getVarisAvail(offers);
									isDispElig = getVarisDispElig(offers);
									onlineOfrId = getVarOnlineOfrId(offers);
								}
								
								product.setIsDispElig(isDispElig);
								product.setIsAvail(isAvail);
								
								product.setIsDeliveryElig(isVariation?isDelivery:((gbOffer.getFfm()==null || gbOffer.getFfm().getIsDeliveryElig()==null)?false:gbOffer.getFfm().getIsDeliveryElig()));
								product.setIsShipElig(isVariation?isShip:((gbOffer.getFfm()==null || gbOffer.getFfm().getIsShipElig()==null)?false:gbOffer.getFfm().getIsShipElig()));
								product.setChannel(gbOffer.getFfm()==null?null:gbOffer.getFfm().getChannel());
								product.setOfferId(isVariation?(onlineOfrId==null?offerId:onlineOfrId):offerId);
								
								product.setIsSpuElig(isVariation?isSpu:((gbOffer.getFfm()==null || gbOffer.getFfm().getIsSpuElig()==null)?false:gbOffer.getFfm().getIsSpuElig()));								
								product.setIsSResElig(isVariation?isSres:((gbOffer.getFfm()==null || gbOffer.getFfm().getIsSResElig()==null)?false:gbOffer.getFfm().getIsSResElig()));
								product.setIsMailable(isVariation?mailable:((gbOffer.getShipping()==null || gbOffer.getShipping().getIsMailable()==null)?false:gbOffer.getShipping().getIsMailable()));
								product.setPurchaseSts(isVariation?purSts:((gbOffer.getReplenishment()==null || gbOffer.getReplenishment().getPurchaseSts()==null)?null:gbOffer.getReplenishment().getPurchaseSts()));
								product.setFirstOnlineDt((gbContent.getOperational()==null || gbContent.getOperational().getFirstOnlineDt()==null)?null:gbContent.getOperational().getFirstOnlineDt());
								product.setWarehouseLocation((gbOffer.getFfm()==null || gbOffer.getFfm().getWrhsLcns()==null || gbOffer.getFfm().getWrhsLcns().size()==0)?null:gbOffer.getFfm().getWrhsLcns().get(0));
								
								if(prdOfferId!=null){ 
									//&& (product.getIsDispElig()?offerId:null)==null
									CompareValuesUtility.logPassed("OfferId", prdOfferId, prdOfferId);
								}else{
									CompareValuesUtility.verifyNullOrEqual("OfferId", product.getIsDispElig()?offerId:null, prdOfferId);
								}

							}
						}
					}else{
						System.out.println("No offer for the product: " + prdId);
					}
				}
					
			}
		}catch(Throwable e){
			System.out.println("Check this id : "+ idToTest +" : "+ prdId);
			e.printStackTrace();
		}finally{
			return product;
		}
	}

	private String getVarOnlineOfrId(List<Offer> offers) {
		String onlineOfferId = null;
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				onlineOfferId = offer.getId();
				break;
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				onlineOfferId = offer.getId();
				break;
			}
		}
		return onlineOfferId;
	}

	private Boolean getVarDelvElig(List<Offer> offers) {
		Boolean delvelig = false;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsDeliveryElig()!=null && offer.getFfm().getIsDeliveryElig()){
					delvelig = true;
					break;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsDeliveryElig()!=null && offer.getFfm().getIsDeliveryElig()){
					delvelig = true;
					break;
				}
			}
		}
		return delvelig;
	}

	private Boolean getVarShipElig(List<Offer> offers) {
		Boolean shipelig = false;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsShipElig()!=null && offer.getFfm().getIsShipElig()){
					shipelig = true;
					break;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsShipElig()!=null && offer.getFfm().getIsShipElig()){
					shipelig = true;
					break;
				}
			}
		}
		return shipelig;
	}

	private Boolean getVarisDispElig(List<Offer> offers) {
		Boolean isDispElig = false;
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				isDispElig = true;
				break;
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				isDispElig = true;
				break;
			}
		}
		return isDispElig;
	}

	private Boolean getVarisAvail(List<Offer> offers) {
		Boolean isAvail = false;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				if(offer.getOperational().getSites().getSears().getIsAvail()!=null 
						&& offer.getOperational().getSites().getSears().getIsAvail()){
					isAvail = true;
					break;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				if(offer.getOperational().getSites().getKmart().getIsAvail()!=null 
						&& offer.getOperational().getSites().getKmart().getIsAvail()){
					isAvail = true;
					break;
				}
			}
		}
		return isAvail;
	}

	private PurchaseSts getVarPurSts(List<Offer> offers) {
		PurchaseSts purSts = null;
		Integer onlineCnt = 0;
		Integer unAvailCnt = 0;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				onlineCnt++;
				if(offer.getReplenishment()!=null 
						&& offer.getReplenishment().getPurchaseSts()!=null 
						&& offer.getReplenishment().getPurchaseSts().equals(Replenishment.PurchaseSts.U)){
					unAvailCnt++;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				onlineCnt++;
				if(offer.getReplenishment()!=null 
						&& offer.getReplenishment().getPurchaseSts()!=null 
						&& offer.getReplenishment().getPurchaseSts().equals(Replenishment.PurchaseSts.U)){
					unAvailCnt++;
				}
			}
		}
		if(onlineCnt > 0 && onlineCnt.equals(unAvailCnt))
			purSts = Replenishment.PurchaseSts.U;
		
		return purSts;
	}

	private Boolean getVarSpuElig(List<Offer> offers) {
		Boolean spuelig = false;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsSpuElig()!=null && offer.getFfm().getIsSpuElig()){
					spuelig = true;
					break;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				if(offer.getFfm()!=null && offer.getFfm().getIsSpuElig()!=null && offer.getFfm().getIsSpuElig()){
					spuelig = true;
					break;
				}
			}
		}
		return spuelig;
	}

	private Boolean getVarSresElig(List<Offer> offers) {
		Boolean sreselig = false;
		Integer onlineCnt = 0;
		Integer sreseligCnt = 0;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				onlineCnt++;
				if(offer.getFfm()!=null && offer.getFfm().getIsSResElig()!=null && offer.getFfm().getIsSResElig()){
					sreseligCnt++;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				onlineCnt++;
				if(offer.getFfm()!=null && offer.getFfm().getIsSResElig()!=null && offer.getFfm().getIsSResElig()){
					sreseligCnt++;
				}
			}
		}
		if(onlineCnt > 0 && onlineCnt.equals(sreseligCnt))
			sreselig = true;
		else
			sreselig = false;
		
		return sreselig;
	}

	private Boolean getVarMailable(List<Offer> offers) {
		Boolean mailable = false;
		Integer onlineCnt = 0;
		Integer mailableCnt = 0;
		//List<com.generated.vos.offer.Offer> offers = RestExecutor.getDataById(CollectionValuesVal.OFFER, offerList);
		for(com.generated.vos.offer.Offer offer : offers){
			if(offer.getOperational()==null || offer.getOperational().getSites()==null){
				continue;
			}else if(parentSite.equals("Sears") 
					&& offer.getOperational().getSites().getSears()!=null 
					&& offer.getOperational().getSites().getSears().getIsDispElig()!=null
					&& offer.getOperational().getSites().getSears().getIsDispElig()){
				onlineCnt++;
				if(offer.getShipping()!=null && offer.getShipping().getIsMailable()!=null && offer.getShipping().getIsMailable()){
					mailableCnt++;
				}
			}else if(parentSite.equals("Kmart") 
					&& offer.getOperational().getSites().getKmart()!=null 
					&& offer.getOperational().getSites().getKmart().getIsDispElig()!=null
					&& offer.getOperational().getSites().getKmart().getIsDispElig()){
				onlineCnt++;
				if(offer.getShipping()!=null && offer.getShipping().getIsMailable()!=null && offer.getShipping().getIsMailable()){
					mailableCnt++;
				}
			}
		}
		if(onlineCnt > 0 && onlineCnt.equals(mailableCnt))
			mailable = true;
		else
			mailable = false;
		
		return mailable;
	}

	/*Returns the latest firstOnlineDt among online child items under the any of the required groups under the bundle*/
	private String findBundleFOD(List<BndlGrp> bundleGroups) {
		
		String fod = null;
		
		for(BndlGrp group : bundleGroups){
			if(group.getType().equals("required")){
				for(BndlGrpProduct prd : group.getProducts()){
					if(prd.isDispElig){
						if(fod==null){
							fod = prd.getFirstOnlineDt();
						}else if(JodaDateTimeUtility.isFirstDateBeforeSecond(fod, prd.getFirstOnlineDt())){
							fod = prd.getFirstOnlineDt();
						}
					}
				}
			}
		}
		return fod;
	}
	
	/*Returns true if bundle is Display eligible*/
	private Boolean isBundleDispElig(Operational gbCntOper, String parentSite, DispTags dispTags) {
		
		/*If isMarkForDelete is true in GB content, return isDispElig as false*/
		if(!(gbCntOper==null) && !(gbCntOper.getIsMarkForDelete()==null) && gbCntOper.getIsMarkForDelete()){
			return false;
		}
		
		Boolean isDispElig = false;
				
		/*Check at least one product from each required group is Disp eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig()){
						bFound = true;
						isDispElig = true;
						break;
					}
				}
				if(!bFound){
					isDispElig = false;
					break;
				}
			}
		}
		
		Boolean hasActivePromotion = false;
		Boolean isBndlPromoReqd = false;
		/*Check if the bundle has isBndlPromoReqd as true. If so, bundle should have active promotion to be disp eligible*/
		if(dispTags!=null && dispTags.getIsBndlPromoReqd()!=null && dispTags.getIsBndlPromoReqd()){
			isBndlPromoReqd = true;
			
			String promorelId = parentSite.toLowerCase()+"_"+idToTest;
			com.generated.vos.promo.neww.Promorel promorel = RestExecutor.getDataById(CollectionValuesVal.PROMO_REL_NEW, promorelId);
			
			String grpName = parentSite.equals("Sears")?"SearsBundleDiscountPromotion":"KmartBundleDiscountPromotion";
			
			if(promorel!=null && promorel.getPromoList()!=null){
				for(PromoDetails p : promorel.getPromoList().getRegular()){
					if (p.getPromoType().equals("BundleSimple")
							&& p.getGrpName().equals(grpName)
							&& p.getStatus().equals("a")) {
						if (JodaDateTimeUtility.validateDate(p.getStartDt(), p.getEndDt())) {
							hasActivePromotion = true;
							break;
						}
					}
				}
			}
		}
		if(isBndlPromoReqd && !hasActivePromotion){
			isDispElig = false;
		}
		
		return isDispElig;
	}
	
	/*Returns true if bundle is Delivery eligible*/
	private Boolean isBundleDeliveryElig() {
		
		Boolean isDeliveryElig = false;
		Boolean atleastOneDlvryElig = false;
		Boolean oneReqDlvryShipElig = false;
		
		/*Check at least one online product from any group is Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
				if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig()){
					atleastOneDlvryElig = true;
					break;
				}
			}
			if(atleastOneDlvryElig)
				break;
		}
		
		/*Check at least one online product from each required group is Ship or Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && 
							(bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig() || bundleGroups.get(i).getProducts().get(j).getIsShipElig())){
						bFound = true;
						oneReqDlvryShipElig = true;
						break;
					}
				}
				if(!bFound){
					oneReqDlvryShipElig = false;
					break;
				}
			}
		}
		
		if(atleastOneDlvryElig && oneReqDlvryShipElig)
			isDeliveryElig = true;
		
		return isDeliveryElig;
	}
	
	/*Returns true if bundle is Ship eligible*/
	private Boolean isBundleShipElig() {
		
		Boolean isShipElig = false;
		Boolean atleastOneShipElig = false;
		Boolean oneReqDlvryShipElig = false;
		
		/*Check at least one online product from any group is Ship eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
				if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsShipElig()){
					atleastOneShipElig = true;
					break;
				}
			}
			if(atleastOneShipElig)
				break;
		}
		
		/*Check at least one online product from each required group is Ship or Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() &&
							(bundleGroups.get(i).getProducts().get(j).getIsShipElig() || bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig())){
						bFound = true;
						oneReqDlvryShipElig = true;
						break;
					}
				}
				if(!bFound){
					oneReqDlvryShipElig = false;
					break;
				}
			}
		}
		
		if(atleastOneShipElig && oneReqDlvryShipElig)
			isShipElig = true;
		
		return isShipElig;
	}
	
	/*Returns true if bundle is Spu eligible*/
	private Boolean isBundleSpuElig() {
		
		Boolean isSpuElig = false;
		
		/*Check at least one online product from each required group is SPU eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsSpuElig()){
						bFound = true;
						isSpuElig = true;
						break;
					}
				}
				if(!bFound){
					isSpuElig = false;
					break;
				}
			}
		}
		return isSpuElig;
	}
	
	/*Returns true if bundle is Pickup only*/
	private Boolean isBundlePickupOnly() {
		
		Boolean isPickupOnly = false;
		
		/*Check if all online items from all required groups are SPU only*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")){
				isPickupOnly = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					/*First set isPickupOnly to true if there is atleast one required group with atleast one online item*/
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig()){
						isPickupOnly = true;
						/*If channel is not SPU for any one online item from a required group, then set isPickupOnly as false and exit*/
						if(null==bundleGroups.get(i).getProducts().get(j).getChannel() || 
								!(bundleGroups.get(i).getProducts().get(j).getChannel().equals("SPU"))){
							isPickupOnly = false;
							break;
						}
					}
				}
				if(!isPickupOnly){
					break;
				}
			}
		}
		return isPickupOnly;
	}
	
	/*Bundle Group VO*/
	private class BndlGrp {

		public BndlGrp() {
			this.name = null;
			this.type = null;
			this.products = null;
		}

		String name;
		String type;
		List<BndlGrpProduct> products;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public List<BndlGrpProduct> getProducts() {
			return products;
		}

		public void setProducts(List<BndlGrpProduct> products) {
			this.products = products;
		}
	}

	/*Bundle Group Product VO*/
	private class BndlGrpProduct {

		public BndlGrpProduct() {
			this.isDispElig = false;
			this.isAvail = false;
			this.isDeliveryElig = false;
			this.isShipElig = false;
			this.isSpuElig = false;
			this.channel = null;
			this.offerId = null;
			this.isSResElig = false;
			this.isMailable = false;
			this.purchaseSts = null;
			this.firstOnlineDt = null;
			this.warehouseLocation = null;
		}

		private Boolean isDispElig;
		private Boolean isAvail;
		private Boolean isDeliveryElig;
		private Boolean isShipElig;
		private Boolean isSpuElig;
		private String channel;
		private String offerId;
		private Boolean isSResElig;
		private Boolean isMailable;
		private PurchaseSts purchaseSts;
		private String firstOnlineDt;
		private String warehouseLocation;

		public Boolean getIsDispElig() {
			return isDispElig;
		}

		public void setIsDispElig(Boolean isDispElig) {
			this.isDispElig = isDispElig;
		}

		public Boolean getIsDeliveryElig() {
			return isDeliveryElig;
		}

		public void setIsDeliveryElig(Boolean isDeliveryElig) {
			this.isDeliveryElig = isDeliveryElig;
		}

		public Boolean getIsShipElig() {
			return isShipElig;
		}

		public void setIsShipElig(Boolean isShipElig) {
			this.isShipElig = isShipElig;
		}

		public Boolean getIsSpuElig() {
			return isSpuElig;
		}

		public void setIsSpuElig(Boolean isSpuElig) {
			this.isSpuElig = isSpuElig;
		}

		public String getChannel() {
			return channel;
		}

		public void setChannel(String channel) {
			this.channel = channel;
		}
		
		public String getOfferId() {
			return offerId;
		}

		public void setOfferId(String offerId) {
			this.offerId = offerId;
		}

		public Boolean getIsSResElig() {
			return isSResElig;
		}

		public void setIsSResElig(Boolean isSResElig) {
			this.isSResElig = isSResElig;
		}

		public Boolean getIsMailable() {
			return isMailable;
		}

		public void setIsMailable(Boolean isMailable) {
			this.isMailable = isMailable;
		}

		public PurchaseSts getPurchaseSts() {
			return purchaseSts;
		}

		public void setPurchaseSts(PurchaseSts purchaseSts) {
			this.purchaseSts = purchaseSts;
		}

		public String getFirstOnlineDt() {
			return firstOnlineDt;
		}

		public void setFirstOnlineDt(String firstOnlineDt) {
			this.firstOnlineDt = firstOnlineDt;
		}

		public String getWarehouseLocation() {
			return warehouseLocation;
		}

		public void setWarehouseLocation(String warehouseLocation) {
			this.warehouseLocation = warehouseLocation;
		}

		public Boolean getIsAvail() {
			return isAvail;
		}

		public void setIsAvail(Boolean isAvail) {
			this.isAvail = isAvail;
		}
	}
}
