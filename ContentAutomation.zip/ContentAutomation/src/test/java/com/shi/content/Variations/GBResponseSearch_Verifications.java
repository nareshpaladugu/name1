package com.shi.content.Variations;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.db.CollectionValues;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class GBResponseSearch_Verifications implements Runnable{
	
	String idToTest;
	CollectionValues gbSearchcollection;

	public GBResponseSearch_Verifications(String idToTest){
		this.idToTest = idToTest;
		
		switch(LoadProperties.collection){
			case "offer":{
				gbSearchcollection = CollectionValuesVal.OFFER;
				break;
			}
			case "content":{
				gbSearchcollection = CollectionValuesVal.CONTENT;
				break;
			}
			case "attribute":{
				gbSearchcollection = CollectionValuesVal.ATTRIBUTE;
				break;
			}
			case "attrvalue":{
				gbSearchcollection = CollectionValuesVal.ATTRIBUTE_VALUE;
				break;
			}
		}
	}

	public void run() {
		CompareValuesUtility.init();
		//Offer offer =  RestExecutor.getDataById(CollectionValuesVal.OFFER,idToTest);

		String offerToTest = RestExecutor.getJSonResponseById(gbSearchcollection,idToTest);
		
		//System.out.println(offerToTest);
		if(offerToTest.contains(LoadProperties.gbSearchString)) {
			System.out.println(LoadProperties.gbSearchString+" is present for: "+ idToTest);
			if(!LoadProperties.gbSearchPassIfNotPresent) {
				CompareValuesUtility.logPassed("Id", idToTest, LoadProperties.gbSearchString+" is present");
			}else {
				CompareValuesUtility.logFailed("Id", idToTest, LoadProperties.gbSearchString+" is present");	
			}
			CompareValuesUtility.setupResult(idToTest+"", true);
		} else if(offerToTest.equals("[]")) {
			System.out.println("Offer response null for: "+ idToTest);
			CompareValuesUtility.logFailed("Id", idToTest, " Offer response NULL");
			CompareValuesUtility.setupResult(idToTest+"", true);
		} else {
			System.out.println(LoadProperties.gbSearchString+" is not present for: "+ idToTest);
			if(!LoadProperties.gbSearchPassIfNotPresent) {
				CompareValuesUtility.logFailed("Id", idToTest, LoadProperties.gbSearchString+" is NOT present");
			}else {
				CompareValuesUtility.logPassed("Id", idToTest, LoadProperties.gbSearchString+" is NOT present");
			}
			CompareValuesUtility.setupResult(idToTest+"", true);
		}
		
		/*if(offer == null){
			System.out.println("Offer response null for: "+ idToTest);
		} else if (offer.getDispTags() != null 
				&& offer.getDispTags().getIsSearchSupression() != null 
				&& offer.getDispTags().getIsSearchSupression() == true) {
			System.out.println("IsSearchSupression is true for: "+ idToTest);
		} else {
			System.out.println("IsSearchSupression is null/false for: "+ idToTest);
		}*/
	}
}

