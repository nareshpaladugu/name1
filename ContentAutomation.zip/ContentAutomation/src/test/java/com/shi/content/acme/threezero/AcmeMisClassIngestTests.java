package com.shi.content.acme.threezero;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.testcommons.FileProviderClass;

public class AcmeMisClassIngestTests {

	public static String misClassFlag;
	
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider", groups="AcmeMisClassIngestTests")
	public void misClassIngestTest(String sFileName) 
	{
		
		misClassFlag =System.getProperty("ExpectedMissClass", "false");
		
		System.out.println("misClassFlag... "+misClassFlag);
		
		System.out.println("Testing sFileName "+ sFileName);

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		try{
			FileInputStream fstream = new FileInputStream(sFileName);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)   {
				pool.execute(new MisClassIngestVerification((strLine.trim())));
			}
			in.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}

		pool.shutdown();

		try {
			pool.awaitTermination(40, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
