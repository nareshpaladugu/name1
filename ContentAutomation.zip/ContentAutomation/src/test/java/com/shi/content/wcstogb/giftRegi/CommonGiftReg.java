package com.shi.content.wcstogb.giftRegi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.bson.Document;

import com.google.gson.Gson;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.shc.autocontent.db.DBUtil;
import com.shc.autocontent.gb.MongoDBClient;
import com.shc.autocontent.softasserts.CompareValuesUtility;

public class CommonGiftReg 
{

	public static String removeSpecialChar(String msg)
	{
		if(msg==null || msg.isEmpty())
			return msg;
		
		String tmp="" ;
		int iVal;
		for (int i = 0; i < msg.length(); i++) {
			
			iVal = (int)msg.charAt(i);
			
			if(iVal!=26 && iVal!=2)
			{
				tmp = tmp +msg.charAt(i);
			}
		}
		
		return tmp;
	}
	public static Map<String,String> WShowerMap = new HashMap<String, String>();

	public static Map<String,String> BShowerMap = new HashMap<String, String>();

	public static Map<String,String> EShowerMap = new HashMap<String, String>();

	public static void initMaps()
	{
		String weddingShowerMapList[] ={"0_C=TriggeredSRSGRWedCongratsDOW","8_W=TriggeredSRSGRWedWelcomeDay8","30_R=TriggeredSRSGRWedOutDay30","42_R=TriggeredSRSGRWedOutDay42","10_R=TriggeredSRSGRWedOutDay10","8_R=TriggeredSRSGRWedOutDay8","7_R=TriggeredSRSGRWedOutDay7","3_R=TriggeredSRSGRWedOutDay3","20_W=TriggeredSRSGRWedDay20","45_W=TriggeredSRSGRWedGetAway","8_W=TriggeredSRSGRWedWelcomeDay8","0_C=TriggeredSRSGRWedCongratsDOW"};

		String babyShowerMapList[] = {"20_W=TriggeredSRSGRBabyDay20","0_C=TriggeredSRSGRBabyCongrats","10_R=Triggered_SRS_GR10DWed"};

		String etcShowerMapList[] = {"0_C=TriggeredSRSGREtcWelcome"};

		for (String str : weddingShowerMapList) {

			WShowerMap.put(str.split("=")[0],str.split("=")[1]);
		}

		for (String str : babyShowerMapList) {

			BShowerMap.put(str.split("=")[0],str.split("=")[1]);
		}

		for (String str : etcShowerMapList) {

			EShowerMap.put(str.split("=")[0],str.split("=")[1]);
		}
	}


	private static Gson gson = new Gson();

	public static MongoDatabase database = null;

	public static MongoClient mongoClient = null;	

	public static Map<String,String> eventData  = new HashMap<String, String>();

	public String getEventType(String id)
	{
		if(eventData.get(id)==null)
		{
			String sQuery  ="select EVENTTYPENAME from GREVNTTYPE where EVENTTYPE_ID = '"+id+"' with ur";

			eventData.put(id,DBUtil.executeQuerySingleResult(sQuery));
		}

		return eventData.get(id);
	}
	/**
	 * Connect to mongo db
	 */
	public static void getGiftRegMongoDB()
	{
		if(database==null)
		{
			try 
			{
				mongoClient = MongoDBClient.connectToMongoDB("giftRegistry");

				database = mongoClient.getDatabase("giftRegistry");

			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Get mongo collection
	 * @param sCollName
	 * @return
	 */
	public static MongoCollection<Document> getCollection(String sCollName)
	{
		return database.getCollection(sCollName);
	}


	/**
	 * Get Collection
	 * @param sCollName
	 * @return
	 */
	public static DBCollection getDBCollection(String sCollName)
	{
		DB db = mongoClient.getDB("giftRegistry");

		return db.getCollection(sCollName);
	}


	public static Map<String,String>  getMap(ResultSet rs)
	{	

		Map<String,String> singleRowData = new HashMap<String,String>();

		try {
			int colSize = rs.getMetaData().getColumnCount();
			for (int i=1;i<=colSize;i++) {

				singleRowData.put(rs.getMetaData().getColumnName(i), rs.getString(i));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return singleRowData;
	}


	/**
	 * Convert json to appropriate object
	 * @param sJsonResponse
	 * @param t
	 * @return
	 */
	public static <T> T getCollectionObject(String sJsonResponse,  Class<T> t)
	{
		return gson.fromJson(sJsonResponse, t);

	}

	public void compareAsNumbers(String field, String sExp, Object sAct,String... strings )
	{
		if((sExp==null || sExp.isEmpty()) &&( sAct==null || sAct.toString().isEmpty()))
		{
			CompareValuesUtility.logPassed(field, "null","null");
			return;
		}
		Double dExp=null;

		try {
			dExp = Double.parseDouble(sExp);
		} catch (Exception e1) {
			dExp = 0d;
		}

		Double dAct =null;

		try {
			dAct  = Double.parseDouble(sAct.toString());
		} catch (Exception e) {
			dAct = null;
		}

		if(dExp==null && dAct == null)
		{
			CompareValuesUtility.logPassed(field, "null", "null", strings);			
		}
		else if(dExp!=null && dExp.equals(dAct))
		{
			CompareValuesUtility.logPassed(field, sExp==null?dExp:sExp, sAct, strings);			
		}
		else
		{
			Object exp = sExp==null?"null":sExp;
			Object act = sAct==null?"null":sAct;

			CompareValuesUtility.logFailed(field, exp, act, strings);
		}
	}
}
