package com.shi.content.bundles;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.getPositionInList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.generated.vos.bundle.BundleSchema;
import com.generated.vos.bundle.Hierarchy__;
import com.generated.vos.bundle.Product;
import com.generated.vos.bundle.Val_;
import com.generated.vos.content.Content;
import com.generated.vos.content.Desc;
import com.generated.vos.contentbco.Assets;
import com.generated.vos.contentbco.Attachment;
import com.generated.vos.contentbco.Brand;
import com.generated.vos.contentbco.Bundle;
import com.generated.vos.contentbco.DispTags;
import com.generated.vos.contentbco.Facets;
import com.generated.vos.contentbco.Ffm;
import com.generated.vos.contentbco.Hierarchy;
import com.generated.vos.contentbco.Hierarchy_;
import com.generated.vos.contentbco.Img_;
import com.generated.vos.contentbco.Operational;
import com.generated.vos.contentbco.SpecificHierarchy;
import com.generated.vos.contentbco.Taxonomy;
import com.generated.vos.contentbco.Video;
import com.generated.vos.contentbco.VocTag;
import com.generated.vos.promo.PromoDetails;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.BeanComparor;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.autocontent.utils.JodaDateTimeUtility;
import com.shc.content.restutils.RestExecutor;

/**
 * @author mbashee
 * Created : 18 March 2015
 */

public class BundleVerifications implements Runnable {

	private String sBundleIdToTest;
	private String errResp;

	List<BndlGrp> bundleGroups = new ArrayList<BndlGrp>();
	
	public BundleVerifications(String bundleId)
	{
		this.sBundleIdToTest=bundleId;
	}
	
	public void run() {
		
		if(sBundleIdToTest!=null) {
			
			APIResponse<Bundle> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENTBCO,sBundleIdToTest);

			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Id", sBundleIdToTest, " Bundle Not found in Content");
					CompareValuesUtility.setupResult(sBundleIdToTest, true);
					return;
				}
				
				Bundle gbBundleContent = (Bundle)allResponse.getT();
				if(gbBundleContent == null){
					CompareValuesUtility.logFailed("Id", sBundleIdToTest, " Bundle Not found in Content");
					CompareValuesUtility.setupResult(sBundleIdToTest, true);
					return;
				}
				//System.out.println("Testing bundle id " + sBundleIdToTest);
				
				if(!LoadProperties.SITE_NAME.equals("Both") && !LoadProperties.SITE_NAME.equals(gbBundleContent.getFfm().getSoldBy())) {
					System.out.println("Ignoring "+gbBundleContent.getFfm().getSoldBy()+" bundle "+sBundleIdToTest);
					return;
				}
				
				String sURL = "http://"+LoadProperties.OTHERGBBOX+"/bundle-service/v1/get/bundle/"+sBundleIdToTest;
				//String sURL = "http://"+LoadProperties.OTHERGBBOX+"/bundle-service/bundle/"+sBundleIdToTest;
				System.out.println(sURL);
	
				//long l1 = System.currentTimeMillis();
				String response = RestExecutor.getJSonResponse(sURL);
				//long l2 = System.currentTimeMillis();
				//System.out.println("Bundle service response time : " + (l2 - l1));
				
				if(response==null){
					CompareValuesUtility.logFailed("Id", sBundleIdToTest, " Bundle Not found in Bundle Service");
					CompareValuesUtility.setupResult(sBundleIdToTest, true);
					return;
				}
				if(response.equals("TIME OUT ERROR")){
					CompareValuesUtility.logFailed("Id", sBundleIdToTest, " TIME OUT ERROR");
					CompareValuesUtility.setupResult(sBundleIdToTest, true);
					return;
				}
				
                this.errResp = response;
				//System.out.println("response..."+response);
				BundleSchema bundleSchema = JSONParser.parseJSON(response, BundleSchema.class);

				if(bundleSchema == null){
					CompareValuesUtility.logFailed("Id", sBundleIdToTest, " Bundle Not found in Bundle Service");
					CompareValuesUtility.setupResult(sBundleIdToTest, true);
					return;
				}
				com.generated.vos.bundle.Bundle bundleService = bundleSchema.getBlob().getBundle();

				verifyBundle(gbBundleContent, bundleService, sBundleIdToTest);
					
				CompareValuesUtility.setupResult(sBundleIdToTest, true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ sBundleIdToTest);
				System.out.println(this.errResp);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	}

	private void verifyBundle(Bundle gbBundleContent, com.generated.vos.bundle.Bundle bundleService, String sBundleId) {
		
		compareValues("Id", sBundleId, bundleService.getId());
		compareValues("Name", gbBundleContent.getName(), bundleService.getName());
		
		compareValues("Classifications", gbBundleContent.getClassifications().getCatentrySubType(), bundleService.getClassifications().getCatentrySubType(),"catentrySubType");
		compareValues("Classifications", gbBundleContent.getClassifications().getEnrichmentProvider(), bundleService.getClassifications().getEnrichmentProvider(),"enrichmentProvider");
		CompareValuesUtility.addNewMultiValuedFields();

		Brand contBrand = gbBundleContent.getBrand();
		com.generated.vos.bundle.Brand serviceBrand = bundleService.getBrand();
		CompareValuesUtility.verifyNullOrEqual("Brand", contBrand==null?null:contBrand.getId(), serviceBrand==null?null:serviceBrand.getId(),"id");
		CompareValuesUtility.verifyNullOrEqual("Brand", contBrand==null?null:contBrand.getName(), serviceBrand==null?null:serviceBrand.getName(),"name");
		CompareValuesUtility.verifyNullOrEqual("Brand", contBrand==null?null:(contBrand.getImg()==null?null:contBrand.getImg().getAttrs().getSrc()), serviceBrand==null?null:(serviceBrand.getImg()==null?null:serviceBrand.getImg().getAttrs().getSrc()),"imageUrl");
		CompareValuesUtility.addNewMultiValuedFields();
		
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getTitle(), bundleService.getSeo().getTitle(),"title");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getDesc(), bundleService.getSeo().getDesc(),"desc");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getUrl(), bundleService.getSeo().getUrl(),"url");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getProductAltTag(), bundleService.getSeo().getProductAltTag(),"productAltTag");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getFeatureAltTag(), bundleService.getSeo().getFeatureAltTag(),"featureAltTag");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getIsRobotFollow(), bundleService.getSeo().getIsRobotFollow(),"isRobotFollow");
		CompareValuesUtility.verifyNullOrEqual("Seo", gbBundleContent.getSeo().getIsRobotIndex(), bundleService.getSeo().getIsRobotIndex(),"isRobotIndex");
		CompareValuesUtility.addNewMultiValuedFields();
		
		String catentryId = GenericUtil.convertToString(gbBundleContent.getAltIds().getCatentryId());
		CompareValuesUtility.verifyNullOrEqual("AltIds", gbBundleContent.getAltIds().getSpinId(), bundleService.getAltIds().getSpinId(),"spinId");
		CompareValuesUtility.verifyNullOrEqual("AltIds", catentryId, bundleService.getAltIds().getCatentryId(),"catentryId");
		CompareValuesUtility.addNewMultiValuedFields();
		
		verifySites(gbBundleContent.getSites(), bundleService.getSites());
		verifyDesc(gbBundleContent.getDesc(), bundleService.getDesc());
		
		CompareValuesUtility.verifyNullOrEqual("DispTags", gbBundleContent.getDispTags()==null?null:gbBundleContent.getDispTags().getIsFxdPriceBndl(), bundleService.getDispTags()==null?null:bundleService.getDispTags().getIsFxdPriceBndl(),"isFxdPriceBndl");
		CompareValuesUtility.verifyNullOrEqual("DispTags", gbBundleContent.getDispTags()==null?null:gbBundleContent.getDispTags().getIsBndlPromoReqd(), bundleService.getDispTags()==null?null:bundleService.getDispTags().getIsBndlPromoReqd(),"isBndlPromoReqd");
		CompareValuesUtility.addNewMultiValuedFields();
		
		verifyVocTags(gbBundleContent.getVocTags(), bundleService.getVocTags());
		verifyFacets(gbBundleContent.getFacets(), bundleService.getFacets());
		verifyBundleGroup(gbBundleContent.getBundleGroup(), bundleService.getBundleGroup());
		CompareValuesUtility.addNewMultiValuedFields();
		
		/*verifyFfm and verifyOperational should only be invoked after verifyBundleGroup.*/
		verifyFfm(gbBundleContent.getFfm(), bundleService.getFfm());
		verifyOperational(gbBundleContent.getOperational(), bundleService.getOperational(), gbBundleContent.getFfm().getSoldBy(), gbBundleContent.getDispTags(), gbBundleContent.getSites());

		verifyAssets(gbBundleContent.getAssets(), bundleService.getAssets());
		verifyTaxonomy(gbBundleContent.getTaxonomy(), bundleService.getTaxonomy());

	}

	private void verifyBundleGroup(List<com.generated.vos.contentbco.BundleGroup> gbCntBndlGrp, List<com.generated.vos.bundle.BundleGroup> bndlGrp) {
		
		for(com.generated.vos.contentbco.BundleGroup gb : gbCntBndlGrp){
			Boolean bFound = false;
					
			BndlGrp bundleGroup = new BndlGrp();
			List<BndlGrpProduct> products = new ArrayList<BndlGrpProduct>();
			
			bundleGroup.setName(gb.getName());
			bundleGroup.setType(gb.getType());
			
			for(com.generated.vos.bundle.BundleGroup bd : bndlGrp){
				if(gb.getName().equals(bd.getName()) && gb.getType().equals(bd.getType())) {
					bFound = true;
					CompareValuesUtility.verifyNullOrEqual("BundleGroup", gb.getName(), bd.getName(), "Name");
					CompareValuesUtility.verifyNullOrEqual("BundleGroup", gb.getType(), bd.getType(), "Type");
					CompareValuesUtility.verifyNullOrEqual("BundleGroup", gb.getRank(), bd.getRank(), "Rank");
					CompareValuesUtility.verifyNullOrEqual("BundleGroup", gb.getProducts().size(), bd.getProducts().size(), "ProductCount");
						
					for(com.generated.vos.contentbco.Product gbPrd : gb.getProducts()){
						Boolean pFound = false;
						for(Product bdPrd : bd.getProducts()){
							if(gbPrd.getId().equals(bdPrd.getId())){
								pFound = true;
								
								BndlGrpProduct product = verifyProduct(gbPrd.getId(), gbPrd, bdPrd);
								products.add(product);
								break; //break when product found
							}
						}
						if(!pFound){
							CompareValuesUtility.logFailed("BundleGroupPrds", gbPrd.getId(), "Not Found", "ProductId");
						}
					}
					break; //break when group found
				}
			}
			if(!bFound){
				if(!(gb.getProducts().size()==0)){
					Boolean pFound = false;
					for(com.generated.vos.contentbco.Product gbPrd : gb.getProducts()){
						pFound = false;
						String id = gbPrd.getId();
						List<String> offerList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+id);
						if(offerList.size() > 0){
							pFound = true;
							break;
						}
					}
					if(!pFound){
						CompareValuesUtility.logPassed("BundleGroup", gb.getName(), "No products under the group; skipping group", "Name");
						CompareValuesUtility.logPassed("BundleGroup", gb.getType(), "No products under the group; skipping group", "Type");
						CompareValuesUtility.logPassed("BundleGroup", gb.getRank(), "No products under the group; skipping group", "Rank");
						CompareValuesUtility.logPassed("BundleGroup", gb.getProducts().size(), "No products under the group; skipping group", "ProductCount");
					}else{
					    CompareValuesUtility.logFailed("BundleGroup", gb.getName(), "Not found", "Name");
					    CompareValuesUtility.logFailed("BundleGroup", gb.getType(), "Not found", "Type");
					    CompareValuesUtility.logFailed("BundleGroup", gb.getRank(), "Not found", "Rank");
					    CompareValuesUtility.logFailed("BundleGroup", gb.getProducts().size(), "Not found", "ProductCount");
					}
				}else{
					CompareValuesUtility.logPassed("BundleGroup", gb.getName(), "No products under the group; skipping group", "Name");
					CompareValuesUtility.logPassed("BundleGroup", gb.getType(), "No products under the group; skipping group", "Type");
					CompareValuesUtility.logPassed("BundleGroup", gb.getRank(), "No products under the group; skipping group", "Rank");
					CompareValuesUtility.logPassed("BundleGroup", gb.getProducts().size(), "No products under the group; skipping group", "ProductCount");
				}
			}
			bundleGroup.setProducts(products);
			bundleGroups.add(bundleGroup);
		}
	}
	
	/*Returns true if bundle is Display eligible*/
	private Boolean isBundleDispElig(Operational gbCntOper, String parentSite, DispTags dispTags) {
		
		/*If isMarkForDelete is true in GB content, return isDispElig as false*/
		if(!(gbCntOper==null) && !(gbCntOper.getIsMarkForDelete()==null) && gbCntOper.getIsMarkForDelete()){
			return false;
		}
		
		Boolean isDispElig = false;
				
		/*Check at least one product from each required group is Disp eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig()){
						bFound = true;
						isDispElig = true;
						break;
					}
				}
				if(!bFound){
					isDispElig = false;
					break;
				}
			}
		}
		
		Boolean hasActivePromotion = false;
		Boolean isBndlPromoReqd = false;
		/*Check if the bundle has isBndlPromoReqd as true. If so, bundle should have active promotion to be disp eligible*/
		if(dispTags!=null && dispTags.getIsBndlPromoReqd()!=null && dispTags.getIsBndlPromoReqd()){
			isBndlPromoReqd = true;
			
			String promorelId = parentSite.toLowerCase()+"_"+sBundleIdToTest;
			com.generated.vos.promo.neww.Promorel promorel = RestExecutor.getDataById(CollectionValuesVal.PROMO_REL_NEW, promorelId);
			
			String grpName = parentSite.equals("Sears")?"SearsBundleDiscountPromotion":"KmartBundleDiscountPromotion";
			
			if(promorel!=null && promorel.getPromoList()!=null){
				for(PromoDetails p : promorel.getPromoList().getRegular()){
					System.out.println("Inside promo validation");
					if (p.getPromoType().equals("BundleSimple")
							&& p.getGrpName().equals(grpName)
							&& p.getStatus().equals("a")) {
						if (JodaDateTimeUtility.validateDate(p.getStartDt(), p.getEndDt())) {
							hasActivePromotion = true;
							break;
						}
					}
				}
			}	
		}
		if(isBndlPromoReqd && !hasActivePromotion){
			isDispElig = false;
		}
		
		return isDispElig;
	}
	
	/*Returns true if bundle is Delivery eligible*/
	private Boolean isBundleDeliveryElig() {
		
		Boolean isDeliveryElig = false;
		Boolean atleastOneDlvryElig = false;
		Boolean oneReqDlvryShipElig = false;
		
		/*Check at least one online product from any group is Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
				if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig()){
					atleastOneDlvryElig = true;
					break;
				}
			}
			if(atleastOneDlvryElig)
				break;
		}
		
		/*Check at least one online product from each required group is Ship or Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && 
							(bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig() || bundleGroups.get(i).getProducts().get(j).getIsShipElig())){
						bFound = true;
						oneReqDlvryShipElig = true;
						break;
					}
				}
				if(!bFound){
					oneReqDlvryShipElig = false;
					break;
				}
			}
		}
		
		if(atleastOneDlvryElig && oneReqDlvryShipElig)
			isDeliveryElig = true;
		
		return isDeliveryElig;
	}
	
	/*Returns true if bundle is Ship eligible*/
	private Boolean isBundleShipElig() {
		
		Boolean isShipElig = false;
		Boolean atleastOneShipElig = false;
		Boolean oneReqDlvryShipElig = false;
		
		/*Check at least one online product from any group is Ship eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
				if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsShipElig()){
					atleastOneShipElig = true;
					break;
				}
			}
			if(atleastOneShipElig)
				break;
		}
		
		/*Check at least one online product from each required group is Ship or Delivery eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() &&
							(bundleGroups.get(i).getProducts().get(j).getIsShipElig() || bundleGroups.get(i).getProducts().get(j).getIsDeliveryElig())){
						bFound = true;
						oneReqDlvryShipElig = true;
						break;
					}
				}
				if(!bFound){
					oneReqDlvryShipElig = false;
					break;
				}
			}
		}
		
		if(atleastOneShipElig && oneReqDlvryShipElig)
			isShipElig = true;
		
		return isShipElig;
	}
	
	/*Returns true if bundle is Spu eligible*/
	private Boolean isBundleSpuElig() {
		
		Boolean isSpuElig = false;
		
		/*Check at least one online product from each required group is SPU eligible*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")) {
				Boolean bFound = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig() && bundleGroups.get(i).getProducts().get(j).getIsSpuElig()){
						bFound = true;
						isSpuElig = true;
						break;
					}
				}
				if(!bFound){
					isSpuElig = false;
					break;
				}
			}
		}
		return isSpuElig;
	}
	
	/*Returns true if bundle is Pickup only*/
	private Boolean isBundlePickupOnly() {
		
		Boolean isPickupOnly = false;
		
		/*Check if all online items from all required groups are SPU only*/
		for(int i=0; i < bundleGroups.size(); i++){
			if(bundleGroups.get(i).getType().equals("required")){
				isPickupOnly = false;
				for(int j=0; j < bundleGroups.get(i).getProducts().size(); j++){
					/*First set isPickupOnly to true if there is atleast one required group with atleast one online item*/
					if(bundleGroups.get(i).getProducts().get(j).getIsDispElig()){
						isPickupOnly = true;
						/*If channel is not SPU for any one online item from a required group, then set isPickupOnly as false and exit*/
						if(null==bundleGroups.get(i).getProducts().get(j).getChannel() || 
								!(bundleGroups.get(i).getProducts().get(j).getChannel().equals("SPU"))){
							isPickupOnly = false;
							break;
						}
					}
				}
				if(!isPickupOnly){
					break;
				}
			}
		}
		return isPickupOnly;
	}
	
	/*Bundle Group VO*/
	private class BndlGrp {

		public BndlGrp() {
			this.name = null;
			this.type = null;
			this.products = null;
		}

		String name;
		String type;
		List<BndlGrpProduct> products;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public List<BndlGrpProduct> getProducts() {
			return products;
		}

		public void setProducts(List<BndlGrpProduct> products) {
			this.products = products;
		}
	}

	/*Bundle Group Product VO*/
	private class BndlGrpProduct {

		public BndlGrpProduct() {
			this.isDispElig = false;
			this.isDeliveryElig = false;
			this.isShipElig = false;
			this.isSpuElig = false;
			this.channel = null;
			this.offerId = null;
		}

		Boolean isDispElig;
		Boolean isDeliveryElig;
		Boolean isShipElig;
		Boolean isSpuElig;
		String channel;
		String offerId;

		public Boolean getIsDispElig() {
			return isDispElig;
		}

		public void setIsDispElig(Boolean isDispElig) {
			this.isDispElig = isDispElig;
		}

		public Boolean getIsDeliveryElig() {
			return isDeliveryElig;
		}

		public void setIsDeliveryElig(Boolean isDeliveryElig) {
			this.isDeliveryElig = isDeliveryElig;
		}

		public Boolean getIsShipElig() {
			return isShipElig;
		}

		public void setIsShipElig(Boolean isShipElig) {
			this.isShipElig = isShipElig;
		}

		public Boolean getIsSpuElig() {
			return isSpuElig;
		}

		public void setIsSpuElig(Boolean isSpuElig) {
			this.isSpuElig = isSpuElig;
		}

		public String getChannel() {
			return channel;
		}

		public void setChannel(String channel) {
			this.channel = channel;
		}
		
		public String getOfferId() {
			return offerId;
		}

		public void setOfferId(String offerId) {
			this.offerId = offerId;
		}
	}
	
	@SuppressWarnings("finally")
	private BndlGrpProduct verifyProduct(String id, com.generated.vos.contentbco.Product gbPrd, Product bdPrd) {
		
		BndlGrpProduct product = new BndlGrpProduct();
		
		APIResponse<Content> contResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,id);
			
		try{
			if(contResponse == null){
				CompareValuesUtility.logFailed("BundleGroupPrds", id, " Not found in GB Content", "ProductId");
			}else{
				Content gbContent = (Content)contResponse.getT();
				if(gbContent == null){
					CompareValuesUtility.logFailed("BundleGroupPrds", id, " Not found in GB Content", "ProductId");
				}else{
					compareValues("BundleGroupPrds", id, bdPrd.getId(), "ProductId");
					
					//Fields to be validated from GB Product Content for the Product Id
					compareValues("BundleGroupPrds", gbContent.getName(), bdPrd.getName(), "Name");
					CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbContent.getMfr()==null?null:gbContent.getMfr().getModelNo(), bdPrd.getModelNo(), "ModelNo");
					CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbContent.getSeo()==null?null:gbContent.getSeo().getUrl(), bdPrd.getUrl(), "Url");
					CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbContent.getBrand()==null?null:gbContent.getBrand().getName(), bdPrd.getBrand(), "Brand");
					
					List<com.generated.vos.content.Desc> desc = gbContent.getDesc();
					int i = getPositionInList("S", desc, "type", Desc.class);
					compareValues("BundleGroupPrds", "S", bdPrd.getDesc()==null?null:bdPrd.getDesc().getType()==null?null:bdPrd.getDesc().getType(), "DescType");
					compareValues("BundleGroupPrds", desc.get(i).getVal()==null?null:desc.get(i).getVal(), bdPrd.getDesc()==null?null:bdPrd.getDesc().getVal()==null?null:bdPrd.getDesc().getVal(), "DescVal");
					compareValues("BundleGroupPrds", gbContent.getClassifications().getCatentrySubType()==null?null:gbContent.getClassifications().getCatentrySubType(), bdPrd.getCatentrySubType()==null?null:bdPrd.getCatentrySubType(), "CatentrySubType");

					//Sites
					for(String site : gbContent.getSites()){
						CompareValuesUtility.verifyItemInList("BundleGroupPrds", site, bdPrd.getSites(), "Sites");
					}
					
					//Product Images
					if(null!=gbContent.getAssets() && null!=gbContent.getAssets().getImgs() && null!=bdPrd.getImgs()){
					verifyPrdImgs(gbContent.getAssets().getImgs(), bdPrd.getImgs());
					}
					
					//Fields to be validation from the GB Bundle Content for the Product Id
					compareValues("BundleGroupPrds", gbPrd.getRank(), bdPrd.getRank(), "Rank");
					compareValues("BundleGroupPrds", gbPrd.getQuantity(), bdPrd.getQuantity(), "Quantity");

					//Fields to be validated from GB Product Offer for the Product Id
					
					List<String> offerList = new ArrayList<String>();
					if(gbContent.getClassifications().getCatentrySubType().equals("NV")){
						offerList.add(id.substring(0, id.length()-1));
					}else{
						List<String> onlineOfferList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+id+"&isDispElig=true");
						
						/*Check if online offer list is empty. If so get all offer for the product*/
						if(onlineOfferList.size()==0){
							offerList = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "parentId="+id);
						}else{
							offerList = onlineOfferList;
						}
					}
					if(offerList.size()!=0){
						String offerId = offerList.get((offerList.size()-1));
						
						compareValues("BundleGroupPrds", offerId, bdPrd.getOfferId(), "OfferId");
						
						APIResponse<com.generated.vos.offer.Offer> offerResponse = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offerId);
	
						if(offerResponse == null){
							CompareValuesUtility.logFailed("BundleGroupPrds", offerId, " Not found in GB Offer", "OfferId");
						}else{
							com.generated.vos.offer.Offer gbOffer = (com.generated.vos.offer.Offer)offerResponse.getT();
							if(gbOffer == null){
								CompareValuesUtility.logFailed("BundleGroupPrds", offerId, " Not found in GB Offer", "OfferId");
							}else{
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getDispTags()==null?false:(gbOffer.getDispTags().getIsSearchSupression()==null?false:gbOffer.getDispTags().getIsSearchSupression()), bdPrd.getIsSearchSupression(), "IsSearchSupression");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getShipping()==null?false:(gbOffer.getShipping().getIsMailable()==null?false:gbOffer.getShipping().getIsMailable()), bdPrd.getIsMailable(), "IsMailable");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getSsin(), bdPrd.getSsin(), "Ssin");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getIdentity()==null?null:gbOffer.getIdentity().getUid(), bdPrd.getUid(), "Uid");
								
								//Operational
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getOperational()==null?null:(gbOffer.getOperational().getSites()==null?null:(gbOffer.getOperational().getSites().getSears()==null?null:(gbOffer.getOperational().getSites().getSears().getIsDispElig()))), 
										bdPrd.getOperational()==null?null:(bdPrd.getOperational().getSites()==null?null:(bdPrd.getOperational().getSites().getSears()==null?null:(bdPrd.getOperational().getSites().getSears().getIsDispElig()))), "OpSrIsDispElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getOperational()==null?null:(gbOffer.getOperational().getSites()==null?null:(gbOffer.getOperational().getSites().getSears()==null?null:(gbOffer.getOperational().getSites().getSears().getFirstOnlineDt()))), 
										bdPrd.getOperational()==null?null:(bdPrd.getOperational().getSites()==null?null:(bdPrd.getOperational().getSites().getSears()==null?null:(bdPrd.getOperational().getSites().getSears().getFirstOnlineDt()))), "OpSrFirstOnlineDt");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getOperational()==null?null:(gbOffer.getOperational().getSites()==null?null:(gbOffer.getOperational().getSites().getKmart()==null?null:(gbOffer.getOperational().getSites().getKmart().getIsDispElig()))), 
										bdPrd.getOperational()==null?null:(bdPrd.getOperational().getSites()==null?null:(bdPrd.getOperational().getSites().getKmart()==null?null:(bdPrd.getOperational().getSites().getKmart().getIsDispElig()))), "OpKmIsDispElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getOperational()==null?null:(gbOffer.getOperational().getSites()==null?null:(gbOffer.getOperational().getSites().getKmart()==null?null:(gbOffer.getOperational().getSites().getKmart().getFirstOnlineDt()))), 
										bdPrd.getOperational()==null?null:(bdPrd.getOperational().getSites()==null?null:(bdPrd.getOperational().getSites().getKmart()==null?null:(bdPrd.getOperational().getSites().getKmart().getFirstOnlineDt()))), "OpKmFirstOnlineDt");
								
								//Ffm
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getChannel(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getChannel(), "Ffm-channel");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsDeliveryElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsDeliveryElig(), "Ffm-isDeliveryElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsSFSElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsSFSElig(), "Ffm-isSFSElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsShipElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsShipElig(), "Ffm-isShipElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsSResElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsSResElig(), "Ffm-isSResElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsSTSElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsSTSElig(), "Ffm-isSTSElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getSTSChannel(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getSTSChannel(), "Ffm-STSChannel");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getIsSpuElig(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getIsSpuElig(), "Ffm-isSpuElig");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getDfltFfmDisplay(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getDfltFfmDisplay(), "Ffm-dfltFfmDisplay");
								CompareValuesUtility.verifyNullOrEqual("BundleGroupPrds", gbOffer.getFfm()==null?null:gbOffer.getFfm().getSoldBy(), bdPrd.getFfm()==null?null:bdPrd.getFfm().getSoldBy(), "Ffm-soldBy");
								

								/*Setting BundleProduct values to evaluate bundle aggregation rules later*/
								product.setChannel(gbOffer.getFfm()==null?null:gbOffer.getFfm().getChannel());
								product.setIsDeliveryElig((gbOffer.getFfm()==null || gbOffer.getFfm().getIsDeliveryElig()==null)?false:gbOffer.getFfm().getIsDeliveryElig());
								product.setIsShipElig((gbOffer.getFfm()==null || gbOffer.getFfm().getIsShipElig()==null)?false:gbOffer.getFfm().getIsShipElig());
								product.setIsSpuElig((gbOffer.getFfm()==null || gbOffer.getFfm().getIsSpuElig()==null)?false:gbOffer.getFfm().getIsSpuElig());								
								product.setOfferId(offerId);
								
								/*Setting isDispElig based on parent store*/
								if(gbOffer.getOperational()==null || gbOffer.getOperational().getSites()==null){
									product.setIsDispElig(false);
								}else if(offerResponse.getFtFieldValue("pgrmType").equals("Sears")){
									product.setIsDispElig(gbOffer.getOperational().getSites().getSears()==null?false:(gbOffer.getOperational().getSites().getSears().getIsDispElig()==null?false:gbOffer.getOperational().getSites().getSears().getIsDispElig()));
								}else if(offerResponse.getFtFieldValue("pgrmType").equals("Kmart")){
									product.setIsDispElig(gbOffer.getOperational().getSites().getKmart()==null?false:(gbOffer.getOperational().getSites().getKmart().getIsDispElig()==null?false:gbOffer.getOperational().getSites().getKmart().getIsDispElig()));
								}else{
									product.setIsDispElig(false);
								}
							}
						}
					}else{
						CompareValuesUtility.logFailed("BundleGroupPrds", id+": No offer for the product", bdPrd.getId(), "OfferId");
					}
				}
					
			}
		}catch(Throwable e){
			System.out.println("Check this id :"+ sBundleIdToTest +" : "+ id);
			e.printStackTrace();
		}finally{
			return product;
		}
	}

	private void verifyPrdImgs(List<com.generated.vos.content.Img_> gbContImgs, com.generated.vos.bundle.Imgs bdPrdImgs) {
		
		String gbimgVal=null;
		String bdimgVal=null;
		Boolean bFound =false;
		List<Object> commonImageContent = new ArrayList<Object>();
		List<Object> commonImageBundle = new ArrayList<Object>();
		for (Iterator<com.generated.vos.content.Img_> iterator = gbContImgs.iterator(); iterator.hasNext();) {
			List<com.generated.vos.content.Img_> contImg = new ArrayList<com.generated.vos.content.Img_>();	
			com.generated.vos.content.Img_ image =  iterator.next();
			contImg.add(image);
			List<com.generated.vos.content.Val> imageval = contImg.get(0).getVals();
			if(image.getType().equals("P")){
				for ( com.generated.vos.content.Val imgVal : imageval) {
					gbimgVal = "[type="+image.getType()+", title="+imgVal.getTitle()+", height="+imgVal.getHeight()+", width="+imgVal.getWidth()+", src="+imgVal.getSrc()+"]";
					commonImageContent.add(gbimgVal);
				}
			}
		}
		//for (Iterator<Img___> iterator = bdPrdImgs.iterator(); iterator.hasNext();) {
			List<com.generated.vos.bundle.Imgs> contImg = new ArrayList<com.generated.vos.bundle.Imgs>();	
			com.generated.vos.bundle.Imgs image = bdPrdImgs;
			contImg.add(image);
			List<com.generated.vos.bundle.Val_> imageval = contImg.get(0).getVals();
			for ( Val_ imgVal : imageval) {
				bdimgVal = "[type="+image.getType()+", title="+imgVal.getTitle()+", height="+imgVal.getHeight()+", width="+imgVal.getWidth()+", src="+imgVal.getSrc()+"]";
				commonImageBundle.add(bdimgVal);
			}
		//}
		for(Object content :commonImageContent){
			for(Object bundle :commonImageBundle){
				if(content.equals(bundle)){
			bFound = true;
			compareObjectList(commonImageContent, commonImageBundle,"BundleGroupPrds","PrdImgs");
				}if(!bFound){
					CompareValuesUtility.logFailed("BundleGroupPrds", commonImageContent, "Not Found", "PrdImgs");
				}
			}
		}
	}

	private void verifyOperational(Operational gbCntOper, com.generated.vos.bundle.Operational bndlOper, String parentSite, DispTags dispTags, List<String> sites) {
		
		CompareValuesUtility.verifyNullOrEqual("Operational", gbCntOper==null?null:gbCntOper.getIsMarkForDelete(), bndlOper==null?null:bndlOper.getIsMarkForDelete(), "isMarkForDelete");
		
		Boolean isDispElig = isBundleDispElig(gbCntOper, parentSite, dispTags);
		
		if(parentSite.equals("Sears")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
			CompareValuesUtility.verifyNullOrEqual("Operational", gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getFirstOnlineDt())), bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getFirstOnlineDt())), "SearsFirstOnlineDt");
			if(sites.contains("kmart")){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
				CompareValuesUtility.verifyNullOrEqual("Operational", gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getFirstOnlineDt())), bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getFirstOnlineDt())), "KmartFirstOnlineDt");
			}else{
				CompareValuesUtility.verifyNullOrEqual("Operational", null, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
				CompareValuesUtility.verifyNullOrEqual("Operational", null, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getFirstOnlineDt())), "KmartFirstOnlineDt");
			}
		}else if(parentSite.equals("Kmart")){
			CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getIsDispElig())), "KmartIsDispElig");
			CompareValuesUtility.verifyNullOrEqual("Operational", gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getKmart()==null?null:gbCntOper.getSites().getKmart().getFirstOnlineDt())), bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getKmart()==null?null:bndlOper.getSites().getKmart().getFirstOnlineDt())), "KmartFirstOnlineDt");
			if(sites.contains("sears")){
				CompareValuesUtility.verifyNullOrEqual("Operational", isDispElig, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
				CompareValuesUtility.verifyNullOrEqual("Operational", gbCntOper==null?null:(gbCntOper.getSites()==null?null:(gbCntOper.getSites().getSears()==null?null:gbCntOper.getSites().getSears().getFirstOnlineDt())), bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getFirstOnlineDt())), "SearsFirstOnlineDt");
			}else{
				CompareValuesUtility.verifyNullOrEqual("Operational", null, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getIsDispElig())), "SearsIsDispElig");
				CompareValuesUtility.verifyNullOrEqual("Operational", null, bndlOper==null?null:(bndlOper.getSites()==null?null:(bndlOper.getSites().getSears()==null?null:bndlOper.getSites().getSears().getFirstOnlineDt())), "SearsFirstOnlineDt");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFacets(Facets gbCntFacets, com.generated.vos.bundle.Facets bndlFacets) {
		
		if(gbCntFacets==null && bndlFacets!=null)
			CompareValuesUtility.logFailed("Facets", "null", "Found in bundle service");
		else if(gbCntFacets!=null && bndlFacets==null)
			CompareValuesUtility.logFailed("Facets", "Found in GB Content", "Not Found in bundle service");
		else if(gbCntFacets!=null && bndlFacets!=null){
			if(gbCntFacets.getSites().getSears()!=null){
				for(com.generated.vos.contentbco.Static_ gbfsr : gbCntFacets.getSites().getSears().getStatic()){
					String gbfsrVal = "[name="+gbfsr.getName()+", value="+gbfsr.getValue()+"]";
					Boolean bFound = false;
					for(com.generated.vos.bundle.Static bdfsr : bndlFacets.getSites().getSears().getStatic()){
						String bdfsrVal = "[name="+bdfsr.getName()+", value="+bdfsr.getValue()+"]";
						if(gbfsrVal.equals(bdfsrVal)){
							bFound = true;
							CompareValuesUtility.compareValues("Facets", gbfsrVal, bdfsrVal, "Sears");
							break;
						}
					}
					if(!bFound){
						CompareValuesUtility.logFailed("Facets", gbfsrVal, "Not Found", "Sears");
					}
				}
			}else{
				if(bndlFacets.getSites().getSears()!=null){
					CompareValuesUtility.logFailed("Facets", "null", "Found in bundle service", "Sears");
				}
			}
			if(gbCntFacets.getSites().getKmart()!=null){
				for(com.generated.vos.contentbco.Static_ gbfkm : gbCntFacets.getSites().getKmart().getStatic()){
					String gbfkmVal = "[name="+gbfkm.getName()+", value="+gbfkm.getValue()+"]";
					Boolean bFound = false;
					for(com.generated.vos.bundle.Static_ bdfkm : bndlFacets.getSites().getKmart().getStatic()){
						String bdfkmVal = "[name="+bdfkm.getName()+", value="+bdfkm.getValue()+"]";
						if(gbfkmVal.equals(bdfkmVal)){
							bFound = true;
							CompareValuesUtility.compareValues("Facets", gbfkmVal, bdfkmVal, "Kmart");
							break;
						}
					}
					if(!bFound){
						CompareValuesUtility.logFailed("Facets", gbfkmVal, "Not Found", "Kmart");
					}
				}
			}else{
				if(bndlFacets.getSites().getKmart()!=null){
					CompareValuesUtility.logFailed("Facets", "null", "Found in bundle service", "Kmart");
				}
			}
			
			//Removed facets/sites/mygofer from schema
			/*if(gbCntFacets.getSites().getMygofer()!=null){
				for(Static gbfmg : gbCntFacets.getSites().getMygofer().getStatic()){
					String gbfmgVal = "[name="+gbfmg.getName()+", value="+gbfmg.getValue()+"]";
					Boolean bFound = false;
					for(com.generated.vos.bundle.Static bdfmg : bndlFacets.getSites().getMygofer().getStatic()){
						String bdfmgVal = "[name="+bdfmg.getName()+", value="+bdfmg.getValue()+"]";
						if(gbfmgVal.equals(bdfmgVal)){
							bFound = true;
							CompareValuesUtility.compareValues("Facets", gbfmgVal, bdfmgVal, "Mygofer");
							break;
						}
					}
					if(!bFound){
						CompareValuesUtility.logFailed("Facets", gbfmgVal, "Not Found", "Mygofer");
					}
				}
			}else{
				if(bndlFacets.getSites().getMygofer()!=null){
					CompareValuesUtility.logFailed("Facets", "null", "Found in bundle service", "Mygofer");
				}
			}*/
		}
		CompareValuesUtility.addNewMultiValuedFields();		
	}

	private void verifyVocTags(List<VocTag> gbContVocTags, List<com.generated.vos.bundle.VocTag> bundlVocTags) {
		
		if(gbContVocTags.size() != 0){
			for(VocTag gb : gbContVocTags){
				String gbVal = "[displayPath="+gb.getDispPath()+", name="+gb.getName()+", type="+gb.getType()+"]";
				if(bundlVocTags.size()!=0){
					Boolean bFound = false;
					for(com.generated.vos.bundle.VocTag bd : bundlVocTags){
						String bdVal = "[displayPath="+bd.getDispPath()+", name="+bd.getName()+", type="+bd.getType()+"]";
						if(gbVal.equals(bdVal)){
							bFound = true;
							CompareValuesUtility.compareValues("VocTags", gbVal, bdVal);
							break;
						}
					}
					if(!bFound){
						CompareValuesUtility.logFailed("VocTags", gbVal, "Not found");
					}
				}else{
					CompareValuesUtility.logFailed("VocTags", gbVal, "Not found");
				}
			}
		}else{
			if(bundlVocTags.size()!=0){
				CompareValuesUtility.logFailed("VocTags", "null", "Found in bundle service");
			}
		}
		CompareValuesUtility.addNewMultiValuedFields();		
	}

	private void verifyDesc(List<com.generated.vos.contentbco.Desc> gbBundlCntDesc, List<com.generated.vos.bundle.Desc> bundleDesc) {
		for(com.generated.vos.contentbco.Desc d : gbBundlCntDesc) {
			Boolean bDescFound = false;
			for(com.generated.vos.bundle.Desc b : bundleDesc) {
				if(d.getType().toString().equals(b.getType().toString())) {
					bDescFound = true;
					compareValues("Desc", d.getVal(), b.getVal(), d.getType().toString());
				}
			}
			if(!bDescFound)
				compareValues("Desc", d.getVal(), "null", d.getType().toString());
		}
		
	}

	private void verifySites(List<String> expSites, List<String> actSites) {
		
		for(String s : expSites) {
			CompareValuesUtility.verifyItemInList("Sites", s, actSites);
		}
		CompareValuesUtility.addNewMultiValuedFields();		
	}
	
	
	private void verifyFfm(Ffm gbBundlCntFfm, com.generated.vos.bundle.Ffm bundleFfm) {
		
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleDeliveryElig(), bundleFfm.getIsDeliveryElig()==null?null:bundleFfm.getIsDeliveryElig(),"isDeliveryElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleShipElig(), bundleFfm.getIsShipElig()==null?null:bundleFfm.getIsShipElig(),"isShipElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundleSpuElig(), bundleFfm.getIsSpuElig()==null?null:bundleFfm.getIsSpuElig(),"isSpuElig");
		CompareValuesUtility.verifyNullOrEqual("Ffm", isBundlePickupOnly(), bundleFfm.getIsPickupOnly()==null?null:bundleFfm.getIsPickupOnly(),"isPickupOnly");
		
		CompareValuesUtility.verifyNullOrEqual("Ffm", gbBundlCntFfm.getSoldBy()==null?null:gbBundlCntFfm.getSoldBy(), bundleFfm.getSoldBy()==null?null:bundleFfm.getSoldBy(),"soldBy");
		CompareValuesUtility.verifyNullOrEqual("Ffm", gbBundlCntFfm.getSoldBy()==null?null:gbBundlCntFfm.getSoldBy(), bundleFfm.getFulfilledBy()==null?null:bundleFfm.getFulfilledBy(),"fulfilledBy");
		
		//Removed warehouseLocation from schema
		//CompareValuesUtility.verifyNullOrEqual("Ffm", gbBundlCntFfm.getWarehouseLocation()==null?null:gbBundlCntFfm.getWarehouseLocation(), bundleFfm.getWarehouseLocation()==null?null:bundleFfm.getWarehouseLocation(),"warehouseLocation");
		CompareValuesUtility.addNewMultiValuedFields();
	}
	
	
    private void verifyTaxonomy(Taxonomy gbBundlCntTaxo, com.generated.vos.bundle.Taxonomy bundleTaxo) {
    	
		if(gbBundlCntTaxo==null && bundleTaxo!=null){
			CompareValuesUtility.logFailed("MasterTaxo", "null", "Found in bundle service");
			CompareValuesUtility.logFailed("WebTaxo", "null", "Found in bundle service");
		}
		else if(gbBundlCntTaxo!=null && bundleTaxo==null){
			CompareValuesUtility.logFailed("MasterTaxo", "Found in GB Content", "Not Found in bundle service");
			CompareValuesUtility.logFailed("WebTaxo", "Found in GB Content", "Not Found in bundle service");
		}
		else if(gbBundlCntTaxo!=null && bundleTaxo!=null){
			//Master
			if(gbBundlCntTaxo.getMaster()!=null 
					&& gbBundlCntTaxo.getMaster().getHierarchy()!=null 
					&& !gbBundlCntTaxo.getMaster().getHierarchy().isEmpty()){
				String gbspecVal=null;
				String bdspecVal=null;
				Boolean bFound =false;
				List<Object> commonHierarchyContent = new ArrayList<Object>();
				List<Object> commonHierarchyBundle = new ArrayList<Object>();
				for (Iterator<Hierarchy> iterator = gbBundlCntTaxo.getMaster().getHierarchy().iterator(); iterator.hasNext();) 
				{
					List<Hierarchy> lstHieararchies = new ArrayList<Hierarchy>();	
					Hierarchy hierarchy =  iterator.next();
					lstHieararchies.add(hierarchy);
					List<Hierarchy> spHie = lstHieararchies;
					for (Hierarchy specificHierarchy : spHie) {
						gbspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
						commonHierarchyContent.add(gbspecVal);
				}
				}
				if(bundleTaxo.getMaster()!=null && bundleTaxo.getMaster().getHierarchy()!=null){
					for (Iterator<com.generated.vos.bundle.Hierarchy> iterator = bundleTaxo.getMaster().getHierarchy().iterator(); iterator.hasNext();) 
					{
						List<com.generated.vos.bundle.Hierarchy> lstHieararchies = new ArrayList<com.generated.vos.bundle.Hierarchy>();	
						com.generated.vos.bundle.Hierarchy hierarchy =  iterator.next();
						lstHieararchies.add(hierarchy);
						List<com.generated.vos.bundle.Hierarchy> spHie = lstHieararchies;
						for ( com.generated.vos.bundle.Hierarchy specificHierarchy : spHie) {
							bdspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
							commonHierarchyBundle.add(bdspecVal);
					}
					}
				}
				if(commonHierarchyContent.equals(commonHierarchyBundle)){
					bFound = true;
					//compareHierrachy(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Sears");
					compareObjectList(commonHierarchyContent, commonHierarchyBundle, "MasterTaxo");
				}if(!bFound){
					CompareValuesUtility.logFailed("MasterTaxo", commonHierarchyContent, "Not Found");
				}
			}else{
				if(bundleTaxo.getMaster()!=null 
						&& bundleTaxo.getMaster().getHierarchy()!=null 
						&& !bundleTaxo.getMaster().getHierarchy().isEmpty()){
					CompareValuesUtility.logFailed("MasterTaxo", "null", "Found in bundle service");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
			
			//Sears
			if(gbBundlCntTaxo.getWeb().getSites().getSears()!=null){
				String gbspecVal=null;
				String bdspecVal=null;
				Boolean bFound =false;
				List<Object> commonHierarchyContent = new ArrayList<Object>();
				List<Object> commonHierarchyBundle = new ArrayList<Object>();
				for (Iterator<Hierarchy_> iterator = gbBundlCntTaxo.getWeb().getSites().getSears().getHierarchies().iterator(); iterator.hasNext();) 
				{
					List<Hierarchy_> lstHieararchies = new ArrayList<Hierarchy_>();	
					Hierarchy_ hierarchy =  iterator.next();
					lstHieararchies.add(hierarchy);
					List<SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
					for ( SpecificHierarchy specificHierarchy : spHie) {
						gbspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
						commonHierarchyContent.add(gbspecVal);
				}
				}
				if(bundleTaxo.getWeb().getSites().getSears()!=null){
					for (Iterator<com.generated.vos.bundle.Hierarchy_> iterator = bundleTaxo.getWeb().getSites().getSears().getHierarchies().iterator(); iterator.hasNext();) 
					{
						List<com.generated.vos.bundle.Hierarchy_> lstHieararchies = new ArrayList<com.generated.vos.bundle.Hierarchy_>();	
						com.generated.vos.bundle.Hierarchy_ hierarchy =  iterator.next();
						lstHieararchies.add(hierarchy);
						List<com.generated.vos.bundle.SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
						for ( com.generated.vos.bundle.SpecificHierarchy specificHierarchy : spHie) {
							bdspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
							commonHierarchyBundle.add(bdspecVal);
					}
					}
				}
				if(commonHierarchyContent.equals(commonHierarchyBundle)){
					bFound = true;
					//compareHierrachy(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Sears");
					compareObjectList(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Sears");
				}if(!bFound){
					CompareValuesUtility.logFailed("WebTaxo", commonHierarchyContent, "Not Found", "Sears");
				}
			}else{
				if(bundleTaxo.getWeb().getSites().getSears()!=null){
					CompareValuesUtility.logFailed("WebTaxo", "null", "Found in bundle service", "Sears");
				}
			}
			//Kmart
			if(gbBundlCntTaxo.getWeb().getSites().getKmart()!=null){
				String gbspecVal=null;
				String bdspecVal=null;
				Boolean bFound =false;
				List<Object> commonHierarchyContent = new ArrayList<Object>();
				List<Object> commonHierarchyBundle = new ArrayList<Object>();
				for (Iterator<Hierarchy_> iterator = gbBundlCntTaxo.getWeb().getSites().getKmart().getHierarchies().iterator(); iterator.hasNext();) 
				{
					List<Hierarchy_> lstHieararchies = new ArrayList<Hierarchy_>();	
					Hierarchy_ hierarchy =  iterator.next();
					lstHieararchies.add(hierarchy);
					List<SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
					for ( SpecificHierarchy specificHierarchy : spHie) {
						gbspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
						commonHierarchyContent.add(gbspecVal);
				}
				}
				if(bundleTaxo.getWeb().getSites().getKmart()!=null){
					for (Iterator<Hierarchy__> iterator = bundleTaxo.getWeb().getSites().getKmart().getHierarchies().iterator(); iterator.hasNext();) 
					{
						List<com.generated.vos.bundle.Hierarchy__> lstHieararchies = new ArrayList<com.generated.vos.bundle.Hierarchy__>();	
						Hierarchy__ hierarchy =  iterator.next();
						lstHieararchies.add(hierarchy);
						List<com.generated.vos.bundle.SpecificHierarchy_> spHie = lstHieararchies.get(0).getSpecificHierarchy();
						for ( com.generated.vos.bundle.SpecificHierarchy_ specificHierarchy : spHie) {
							bdspecVal = "[spinId="+GenericUtil.convertToString(specificHierarchy.getSpinId())+", name="+specificHierarchy.getName()+"]";
							commonHierarchyBundle.add(bdspecVal);
					}
					}
				}
				if(commonHierarchyContent.equals(commonHierarchyBundle)){
					bFound = true;
					//compareHierrachy(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Kmart");
					compareObjectList(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Kmart");

				}if(!bFound){
					CompareValuesUtility.logFailed("WebTaxo", commonHierarchyContent, "Not Found", "Kmart");
				}
			}else{
				if(bundleTaxo.getWeb().getSites().getKmart()!=null){
					CompareValuesUtility.logFailed("WebTaxo", "null", "Found in bundle service", "Kmart");
				}
			}
			//Removed taxonomy/web/sites/mygofer from schema
			//Mygofer
			/*if(gbBundlCntTaxo.getWeb().getSites().getMygofer()!=null){
				String gbspecVal=null;
				String bdspecVal=null;
				Boolean bFound =false;
				List<Object> commonHierarchyContent = new ArrayList<Object>();
				List<Object> commonHierarchyBundle = new ArrayList<Object>();
				for (Iterator<Hierarchy> iterator = gbBundlCntTaxo.getWeb().getSites().getMygofer().getHierarchies().iterator(); iterator.hasNext();) 
				{
					List<Hierarchy> lstHieararchies = new ArrayList<Hierarchy>();	
					Hierarchy hierarchy =  iterator.next();
					lstHieararchies.add(hierarchy);
					List<SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
					for ( SpecificHierarchy specificHierarchy : spHie) {
						gbspecVal = "[id="+specificHierarchy.getId()+", name="+specificHierarchy.getName()+"]";
						commonHierarchyContent.add(gbspecVal);
				}
				}
				if(bundleTaxo.getWeb().getSites().getMygofer()!=null){
					for (Iterator<com.generated.vos.bundle.Hierarchy> iterator = bundleTaxo.getWeb().getSites().getMygofer().getHierarchies().iterator(); iterator.hasNext();) 
					{
						List<com.generated.vos.bundle.Hierarchy> lstHieararchies = new ArrayList<com.generated.vos.bundle.Hierarchy>();	
						com.generated.vos.bundle.Hierarchy hierarchy =  iterator.next();
						lstHieararchies.add(hierarchy);
						List<com.generated.vos.bundle.SpecificHierarchy> spHie = lstHieararchies.get(0).getSpecificHierarchy();
						for ( com.generated.vos.bundle.SpecificHierarchy specificHierarchy : spHie) {
							bdspecVal = "[id="+specificHierarchy.getId()+", name="+specificHierarchy.getName()+"]";
							commonHierarchyBundle.add(bdspecVal);
					}
					}
				}
				if(commonHierarchyContent.equals(commonHierarchyBundle)){
					bFound = true;
					//compareHierrachy(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Mygofer");
					compareObjectList(commonHierarchyContent, commonHierarchyBundle,"WebTaxo","Mygofer");
				}if(!bFound){
					CompareValuesUtility.logFailed("WebTaxo", commonHierarchyContent, "Not Found", "Mygofer");
				}
			}else{
				if(bundleTaxo.getWeb().getSites().getMygofer()!=null){
					CompareValuesUtility.logFailed("WebTaxo", "null", "Found in bundle service", "Mygofer");
				}
			}*/
		}
	}

    public void compareHierrachy(List<Object> content, List<Object> bundle,String taxoName,String site ) {
    	for (Iterator<Object> iterator = content.iterator(); iterator.hasNext();) {
    		Object commonHierarchy = iterator.next();

			try {
				if(BeanComparor.containsObject(bundle, commonHierarchy)) {
					CompareValuesUtility.logPassed(taxoName,TestUtils.getDisplayableObject(commonHierarchy),TestUtils.getDisplayableObject(bundle),site);
				}else {
					CompareValuesUtility.logFailed(taxoName,TestUtils.getDisplayableObject(commonHierarchy),"NOT FOUND" );
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
    }
  
	public void compareObjectList(List<Object> content, List<Object> bundle, String field, String... toAppend) {
		for (Iterator<Object> c = content.iterator(); c.hasNext();) {
			Object contentSingle = c.next();
			Boolean bFound = false;

			for (Iterator<Object> b = bundle.iterator(); b.hasNext();) {
				Object bundleSingle = b.next();

				try {
					if (BeanComparor.compareObjects(contentSingle, bundleSingle)) {
						bFound = true;
						CompareValuesUtility.logPassed(field, TestUtils.getDisplayableObject(contentSingle), TestUtils.getDisplayableObject(bundleSingle), toAppend);
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			 if(!bFound) {
				CompareValuesUtility.logFailed(field, TestUtils.getDisplayableObject(contentSingle), "NOT FOUND");
			}
		}
	}
	
	private void verifyAssets(Assets gbBundlCntAsset, com.generated.vos.bundle.Assets bundleAsset){
		if(gbBundlCntAsset==null && bundleAsset!=null){
			CompareValuesUtility.logFailed("Assets", "null", "Found in bundle service");
		}else if(gbBundlCntAsset!=null && bundleAsset==null){
			CompareValuesUtility.logFailed("Assets", "Found in GB Content", "Not Found in bundle service");
		}else if(gbBundlCntAsset!=null && bundleAsset!=null){
			try {
				verifyAssetAttachments(gbBundlCntAsset.getAttachments(), bundleAsset.getAttachments());
			} catch (Exception e2) {
				System.out.println("Exception in verifyAssetAttachments : ");
				e2.printStackTrace();
			}
			try {
				verifyAssetVideos(gbBundlCntAsset.getVideos(),bundleAsset.getVideos());
			} catch (Exception e1) {
				e1.printStackTrace();
				System.out.println("Exception in validateFeaturedImages : "+e1.getMessage());
			}
	
			try {
				verifyImages(gbBundlCntAsset.getImgs(), bundleAsset.getImgs());
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in validatePrimaryImages : "+e.getMessage());
			}
		}else{
			if(bundleAsset!=null){
			CompareValuesUtility.logFailed("Assets", "null", "Found in bundle service");
			}
		}
  }
	  
  	private void verifyAssetAttachments(List<Attachment> gbAttachment, List<com.generated.vos.bundle.Attachment> bundleAttachment){
		  if(gbAttachment.size()!=0){
			  for (Attachment gbattach : gbAttachment) {
				  String gbVal = "[lang="+gbattach.getLang()+", name="+gbattach.getName()+", linkHref="+gbattach.getLink().getAttrs().getHref()+",linkRel="+gbattach.getLink().getAttrs().getRel()+",body="+gbattach.getLink().getBody()+",type="+gbattach.getType()+"]";
				  boolean bFound = false;
				  if(bundleAttachment.size()!=0){
					  for (com.generated.vos.bundle.Attachment bdAttach : bundleAttachment){
						  String bdVal = "[lang="+bdAttach.getLang()+", name="+bdAttach.getName()+", linkHref="+bdAttach.getLink().getAttrs().getHref()+",linkRel="+bdAttach.getLink().getAttrs().getRel()+",body="+bdAttach.getLink().getBody()+",type="+bdAttach.getType()+"]";
						  if(gbVal.equals(bdVal)){
							  bFound = true;
							  CompareValuesUtility.compareValues("Assets", gbVal, bdVal,"Attachment");
							  break;
						  }
					  }
					  if(!bFound){
						  CompareValuesUtility.logFailed("Assets", gbVal, "Not found","Attachment");
					  }
				  }else{
					  CompareValuesUtility.logFailed("Assets", gbVal, "Not found","Attachment");
				  }
			  }
		  }else{
			  if(bundleAttachment.size()!=0){
				  CompareValuesUtility.logFailed("Assets", "null", "Found in bundle service","Attachment");
			  }	
		  }
		  CompareValuesUtility.addNewMultiValuedFields();
	 }
	  
	  private void verifyAssetVideos(List<Video> gbVideo, List<com.generated.vos.bundle.Video> bdVideo){
		  if(gbVideo.size()!=0){
			  for (Video gbVid : gbVideo) {
				  String gbVal = "[name="+gbVid.getName()+", linkHref="+gbVid.getLink().getAttrs().getHref()+",linkRel="+gbVid.getLink().getAttrs().getRel()+",linkType="+gbVid.getLink().getAttrs().getType()+",body="+gbVid.getLink().getBody()+",type="+gbVid.getType()+"]";
				  boolean bFound = false;
				  if(bdVideo.size()!=0){
					  for (com.generated.vos.bundle.Video bdVid : bdVideo){
						  String bdVal = "[name="+bdVid.getName()+", linkHref="+bdVid.getLink().getAttrs().getHref()+",linkRel="+bdVid.getLink().getAttrs().getRel()+",linkType="+bdVid.getLink().getAttrs().getType()+",body="+bdVid.getLink().getBody()+",type="+bdVid.getType()+"]";
						  if(gbVal.equals(bdVal)){
							  bFound = true;
							  CompareValuesUtility.compareValues("Assets", gbVal, bdVal,"Video");
							  break;
						  }
					  }
					  if(!bFound){
						  CompareValuesUtility.logFailed("Assets", gbVal, "Not found","Video");
					  }
				  }else{
					  CompareValuesUtility.logFailed("Assets", gbVal, "Not found","Video");
				  }
			  }
		  }else{
			  if(bdVideo.size()!=0){
				  CompareValuesUtility.logFailed("Assets", "null", "Found in bundle service","Video");
			  }
		  }
		  CompareValuesUtility.addNewMultiValuedFields(); 
	 }
	  
	  private void verifyImages(List<Img_> gbImg, List<com.generated.vos.bundle.Img_> bdImg){
	  
		  String gbimgVal=null;
		  String bdimgVal=null;
		  Boolean bFound =false;
		  List<Object> commonImageContent = new ArrayList<Object>();
		  List<Object> commonImageBundle = new ArrayList<Object>();
		  for (Iterator<Img_> iterator = gbImg.iterator(); iterator.hasNext();){
			  List<Img_> contImg = new ArrayList<Img_>();	
			  Img_ image =  iterator.next();
			  contImg.add(image);
			  List<com.generated.vos.contentbco.Val_> imageval = (List<com.generated.vos.contentbco.Val_>) contImg.get(0).getVals();
			  for ( com.generated.vos.contentbco.Val_ imgVal : imageval) {
				  gbimgVal = "[type="+image.getType()+", title="+imgVal.getImg().getAttrs().getTitle()+", height="+imgVal.getImg().getAttrs().getHeight()+", width="+imgVal.getImg().getAttrs().getWidth()+", src="+imgVal.getImg().getAttrs().getSrc()+"]";
				  commonImageContent.add(gbimgVal);
			  }
		  }
		  for (Iterator<com.generated.vos.bundle.Img_> iterator = bdImg.iterator(); iterator.hasNext();){
			  List<com.generated.vos.bundle.Img_> contImg = new ArrayList<com.generated.vos.bundle.Img_>();	
			  com.generated.vos.bundle.Img_ image =  iterator.next();
			  contImg.add(image);
			  List<com.generated.vos.bundle.Val> imageval = contImg.get(0).getVals();
			  for ( com.generated.vos.bundle.Val imgVal : imageval) {
				  bdimgVal = "[type="+image.getType()+", title="+imgVal.getImg().getAttrs().getTitle()+", height="+imgVal.getImg().getAttrs().getHeight()+", width="+imgVal.getImg().getAttrs().getWidth()+", src="+imgVal.getImg().getAttrs().getSrc()+"]";
				  commonImageBundle.add(bdimgVal);
			  }
		  }
		  if(commonImageContent.equals(commonImageBundle)){
			  bFound = true;
			  //compareHierrachy(commonImageContent, commonImageBundle,"Image","Attr");
			  compareObjectList(commonImageContent, commonImageBundle,"Assets","Images");
		  }
		  if(!bFound){
			  CompareValuesUtility.logFailed("Image", commonImageContent, "Not Found", "Attr");
		  }
		  CompareValuesUtility.addNewMultiValuedFields();
	  }
}
