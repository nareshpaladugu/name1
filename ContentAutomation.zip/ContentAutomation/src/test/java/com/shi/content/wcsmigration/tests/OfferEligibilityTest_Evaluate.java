package com.shi.content.wcsmigration.tests;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.LoadProperties.MSGTYPE;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.batchrules.OfferEligibilityTest_Evaluate_Verifications;
import com.shi.content.wcsmigration.commons.OfferEligibilityUtils;
import com.shi.content.wcsmigration.commons.vos.EligibilityVo;

/**
 * @author ddaphal
 *
 */
public class OfferEligibilityTest_Evaluate 
{
	public static  String fieldsToVerify ="";

	public static List<EligibilityVo> mappingDetails=null;

	public static boolean checkDefaultValues = false;

	@Test(dataProvider="sourceIdProvider",groups="OfferEligibilityTest(Batch-Rules-Evaluation)")

	public void offerEligibilityTest(ArrayList<String> offerIds)
	{
		int counter =0;
		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("bucket"))
		{
			List<String> lstValues = new ArrayList<String>();

			if(LoadProperties.RUN_PARAMS.contains("-")){
				String[] range = LoadProperties.RUN_PARAMS.split("-");
				for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
					lstValues.add(i.toString());
				}
				System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);

			}else{
				lstValues = Arrays.asList(LoadProperties.RUN_PARAMS.split(","));
			}

			for (Iterator<String> iterator = lstValues.iterator(); iterator.hasNext();) 
			{
				String string = iterator.next();

				List<String> lstIdsInBucket  = RestExecutor.getFilteredIds(CollectionValuesVal.OFFER_ATTR, Integer.parseInt(string), "pgrmType", LoadProperties.SITE_NAME);

				System.out.println("Running for bucket : "+ string+"  Size "+ lstIdsInBucket.size());

				for (Iterator<String> iterator2 = lstIdsInBucket.iterator(); iterator2
						.hasNext();) {
					String offer = iterator2.next();

					pool.execute(new OfferEligibilityTest_Evaluate_Verifications(offer));
					counter++;

					if(LoadProperties.TESTDATALIMIT !=-1 && counter>LoadProperties.TESTDATALIMIT)
						break;
				}
			}
		}
		else
		{
			for (Iterator<String> iterator = offerIds.iterator(); iterator.hasNext();) 
			{
				String offer =  iterator.next();
				pool.execute(new OfferEligibilityTest_Evaluate_Verifications(offer));
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(240, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println("pool.awaitTermination - Exception");
		}

		LoadProperties.setCustomMsgForEmail("Fields Tested  : "+fieldsToVerify, MSGTYPE.SUCCESS);

		//TODO Optimization needed
		/*LinkedList<RuleVO> allRules;
		String sSheetName ;

		for (EligibilityVo eligibilityVo : mappingDetails) {

			sSheetName = eligibilityVo.getTabName();

			System.out.println(" ------------------------ Sheetname : "+sSheetName +" ------------------------ ");

			Map<String, LinkedList<RuleVO>> ruleList = eligibilityVo.getRuleList();

			Iterator<Entry<String, LinkedList<RuleVO>>> iterator = ruleList.entrySet().iterator();

			while (iterator.hasNext()) 
			{
				Map.Entry<String, LinkedList<RuleVO>> entry = iterator.next();

				System.out.println("Field : " + entry.getKey() );

				allRules = entry.getValue();

				System.out.println("\nFollowing rules Tested ............");

				for (RuleVO ruleVO : allRules) {

					if(ruleVO.isCheckedThisRule())
					{
						//This rule is never tested
						System.out.print (" \t #"+ruleVO.getRuleName());
					}
				}

				System.out.println("\nFollowing rules never statisfied/checked ............");

				for (RuleVO ruleVO : allRules) {

					if(!ruleVO.isCheckedThisRule())
					{
						//This rule is never tested
						System.out.print(" \t #"+ruleVO.getRuleName());
					}
				}
			}
		}*/

		System.out.println("----------------------END--------------------");
	}

	@DataProvider(name="sourceIdProvider", parallel=true)
	public Object[][] sourceIdProvider()
	{
		List<String> offerIds = new java.util.ArrayList<String>();

		String sOfferIds = LoadProperties.RUN_PARAMS;

		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("fileMode"))
		{

			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");

			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty() )
					{
						offerIds.add(strLine);
					}
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}
		else
		{
			offerIds.addAll(Arrays.asList(sOfferIds.split(",")));
		}

		return new Object[][] { { offerIds} };
	}


	/**
	 * Read mapping sheet for rules 
	 * @param sMappingFile
	 * @return
	 */
	@BeforeSuite(groups="OfferEligibilityTest(Batch-Rules-Evaluation)")
	private void readMappingFile()
	{
		//System.out.println("SITE.... "+LoadProperties.SITE_NAME);
		checkDefaultValues = Boolean.parseBoolean(System.getProperty("checkDefaultValues", "false"));

		mappingDetails = OfferEligibilityUtils.readMappingFile();
	}
}
