package com.shi.content.outletoffer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.generated.vos.offer.Offer;
import com.generated.vos.outletoffer.Item;
import com.generated.vos.outletoffer.Outletoffer;
import com.generated.vos.outletoffer.ProdCnd;
import com.google.common.base.CharMatcher;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class OutletOfferVerifications implements Runnable {

	List<String> outletData;
	int currentCount;
	Map<String, String> outletMetaMap;
	OutletCommons outletCommons;
	
	public OutletOfferVerifications(OutletCommons outletCommons, Map<String, String> outletMetaMap, List<String> outletData, int currentCount) {
		this.outletMetaMap = outletMetaMap;
		this.outletData = outletData;
		this.currentCount = currentCount;
		this.outletCommons = outletCommons;
	}

	@Override
	public void run() {
		
		CompareValuesUtility.init();
		
		String outletOfferId = "";
		
		try{
			List<String> outletOfferLst = new ArrayList<String>();
		
			String[] singleOutletData = outletData.get(0).split("\\|");
			String partNumber = singleOutletData[0];
			String unitNumber = singleOutletData[2].trim().equals("")?null:StringUtils.leftPad(singleOutletData[2].trim(), 7, "0");
			String parentPno = singleOutletData[3];
			
			if(unitNumber==null){
				System.out.println("Ignoring as unitnumber is blank for " + partNumber);
				return;
			}
			
			String strType = outletCommons.getStrType(unitNumber);
			
			outletOfferId = partNumber + "-" + unitNumber;
			
			System.out.println("Testing outlet offer id: " + outletOfferId);
			
			APIResponse<Outletoffer> outletAllResponse = RestExecutor.getAllDataById(CollectionValuesVal.OUTLETOFFER, outletOfferId);
			Outletoffer gbOutletOffer = outletAllResponse.getT();
			
			if((strType==null || !(strType.equals("A") || strType.equals("B") || strType.equals("C"))) && gbOutletOffer==null){
				CompareValuesUtility.logPassed("id", outletOfferId, "Invalid unitnumber. Outlet offer not found in GB");
				CompareValuesUtility.setupResult(outletOfferId, true);
				return;
			}
			
			if((strType==null || !(strType.equals("A") || strType.equals("B") || strType.equals("C"))) && gbOutletOffer!=null){
				CompareValuesUtility.logFailed("id", outletOfferId, "Invalid unitnumber. Outlet offer found in GB");
				CompareValuesUtility.setupResult(outletOfferId, true);
				return;
			}
			
			if(gbOutletOffer==null){
				CompareValuesUtility.logFailed("id", outletOfferId, "Outlet offer not found in GB");
				CompareValuesUtility.setupResult(outletOfferId, true);
				return;
			}
			
			CompareValuesUtility.compareValues("id", outletOfferId, gbOutletOffer.getId());
			CompareValuesUtility.compareValues("partNumber", partNumber, gbOutletOffer.getPartNumber());
			CompareValuesUtility.compareValues("unitNumber", unitNumber, gbOutletOffer.getUnitNumber());
			CompareValuesUtility.compareValues("parentPno", parentPno, gbOutletOffer.getParentPno());
			
			for (String s : outletData) {
				outletOfferLst.add(s);
			}
			
			for (String outlet : outletOfferLst) {
				String[] outletItem = outlet.split("\\|");
				List<String> prdCondCdLst = populatePrdCondCd(outletItem);
				Boolean gFound = false;
				for(Item gbOutletItem : gbOutletOffer.getItems()){
					if(outletItem[1].equals(gbOutletItem.getSeqNo())
							&& CharMatcher.is('0').trimLeadingFrom(outletItem[5]).equals(gbOutletItem.getReducedPrice())
							&& (outletItem[6].equals("N")?"New":"Used").equals(gbOutletItem.getItemCndCode())){
						gFound = true;
						CompareValuesUtility.compareValues("seqNo", outletItem[1], gbOutletItem.getSeqNo());
						CompareValuesUtility.compareValues("itemCndCode", outletItem[6].equals("N")?"New":"Used", gbOutletItem.getItemCndCode());
						CompareValuesUtility.compareValues("onHandQty", CharMatcher.is('0').trimLeadingFrom(outletItem[4]), gbOutletItem.getOnHandQty());
						CompareValuesUtility.compareValues("reducedPrice", CharMatcher.is('0').trimLeadingFrom(outletItem[5]), gbOutletItem.getReducedPrice());
						
						if(!prdCondCdLst.isEmpty()){
							for(String prdCondCd : prdCondCdLst){
								Boolean pFound = false;
								for(ProdCnd gPrdCondCd : gbOutletItem.getProdCnds()){
									if(prdCondCd.equals(gPrdCondCd.getProdCndCode())){
										pFound = true;
										CompareValuesUtility.compareValues("prodCndCode", prdCondCd, gPrdCondCd.getProdCndCode());
										String prodCndDesc = outletMetaMap.get(partNumber.substring(0, 3) + "-" + outletItem[6] + "-" + prdCondCd);
										if(prodCndDesc==null || prodCndDesc.equals("")){
											prodCndDesc = "NA";
										}
										CompareValuesUtility.compareValues("prodCndDesc", prodCndDesc, gPrdCondCd.getProdCndDesc());
										break; //break when prodCnd found
									}
								}
								if(!pFound){
									CompareValuesUtility.compareValues("prodCndCode", prdCondCd, "Not found in GB");
								}
							}
							CompareValuesUtility.addNewMultiValuedFields();
						}else{
							CompareValuesUtility.verifyNull("prodCndCode", gbOutletItem.getProdCnds().isEmpty()?null:gbOutletItem.getProdCnds());
						}
						break; //break when item found
					}
				}
				if(!gFound){
					CompareValuesUtility.compareValues("seqNo", outletItem[1], "Not found in GB");
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
						
			CompareValuesUtility.compareValues("_search", parentPno, outletAllResponse.getSearchFieldValue("parentPno"), "parentPno");
			CompareValuesUtility.compareValues("_search", unitNumber, outletAllResponse.getSearchFieldValue("unitNumber"), "unitNumber");
			CompareValuesUtility.addNewMultiValuedFields();
			
			Offer gbOffer = RestExecutor.getDataById(CollectionValuesVal.OFFER, parentPno);

			if(gbOffer==null){
				CompareValuesUtility.logPassed("Offer.isOutletItem", parentPno, "Offer not found in GB");
			}
			else{
				CompareValuesUtility.compareValues("Offer.isOutletItem", true, gbOffer.getDispTags()==null?null:gbOffer.getDispTags().getIsOutletItem());
			}

			CompareValuesUtility.setupResult(outletOfferId, true);
		}
		catch(Throwable e){
			System.out.println("Check this id :"+ outletOfferId);
			e.printStackTrace();
		}
		finally{
			CompareValuesUtility.teardown();
		}
	}

	/*private String getStrType(String unitNumber) {
		return RestExecutor.getSpecificValueFromJson(CollectionValuesVal.STORE, unitNumber,	"[{_blob{unit{strType2}}}]");
	}*/

	private List<String> populatePrdCondCd(String[] outletItem) {
		
		List<String> prdCondCdLst = new ArrayList<String>();
		
		if(!outletItem[7].trim().equals(""))
			prdCondCdLst.add(outletItem[7]);
		if(!outletItem[8].trim().equals(""))
			prdCondCdLst.add(outletItem[8]);
		if(!outletItem[9].trim().equals(""))
			prdCondCdLst.add(outletItem[9]);
		if(!outletItem[10].trim().equals(""))
			prdCondCdLst.add(outletItem[10]);
		if(!outletItem[11].trim().equals(""))
			prdCondCdLst.add(outletItem[11]);
		if(!outletItem[12].trim().equals(""))
			prdCondCdLst.add(outletItem[12]);
		if(!outletItem[13].trim().equals(""))
			prdCondCdLst.add(outletItem[13]);
		if(!outletItem[14].trim().equals(""))
			prdCondCdLst.add(outletItem[14]);
		if(!outletItem[15].trim().equals(""))
			prdCondCdLst.add(outletItem[15]);
		if(!outletItem[16].trim().equals(""))
			prdCondCdLst.add(outletItem[16]);
		
		return prdCondCdLst;
	}

}
