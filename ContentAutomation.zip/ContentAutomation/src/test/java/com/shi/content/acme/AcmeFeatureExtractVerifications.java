package com.shi.content.acme;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.jboss.netty.util.internal.ConcurrentHashMap;

import com.generated.vos.acmesourcebyid.AcmeSourceById;
import com.generated.vos.iafeaturesbyid.IaFeaturesById;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JSONParser;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.content.restutils.RestExecutor;

public class AcmeFeatureExtractVerifications implements Runnable {
	private String sID;
	private String sourceResponse;
	
	
	
	public AcmeFeatureExtractVerifications(String sID, String sourceResponseIfAvailable)
	{
		this.sID = sID ;
		this.sourceResponse = sourceResponseIfAvailable;
	}

	@Override
	public void run() 
	{
		System.out.println("------------------ Processing Source ID "+sID +" ------------------ ");
		long l1 = System.currentTimeMillis();
		CompareValuesUtility.init();
		
		try {
			String varAttr;
			com.generated.vos.acmesourcebyid.Item item;
			if(sourceResponse == null){
				String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/source/"+sID;
				String srcResponse = RestExecutor.getJSonResponse(new URI(sURL));
			
				if(!srcResponse.contains("item")){
					CompareValuesUtility.logFailed("id", sID, " Source Not found");
					CompareValuesUtility.setupResult(sID, true);
					return;
				}
				//System.out.println(srcResponse);
				AcmeSourceById acmeSrcById = JSONParser.parseJSON(srcResponse, AcmeSourceById.class);
				 
				if(acmeSrcById == null){
					CompareValuesUtility.logFailed("id", sID, " Source Not found");
					CompareValuesUtility.setupResult(sID, true);
					return;
				}
				item = acmeSrcById.getItem();
				varAttr = JsonStringParser.getJsonValue(srcResponse, "{item{attributes{varAttr}}}");
				//System.out.println(sID + " : "+ varAttr);
			}
			else{
				
				varAttr = JsonStringParser.getJsonValue(sourceResponse, "{attributes{varAttr}}");
				item =  JSONParser.parseJSON(sourceResponse, com.generated.vos.acmesourcebyid.Item.class);
			}
			String fURL = "http://"+LoadProperties.IA_SERVER+"/acme/features/"+sID;
			String featResponse = RestExecutor.getJSonResponse(new URI(fURL));
			
			if(!featResponse.contains("item")){
				CompareValuesUtility.logFailed("id", sID, " Features Not found");
				CompareValuesUtility.setupResult(sID, true);
				return;
			}
			
			IaFeaturesById iaFeaturesById = JSONParser.parseJSON(featResponse, IaFeaturesById.class);

			if(iaFeaturesById == null){
				CompareValuesUtility.logFailed("id", sID, " Features Not found");
				CompareValuesUtility.setupResult(sID, true);
				return;
			}
			
			
			verifyFeatures(item, iaFeaturesById, varAttr);
			CompareValuesUtility.setupResult(sID, true);
			
		}catch (URISyntaxException e) {
			e.printStackTrace();
		}catch(Throwable e){
			e.printStackTrace();
			System.out.println("Check this id :"+ sID + "; Exception:" + e);
			//e.printStackTrace();
			CompareValuesUtility.addFailedDataFieldForReport("Exception", e.getMessage());
			CompareValuesUtility.setupResult(sID, true);
		}finally{
			CompareValuesUtility.teardown();
		}
		long l2 = System.currentTimeMillis();
		//System.out.println("Total id time "+ (l2-l1) + " ms  " );
	}

	private void verifyFeatures(com.generated.vos.acmesourcebyid.Item acmeSrcById, IaFeaturesById iaFeaturesById, String varAttr) {
		
		
		com.generated.vos.acmesourcebyid.Attributes sourceAttr = acmeSrcById.getAttributes();
		com.generated.vos.iafeaturesbyid.Attributes featAttr = iaFeaturesById.getItem().getAttributes();
		compareValues("id", sID, iaFeaturesById.getItem().getId());
		verifyNullOrEqual("itemClassId", acmeSrcById.getItemClassId()==null?null:
			getMasterVertical(acmeSrcById.getItemClassId().toString()), featAttr.getItemClassId());
		verifyNullOrEqual("upcCode", StringUtils.leftPad(sourceAttr.getUpcCode(),14,"0"), featAttr.getUpcCode());
		verifyNullOrEqual("modelNumber", normalizeModelNo(sourceAttr.getModelNumber()), featAttr.getModelNumber());
		verifyNullOrEqual("brandName", sourceAttr.getBrandName()==null?null:sourceAttr.getBrandName().toUpperCase(), featAttr.getBrandName());
		verifyNullOrEqual("defAttr", formDefAttr(varAttr), featAttr.getDefAttr());
		verifyNullOrEqual("classifier", sourceAttr.getClassifier(), featAttr.getClassifier());
		verifyNullOrEqual("programType", sourceAttr.getProgramType()==null?null:sourceAttr.getProgramType().toUpperCase(), featAttr.getProgramType());
		verifyNullOrEqual("pid", sourceAttr.getPid(), featAttr.getPid());
		verifyNullOrEqual("title", sourceAttr.getTitle(), featAttr.getTitle());
		verifyNullOrEqual("divLine", sourceAttr.getStoreHierId()==null?null:getDivLine(sourceAttr.getStoreHierId()), featAttr.getDivLine());
		verifyNullOrEqual("brandCodeId", sourceAttr.getBrandCodeId(), featAttr.getBrandCodeId());
		verifyNullOrEqual("isTires", sourceAttr.getIsTires()==null?null:sourceAttr.getIsTires().toString().toUpperCase(), featAttr.getIsTires());
	}
	
	private String formDefAttr(String json) {
		List<String> list = new ArrayList<>();
		String defAttr = null;
		//try {
			if(json==null || json.isEmpty())
				return null;
	
			JsonParser jParser = new JsonParser();
			JsonElement jsonElement = jParser.parse(json);
			JsonArray jsonArr = jsonElement.getAsJsonArray();
			//JsonObject jObj  = jsonElement.getAsJsonObject();
			//JsonObject jObj  = (JsonObject) jsonArr.get(0);
			
			for(JsonElement attr : jsonArr){
				JsonObject jObj = attr.getAsJsonObject();
			
	
				for(Entry<String, JsonElement> abc : jObj.entrySet())
				{
					String attrId = abc.getKey();
					String attrName ; 
					if(AcmeFeatureExtractTests.attributeTypeData1.containsKey(attrId)){
						attrName = AcmeFeatureExtractTests.attributeTypeData1.get(attrId).displayName;
					}else{
						String attrURL = "http://"+LoadProperties.IA_SERVER+"/acme/attribute-type/"+attrId;
						String response = RestExecutor.getJSonResponse(attrURL);
						attrName = JsonStringParser.getJsonValue(response, "{item{displayName}}");
	//					String attrValues = JsonStringParser.getJsonValue(response, "{item{values}}");
						AcmeFeatureExtractTests.attributeTypeData1.put(attrId, new AttributeDataVO(attrName, response));
						
					}
					
					String attrValId = null;
					String attrValName = null;
					
					JsonElement attrvalue = abc.getValue();
					JsonObject avObj  = attrvalue.getAsJsonObject();
					
					if(avObj.has("valueId") && avObj.has("trademarkText")){
						attrValName = avObj.get("trademarkText").toString().replaceAll("\"", "");
					}
					else if(avObj.has("valueId")){
						attrValId = avObj.get("valueId").toString();
						attrValName = JsonStringParser.getJsonValue(AcmeFeatureExtractTests.attributeTypeData1.get(attrId).valueIds, "{item{values{"+attrValId+"}}}");
						/*String response; 
						if(attributeTypeData.containsKey(attrId))
							response = attributeTypeData.get(attrId);
						else{
							response = RestExecutor.getJSonResponse(attrURL);
							attributeTypeData.put(attrId, response);
						}
							attrValName = JsonStringParser.getJsonValue(response, "{item{values{"+attrValId+"}}}");*/
					}
					else if(avObj.has("valueFree")){
						attrValName = avObj.get("valueFree").toString().replaceAll("\"", "");
					}
					else if(avObj.has("valueFlag")){
						attrValName = avObj.get("valueFlag").toString();
					}
					list.add(attrName+":"+attrValName+";");
				}
			}
			Collections.sort(list);
			for(String x : list) {
				if(defAttr==null)
					defAttr=x;
				else
					defAttr=defAttr+x;
			}			
		//}catch(Throwable e){
			//System.out.println("Check this id :"+ sID);
			//e.printStackTrace();
		//}
//		long l2 = System.currentTimeMillis();
//		System.out.println("Total defAttr time "+ (l2-l1) + " ms");
		return defAttr;
	}

	/*private String getMasterVertical(String itemClassId) {
		String parentId = null;
		
		try{
			String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/taxonomy/"+itemClassId;
			parentId = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{parentTaxonomyId}}");
			if(!(parentId==null)){
				while(!parentId.equals("0")){
					String yURL = "http://"+LoadProperties.IA_SERVER+"/acme/taxonomy/"+parentId;
					String parentTaxonomyId = RestExecutor.getSpecificValueFromJson(new URI(yURL), "{item{parentTaxonomyId}}");

					if(!parentTaxonomyId.equals("0")){
						parentId=parentTaxonomyId;
					}else{
						break;
					}
				}
			}else{
				parentId=itemClassId;
			}
		}catch(URISyntaxException e) {
			e.printStackTrace();
		}catch(Throwable e){
			System.out.println("Check this id :"+ sID);
			e.printStackTrace();
		}
		return parentId;
	}*/
		
	private String getMasterVertical(String itemClassId){
//		long l1 = System.currentTimeMillis();
		String parentId = getParent(itemClassId);
		
		if(parentId.equals(itemClassId) || parentId.equals("0"))
			return itemClassId;
		
		
		while(!parentId.equals("0")){
			String parentTaxId = getParent(parentId);
			if(parentTaxId.equals("0") || parentTaxId.equals(parentId))
				break;
			parentId = parentTaxId;
		}
		
		
//		long l2 = System.currentTimeMillis();
//		System.out.println("Total master time "+ (l2-l1) + " ms");
		return parentId;
	}
		
	private String getParent(String itemClassId){
		if(AcmeFeatureExtractTests.hierarchyToParent.keySet().contains(itemClassId)){
			return AcmeFeatureExtractTests.hierarchyToParent.get(itemClassId);
		}
		else{
			try {
				String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/taxonomy/"+itemClassId;
				String parentId = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{parentTaxonomyId}}");
				
				if(parentId==null){
					parentId=itemClassId;
				}
				AcmeFeatureExtractTests.hierarchyToParent.put(itemClassId, parentId);
				return parentId;
			} catch (URISyntaxException e) {
				e.printStackTrace();
				return null;
			}
		}
	}
	/*private String getDivLine(String storeHierId) {
		String div = null;
		String line = null;
		String divId = null;
		String lineId = null;
		String subLineId = null;
		String sURL = null;
		try{
			sURL = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/"+storeHierId;
			subLineId = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{parentTaxonomyId}}");
			if(subLineId!=null) {
				sURL = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/"+subLineId;
				lineId = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{parentTaxonomyId}}");
				if(lineId!=null) {
					sURL = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/"+lineId;
					divId = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{parentTaxonomyId}}");
					line = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{divId}}");
					if(divId!=null) {
						sURL = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/"+divId;
						div = RestExecutor.getSpecificValueFromJson(new URI(sURL), "{item{divId}}");
					}else{
						return null;
					}
				}else {
					return null;
				}
			}else {
				return null;
			}

		}catch(URISyntaxException e) {
			e.printStackTrace();
		}catch(Throwable e){
			System.out.println("Check this id :"+ sID);
			e.printStackTrace();
		}
		return div+"-"+line;
	}*/
	
	static Map<String, StoreTaxonomyVO> storeTaxData = new ConcurrentHashMap<String, StoreTaxonomyVO>();
	
	private String getDivLine(String storeHierId) {
//		long l1 = System.currentTimeMillis();
		String div = null;
		String line = null;
		String divId = null;
		String lineId = null;
		String subLineId = null;
		
		subLineId = getStoreTaxonomyData(storeHierId).parentTaxonomyId;
			
		if(subLineId!=null) {
			lineId =  getStoreTaxonomyData(subLineId).parentTaxonomyId;
			if(lineId!=null) {
				
				divId = getStoreTaxonomyData(lineId).parentTaxonomyId;
				line = getStoreTaxonomyData(lineId).divId;
				if(divId!=null) {
					div = getStoreTaxonomyData(divId).divId;
				}else{
					return null;
				}
			}else {
				return null;
			}
		}else {
			return null;
		}

//		long l2 = System.currentTimeMillis();
//		System.out.println("Time in divline "+(l2-l1));
		return div+"-"+line;
	}
	
	private StoreTaxonomyVO getStoreTaxonomyData(String storeHierarchyId){
		if(!storeTaxData.containsKey(storeHierarchyId)){
			String sURL = "http://"+LoadProperties.IA_SERVER+"/acme/storetaxonomy/"+storeHierarchyId;
			String storeGBTaxData = RestExecutor.getJSonResponse(sURL);
			String subLineId = JsonStringParser.getJsonValue(storeGBTaxData, "{item{parentTaxonomyId}}");
			String divLine =  JsonStringParser.getJsonValue(storeGBTaxData, "{item{divId}}");
			storeTaxData.put(storeHierarchyId, new StoreTaxonomyVO(subLineId,divLine));
		}
		return storeTaxData.get(storeHierarchyId);
	}

	private String normalizeModelNo(String modelNo) {
		if(modelNo == null)
			return null;
		String mfg = modelNo.replaceAll("[\\W_]", "").toUpperCase();
		return mfg;
	}
	
	class StoreTaxonomyVO{
		public StoreTaxonomyVO(String subLineId, String divId2) {
			
			this.parentTaxonomyId = subLineId;
			this.divId = divId2;
		}
		String divId;
		String parentTaxonomyId;
		
	}
	
	class AttributeDataVO{
		public AttributeDataVO(String attrName, String attrValues) {
			this.displayName = attrName;
			this.valueIds = attrValues;
		}
		String displayName;
		String valueIds;
		
	}

}
