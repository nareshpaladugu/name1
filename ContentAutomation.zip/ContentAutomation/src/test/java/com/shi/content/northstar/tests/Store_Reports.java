package com.shi.content.northstar.tests;

import java.util.ArrayList;
import java.util.Arrays;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.pages.LinkPanel;
import com.shi.content.northstar.pages.LoginPage;
import com.shi.content.northstar.pages.StoreReportPage;

public class Store_Reports {
	
	@BeforeMethod
	public void login(){
		System.out.println("In beforemethod");
		LoginPage login = new LoginPage("");
		LinkPanel linkPanel = new LinkPanel();
		login.login("sdhinga", "4444");
		//WaitUtils.waitUntilElementIsVisible(linkPanel.goToStoreReport());
		StoreReportPage searchstorepage = new StoreReportPage("Store Report");
		
		
	}
	@Test(description="Test to generate report on the basis of report type ", groups = {"NS-P1"})
	public static void verifyType(String rType,String value){
		ArrayList<String> reportTypes = new ArrayList<String>(Arrays.asList("Cheetah","SPU","Store Status","SFS","Layaway"));
		String Value = "True";
		String responseType = "";
		String site = "";
		if(responseType=="SPU"){
			//Values to be fetch through UI -Status/Value?Stroe ID/Search button
			String jResponse = RestExecutor.getJSonResponseById(CollectionValuesVal.STORE, "3311");
			String hldyObj = JsonStringParser.getJsonValueNew(jResponse,"_blob.unit.strAttr.sites"+site+".pickUp");
			String layaway = JsonStringParser.getJsonValueNew(jResponse,"_blob.unit.strAttr.sites"+site+".sfsElig");
			String strType = JsonStringParser.getJsonValueNew(jResponse,"_search.strStatus");	
			
		}
		
		
	}
	
}
