package com.shi.content.ranking.vos.pricing;

public class _Blob {

	private Price price;

	public Price getPrice() {
		return price;
	}

	public void setPrice(Price price) {
		this.price = price;
	}
	
}
