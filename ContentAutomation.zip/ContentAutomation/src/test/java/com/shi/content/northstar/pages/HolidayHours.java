package com.shi.content.northstar.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.shc.content.webdriver.assertions.DriverLogger;
import com.shc.content.webdriver.html.Button;
import com.shc.content.webdriver.html.DialogBox;
import com.shc.content.webdriver.html.Link;
import com.shc.content.webdriver.html.Table;
import com.shc.content.webdriver.html.TextField;
import com.shc.content.webdriver.html.WaitUtils;
import com.shi.content.northstar.common.CommonMethods;


/**
 * @author inaikwa
 *
 */
public class HolidayHours extends EditStoreDetails {

	Link linkUnitHolidayHoursView = new Link("//a[contains(text(),'Holiday Hours View')]","Holiday Hours View");
	TextField txtHolidayTableFields_Multi= new TextField("//table[@id='frm-multi-view:pnl-multi-view:holiday-hour-multi']/tbody/tr/td/span/input","Holiday");
	Table tblView = new Table("//div[@class='ui-accordion-content ui-helper-reset ui-widget-content ui-helper-hidden'][@aria-hidden='false']", "Department View");
//MultiView
	TextField txtNewHolidayDate_Multi= new TextField("//input[@id='frm-multi-view:pnl-multi-view:j_idt194_input']","New Holiday Date");
	TextField txtNewHolidayOpenTime_Multi= new TextField( "//input[@id='frm-multi-view:pnl-multi-view:multiholopnhr_input']","New Holiday Open Time");
	TextField txtNewHolidayCloseTime_Multi= new TextField( "//input[@id='frm-multi-view:pnl-multi-view:multiholclohr_input']","New Holiday Close Time");
	TextField txtNewHolidayOffsetTime_Multi= new TextField( "//input[@id='frm-multi-view:pnl-multi-view:multiholopnoffhr_input']","New Holiday offset Time");
//Single View
	TextField txtNewHolidayDate= new TextField("//input[@id='frm-single-view:pnl-single-view:j_idt333_input']","New Holiday Date");
	TextField txtNewHolidayOpenTime= new TextField( "//input[@id='frm-single-view:pnl-single-view:addValopnhr_input']","New Holiday Open Time");
	TextField txtNewHolidayCloseTime= new TextField( "//input[@id='frm-single-view:pnl-single-view:addValclohr_input']","New Holiday Close Time");
	TextField txtNewHolidayOffsetTime= new TextField( "//input[@id='frm-single-view:pnl-single-view:addValoffopnhr_input']","New Holiday offset Time");
	
	DialogBox dlgDeleteHolidaySuccess = new DialogBox("//p[contains(text(),'The holiday hour details are deleted successfully.')]", "Delete Holiday Success dialog");
	Table tableDisplayHolidays = new Table("//*[@id='frm-single-view:pnl-single-view:tbl-holiday_data']/tr", "Holiday Display Table");
	Button btnCalendarNext= new Button("//span[@class='ui-icon ui-icon-circle-triangle-e']","Next month button") ;
		
	TextField txtHolidayTableFields= new TextField("//table[@id='frm-single-view:pnl-single-view:tbl-holiday-add']/tbody/tr/td/span/input","Holiday");
	Link lnkHolidayDate= new Link("//a[@class='ui-state-default'][contains(text(),'{0}')]","HolidayDate");
	
	
	DriverLogger logger = new DriverLogger();
	

	/**
	 * Clicks on Holiday Hours view
	 */
	public void goToHolidayHoursView(){
		
		logger.log("Go to Holiday Hours view ", false);
		
		if(tblView.isVisible()){
			WaitUtils.waitUntilElementIsVisible(linkUnitHolidayHoursView);
			linkUnitHolidayHoursView.click();
		}
		
		WaitUtils.waitUntilElementIsVisible(linkUnitHolidayHoursView);
		linkUnitHolidayHoursView.click();
	
	}
	
	/**
	 *  Adds new holiday for multiple Stores
	 *  @return SelectedHolidayDetails (Date, OpenTime, CloseTime, Offset)
	 */

	public HashMap<String, String>  addHolidayMultiView() {
		
		List<WebElement> holidayTableFields = txtHolidayTableFields_Multi.findElements();
		
		if (holidayTableFields.size()<1){
			return null;
		}
	
		HashMap<String, String> selectedHolidayDetails = new HashMap<String, String>();
		
		logger.log("Selecting New Holiday Date ", false);
		txtNewHolidayDate_Multi.click();
		WaitUtils.waitUntilElementIsVisible(btnCalendarNext);
		btnCalendarNext.click();	
		Link lnkSelectHolidayDate = (Link)lnkHolidayDate.formatOption(CommonMethods.getRandomNumber());
		WaitUtils.waitUntilElementIsVisible(lnkSelectHolidayDate);
		lnkSelectHolidayDate.click();
		selectedHolidayDetails.put("Date", CommonMethods.getFormattedDate(txtNewHolidayDate_Multi.getText()));
		logger.log("Selected Date : "+selectedHolidayDetails.get("Date"), false);
		
		logger.log("Selecting New Holiday Open Time ", false);
		txtNewHolidayOpenTime_Multi.click();
		Link lnkTimePickerOpenTime = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerOpenTime.click();
		selectedHolidayDetails.put("OpenTime", txtNewHolidayOpenTime_Multi.getText());
		logger.log("Selected OpenTime : "+selectedHolidayDetails.get("OpenTime"), false);
		
		logger.log("Selecting New Holiday Close Time ", false);
		txtNewHolidayCloseTime_Multi.click();
		Link lnkTimePickerCloseTime = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerCloseTime.click();
		selectedHolidayDetails.put("CloseTime", txtNewHolidayCloseTime_Multi.getText());
		logger.log("Selected CloseTime : "+selectedHolidayDetails.get("CloseTime"), false);
		
		logger.log("Selecting New Holiday Offset ", false);
		txtNewHolidayOffsetTime_Multi.click();
		Link lnkTimePickerOffset = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerOffset.click();
		selectedHolidayDetails.put("Offset", txtNewHolidayOffsetTime_Multi.getText());
		logger.log("Selected Offset : "+selectedHolidayDetails.get("Offset"), false);
		
		return selectedHolidayDetails;
	}

	
	/**
	 *  Adds new holiday for sinlge store
	 *  @return SelectedHolidayDetails (Date, OpenTime, CloseTime, Offset)
	 */
	
	public HashMap<String, String> addHolidaySingleView() {
		
		List<WebElement> holidayTableFields = txtHolidayTableFields.findElements();
		
		if (holidayTableFields.size()<1){
			return null;
		}

		HashMap<String, String> selectedHolidayDetails = new HashMap<String, String>();
		
		logger.log("Selecting New Holiday Date ", false);
		txtNewHolidayDate.click();
		btnCalendarNext.click();	
		Link lnkSelectHolidayDate = (Link)lnkHolidayDate.formatOption(CommonMethods.getRandomNumber());
		WaitUtils.waitUntilElementIsVisible(lnkSelectHolidayDate);
		lnkSelectHolidayDate.click();
		selectedHolidayDetails.put("Date", CommonMethods.getFormattedDate(txtNewHolidayDate.getText()));
		logger.log("Selected Date : "+selectedHolidayDetails.get("Date"), false);
	
		logger.log("Selecting New Holiday Open Time ", false);
		txtNewHolidayOpenTime.click();
		Link lnkTimePickerOpenTime = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerOpenTime.click();
		selectedHolidayDetails.put("OpenTime", CommonMethods.getFormattedTime(txtNewHolidayOpenTime.getText()));
		logger.log("Selected OpenTime : "+selectedHolidayDetails.get("OpenTime"), false);
		
		logger.log("Selecting New Holiday Close Time ", false);
		txtNewHolidayCloseTime.click();
		Link lnkTimePickerCloseTime = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerCloseTime.click();
		selectedHolidayDetails.put("CloseTime", CommonMethods.getFormattedTime(txtNewHolidayCloseTime.getText()));
		logger.log("Selected CloseTime : "+selectedHolidayDetails.get("CloseTime"), false);
	
		logger.log("Selecting New Holiday Offset ", false);
		txtNewHolidayOffsetTime.click();
		Link lnkTimePickerOffset = (Link)lnkTimePickerHourCell.formatOption(CommonMethods.getRandomNumber());
		lnkTimePickerOffset.click();
		selectedHolidayDetails.put("Offset", txtNewHolidayOffsetTime.getText());
		logger.log("Selected Offset : "+selectedHolidayDetails.get("Offset"), false);
		
		return selectedHolidayDetails;
	}

	/**
	 *  Get All Holidays already present
	 *  @return tableOfWebElements
	 */
	public ArrayList<ArrayList<WebElement>> fecthAvailableHolidays(){
		WaitUtils.waitUntilElementIsVisible(tblView);		
		ArrayList<ArrayList<WebElement>> table =tableDisplayHolidays.getTableElements();
		
		
		if(table.size()==0){
			return null;	
		}
		
		if(checkIfNoRecords(table.get(0).get(0).getText())){
			return null;
		}else{ 	
			return table;
		}
				
	}
	/**
	 * Deletes given holiday 
	 * @return true if given holiday is deleted else false
	 */
	public boolean deleteHoliday(HashMap<String, String> date){
		boolean isDelete=false;
		
		ArrayList<ArrayList<WebElement>> table = fecthAvailableHolidays();
		
		for (int row = 0; row < table.size(); row++) {
			
			String availableDate = table.get(row).get(0).getText();
//			String availableOpenTime = table.get(row).get(1).getText();
//			String availableCloseTime = table.get(row).get(2).getText();
			String availableOffset = table.get(row).get(3).getText();

			if(availableDate.contains(date.get("Date"))&&
//					availableOpenTime.contains(date.get("OpenTime"))&&
//							availableCloseTime.contains(date.get("CloseTime"))&&
							availableOffset.contains(date.get("Offset"))){
				logger.log("Target record with date "+ availableDate+" is found in "+(row+1) +" row..." , false);
				table.get(row).get(4).click();
				logger.log("Deleting Holiday record with date "+ availableDate , false);
					isDelete=true;

			}else{
				logger.log("Record with date "+ date+" is NOT found in "+(row+1) +" row..." , false);
			}
		}
		return isDelete;
	}
	
	/**
	 * Checks if delete Success dialog is displayed after deleting holiday 
	 * @return true if delete success msg is displayed else false
	 */
	public boolean deleteSuccessMsg(){
		
		WaitUtils.waitUntilElementIsVisible(dlgDeleteHolidaySuccess);
		
		if(dlgDeleteHolidaySuccess.isVisible()){
			
			logger.log("Delete Holiday Success.....", false);
			return true;
			
		}else{
			logger.log("Delete Holiday : Failed.....", false);
			return false;
			
		}

	}

	/**
	 * Check if holiday with same date is already added 
	 */
	public boolean checkIfNoRecords(String noRecordsmsg){
		
		if(noRecordsmsg.equalsIgnoreCase("No records found.")){
			logger.log("No records found.", false);
			return true;
	
		}else{
			logger.log("Holiday table contains records", false);
			return false;
			
		}
	}

}
