package com.shi.content.ranking;

import java.net.URISyntaxException;
import java.util.List;

import com.generated.vos.offer.OfferSchema;
import com.generated.vos.rankingauto.RankingResponseFull;
import com.google.gson.Gson;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.ranking.logic.CompareResponses;
import com.shi.content.ranking.logic.GBRankBean;
import com.shi.content.ranking.logic.GBRankUid;

public class RankingTestValidations implements Runnable
{
	private String sSingleUID;

	public RankingTestValidations(String sUID)
	{
		this.sSingleUID=sUID;
	}

	@Override
	public void run()
	{
		System.out.println("Testing UID : "+sSingleUID);
		
		if((sSingleUID!=null) && !sSingleUID.isEmpty())
		{
			testSingleUID(sSingleUID);
		}
	}

	public void testSingleUID(String sUID)
	{
		CompareValuesUtility.init();

		RankingResponseFull rankingResponse = RankingDataExtractor.getRankingResponseFull(sUID);

		//System.out.println("ranking response--------------"+rankingResponse);
				

		if(rankingResponse==null)
		{

			CompareValuesUtility.addFailedDataFieldForReport("RankingServiceResponse", "Not Found");

		}else if((rankingResponse.getGroups().size() == 0) && (rankingResponse.getMetadata() == null)){

			//No offers to rank has returned from ranking response, now get by alt key to cross check

			List<String> noOfoffers= checkIfOffersExists(sUID);

			if(noOfoffers.size()==0){

//				CompareValuesUtility.addDataFieldForReport("By uid", "No offers found in GB");
//				CompareValuesUtility.addDataFieldForReport("In Response", "No Offers to Rank");
				System.out.println("No offers found in GB for UID=" + sUID);

			}else {
				Gson gson = new Gson();
				for(String offer:noOfoffers){

					String offerResponse=RestExecutor.getJSonResponseById(CollectionValuesVal.OFFER, offer);
					offerResponse=offerResponse.substring(1, offerResponse.length()-1);
					//						OfferSchema  offerObj = RestExecutor.getDataById(CollectionValuesVal.OFFER_SCHEMA, offer);
					OfferSchema offerObj= gson.fromJson(offerResponse, OfferSchema.class);
					String sitesObj= offerObj.getBlob().getOffer().getSites().toString();

					if(checkOfferPrice(offer,offerObj)==0){

						//CompareValuesUtility.addDataFieldForReport("Offers having pricing issue", offer);
						//CompareValuesUtility.addDataFieldForReport("Ranking Response", "No offers to rank");
						System.out.println("Offers having pricing issue for UID=" + sUID + " and offerId=" + offer);


					}else if(sitesObj.contains(LoadProperties.STORESITE.toLowerCase())){

						CompareValuesUtility.addFailedDataFieldForReport("Offers found by uid in GB", offer);

						CompareValuesUtility.addFailedDataFieldForReport("Offers found in Ranking Response", "Offers Missing in response");

					}else {

//						CompareValuesUtility.addDataFieldForReport("Offers found by uid", "No offers");
//						CompareValuesUtility.addDataFieldForReport("Offers found in Ranking Response", "No offers to rank");
						System.out.println("No Offers found by uid for UID=" + sUID + " and site=" + LoadProperties.STORESITE);

					}
				}
			}

		}
		else
		{
			try {

				GBRankUid qaRank = new GBRankUid();

				CompareResponses comp = new CompareResponses();

				List<GBRankBean> qaRankGroup = qaRank.RankGroup(sUID,rankingResponse);

				if((rankingResponse!=null) && !qaRankGroup.isEmpty())
				{
					comp.CompareRankResponses(qaRankGroup,rankingResponse,sUID);
				} else
				{
					//System.out.println("NO Validation for QA Rank " + qaRankGroup.toString() +  " BuyBox Rank "+ buyboxResp);
					System.out.println("No validation for UID:" + sUID);
				}

			} catch (URISyntaxException e) {
				System.out.println("Check this UID: " + sUID);
				e.printStackTrace();
			}

		}

		CompareValuesUtility.setupResult(sUID, true);
	}

// check if offers exists 
	public List<String> checkIfOffersExists(String sUID)
	{

		return RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid",sUID);

	}


	public float checkOfferPrice(String offer, OfferSchema offerObj)

	{

		float price = 0;

		String pgrmType= offerObj.getFt().getPgrmType();

		GBRankUid qaRank = new GBRankUid();

		try {

			if(pgrmType.equalsIgnoreCase("Sears")||pgrmType.equalsIgnoreCase("Kmart")){

				price= qaRank.getPrice(offer, LoadProperties.STORESITE);

			}else {

				if(RankingTest.serialAcceesFlag)
				{
					price=qaRank.getMpPrice(offerObj);
				}
				else
				{
					
					price=qaRank.getPrice(offerObj.getId(), LoadProperties.STORESITE);

				}
			}

		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return price;

	}


}
