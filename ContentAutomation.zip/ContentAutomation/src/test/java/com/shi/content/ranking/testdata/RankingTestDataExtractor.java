package com.shi.content.ranking.testdata;

import java.util.List;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class RankingTestDataExtractor implements Runnable
{
	private String offerId;
	private String site;

	public RankingTestDataExtractor(String offerId, String site)
	{
		this.offerId=offerId;
		this.site = site;
	}

	@Override
	public void run()
	{
		//System.out.println("Testing Offer : "+offerId);		
		//CompareValuesUtility.init();
		testOfferId(offerId);

	}

	public void testOfferId(String offerId)
	{	
		
		/****************************************************************************************************/
		
		Offer gbOffer  = RestExecutor.getDataById(CollectionValuesVal.OFFER,offerId);
		
		if( gbOffer == null || gbOffer.getIdentity() == null || gbOffer.getIdentity().getUid() == null )
		{
			//System.out.println("UID Not found : "+offerId);
			return;
		}
			
		String sUID =  gbOffer.getIdentity().getUid();
		
		if(RankingTestData.setOfProcessedUIDs.contains(sUID))
		{
			return;
		}
		RankingTestData.setOfProcessedUIDs.add(sUID);
		
		
//		if(gbOffer.getCondition() != null )
//			if( gbOffer.getCondition().getImg() != null )
//			return;
				
		List<String> lstOffers = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid", sUID);
		RankingTestData.setOfProcessedOffers.addAll(lstOffers);
		
//		System.out.println("List of offers by UID=" + lstOffers.size());
		if(lstOffers.size() <= 1 || lstOffers.size() >100)
		{
			return;
		}

		/****************************************************************************************************/
		String pgrmType = null;
		String offerType = null;
		List<String> sites = null;
		String totalOffers = "";
		
		int isSearsVGroup= 0;
		int isSearsNVGroup= 0;
		
		int isKmartVGroup= 0;
		int isKmartNVGroup= 0;
		
		int isFBMVGroup= 0;
		int isFBMNVGroup= 0;
		
		int isFBSVGroup= 0;
		int isFBSNVGroup= 0;
		
		int isDSSVGroup= 0;
		int isDSSNVGroup= 0;
		
		int isCPCVGroup= 0;
		int isCPCNVGroup= 0;
		
//		boolean isSYWVGroup= false;
//		boolean isSYWNVGroup= false;
//		
//		boolean isUVDVGroup= false;
//		boolean isUVDNVGroup= false;
//		
//		boolean isHSVGroup= false;
//		boolean isHSNVGroup= false;
//		
//		boolean isSVGroup= false;
//		boolean isSNVGroup= false;
					
		for(String offer : lstOffers)
		{	
//			if(!offer.equalsIgnoreCase("SPM10993235613"))
//				continue;
			
			APIResponse<Offer> allResponse  = RestExecutor.getAllDataById(CollectionValuesVal.OFFER,offer);				
			Offer gbOffer1 = (Offer) allResponse.getT();
			pgrmType = allResponse.getFtFieldValue("pgrmType");
			offerType = allResponse.getFtFieldValue("offerType");
			sites = gbOffer1.getSites();
			
			if(sites.contains(site.toLowerCase()))
			{
				if(pgrmType.equalsIgnoreCase("Sears") && offerType.equalsIgnoreCase("V"))
				{
					isSearsVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("Sears") && offerType.equalsIgnoreCase("NV"))
				{
					isSearsNVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("Kmart") && offerType.equalsIgnoreCase("V"))
				{
					isKmartVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("Kmart") && offerType.equalsIgnoreCase("NV"))
				{
					isKmartNVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("FBM") && offerType.equalsIgnoreCase("V"))
				{
					isFBMVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("FBM") && offerType.equalsIgnoreCase("NV"))
				{
					isFBMNVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("FBS") && offerType.equalsIgnoreCase("V"))
				{
					isFBSVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("FBS") && offerType.equalsIgnoreCase("NV"))
				{
					isFBSNVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("DSS") && offerType.equalsIgnoreCase("V"))
				{
					isDSSVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("DSS") && offerType.equalsIgnoreCase("NV"))
				{
					isDSSNVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("CPC") && offerType.equalsIgnoreCase("V"))
				{
					isCPCVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("CPC") && offerType.equalsIgnoreCase("V"))
				{
					isCPCVGroup += 1;
					totalOffers += " " + offer;
				}
				else if(pgrmType.equalsIgnoreCase("CPC") && offerType.equalsIgnoreCase("NV"))
				{
					isCPCNVGroup += 1;
					totalOffers += " " + offer;
				}
//				else if(pgrmType.equalsIgnoreCase("SYW") && offerType.equalsIgnoreCase("V"))
//				{
//					isSYWVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("SYW") && offerType.equalsIgnoreCase("NV"))
//				{
//					isSYWNVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("UVD") && offerType.equalsIgnoreCase("V"))
//				{
//					isUVDVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("UVD") && offerType.equalsIgnoreCase("NV"))
//				{
//					isUVDNVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("HS") && offerType.equalsIgnoreCase("V"))
//				{
//					isHSVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("HS") && offerType.equalsIgnoreCase("NV"))
//				{
//					isHSNVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("S") && offerType.equalsIgnoreCase("V"))
//				{
//					isSVGroup = true;
//					totalOffers += " " + offer;
//				}
//				else if(pgrmType.equalsIgnoreCase("S") && offerType.equalsIgnoreCase("NV"))
//				{
//					isSNVGroup = true;
//					totalOffers += " " + offer;
//				}
			}
			else
			{
				continue;
			}
		}
		CompareValuesUtility.init();
		if(isSearsNVGroup >= 1 && isKmartNVGroup >= 1 && isFBMNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site, "SEARS_KMART_FBM_NV_Group" , "SEARS_KMART_FBM_NV_Group");
			System.out.println("SEARS_KMART_FBM_NV_Group="+sUID);
			//CompareValuesUtility.setupResult(sUID, true);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup >=1 && isFBMVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_KMART_FBM_V_Group","SEARS_KMART_FBM_V_Group" );
			System.out.println("SEARS_KMART_FBM_V_Group="+sUID);
			//CompareValuesUtility.setupResult(sUID, true);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup >= 1 && isFBSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_KMART_FBS_NV_Group","SEARS_KMART_FBS_NV_Group");
			System.out.println("SEARS_KMART_FBS_NV_Group="+sUID);
			//CompareValuesUtility.setupResult(sUID, true);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup >=1 && isFBSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_KMART_FBS_V_Group","SEARS_KMART_FBS_V_Group");
			System.out.println("SEARS_KMART_FBS_V_Group="+sUID);
			//CompareValuesUtility.setupResult(sUID, true);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup >= 1 && isDSSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_KMART_DSS_NV_Group", "SEARS_KMART_DSS_NV_Group");
			System.out.println("SEARS_KMART_DSS_NV_Group="+sUID);
			//CompareValuesUtility.setupResult(sUID, true);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup >=1 && isDSSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_KMART_DSS_V_Group", "SEARS_KMART_DSS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_KMART_DSS_V_Group="+sUID);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup >= 1 && isCPCNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_KMART_CPC_NV_Group","SEARS_KMART_CPC_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_KMART_CPC_NV_Group="+sUID);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup >=1 && isCPCVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_KMART_CPC_V_Group", "SEARS_KMART_CPC_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_KMART_CPC_V_Group="+sUID);
		}	
		/****************************************************************************************************/
		else if(isSearsNVGroup >= 1 && isKmartNVGroup == 0 && isFBMNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_FBM_NV_Group", "SEARS_FBM_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_FBM_NV_Group="+sUID);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup == 0 && isFBMVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_FBM_V_Group","SEARS_FBM_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_FBM_V_Group="+sUID);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup == 0 && isFBSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_FBS_NV_Group", "SEARS_FBS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_FBS_NV_Group="+sUID);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup == 0 && isFBSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual(site , "SEARS_FBS_V_Group", "SEARS_FBS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_FBS_V_Group="+sUID);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup == 0 && isDSSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_DSS_NV_Group","SEARS_DSS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_DSS_NV_Group="+sUID);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup == 0 && isDSSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_DSS_V_Group","SEARS_DSS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_DSS_V_Group="+sUID);
		}
		else if(isSearsNVGroup >= 1 && isKmartNVGroup == 0 && isCPCNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_CPC_NV_Group","SEARS_CPC_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_CPC_NV_Group="+sUID);
		}
		else if(isSearsVGroup >=1 && isKmartVGroup == 0 && isCPCVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "SEARS_CPC_V_Group","SEARS_CPC_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("SEARS_CPC_V_Group="+sUID);
		}
		/****************************************************************************************************/
		else if(isSearsNVGroup == 0 && isKmartNVGroup >= 1 && isFBMNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_FBM_NV_Group","KMART_FBM_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_FBM_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup >=1 && isFBMVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_FBM_V_Group","KMART_FBM_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_FBM_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup >= 1 && isFBSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_FBS_NV_Group","KMART_FBS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_FBS_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup >=1 && isFBSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_FBS_V_Group","KMART_FBS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_FBS_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup >= 1 && isDSSNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_DSS_NV_Group","KMART_DSS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_DSS_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup >=1 && isDSSVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_DSS_V_Group","KMART_DSS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_DSS_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup >= 1 && isCPCNVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_CPC_NV_Group","KMART_CPC_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_CPC_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup >=1 && isCPCVGroup >= 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "KMART_CPC_V_Group","KMART_CPC_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("KMART_CPC_V_Group="+sUID);
		}
		/****************************************************************************************************/
		else if(isSearsNVGroup == 0 && isKmartNVGroup == 0 && isFBMNVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "FBM_NV_Group","FBM_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("FBM_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup == 0 && isFBMVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "FBM_V_Group","FBM_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("FBM_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup == 0 && isFBSNVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "FBS_NV_Group","FBS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("FBS_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup == 0 && isFBSVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "FBS_V_Group","FBS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("FBS_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup == 0 && isDSSNVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "DSS_NV_Group","DSS_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("DSS_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup == 0 && isDSSVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "DSS_V_Group","DSS_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("DSS_V_Group="+sUID);
		}
		else if(isSearsNVGroup == 0 && isKmartNVGroup == 0 && isCPCNVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "CPC_NV_Group","CPC_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("CPC_NV_Group="+sUID);
		}
		else if(isSearsVGroup == 0 && isKmartVGroup == 0 && isCPCVGroup > 1)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "CPC_V_Group","CPC_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("CPC_V_Group="+sUID);
		}	
		/****************************************************************************************************/
		else if(isSearsNVGroup > 0 && isKmartNVGroup > 0 && isFBMNVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_NV_Group","Sears_Kmart_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_NV_Group="+sUID);
		}
		else if(isSearsVGroup > 0 && isKmartVGroup > 0 && isFBMVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_V_Group","Sears_Kmart_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_V_Group="+sUID);
		}
		else if(isSearsNVGroup > 0 && isKmartNVGroup > 0 && isFBSNVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_NV_Group","Sears_Kmart_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_NV_Group="+sUID);
		}
		else if(isSearsVGroup > 0 && isKmartVGroup > 0 && isFBSVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_V_Group","Sears_Kmart_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_V_Group="+sUID);
		}
		else if(isSearsNVGroup > 0 && isKmartNVGroup > 0 && isDSSNVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_NV_Group","Sears_Kmart_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_NV_Group="+sUID);
		}
		else if(isSearsVGroup > 0 && isKmartVGroup > 0 && isDSSVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_V_Group","Sears_Kmart_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_V_Group="+sUID);
		}
		else if(isSearsNVGroup > 0 && isKmartNVGroup > 0 && isCPCNVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_NV_Group","Sears_Kmart_NV_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_NV_Group="+sUID);
		}
		else if(isSearsVGroup > 0 && isKmartVGroup > 0 && isCPCVGroup == 0)
		{
			CompareValuesUtility.verifyNullOrEqual( site , "Sears_Kmart_V_Group","Sears_Kmart_V_Group");
			//CompareValuesUtility.setupResult(sUID, true);
			System.out.println("Sears_Kmart_V_Group="+sUID);
		}

		//		System.out.println("Count Of Processed UIDs=" + RankingTestData.setOfProcessedUIDs.size());
		CompareValuesUtility.setupResult(sUID, true);
	}
}