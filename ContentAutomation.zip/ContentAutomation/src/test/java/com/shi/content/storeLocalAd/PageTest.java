package com.shi.content.storeLocalAd;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.generated.xmls.storelocalad.Media;
import com.generated.xmls.storelocalad.Page;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;
import com.shc.autocontent.testcommons.FileProviderClass;

public class PageTest
{
	@Test(dataProviderClass=FileProviderClass.class, dataProvider="fileProvider",groups="LocalAdPageTest")
	public void testLocalAdPage(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Media>> localAdQueue = new LinkedBlockingQueue<List<Media>>();

		//Create producer thread
		ChunkProducerThread<Media> prodThread = new ChunkProducerThread<Media>(sFileName, localAdQueue, Media.class);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		//Create consumer threads
		//Each thread does validation for attribute and attribute val

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);

		while(true)
		{
			try
			{
				List<Media> lstXmlMedia = localAdQueue.poll(20, TimeUnit.SECONDS);

				if(lstXmlMedia == prodThread.POISON_PILL)
				{
					System.out.println("Got poison pill ..breaking out" + lstXmlMedia);
					break;
				}

				if(lstXmlMedia != null)
				{
					for(Media media : lstXmlMedia)
					{
						System.out.println("Testing mediaType: " + media.getMedia_type());

						for(Page page : Arrays.asList(media.getSection(0).getPage()) )
						{
							pool.execute(new PageVerification(media, page));
						}
					}
				}

				else
				{
					System.out.println("got null");
				}
			}

			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try
		{
			pool.awaitTermination(20, TimeUnit.MINUTES);
		}

		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
