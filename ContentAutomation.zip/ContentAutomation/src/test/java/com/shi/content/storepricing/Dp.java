
package com.shi.content.storepricing;

import javax.annotation.Generated;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;


/**
 * details of all price types
 * 
 * 
 */
@Generated("org.jsonschema2pojo")
public class Dp {

    /**
     * dynamic price of an item
     * (Required)
     * 
     */
    @Expose
    private Double ip;
    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). start time for dynamic price
     * (Required)
     * 
     */
    @Expose
    private String st;
    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). end time for dynamic price
     * (Required)
     * 
     */
    @Expose
    private String et;

    /**
     * dynamic price of an item
     * (Required)
     * 
     */
    public Double getIp() {
        return ip;
    }

    /**
     * dynamic price of an item
     * (Required)
     * 
     */
    public void setIp(Double ip) {
        this.ip = ip;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). start time for dynamic price
     * (Required)
     * 
     */
    public String getSt() {
        return st;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). start time for dynamic price
     * (Required)
     * 
     */
    public void setSt(String st) {
        this.st = st;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). end time for dynamic price
     * (Required)
     * 
     */
    public String getEt() {
        return et;
    }

    /**
     * ISO Date Format(Example 2013-02-07T01:15:01.090Z). end time for dynamic price
     * (Required)
     * 
     */
    public void setEt(String et) {
        this.et = et;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object other) {
        return EqualsBuilder.reflectionEquals(this, other);
    }

}
