package com.shi.content.wcsmigration.mp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.generated.vos.catdelta.CommonFbmsFieldsGroup;
import com.generated.vos.catdelta.Cpc;
import com.generated.vos.catdelta.Dss;
import com.generated.vos.catdelta.Fbm;
import com.generated.vos.catdelta.Fbs;
import com.generated.vos.catdelta.SpecificFbmsFieldsGroup;
import com.generated.vos.catdelta.Variation;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.ChunkProducerThread;

public class MPCatalog_ContentTestsNew 
{
	@Test(dataProvider="fileProvider",groups="MPCatalogContentTestsNew")
	public void testFbm(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Fbm>> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Fbm>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Fbm> prodThread = new ChunkProducerThread<Fbm>(sFileName, masterHierarchyNodeQueue, Fbm.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Fbm> nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);

				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new MPCatalog_ContentVerificationsNew(nodeToTest));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}


	@Test(dataProvider="fileProvider",groups="MPCatalogContentTestsNew")
	public void testFbs(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Fbs>> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Fbs>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Fbs> prodThread = new ChunkProducerThread<Fbs>(sFileName, masterHierarchyNodeQueue, Fbs.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Fbs> nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){

					pool.execute(new MPCatalog_ContentVerificationsNew(processNodeList(nodeToTest)));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}


	@Test(dataProvider="fileProvider",groups="MPCatalogContentTestsNew")
	public void testDss(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Dss>> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Dss>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Dss> prodThread = new ChunkProducerThread<Dss>(sFileName, masterHierarchyNodeQueue, Dss.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Dss> nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new MPCatalog_ContentVerificationsNew(processNodeList(nodeToTest)));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	@Test(dataProvider="fileProvider",groups="MPCatalogContentTestsNew")
	public void testVariation(String sFileName) throws InterruptedException
	{
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		
		String sSeller = sFileName.split("\\.")[0].split("-")[2];
		if(sSeller.equalsIgnoreCase("DSS")) {
			sSeller = sFileName.split("\\.")[0].split("-")[3];
		}
		System.out.println("Seller is "+sSeller);
		
		BlockingQueue<List<Variation>> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Variation>>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Variation> prodThread = new ChunkProducerThread<Variation>(sFileName, masterHierarchyNodeQueue, Variation.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Variation> nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					CommonFbmsFieldsGroup commonFields = this.convertToCommon(nodeToTest.get(0).getCommonFbmsFieldsGroupVariation());
					SpecificFbmsFieldsGroup specificFields =  this.convertToSpecificFields(nodeToTest.get(0).getVariantItems().getVariantItem()[0].getSpecificFbmsFieldsGroupVariation());
					pool.execute(new MPCatalog_ContentVerificationsNew(processNodeList(nodeToTest), commonFields, specificFields, sSeller,nodeToTest.get(0).getVariationGroupId(),nodeToTest.get(0).getProgramType().toString()));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		

	}
	
	
	public static List<Fbm> processNodeList(List<?> nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);

		List<Fbm> toReturn = new ArrayList<Fbm>();

		try {

			for (Object t : nodeToTest) {

				Fbm fbm=new Fbm();

				BeanUtils.copyProperties(fbm, t);

				toReturn.add(fbm);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return toReturn;
	}
	
	public static <T> CommonFbmsFieldsGroup convertToCommon(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		CommonFbmsFieldsGroup commonsIncommons=new CommonFbmsFieldsGroup();
		try {
				BeanUtils.copyProperties(commonsIncommons, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsIncommons;
	}
	
	public static <T> SpecificFbmsFieldsGroup convertToSpecificFields(T nodeToTest)
	{
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		SpecificFbmsFieldsGroup commonsInSpecificFields=new SpecificFbmsFieldsGroup();
		try {
				BeanUtils.copyProperties(commonsInSpecificFields, nodeToTest);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return commonsInSpecificFields;
	}
	
	@DataProvider(name="fileProvider")
	public Object[][] fileProvider(){

		String files = LoadProperties.LST_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		return lstOfFiles;
	}
	
	@Test(dataProvider="fileProvider",groups="MPCatalogContentTestsNew")
	public void testCPC(String sFileName) throws InterruptedException
	{
		String sSeller = sFileName.split("\\.")[0].split("-")[2];
		if(sSeller.equalsIgnoreCase("DSS")) {
			sSeller = sFileName.split("\\.")[0].split("-")[3];
		}
		//System.out.println("Seller is "+sSeller);
		
		
		//Create a blocking queue per thread
		System.out.println("Testing sFileName "+ sFileName);
		BlockingQueue<List<Cpc >> masterHierarchyNodeQueue = new LinkedBlockingQueue<List<Cpc >>(); 

		// Start producer thread to produce nodes
		ChunkProducerThread<Cpc > prodThread = new ChunkProducerThread<Cpc >(sFileName, masterHierarchyNodeQueue, Cpc.class);//, poison);
		prodThread.setBucketSize(1);
		Thread t = new Thread(prodThread);
		t.start();

		final ExecutorService pool = Executors.newFixedThreadPool(LoadProperties.CONSUMER_THREADCOUNT);
		while(true){
			try {
				List<Cpc > nodeToTest = masterHierarchyNodeQueue.poll(20, TimeUnit.SECONDS);
				if(nodeToTest == prodThread.POISON_PILL){
					System.out.println("Got poison pill ..breaking out" + nodeToTest);
					break;
				}
				if(nodeToTest != null){
					pool.execute(new MPCatalog_ContentVerificationsNew(nodeToTest,true,sSeller));
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();

		try {
			pool.awaitTermination(80, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
