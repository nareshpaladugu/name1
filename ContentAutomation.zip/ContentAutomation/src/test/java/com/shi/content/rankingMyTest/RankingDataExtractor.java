package com.shi.content.rankingMyTest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.generated.vos.rankingauto.Offer;
import com.generated.vos.rankingauto.RankingResponseFull;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

/**
 * @author ddaphal
 *
 */
public class RankingDataExtractor
{

	/**
	 * @param uid
	 * @return
	 */
	public static RankingResponseFull getRankingResponseFull(String uid)
	{
		String url = LoadProperties.IFTRANKVIP+"?uid="+uid+"&fullResponse=true&ignoreOffline=false";
		try 
		{

			if(LoadProperties.USERTYPE.equals("GUEST"))
				url = url + "&memberStatus=G&sywMax=N";

			else if(LoadProperties.USERTYPE.equals("MAX"))
				url = url + "&sywMax=Y";

			else if(LoadProperties.USERTYPE.equals("SYWR"))
				url = url + "&memberStatus=S&sywMax=N";

			if(!LoadProperties.ZIPCODE.isEmpty())
				url = url + "&zipCode="+LoadProperties.ZIPCODE;

			if(Boolean.valueOf(LoadProperties.LOCALADFLAG))
				url = url + "&storeUnitNumber="+LoadProperties.STOREUNITNUMBER;

			//SITE - mandatory
			url = url+"&site="+LoadProperties.STORESITE;

			System.out.println("Ranking response URL : "+url);

			String resp = RestExecutor.getJSonResponse(url);

			if(resp.equalsIgnoreCase("TIME OUT ERROR"))
			{
				System.out.println("TIME OUT ERROR... "+url);
				return null;
			}else if (resp.equalsIgnoreCase("No offers to rank")||resp.startsWith("Invalid UID value=")){
				
				return new RankingResponseFull();
// end here				
			}else{
			
				return RestExecutor.getDataById(resp,CollectionValuesVal.RankingResponseFull);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @param rankingResponse
	 * @return
	 */
	public static Map<String, String> getOfferToRankMapActual(RankingResponseFull rankingResponse )
	{
		Map<String, String> offerToRankMap = new LinkedHashMap<String, String>();
		try 
		{
			List<com.generated.vos.rankingauto.Offer> offersFromRanking = rankingResponse.getGroups().get(0).getOffers();
			for (Offer offer : offersFromRanking) 
			{
				offerToRankMap.put(offer.getId(),offer.getRank());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return offerToRankMap;
	}

	/**
	 * @return
	 */
	public static Map<String, String> getOfferToRankMapExpected(String sUID)
	{
		//TODO calculate expected

		Map<String, String> offerToRankMap = new LinkedHashMap<String, String>();
		//get offer list by uid
		List<String> offerIds =  RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER, "uid",sUID);

		List<APIResponse<Offer>> lstOffer = RestExecutor.getAllDataById(CollectionValuesVal.OFFER, offerIds);

		for (APIResponse<Offer> apiResponse : lstOffer) 
		{
			com.generated.vos.offer.Offer offerObj = (com.generated.vos.offer.Offer)apiResponse.getT();

			offerToRankMap.put(offerObj.getId(),"TBD");
		}
		return offerToRankMap;
	}

	/*public static void main(String m[])
	{
		RankingResponseFull rankingResponse = getRankingResponseFull("f9c2a57f-a43a-43c3-b65a-c403cc555d45");

		System.out.println(rankingResponse.getGroups().get(0).getOffers().get(0).getId());

		Map<String, String> map = getOfferToRankMapActual(rankingResponse);

		for (Map.Entry<String, String> entry : map.entrySet())
		{
			System.out.println(entry.getKey() + " -- " + entry.getValue());
		}
	}*/

}
