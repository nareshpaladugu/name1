package com.shi.content.wcsmigration.verifications;

import static com.shc.autocontent.softasserts.CompareValuesUtility.compareValues;
import static com.shc.autocontent.softasserts.CompareValuesUtility.verifyNullOrEqual;
import static com.shc.autocontent.utils.GenericUtil.convertToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.generated.vos.attrvalue.AttrId;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.content.Assets;
import com.generated.vos.content.Attr;
import com.generated.vos.content.Content;
import com.generated.vos.content.Spec;
import com.generated.vos.content.Static;
import com.generated.vos.hierarchy.Attrs;
import com.generated.vos.hierarchy.Label;
import com.generated.vos.offer.Legal;
import com.generated.vos.productoffering.Attribute;
import com.generated.vos.productoffering.Brand;
import com.generated.vos.productoffering.Hierarchy;
import com.generated.vos.productoffering.Nutrition;
import com.generated.vos.productoffering.OperationalAttribute;
import com.generated.vos.productoffering.OperationalAttributes;
import com.generated.vos.productoffering.ProductAttribute;
import com.generated.vos.productoffering.ProductContent;
import com.generated.vos.productoffering.ProductOffer;
import com.generated.vos.productoffering.SingleProductOffer;
import com.generated.vos.productoffering.Site;
import com.generated.vos.productoffering.Source;
import com.generated.vos.productoffering.VariationProductOffer;
import com.generated.vos.productoffering.types.ChokingHazardType;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.reports.vo.FieldResultVO.INFOTYPE;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.testcommons.TestUtils;
import com.shc.autocontent.utils.GenericUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.GreenBoxCache;
import com.shi.content.Variations.OfferCommons;
import com.shi.content.Variations.SHCContentCommons;
import com.shi.content.wcsmigration.tests.SHC_ContentLoadTest_New;

public class SHC_ContentVerifications_New implements Runnable 
{
	ProductOffer[] prodOffers;
	Attrs masterHierarchyAttributes;
	SingleProductOffer singleProductOffer ;
	VariationProductOffer varProdOffer ;
	SHCContentCommons commonUtils;
	String itemClassId;
	Boolean bSingleProductOffer = true;
	String partNumberToTest;
	String sSiteToTest;
	String spinId;
	String ssin;
	String guid;
	private boolean bCrossFormattedItem;
	private boolean bCommonSpinId;
	private boolean bOtherSiteNumberAvlbl;
	private boolean validHierarchy;
	
	public SHC_ContentVerifications_New(SingleProductOffer wNodeListToTest,  
			String itemClassId, VariationProductOffer varProdOffer, String siteToTest)
	{
		commonUtils = new SHCContentCommons(siteToTest);
		if(wNodeListToTest == null)
		{
			bSingleProductOffer = false;
			spinId = varProdOffer.getVariationGroupId();
		}
		else
		{
			spinId = wNodeListToTest.getProductOfferings().getProductOffer(0).getSpinUniqueId();
		}
		
		this.singleProductOffer = wNodeListToTest;
		this.itemClassId = itemClassId;
		this.varProdOffer = varProdOffer;
		this.sSiteToTest = siteToTest;
		
		if(sSiteToTest.equals("sears")){
			if((bSingleProductOffer && singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber() != null)
					|| (!bSingleProductOffer && varProdOffer.getVariationKmartPartNumber() != null))
				bOtherSiteNumberAvlbl = true;
			if(bSingleProductOffer && singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber() != null 
					&& commonUtils.isSiteTaxonomyAvailable(singleProductOffer.getProductContent().getSite(),1L)
					&& commonUtils.isSiteTaxonomyAvailable(singleProductOffer.getProductContent().getSite(),2L))
				bCommonSpinId = true;
			if(!bSingleProductOffer && varProdOffer.getVariationKmartPartNumber() != null
					&& commonUtils.isSiteTaxonomyAvailable(varProdOffer.getProductContent().getSite(),1L)
					&& commonUtils.isSiteTaxonomyAvailable(varProdOffer.getProductContent().getSite(),2L))
				bCommonSpinId = true;
		}else{
			if((bSingleProductOffer && singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber() != null)
					|| (!bSingleProductOffer && varProdOffer.getVariationSearsPartNumber() != null))
				bOtherSiteNumberAvlbl = true;
			if(bSingleProductOffer && singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber() != null
					&& commonUtils.isSiteTaxonomyAvailable(wNodeListToTest.getProductContent().getSite(),2L)
					&& commonUtils.isSiteTaxonomyAvailable(singleProductOffer.getProductContent().getSite(),1L))
				bCommonSpinId = true;
			if(!bSingleProductOffer && varProdOffer.getVariationSearsPartNumber() != null
					&& commonUtils.isSiteTaxonomyAvailable(varProdOffer.getProductContent().getSite(),2L)
					&& commonUtils.isSiteTaxonomyAvailable(varProdOffer.getProductContent().getSite(),1L))
				bCommonSpinId = true;
		}
		commonUtils.setbUniqueSpinId(bCommonSpinId);
	}

	

	public void run() 
	{
		/*if(this.spinId.contains("1461252812"))
			return;*/
		ProductContent pContentToTest = this.getContentToTest();

		if(partNumberToTest.equals("nullP"))
		{
			return;
		}

		if (SHC_ContentLoadTest_New.errorPartNumbers.contains(partNumberToTest)) 
		{
			System.out.println("Skipping error part : " + partNumberToTest);
			return;
		}

		APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,partNumberToTest);
		/** Changes for INCO554932 - Sites should be loaded in all conditions
		/*if(sSiteToTest.equals("sears")){
			if(!commonUtils.isSiteTaxonomyAvailable(pContentToTest.getSite(),2L )){
				System.out.println("Sears hierarchy not present : "+ partNumberToTest);
				//Check if the only site available in sites section is Kmart, then validate, item is not loaded
				if(pContentToTest.getSite().length == 1 && commonUtils.isSiteTaxonomyAvailable(pContentToTest.getSite(),1L )){
					CompareValuesUtility.init();
					CompareValuesUtility.verifyNull("Id", allResponse.getT(), "Only Kmart hierarchy present");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					System.out.println("Only kmart present : "+ partNumberToTest);
					return;
				}
			}
		}
		if(sSiteToTest.equals("kmart")){
			if(!commonUtils.isSiteTaxonomyAvailable(pContentToTest.getSite(),1L )){
				System.out.println("Kmart hierarchy not present : "+ partNumberToTest);
				//Check if the only site available in sites section is Kmart, then validate, item is not loaded
				if(pContentToTest.getSite().length == 1 && commonUtils.isSiteTaxonomyAvailable(pContentToTest.getSite(),2L )){
					CompareValuesUtility.init();
					CompareValuesUtility.verifyNull("Id", allResponse.getT(), "Only Sears hierarchy present");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					System.out.println("Only kmart present : "+ partNumberToTest);
					return;
				}
			}
		}*/
		bCrossFormattedItem = commonUtils.isCrossFormattedItem(pContentToTest, sSiteToTest, singleProductOffer, varProdOffer == null?null:varProdOffer.getProductOfferings().getProductOffer(0), bSingleProductOffer);
		

		if(partNumberToTest!= null)
		{
			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return;
				}

				Content gbContent = (Content)allResponse.getT();
				if(gbContent == null){
					CompareValuesUtility.logFailed("Id", partNumberToTest, " Not found");
					CompareValuesUtility.setupResult(partNumberToTest, true);
					return;
				}
				
				System.out.println("Testing content id: " + partNumberToTest);
				verifyProduct(pContentToTest, gbContent,partNumberToTest ,sSiteToTest );
				verifyFtSearch(pContentToTest, allResponse);
				CompareValuesUtility.addDataFieldForReport("OtherSiteNumber", Boolean.toString(bOtherSiteNumberAvlbl), INFOTYPE.DATA);
				CompareValuesUtility.setupResult(partNumberToTest, true);

			}catch(Throwable e){
				System.out.println("Check this id :"+ partNumberToTest);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}

	}
	
	/**
	 * Gets the data to be tested
	 * If NV item, sets the partnumber to be tested based on the site deduced from file name and returns content
	 * If V item, checks whether site offers are present.  If present sets partnumber else sets partnumber to null
	 * eg. if sears site is being tested and if no sears part number is present in product offerings, return null
	 * @return
	 */
	private ProductContent getContentToTest() 
	{
		boolean bFoundSiteOffers = false;
		if(bSingleProductOffer){

			if(sSiteToTest.equals("sears")){
				partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getSearsPartNumber()+"P";
			}else{
				partNumberToTest = singleProductOffer.getProductOfferings().getProductOffer(0).getPartNumber().getKmartPartNumber()+"P";
			}

			prodOffers = singleProductOffer.getProductOfferings().getProductOffer();
			ssin = singleProductOffer.getProductOfferings().getProductOffer(0).getSsin();
			guid = singleProductOffer.getProductOfferings().getProductOffer(0).getGuid();
			

			return singleProductOffer.getProductContent();

		}else{
			if(sSiteToTest.equals("sears")){
				for( ProductOffer prodOff : varProdOffer.getProductOfferings().getProductOffer()){
					if(prodOff.getPartNumber().getSearsPartNumber()!=null){
						bFoundSiteOffers = true;
						break;
					}
				}
				if(bFoundSiteOffers)
					partNumberToTest = varProdOffer.getVariationSearsPartNumber()+"P";
				else
					partNumberToTest = "nullP";
			}else{
				for( ProductOffer prodOff : varProdOffer.getProductOfferings().getProductOffer()){
					if(prodOff.getPartNumber().getKmartPartNumber()!=null){
						bFoundSiteOffers = true;
						break;
					}
				}
				if(bFoundSiteOffers)
					partNumberToTest = varProdOffer.getVariationKmartPartNumber()+"P";
				else
					partNumberToTest = "nullP";
			}

			prodOffers = varProdOffer.getProductOfferings().getProductOffer();
			ssin = varProdOffer.getProductOfferings().getProductOffer(0).getSsin();
			
			return varProdOffer.getProductContent();
		}
	}



	private void verifyProduct(ProductContent pContent, Content content, String id, String site) 
	{

		compareValues("Id", id,content.getId());

		CompareValuesUtility.addDataFieldForReport("itemclassid", itemClassId==null?"null":itemClassId);
	
		//Identity.ssin
		if(ssin == null)
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", ssin, content.getIdentity()== null ? null : content.getIdentity().getSsin(),"ssin");
			
			if(content.getIdentity().getPrevSsin() == null)
			{
				CompareValuesUtility.logFailed("Identity", "SSIN not in Feed", "PrevSsin is not set");
			}
			else
			{
				CompareValuesUtility.logPassed("Identity", "SSIN not in Feed", "PrevSsin="+content.getIdentity().getPrevSsin());
			}
			
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", ssin, content.getIdentity()== null ? null : content.getIdentity().getSsin(),"ssin");
		}
		
		
		/* ---------------- Identity --------------- */
		if(bSingleProductOffer)
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", guid, content.getIdentity()== null ? null : content.getIdentity().getUid(),"UID");
			if(content.getMeta().getModifiedTs() == null)
			{
				CompareValuesUtility.verifyNullOrEqual("Identity", pContent.getOfferCount() == null ? "99" : pContent.getOfferCount(), content.getIdentity().getOfferCnt() == null ? null : content.getIdentity().getOfferCnt().intValue(),"OfferCnt");
			}
			else
			{
				if(pContent.getOfferCount() == null)
				{
					CompareValuesUtility.logPassed("Identity", "OfferCnt is null in feed", content.getIdentity()== null ? "null" : content.getIdentity().getOfferCnt() == null ? "null" : content.getIdentity().getOfferCnt().intValue(),"OfferCnt");
				}
				else
				{
					CompareValuesUtility.verifyNullOrEqual("Identity", pContent.getOfferCount(), content.getIdentity()== null ? null : content.getIdentity().getOfferCnt() == null ? null : content.getIdentity().getOfferCnt().intValue(),"OfferCnt");
				}
			}
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Identity", pContent.getOfferCount(), content.getIdentity()== null ? null : content.getIdentity().getOfferCnt() == null ? null : content.getIdentity().getOfferCnt().intValue(),"OfferCnt");
		}
		
		/* ---------------- legal --------------- */
		
		Gson gson = new Gson();
		String json = gson.toJson(content);
		com.generated.vos.content.Legal legalTagGb = null;
		if(json.contains("\"legal\":{\"chokingHazards\":[]}"))
		{
			legalTagGb = null;
		}
		else
		{
			legalTagGb = content.getLegal();
		}

		verifyLegal(pContent, legalTagGb);
		
		
		//name
		if(pContent.getName()==null || pContent.getName().isEmpty())
		{
			CompareValuesUtility.verifyNullOrEqual("Name", pContent.getName(), content.getName());
		}
		else
		{
			compareValues("Name", TestUtils.plainEncodeHTML(OfferCommons.escapeNewline(pContent.getName())), content.getName());
		}

		//isLongDescSuppress
		if(pContent.getSuppressLongDescriptionFlag() == null || pContent.getSuppressLongDescriptionFlag().equals(false))
			CompareValuesUtility.verifyNull("SuppresLongDesc", content.getIsLongDescSuppress());
		else
			compareValues("SuppresLongDesc",pContent.getSuppressLongDescriptionFlag(), content.getIsLongDescSuppress());

		//sites
		commonUtils.verifySites(pContent, content.getSites(), bCrossFormattedItem);

		//classifications
		compareValues("Classifications", "P", content.getClassifications().getCatentryType(),"Catentrytype");
		compareValues("Classifications", bSingleProductOffer?"NV":"V", content.getClassifications().getCatentrySubType(),"CatentrySubtype");

		if(pContent.getEnrichmentInfo()!=null && !pContent.getEnrichmentInfo().getEnrichmentProvider().value().equals("1WORLDSYNC"))
		{
			compareValues("Classifications", commonUtils.getEnrichmentProvider(pContent.getEnrichmentInfo() == null?"S":
				pContent.getEnrichmentInfo().getEnrichmentProvider().value(),true), content.getClassifications().getEnrichmentProvider(),"EnrichProv");
		}
		Boolean isAuto = sSiteToTest.equals("sears")?isAutomotive(prodOffers[0].getCoreHierarchyId().toString()):isAutomotive(prodOffers[0].getShcHierarchyId().toString());
		CompareValuesUtility.verifyNullOrFalse("Classifications", isAuto, content.getClassifications().getIsAutomotive(), "IsAutomotive");
		CompareValuesUtility.verifyNullOrFalse("Classifications", false, content.getClassifications().getIsUvd(), "IsUvd");
		CompareValuesUtility.addNewMultiValuedFields();

		/* ---------------- desc --------------- */
		commonUtils.verifyDesc(pContent.getFeatureDescription(), pContent.getMarketingDescription(),content.getDesc(),true);

		if(pContent.getFeatureTopDescriptions() != null){
			commonUtils.verifyTopDescriptions(pContent.getFeatureTopDescriptions().getFeatureTopDescription(), content.getDesc());
		}
		CompareValuesUtility.addNewMultiValuedFields();
		
		/* ---------------- brand --------------- */
		verifyBrand(pContent.getBrand(), content.getBrand());
		CompareValuesUtility.addNewMultiValuedFields();

		/* ---------------- mfr --------------- */
		String xmlMfrName = pContent.getManufacturerName();
		if (xmlMfrName != null) {
			int xmlMfrNameLen = pContent.getManufacturerName().length();
			xmlMfrName = xmlMfrName.substring(0,xmlMfrNameLen>64?64:xmlMfrNameLen);
		}
		CompareValuesUtility.verifyNullOrEqual("Mfr",xmlMfrName,content.getMfr()!= null? content.getMfr().getName() : null,"MfrName");
		CompareValuesUtility.verifyNullOrEqual("Mfr",pContent.getManufacturerModelNumber(), content.getMfr()!= null? content.getMfr().getModelNo(): null,"MfrModel");
		CompareValuesUtility.addNewMultiValuedFields();

		/* ---------------- seo --------------- */
		commonUtils.verifySeo(pContent.getSeo(), content);
		//commonUtils.verifySeoNew(pContent, content, sSiteToTest);
		
		/* ---------------- assets --------------- */
		verifyAssets(pContent, content.getAssets());

		/* ---------------- facets --------------- */
		verifyFacetsGB(pContent, content);

		CompareValuesUtility.addNewMultiValuedFields();

		/* ---------------- specs --------------- */
		verifySpecsGB(content.getSpecs());

		/* ---------------- taxo --------------- */
		verifyTaxonomy(pContent.getSite(), content);

		/* ------------- automotive ---------- */
		CompareValuesUtility.verifyNullOrEqual("Automotive", brandCodeId, content.getAutomotive()==null?null:content.getAutomotive().getBrandCodeId(),"BrandCodeId");
		CompareValuesUtility.verifyNullOrEqual("Automotive", autoFitmentType, content.getAutomotive()==null?null:content.getAutomotive().getAutoFitment(),"AutoFitment");
		CompareValuesUtility.verifyNull("Automotive", content.getAutomotive()==null?null:content.getAutomotive().getAutoType(),"AutoType");
		CompareValuesUtility.addNewMultiValuedFields();
				
		/* ------------- grocery --------------- */
		verifyGroceryTag(pContent, content);

		/* ------------ curatedContents ------- */
		if(pContent.getCuratedContents() != null){
			CompareValuesUtility.addNewMultiValuedFields();
			commonUtils.verifyCuratedContents(pContent.getCuratedContents().getCuratedGroup(), content.getCuratedContents());
		}
		
		//AltIds
		CompareValuesUtility.compareValues("AltIds", spinId, content.getAltIds().getSpinId(), "SpinId");

		//ima-attributes from offer level
		if(prodOffers[0].getImaAttributes()!=null){ 
			//prop65
			if(prodOffers[0].getImaAttributes().getProp65Flag()!=null && prodOffers[0].getImaAttributes().getProp65Flag() == true){
				CompareValuesUtility.compareValues("Legal", true, content.getLegal().getIsProp65(), "IsProp65");
			}
			//sywItemType
			for(Attribute attr : prodOffers[0].getImaAttributes().getAttribute()){
				if(attr.getName().equals("shop your way exclusives") && attr.getContent()!=null){
					CompareValuesUtility.compareValues("DispTags", attr.getContent(), content.getDispTags().getSywItemType(), "SywItemType");
				}
			}
		}	
		if(bSingleProductOffer)
			CompareValuesUtility.addDataFieldForReport("FSD", prodOffers[0].getFutureActiveStartDate() == null?"":prodOffers[0].getFutureActiveStartDate().toString());
		else
		{
			for(ProductOffer po : prodOffers){
				if(po.getFutureActiveStartDate() != null){
					CompareValuesUtility.addDataFieldForReport("FSD", prodOffers[0].getFutureActiveStartDate() == null?"":prodOffers[0].getFutureActiveStartDate().toString());
					break;
				}
			}
		}
		verifyOperational(pContent, content);
		
		try {
			testNewChanges5_20(content);
		} catch (Exception e) {

			System.out.println("Check this id(testNewChanges5_20) :"+ partNumberToTest);
			e.printStackTrace();
		}
	}
	
	private void verifyLegal(ProductContent prodContent, com.generated.vos.content.Legal gbLegal) {

		String jewelry_disclosure_52="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care";

		String jewelry_disclosure_53="Diamond weights may not be exact, but are never more than .05 carats below the stated weight";

		String jewelry_disclosure_84="Colored gemstones may use treatments to enhance natural appearance which may not be permanent and require special care. Diamond weights may not be exact, but are never more than .05 carats below the stated weight";


		boolean bDisclosurePresent = false;

		Integer dicValueId = null;

		if(prodContent.getProductAttributes()!=null && prodContent.getProductAttributes().getProductAttribute()!=null)
		{
			ProductAttribute[] attrs = prodContent.getProductAttributes().getProductAttribute();
			for (ProductAttribute productAttribute : attrs) {

				if(productAttribute.getAttributeId().intValue()==30201)
				{
					bDisclosurePresent = true;
					dicValueId = productAttribute.getProductAttributeTypeChoice().getAttributeValueId().intValue();
					break;
				}
			}
		}

		if (  !bDisclosurePresent && prodContent.getAggrLegalData() == null || prodContent.getAggrLegalData().getHazardMaterialCode() == null
				&& prodContent.getAggrLegalData().getHazardStorageCode() == null
				&& prodContent.getAggrLegalData().getIsCaEmmission() == null
//				&& checkInAttributeGroup("California Emission Compliant") == null
				&& (prodContent.getAggrLegalData().getProp65Flag() == false || prodContent.getAggrLegalData().getProp65Flag() == null)
				//&& xmlProductOffer.getGeoLimiters() == null
				&& (prodContent.getGlobalAttributes() == null || prodContent
				.getGlobalAttributes().getChokingHazard() == null)) {
			CompareValuesUtility.verifyNull("Legal", gbLegal);
		} else {

			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getHazmatMaterialCd(),
					"HazmatMtrCd");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardMaterialCode(), gbLegal == null ? null : gbLegal.getUsDotType(),
					"usDotType");
			verifyNullOrEqual("Legal", prodContent.getAggrLegalData()
					.getHazardStorageCode(), gbLegal == null ? null : gbLegal.getHazmatStorageCd(),
					"HazmatStrgCd");
			verifyNullOrEqual("Legal",
					prodContent.getAggrLegalData().getIsCaEmmission() == null || prodContent.getAggrLegalData().getIsCaEmmission() == false ? null : true,
					gbLegal == null ? null : gbLegal.getIsCaEmmision(), "isCaEmmision");
			verifyNullOrEqual("Legal", (prodContent.getAggrLegalData().getProp65Flag() == null ||
					prodContent.getAggrLegalData().getProp65Flag() == false) ? null : true,
							gbLegal == null ? null : gbLegal.getIsProp65(), "isProp65");
			CompareValuesUtility.addNewMultiValuedFields();
			/*if (xmlProductOffer.getGeoLimiters() != null)
				compareValues(
						"LegalGeo",
						Arrays.asList(xmlProductOffer.getGeoLimiters()
								.getStates().split(",")),
								legal.getLimitedGeos());*/
			
//			if(bDisclosurePresent)
//			{
//				if(dicValueId==52)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_52, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==53)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_53, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==84)
//				{
//					verifyNullOrEqual("Legal",jewelry_disclosure_84, gbLegal == null ? null : gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else if(dicValueId==2534)
//				{
//					CompareValuesUtility.verifyNull("Legal", gbLegal == null ? null : gbLegal.getJewelry()==null?null:gbLegal.getJewelry().getDisclosure(), "jwelery.disclosure");
//				}
//				else
//				{
//					System.out.println(" ===================== check this dicValueId : "+dicValueId+"===================");
//				}
//			}
		}
		verifyChokingHazards(gbLegal,prodContent);
	}
	
	private void verifyChokingHazards(com.generated.vos.content.Legal gbLegal,ProductContent prodContent) {
		Boolean isWarn = false;
		Boolean safetyWarn = false;
		
		if (prodContent.getAggrLegalData() != null &&  prodContent.getAggrLegalData().getChokingHazards() != null) {
			for (ChokingHazardType cType : prodContent.getAggrLegalData().getChokingHazards()
					.getChokingHazard()) {
				if (cType.equals(ChokingHazardType.HAZARD___NO_WARNING))
					isWarn = true;
				else if (cType.equals(ChokingHazardType.OTHER_SAFETY_WARNING))
					safetyWarn = true;
				else
				{
					ArrayList<String> list1 = new ArrayList<String>();
					CompareValuesUtility.verifyItemInList("ChokingHazard", cType.value(), gbLegal == null ? list1 : gbLegal.getChokingHazards());
				}
			}
			CompareValuesUtility.addNewMultiValuedFields();
		}
		
		if(isWarn)
			compareValues("LegalIsNoWarn", true, gbLegal == null ? null : gbLegal.getIsNoWarning());
		if(safetyWarn)
			compareValues("LegalsafetyWarn", true, gbLegal == null ? null : gbLegal.getSafetyWarnings());
	}
	
	/**
	 * Verifies by default isdispelig is set for all sites
	 * @param pContent
	 * @param content
	 */
	private void verifyOperational(ProductContent pContent, Content content) {
		Boolean isdispelig = null;
		for (com.generated.vos.productoffering.Site s : pContent.getSite()) {
			if(s.getId() != 13){
			if (s.getId() == 10 || s.getId() == 6 || s.getId() == 5)
				continue;
			}
			if(sSiteToTest.equalsIgnoreCase("kmart") && (s.getId()==11 ))
				continue;
			
			
			if(s != null && content.getOperational() != null)
			{
				isdispelig = SHCContentCommons.getDispEligValue(Long.toString(s.getId()), content.getOperational());
			}
			/** Changes for Kmart MP project - for common spinid, isdispelig would be set to true for both sites*/
			/** Changes for INCO554932 - Sites should be loaded in all conditions
			/*if(!bCommonSpinId && !bCrossFormattedItem){
				if(sSiteToTest.equalsIgnoreCase("sears") && s.getId() == 1)
					CompareValuesUtility.verifyNull("DispElig",  isdispelig, TestUtils.getSite(s.getId()));
				if(sSiteToTest.equalsIgnoreCase("kmart") && s.getId() == 2)
					CompareValuesUtility.verifyNull("DispElig", isdispelig, TestUtils.getSite(s.getId()));
			}else*/
				CompareValuesUtility.compareValues("DispElig", true, isdispelig, TestUtils.getSite(s.getId())); 
			
		}
		
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void testNewChanges5_20(Content content)
	{

		if(sSiteToTest.equalsIgnoreCase("sears"))
		{
			OperationalAttributes opAttribute = prodOffers[0].getOperationalAttributes();

			if(opAttribute!=null)
			{
				Source[] sources = opAttribute.getSource();

				if(sources!=null)
				{
					String valueXml = null;
					String attrName = null;

					for (Source source : sources) {

						OperationalAttribute[] allAttributes = source.getOperationalAttribute();

						/*============================= SPIN =====================*/
						if(source.getName().equalsIgnoreCase("SPIN"))
						{

							for (OperationalAttribute attribute : allAttributes) 
							{
								try {
									valueXml = attribute.getOperationalValue()[0].getValue();
								} catch (Exception e) {
									valueXml = null;
								}
								attrName = attribute.getName();

								if(attrName.equals("SCHEDULE_NOW") && valueXml.equalsIgnoreCase("Y"))
								{
									compareAsBoolean("SCHEDULE_NOW", valueXml, content.getAutomotive()== null?null:
										content.getAutomotive().getIsScheduleNow());
								}
							}
						}
					}
				}
			}
		}
	}

	private void compareAsBoolean(String field,String sExpectedvalue,Boolean actaul)
	{
		Boolean bExpectedvalue = false;
		if(sExpectedvalue.equals("1") || sExpectedvalue.equals("YES") || sExpectedvalue.equals("Y"))
		{
			bExpectedvalue = true;
		}
		else if (sExpectedvalue.equals("0") || sExpectedvalue.equals("NO")|| sExpectedvalue.equals("N"))
		{
			bExpectedvalue = false;
		}

		//false and null is equal

		if(actaul==null && bExpectedvalue==false)
		{
			CompareValuesUtility.logPassed(field, "false", "null");
		}
		else
		{
			CompareValuesUtility.compareValues(field, bExpectedvalue, actaul);
		}
	}
	
	public void verifyBrand(Brand xmlBrand, com.generated.vos.content.Brand contentBrand) 
	{
		if(xmlBrand == null)
			return;
		String imgSrc=null;
		try {
			imgSrc = contentBrand.getImg().getSrc();
		} catch (Exception e) {
		}

		CompareValuesUtility.verifyNullOrEqual("Brand", xmlBrand.getId(), convertToString(contentBrand.getId()), "Id");

		if((xmlBrand.getLogoImageUrl()==null?"null":xmlBrand.getLogoImageUrl()).equals(imgSrc==null?"null":imgSrc))
		{
			CompareValuesUtility.logPassed("Brand", xmlBrand.getLogoImageUrl()==null?"null":xmlBrand.getLogoImageUrl(),imgSrc==null?"null":imgSrc, "ImageUrl");
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Brand", TestUtils.modifyURL(xmlBrand.getLogoImageUrl()),imgSrc==null?"null":imgSrc, "ImageUrl");
		}

		if(xmlBrand.getName().equals("Â ") && contentBrand.getName().equalsIgnoreCase("&#160;") )
		{
			CompareValuesUtility.logPassed("Brand", " ", "&#160;", "Name");
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Brand",xmlBrand.getName()==null?null:
				TestUtils.encodeHTML(xmlBrand.getName()).replaceAll("`", "&#96;")
				,contentBrand.getName(), "Name");
		}
	}

	List<String> lstFacetAttributes = new ArrayList<String>();
	List<String> lstSpecAttributes = new ArrayList<String>();
	List<String> lstAttributeVals = new ArrayList<String>();
	Map<String, String> attributeToVal = new HashMap<String, String>();
	Map<String, String> attributeToGroup = new HashMap<String, String>();
	Map<Integer, String> groupRanks = new TreeMap<Integer,String>();
	List<String>  lstAttribsNotFound = new ArrayList<>();
	String brandCodeId = null, autoFitmentType = null;
	List<String> ignoreAttrIds = Arrays.asList(new String[] { "781110","797010", "250601", "796910", "796810", "1774","848610" });
	List<String> ignoreFacetAttrIds = Arrays.asList(new String[] { "1109310","12206" });
	List<String> autoIds = Arrays.asList(new String[] { "1035210", "873910" });

	public void verifySpecsGB(List<Spec> specsXML) {

		if(masterHierarchyAttributes == null){
			return;
		}

		if(lstSpecAttributes.isEmpty()){

			if(!specsXML.isEmpty())
				CompareValuesUtility.addFailedDataFieldForReport("No specs expected" , "Specs Found");

			/*CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecName", "No specs expected", "Specs found");
			CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecVal", "No specs expected", "Specs found");*/

			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstSpecAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		verifySpecValues(attributeData, attributeValData, specsXML);

	}

	private void verifySpecValues(Map<String, String> attribData,  Map<String, String> attribValData,List<Spec> specsXML)
	{
		for(String attributeId : lstSpecAttributes)
		{
			String grpNameIA = attributeToGroup.get(attributeId)==null?"Others:":attributeToGroup.get(attributeId);
			boolean bAttributeFound = false;
			boolean bGroupFound = false;
			boolean bAttrValueFound = false;
			boolean bIsDoNotDisplaySpecFound = false;
			String displayEligibility = GreenBoxCache.isDoNotDisplay(attributeId);
			for (Spec spec : specsXML) {
				String grpNameJson = spec.getGrpName();
				if(grpNameIA.equals(grpNameJson)){
					bGroupFound = true;
					for(Attr attr : spec.getAttrs()){

						if(displayEligibility!= null && attr.getName().equals(displayEligibility))
						{
							bIsDoNotDisplaySpecFound = true;
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName",displayEligibility+ ": Do not display set("+attributeId+").  Attribute should not be in specs.", attr.getName() + " found in specs");
							break;
						}

						//Checking to prevent it getting printed everytime the same attribute is found 
						if (attr.getName().equals(attribData.get(attributeId)))
						{
							if(!bAttributeFound){
								CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
								bAttributeFound = true;
								CompareValuesUtility.logPassed("SpecName",attribData.get(attributeId), attr.getName());
							}

							boolean bRes;

							try
							{
								bRes = bAttributeFound && 
										(attributeToVal.get(attributeId).equals(attr.getVal()) 
												||	TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()) 
												|| TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()));

							}
							catch (Exception e) 
							{
								bRes = false;
							}

							if(bRes)
							{
								bAttrValueFound = true;

								if(attributeToVal.get(attributeId).equals(attr.getVal()))
								{
									CompareValuesUtility.logPassed("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}
								else if(TestUtils.encodeHTML(attributeToVal.get(attributeId)).equals(attr.getVal()))
								{
									CompareValuesUtility.logPassed("SpecVal", TestUtils.encodeHTML(attributeToVal.get(attributeId)) , attr.getVal());
								}
								else if (TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))).equals(attr.getVal()))
								{
									CompareValuesUtility.logPassed("SpecVal",TestUtils.encodeHTML(attribValData.get(attributeToVal.get(attributeId))) , attr.getVal());
								}

								break;
							}
							else
							{
								//http://greenvip.prod.ch4.s.com:80/gbox/gb/s/data/get/content/05244463000P
								if(attributeToVal.get(attributeId).replaceAll("\\|","&#124;").equals(attr.getVal()))
								{
									bAttrValueFound = true;

									CompareValuesUtility.logPassed("SpecVal", attributeToVal.get(attributeId) , attr.getVal());
								}
							}

						}
					}

					//If attribute is donotdisplay type and is not displayed, mark as passed
					if(displayEligibility!= null && !bIsDoNotDisplaySpecFound){
						CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
						CompareValuesUtility.logPassed("SpecName", attributeId+":"+displayEligibility, "Do not display set.Not found in specs.");
					}
					//Do the following checks only for displayable attributes
					if(displayEligibility == null){
						if(!bAttributeFound){
							CompareValuesUtility.logPassed("SpecGrpName",grpNameIA, grpNameJson);
							CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
						}
						if(bAttributeFound && !bAttrValueFound){
							CompareValuesUtility.logFailed("SpecVal", attributeToVal.get(attributeId), "Not found");
						}
					}
					break;
				}
			}

			if(!bAttributeFound && !bGroupFound)
				CompareValuesUtility.logFailed("SpecName", attributeId+":"+attribData.get(attributeId), "Not found");
		}
		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyFacetsGB( ProductContent pContent,Content content)
	{
		if(pContent.getProductAttributes()==null)
			return;

		masterHierarchyAttributes = GreenBoxCache.getAttrsForItemClass(itemClassId);
		if(masterHierarchyAttributes == null){
			CompareValuesUtility.logFailed("FacetName", "Expecting attributes in masterHierarchy","No hierarchy found for "+itemClassId);
			return;
		}

		segregateAttributes(pContent.getProductAttributes().getProductAttribute());
		
		if(lstFacetAttributes.isEmpty()){

			if(content.getFacets()!=null)
			{
				//CompareValuesUtility.verifyTrue(specsXML.isEmpty(),"SpecGrpName", "No specs expected", "Specs found");
				/*CompareValuesUtility.logFailed("FacetName", "No facets expected" , "Facets Found");
				CompareValuesUtility.logFailed("FacetVal","No facets expected" , "Facets Found");*/

				CompareValuesUtility.addFailedDataFieldForReport("No facets expected" , "Facets Found");
			}
			//
			return;
		}

		//Hit all attributes
		Map<String, String> attributeData = GreenBoxCache.getAttributeData(lstFacetAttributes);
		Map<String, String> attributeValData = GreenBoxCache.getAttributeValData(lstAttributeVals);

		List<Static> staticFacets=null;

		if(sSiteToTest.equalsIgnoreCase("sears")){
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
			verifyFacetData(staticFacets, attributeData, attributeValData, "Sears");
			if(bCommonSpinId || bCrossFormattedItem){
				staticFacets = content.getFacets() == null? null: 
					content.getFacets().getSites().getKmart() == null? null:content.getFacets().getSites().getKmart().getStatic();
				verifyFacetData(staticFacets, attributeData, attributeValData, "Kmart");
			}
				
		}
		else if(sSiteToTest.equalsIgnoreCase("kmart")){
			staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getKmart().getStatic();
			verifyFacetData(staticFacets, attributeData, attributeValData, "Kmart");
			if(bCommonSpinId || bCrossFormattedItem){
				staticFacets = content.getFacets() == null? null: content.getFacets().getSites().getSears().getStatic();
				verifyFacetData(staticFacets, attributeData, attributeValData, "Sears");
			}
		}
	}
	
	/**
	 * Verify facets in the given sites object
	 * @param staticFacets
	 * @param attributeData
	 * @param attributeValData
	 * @param site 
	 */
	private void verifyFacetData(List<Static> staticFacets,Map<String, String> attributeData,Map<String, String> attributeValData, String site ){
		
		String val ;
		for(String facetAttributeId : lstFacetAttributes)
		{

			if(sSiteToTest.equalsIgnoreCase("sears") && facetAttributeId.equals("1109310"))
			{
				continue;
			}
			boolean bFound = false;
			boolean bAttrValueFound = false;
			if(staticFacets ==  null){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId), "Facets Not found",site);
				continue;
			}
			for(Static gbFacet : staticFacets){
				if(attributeData.get(facetAttributeId).equals(gbFacet.getName())){
					if(!bFound){
						bFound = true;
						CompareValuesUtility.logPassed("FacetName", attributeData.get(facetAttributeId),attributeData.get(facetAttributeId), site);
					}

					val = attributeValData.get(attributeToVal.get(facetAttributeId));
					val= val==null?"null":val;

					if(bFound &&
							(attributeToVal.get(facetAttributeId).equals(gbFacet.getValue())
									|| val.equals(gbFacet.getValue())))
					{
						bAttrValueFound = true;
						if(lstAttributeVals.contains(attributeToVal.get(facetAttributeId)))
							compareValues("FacetVal", attributeValData.get(attributeToVal.get(facetAttributeId)) , gbFacet.getValue(), site);
						else //free value
							compareValues("FacetVal", attributeToVal.get(facetAttributeId) , gbFacet.getValue(), site);
						break;
					}
				}
			}
			if(!bFound){
				CompareValuesUtility.logFailed("FacetName", facetAttributeId+":"+attributeData.get(facetAttributeId),"Not found", site);
			}

			if(!bAttrValueFound){
				CompareValuesUtility.logFailed("FacetVal", attributeToVal.get(facetAttributeId),"Not found", site);
			}
		}
	}


	private void segregateAttributes( ProductAttribute[] productAttributes){


		Integer iCheckValId;
		String sAttrId;
		String sValFree;
		String valueFlag;
		String sValId;
		boolean foundCheck;
		for(ProductAttribute attributeXML : productAttributes )
		{
			sAttrId = String.valueOf(attributeXML.getAttributeId().intValue());
			
			if(sAttrId.equals("1774"))
				System.out.println("To check this one");

			try {
				if(!attributeXML.getProductAttributeTypeChoice().getAttributeValueFlag())
				{
					//System.out.println("Attribute "+sAttrId+" attribute-value-flag = false");
					continue;
				}
			} catch (Exception e1) {
			}

			foundCheck  = false;
			try 
			{
				try {
					iCheckValId = attributeXML.getProductAttributeTypeChoice().getAttributeValueId().intValue();
				} catch (Exception e) {

					iCheckValId =null;
				}

				if(iCheckValId!=null)
				{
					AttributeValueSchema attrValsch = RestExecutor.getDataById(CollectionValuesVal.ATTRIBUTE_VALUE, iCheckValId+"");

					//System.out.println("attrValsch.......... "+attrValsch);
					if(attrValsch==null)
					{
						//System.out.println("Attribute "+sAttrId+" Value id "+iCheckValId +" attrvalue resp is null");
						continue;
					}
					else
					{
						List<AttrId> allattrids = attrValsch.getAttrIds();

						for (AttrId attrId : allattrids) {

							if(attrId.getAttrId().equals(sAttrId))
							{
								foundCheck = true;
								break;
							}
						}

						if(!foundCheck)
						{
							//System.out.println("Attribute "+sAttrId+" is not associate with value "+iCheckValId +" hence skipping");
							continue;
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();

			}


			sValFree = attributeXML.getProductAttributeTypeChoice().getAttributeValueFree();

			valueFlag = String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueFlag());

			try {
				sValId =String.valueOf(attributeXML.getProductAttributeTypeChoice().getAttributeValueId().intValue());
			} catch (Exception e) {
				sValId = null;
			}

			if(autoIds.contains(sAttrId)){
				if(sAttrId.equals("873910")){
					brandCodeId = sValFree;
				}
				if(sAttrId.equals("1035210")){
					switch(sValId){
					case "2509410":{
						autoFitmentType = "AU Cross Fit";
						break;
					}

					case "92":{
						autoFitmentType = "No";
						break;
					}
					case "2509310":{
						autoFitmentType = "Requires Fitment";
						break;
					}
					}
				}
				continue;
			}
			if(ignoreAttrIds.contains(sAttrId) )
				continue;
			
			boolean bFound = false;

			//label is array
			for(Label label : masterHierarchyAttributes.getLabels())
			{
				//each label has attr array again
				for(com.generated.vos.hierarchy.Attr attr : label.getAttrs())
				{
					if(sAttrId.equals(attr.getId()) && (attr.getType().contains("search") 
							|| attr.getType().contains("label")))
					{

						bFound = true;
						if(attr.getType().contains("search")){
							if(!ignoreFacetAttrIds.contains(sAttrId))
								lstFacetAttributes.add(sAttrId);
						}

						if( attr.getType().contains("label")){
							lstSpecAttributes.add(sAttrId);
							if(label.getName() == null)
								groupRanks.put(-1, "Others:");
							else
								groupRanks.put(label.getRank().intValue(), label.getName());

						}
						attributeToGroup.put(sAttrId, label.getName());

						if(sValId != null)
							lstAttributeVals.add(sValId);

						//Commenting td text - ECOM-361803

						/*if(attributeXML.getTrademarkText() != null){
							attributeToVal.put(sAttrId, attributeXML.getTrademarkText());
						}
						else 
						 */


						if( sValFree != null)
							attributeToVal.put(sAttrId, sValFree);
						else if(valueFlag != null && !valueFlag .equals("null"))
							attributeToVal.put(sAttrId, valueFlag.toString());
						else if(sValId != null){
							lstAttributeVals.add(sValId);
							attributeToVal.put(sAttrId, sValId);
						}
						else
							//TODO :: Commenting this for now till publisher settings are fixed
							//							throw new IllegalArgumentException("No attribute val data found");

							break;
					}

				}
				if(bFound)
					break;
			}
			if(!bFound){
				//TODO : Should this be termed as failure?
				lstAttribsNotFound.add(sAttrId);
			}
		}
	}

	boolean isPrimaryAvlbl = false; 
	boolean isPrimaryAvlblOffer = false; 

	private void verifyTaxonomy(Site[] sitesContent, Content content) {

		Map<Long, List<String>> mpSiteHiearachies = new HashMap<Long, List<String>>();

		for ( Site site : sitesContent) {

			long lSiteId = site.getId();
			
			if(lSiteId !=13){

			if(lSiteId > 11 || lSiteId == 10)
				continue;
			}

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				if(hierarchy.getPrimary().equals("true"))
					isPrimaryAvlbl = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			mpSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}

		Map<Long, List<String>> offerSiteHiearachies = new HashMap<Long, List<String>>();

		for ( Site site : prodOffers[0].getSite()) {

			long lSiteId = site.getId();

			if(lSiteId > 11 || lSiteId == 10)
				continue;

			List<String> lstHieararchyIds = new ArrayList<String>();
			for(Hierarchy hierarchy : site.getTaxonomy().getHierarchy()){
				if(hierarchy.getPrimary().equals("true"))
					isPrimaryAvlblOffer = true;
				lstHieararchyIds.add(GenericUtil.convertToString(hierarchy.getId()));
			}

			offerSiteHiearachies.put(lSiteId, lstHieararchyIds);
		}
		
		for(Map.Entry<Long, List<String>> entry : offerSiteHiearachies.entrySet())
		{
			List<String> lstHieararchyIds = entry.getValue();
			for(String hieararchyId : lstHieararchyIds)
			{
				com.generated.vos.hierarchy.Hierarchy responseHierarchy = RestExecutor.getDataById(CollectionValuesVal.WEB_HIERARCHY, hieararchyId);
				
				if(content.getTaxonomy().getWeb() == null && ( responseHierarchy == null || !responseHierarchy.getIsLeaf()))
				{
					CompareValuesUtility.logPassed("TaxonomyWeb", "Invalid Hierarchy in feed for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy is null in GB");
					CompareValuesUtility.verifyNullOrEqual("Site", "[]", content.getSites());
					validHierarchy = false;
				}
				else if(content.getTaxonomy().getWeb() != null &&  responseHierarchy != null && responseHierarchy.getIsLeaf())
				{
					CompareValuesUtility.logPassed("TaxonomyWeb", "Valid Hierarchy in feed for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy present in GB");
					validHierarchy = true;
				}
				else if(content.getTaxonomy().getWeb() != null &&  responseHierarchy != null && !responseHierarchy.getIsLeaf())
				{
					CompareValuesUtility.logFailed("TaxonomyWeb", "IsLeaf is false for "+TestUtils.getSite(entry.getKey())+" = "+hieararchyId, "Web Taxonomy present in GB");
					CompareValuesUtility.verifyNullOrEqual("Site", "[]", content.getSites());
					validHierarchy = false;
				}

			}
		}
		
		if(!(offerSiteHiearachies.size() == 0)){
			commonUtils.compareWebhierarchyGB(offerSiteHiearachies, content.getTaxonomy() == null? null : content.getTaxonomy().getWeb(),sSiteToTest,bCrossFormattedItem);
		}
		commonUtils.compareMasterhierarchyGB(Long.parseLong(itemClassId), content.getTaxonomy() == null? null : content.getTaxonomy().getMaster().getHierarchy());
	}


	private void verifyAssets(ProductContent pContentAsset, Assets contentAssets){

		commonUtils.verifyAssets(pContentAsset.getPrimaryImage(), pContentAsset.getFeatureImages(), contentAssets);

		if(pContentAsset.getProductAssets() != null){
			commonUtils.verifyAssetAttachments(pContentAsset.getProductAssets().getProductAsset(), contentAssets.getAttachments());

			commonUtils.verifyAssetVideo(pContentAsset.getProductAssets().getProductAsset(), contentAssets.getVideos());
		}
		if(pContentAsset.getContentExtensions()!= null)
			commonUtils.verifyContentExtension(pContentAsset.getContentExtensions().getProvider(0), contentAssets.getContentExtensions().get(0));

		CompareValuesUtility.addNewMultiValuedFields();
	}

	private void verifyGroceryTag(ProductContent prodContent,Content content)
	{
		com.generated.vos.content.Nutrition iaGrocery=null;
		try {
			iaGrocery = content.getGrocery().getNutrition();
		} catch (Exception e) {
			iaGrocery=null;
		}

		Nutrition nutritionXML  = prodContent.getNutrition();

		if(nutritionXML==null && iaGrocery==null)
		{
			CompareValuesUtility.logPassed("Grocery", "null","null");
		}
		else if(nutritionXML==null && iaGrocery!=null)
		{
			CompareValuesUtility.logFailed("Grocery", "null","Found in GB");
		}
		else if(nutritionXML!=null && iaGrocery==null)
		{
			CompareValuesUtility.logFailed("Grocery", nutritionXML ,"Not Found in GB");
		}
		else
		{
			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getAllergen()==null?null:nutritionXML.getAllergen().getContent()
					, iaGrocery.getAllergen()==null?null:iaGrocery.getAllergen().getFreeText(),"Allergen");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getGreenInformation()==null?null:nutritionXML.getGreenInformation().getContent(),
					iaGrocery.getGreenInformation()==null?null: iaGrocery.getGreenInformation().getFreeText(),"GreenInformation");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getGuaranteeAnalysis()==null?null:nutritionXML.getGuaranteeAnalysis().getContent()
					, iaGrocery.getGuaranteeAnalysis()==null?null:iaGrocery.getGuaranteeAnalysis().getFreeText(),"GuaranteeAnalysis");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getGuarantees()==null?null:nutritionXML.getGuarantees().getContent()
					,  iaGrocery.getGuarantees()==null?null:iaGrocery.getGuarantees().getFreeText(),"Guarantees");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getHtmlLabel()==null?null:nutritionXML.getHtmlLabel().getContent()
					, iaGrocery.getHtmlLabel()==null?null:iaGrocery.getHtmlLabel().getFreeText(),"HtmlLabel");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getIndications() ==null?null:nutritionXML.getIndications().getContent()
					, iaGrocery.getIndications()==null?null:iaGrocery.getIndications().getFreeText(),"Indications");

			CompareValuesUtility.verifyNullOrEqual("Grocery",nutritionXML.getInstructions() ==null?null:nutritionXML.getInstructions().getContent()
					, iaGrocery.getInstructions()==null?null:iaGrocery.getInstructions().getFreeText(),"Instructions");

			CompareValuesUtility.verifyNullOrEqual("Grocery", nutritionXML.getInteractions()==null?null:nutritionXML.getInteractions().getContent()
					, iaGrocery.getInteractions()==null?null:iaGrocery.getInteractions().getFreeText(),"Interactions");

			String expIng = nutritionXML.getIngredients()==null?null:nutritionXML.getIngredients().getContent();

			String actIng = iaGrocery.getIngredients()==null?null:iaGrocery.getIngredients().getFreeText();

			CompareValuesUtility.verifyNullOrEqual("Grocery", expIng
					, actIng,"Ingredients");

			String expectedWar = nutritionXML.getWarnings()==null?null:nutritionXML.getWarnings().getContent();

			String actualWar = iaGrocery.getWarnings()==null?null:iaGrocery.getWarnings().getFreeText();

			CompareValuesUtility.verifyNullOrEqual("Grocery", 
					expectedWar , actualWar ,"Warnings");


			//---------------------

			CompareValuesUtility.addNewMultiValuedFields();

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getAllergen()==null?null:nutritionXML.getAllergen().getDisplayLabel()
							, iaGrocery.getAllergen()==null?null:iaGrocery.getAllergen().getDispLabel(),"Allergen");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getGreenInformation() ==null?null:nutritionXML.getGreenInformation().getDisplayLabel(),
							iaGrocery.getGreenInformation()==null?null: iaGrocery.getGreenInformation().getDispLabel(),"GreenInformation");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getGuaranteeAnalysis()==null?null:nutritionXML.getGuaranteeAnalysis().getDisplayLabel()
							, iaGrocery.getGuaranteeAnalysis()==null?null:iaGrocery.getGuaranteeAnalysis().getDispLabel(),"GuaranteeAnalysis");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getGuarantees() ==null?null:nutritionXML.getGuarantees().getDisplayLabel()
							,  iaGrocery.getGuarantees()==null?null:iaGrocery.getGuarantees().getDispLabel(),"Guarantees");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getHtmlLabel()==null?null:nutritionXML.getHtmlLabel().getDisplayLabel()
							, iaGrocery.getHtmlLabel()==null?null:iaGrocery.getHtmlLabel().getDispLabel(),"HtmlLabel");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getIndications() ==null?null:nutritionXML.getIndications().getDisplayLabel()
							, iaGrocery.getIndications()==null?null:iaGrocery.getIndications().getDispLabel(),"Indications");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					,nutritionXML.getInstructions() ==null?null:nutritionXML.getInstructions().getDisplayLabel()
							, iaGrocery.getInstructions()==null?null:iaGrocery.getInstructions().getDispLabel(),"Instructions");

			CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
					, nutritionXML.getInteractions()==null?null:nutritionXML.getInteractions().getDisplayLabel()
							, iaGrocery.getInteractions()==null?null:iaGrocery.getInteractions().getDispLabel(),"Interactions");


			if(!(expIng==null || expIng.isEmpty()) && (actIng==null || actIng.isEmpty()))
			{
				CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
						, nutritionXML.getIngredients()==null?null:nutritionXML.getIngredients().getDisplayLabel()
								, iaGrocery.getIngredients()==null?null:iaGrocery.getIngredients().getDispLabel(),"Ingredients");
			}

			if(!(expectedWar==null || expectedWar.isEmpty())  && (actualWar==null || actualWar.isEmpty()))
			{
				CompareValuesUtility.verifyNullOrEqual("Grocery-DispLabel"
						, nutritionXML.getWarnings()==null?null:nutritionXML.getWarnings().getDisplayLabel()
								, iaGrocery.getWarnings()==null?null:iaGrocery.getWarnings().getDispLabel(),"Warnings");
			}

			CompareValuesUtility.addNewMultiValuedFields();
		}
	}
	
	private void verifyFtSearch(ProductContent pContentToTest, APIResponse<Content> allResponse) {
		CompareValuesUtility.verifyNullOrEqual("_ft", bSingleProductOffer?"NV":"V", allResponse.getFtFieldValue("catentrySubType").toString(),"catentrySubType");
		CompareValuesUtility.verifyNullOrEqual("_search", spinId, allResponse.getSearchFieldValue("spinId").toString(),"spinId");
		CompareValuesUtility.verifyNullOrEqual("_search", ssin, allResponse.getSearchFieldValue("ssin"),"ssin");
		if(bSingleProductOffer)
		{
			CompareValuesUtility.verifyNullOrEqual("_search", guid, allResponse.getSearchFieldValue("uid"),"UID");
		}
		commonUtils.verifyDispSite(pContentToTest, allResponse.getSearchFieldList("dispSite"),bCrossFormattedItem,true);
	}
	
	Map<String, String> divMap = new HashMap<String, String>();
	
	private boolean isAutomotive(String storeHierId){
		
		String div = "";
		Boolean isAuto = false;
		if(divMap.get(storeHierId)!=null){
			div = divMap.get(storeHierId);
		}else{
			String name = RestExecutor.getSpecificValueFromJson(CollectionValuesVal.STORE_HIERARCHY, storeHierId, "[{_blob{hierarchy{name}}}]");
			if(name!=null)
				div = name.substring(0, name.indexOf("-"));
			divMap.put(storeHierId, div);
		}
		
		if(div!=null){
			if(sSiteToTest.equals("sears") && (div.equals("095") || div.equals("028") || div.equals("090")))
				isAuto = true;
			else if(sSiteToTest.equals("kmart") && (div.equals("82") || div.equals("83") || div.equals("72")))
				isAuto = true;
		}
		
		return isAuto;
	}

}
