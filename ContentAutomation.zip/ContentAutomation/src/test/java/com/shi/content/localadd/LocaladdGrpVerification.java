package com.shi.content.localadd;

import java.util.ArrayList;
import java.util.List;

import com.generated.vos.localadgrp.Localadgrp_;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class LocaladdGrpVerification implements Runnable {

	String finalId = null;
	List<String> localadddata;
	int currentCount;

	public LocaladdGrpVerification(List<String> pricingDataForProduct,
			int currentC) {
		this.localadddata = pricingDataForProduct;
		this.currentCount = currentC;
	}

	public void run() {
		long l1 = System.currentTimeMillis();
		CompareValuesUtility.init();
		List<String> localadd = new ArrayList<String>();
		String[] singlePriceData = localadddata.get(0).split("\\|");
		// this Gbid is the main id that we hit with api in the greenbox
		String groupId = singlePriceData[0] ;
		// storing data in each line in the list
		try{
		for (String s : localadddata) {
			localadd.add(s);

		}
		// getting data for each line and each field
		for (String id : localadd) {
			String[] afterSplit = id.split("\\|");
			String grpId = afterSplit[0];
			String grpType = afterSplit[1];
			String grpName = afterSplit[2];
			String grpDesc = afterSplit[3];
			String grpStatus = afterSplit[4];
			String grpStDate = afterSplit[5];
			String grpEndDate = afterSplit[6];
			String grpDispOrder = afterSplit[7];
			String storeId = afterSplit[8];

			String gbMainid = grpId;
			System.out.println(gbMainid);
			Localadgrp_ localGB=null;
			if((gbMainid==null) || (grpType==null) || !(LoadProperties.Local_Store.contains(storeId))
					|| (grpStDate.equals("")) ||(grpEndDate.equals("")) ||(grpType.equals("Timed") &&(grpStDate.equals("") ||grpEndDate.equals("")))){
				System.out.println("Group ID is not present");
		}else{
			localGB=RestExecutor.getDataById(CollectionValuesVal.LOCALADGRP,
					gbMainid);
			
		}
				if(localGB!=null){
				CompareValuesUtility.compareValues("GroupID",
						grpId, localGB.getId()
								==null?null:localGB.getId());
				CompareValuesUtility.compareValues("GroupType", localGB.getType()==null?null:localGB.getType()
						, grpType);
				CompareValuesUtility.compareValues("GroupName",
						localGB.getName()==null?null:localGB.getName(),grpName);
				CompareValuesUtility.compareValues("GroupDesc", localGB.getDesc()==null?null:localGB.getDesc()
						, grpDesc);
				CompareValuesUtility.compareValues("GroupStatus", localGB.getStatus()==null?null:localGB.getStatus()
						, grpStatus);
				CompareValuesUtility.compareValues("StartDate", localGB.getSttdt()==null?null:localGB.getSttdt()
						, grpStDate);
				CompareValuesUtility.compareValues("EndDate", localGB.getEnddt()==null?null:localGB.getEnddt()
						, grpEndDate);
				CompareValuesUtility.compareValues("DisplayOrder", localGB.getDispOrd()==null?null:localGB.getDispOrd()
						, grpDispOrder);
				CompareValuesUtility.compareValues("StoreId", localGB.getStoreId()==null?null:localGB.getStoreId()
						, storeId);
			
				}else{
					CompareValuesUtility.logFailed("GroupID",groupId,"No result found in gb");
				}
			
			// Here starts the actual code api...Currenlty once you run this
			// with the small csv file that was there we are getting the output
			// correclty----
		}
		CompareValuesUtility.setupResult(groupId, true);
		CompareValuesUtility.teardown();
		}catch(Throwable e){
			System.out.println("Check this id :"+ groupId);
			e.printStackTrace();
		}		
	}

	
}
