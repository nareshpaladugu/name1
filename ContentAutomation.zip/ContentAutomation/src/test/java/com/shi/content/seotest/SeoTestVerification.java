package com.shi.content.seotest;

import com.generated.vos.content.Content;
import com.shc.autocontent.parsers.APIResponse;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.Variations.SHCContentCommons;

public class SeoTestVerification implements Runnable {

	private String sContentIdToTest;

	public SeoTestVerification(String contentId)
	{
		this.sContentIdToTest=contentId;
	}

	public void run() 
	{

		if(sContentIdToTest!= null)
		{
			System.out.println("Testing id : "+sContentIdToTest);
			APIResponse<Content> allResponse = RestExecutor.getAllDataById(CollectionValuesVal.CONTENT,sContentIdToTest);

			try{
				CompareValuesUtility.init();
				if(allResponse == null){
					CompareValuesUtility.logFailed("Id", sContentIdToTest, " Not found");
					CompareValuesUtility.setupResult(sContentIdToTest, true);
					return;
				}

				Content gbContent = (Content)allResponse.getT();
				if(gbContent == null){
					CompareValuesUtility.logFailed("Id", sContentIdToTest, " Not found");
					CompareValuesUtility.setupResult(sContentIdToTest, true);
					return;
				}

				String type = "";

				try {
					type=gbContent.getClassifications().getCatentrySubType().toString();
				} catch (Exception e) {
				}
				System.out.println(sContentIdToTest + " > type...."+type);
				if(type.equalsIgnoreCase("S"))
				{
					CompareValuesUtility.addDataFieldForReport("Store-Only-Item", "Skipping Test");
				}
				else
				{
					CompareValuesUtility.addDataFieldForReport("Name", gbContent.getName());

					CompareValuesUtility.addDataFieldForReport("Brand Name", gbContent.getBrand()==null?"null":gbContent.getBrand().getName());

					SHCContentCommons.checkSHCSEOURL(gbContent);
				}
				CompareValuesUtility.setupResult(sContentIdToTest, true);
			}catch(Throwable e){
				System.out.println("Check this id :"+ sContentIdToTest);
				e.printStackTrace();
			}finally{
				CompareValuesUtility.teardown();
			}
		}
	}

}
