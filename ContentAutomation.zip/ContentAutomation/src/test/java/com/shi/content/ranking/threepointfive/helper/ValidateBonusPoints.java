package com.shi.content.ranking.threepointfive.helper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.generated.vos.offer.Offer;
import com.generated.vos.rankingmongo.telluride.GetFromTellurideApus;
import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.autocontent.utils.DateUtil;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.ranking.threepointfive.DRMetadata;
import com.shi.content.ranking.threepointfive.DailyRoutineHelper;
import com.shi.content.ranking.threepointfive.TextFileReader;
import com.shi.content.ranking.vos.PriceGridSchema;

/**
 * @author ddaphal
 *
 */
public class ValidateBonusPoints 
{
	@Test(description="ValidateBonusPoints", groups="ValidateBonusPoints")

	public void dailyRoutineTest()
	{
		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("full"))
		{
			try {

				int processed=0;
				MongoCollection<org.bson.Document> collection = RankingMongoDbUtil.getRankingMongoCollection();

				BasicDBObject query = new BasicDBObject();

				FindIterable<org.bson.Document> findResult = collection.find(query).projection(new org.bson.Document("_id",1)).batchSize(5);

				for (org.bson.Document document : findResult) {

					processed++;
					processSingleItem(document.get("_id").toString());

					if(LoadProperties.TESTDATALIMIT!=-1 && processed>=LoadProperties.TESTDATALIMIT)
					{
						System.out.println("Processed required items..");
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else
		{
			String sOfferId=System.getProperty("OfferIds","SPM10343472318");

			String sp[] = sOfferId.split(",");

			for (String sSingleOffer : sp) {

				processSingleItem(sSingleOffer);
			}
		}
	}

	public static void processSingleItem(String sSingleOffer)
	{
		String bonusPointsIft="0";

		try {
			if(sSingleOffer.trim().isEmpty())
				return;

			CompareValuesUtility.init();

			Offer offer= RestExecutor.getDataById(CollectionValuesVal.OFFER, sSingleOffer);

			List<String> sitesToCheckFor = offer.getSites();

			CompareValuesUtility.addDataFieldForReport("Sites", sitesToCheckFor.toString());

			for (String siteNameSingle : sitesToCheckFor) 
			{
				if(siteNameSingle.equalsIgnoreCase("sears") || siteNameSingle.equalsIgnoreCase("kmart"))
				{
					String bonusPointsExpected = getBonusPointsForOffer(sSingleOffer.trim(),siteNameSingle);

					System.out.println("Offer : "+sSingleOffer + " siteName : "+siteNameSingle+" BonusPoints : "+bonusPointsExpected);

					String resp = RestExecutor.getJSonResponse(LoadProperties.rankingBonusService+"/getfromtelluride/"+sSingleOffer);

					List<GetFromTellurideApus> bonusPointList = stringToArray(resp, GetFromTellurideApus[].class);

					for (GetFromTellurideApus getFromTellurideApus : bonusPointList) {

						if(getFromTellurideApus.getSite().equalsIgnoreCase(siteNameSingle))
						{
							bonusPointsIft = String.valueOf(getFromTellurideApus.getBonusPoints().intValue());
						}
					}

					CompareValuesUtility.compareValues("BonusPoints-"+siteNameSingle, bonusPointsExpected,bonusPointsIft);
				}
				else
				{
					System.out.println(" ### Unhandled site ### "+sSingleOffer+" -- "+siteNameSingle +" ");
				}
			}
			CompareValuesUtility.setupResult(sSingleOffer,true);
		} catch (Exception e) {
			System.out.println("Check this offer  : "+sSingleOffer);
			e.printStackTrace();
		}

	}
	public static <T> List<T> stringToArray(String s, Class<T[]> clazz) {
		T[] arr = new Gson().fromJson(s, clazz);
		return Arrays.asList(arr); //or return Arrays.asList(new Gson().fromJson(s, clazz)); for a one-liner
	}

	public static String getBonusPointsForOffer(String sSingleOffer,String siteNameSingle)
	{
		String sTime=null;
		String price=null;

		DRMetadata metaData = DailyRoutineHelper.getMetaData();

		String urlTellurideApi = metaData.getTellurideApi();

		try {
			price = String.valueOf(getPrice(sSingleOffer,siteNameSingle));

		} catch (Exception e) {
			price = "0";
			e.printStackTrace();
		}

		CompareValuesUtility.addDataFieldForReport("Price-PriceGrid-"+siteNameSingle, price);

		//String bodyOrg=TextFileReader.getFile("C:\\Users\\ddaphal\\Desktop\\Req.txt", true);

		//System.out.println("bodyOrg.."+bodyOrg);

		String bodyOrg= "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns=\"http://www.epsilon.com/webservices/\" xmlns:web=\"http://www.epsilon.com/webservices/\">   <soap:Header/>   <soap:Body>      <GetApplicableOffers>         <MessageVersion>3.0</MessageVersion>         <RequestorID>##RequestorID##</RequestorID>         <OrderStoreNumber>09301</OrderStoreNumber>         <CurrentDTTM>##TIME##</CurrentDTTM>         <web:UnconditionalPointsOnly>N</web:UnconditionalPointsOnly>         <ProductList>            <Product>               <HierarchyLevels>                  <HierarchyLevel>                     <LevelCode>##DIV_LEVEL##</LevelCode>                     <LevelCodeDescription>Division</LevelCodeDescription>                     <LevelValue>91</LevelValue>                  </HierarchyLevel>                  <HierarchyLevel>                     <LevelCode>##ITEM_LEVEL##</LevelCode>                     <LevelCodeDescription>ItemNumber</LevelCodeDescription>                     <LevelValue>##OFFER##</LevelValue>                  </HierarchyLevel>               </HierarchyLevels>               <UPC></UPC>               <LineItemAmountTypeCode>1</LineItemAmountTypeCode>               <ItemPrice>##PRICE##</ItemPrice>               <Quantity>1</Quantity>               <web:MapCompliance>N</web:MapCompliance>            </Product>         </ProductList>      </GetApplicableOffers>   </soap:Body></soap:Envelope> ";
		String body;

		sTime = DateUtil.getCurrentDateAndTimeInRquiredFormat("yyyy-MM-dd HH:mm:ss");

		body=bodyOrg.replace("##TIME##", sTime);
		body=body.replace("##OFFER##", sSingleOffer);
		body=body.replace("##PRICE##", price);

		if(siteNameSingle.equalsIgnoreCase("sears"))
		{
			body=body.replace("##RequestorID##", "SCOM");
			body=body.replace("##DIV_LEVEL##", "4");
			body=body.replace("##ITEM_LEVEL##", "8");

		}
		else 
		{
			body=body.replace("##RequestorID##", "KCOM");
			body=body.replace("##DIV_LEVEL##", "3");
			body=body.replace("##ITEM_LEVEL##", "9");
		}


		System.out.println("body..."+body);
		String response =RestExecutor.postForXmlResponse(urlTellurideApi, body);

		String bonusPoints= getBonusBonus(response);

		System.out.println("offerId ... "+sSingleOffer);
		System.out.println("TellurideApi ... "+urlTellurideApi);
		System.out.println("price... "+price);
		System.out.println("time... "+sTime);
		System.out.println("bonusPoints ... "+bonusPoints);

		return bonusPoints;

	}

	
	public static String bodyRequest="";
	
	public static String getTellurideRespose(String sSingleOffer,String siteNameSingle)
	{
		String sTime=null;
		String price=null;

		DRMetadata metaData = DailyRoutineHelper.getMetaData();

		String urlTellurideApi = metaData.getTellurideApi();

		try {
			price = String.valueOf(getPrice(sSingleOffer,siteNameSingle));

		} catch (Exception e) {
			price = "0";
			e.printStackTrace();
		}

		String bodyOrg=TextFileReader.getFile("C:\\Users\\ddaphal\\Desktop\\Req.txt", true);

		System.out.println("bodyOrg.."+bodyOrg);

		//String bodyOrg= "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns=\"http://www.epsilon.com/webservices/\" xmlns:web=\"http://www.epsilon.com/webservices/\">   <soap:Header/>   <soap:Body>      <GetApplicableOffers>         <MessageVersion>3.0</MessageVersion>         <RequestorID>##RequestorID##</RequestorID>         <OrderStoreNumber>09301</OrderStoreNumber>         <CurrentDTTM>##TIME##</CurrentDTTM>         <web:UnconditionalPointsOnly>N</web:UnconditionalPointsOnly>         <ProductList>            <Product>               <HierarchyLevels>                  <HierarchyLevel>                     <LevelCode>##DIV_LEVEL##</LevelCode>                     <LevelCodeDescription>Division</LevelCodeDescription>                     <LevelValue>91</LevelValue>                  </HierarchyLevel>                  <HierarchyLevel>                     <LevelCode>##ITEM_LEVEL##</LevelCode>                     <LevelCodeDescription>ItemNumber</LevelCodeDescription>                     <LevelValue>##OFFER##</LevelValue>                  </HierarchyLevel>               </HierarchyLevels>               <UPC></UPC>               <LineItemAmountTypeCode>1</LineItemAmountTypeCode>               <ItemPrice>##PRICE##</ItemPrice>               <Quantity>1</Quantity>               <web:MapCompliance>N</web:MapCompliance>            </Product>         </ProductList>      </GetApplicableOffers>   </soap:Body></soap:Envelope> ";
		String body;

		sTime = DateUtil.getCurrentDateAndTimeInRquiredFormat("yyyy-MM-dd HH:mm:ss");

		body=bodyOrg.replace("##TIME##", sTime);
		body=body.replace("##OFFER##", sSingleOffer);
		body=body.replace("##PRICE##", price);

		if(siteNameSingle.equalsIgnoreCase("sears"))
		{
			body=body.replace("##RequestorID##", "SCOM");
			body=body.replace("##DIV_LEVEL##", "4");
			body=body.replace("##ITEM_LEVEL##", "8");

		}
		else 
		{
			body=body.replace("##RequestorID##", "KCOM");
			body=body.replace("##DIV_LEVEL##", "3");
			body=body.replace("##ITEM_LEVEL##", "9");
		}

		bodyRequest=body;
		System.out.println("body..."+body);
		String response =RestExecutor.postForXmlResponse(urlTellurideApi, body);
		
		return response;

	}

	public static String getBonusBonus(String response)
	{
		String bonusPoints="0";
		try {
			createResponseXml(response);

			String fileRequestInput = "tmp.xml";

			File xmlFileRequest = new File(fileRequestInput);

			FileInputStream fstreamRequest = new FileInputStream(xmlFileRequest);

			DocumentBuilderFactory docFactory = null;   
			DocumentBuilder docBuilder = null;   
			Document document = null;   
			docFactory = DocumentBuilderFactory.newInstance();   
			docBuilder = docFactory.newDocumentBuilder();   
			document = docBuilder.parse(fstreamRequest);  

			String path = "soap:Envelope,soap:Body,ns2:GetApplicableOffersResponse,ns2:GetApplicableOffersResult,ns2:Epsilon,ns2:Response,ns2:GetApplicableOffersReply"+
					",ns2:RewardsSummary,ns2:RewardPotentialDetails,ns2:BonusPoints";

			String sp[]=path.split(",");

			NodeList nodeList = document.getChildNodes();

			for (String currentNodeName : sp)
			{

				for (int i = 0; i < nodeList.getLength(); i++) 
				{

					for (int j = 0; j < nodeList.getLength(); j++)
					{

						if(nodeList.item(j).getNodeName().contains(currentNodeName))
						{
							nodeList = nodeList.item(j).getChildNodes();
							break;
						}
					}
				}			
			}

			bonusPoints =  nodeList.item(0).getNodeValue().toString();

		} catch (Exception e) 
		{
			e.printStackTrace();
		}

		return bonusPoints;
	}

	public static void createResponseXml(String response)
	{
		try {
			File file2 = new File("tmp.xml");

			FileWriter fw = new FileWriter(file2.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(response);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static float getPrice(String PartNumber,String store) throws URISyntaxException{
		float price = 0;

		String priceGridUrl="";

		priceGridUrl = LoadProperties.PRICEGRIDAPIV2+"?site="+store.toUpperCase()+"&pidType=0&zipCode=0&offer="+PartNumber ;

		String PricingGridResponse=RestExecutor.getJSonResponse(priceGridUrl);

		PricingGridResponse=StringUtils.replace(PricingGridResponse, "price-response", "priceresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "item-response", "itemresponse");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "syw-price", "sywrmemberprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "regular-price", "regularprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "promo-price", "promoprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "ndd-price", "nddprice");
		PricingGridResponse=StringUtils.replace(PricingGridResponse, "sell-price", "sellprice");

		Gson gson=new Gson();

		PriceGridSchema priceGrid = gson.fromJson(PricingGridResponse, PriceGridSchema.class);

		if(!priceGrid.getPriceresponse().getItemresponse().isEmpty()){

			if(priceGrid.getPriceresponse().getItemresponse().get(0).getSywrmemberprice() > 0)
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getSywrmemberprice();
			} else if(priceGrid.getPriceresponse().getItemresponse().get(0).getNddprice()> 0)
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getNddprice();
				System.out.println("price ndd "+PartNumber +": .............................................................................."+price);
			} else if((priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice()!=null)
					&& (priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice().getPrice() > 0))
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getSellprice().getPrice();
			} else if(priceGrid.getPriceresponse().getItemresponse().get(0).getPromoprice() > 0)
			{
				price= priceGrid.getPriceresponse().getItemresponse().get(0).getPromoprice();
			} else
			{
				price=priceGrid.getPriceresponse().getItemresponse().get(0).getRegularprice();
			}

		}

		return price;
	}
}

