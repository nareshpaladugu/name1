package com.shi.content.wcsmigration.verifications;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.generated.vos.offer.Offer;
import com.generated.vos.offerattrs.Offerattrs;
import com.google.gson.Gson;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.softasserts.CompareValuesUtility;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestAPIs;
import com.shc.content.restutils.RestExecutor;
import com.shi.content.wcsmigration.commons.vos.SyncVo;
import com.shi.content.wcsmigration.tests.OfferEligibilityTest_Prop;


/**
 * @author ddaphal
 *
 */
public class OfferEligibilityTest_Prop_Verifications implements Runnable
{

	List<Offerattrs> allOffersAttrsGB;
	List<String> offerIds;
	List<String> offerIdsNotFound;

	public OfferEligibilityTest_Prop_Verifications(List<Offerattrs> allOffersAttrsGB,List<String> offerIds)
	{
		this.allOffersAttrsGB=allOffersAttrsGB;
		this.offerIds=offerIds;
		offerIdsNotFound=new ArrayList<String>();
		offerIdsNotFound.addAll(offerIds);
	}

	public void run() 
	{
		Map<String, Offer> OfferMap = new HashMap<String, Offer>();

		List<Offer> allOffersGB=null;
		try {
			allOffersGB = RestExecutor.getDataById(OfferEligibilityTest_Prop.gb2,CollectionValuesVal.OFFER, offerIds);
		} catch (Exception e) {
			System.out.println("Exception ... : "+e.getMessage());
			
			URI uri = RestAPIs.getByIdURI(OfferEligibilityTest_Prop.gb2,CollectionValuesVal.OFFER, offerIds);
			System.out.println("URIIIIIIIIIIIIIIIIIIII ..... : "+uri.toString());
			String jsonAsString = RestExecutor.getJSonResponse(uri);
			System.out.println(jsonAsString);
		}
		
		if(allOffersGB==null)
		{
			allOffersGB = new ArrayList<Offer>();
		}
			
		//List<Offer> allOffersGB = RestExecutor.getDataById(OfferEligibilityTest_Prop.gb2,CollectionValuesVal.OFFER, offerIds);

		for (Offer offer : allOffersGB) 
		{
			OfferMap.put(offer.getId(), offer);
		}

		if(allOffersAttrsGB==null|| allOffersAttrsGB.isEmpty())
		{
			return;
		}
		for (Iterator<Offerattrs> iterator = allOffersAttrsGB.iterator(); iterator.hasNext();) 
		{
			Offerattrs offerAttrs = iterator.next();

			CompareValuesUtility.init();

			String sOfferIdSingle =	offerAttrs.getId();

			offerIdsNotFound.remove(sOfferIdSingle);

			if(OfferMap.get(sOfferIdSingle)==null)
			{
				CompareValuesUtility.addFailedDataFieldForReport("Offer-not-found",sOfferIdSingle);
			}
			else
			{
				doVerification(offerAttrs , OfferMap.get(sOfferIdSingle));
			}
			CompareValuesUtility.setupResult(sOfferIdSingle,true);
		}

		for (Iterator<String> iterator = offerIdsNotFound.iterator(); iterator.hasNext();) 
		{
			String offerNotFound = iterator.next();

			CompareValuesUtility.init();

			CompareValuesUtility.addFailedDataFieldForReport("Offer-not-found",offerNotFound);

			CompareValuesUtility.setupResult(offerNotFound,true);
		}
	}

	/**
	 * @param offer
	 * @param offerattrs
	 */
	public void doVerification(Offerattrs offerattrs,Offer offer)
	{
		Gson gson = new Gson();

		String offerResp  = gson.toJson(offer);

		String offerAttrsResp  = gson.toJson(offerattrs);

		//	System.out.println(offerResp);
		for (SyncVo syncVo : OfferEligibilityTest_Prop.SyncFieldsList) {

			if(syncVo.getSkip().equalsIgnoreCase("x")||syncVo.getSkip().equalsIgnoreCase("y") || syncVo.getFieldName().isEmpty())
			{
				continue;
			}

			if(syncVo.getOfferPath().isEmpty() || syncVo.getOfferAttrsPath().isEmpty())
			{
				CompareValuesUtility.addDataFieldForReport("Incomplete Mapping", "Field name : "+syncVo.getFieldName());

				CompareValuesUtility.addNewMultiValuedFields();
				continue;
			}
			if(syncVo.getOfferPath()!=null && !syncVo.getOfferPath().contains("?"))
			{
				String expectedValue = JsonStringParser.getJsonValueNew(offerAttrsResp,syncVo.getOfferAttrsPath());

				String actualValue  = JsonStringParser.getJsonValueNew(offerResp,syncVo.getOfferPath());

				if(syncVo.getOfferAttrsPath().equalsIgnoreCase("ffm.wrhsLcn"))
				{
					if(actualValue.equals("[]"))
					{
						actualValue = null;
					}

					if(actualValue!=null)
					actualValue=actualValue.replaceAll("\\[", "").replaceAll("\\]", "");
					
					expectedValue=expectedValue==null?"null":expectedValue;
					actualValue=actualValue==null?"null":actualValue;

					CompareValuesUtility.verifyNullOrEqual(syncVo.getFieldName(), expectedValue,actualValue);
				}

				else
				{
					if(syncVo.getBooleanField().equalsIgnoreCase("y"))
					{
						actualValue=actualValue.equals("null")?null:actualValue;
						CompareValuesUtility.verifyNullOrFalse(syncVo.getFieldName(), expectedValue,actualValue);
					}
					else
					{
						expectedValue=expectedValue==null?"null":expectedValue;
						actualValue=actualValue==null?"null":actualValue;

						CompareValuesUtility.verifyNullOrEqual(syncVo.getFieldName(), expectedValue,actualValue);
					}
				}
			}
		}
	}
}
