package com.shi.zmallutiltasks;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.testng.annotations.Test;

import com.generated.vos.offer.Offer;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.autocontent.testcommons.CollectionValuesVal;
import com.shc.content.restutils.RestExecutor;

public class BasicIFTnGBPartValidation 
{
	@Test
	public void test()
	{
		String parts="5910663501,5910665101,5910663101,5910663301,5910663201,5910665601,531870802,531870402,531868902,531870902,531870502,531869002,531870602,531870702";

		String[] sp= parts.split(",");

		String url = "http://iavip.qa.ch3.s.com/acme/source/";

		String resp;

		ArrayList<String> l =new ArrayList<String>();
		
		String name,classifier,lastupdate,guid,ssin;
		Offer offer;

		for (String singlePart : sp) {

			try {
				resp = RestExecutor.getJSonResponse(url+singlePart);

				name = JsonStringParser.getJsonValueNew(resp, "item.attributes.title",true);

				classifier = JsonStringParser.getJsonValueNew(resp, "item.attributes.classifier",true);

				guid = JsonStringParser.getJsonValueNew(resp, "item.guid",true);

				if(guid==null)
				{
					System.out.println("**************************************");
					System.out.println("************ source : "+ singlePart +" - FAILED ************");
					System.out.println("**************************************");
					//continue;
				}


				List<String> list=null;
				try {
					list = RestExecutor.getIdsByAltKey(CollectionValuesVal.OFFER,"spinId="+singlePart);
				} catch (Exception e1) {

					//System.out.println(e1.getMessage() + " : "+singlePart) ;

				}

				if(list==null || list.isEmpty())
				{
					l.add(singlePart);
					System.out.println("**************************************");
					System.out.println("************ offer : "+ singlePart +" - FAILED ************");
					System.out.println("**************************************");
				}
				/*offer = RestExecutor.getDataById(CollectionValuesVal.OFFER,"SPM"+singlePart);
				if(offer==null || offer.getId()==null)
				{
					System.out.println("**************************************");
					System.out.println("************ offer : "+ singlePart +" - FAILED ************");
					System.out.println("**************************************");
				}*/

				try {
					ssin = JsonStringParser.getJsonValueNew(resp, "item.ssin",true);

					lastupdate = JsonStringParser.getJsonValueNew(resp, "item.lastUpdated",true);

					Date date=new Date(Long.parseLong(lastupdate));


					System.out.println("#"+singlePart+">"+classifier+">"+ssin+">"+guid+">"+date);
				} catch (Exception e) {
					System.out.println("Ignore error...");
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}

		System.out.println(l);
	}
}
