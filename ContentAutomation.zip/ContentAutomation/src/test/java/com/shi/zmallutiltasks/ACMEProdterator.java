package com.shi.zmallutiltasks;

import org.testng.annotations.Test;

import com.shc.autocontent.LoadProperties;
import com.shc.autocontent.parsers.JsonStringParser;
import com.shc.content.restutils.RestExecutor;

public class ACMEProdterator {

	@Test
	public void test()
	{
		int pageSize=200;
		int pageNumber=0;
		String jsonResponse2;
		String u2;
		String id="";
		String ssinSourceBlock="";
		
		String sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled?page-size="+pageSize+"&page="+pageNumber;
		String jsonResponse = RestExecutor.getJSonResponse(sUrl);

		for (int i = 0; i < 50000; i++) {

			
			System.out.println("Page "+i);
			sUrl = "http://"+LoadProperties.IA_SERVER+"/acme/reconciled?page-size="+pageSize+"&page="+i;
			jsonResponse = RestExecutor.getJSonResponse(sUrl);
			String ids2 = JsonStringParser.getJsonValue(jsonResponse, "{items{id}}",",");
			String idsSp[] = ids2.split(",");

			for (String string : idsSp) {
				u2 ="http://iavip.prod.ch4.s.com/acme/reconciled/"+string;
				jsonResponse2 = RestExecutor.getJSonResponse(u2);
				id=JsonStringParser.getJsonValue(jsonResponse2, "{item{id}}",",");
				ssinSourceBlock=JsonStringParser.getJsonValue(jsonResponse2, "{item{attributes{ssinSourceId}}}",",");
				
				if( (id!=null && !id.equals("null") && !id.isEmpty())
						&& (ssinSourceBlock==null || ssinSourceBlock.equals("null") || ssinSourceBlock.isEmpty())
						)
				{
					System.out.println(u2);
				}
			}
		}
	}

}
