package com.shc.autocontent.testcommons;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.testng.annotations.DataProvider;

import com.shc.autocontent.LoadProperties;

public class CatEntryIdsProvider {

	@DataProvider(name="CatEntryIdsProvider", parallel=true)
	public static Object[][] fileProvider(){/*
		String files = LoadProperties.LST_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		return lstOfFiles;
	 */

		String 	catEntryIds=null;
		
		if(LoadProperties.EXECUTION_MODE.equalsIgnoreCase("listBased - catentryIds"))
		{
			System.out.println("Execution mode : listBased - catentryIds");
			
			catEntryIds = LoadProperties.RUN_PARAMS;
		}
		else
		{
			String files = LoadProperties.LST_FILES;
			String[] lstFiles= files.split(",");

			String sFilePath = LoadProperties.LST_FILES_FOLDER+lstFiles[0];

			

			try{
				FileInputStream fstream = new FileInputStream(sFilePath);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.equalsIgnoreCase("CATENTRYID"))
						if(catEntryIds==null)
							catEntryIds = strLine;
						else	
							catEntryIds=catEntryIds+","+strLine;


				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}

			
		}
		
		String sp[]=catEntryIds.split(",");

		Object[][] lstOfObjectToReturn = new Object[sp.length][1];

		int i=0;
		for (String string : sp) {

			lstOfObjectToReturn[i++]= new Object[]{string};
		}
		return lstOfObjectToReturn;
		

	}
}
