package com.shc.autocontent.testcommons;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.DataProvider;

import com.shc.autocontent.LoadProperties;

public class ParamBasedDataProvider {

	
	@DataProvider(parallel=true, name = "executionModeBasedDp")
	public static Iterator<Object[]> provideDataBasedOnRunMode() throws Exception{
		
		List<String> lstValues = new ArrayList<String>();

		switch(LoadProperties.EXECUTION_MODE){
		case "LIST":{
			LoadProperties.IS_LISTBASED_RUN = true;
			lstValues =Arrays.asList(LoadProperties.RUN_PARAMS.split(","));
			break;
		}
		case "BUCKET":{
			LoadProperties.IS_BUCKETBASED_RUN = true;
			if(LoadProperties.RUN_PARAMS.contains("-")){
				String[] range = LoadProperties.RUN_PARAMS.split("-");
				for(Integer i = Integer.parseInt(range[0]); i <= Integer.parseInt(range[1]); i++){
					lstValues.add(i.toString());
				}
				System.out.println("Bucket range "+ LoadProperties.RUN_PARAMS+" translated to:"+lstValues);
				
			}else{
				lstValues = Arrays.asList(LoadProperties.RUN_PARAMS.split(","));
			}
			break;
		}
		case "FILE":{
			try{
				FileInputStream fstream = new FileInputStream(LoadProperties.RUN_PARAMS);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				while ((strLine = br.readLine()) != null)   {
					if(!strLine.isEmpty())
						lstValues.add(strLine);
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}
		
		}
		
		List<Object[]> dataToBeReturned = new ArrayList<Object[]>();
		for (String data : lstValues)
        {
            dataToBeReturned.add(new Object[] { data.trim() } );
        }
		lstValues = null;
		return dataToBeReturned.iterator();
	}
}
