package com.shc.autocontent.testcommons;

import java.util.HashMap;
import java.util.Map;

import com.generated.vos.Shc_pricing.ShcPricing;
import com.generated.vos.attribute.AttributeSchema;
import com.generated.vos.attrvalue.AttributeValueSchema;
import com.generated.vos.content.Content;
import com.generated.vos.content.ContentSchema;
import com.generated.vos.contentbco.Bundle;
import com.generated.vos.contentkafka.Attribute;
import com.generated.vos.contentkafka.ContentKafkaSchema;
import com.generated.vos.hierarchy.Hierarchy;
import com.generated.vos.iafeaturesbyid.IaFeaturesById;
import com.generated.vos.iasourcebyid.IaSourceById;
import com.generated.vos.itemauthority.ItemAuthoritySourceByGuid;
import com.generated.vos.itemauthority.reconciled.ReconciledResponse;
import com.generated.vos.itemauthority.vendor.VendorAttributeRank;
import com.generated.vos.localad.Localad;
import com.generated.vos.localadgrp.Localadgrp_;
import com.generated.vos.localadpage.Localadpage;
import com.generated.vos.localoffer.Localoffer;
import com.generated.vos.offer.Offer;
import com.generated.vos.offer.OfferSchema;
import com.generated.vos.offer.Store;
import com.generated.vos.offerattrs.Offerattrs;
import com.generated.vos.offerattrs.OfferattrsSchema;
import com.generated.vos.outletoffer.Outletoffer;
import com.generated.vos.pricing.PricingSchema;
import com.generated.vos.pricing.kmstore.KmartStorePricing;
import com.generated.vos.prodrel.Prodrel;
import com.generated.vos.promo.Promorel;
import com.generated.vos.promos.Promo;
import com.generated.vos.rankingauto.RankingResponseFull;
import com.generated.vos.store.Unit;
import com.generated.vos.storelocalads.Storelocalads;
import com.generated.vos.varattr.Attributes;
import com.generated.vos.vendor.Seller;
import com.generated.vos.zipNew.Zip;
import com.shc.autocontent.db.CollectionValues;
import com.shi.content.storepricing.StorePricing;

public class CollectionValuesVal extends CollectionValues {

	static Map<String, CollectionValues> allColls = new HashMap<String, CollectionValues>();
	
	public CollectionValuesVal(String sCollection, String sType, Class classType) {
		super(sCollection, sType, classType); 
		if(classType != null && !classType.getSimpleName().contains("Schema"))
			allColls.put(sCollection,this);
	}
	public static final CollectionValues CONTENTSCHEMA = new CollectionValuesVal("content","content", ContentSchema.class);
	public static final CollectionValues CONTENTKAFKASCHEMA = new CollectionValuesVal("contentkafka","content", ContentKafkaSchema.class);
   
	
	public static final CollectionValues CONTENT = new CollectionValuesVal("content","content", Content.class);
	public static final CollectionValues OFFER = new CollectionValuesVal("offer","offer", Offer.class);
	public static final CollectionValues OUTLETOFFER = new CollectionValuesVal("outletoffer","outletoffer", Outletoffer.class);
	public static final CollectionValues LOCALOFFER = new CollectionValuesVal("localoffer","localoffer", Localoffer.class);
	public static final CollectionValues LOCALADGRP = new CollectionValuesVal("localadgrp","localadgrp", Localadgrp_.class);
	public static final CollectionValues LOCALAD = new CollectionValuesVal("localad","localAd", Localad.class);
	public static final CollectionValues STORELOCALAD = new CollectionValuesVal("storelocalads","storelocalads", Storelocalads.class);
	public static final CollectionValues LOCALADPAGE = new CollectionValuesVal("localadpage","localadpage", Localadpage.class);
	public static final CollectionValues OFFER_ATTR = new CollectionValuesVal("offerattrs","offerattrs", Offerattrs.class);
	public static final CollectionValues OFFER_ATTR_SCHEMA = new CollectionValuesVal("offerattrs","offerattrs", OfferattrsSchema.class);
	
	public static final CollectionValues OFFER_SCHEMA = new CollectionValuesVal("offer","offer", OfferSchema.class);
    
	public static final CollectionValues STORE_UNIT=new CollectionValues("store", "unit", Unit.class);
    
	public static final CollectionValues ITEM_CLASS_HIERARCHY = new CollectionValuesVal("itemclasshierarchy","hierarchy", Hierarchy.class);
	public static final CollectionValues WEB_HIERARCHY = new CollectionValuesVal("webhierarchy","hierarchy", Hierarchy.class);
	
	public static final CollectionValues ATTRIBUTE2 = new CollectionValuesVal("attribute","attribute", Attribute.class);
	public static final CollectionValues ATTRIBUTE_VALUE2 = new CollectionValuesVal("attrvalue","attrvalue", Attribute.class);
	public static final CollectionValues ATTRIBUTE = new CollectionValuesVal("attribute","attribute", AttributeSchema.class);
	public static final CollectionValues ATTRIBUTE_VALUE = new CollectionValuesVal("attrvalue","attrvalue", AttributeValueSchema.class);
	
	public static final CollectionValues SELLER = new CollectionValuesVal("seller","seller", Seller.class);
	public static final CollectionValues MPSELLER = new CollectionValuesVal("seller","seller", com.generated.vos.seller.Seller.class);
	
	public static final CollectionValues VARATTRIBUTE = new CollectionValuesVal("varattribute","attributes", Attributes.class);
	
	public static final CollectionValues PROMO = new CollectionValuesVal("promo","promo", Promo.class);
	public static final CollectionValues PROMO_TMP = new CollectionValuesVal("promo_tmp","promo_tmp", Promo.class);
	public static final CollectionValues PREVIEWPROMO = new CollectionValuesVal("previewpromo","promo", Promo.class);
	public static final CollectionValues ZIP_CODE = new CollectionValuesVal("zipcode","zipcode", Promo.class);
	
	public static final CollectionValues ZIP_OLD = new CollectionValuesVal("zipcode","zipcode", com.generated.vos.zipOld.ZipcodeOld.class);
	public static final CollectionValues ZIP_NEW = new CollectionValuesVal("zip","zip", Zip.class);
	
	/*public static final CollectionValues PROMO = new CollectionValues("promo","promo", Promo.class);
	public static final CollectionValues PROMO_SCHEMA = new CollectionValues("promo","promo", PromoMetaSchema.class);*/
	
	public static final CollectionValues PROMO_REL = new CollectionValuesVal("promorel","promorel", Promorel.class);
	public static final CollectionValues PROMO_REL_TMP = new CollectionValuesVal("promorel_tmp","promorel", Promorel.class);
	public static final CollectionValues PROMO_REL_NEW = new CollectionValuesVal("promorel","promorel", com.generated.vos.promo.neww.Promorel.class);
	public static final CollectionValues PREVIEWPROMOREL = new CollectionValuesVal("previewpromorel","promorel", com.generated.vos.promo.neww.Promorel.class);
	public static final CollectionValues STORE_HIERARCHY = new CollectionValuesVal("storehierarchy","hierarchy", Hierarchy.class);
	public static final CollectionValues STORE= new CollectionValuesVal("store","unit",null);
	public static final CollectionValues STORE2= new CollectionValuesVal("store","store",Store.class);
	
	public static final CollectionValues STOREPRICING= new CollectionValuesVal("store_pricing","storeprice",StorePricing.class);
	public static final CollectionValues KM_STOREPRICING= new CollectionValuesVal("kmstore_pricing","storeprice",KmartStorePricing.class);
	
	public static final CollectionValues SHCPRICING= new CollectionValuesVal("shc_pricing","storeprice",ShcPricing.class);
	public static final CollectionValues RGNPRICING = new CollectionValuesVal("rgn_pricing","regionalpricing", ShcPricing.class);
	public static final CollectionValues PRICING = new CollectionValuesVal("pricing","price", PricingSchema.class);
	public static final CollectionValues PRICING_ = new CollectionValuesVal("pricing","pricing", PricingSchema.class);
	
	public static final CollectionValues ITEM_AUTH = new CollectionValuesVal("source","source", ItemAuthoritySourceByGuid.class);
	public static final CollectionValues Reconciled_Response = new CollectionValuesVal("source","source", ReconciledResponse.class);
	public static final CollectionValues VendorAttributeRank = new CollectionValuesVal("source","source", VendorAttributeRank.class);
	
	public static final CollectionValues IA_SOURCE_BY_ID = new CollectionValuesVal("source","source", IaSourceById.class);
	public static final CollectionValues ACME_FEATURE = new CollectionValuesVal("features","item", IaFeaturesById.class);
	public static final CollectionValues ACME_RECONCILED = new CollectionValuesVal("reconciled","item", IaFeaturesById.class);

	public static final CollectionValues IACONTENT = new CollectionValuesVal("iacontent","content", Content.class);
	public static final CollectionValues CONTENTBCO = new CollectionValuesVal("content","bundle", Bundle.class);

	public static final CollectionValues RankingResponseFull = new CollectionValuesVal("RankingResponseFull","RankingResponseFull", RankingResponseFull.class);
	public static final CollectionValues Fixrate = new CollectionValuesVal("fxrates","fxrates", com.generated.vos.fixrate.Fxrates.class);
	
	public static final CollectionValues PRODREL = new CollectionValuesVal("prodrel","prodrel", Prodrel.class);
	
	/**
	 * Returns CollectionValues object for corresponding name
	 * @param name
	 * @return
	 */
	public static CollectionValues getCollection(String name)
	{
		
		name = name.toLowerCase();
		return allColls.get(name);
		
	}

	/**
	 * Returns CollectionValues object of schema for corresponding name
	 * @param name
	 * @return
	 */
	public static CollectionValues getCollectionSchema(String name)
	{
		name = name.toLowerCase();
		switch(name)
		{
			case "content":
				return CONTENTSCHEMA;
			
		}
		
		return null;
	}
}
