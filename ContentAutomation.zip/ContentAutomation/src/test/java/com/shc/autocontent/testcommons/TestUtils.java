package com.shc.autocontent.testcommons;

import java.text.CharacterIterator;
import java.text.DecimalFormat;
import java.text.StringCharacterIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.shc.autocontent.utils.GenericUtil;

public class TestUtils { 

	public static List<String> getSitesList(String sSiteVal)
	{
		sSiteVal = cleanListValue(sSiteVal);
		
		return Arrays.asList(sSiteVal.split(","));
	}

	public static String cleanListValue(String sVal)
	{
		if(sVal==null)
		{
			return null;
		}

		sVal = sVal.replaceAll("\",\"", ",");

		sVal = sVal.replaceFirst("\\[\"", "");
		sVal = sVal.replaceFirst("\"\\]", "");

		sVal = sVal.replaceFirst("\\[", "");
		sVal = sVal.replaceFirst("\\]", "");

		return sVal;
	}


	/**
	 * Returns Site name from Site id
	 * @param siteId
	 * @return
	 */
	public static String getSite(long siteId){
		//Long.valueOf(siteId).intValue()
		switch(GenericUtil.convertToIntFromDouble(siteId)){
		case 1 :
			return "kmart";
		case 2:
			return "sears";
		case 4:
			return "mygofer";
		case 5:
			return "kenmore";
		case 6:
			return "craftsman";
		case 7:
			return "insco";
		case 8:
			return "tgi";
		case 11:
			return "puertorico";
		case 13:
			return "scom";
		default:
			return null;

		}
	}

	/**
	 * Returns store id from store name
	 * 
	 * @param Store_name
	 * @return
	 */
	public static String figureOutStoreIdFromStoreName(String Store_name){

		switch(Store_name.toLowerCase())
		{
		case "sears":
			return "10153";

		case "kmart":
			return "10151";

		case "srspuertorico": case  "puertorico":
			return "10165";

		case "mygofer":case "mygofer3":
			return "10175";

		case "mcgofer":
			return "10161";

		case "kconcierge":
			return "10152";

		case "tgi":
			return "10156";

		case "shcextendedsiteshub": return "10001";
		case "kmartcatalogassetstore": return "10051";
		case "shcb2bdirectstorefrontassetstore": return "10101";
		case "searscatalogassetstore": return "10651";
		case "kenmore": return "10154";
		case "craftsman": return "10155";
		case "mygoferle": return "10701";
		case "rockford": return "12701";
		case "joliet": return "13201";
		case "shccatalogassetstore": return "13701";
		case "mychoice": return "10157";
		case "insuranceb2b": return "11201";
		case "statestreet": return "11701";
		case "greenwich": return "11702";
		case "astorplace": return "11703";


		}

		return null;
	}


	/**
	 * Return catalog id from site id
	 * @param sSiteId
	 * @return
	 */
	public static String figureOutCatalogId(String sSiteId){
		switch(sSiteId){
		case "2":{
			return "12605";
		}
		case "1":{
			return "10104";
		}
		case "4":{
			return "27151";
		}
		case "5":{
			return "12604";
		}
		case "6":{
			return "12602";
		}
		case "7":{
			return "16601";
		}
		case "8":{
			return "23151";
		}
		case "11":{
			return "26151";
		}
		case "2_STORE":{
			return "12609";
		}
		case "1_STORE":{
			return "10105";
		}
		default:{
			return "21101";
		}
		}
	}

	public static String replacesSPecialCharsFromURL(String url)
	{
		//url = url.replaceAll("\"", "inch");
		//url = url.replaceAll("[\\W^[\\.]]", " ");
		//Replace all non-word characters except dots
		//url = url.replaceAll("[^\\w.]", " ");

		/******/
		//Replace all special character except dot, single and double quotes
		url = url.replaceAll("[^\\w.'\"]", " ");

		//Replace double quote with inch if previous character is number, else replace with space
		//Do no replace dot and single quote if previous character is number, else replace with space
		url = handledotsandquotes(url);

		//Replace underscore
		url = url.replaceAll("_", "-");
		/*****/

		url = url.trim();
		url = url.replaceAll("\\s+", "-");

		return url;

	}

	public static String handledotsandquotes(String url) {

		url=url.replaceAll("''", "inch");
		String newUrl = "";
		try {
			CharacterIterator it = new StringCharacterIterator(url);
			char prevChar = ' ';
			// Iterate over the characters in the forward direction
			for (char ch = it.first(); ch != CharacterIterator.DONE; ch = it
					.next()) {
				if ((ch == '"' || ch == '\'' || ch == '.') && prevChar >= '0'
						&& prevChar <= '9') {
					if (ch == '"' )//|| ch == '\''
					{
						newUrl = newUrl + "inch";
					} else {
						newUrl = newUrl + ch;
					}
				} else {
					if (ch == '"' || ch == '\'' || ch == '.')
						newUrl = newUrl + " ";
					else
						newUrl = newUrl + ch;
				}
				prevChar = ch;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return newUrl;
	}


	public static String trimURLBySpace(String url)
	{
		//split by space first
		String[] url1 = url.split(" ");
		List<String> finalList = new ArrayList<String>();
		String toReturn = "";

		//split if words contain -
		for(String urlspaced : url1){

			if(urlspaced.contains("-")){
				finalList.addAll(Arrays.asList(urlspaced.split("-")));
			}else{
				finalList.add(urlspaced);
			}

		}

		int iCounter = 0;
		if(finalList.size()> 8){
			for(String finala : finalList){
				if(finala.equals("&") )//|| finala.equals("")
					continue;
				toReturn += finala + " ";
				iCounter++;
				if(iCounter == 8)
					break;
			}
			return toReturn.trim();
		}else{
			for(String finala : finalList){
				toReturn += finala + " ";
			}
			return toReturn.trim();
		}
	}

	public static String removeAdjacentDuplicateWords(String url, String separator){
		String finalUrl = null;

		String[] urlList = url.split(separator);
		String preWord = null;
		for(String word : urlList) {
			if(preWord==null){
				preWord = word;
				finalUrl = finalUrl==null?word+"-":finalUrl+word+"-";
			}
			else{
				if(word.equals(preWord)){
					continue;
				}else{
					finalUrl = finalUrl==null?word+"-":finalUrl+word+"-";
				}
				preWord = word;
			}
		}
		if(finalUrl.endsWith("-"))
			finalUrl = finalUrl.substring(0, finalUrl.length()-1);

		return finalUrl;
	}

	public static String trimURL(String url)
	{
		int ind =-1;
		for (int i = 0; i < 8; i++) {
			ind = url.indexOf("-",ind+1);
			if(ind==-1)
			{
				ind=url.length();
				break;
			}
		}

		url=url.substring(0,ind);
		return url;
	}

	public static String modifyImgURL(String sURL){

		if(sURL.contains("i.sears.com"))
			return sURL.replace("i.sears.com", "c.shld.net/rpx/i");
		else
			return sURL.replace("i.kmart.com", "c.shld.net/rpx/i");
	}

	public static String modifyURL(String sURL){

		if(sURL==null)
			return null;

		if(sURL.contains("i.sears.com"))
			return sURL.replace("i.sears.com", "c.shld.net/rpx/i");
		else if(sURL.contains("i.sears.com"))
			return sURL.replace("i.kmart.com", "c.shld.net/rpx/i");
		else if	(sURL.contains("s7.sears.com"))
			return sURL.replace("s7.sears.com", "s.shld.net");
		else if (sURL.contains("s7.kmart.com"))
			return sURL.replace("s7.kmart.com", "s.shld.net");

		return sURL;
	}
	public static String modifyBrandImgURL(String sURL){
		//Actaul : src=http://s.shld.net/is/image/Sears/DRAWNTI001
		//Exp : http://s7.sears.com/is/image/Sears/DRAWNTI001
		if(sURL==null)
		{
			return "";
		}
		
		if(sURL.contains("i.sears.com"))
			return sURL.replace("i.sears.com", "c.shld.net/rpx/i");
		else if(sURL.contains("i.sears.com"))
			return sURL.replace("i.kmart.com", "c.shld.net/rpx/i");
		else if	(sURL.contains("s7.sears.com"))
			return sURL.replace("s7.sears.com", "s.shld.net");
		else if (sURL.contains("s7.kmart.com"))
			return sURL.replace("s7.kmart.com", "s.shld.net");
		else if (sURL.contains("download.sears.com"))
			return sURL.replace("download.sears.com", "c.shld.net/assets");

		
		return sURL;
	}

	public static String generateFBMId(long itemId){
		return "SPM"+itemId;
	}


	/**
	 * Generates id for variation item
	 * @param sellerId
	 * @param varGroupId
	 * @return
	 */
	public static String generateVariationId(String sellerId, String varGroupId, String varPgrmType){
		String sifars = "00000000000000000000";
		String seller20 = sifars+sellerId;
		String varGroupId20 = sifars+varGroupId;
		if(varPgrmType.equals("FBS")){
			String op = "S"+seller20.substring(sellerId.length()+1)+varGroupId20.substring(varGroupId.length())+"P";
			op=op.replaceAll("_", "-");
			op=op.replaceAll(" ", "");
			return op;
		}else {

			String op = seller20.substring(sellerId.length())+varGroupId20.substring(varGroupId.length())+"P";
			op=op.replaceAll("_", "-");
			op=op.replaceAll(" ", "");
			return op;
		}
	}


	/**
	 * Generates cpc id given the aggregator id, seller id and item id
	 * @param aggregatorId - fetched from seller collection
	 * @param sellerId - fetched from input xml
	 * @param itemId - from inputxml
	 * @return
	 */
	public static String generateCPCId(String aggregatorId, String sellerId,
			long itemId) {

		if(aggregatorId.equals("0")){
			return "SP"+"A"+sellerId+"S"+itemId;
		}else{
			return "SP"+aggregatorId+"A"+sellerId+"S"+itemId;
		}

	}

	/**
	 * Method to clean desc having new line and special chars
	 * @param desc
	 * @return
	 */
	public static String cleanDesc(String desc){
		//		System.out.println("Incoming desc "+ desc);
		//		desc = desc.replaceAll("''", "'");
		//		desc = desc.replaceAll("&amp;", "&");
		desc = desc.replaceAll("[\n\r]", " ").trim();
		desc = plainEncodeHTML(desc);
		desc = desc.replaceAll("download.sears.com", "c.shld.net/assets");
		desc = desc.replaceAll("i.sears.com", "c.shld.net/rpx/i");
		desc = desc.replaceAll("i.kmart.com", "c.shld.net/rpx/i");
		desc = desc.replaceAll("s7.sears.com", "s.shld.net");
		desc = desc.replaceAll("s7.kmart.com", "s.shld.net");
		//		desc = desc.replaceAll("\\s\\s+", " ").trim();
		//		System.out.println("Outgoing desc "+ desc);
		return desc;
	}

	/**
	 * Rounds number to N decimal points
	 * @param d
	 * @param digits
	 * @return
	 */
	public static String roundToNDigits(Double d,int digits)
	{
/*		String zeros ="";
		for (int i = 0; i < digits; i++) {
			zeros=zeros+"0";
		}
		DecimalFormat f = new DecimalFormat("##."+zeros);
		return f.format(d);
*/		
		String s = "%."+digits+"f";
		return String.format(s, d);
	}

	public static String encodeHTML(String s)
	{
		if(s == null)
			return null;
		StringBuffer out = new StringBuffer();
		for(int i=0; i<s.length(); i++)
		{
			char c = s.charAt(i);
			if(c > 127 || c=='"' )
			{
				out.append("&#"+(int)c+";");
			}
			else
			{
				out.append(c);
			}
		}
		return out.toString();
	}

	public static String plainEncodeHTML(String s)
	{
		if (s == null)
			return null;
		StringBuffer out = new StringBuffer();
		for(int i=0; i<s.length(); i++)
		{
			char c = s.charAt(i);
			if(c > 127 || c==96 || c==124)
			{
				out.append("&#"+(int)c+";");
			}
			else
			{
				out.append(c);
			}
		}
		return out.toString();
	}
	
	public static String replaceDoubleQuotesWithHTML(String s)
	{
		if (s == null)
			return null;
		StringBuffer out = new StringBuffer();
		for(int i=0; i<s.length(); i++)
		{
			char c = s.charAt(i);
			if(c==34)
			{
				out.append("&#"+(int)c+";");
			}
			else
			{
				out.append(c);
			}
		}
		return out.toString();
	}

	/**
	 * Added by Daffy 
	 * Replaces " with \"
	 * @param s
	 * @return
	 */
	public static String replaceDoubleQuotesWithSlashDoubleQuotes(String s) 
	{
		if (s == null)
			return null;
		else
		{
			s=s.replaceAll("\\\\", "\\\\\\\\");
			return s.replaceAll("\"", "\\\\\"");
		}
	}

	/**
	 * replaces " with &#34; 
	 * @param s
	 * @return
	 */
	public static String replaceDoubleQuote(String s) {
		if (s == null)
			return null;
		else
			return s.replaceAll("\"", "&#34;");
	}

	/**
	 * Return true if given json string is empty/null
	 * @param sJsonResp
	 * @return
	 */
	public static boolean isEmptyJsonResponse(String sJsonResp)
	{
		if (sJsonResp==null || sJsonResp.isEmpty() || sJsonResp.equals("[]") || sJsonResp.contains("TIME OUT ERROR") || sJsonResp.equals("null"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean isEmptyString(String sString)
	{
		if (sString==null || sString.isEmpty() )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * Removes underscores from attributes and convert to camel case
	 * eg. Hot_buy would get converted to hotBuy, CLEARANCE_INDICATOR would get converted to clearanceIndicator
	 * @param value - String to be converted
	 * @return
	 */
	public static String removeUnderscoreCharsAndToCamelCase(String value){

		String toReturn = value.toLowerCase();

		String[] allVals = toReturn.split("_");

		int iCounter = 0;
		for(String val : allVals){

			if(iCounter == 0){
				toReturn = val;
				iCounter++;
				continue;
			}
			iCounter++;
			val = val.substring(0, 1).toUpperCase() + val.substring(1).toLowerCase();
			toReturn = toReturn.concat(val);

		}

		return toReturn;

	}

	public static List<String> removeUnderscoreCharsAndToCamelCase(List<String> values){
		List<String> toReturnList = new ArrayList<String>();

		for(String value : values){
			toReturnList.add(removeUnderscoreCharsAndToCamelCase(value));

		}
		return toReturnList;
	}

	/**
	 * Its generic method to prepare displayable object
	 * Input : com.shi.content.itemauthority.VarAttr@d4172e[id=371301,trademarkText=<null>,valueFlag=<null>,valueFree=<null>,valueId=1352601]
	 * Output :  [id=371301,trademarkText=<null>,valueFlag=<null>,valueFree=<null>,valueId=1352601]
	 * @param object
	 * @return
	 */
	public static String getDisplayableObject(Object object)
	{
		String output ="";

		if(object!=null)
		{
			if(object.toString().contains("["))
			{
				output = object.toString().substring(object.toString().indexOf("["));
			}
			else
			{
				output = object.toString();
			}

		}
		return output;
	}


	public static String getDisplayableObjectForList(Object object)
	{
		String output ="";

		if(object!=null)
		{
			output = object.toString().substring(object.toString().indexOf("[",object.toString().indexOf("@")+1));

		}
		return output;
	}
}