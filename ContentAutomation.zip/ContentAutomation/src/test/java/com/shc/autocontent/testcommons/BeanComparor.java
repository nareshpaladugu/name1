package com.shc.autocontent.testcommons;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.beanutils.PropertyUtilsBean;

/**
 * @author ddaphal
 *
 */
public class BeanComparor 
{

	/**
	 * This method will compare two objects, this will work for objects containing field like List<UserDefinedObject>, primitive fields etc
	 * Also this method can be used to compare two promitive types fields also
	 * @param oldObject 
	 * @param newObject
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static boolean compareObjects(Object oldObject, Object newObject) throws Exception
	{

		if(oldObject!=null && newObject!=null)
		{
			// if both fields are string or of primitive types
			if(oldObject.getClass().isPrimitive() || oldObject.getClass().toString().equalsIgnoreCase("class java.lang.String"))
			{
				if(oldObject.toString().trim().equals(newObject.toString().trim()))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else if(oldObject.getClass().toString().contains("Array"))
			{
				java.util.ArrayList<Object> oList1 = (ArrayList<Object>) oldObject;

				java.util.ArrayList<Object> oList2 = (ArrayList<Object>) newObject;
				
				if(oList1.size()!=oList2.size())
				{
					return false;
				}
				for (Object object : oList1) {

					if(!containsObject(oList2,object))
					{
						return false;
					}
				}
			}
		}
		
		BeanMap map = new BeanMap(oldObject);

		PropertyUtilsBean propUtils=null;
		try {
			propUtils = new PropertyUtilsBean();
		} catch (Throwable e1) {
			System.out.println("new PropertyUtilsBean() exception ... "+e1.getMessage()==null?"NPE":e1.getMessage());
		}

		for (Object propNameObject : map.keySet()) 
		{
			String propertyName = (String) propNameObject;

			Object property1 = propUtils==null?"null":propUtils.getProperty(oldObject, propertyName);
			Object property2 = propUtils==null?"null":propUtils.getProperty(newObject, propertyName);

			// consider null value as string null value
			property1 = property1==null?"null":property1;
			property2 = property2==null?"null":property2;

			// For comparing ArrayList field
			if(property1.getClass().toString().contains("Array"))
			{
				java.util.ArrayList<Object> prop1 = (ArrayList<Object>) property1;

				java.util.ArrayList<Object> prop2 = (ArrayList<Object>) property2;

				// if sizes of two lists are not matching, no need to compare contents 
				if(prop1.size()!=prop2.size())
				{
					return false;
				}
				else
				{
					// check if target list has all objects which are there in source list
					for (Object object : prop1) {

						if(!containsObject(prop2,object))
						{
							return false;
						}
					}
					//return true;
				}

			}

			// igonre class and empty properties
			if (!propertyName.equalsIgnoreCase("class") && !propertyName.equalsIgnoreCase("empty")  && (property1==null&&property2!=null || property2==null&&property1!=null
					|| !property1.equals(property2))) 
			{
				//System.out.println("> " + propertyName + " is different (oldValue=\"" + property1 + "\", newValue=\"" + property2 + "\")");

				try {
					//Give a try as Object
					if(!compareObjects(property1,property2))
					{
						return false;
					}

				} catch (Exception e) {
					return false;
				}
			}
		}

		return true;

	}

	/**
	 * Returns true if "objectList" contains "objectToCheck" object
	 * Object can be any user defined object or primitive type object
	 * @param objectList
	 * @param objectToCheck
	 * @return
	 * @throws Exception
	 */
	public static boolean containsObject(List<Object> objectList, Object objectToCheck) throws Exception
	{
		for (Object objectSingle : objectList) 
		{
			try 
			{
				if(compareObjects(objectSingle, objectToCheck))
				{
					return true;
				}
			} catch ( Exception e) {

				e.printStackTrace();
				throw e;
			}
		}

		return false;
	}
	
}
